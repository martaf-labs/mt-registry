<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Routes mt-icons
|--------------------------------------------------------------------------
| Enregistrées uniquement si 'preview.enabled' est true dans la config.
| Protégées par le middleware configuré dans 'preview.middleware'.
|
| ⚠️  En production, ajoutez 'auth' au middleware :
|     MT_ICONS_PREVIEW=true et configurez preview.middleware = ['web', 'auth']
*/

Route::group([
    'prefix'     => config('mt-icons.preview.prefix', 'mt-icons'),
    'middleware' => config('mt-icons.preview.middleware', ['web']),
    'as'         => 'mt-icons.',
], function () {

    // GET /mt-icons/preview — Panneau de prévisualisation Livewire
    Route::get('/preview', \MtIcons\Livewire\IconPreview::class)->name('preview');

    // GET /mt-icons/api/icons — Liste JSON des icônes disponibles
    Route::get('/api/icons', function () {
        $renderer = app(\MtIcons\IconRenderer::class);
        $icons    = $renderer->available();
        sort($icons);

        return response()->json([
            'total' => count($icons),
            'icons' => $icons,
            'mode'  => config('mt-icons.mode'),
        ]);
    })->name('api.icons');

    // GET /mt-icons/api/icon/{name}?mode=inline&size=md&color=currentColor
    Route::get('/api/icon/{name}', function (string $name) {
        abort_unless(preg_match('/^[a-z0-9\-]+$/i', $name), 400, 'Nom invalide');

        $renderer = app(\MtIcons\IconRenderer::class);
        $mode     = request('mode',  config('mt-icons.mode', 'inline'));
        $size     = request('size',  'md');
        $color    = request('color', 'currentColor');

        if (! $renderer->loadSvg($name)) {
            return response()->json(['error' => "Icône introuvable : {$name}"], 404);
        }

        return response()->json([
            'name'  => $name,
            'html'  => $renderer->render($name, compact('mode', 'size', 'color')),
            'exists' => true,
        ]);
    })->name('api.icon');

});
