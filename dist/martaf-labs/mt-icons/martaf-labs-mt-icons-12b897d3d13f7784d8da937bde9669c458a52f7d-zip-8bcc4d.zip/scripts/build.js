#!/usr/bin/env node

/**
 * mt-icons — Script de build principal
 * Lance l'optimisation SVG + génération sprite + génération font
 */

import { execSync } from 'child_process';
import chalk from 'chalk';
import fs from 'fs';

const steps = [
    { label: 'Optimisation des SVG',  cmd: 'node scripts/optimize-svgs.js' },
    { label: 'Génération du sprite',  cmd: 'node scripts/generate-sprite.js' },
    { label: 'Génération de la font', cmd: 'node scripts/generate-font.js' },
];

console.log(chalk.bold.cyan('\n⚡ mt-icons — Build\n'));

const startAll = Date.now();

for (const step of steps) {
    const start = Date.now();
    process.stdout.write(chalk.gray(`  → ${step.label}... `));

    try {
        execSync(step.cmd, { stdio: 'pipe' });
        const ms = Date.now() - start;
        console.log(chalk.green(`✓`) + chalk.gray(` (${ms}ms)`));
    } catch (err) {
        console.log(chalk.red('✗'));
        console.error(chalk.red(err.stderr?.toString() ?? err.message));
        process.exit(1);
    }
}

const totalMs = Date.now() - startAll;

// Afficher la taille du dist/
const distDir = './dist';
let totalSize = 0;

if (fs.existsSync(distDir)) {
    const files = fs.readdirSync(distDir);
    for (const f of files) {
        const stat = fs.statSync(`${distDir}/${f}`);
        totalSize += stat.size;
    }
}

console.log(chalk.bold.green(`\n✅  Build terminé en ${totalMs}ms`));
console.log(chalk.gray(`   dist/ : ${(totalSize / 1024).toFixed(1)} KB total\n`));
