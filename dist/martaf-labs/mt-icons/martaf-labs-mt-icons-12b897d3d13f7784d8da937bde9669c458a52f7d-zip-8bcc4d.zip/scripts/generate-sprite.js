#!/usr/bin/env node

/**
 * mt-icons — Génération du SVG Sprite
 *
 * Lit tous les fichiers .svg dans resources/icons/
 * et produit dist/sprite.svg (fichier unique réutilisable via <use>)
 */

import fs from 'fs';
import path from 'path';
import { globSync } from 'glob';
import chalk from 'chalk';

const INPUT_DIR  = './resources/icons';
const OUTPUT_DIR = './dist';
const OUTPUT_FILE = path.join(OUTPUT_DIR, 'sprite.svg');

// ── Extraction du contenu interne du SVG ─────────────────────────────────────

function extractViewBox(content) {
    const match = content.match(/viewBox="([^"]+)"/);
    return match ? match[1] : '0 0 24 24';
}

function extractInner(content) {
    // Retirer déclaration XML et commentaires
    content = content.replace(/<\?xml[^?]*\?>/g, '');
    content = content.replace(/<!--[\s\S]*?-->/g, '');

    // Extraire le contenu entre <svg> et </svg>
    const match = content.match(/<svg[^>]*>([\s\S]*?)<\/svg>/i);
    return match ? match[1].trim() : '';
}

// ── Build ─────────────────────────────────────────────────────────────────────

const files = globSync(`${INPUT_DIR}/**/*.svg`);

if (files.length === 0) {
    console.warn(chalk.yellow(`⚠️  Aucun SVG trouvé dans ${INPUT_DIR}`));
    process.exit(0);
}

fs.mkdirSync(OUTPUT_DIR, { recursive: true });

let sprite = `<?xml version="1.0" encoding="UTF-8"?>
<!-- mt-icons sprite — généré automatiquement, ne pas éditer -->
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display:none;">
`;

let count = 0;

for (const file of files) {
    const name    = path.basename(file, '.svg');
    const content = fs.readFileSync(file, 'utf8');
    const viewBox = extractViewBox(content);
    const inner   = extractInner(content);

    if (!inner) {
        console.warn(chalk.yellow(`  ⚠️  SVG vide ou invalide : ${file}`));
        continue;
    }

    sprite += `  <symbol id="${name}" viewBox="${viewBox}">\n    ${inner}\n  </symbol>\n`;
    count++;
}

sprite += '</svg>\n';

fs.writeFileSync(OUTPUT_FILE, sprite, 'utf8');

const sizeKB = (Buffer.byteLength(sprite, 'utf8') / 1024).toFixed(2);
console.log(chalk.green(`✅  Sprite généré`) + chalk.gray(` — ${count} icônes · ${sizeKB} KB → ${OUTPUT_FILE}`));
