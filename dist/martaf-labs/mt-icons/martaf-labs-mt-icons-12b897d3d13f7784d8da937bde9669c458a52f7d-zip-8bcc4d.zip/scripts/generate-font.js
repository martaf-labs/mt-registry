#!/usr/bin/env node

/**
 * mt-icons — Génération de la font WOFF2 via fantasticon
 *
 * Produit dans dist/ :
 *   - mt-icons.woff2   (font principale)
 *   - mt-icons.woff    (fallback)
 *   - mt-icons.css     (classes .mt-icon-{name})
 */

import { generateFonts, FontAssetType, OtherAssetType } from 'fantasticon';
import path from 'path';
import { fileURLToPath } from 'url';
import chalk from 'chalk';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT      = path.resolve(__dirname, '..');

const INPUT_DIR    = path.join(ROOT, 'resources', 'icons');
const OUTPUT_DIR   = path.join(ROOT, 'dist');
const TEMPLATE_CSS = path.join(__dirname, 'templates', 'font.css.hbs');
const FONT_NAME    = 'mt-icons';
const CSS_PREFIX   = 'mt-icon';

if (!fs.existsSync(INPUT_DIR) || fs.readdirSync(INPUT_DIR).filter(f => f.endsWith('.svg')).length === 0) {
    console.warn(chalk.yellow(`⚠️  Aucun SVG dans ${INPUT_DIR} — font non générée.`));
    process.exit(0);
}

fs.mkdirSync(OUTPUT_DIR, { recursive: true });

try {
    const result = await generateFonts({
        inputDir:  INPUT_DIR,
        outputDir: OUTPUT_DIR,
        name:      FONT_NAME,
        prefix:    CSS_PREFIX,
        selector:  `.${CSS_PREFIX}`,

        fontTypes:  [FontAssetType.WOFF2, FontAssetType.WOFF],
        assetTypes: [OtherAssetType.CSS],

        formatOptions: {
            woff2: { quality: 100 },
        },

        // Template CSS personnalisé (si présent)
        ...(fs.existsSync(TEMPLATE_CSS) ? {
            templates: { css: TEMPLATE_CSS },
        } : {}),

        // Callback de nommage : transforme le nom de fichier en nom de classe
        getIconId: ({ basename }) => basename.toLowerCase().replace(/\s+/g, '-'),
    });

    const icons = Object.keys(result.assetsOut).filter(k => k !== 'css');
    const cssFile = path.join(OUTPUT_DIR, `${FONT_NAME}.css`);
    const cssSize = fs.existsSync(cssFile)
        ? (fs.statSync(cssFile).size / 1024).toFixed(1)
        : '?';

    const woff2File = path.join(OUTPUT_DIR, `${FONT_NAME}.woff2`);
    const fontSize = fs.existsSync(woff2File)
        ? (fs.statSync(woff2File).size / 1024).toFixed(1)
        : '?';

    console.log(chalk.green(`✅  Font générée`) + chalk.gray(` — ${icons.length} glyphes · WOFF2 ${fontSize} KB · CSS ${cssSize} KB`));
} catch (err) {
    console.error(chalk.red('❌  Erreur lors de la génération de la font :'));
    console.error(err.message);
    process.exit(1);
}
