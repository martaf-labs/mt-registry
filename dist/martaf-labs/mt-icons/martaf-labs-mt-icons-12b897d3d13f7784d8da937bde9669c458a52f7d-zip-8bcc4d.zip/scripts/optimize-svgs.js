#!/usr/bin/env node

/**
 * mt-icons — Optimisation des SVG sources via SVGO
 *
 * Optimise en place les fichiers .svg dans resources/icons/
 * pour réduire leur taille avant le build du sprite et de la font.
 */

import { optimize } from 'svgo';
import { globSync } from 'glob';
import fs from 'fs';
import chalk from 'chalk';

const INPUT_DIR = './resources/icons';

/** @type {import('svgo').Config} */
const svgoConfig = {
    plugins: [
        'removeDoctype',
        'removeXMLProcInst',
        'removeComments',
        'removeMetadata',
        'removeTitle',
        'removeDesc',
        'removeUselessDefs',
        'removeEditorsNSData',
        'removeEmptyAttrs',
        'removeHiddenElems',
        'removeEmptyText',
        'removeEmptyContainers',
        'cleanupEnableBackground',
        'convertStyleToAttrs',
        'convertColors',
        'convertPathData',
        'convertTransform',
        'removeUnknownsAndDefaults',
        'removeNonInheritableGroupAttrs',
        'removeUselessStrokeAndFill',
        'removeUnusedNS',
        'cleanupIds',
        'cleanupNumericValues',
        'moveElemsAttrsToGroup',
        'moveGroupAttrsToElems',
        'collapseGroups',
        'mergePaths',
        'convertShapeToPath',
        'sortAttrs',
        {
            // Forcer fill="currentColor" pour la compatibilité CSS
            name: 'addCurrentColor',
            type: 'visitor',
            fn: () => ({
                element: {
                    enter(node) {
                        if (node.name === 'svg') {
                            node.attributes.fill = node.attributes.fill || 'currentColor';
                        }
                    },
                },
            }),
        },
        {
            // Supprimer width/height fixes (on laisse CSS gérer)
            name: 'removeWidthHeight',
            type: 'visitor',
            fn: () => ({
                element: {
                    enter(node) {
                        if (node.name === 'svg') {
                            delete node.attributes.width;
                            delete node.attributes.height;
                        }
                    },
                },
            }),
        },
    ],
};

// ── Run ───────────────────────────────────────────────────────────────────────

const files = globSync(`${INPUT_DIR}/**/*.svg`);

if (files.length === 0) {
    console.warn(chalk.yellow(`⚠️  Aucun SVG trouvé dans ${INPUT_DIR}`));
    process.exit(0);
}

let totalOriginal = 0;
let totalOptimized = 0;

for (const file of files) {
    const original = fs.readFileSync(file, 'utf8');
    const originalSize = Buffer.byteLength(original, 'utf8');

    try {
        const result = optimize(original, { path: file, ...svgoConfig });
        const optimizedSize = Buffer.byteLength(result.data, 'utf8');
        const saving = (((originalSize - optimizedSize) / originalSize) * 100).toFixed(1);

        fs.writeFileSync(file, result.data, 'utf8');

        totalOriginal  += originalSize;
        totalOptimized += optimizedSize;
    } catch (err) {
        console.warn(chalk.yellow(`  ⚠️  ${file} : ${err.message}`));
    }
}

const globalSaving = (((totalOriginal - totalOptimized) / totalOriginal) * 100).toFixed(1);
const savedKB      = ((totalOriginal - totalOptimized) / 1024).toFixed(1);

console.log(
    chalk.green(`✅  ${files.length} SVG optimisés`) +
    chalk.gray(` — économie : ${savedKB} KB (${globalSaving}%)`)
);
