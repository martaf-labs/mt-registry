<?php

namespace MtIcons;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;
use MtIcons\Components\Icon;
use MtIcons\Console\GenerateSpriteCommand;
use MtIcons\Console\GenerateFontCommand;
use MtIcons\Console\MakeIconCommand;
use MtIcons\Console\ListIconsCommand;

class MtIconsServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // ── Vues ────────────────────────────────────────────────────────────────
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'mt');

        // ── Composant Blade : <x-mt::icon name="home" /> ──────────────────────
        Blade::component(Icon::class, 'mt::icon');

        // ── Directive @mtIcon('home') — rendu d'une icône ────────────────────
        Blade::directive('mtIcon', function (string $expression): string {
            return "<?php echo app(\\MtIcons\\IconRenderer::class)->render({$expression}); ?>";
        });

        // ── Directive @mtIcons — inclut la feuille CSS mode mask ─────────────
        Blade::directive('mtIcons', function (): string {
            return "<?php echo '<link rel=\"stylesheet\" href=\"' . asset('vendor/mt/mt-icons/icons.css') . '\">'; ?>";
        });

        // ── Livewire ───────────────────────────────────────────────────────────
        $this->bootLivewire();

        // ── Routes (preview panel) ─────────────────────────────────────────────
        $this->bootRoutes();

        // ── Publications ──────────────────────────────────────────────────────
        if ($this->app->runningInConsole()) {
            $this->publishes([
                __DIR__ . '/../dist' => public_path('vendor/mt/mt-icons'),
            ], 'mt-icons-assets');

            $this->publishes([
                __DIR__ . '/../config/mt-icons.php' => config_path('mt-icons.php'),
            ], 'mt-icons-config');

            $this->publishes([
                __DIR__ . '/../resources/views' => resource_path('views/vendor/mt'),
            ], 'mt-icons-views');

            $this->publishes([
                __DIR__ . '/../resources/icons' => resource_path('icons'),
            ], 'mt-icons-svgs');

            // Tout en une fois
            $this->publishes([
                __DIR__ . '/../resources/css/icons.css' => public_path('vendor/mt/mt-icons/icons.css'),
            ], 'mt-icons-css');

            // Tout en une fois
            $this->publishes([
                __DIR__ . '/../dist'                     => public_path('vendor/mt/mt-icons'),
                __DIR__ . '/../config/mt-icons.php'       => config_path('mt-icons.php'),
                __DIR__ . '/../resources/css/icons.css'  => public_path('vendor/mt/mt-icons/icons.css'),
            ], 'mt-icons');

            $this->commands([
                GenerateSpriteCommand::class,
                GenerateFontCommand::class,
                MakeIconCommand::class,
                ListIconsCommand::class,
            ]);
        }

        // ── Config merge ───────────────────────────────────────────────────────
        $this->mergeConfigFrom(__DIR__ . '/../config/mt-icons.php', 'mt-icons');
    }

    public function register(): void
    {
        $this->app->singleton(IconRenderer::class, function ($app) {
            return new IconRenderer($app['config']['mt-icons']);
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    protected function bootLivewire(): void
    {
        if (! class_exists(\Livewire\Livewire::class)) {
            return;
        }

        \Livewire\Livewire::component('mt-icons::icon-picker',  \MtIcons\Livewire\IconPicker::class);
        \Livewire\Livewire::component('mt-icons::icon-preview', \MtIcons\Livewire\IconPreview::class);
    }

    protected function bootRoutes(): void
    {
        if (! $this->app['config']->get('mt-icons.preview.enabled', true)) {
            return;
        }

        if (! class_exists(\Livewire\Livewire::class)) {
            return;
        }

        $this->loadRoutesFrom(__DIR__ . '/../routes/web.php');
    }
}
