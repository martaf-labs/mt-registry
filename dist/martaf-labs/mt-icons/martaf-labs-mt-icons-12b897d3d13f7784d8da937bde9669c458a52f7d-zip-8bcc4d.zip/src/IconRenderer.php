<?php

namespace MtIcons;

use Illuminate\Support\Facades\Cache;

class IconRenderer
{
    protected array $config;

    /** @var array<string, string> Cache en mémoire pour la requête courante */
    protected array $memory = [];

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * Point d'entrée principal — utilisé par la directive @mtIcon et le composant.
     *
     * @param  string  $name   Nom de l'icône (ex: "home", "arrow-right")
     * @param  array   $attrs  Attributs optionnels (size, color, class, mode)
     */
    public function render(string $name, array $attrs = []): string
    {
        $mode  = $attrs['mode']  ?? $this->config['mode']  ?? 'inline';
        $size  = $attrs['size']  ?? $this->config['default_size'] ?? 'md';
        $color = $attrs['color'] ?? 'currentColor';
        $class = $attrs['class'] ?? '';

        return match ($mode) {
            'sprite' => $this->renderSprite($name, $size, $color, $class),
            'font'   => $this->renderFont($name, $size, $class),
            default  => $this->renderInline($name, $size, $color, $class),
        };
    }

    // ── Modes de rendu ────────────────────────────────────────────────────────

    public function renderInline(string $name, string $size = 'md', string $color = 'currentColor', string $class = ''): string
    {
        $svg = $this->loadSvg($name);

        if (! $svg) {
            return $this->renderFallback($name);
        }

        $classes = $this->buildClasses(['mt-icon', "mt-icon--{$size}", $class]);
        $svg     = $this->cleanSvg($svg, $color);
        $dim     = $this->config['sizes'][$size] ?? '1.25rem';

        return sprintf(
            '<span class="%s" aria-hidden="true" style="display:inline-flex;align-items:center;line-height:0;width:%s;height:%s;flex-shrink:0;">%s</span>',
            e($classes),
            $dim, $dim,
            $svg
        );
    }

    public function renderSprite(string $name, string $size = 'md', string $color = 'currentColor', string $class = ''): string
    {
        $spriteUrl = asset('vendor/mt/mt-icons/sprite.svg');
        $classes   = $this->buildClasses(['mt-icon', "mt-icon--{$size}", $class]);

        return sprintf(
            '<svg class="%s" style="color:%s;" aria-hidden="true" focusable="false"><use href="%s#%s"></use></svg>',
            e($classes),
            e($color),
            e($spriteUrl),
            e($name)
        );
    }

    public function renderFont(string $name, string $size = 'md', string $class = ''): string
    {
        $prefix  = $this->config['css_prefix'] ?? 'mt-icon';
        $classes = $this->buildClasses([$prefix, "{$prefix}-{$name}", "mt-icon--{$size}", $class]);

        return sprintf(
            '<i class="%s" aria-hidden="true"></i>',
            e($classes)
        );
    }

    // ── Chargement SVG ────────────────────────────────────────────────────────

    public function loadSvg(string $name): ?string
    {
        if (isset($this->memory[$name])) {
            return $this->memory[$name];
        }

        // Cache Laravel (optionnel, configuré dans mt-icons.php)
        if ($this->config['cache'] ?? false) {
            $cacheKey = "mt-icons.{$name}";
            $ttl      = $this->config['cache_ttl'] ?? 3600;

            return Cache::remember($cacheKey, $ttl, fn () => $this->readSvgFile($name));
        }

        $content = $this->readSvgFile($name);
        $this->memory[$name] = $content;

        return $content;
    }

    protected function readSvgFile(string $name): ?string
    {
        // Ordre de résolution : dossier app > dossier package
        $paths = [
            $this->config['icons_path'] . "/{$name}.svg",
            __DIR__ . "/../resources/icons/{$name}.svg",
        ];

        foreach ($paths as $path) {
            if (is_file($path) && is_readable($path)) {
                return file_get_contents($path);
            }
        }

        return null;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Nettoie le SVG : supprime width/height fixes, injecte currentColor si demandé.
     */
    protected function cleanSvg(string $svg, string $color = 'currentColor'): string
    {
        // Supprimer width/height UNIQUEMENT sur le tag <svg> (pas sur les éléments
        // internes comme <rect>/<image>, sinon ils perdent leurs dimensions et
        // disparaissent), puis forcer 100% (taille gérée par le span conteneur).
        $svg = preg_replace_callback(
            '/<svg\b[^>]*>/i',
            fn ($m) => preg_replace('/\s(width|height)="[^"]*"/', '', $m[0]),
            $svg,
            1
        );
        $svg = str_replace('<svg', '<svg width="100%" height="100%"', $svg);

        // Ajouter fill="currentColor" si absent
        if ($color === 'currentColor' && ! str_contains($svg, 'fill=')) {
            $svg = str_replace('<svg', '<svg fill="currentColor"', $svg);
        } elseif ($color !== 'currentColor') {
            $svg = preg_replace('/fill="[^"]*"/', "fill=\"{$color}\"", $svg);
            if (! str_contains($svg, 'fill=')) {
                $svg = str_replace('<svg', "<svg fill=\"{$color}\"", $svg);
            }
        }

        // Forcer viewBox si absent (fallback)
        if (! str_contains($svg, 'viewBox')) {
            $svg = str_replace('<svg', '<svg viewBox="0 0 24 24"', $svg);
        }

        return $svg;
    }

    protected function buildClasses(array $classes): string
    {
        return implode(' ', array_filter(array_map('trim', $classes)));
    }

    protected function renderFallback(string $name): string
    {
        // Carré vide en cas d'icône introuvable (mode debug)
        if (config('app.debug')) {
            return sprintf(
                '<span style="display:inline-flex;width:1em;height:1em;background:#f87171;border-radius:2px;" title="Icon not found: %s"></span>',
                e($name)
            );
        }

        return '';
    }

    public function exists(string $name): bool
    {
        return in_array($name, $this->available());
    }

    /**
     * Retourne la liste de toutes les icônes disponibles.
     *
     * @return string[]
     */
    public function available(): array
    {
        $paths = [
            $this->config['icons_path'],
            __DIR__ . '/../resources/icons',
        ];

        $icons = [];

        foreach ($paths as $dir) {
            if (! is_dir($dir)) {
                continue;
            }
            foreach (glob("{$dir}/*.svg") as $file) {
                $icons[] = basename($file, '.svg');
            }
        }

        return array_unique($icons);
    }
}
