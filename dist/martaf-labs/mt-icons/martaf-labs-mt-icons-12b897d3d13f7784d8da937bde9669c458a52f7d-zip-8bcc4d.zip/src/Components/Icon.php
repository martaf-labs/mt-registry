<?php

namespace MtIcons\Components;

use Illuminate\Support\Str;
use Illuminate\View\Component;
use MtIcons\IconRenderer;

class Icon extends Component
{
    public string $renderedHtml;

    public function __construct(
        public string  $name,
        public string  $size    = 'md',
        public string  $color   = 'currentColor',
        public ?string $class   = null,
        public string  $mode    = '',        // vide = utilise la config
    ) {
        $renderer = app(IconRenderer::class);

        $resolvedMode = $mode ?: config('mt-icons.mode', 'inline');

        // IconRenderer attend le nom BRUT (ex. "home"). On tolère un nom préfixé
        // "mt-icon-..." (renvoyé par mt_get_icon / la config sidebar) en le retirant.
        $resolvedName = Str::startsWith($name, 'mt-icon-') ? Str::after($name, 'mt-icon-') : $name;

        $this->renderedHtml = $renderer->render($resolvedName, [
            'mode'  => $resolvedMode,
            'size'  => $size,
            'color' => $color,
            'class' => $class ?? '',
        ]);
    }

    public function render()
    {
        return view('mt::components.icon');
    }
}
