<?php

use MtIcons\IconRenderer;

/**
 * Render an icon and return its HTML string.
 * Delegates to IconRenderer with the configured mode (inline by default).
 */
if (! function_exists('mt_icon')) {
    function mt_icon(string $name, array $attrs = []): string
    {
        return app(IconRenderer::class)->render($name, $attrs);
    }
}

/**
 * Return all available icon names.
 */
if (! function_exists('mt_icons')) {
    function mt_icons(): array
    {
        return app(IconRenderer::class)->available();
    }
}

/**
 * Icônes disponibles groupées par catégorie (config mt-icons.categories).
 * Les icônes non catégorisées tombent sous "Autres".
 *
 * @return array<string, string[]>  ['Catégorie' => ['icon-a', 'icon-b', …]]
 */
if (! function_exists('mt_icons_categorized')) {
    function mt_icons_categorized(): array
    {
        $all        = mt_icons();
        $categories = config('mt-icons.categories', []);

        $result   = [];
        $assigned = [];

        foreach ($categories as $label => $names) {
            $present = array_values(array_intersect($names, $all));
            if ($present !== []) {
                $result[$label] = $present;
                $assigned = array_merge($assigned, $present);
            }
        }

        $others = array_values(array_diff($all, $assigned));
        sort($others);
        if ($others !== []) {
            $result['Autres'] = $others;
        }

        return $result;
    }
}

/**
 * Check whether an icon exists in the registry.
 */
if (! function_exists('mt_icon_exists')) {
    function mt_icon_exists(string $name): bool
    {
        return app(IconRenderer::class)->exists($name);
    }
}
