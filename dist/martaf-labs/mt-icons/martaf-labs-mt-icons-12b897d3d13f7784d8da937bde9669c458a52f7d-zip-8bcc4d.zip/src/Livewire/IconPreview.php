<?php

namespace MtIcons\Livewire;

use Livewire\Component;
use MtIcons\IconRenderer;

/**
 * Composant Livewire : panneau de prévisualisation du catalogue complet.
 *
 * Accessible via la route /mt-icons/preview (configurable).
 *
 * Fonctionnalités :
 *   - Grille de toutes les icônes disponibles
 *   - Recherche en temps réel
 *   - Sélection d'icône avec copie du snippet
 *   - Changement de mode (inline / sprite / font)
 *   - Changement de taille
 *   - Changement de couleur
 */
class IconPreview extends Component
{
    // ── Filtres ───────────────────────────────────────────────────────────────

    public string $search   = '';
    public string $mode     = 'inline';
    public string $size     = 'xl';
    public string $color    = '#0f172a';
    public string $bgColor  = '#ffffff';

    // ── Sélection ─────────────────────────────────────────────────────────────

    public ?string $selectedIcon = null;
    public string  $copiedSnippet = '';

    // ── Computed ──────────────────────────────────────────────────────────────

    public function getFilteredIconsProperty(): array
    {
        $renderer = app(IconRenderer::class);
        $all = $renderer->available();
        sort($all);

        if (! $this->search) {
            return $all;
        }

        $q = strtolower(trim($this->search));

        return array_values(array_filter(
            $all,
            fn (string $n) => str_contains(strtolower($n), $q)
        ));
    }

    public function getCountProperty(): int
    {
        return count($this->filteredIcons);
    }

    public function getTotalProperty(): int
    {
        return count(app(IconRenderer::class)->available());
    }

    // ── Snippets ──────────────────────────────────────────────────────────────

    public function getSnippetsProperty(): array
    {
        if (! $this->selectedIcon) {
            return [];
        }

        $n = $this->selectedIcon;
        $s = $this->size;
        $c = $this->color !== '#0f172a' ? " color=\"{$this->color}\"" : '';

        return [
            'blade_component' => "<x-mt::icons name=\"{$n}\" size=\"{$s}\"{$c} />",
            'blade_directive' => "@mtIcon('{$n}', ['size' => '{$s}'])",
            'css_class'       => "<i class=\"mt-icon-{$n} mt-icon--{$s}\"></i>",
            'php'             => "app(\\MtIcons\\IconRenderer::class)->render('{$n}', ['size' => '{$s}'])",
        ];
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    public function selectIcon(string $name): void
    {
        $this->selectedIcon = ($this->selectedIcon === $name) ? null : $name;
    }

    public function resetSearch(): void
    {
        $this->search = '';
    }

    // ── Render ────────────────────────────────────────────────────────────────

    public function render()
    {
        return view('mt::livewire.icon-preview', [
            'icons'    => $this->filteredIcons,
            'count'    => $this->count,
            'total'    => $this->total,
            'snippets' => $this->snippets,
            'renderer' => app(IconRenderer::class),
        ])->layout('mt::layouts.preview');
    }
}
