<?php

namespace MtIcons\Livewire;

use Livewire\Component;
use Livewire\Attributes\On;
use MtIcons\IconRenderer;

/**
 * Composant Livewire : sélecteur d'icônes interactif.
 *
 * Usage :
 *   <livewire:mt-icons::icon-picker />
 *   <livewire:mt-icons::icon-picker :selected="$currentIcon" wire:model="icon" />
 *
 * Événements émis :
 *   → icon-selected  { name: string }   quand l'utilisateur choisit une icône
 */
class IconPicker extends Component
{
    // ── Props ─────────────────────────────────────────────────────────────────

    /** Icône actuellement sélectionnée */
    public string $selected = '';

    /** Filtre de recherche */
    public string $search = '';

    /** Mode de rendu des icônes dans le picker */
    public string $mode = 'inline';

    /** Taille d'aperçu dans la grille */
    public string $previewSize = 'lg';

    // ── État interne ──────────────────────────────────────────────────────────

    /** Indique si le panneau est ouvert */
    public bool $open = false;

    // ── Computed ──────────────────────────────────────────────────────────────

    public function getFilteredIconsProperty(): array
    {
        $renderer = app(IconRenderer::class);
        $all      = $renderer->available();

        if (! $this->search) {
            return $all;
        }

        $q = strtolower(trim($this->search));

        return array_values(array_filter(
            $all,
            fn (string $name) => str_contains(strtolower($name), $q)
        ));
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    public function select(string $name): void
    {
        $this->selected = $name;
        $this->open     = false;
        $this->search   = '';

        $this->dispatch('icon-selected', name: $name);
    }

    public function toggle(): void
    {
        $this->open   = ! $this->open;
        $this->search = '';
    }

    public function clear(): void
    {
        $this->selected = '';
        $this->dispatch('icon-selected', name: '');
    }

    // ── Render ────────────────────────────────────────────────────────────────

    public function render()
    {
        return view('mt::livewire.icon-picker', [
            'icons'    => $this->filteredIcons,
            'renderer' => app(IconRenderer::class),
        ]);
    }
}
