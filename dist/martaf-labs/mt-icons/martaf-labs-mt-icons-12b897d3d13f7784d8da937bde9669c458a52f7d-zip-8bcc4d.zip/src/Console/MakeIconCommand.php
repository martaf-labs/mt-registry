<?php

namespace MtIcons\Console;

use Illuminate\Console\Command;

class MakeIconCommand extends Command
{
    protected $signature   = 'mt-icons:make
                                {name : Nom de l\'icône (ex: arrow-right)}
                                {--path= : Chemin vers le SVG source à importer}';

    protected $description = 'Crée ou importe une icône SVG dans le dossier icons';

    public function handle(): int
    {
        $name      = $this->argument('name');
        $sourcePath = $this->option('path');
        $iconsDir  = config('mt-icons.icons_path');

        // S'assurer que le dossier existe
        if (! is_dir($iconsDir)) {
            mkdir($iconsDir, 0755, true);
            $this->line("📁  Dossier créé : {$iconsDir}");
        }

        $destFile = "{$iconsDir}/{$name}.svg";

        if (file_exists($destFile) && ! $this->confirm("L'icône «{$name}» existe déjà. Écraser ?")) {
            $this->info('Opération annulée.');
            return self::SUCCESS;
        }

        if ($sourcePath) {
            // Importer depuis un fichier existant
            if (! file_exists($sourcePath)) {
                $this->error("❌  Fichier source introuvable : {$sourcePath}");
                return self::FAILURE;
            }

            copy($sourcePath, $destFile);
            $this->info("✅  Icône importée : {$destFile}");
        } else {
            // Créer un SVG vierge (template)
            file_put_contents($destFile, $this->svgTemplate($name));
            $this->info("✅  Icône créée : {$destFile}");
            $this->line("    └─ Éditez ce fichier pour ajouter votre path SVG.");
        }

        $this->newLine();
        $this->line("💡  Utilisez l'icône dans vos vues :");
        $this->line("    <x-mt::icons name=\"{$name}\" />");
        $this->line("    @mtIcon('{$name}')");
        $this->line("    <i class=\"mt-icon-{$name}\"></i>  ← mode font uniquement");

        return self::SUCCESS;
    }

    protected function svgTemplate(string $name): string
    {
        return <<<SVG
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
          <!-- Icône : {$name} -->
          <!-- Remplacez ce commentaire par votre path SVG -->
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
        </svg>
        SVG;
    }
}
