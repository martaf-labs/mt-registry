<?php

namespace MtIcons\Console;

use Illuminate\Console\Command;
use Symfony\Component\Process\Process;

class GenerateFontCommand extends Command
{
    protected $signature   = 'mt-icons:font
                                {--input= : Dossier source des SVG}
                                {--output= : Dossier de destination}
                                {--name=mt-icons : Nom de la font}';

    protected $description = 'Génère la font WOFF2 et le CSS associé via fantasticon (Node.js requis)';

    public function handle(): int
    {
        $inputDir  = $this->option('input')  ?? config('mt-icons.icons_path');
        $outputDir = $this->option('output') ?? public_path('vendor/mt/mt-icons');
        $fontName  = $this->option('name');

        // Vérifier que Node.js est disponible
        $nodeCheck = new Process(['node', '--version']);
        $nodeCheck->run();

        if (! $nodeCheck->isSuccessful()) {
            $this->error('❌  Node.js est requis pour générer la font.');
            $this->line('   → Installez Node.js : https://nodejs.org');
            return self::FAILURE;
        }

        // Vérifier que fantasticon est installé
        $fantasticonCheck = new Process(['npx', 'fantasticon', '--version']);
        $fantasticonCheck->run();

        if (! $fantasticonCheck->isSuccessful()) {
            $this->warn('⚠️  fantasticon non trouvé. Installation en cours...');
            $install = new Process(['npm', 'install', '-g', 'fantasticon']);
            $install->run();

            if (! $install->isSuccessful()) {
                $this->error('❌  Impossible d\'installer fantasticon.');
                $this->line($install->getErrorOutput());
                return self::FAILURE;
            }
        }

        if (! is_dir($inputDir)) {
            $this->error("❌  Dossier source introuvable : {$inputDir}");
            return self::FAILURE;
        }

        if (! is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }

        $prefix = config('mt-icons.css_prefix', 'mt-icon');

        $this->info("🔡  Génération de la font «{$fontName}»...");

        $process = new Process([
            'npx', 'fantasticon',
            $inputDir,
            '--output', $outputDir,
            '--name', $fontName,
            '--font-types', 'woff2', 'woff',
            '--asset-types', 'css',
            '--prefix', $prefix,
            '--selector', ".{$prefix}",
        ]);

        $process->setTimeout(120);
        $process->run(function ($type, $buffer) {
            $this->getOutput()->write($buffer);
        });

        if (! $process->isSuccessful()) {
            $this->newLine();
            $this->error('❌  La génération de la font a échoué.');
            return self::FAILURE;
        }

        $this->newLine();
        $this->info("✅  Font générée dans : {$outputDir}");
        $this->line("    └─ {$fontName}.woff2");
        $this->line("    └─ {$fontName}.css");

        return self::SUCCESS;
    }
}
