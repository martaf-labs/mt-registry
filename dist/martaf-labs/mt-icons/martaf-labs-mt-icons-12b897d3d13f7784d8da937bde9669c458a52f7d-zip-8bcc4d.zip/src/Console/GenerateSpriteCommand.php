<?php

namespace MtIcons\Console;

use Illuminate\Console\Command;

class GenerateSpriteCommand extends Command
{
    protected $signature   = 'mt-icons:sprite
                                {--input= : Dossier source des SVG (défaut: config icons_path)}
                                {--output= : Dossier de destination (défaut: public/vendor/mt/mt-icons)}
                                {--optimize : Optimiser les SVG avec SVGO avant génération}';

    protected $description = 'Génère le fichier sprite.svg à partir de vos icônes SVG';

    public function handle(): int
    {
        $inputDir  = $this->option('input')  ?? config('mt-icons.icons_path');
        $outputDir = $this->option('output') ?? public_path('vendor/mt/mt-icons');
        $optimize  = $this->option('optimize');

        if (! is_dir($inputDir)) {
            $this->error("❌  Dossier source introuvable : {$inputDir}");
            return self::FAILURE;
        }

        $files = glob("{$inputDir}/*.svg");

        if (empty($files)) {
            $this->warn("⚠️  Aucun fichier SVG trouvé dans : {$inputDir}");
            return self::SUCCESS;
        }

        $this->info("🔍  {$count} fichier(s) SVG trouvé(s) dans {$inputDir}");
        $count = count($files);

        // Créer le dossier de sortie
        if (! is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }

        $this->info("🔧  Construction du sprite SVG...");

        // En-tête du sprite
        $sprite  = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
        $sprite .= '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display:none;">' . PHP_EOL;

        $bar = $this->output->createProgressBar($count);
        $bar->start();

        $added = 0;

        foreach ($files as $file) {
            $name    = basename($file, '.svg');
            $content = file_get_contents($file);

            if ($content === false) {
                $this->newLine();
                $this->warn("  ⚠️  Impossible de lire : {$file}");
                continue;
            }

            // Extraire le contenu interne du SVG
            $inner = $this->extractSvgInner($content);

            if (! $inner) {
                $bar->advance();
                continue;
            }

            // Extraire le viewBox
            preg_match('/viewBox="([^"]+)"/', $content, $viewBoxMatch);
            $viewBox = $viewBoxMatch[1] ?? '0 0 24 24';

            $sprite .= "  <symbol id=\"{$name}\" viewBox=\"{$viewBox}\">{$inner}</symbol>" . PHP_EOL;
            $added++;

            $bar->advance();
        }

        $sprite .= '</svg>' . PHP_EOL;
        $bar->finish();
        $this->newLine(2);

        $outputFile = "{$outputDir}/sprite.svg";
        file_put_contents($outputFile, $sprite);

        $size = number_format(strlen($sprite) / 1024, 2);
        $this->info("✅  Sprite généré : {$outputFile}");
        $this->line("    └─ {$added} icônes • {$size} KB");

        return self::SUCCESS;
    }

    /**
     * Extrait le contenu SVG (sans la balise <svg> englobante).
     */
    protected function extractSvgInner(string $svg): string
    {
        // Supprimer commentaires XML et déclaration
        $svg = preg_replace('/<\?xml[^?]*\?>/', '', $svg);
        $svg = preg_replace('/<!--.*?-->/s', '', $svg);

        // Extraire ce qui est entre <svg ...> et </svg>
        if (preg_match('/<svg[^>]*>(.*?)<\/svg>/s', $svg, $matches)) {
            return trim($matches[1]);
        }

        return '';
    }
}
