<?php

namespace MtIcons\Console;

use Illuminate\Console\Command;
use MtIcons\IconRenderer;

class ListIconsCommand extends Command
{
    protected $signature   = 'mt-icons:list
                                {--filter= : Filtrer par nom (partiel)}
                                {--json    : Sortie en JSON}
                                {--count   : Afficher uniquement le nombre}';

    protected $description = 'Liste toutes les icônes disponibles dans mt-icons';

    public function handle(): int
    {
        $renderer = app(IconRenderer::class);
        $icons    = $renderer->available();
        sort($icons);

        // Filtre optionnel
        if ($filter = $this->option('filter')) {
            $icons = array_values(array_filter(
                $icons,
                fn (string $n) => str_contains(strtolower($n), strtolower($filter))
            ));
        }

        $total = count($icons);

        // Mode --count
        if ($this->option('count')) {
            $this->line((string) $total);
            return self::SUCCESS;
        }

        // Mode --json
        if ($this->option('json')) {
            $this->line(json_encode([
                'total' => $total,
                'icons' => $icons,
            ], JSON_PRETTY_PRINT));
            return self::SUCCESS;
        }

        // Affichage tableau
        if ($total === 0) {
            $this->warn('⚠️  Aucune icône trouvée' . ($filter ? " pour le filtre « {$filter} »" : '.'));
            $this->line('   → Ajoutez des SVG dans : ' . config('mt-icons.icons_path'));
            return self::SUCCESS;
        }

        $this->newLine();
        $this->line('  <fg=cyan;options=bold>mt-icons</> — Icônes disponibles');
        $this->newLine();

        // Regrouper en colonnes de 3
        $rows = array_chunk($icons, 3);
        $tableRows = array_map(function (array $chunk) {
            return array_pad($chunk, 3, '');
        }, $rows);

        $this->table(
            ['Icône', 'Icône', 'Icône'],
            $tableRows
        );

        $this->newLine();
        $this->line("  <fg=green>✓</> <options=bold>{$total}</> icône(s) au total.");

        if ($filter) {
            $this->line("  <fg=gray>Filtre appliqué :</> « {$filter} »");
        }

        $this->newLine();
        $this->line('  <fg=gray>Panneau de prévisualisation :</> ' . url(config('mt-icons.preview.prefix', 'mt-icons') . '/preview'));
        $this->newLine();

        return self::SUCCESS;
    }
}
