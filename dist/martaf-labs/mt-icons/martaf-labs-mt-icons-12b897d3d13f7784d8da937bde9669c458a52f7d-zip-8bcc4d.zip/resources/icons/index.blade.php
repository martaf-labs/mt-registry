<x-mt::layouts.app>
    @section('title', 'Icônes disponibles')            


    <div class="p-6 space-y-6">

        <h1 class="text-2xl font-bold">Icônes disponibles</h1>

        <!-- Input de recherche -->
        <div class="flex items-center max-w-md">
            <x-mt::form.input 
                id="icon-search"  {{-- Ajout de l'id --}}
                placeholder="Rechercher une icône..."
                icon="magnifying-glass"
            /> 
        </div>

        <!-- Grille des icônes -->
        <div id="icons-grid" class="grid grid-cols-2 gap-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">

            @foreach($icons as $icon)
                <div 
                    data-icon="{{ $icon }}" {{-- Ajout de data-icon pour filtrage JS --}}
                    class="flex flex-col items-center justify-center p-4 transition border rounded-xl hover:bg-gray-50 dark:hover:bg-white/5"
                >

                    <x-mt::icon :name="$icon" class="w-8 h-8 mb-2 text-gray-700 dark:text-gray-200" />

                    <span class="text-xs text-center">{{ $icon }}</span>

                    <button 
                        onclick="copyIconCode('{{ $icon }}')"
                        class="mt-2 text-[10px] text-blue-500 hover:underline"
                    >
                        copier
                    </button>

                </div>
            @endforeach

        </div>

    </div>

    <script>
        // Filtrage en temps réel
        const searchInput = document.getElementById('icon-search');
        const iconsGrid = document.getElementById('icons-grid');

        if (searchInput && iconsGrid) {
            searchInput.addEventListener('input', function(e) {
                const query = e.target.value.toLowerCase();
                iconsGrid.querySelectorAll('[data-icon]').forEach(el => {
                    el.style.display = el.dataset.icon.toLowerCase().includes(query) ? 'flex' : 'none';
                });
            });
        }
    </script>

    <script>
    function copyIconCode(iconName) {
        // On copie le code Blade simple, pas le SVG
        const iconCode = `<x-mt::icon name="${iconName}" />`;

        // Utilisation du clipboard API
        navigator.clipboard.writeText(iconCode)
            .then(() => {
                // Notification simple
                alert(`Le code de l'icône "${iconName}" a été copié dans le presse-papiers.`);
            })
            .catch(err => {
                console.error('Erreur lors de la copie : ', err);
                alert('Une erreur est survenue lors de la copie de l\'icône.');
            });
    }
    </script>

</x-mt::layouts.app>