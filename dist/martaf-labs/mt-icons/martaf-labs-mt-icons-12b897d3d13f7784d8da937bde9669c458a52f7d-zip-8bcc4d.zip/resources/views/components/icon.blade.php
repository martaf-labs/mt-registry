{{--
    mt-icons — Composant <x-mt::icon>
    Le rendu HTML est géré par IconRenderer.
    Les attributs Alpine/HTML (x-show, x-cloak, wire:*, etc.) sont
    transmis via un <span> wrapper pour ne pas être perdus.
--}}
{{--
    ⚠️ Le wrapper DOIT être inline-flex + line-height:0 : un <span> inline nu a une
    boîte de ligne au line-height hérité et pose l'icône sur la BASELINE → icône
    décalée de ~3-4 px vers le haut à côté d'un texte dans tout conteneur flex
    (boutons, menus…). Styles inline (pas de classe Tailwind arbitraire — CSS précompilé).
--}}
<span {{ $attributes->except(['name', 'size', 'color', 'mode'])->merge(['style' => 'display:inline-flex;align-items:center;line-height:0;']) }}>{!! $renderedHtml !!}</span>
