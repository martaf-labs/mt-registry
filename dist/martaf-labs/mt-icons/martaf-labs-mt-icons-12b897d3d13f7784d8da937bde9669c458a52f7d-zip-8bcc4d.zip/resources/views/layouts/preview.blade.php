<!DOCTYPE html>
<html lang="fr" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mt-icons — Catalogue des icônes</title>

    {{-- Tailwind CDN (preview only) --}}
    <script src="https://cdn.tailwindcss.com"></script>

    {{-- Livewire --}}
    @livewireStyles

    {{-- Google Fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,400&family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --ink:     #0a0a0f;
            --ink-2:   #1e1e2e;
            --ink-3:   #2d2d42;
            --muted:   #6b7280;
            --accent:  #6366f1;
            --accent2: #ec4899;
            --surface: #f8f8fc;
            --border:  #e5e5f0;
            --mono:    'DM Mono', monospace;
            --sans:    'Syne', sans-serif;
        }

        * { box-sizing: border-box; }

        body {
            font-family: var(--sans);
            background: var(--surface);
            color: var(--ink);
            min-height: 100vh;
        }

        /* Grain overlay */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
            pointer-events: none;
            z-index: 9999;
        }

        .font-mono { font-family: var(--mono); }
        .font-sans  { font-family: var(--sans); }

        /* Scrollbar */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

        /* Highlight pulsé sur copie */
        @keyframes flash {
            0%,100% { background: transparent; }
            50%      { background: rgba(99,102,241,.15); }
        }
        .flash { animation: flash .4s ease; }
    </style>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        ink:    '#0a0a0f',
                        ink2:   '#1e1e2e',
                        accent: '#6366f1',
                        a2:     '#ec4899',
                    },
                    fontFamily: {
                        sans: ['Syne', 'sans-serif'],
                        mono: ['DM Mono', 'monospace'],
                    }
                }
            }
        }
    </script>
</head>
<body class="h-full">
    {{ $slot }}
    @livewireScripts
</body>
</html>
