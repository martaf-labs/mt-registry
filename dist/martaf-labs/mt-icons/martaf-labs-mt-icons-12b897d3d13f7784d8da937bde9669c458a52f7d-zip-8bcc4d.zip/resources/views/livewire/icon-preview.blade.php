<div
    x-data="{
        copied: null,
        copySnippet(text, key) {
            navigator.clipboard.writeText(text).then(() => {
                this.copied = key;
                setTimeout(() => this.copied = null, 2000);
            });
        }
    }"
    class="flex flex-col min-h-screen"
>

{{-- ══════════════════════════════════════════════════════════════
     HEADER
══════════════════════════════════════════════════════════════ --}}
<header class="sticky top-0 z-50 border-b border-gray-200 bg-white/80 backdrop-blur-xl">
    <div class="max-w-screen-2xl mx-auto px-6 h-16 flex items-center justify-between gap-6">

        {{-- Logo --}}
        <div class="flex items-center gap-3 shrink-0">
            <div class="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="white" class="w-4 h-4">
                    <path d="M9.315 7.584C12.195 3.883 16.695 1.5 21.75 1.5a.75.75 0 0 1 .75.75c0 5.056-2.383 9.555-6.084 12.436A6.75 6.75 0 0 1 9.75 22.5a.75.75 0 0 1-.75-.75v-4.131A15.838 15.838 0 0 1 6.382 15H2.25a.75.75 0 0 1-.75-.75 6.75 6.75 0 0 1 7.815-6.666ZM15 6.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z"/>
                    <path d="M5.26 17.242a.75.75 0 1 0-.897-1.203 5.243 5.243 0 0 0-2.05 5.022.75.75 0 0 0 .625.627 5.243 5.243 0 0 0 5.022-2.051.75.75 0 1 0-1.202-.897 3.744 3.744 0 0 1-3.008 1.51c0-1.23.592-2.323 1.51-3.008Z"/>
                </svg>
            </div>
            <div>
                <span class="font-bold text-sm tracking-tight text-gray-900">mt-icons</span>
                <span class="hidden sm:inline text-xs text-gray-400 ml-2 font-mono">catalogue</span>
            </div>
        </div>

        {{-- Barre de recherche --}}
        <div class="flex-1 max-w-md relative">
            <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" viewBox="0 0 24 24" fill="currentColor">
                <path fill-rule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clip-rule="evenodd"/>
            </svg>
            <input
                wire:model.live.debounce.200ms="search"
                type="text"
                placeholder="Rechercher une icône..."
                class="w-full pl-9 pr-4 py-2 text-sm bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition font-mono placeholder:font-sans"
            >
            @if($search)
                <button wire:click="resetSearch" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                        <path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd"/>
                    </svg>
                </button>
            @endif
        </div>

        {{-- Contrôles --}}
        <div class="flex items-center gap-3 shrink-0">

            {{-- Mode --}}
            <div class="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
                @foreach(['inline' => 'SVG', 'sprite' => 'Sprite', 'font' => 'Font'] as $val => $label)
                    <button
                        wire:click="$set('mode', '{{ $val }}')"
                        class="px-2.5 py-1 text-xs rounded-md font-medium transition {{ $mode === $val ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700' }}"
                    >{{ $label }}</button>
                @endforeach
            </div>

            {{-- Taille --}}
            <select
                wire:model.live="size"
                class="text-xs border border-gray-200 rounded-lg px-2 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
            >
                @foreach(['xs', 'sm', 'md', 'lg', 'xl', '2xl'] as $s)
                    <option value="{{ $s }}">{{ $s }}</option>
                @endforeach
            </select>

            {{-- Couleur --}}
            <label class="relative cursor-pointer" title="Couleur des icônes">
                <div class="w-8 h-8 rounded-lg border-2 border-gray-200 overflow-hidden transition hover:border-indigo-400">
                    <input wire:model.live="color" type="color" class="absolute inset-0 opacity-0 cursor-pointer w-full h-full">
                    <div class="w-full h-full" style="background: {{ $color }}"></div>
                </div>
            </label>

            {{-- Compteur --}}
            <span class="text-xs font-mono text-gray-400 tabular-nums whitespace-nowrap">
                <span class="font-semibold text-gray-700">{{ $count }}</span> / {{ $total }}
            </span>
        </div>
    </div>
</header>

{{-- ══════════════════════════════════════════════════════════════
     BODY
══════════════════════════════════════════════════════════════ --}}
<div class="flex flex-1 max-w-screen-2xl mx-auto w-full">

    {{-- ── Grille d'icônes ────────────────────────────────────────────────── --}}
    <main class="flex-1 p-6 overflow-y-auto">

        @if($count === 0)
            <div class="flex flex-col items-center justify-center h-64 text-gray-400 gap-3">
                <svg class="w-12 h-12 text-gray-200" viewBox="0 0 24 24" fill="currentColor">
                    <path fill-rule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clip-rule="evenodd"/>
                </svg>
                <p class="text-sm">Aucune icône trouvée pour <span class="font-mono font-semibold">« {{ $search }} »</span></p>
                <button wire:click="resetSearch" class="text-xs text-indigo-500 hover:underline">Réinitialiser</button>
            </div>
        @else
            <div class="grid grid-cols-[repeat(auto-fill,minmax(90px,1fr))] gap-2">
                @foreach($icons as $icon)
                    <button
                        wire:click="selectIcon('{{ $icon }}')"
                        class="group relative flex flex-col items-center gap-2 p-3 rounded-xl border transition-all duration-150
                               {{ $selectedIcon === $icon
                                   ? 'bg-indigo-50 border-indigo-300 shadow-sm shadow-indigo-100'
                                   : 'bg-white border-gray-100 hover:border-indigo-200 hover:bg-indigo-50/40' }}"
                        title="{{ $icon }}"
                    >
                        {{-- Icône --}}
                        <span class="transition-transform duration-150 group-hover:scale-110 {{ $selectedIcon === $icon ? 'scale-110' : '' }}">
                            {!! $renderer->render($icon, ['mode' => $mode, 'size' => $size, 'color' => $color]) !!}
                        </span>

                        {{-- Nom --}}
                        <span class="text-[10px] font-mono text-gray-500 truncate w-full text-center leading-tight {{ $selectedIcon === $icon ? 'text-indigo-600 font-semibold' : '' }}">
                            {{ $icon }}
                        </span>

                        {{-- Badge sélectionné --}}
                        @if($selectedIcon === $icon)
                            <span class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-indigo-500"></span>
                        @endif
                    </button>
                @endforeach
            </div>
        @endif
    </main>

    {{-- ── Panneau latéral (détail icône sélectionnée) ──────────────────────── --}}
    @if($selectedIcon)
        <aside class="w-80 shrink-0 border-l border-gray-100 bg-white/70 backdrop-blur-sm sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto p-5 flex flex-col gap-5">

            {{-- Aperçu principal --}}
            <div class="flex flex-col items-center gap-3 p-6 rounded-2xl border border-gray-100 bg-gray-50">
                <div class="transition-all">
                    {!! $renderer->render($selectedIcon, ['mode' => $mode, 'size' => '2xl', 'color' => $color]) !!}
                </div>
                <div>
                    <p class="font-mono text-sm font-semibold text-center text-gray-800">{{ $selectedIcon }}</p>
                    <p class="text-xs text-center text-gray-400 mt-0.5">{{ ucfirst($mode) }} · {{ $size }}</p>
                </div>
            </div>

            {{-- Aperçu multi-tailles --}}
            <div>
                <p class="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2">Tailles</p>
                <div class="flex items-end gap-3 flex-wrap">
                    @foreach(['xs', 'sm', 'md', 'lg', 'xl', '2xl'] as $s)
                        <div class="flex flex-col items-center gap-1">
                            {!! $renderer->render($selectedIcon, ['mode' => $mode, 'size' => $s, 'color' => $color]) !!}
                            <span class="text-[9px] font-mono text-gray-400">{{ $s }}</span>
                        </div>
                    @endforeach
                </div>
            </div>

            {{-- Snippets --}}
            <div class="flex flex-col gap-2">
                <p class="text-xs font-semibold text-gray-400 uppercase tracking-widest">Usage</p>

                @foreach([
                    'blade_component' => 'Composant',
                    'blade_directive' => 'Directive',
                    'css_class'       => 'CSS class',
                    'php'             => 'PHP',
                ] as $key => $label)
                    @if(isset($snippets[$key]))
                        <div
                            x-data
                            class="group relative"
                        >
                            <p class="text-[10px] font-medium text-gray-400 mb-1">{{ $label }}</p>
                            <div
                                class="relative rounded-lg bg-gray-900 text-gray-100 overflow-hidden cursor-pointer"
                                @click="copySnippet('{{ addslashes($snippets[$key]) }}', '{{ $key }}'); $wire.dispatch('snippet-copied')"
                                :class="{ 'flash': copied === '{{ $key }}' }"
                            >
                                <code class="block font-mono text-[10px] leading-relaxed p-3 pr-8 break-all whitespace-pre-wrap">{{ $snippets[$key] }}</code>
                                <button class="absolute top-2 right-2 text-gray-500 hover:text-gray-200 transition">
                                    <template x-if="copied !== '{{ $key }}'">
                                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                                        </svg>
                                    </template>
                                    <template x-if="copied === '{{ $key }}'">
                                        <svg class="w-3.5 h-3.5 text-green-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <polyline points="20 6 9 17 4 12"/>
                                        </svg>
                                    </template>
                                </button>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>

            {{-- Fermer --}}
            <button
                wire:click="selectIcon('{{ $selectedIcon }}')"
                class="mt-auto text-xs text-gray-400 hover:text-gray-600 transition flex items-center justify-center gap-1.5"
            >
                <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                    <path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd"/>
                </svg>
                Fermer le détail
            </button>
        </aside>
    @endif
</div>

</div>
