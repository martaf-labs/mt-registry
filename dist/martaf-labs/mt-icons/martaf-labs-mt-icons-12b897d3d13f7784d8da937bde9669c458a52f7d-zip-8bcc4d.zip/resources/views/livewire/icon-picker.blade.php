<div
    class="relative"
    x-data="{ open: @entangle('open') }"
    x-on:keydown.escape.window="open = false"
    x-on:click.outside="open = false"
>

{{-- ── Déclencheur ──────────────────────────────────────────────────────────── --}}
<button
    wire:click="toggle"
    type="button"
    class="group flex items-center gap-2.5 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:border-indigo-300 hover:bg-indigo-50/30 transition-all duration-150 min-w-[160px] text-left"
>
    @if($selected)
        {{-- Icône sélectionnée --}}
        <span class="shrink-0 text-indigo-600">
            {!! app(\MtIcons\IconRenderer::class)->render($selected, ['mode' => $mode, 'size' => 'sm']) !!}
        </span>
        <span class="flex-1 font-mono text-sm text-gray-700 truncate">{{ $selected }}</span>
        <button
            wire:click.stop="clear"
            type="button"
            class="ml-auto text-gray-300 hover:text-red-400 transition"
            title="Effacer"
        >
            <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                <path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd"/>
            </svg>
        </button>
    @else
        {{-- Placeholder --}}
        <svg class="w-4 h-4 text-gray-300 shrink-0" viewBox="0 0 24 24" fill="currentColor">
            <path d="M9.315 7.584C12.195 3.883 16.695 1.5 21.75 1.5a.75.75 0 0 1 .75.75c0 5.056-2.383 9.555-6.084 12.436A6.75 6.75 0 0 1 9.75 22.5a.75.75 0 0 1-.75-.75v-4.131A15.838 15.838 0 0 1 6.382 15H2.25a.75.75 0 0 1-.75-.75 6.75 6.75 0 0 1 7.815-6.666ZM15 6.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z"/>
        </svg>
        <span class="flex-1 text-sm text-gray-400">Choisir une icône</span>
        <svg class="w-3.5 h-3.5 text-gray-300 group-hover:text-indigo-400 transition" viewBox="0 0 24 24" fill="currentColor">
            <path fill-rule="evenodd" d="M12.53 16.28a.75.75 0 0 1-1.06 0l-7.5-7.5a.75.75 0 0 1 1.06-1.06L12 14.69l6.97-6.97a.75.75 0 1 1 1.06 1.06l-7.5 7.5Z" clip-rule="evenodd"/>
        </svg>
    @endif
</button>

{{-- ── Dropdown ──────────────────────────────────────────────────────────────── --}}
<div
    x-show="open"
    x-transition:enter="transition ease-out duration-150"
    x-transition:enter-start="opacity-0 scale-95 -translate-y-1"
    x-transition:enter-end="opacity-100 scale-100 translate-y-0"
    x-transition:leave="transition ease-in duration-100"
    x-transition:leave-start="opacity-100 scale-100"
    x-transition:leave-end="opacity-0 scale-95 -translate-y-1"
    class="absolute z-50 top-full left-0 mt-1.5 w-[320px] rounded-2xl border border-gray-100 bg-white shadow-xl shadow-black/5 overflow-hidden"
>
    {{-- Recherche --}}
    <div class="p-2 border-b border-gray-50">
        <div class="relative">
            <svg class="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" viewBox="0 0 24 24" fill="currentColor">
                <path fill-rule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clip-rule="evenodd"/>
            </svg>
            <input
                wire:model.live.debounce.150ms="search"
                type="text"
                placeholder="Rechercher..."
                class="w-full pl-8 pr-3 py-1.5 text-sm bg-gray-50 rounded-xl border-0 focus:outline-none focus:ring-1 focus:ring-indigo-400 font-mono"
                x-ref="searchInput"
                x-init="$watch('open', v => v && $nextTick(() => $refs.searchInput.focus()))"
            >
        </div>
    </div>

    {{-- Grille d'icônes --}}
    <div class="overflow-y-auto max-h-64 p-2">
        @if(count($icons) === 0)
            <p class="text-xs text-center text-gray-400 py-6 font-mono">Aucune icône « {{ $search }} »</p>
        @else
            <div class="grid grid-cols-6 gap-1">
                @foreach($icons as $icon)
                    <button
                        wire:click="select('{{ $icon }}')"
                        type="button"
                        class="group flex flex-col items-center gap-1 p-2 rounded-lg transition-all
                               {{ $selected === $icon
                                   ? 'bg-indigo-100 text-indigo-600'
                                   : 'hover:bg-gray-50 text-gray-600 hover:text-indigo-500' }}"
                        title="{{ $icon }}"
                    >
                        {!! $renderer->render($icon, ['mode' => $mode, 'size' => 'md', 'color' => $selected === $icon ? '#4f46e5' : 'currentColor']) !!}
                    </button>
                @endforeach
            </div>
        @endif
    </div>

    {{-- Footer info --}}
    <div class="border-t border-gray-50 px-3 py-1.5 flex items-center justify-between">
        <span class="font-mono text-[10px] text-gray-400">{{ count($icons) }} icône(s)</span>
        <a href="{{ route('mt-icons.preview') }}" target="_blank" class="text-[10px] text-indigo-400 hover:text-indigo-600 transition">
            Catalogue complet →
        </a>
    </div>
</div>

</div>
