<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Mode de rendu par défaut
    |--------------------------------------------------------------------------
    | 'inline'  → SVG injecté dans le DOM (flexibilité CSS maximale)
    | 'sprite'  → <use href="sprite.svg#name"> (1 requête HTTP)
    | 'font'    → Icon Font via classe CSS (ultra-léger)
    */
    'mode' => env('MT_ICONS_MODE', 'inline'),

    /*
    |--------------------------------------------------------------------------
    | Taille par défaut
    |--------------------------------------------------------------------------
    | Valeurs : 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'
    */
    'default_size' => 'md',

    /*
    |--------------------------------------------------------------------------
    | Chemin vers les icônes SVG de l'application
    |--------------------------------------------------------------------------
    | Prioritaire sur les icônes embarquées dans le package.
    */
    'icons_path' => resource_path('icons'),

    /*
    |--------------------------------------------------------------------------
    | Préfixe CSS (mode font)
    |--------------------------------------------------------------------------
    | Exemple : 'mt-icon' → classe CSS "mt-icon-home"
    */
    'css_prefix' => 'mt-icon',

    /*
    |--------------------------------------------------------------------------
    | Mise en cache des SVG (mode inline)
    |--------------------------------------------------------------------------
    | Recommandé en production pour éviter les lectures disque répétées.
    */
    'cache'     => env('MT_ICONS_CACHE', false),
    'cache_ttl' => env('MT_ICONS_CACHE_TTL', 86400),

    /*
    |--------------------------------------------------------------------------
    | Tailles disponibles
    |--------------------------------------------------------------------------
    */
    'sizes' => [
        'xs'  => '0.75rem',
        'sm'  => '1rem',
        'md'  => '1.25rem',
        'lg'  => '1.5rem',
        'xl'  => '2rem',
        '2xl' => '3rem',
    ],

    /*
    |--------------------------------------------------------------------------
    | Panneau de prévisualisation
    |--------------------------------------------------------------------------
    |
    | enabled    → Active/désactive la route /mt-icons/preview
    | prefix     → Préfixe URL (défaut : "mt-icons")
    | middleware → Middlewares appliqués aux routes du panneau
    |
    | ⚠️  En production, protégez cette route :
    |     'middleware' => ['web', 'auth'],
    |
    */
    'preview' => [
        'enabled'    => env('MT_ICONS_PREVIEW', true),
        'prefix'     => env('MT_ICONS_PREFIX', 'mt-icons'),
        'middleware' => ['web'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Catégories (manifeste) — pour regrouper les icônes dans le sélecteur.
    |--------------------------------------------------------------------------
    | Map "Catégorie" => [noms d'icônes]. Les icônes disponibles non listées
    | tombent sous "Autres". Le projet hôte peut surcharger/compléter (notamment
    | pour ses propres icônes ajoutées via icons_path).
    */
    'categories' => [
        'Engins & BTP' => [
            'heavy-equipment', 'excavator', 'wheel-loader', 'bulldozer',
            'crane', 'road-roller', 'forklift', 'generator', 'helmet', 'wrench',
        ],
        'Transport & Transit' => [
            'truck', 'dump-truck', 'tanker', 'container',
        ],
        'Navigation' => [
            'home', 'menu', 'hamburger',
            'arrow-up', 'arrow-down', 'arrow-left', 'arrow-right',
            'arrow-up-left', 'arrow-up-right', 'arrow-down-left', 'arrow-down-right',
            'arrow-double-up-down', 'arrow-double-left-right',
            'chevron-up', 'chevron-down', 'chevron-left', 'chevron-right', 'chevron-up-down',
        ],
        'Interface' => [
            'gear', 'settings', 'filter', 'magnifying-glass', 'search', 'eye', 'lock',
            'bell', 'refresh', 'list', 'add-to-list', 'link', 'tag', 'calendar', 'star',
            'heart', 'question', 'question-circle', 'info', 'warning', 'alert',
            'check', 'check-circle', 'check-badge', 'check-square',
            'close', 'x', 'x-circle', 'plus', 'plus-circle', 'plus-square',
            'map-pin', 'cloud', 'code', 'chart-bar',
        ],
        'Actions' => [
            'edit', 'pencil', 'copy', 'trash', 'trash-empty', 'trash-x', 'trash-warning',
            'disk', 'power', 'logout', 'share', 'download', 'upload', 'import', 'export',
        ],
        'Médias' => [
            'image', 'images', 'gallery', 'video', 'videos', 'chat-bubble',
        ],
        'Utilisateurs' => [
            'user', 'users', 'user-plus', 'user-x',
        ],
        'Communication' => [
            'mail', 'phone', 'language', 'language-fr', 'language-en', 'language-ar',
        ],
    ],

];
