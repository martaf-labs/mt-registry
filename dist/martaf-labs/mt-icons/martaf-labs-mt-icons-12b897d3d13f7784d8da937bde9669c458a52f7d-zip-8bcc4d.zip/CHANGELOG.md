# Changelog

Tous les changements notables de ce projet sont documentés dans ce fichier.

Le format est basé sur [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/),
et ce projet suit le [Versionnement Sémantique](https://semver.org/lang/fr/).

---

## [1.1.0] — 2025-xx-xx

### Ajouté
- **Support Livewire v3** complet
  - Composant `<livewire:mt-icons::icon-picker />` — sélecteur d'icônes embarquable dans n'importe quel formulaire
  - Composant `<livewire:mt-icons::icon-preview />` — catalogue interactif complet
  - Événement `icon-selected` émis lors d'une sélection dans `icon-picker`
- **Panneau de prévisualisation** accessible via `/mt-icons/preview`
  - Grille réactive de toutes les icônes
  - Recherche en temps réel (debounce 200ms)
  - Bascule de mode : SVG inline / Sprite / Font
  - Changement de taille et de couleur à la volée
  - Panneau latéral de détail : aperçu multi-tailles + snippets copiables
- **API JSON** embarquée
  - `GET /mt-icons/api/icons` — liste complète des icônes
  - `GET /mt-icons/api/icon/{name}` — HTML rendu d'une icône
- **Commande Artisan** `mt-icons:list` avec filtrage et sortie JSON
- **37 icônes** SVG incluses (Heroicons Solid)
  - Nouvelles icônes : `arrow-left`, `arrow-up`, `arrow-down`, `info`, `warning`, `logout`, `copy`, `cloud`, `tag`, `phone`, `map-pin`, `code`

### Modifié
- `config/mt-icons.php` — ajout de la section `preview` (enabled, prefix, middleware)
- `MtIconsServiceProvider` — enregistrement conditionnel Livewire + routes
- `composer.json` — Livewire `^3.0` ajouté en `suggest`

---

## [1.0.0] — 2025-xx-xx

### Ajouté
- Premier release stable
- Trois modes de rendu : `inline`, `sprite`, `font`
- Composant Blade `<x-mt::icons name="home" />`
- Directive Blade `@mtIcon('home')`
- Classes CSS `<i class="mt-icon-home">` (mode font)
- `IconRenderer` — moteur central avec cache mémoire et cache Laravel
- Scripts Node.js : `build`, `optimize-svgs`, `generate-sprite`, `generate-font`
- Commandes Artisan : `mt-icons:sprite`, `mt-icons:font`, `mt-icons:make`
- 25 icônes SVG incluses (Heroicons Solid)
- Tests PHPUnit avec Orchestra Testbench
- Support Laravel 10 et 11
- Support PHP 8.1+
