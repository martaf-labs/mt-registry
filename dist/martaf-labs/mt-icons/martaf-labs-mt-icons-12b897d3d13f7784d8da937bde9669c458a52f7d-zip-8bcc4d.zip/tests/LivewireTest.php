<?php

namespace MtIcons\Tests;

use MtIcons\Livewire\IconPicker;
use MtIcons\Livewire\IconPreview;
use MtIcons\MtIconsServiceProvider;
use Orchestra\Testbench\TestCase;
use Livewire\LivewireServiceProvider;

class LivewireTest extends TestCase
{
    protected function getPackageProviders($app): array
    {
        return [
            LivewireServiceProvider::class,
            MtIconsServiceProvider::class,
        ];
    }

    protected function getEnvironmentSetUp($app): void
    {
        $app['config']->set('mt-icons.icons_path', __DIR__ . '/../resources/icons');
        $app['config']->set('mt-icons.mode', 'inline');
        $app['config']->set('mt-icons.default_size', 'md');
        $app['config']->set('mt-icons.css_prefix', 'mt-icon');
        $app['config']->set('mt-icons.cache', false);
        $app['config']->set('mt-icons.preview.enabled', true);
        $app['config']->set('mt-icons.preview.prefix', 'mt-icons');
        $app['config']->set('mt-icons.preview.middleware', ['web']);
        $app['config']->set('app.key', 'base64:' . base64_encode(random_bytes(32)));
    }

    // ── IconPicker ─────────────────────────────────────────────────────────────

    public function test_icon_picker_renders(): void
    {
        \Livewire\Livewire::test(IconPicker::class)
            ->assertSet('selected', '')
            ->assertSet('open', false)
            ->assertSet('search', '');
    }

    public function test_icon_picker_toggle_opens_and_closes(): void
    {
        \Livewire\Livewire::test(IconPicker::class)
            ->call('toggle')
            ->assertSet('open', true)
            ->call('toggle')
            ->assertSet('open', false);
    }

    public function test_icon_picker_can_select_icon(): void
    {
        \Livewire\Livewire::test(IconPicker::class)
            ->call('select', 'home')
            ->assertSet('selected', 'home')
            ->assertSet('open', false)
            ->assertDispatched('icon-selected');
    }

    public function test_icon_picker_can_clear_selection(): void
    {
        \Livewire\Livewire::test(IconPicker::class)
            ->set('selected', 'home')
            ->call('clear')
            ->assertSet('selected', '')
            ->assertDispatched('icon-selected');
    }

    public function test_icon_picker_search_filters_icons(): void
    {
        $component = \Livewire\Livewire::test(IconPicker::class)
            ->set('search', 'hom');

        // La propriété calculée filteredIcons doit contenir 'home'
        $this->assertContains('home', $component->instance()->filteredIcons);
    }

    public function test_icon_picker_search_returns_empty_for_unknown(): void
    {
        $component = \Livewire\Livewire::test(IconPicker::class)
            ->set('search', 'xxxxxxxxxnotexist');

        $this->assertEmpty($component->instance()->filteredIcons);
    }

    // ── IconPreview ────────────────────────────────────────────────────────────

    public function test_icon_preview_renders(): void
    {
        \Livewire\Livewire::test(IconPreview::class)
            ->assertSet('search', '')
            ->assertSet('mode', 'inline')
            ->assertSet('size', 'xl')
            ->assertSet('selectedIcon', null);
    }

    public function test_icon_preview_select_icon(): void
    {
        \Livewire\Livewire::test(IconPreview::class)
            ->call('selectIcon', 'home')
            ->assertSet('selectedIcon', 'home');
    }

    public function test_icon_preview_deselect_on_second_click(): void
    {
        \Livewire\Livewire::test(IconPreview::class)
            ->call('selectIcon', 'home')
            ->assertSet('selectedIcon', 'home')
            ->call('selectIcon', 'home')
            ->assertSet('selectedIcon', null);
    }

    public function test_icon_preview_search_resets(): void
    {
        \Livewire\Livewire::test(IconPreview::class)
            ->set('search', 'home')
            ->call('resetSearch')
            ->assertSet('search', '');
    }

    public function test_icon_preview_snippets_generated_when_selected(): void
    {
        $component = \Livewire\Livewire::test(IconPreview::class)
            ->call('selectIcon', 'home');

        $snippets = $component->instance()->snippets;

        $this->assertArrayHasKey('blade_component', $snippets);
        $this->assertArrayHasKey('blade_directive', $snippets);
        $this->assertArrayHasKey('css_class', $snippets);
        $this->assertArrayHasKey('php', $snippets);
        $this->assertStringContainsString('home', $snippets['blade_component']);
    }

    public function test_icon_preview_snippets_empty_when_none_selected(): void
    {
        $component = \Livewire\Livewire::test(IconPreview::class);
        $this->assertEmpty($component->instance()->snippets);
    }

    // ── Routes API ─────────────────────────────────────────────────────────────

    public function test_api_icons_returns_json(): void
    {
        $response = $this->getJson('/mt-icons/api/icons');
        $response->assertStatus(200)
                 ->assertJsonStructure(['total', 'icons']);

        $data = $response->json();
        $this->assertIsArray($data['icons']);
        $this->assertGreaterThan(0, $data['total']);
    }

    public function test_api_icon_returns_html_for_known_icon(): void
    {
        $response = $this->getJson('/mt-icons/api/icon/home');
        $response->assertStatus(200)
                 ->assertJsonStructure(['name', 'html', 'exists'])
                 ->assertJsonFragment(['name' => 'home', 'exists' => true]);
    }

    public function test_api_icon_returns_404_for_unknown(): void
    {
        $this->getJson('/mt-icons/api/icon/not-an-icon-xyz')
             ->assertStatus(404);
    }
}
