<?php

namespace MtIcons\Tests;

use MtIcons\IconRenderer;
use MtIcons\MtIconsServiceProvider;
use Orchestra\Testbench\TestCase;

class IconRendererTest extends TestCase
{
    protected function getPackageProviders($app): array
    {
        return [MtIconsServiceProvider::class];
    }

    protected function getEnvironmentSetUp($app): void
    {
        $app['config']->set('mt-icons.icons_path', __DIR__ . '/../resources/icons');
        $app['config']->set('mt-icons.mode', 'inline');
        $app['config']->set('mt-icons.default_size', 'md');
        $app['config']->set('mt-icons.css_prefix', 'mt-icon');
        $app['config']->set('mt-icons.cache', false);
    }

    // ── Renderer ──────────────────────────────────────────────────────────────

    public function test_renderer_returns_inline_svg(): void
    {
        $renderer = app(IconRenderer::class);
        $html = $renderer->renderInline('home');

        $this->assertStringContainsString('<span', $html);
        $this->assertStringContainsString('mt-icon', $html);
        $this->assertStringContainsString('<svg', $html);
    }

    public function test_renderer_returns_sprite(): void
    {
        $renderer = app(IconRenderer::class);
        $html = $renderer->renderSprite('home');

        $this->assertStringContainsString('<svg', $html);
        $this->assertStringContainsString('<use', $html);
        $this->assertStringContainsString('sprite.svg#home', $html);
    }

    public function test_renderer_returns_font(): void
    {
        $renderer = app(IconRenderer::class);
        $html = $renderer->renderFont('home');

        $this->assertStringContainsString('<i', $html);
        $this->assertStringContainsString('mt-icon-home', $html);
        $this->assertStringContainsString('aria-hidden="true"', $html);
    }

    public function test_renderer_returns_fallback_for_unknown_icon(): void
    {
        $renderer = app(IconRenderer::class);

        // En dehors du mode debug, doit retourner une chaîne vide
        $this->app['config']->set('app.debug', false);
        $html = $renderer->renderInline('non-existent-icon-xyz');

        $this->assertSame('', $html);
    }

    public function test_renderer_lists_available_icons(): void
    {
        $renderer = app(IconRenderer::class);
        $icons = $renderer->available();

        $this->assertIsArray($icons);
        $this->assertContains('home', $icons);
        $this->assertContains('user', $icons);
        $this->assertContains('settings', $icons);
    }

    public function test_size_class_is_applied(): void
    {
        $renderer = app(IconRenderer::class);
        $html = $renderer->renderInline('home', 'xl');

        $this->assertStringContainsString('mt-icon--xl', $html);
    }

    // ── ServiceProvider ───────────────────────────────────────────────────────

    public function test_service_provider_registers_renderer(): void
    {
        $this->assertInstanceOf(IconRenderer::class, app(IconRenderer::class));
    }

    public function test_config_is_loaded(): void
    {
        $this->assertNotNull(config('mt-icons'));
        $this->assertEquals('inline', config('mt-icons.mode'));
        $this->assertEquals('mt-icon', config('mt-icons.css_prefix'));
    }
}
