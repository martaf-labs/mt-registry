**mt-views**, initié le Mercredi 06 Août 2025, à N'Djaména
mt-views est un package Laravel destiné à centraliser toutes les vues Blade partagées utilisées dans plusieurs projets Laravel. Il inclut des layouts standards, des composants Blade personnalisés (alertes, boutons, modals…), des partials réutilisables (headers, footers, sidebars), et d'autres structures visuelles communes.

L'objectif est de faciliter la cohérence visuelle, d'accélérer le développement, et de maintenir un design unifié à travers tous les projets Laravel.

###   Pour versionner:
git tag v1.0.1
git push origin v1.0.1
