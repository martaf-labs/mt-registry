<?php  

use Carbon\Carbon;
use App\Models\User;
use App\Models\Visite;
use App\Helpers\NavHelper;
use App\Helpers\ViewHelper;
use Illuminate\Support\Str;
use Faker\Provider\tr_TR\DateTime;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use App\Notifications\HandleNotification;

if (!function_exists('getActiveLayout')) {
    //fonction pour recuperer le layout actif

    function getActiveLayout()
    {
        return session('active_layout');
    }
}

//Obtenir le niveau d'accès del'utilisateur authentifié
if (!function_exists('get_access_level')) {
    function get_access_level()
    {
        $user = Auth::user();
        
        if (!$user) {
            return 999; // niveau max = accès refusé
        }

        $roles = $user->roles; // supposons que l'utilisateur a plusieurs rôles
        $levels = [];

        foreach ($roles as $role) {
            $levels[] = User::getAccessLevels()[$role->name] ?? 999;
        }

        return min($levels); // plus petit niveau = plus haut accès
    }

}

//OPour verifier l'accebilité de utilisateur authentifié
if (!function_exists('has_access_level')) {
    function has_access_level($maxLevel)
    {
        return get_access_level() <= $maxLevel;
    }
}

//verifier si l'utilisateur authentifié à l'un des role lister dans le tableau
if (!function_exists('has_role')) {
    function has_role(array $roles)
    {
        $user = Auth::user();
        
        if (!$user) {
            return false;
        }
        
        foreach ($roles as $role) {
            if ($user->hasRole($role)) {
                return true;
            }
        }
        
        return false;
    }
}

//verifier si l'utilisateur auhentifier est un developpeur
if (!function_exists('is_dev')) {
    function is_dev(): bool {
        return Auth::user()->hasRole(User::DEVELOPPEUR);
    }
}

//verifier si l'utilisateur auhentifier est un administrateur
if (!function_exists('is_admin')) {
    function is_admin(): bool {
        return Auth::user()->hasRole(User::ADMIN);
    }
}

//verifier si l'utilisateur a les permissions necessaire
if (!function_exists('can_access')) {
    function can_access($permission) {
        return auth()->check() && auth()->user()->hasPermissionTo($permission);
    }
}

/**
 * Gestion des viewItems
 */
if (!function_exists('viewItems')) {
    function viewItems(string $model, string $mainLabel): ViewHelper
    {
        return new ViewHelper($model, $mainLabel);
    }
}

/**
 * Gestion des navitems
 */
if (!function_exists('navItems')) {
    function navItems(string $model, string $mainLabel): NavHelper
    {
        return new NavHelper($model, $mainLabel);
    }
}

/**
 * Recuperation de la session du formulaire
 */
if (!function_exists('formSession')) {
    function formSession(string $model)
    {
        return session("formSessionData.{$model}") ?? null;
    }
}

/**
 * Determiner le disque de stockage
 */
if (!function_exists('storage_disk')) {
    //fonction pour determiner le disque de stockage
    function getStorageDisk()
    {
        $storage_disk=config('app.storage_disk') ?? '';
        return $storage_disk;
    }
}

/**
 * Configurer le chemin d'access au assets partages
 */
if (!function_exists('mt_shared')) {
    
    function mt_shared($path = '')
    {
        return rtrim(config('app.mt_shared_url'), '/') . '/' . ltrim($path, '/');
    }
}

if (!function_exists('resolve_string')) {
    /**
     * Résout une chaine de caractères de classe/constante en valeur.
     */
    function resolve_string($code)
    {
        // Si ce n'est pas une classe ou une constante, retourne tel quel
        if (!str_contains($code, '::')) {
            return $code;
        }

        [$class, $const] = explode('::', $code);
        if (class_exists($class) && defined("{$class}::{$const}")) {
            return constant("{$class}::{$const}");

        }

        return $code;
    }
}

if (!function_exists('resolve_count')) {
    /**
     * Résout une chaine de caractères de requetes en nombre.
     */
    function resolve_count($code)
    {
        return eval("return $code;");
    }
}


if (!function_exists('getSidebar')) {
    // Récupère les données de la sidebar depuis config/sidebar.php
    function getSidebar(): array
    {
        $sideBarItems = config('sidebar');
        $currentUrl = request()->fullUrl();
        $activeKey = null;

        foreach ($sideBarItems as &$item) {

            $item['key'] = $item['key'] ?? Str::slug($item['label']);
            $item['icon'] = isset($item['icon']) ? getIcone($item['icon']) : null;
            $item['count'] = isset($item['count']) ? addZero(resolve_count($item['count'])) : null;

            $item['isActive'] = false;

            // Résoudre les paramètres
            $itemParams = $item['params'] ?? []; 
            foreach ($itemParams as $k => $v) {
                if (str_contains($v, '::')) {
                    $itemParams[$k] = constant($v);
                }
            }

            if (isset($item['route'])) {
                $item['route'] = getRoute($item['route'], $itemParams);
            }

            if (!empty($item['route'])) {
                $currentPath = parse_url($currentUrl, PHP_URL_PATH);
                $itemPath = parse_url($item['route'], PHP_URL_PATH);

                if ($item['route'] === $currentUrl ||
                    $itemPath === $currentPath) {

                    $item['isActive'] = true;
                    $activeKey = $item['key'];
                }
            }

            if (!empty($item['subItems'])) {
                foreach ($item['subItems'] as &$sub) {

                    $sub['key'] = $sub['key'] ?? Str::slug($sub['label']);
                    $sub['icon'] = isset($sub['icon']) ? getIcone($sub['icon']) : null;
                    $sub['count'] = isset($sub['count']) ? addZero(resolve_count($sub['count'])) : null;
                    $sub['isActive'] = false;

                    $subParams = $sub['params'] ?? []; 
                    foreach ($subParams as $k => $v) {
                        if (str_contains($v, '::')) {
                            $subParams[$k] = constant($v);
                        }
                    }

                    if (isset($sub['route'])) {
                        $sub['route'] = getRoute($sub['route'], $subParams);
                    }

                    if (!empty($sub['route']) && $sub['route'] === $currentUrl) {
                        $sub['isActive'] = true;
                        $item['isActive'] = true;
                        $activeKey = $sub['key'];
                    }
                }
            }
        }

        if ($activeKey) {
            session(['active_sidebar_key' => $activeKey]);
        }

        return $sideBarItems;
    }


}


if (!function_exists('getIcone')) {
    //fonction config icones value

    function getIcone(string $item)
    {
        $icone=config('app.icones')[$item] ?? '';
        return $icone;
    }
}


if (!function_exists('getRoute')) {
    //fonction config routes value

    /**
     * 
     * @param
     * @return string
     */
    function getRoute(string $item, array $parametres=[])
    {
        $route=config('routes.'.$item);
        if (!$route) {
            // throw new InvalidArgumentException("La route {$item} n'existe pas dans la configuration...");
            return '';
        }
        
        return route($route, $parametres);
    }
}


if (!function_exists('markTerms')) {
    //fonction markTerms: pour marqué toute les occurences d'un element dans un groupe d'element

    function markTerms(string $phrase='', string $expression='')
    {
        if (strlen($phrase)>0 && strlen($expression)>0) {
            $phraseMarquee=preg_replace_callback('/'.preg_quote($expression, '/'). '/i', function($matches){
                return '<mark>'.$matches[0].'</mark>';
            }, $phrase);
        } else {
            $phraseMarquee='';
        }
        
        
        return $phraseMarquee;
    }
}

if (!function_exists('fileExists')) {
    //verifier l'existance d'un fichier

    function fileExists(string $filePath)
    {
        if (Storage::exists($filePath)) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('notifier')) {
    //pour notifier un ou plusieurs utilisateurs

    function notifier($userIds, array $data)
    {
        $notifiedUserIds=is_array($userIds) ? $userIds : [$userIds]; //pour parametre le tableau d'utilisateurs
        foreach ($notifiedUserIds as $id) {
            $user=User::find($id);
            if($user){
                $user->notify(new HandleNotification(...$data)); 
            }
        }
    }
}


if (!function_exists('addZero')) {
    // fonction qui sert à ajouter "0" devant un nombre compris entre "0" et "10"
    
    function addZero($nbre): string
    {
        $nbre=(int) $nbre;
        if (0 < $nbre && $nbre < 10) {
            return '0' . $nbre;
        }

        if ($nbre < 1_000) {
            return (string) $nbre;
        }

        if ($nbre < 1_000_000) {
            return round($nbre / 1_000, 1) . 'K';
        }

        if ($nbre < 1_000_000_000) {
            return round($nbre / 1_000_000, 1) . 'M';
        }

        return round($nbre / 1_000_000_000, 1) . 'Md';
    }
}


if (!function_exists('inRange')) {
    // fonction qui sert à ajouter "0" devant un nombre compris entre "0" et "10"
    
    function inRange(int $val, int $min, int $max) : int
    {
        return $val >= $min && $val <= $max;
    }
}


// if (!function_exists('tempsEcoule')) {
//     // fonction qui a cournir le temps passe entre maintenat et une date
//     function tempsEcoule($date) {
//         $now = now();
//         $diff = $now->diffInSeconds($date);

//         if ($diff < 60) {
//             return addZero($diff) . ' seconde' . ($diff > 1 ? 's' : '');
//         }

//         $diff = $now->diffInMinutes($date);
//         if ($diff < 60) {
//             return addZero($diff) . ' minute' . ($diff > 1 ? 's' : '');
//         }

//         $diff = $now->diffInHours($date);
//         if ($diff < 24) {
//             return addZero($diff) . ' heure' . ($diff > 1 ? 's' : '');
//         }

//         $diff = $now->diffInDays($date);
//         if ($diff < 30) {
//             return addZero($diff) . ' jour' . ($diff > 1 ? 's' : '');
//         }

//         $diff = $now->diffInMonths($date);
//         if ($diff < 12) {
//             return addZero($diff) . ' mois' . ($diff > 1 ? 's' : '');
//         }

//         $diff = $now->diffInYears($date);
//         return addZero($diff) . ' an' . ($diff > 1 ? 's' : '');
//     }


// }

if (!function_exists('tempsEcoule')) {
    function tempsEcoule($debut, $fin = null, $abrege = false, $prefixe = false, $type = null)
    {
        try {
            $now = is_null($fin) ? Carbon::now() : Carbon::parse($fin);
            $debut = Carbon::parse($debut);
        } catch (\Exception $e) {
            return null;
        }

        $future = $debut->greaterThan($now);
        $ref1 = $future ? $now : $debut;
        $ref2 = $future ? $debut : $now;

        if ($type) {
            $type = strtolower($type);
            $val = 0;
            $label = '';

            switch ($type) {
                case 'seconde':
                case 's':
                    $val = $ref1->diffInSeconds($ref2);
                    $label = $abrege ? 's' : 'seconde' . ($val > 1 ? 's' : '');
                    break;

                case 'minute':
                case 'min':
                    $val = $ref1->diffInMinutes($ref2);
                    $label = $abrege ? 'min' : 'minute' . ($val > 1 ? 's' : '');
                    break;

                case 'heure':
                case 'h':
                    $val = $ref1->diffInHours($ref2);
                    $label = $abrege ? 'h' : 'heure' . ($val > 1 ? 's' : '');
                    break;

                case 'jour':
                case 'j':
                    $val = $ref1->diffInDays($ref2);
                    $label = $abrege ? 'j' : 'jour' . ($val > 1 ? 's' : '');
                    break;

                case 'semaine':
                case 'sem':
                    $val = floor($ref1->diffInDays($ref2) / 7);
                    $label = $abrege ? 'sem' : 'semaine' . ($val > 1 ? 's' : '');
                    break;

                case 'mois':
                    $val = $ref1->diffInMonths($ref2);
                    $label = 'mois';
                    break;

                case 'an':
                case 'annee':
                    $val = $ref1->diffInYears($ref2);
                    $label = $abrege ? 'an' : 'an' . ($val > 1 ? 's' : '');
                    break;
            }

            return ($prefixe ? ($future ? 'dans ' : 'il y a ') : '') . addZero($val) . ' ' . $label;
        }

        // --- Comportement sans $type (durée composée) ---
        $diff = $ref1->diff($ref2);
        $joursTotal = $ref1->diffInDays($ref2);
        $semaines = floor($joursTotal / 7);
        $resteJours = $joursTotal % 7;

        $parts = [];

        if ($diff->y > 0) {
            $label = $abrege ? 'an' : 'an' . ($diff->y > 1 ? 's' : '');
            $parts[] = addZero($diff->y) . ' ' . $label;
        }

        if ($diff->m > 0) {
            $label = 'mois';
            $parts[] = addZero($diff->m) . ' ' . $label;
        }

        if ($semaines > 0) {
            $label = $abrege ? 'sem' : 'semaine' . ($semaines > 1 ? 's' : '');
            $parts[] = addZero($semaines) . ' ' . $label;
        }

        if ($resteJours > 0) {
            $label = $abrege ? 'j' : 'jour' . ($resteJours > 1 ? 's' : '');
            $parts[] = addZero($resteJours) . ' ' . $label;
        }

        if ($diff->h > 0 && empty($parts)) {
            $label = $abrege ? 'h' : 'heure' . ($diff->h > 1 ? 's' : '');
            $parts[] = addZero($diff->h) . ' ' . $label;
        }

        if ($diff->i > 0 && empty($parts)) {
            $label = $abrege ? 'min' : 'minute' . ($diff->i > 1 ? 's' : '');
            $parts[] = addZero($diff->i) . ' ' . $label;
        }

        if ($diff->s > 0 && empty($parts)) {
            $label = $abrege ? 's' : 'seconde' . ($diff->s > 1 ? 's' : '');
            $parts[] = addZero($diff->s) . ' ' . $label;
        }

        $texte = implode(' et ', array_slice($parts, 0, 2));

        return $prefixe ? ($future ? 'dans ' . $texte : 'il y a ' . $texte) : $texte;
    }
}
