<?php

namespace Mt\MtViews;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class MtViewsServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any package services.
     */
    public function boot(): void
    {
        // Charger les vues avec un alias (namespace)
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'mt');

        // Rendre les assets (public) publiables
        $this->publishes([
            __DIR__.'/../public' => public_path('vendor/mt'),
        ], 'mt-assets');

        // Rendre les vues publiables
        $this->publishes([
            __DIR__.'/../resources/views' => $this->app->resourcePath('views/vendor/mt'),
        ], 'mt-views');

        // (Optionnel) Charger des composants Blade si tu en as
        Blade::componentNamespace('MtViews\\View\\Components', 'mt');
        
        if (file_exists(__DIR__.'/helpers/helpers.php')) {
        require_once __DIR__.'/helpers/helpers.php';
    }
    }

    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }
}
