<?php

namespace App\View\Components;

use Illuminate\View\View;
use Illuminate\View\Component;

class AppLayout extends Component
{
    public $bgBody;
    public $titre;
    public $icone;
    public $addRoute;
    public $editRoute;
    public $navItems;
    public $optionsItems;
    public $viewName;

    /**
     * Create a new component instance.
     */
    public function __construct($bgBody='',$titre='', $icone='', $addRoute=null, $editRoute=null, $navItems=[], $optionsItems=[], $viewName='')
    {   
        $this->bgBody=$bgBody;
        $this->titre=$titre;
        $this->icone=$icone;
        $this->addRoute=$addRoute;
        $this->editRoute=$editRoute;
        $this->navItems=$navItems;
        $this->optionsItems=$optionsItems;
        $this->viewName=$viewName;
        
    }
    /**
     * Get the view / contents that represents the component.
     */
    public function render(): View
    {
        return view('mt::layouts.app');
    }
}
