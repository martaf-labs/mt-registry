<?php

namespace App\View\Components;

use Illuminate\View\View;
use Illuminate\View\Component;

class GuestLayout extends Component
{
    public $mode; //les different modes: 'show', 'print'
    public $bgBody;
    public $titre;
    public $icone;
    public $navItems;

    //variable de partage
    public $ogUrl;
    public $ogTitle;
    public $ogDescription;
    public $ogImage;

    /**
     * Create a new component instance.
     */
    public function __construct($mode='',$bgBody='bg-coul4',$titre='', $icone='', $navItems=[], $ogUrl='', $ogTitle='', $ogDescription='', $ogImage='')
    {   
        $this->mode=$mode;
        $this->bgBody=$bgBody;
        $this->titre=$titre;
        $this->icone=$icone;
        $this->navItems=$navItems;
        $this->ogUrl=$ogUrl;
        $this->ogTitle=$ogTitle;
        $this->ogDescription=$ogDescription;
        $this->ogImage=$ogImage;
        
    }
    /**
     * Get the view / contents that represents the component.
     */
    public function render(): View
    {
        return view('mt::layouts.guest');
    }
}
