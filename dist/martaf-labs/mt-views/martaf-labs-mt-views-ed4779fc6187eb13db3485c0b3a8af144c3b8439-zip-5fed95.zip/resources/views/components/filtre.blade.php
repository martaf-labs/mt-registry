
@php
    $filters=$filters?? []; 
    $filterOptions=$filterOptions?? []; 

    $filtersWithKeyWord=array_filter($filters, function($filter){
        return (isset($filter['type']) && $filter['type'] === 'keyWord');
    }); //les filtres avec pour type 'keyWord'

    $filtersWithKeyDate=array_filter($filters, function($filter){
        return (isset($filter['type']) && $filter['type'] === 'keyDate');
    }); //les filtres avec pour type 'keyDate'

    // $filtersWithoutKeys=array_filter($filters, function($filter){
    //     return !(isset($filter['type']) && $filter['type'] === 'keyWord' || $filter['type'] === 'keyDate');
    // });  //les filtres qui n'on pas pour type 'keys'

    $filtersWithoutKeys=array_filter($filters, function($filter){
        if (isset($filter['options']) && count($filter['options']) > 1) {
            return !(isset($filter['type']) && $filter['type'] === 'keyWord' || $filter['type'] === 'keyDate');
        }
    });  //les filtres qui n'on pas pour type 'keys'
@endphp



<div class="row row-cols-1 py-0 mb-4 rounded-2 d-flex flex-column justify-content-between align-items-center" style="min-height: 50vh">
        
    @if ($filters != [])
        <div class="container-fluid pb-1 px-1 rounded-1 col d-flex flex-row flex-wrap justify-content-around justify-content-lg-end align-items-center">
                
            <div class="d-flex flex-row flex-nowrap justify-content-between justify-content-lg-end align-items-center list-group-horizontal">

                <div class="list-group-item">                
                    @foreach($filtersWithKeyWord as $index => $filtre)
                        <span class="bi bi-search d-inline-block text-muted" id="filter-search-icon"></span>
                        <input type="text" id="{{ $filtre['id'] }}" class="form-control d-inline-block border-0 border-bottom w-auto me-2 fs-80" placeholder="Rechercher par {{ $filtre['label'] }}" onkeyup="filtrerGenerique()" aria-describedby="filter-search-icon" style="border-radius: 0%; background-color:transparent;box-shadow:0 0 0 transparent;">
                    @endforeach  

                    @foreach($filtersWithKeyDate as $index => $filtre)
                        <input type="date" id="{{ $filtre['id'] }}" class="form-control border-0 border-bottom w-auto me-2 fs-80" onchange="filtrerGenerique()" style="border-radius: 0%; background-color:transparent;box-shadow:0 0 0 transparent;">
                    @endforeach
                </div> 

                @if (!empty($filtersWithoutKeys))
                    <!-- champ de filtre-->
                    <div class="p-0 m-0 list-group-item">
                        <div class="dropdown"> 
                            <a href="#" class="btn btn-outline-dark px-3 py-1 px-lg-2 py-lg-1 rounded-2 fs-80 fw-bold" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="">
                                <span class="bi bi-sliders"></span>
                                <span class="ms-1 d-lg-inline-block">{{ count($filtersWithoutKeys) > 1 ? "Filtres" : "Filtre" }}</span>
                            </a>
                            <ul class="dropdown-menu px-2 border-0">
                                <li>
                                    <form action="">
                                        <fieldset class="p-2 pt-0 rounded-2">
                                            {{-- <legend class="float-none w-auto px-2 fs-80">Filtrer par:</legend> --}}
                                            <div class="container-fluid px-0 d-flex flex-column justify-content-start align-items-start">
                                                @foreach($filtersWithoutKeys as $index => $filtre)
                        
                                                    @php
                                                        //variables du filtre par defaut
                                                        $filtreType=$filtre['type']?? '';
                                                        $filtreId=$filtre['id']?? "filtre$index";
                                                        $filtreLabel=$filtre['label']?? "filtre $index";
                                                        $filtreOptions=$filtre['options']?? [];
                                                        $col=$filtre['col']?? 2;
                                                    @endphp
                        
                                                    <div class="col-12 col-lg-{{ "12" }} p-1">
                                                        <div class="form-group">
                                                            @if($filtreType === 'select' && count($filtreOptions) > 1)
                                                                <select id="{{ $filtreId }}" class="form-select fs-80" aria-label="" onchange="filtrerGenerique()">
                                                                    <option value="" class="fst-italic">{{ $filtreLabel }}</option>
                                                                    @foreach($filtreOptions as $option)
                                                                        <option value="{{ $option['value'] }}" class="fw-bold">{{ $option['label'] }}</option>
                                                                    @endforeach
                                                                </select>
                                                            @endif
                                                            @if($filtreType === 'text')
                                                                {{-- <input type="text" id="{{ $filtreId }}" class="form-control fs-80" placeholder=">{{ $filtreLabel }}" onkeyup="filtrerGenerique()"> --}}
                                                            @endif
                                                            @if($filtreType === 'number')
                                                                <input type="number" id="{{ $filtreId }}" class="form-control fs-80" placeholder="{{ $filtreLabel }}" onkeyup="filtrerGenerique()">
                                                            @endif
                                                            @if($filtreType === 'date')
                                                                <input type="date" id="{{ $filtreId }}" class="form-control fs-80" placeholder="{{ $filtreLabel }}" onchange="filtrerGenerique()">
                                                            @endif
                                    
                                                            {{-- <label for="{{ $filtreId }}" class="form-label fs-80">{{ $filtreLabel }}</label> --}}
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>  
                                        </fieldset>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- champ de tri-->
                    <div class="p-0 m-0 d-none list-group-item">
                        <div class="dropdown"> 
                            <a href="#" class="btn btn-coul4 px-1 py-1 px-lg-2 py-lg-1 rounded-2 fs-100" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="bi bi-funnel-fill"></span>
                                {{-- <span class="ms-1 d-none d-lg-inline-block">Trier par:</span> --}}
                            </a>
                            <ul class="dropdown-menu px-2 border-0">
                                <span class="fs-80 bg-coul1 fg-coul4 px-1 rounded-1">Trier par:</span>
                                @foreach($filtersWithoutKeys as $filtre)
                                    <li>
                                        <a class="dropdown-item tri-btn px-0 fs-90" onclick="document.getElementById('tri-colonne').value=`{{ $filtre['id'] }}`">{{ $filtre['label'] }}</a>
                                    </li>
                                @endforeach
                                <!-- champ témoin-->
                                <input id="tri-colonne" type="hidden" name="" value="">
                            </ul>
                            <script>
                                document.querySelectorAll('.tri-btn').forEach(btn=>{
                                    btn.addEventListener('click',function(){
                                        filtrerGenerique();
                                    });
                                });
                            </script>
                        </div>
                    </div>

                    <!-- champ de l'odre de tri-->
                    <div class="p-0 m-0 d-none list-group-item">
                        <div class="dropdown"> 
                            <a href="#" class="btn btn-coul4 px-1 py-1 px-lg-2 py-lg-1 rounded-2 fs-100" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="bi bi-sort-alpha-down"></span>
                                {{-- <span class="ms-1 d-none d-lg-inline-block">Trier par:</span> --}}
                            </a>
                            <ul class="dropdown-menu px-2 border-0">
                                <span class="fs-80 bg-coul1 fg-coul4 px-1 rounded-1">Ordre:</span>
                                    <li>
                                        <a class="dropdown-item tri-ordre-btn px-0 fs-90" onclick="document.getElementById('tri-ordre').value=`asc`">Croissant</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item tri-ordre-btn px-0 fs-90" onclick="document.getElementById('tri-ordre').value=`desc`">Décroissant</a>
                                    </li>
                                <!-- champ témoin-->
                                <input id="tri-ordre" type="hidden" name="" value="">
                            </ul>
                            <script>
                                document.querySelectorAll('.tri-ordre-btn').forEach(btn=>{
                                    btn.addEventListener('click',function(){
                                        filtrerGenerique();
                                    });
                                });
                            </script>
                        </div>
                    </div>
                @endif

            </div>

            @if ($filterOptions != [])
                
                <div class="ms-4 d-flex flex-row flex-nowrap justify-content-between justify-content-lg-end align-items-center">
                    <!-- option du tableau-->
                    <div class="p-0 m-0">
                        <div class="dropdown"> 
                            <a href="#" class="btn btn-coul4 px-1 py-1 px-lg-2 py-lg-1 rounded-2 fs-100" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="bi bi-three-dots"></span>
                                {{-- <span class="ms-1 d-none d-lg-inline-block">Options</span> --}}
                            </a>
                            <ul class="dropdown-menu px-2 border-0">
                                @foreach($filterOptions as $filterOption)
                                    <li>
                                        <a href="" class="dropdown-item px-0 fs-90">
                                            <span class="{{ $filterOption['icone'] }} me-1"></span>
                                            <span class="">{{ $filterOption['label'] }}</span>
                                        </a>
                                    </li>
                                    {{-- <li>
                                        <a href="#" class="dropdown-item px-0 fs-90" onclick="exportToExcel(JSON.parse(tableContainer.getAttribute('data-tab-datas')),'liste_complete.xlsx' )">
                                            <span class="bi bi-file-excel me-1"></span>
                                            <span class="">vers Excel</span>
                                        </a>
                                    </li> --}}
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    
                </div>
                
            @endif
        </div>

        {{-- block des mot cle de recherche --}}
        <div class="container-fluid" id="filterTags">
        </div>
    @endif
    
    <div class="col py-1 my-3 flex-grow-1 rounded-3 bg-white">
        {{ $slot }}
        <div id="aucun-resultat" class="container-fluid d-none p-lg-4">
            <div class="container d-flex flex-column justify-content-center align-items-center px-2 py-4">
                <span class="bi bi-cloud-slash opacity-50" style="font-size: 500%"></span>
                <p class="opacity-50">Aucun élément trouvé...</p>
            </div> 
        </div>
    </div>

    <div class="col">
        <div class="row row-cols-1 row-cols-lg-2 d-flex justify-content-between align-items-center">
            <div class="col d-flex justify-content-between align-items-center">
                <div id="pagination-controls" class="pagination d-flex flex-row flex-nowrap align-items-center">
                    <div class="d-flex flex-row flex-nowrap" id="blockNavigationpage">
                        <button id="prev-page" class="pagination-button btn btn-coul1 px-2 py-1 px-lg-3 rounded-2 hover-shadow fs-80 me-1" onclick="changerPage('prev')" disabled><span class="bi bi-chevron-left"></span><span class="d-none d-lg-inline-block">Préc.</span></button>
                        <button id="next-page" class="pagination-button btn btn-coul1 px-2 py-1 px-lg-3 rounded-2 hover-shadow fs-80 ms-1" onclick="changerPage('next')" disabled><span class="d-none d-lg-inline-block">Suiv.</span><span class="bi bi-chevron-right"></span></button>
                    </div>
                    <div class="ps-1 px-lg-2 fs-80">
                        <span id="page-info" class=""></span>
                    </div>
                    <div class="d-flex flex-row flex-nowrap align-items-center ps-2 px-lg-2 fs-80 ">
                        <span class="me-1"></span> <span id="count-resultats" class="fg-coul2 me-1">0</span> <span id="count-label">résultat</span>
                    </div>
                </div>
                {{-- <div class="d-none d-lg-block fs-80">
                    <span id="count-resultats" class="">0</span> résultats trouvés.
                </div> --}}
            </div>
        </div>
    </div>
</div>

<script>
    //variables necessaires
    // Sélectionne le parent existant
    const tableContainer = document.getElementById('resultats')?? '';
    const tabDatas =JSON.parse(tableContainer.getAttribute('data-tab-datas'))?? [];
    const tabModel= tableContainer.getAttribute('data-tab-model')?? '';
    const datafiltres = JSON.parse(tableContainer.getAttribute('data-filtres'))?? [];
    const tabDisplay = tableContainer.getAttribute('data-tab-display')?? 'list';
    const appUrl = @json(env('APP_URL'));

    tableContainer.innerHTML = '';//initialisation du container
    const ITEMS_PAR_PAGE = 40; // Nombre d'éléments par page
    let pageActuelle = 1;      // La page courante
    let totalPages = 0;        // Le nombre total de pages
    let lignesFiltrees = [];   // Pour stocker les lignes visibles après filtrage

    document.addEventListener('DOMContentLoaded', function () {
        generateTable(tabDisplay);
        filtrerGenerique();
        initialiserPagination();
    });

    function initialiserPagination() {
        const lignes = Array.from(document.querySelectorAll('.filtrable-item'));
        totalPages = Math.ceil(lignes.length / ITEMS_PAR_PAGE);
        pageActuelle = 1;
        mettreAJourPagination();
        afficherPage(pageActuelle);
    }

    function mettreAJourPagination() {
        // const lignes = Array.from(document.querySelectorAll('.filtrable-item'));
        // const lignesVisibles = lignesFiltrees.length ? lignesFiltrees : Array.from(document.querySelectorAll('.filtrable-item'));
        const lignesVisibles = lignesFiltrees//.length ? lignesFiltrees : Array.from(document.querySelectorAll('.filtrable-item'));
        totalPages = Math.ceil(lignesVisibles.length / ITEMS_PAR_PAGE);
        pageActuelle = Math.min(pageActuelle, totalPages) || 1;
        

        // document.getElementById('page-info').textContent = totalPages === 0
        const pageInfo = document.getElementById('page-info');
        const blockNavigationpage = document.getElementById('blockNavigationpage');

        pageInfo.textContent = totalPages <= 1
            ? "" 
            : `Page ${pageActuelle} sur ${totalPages}`;
        document.getElementById('prev-page').disabled = (pageActuelle === 1 || totalPages === 0);
        document.getElementById('next-page').disabled = (pageActuelle === totalPages || totalPages === 0);
    }

    function afficherPage(page) {
        const lignes = lignesFiltrees;//.length ? lignesFiltrees : Array.from(document.querySelectorAll('.filtrable-item'));
        const totalPages = Math.ceil(lignes.length / ITEMS_PAR_PAGE);

        if (page > totalPages) {
            page = totalPages;
        }

        const debut = (page - 1) * ITEMS_PAR_PAGE;
        const fin = debut + ITEMS_PAR_PAGE;

        lignes.forEach((ligne, index) => {
            if (lignesFiltrees.length === 0) {
                // Si aucun résultat après filtrage, masquer tous les éléments
                ligne.classList.add('d-none');
            } else {
                ligne.classList.add('d-none');
                if (index >= debut && index < fin) {
                    ligne.classList.remove('d-none');
                }
            }
        });

        pageActuelle = page;
        mettreAJourPagination();
    }

    function changerPage(direction) {
        if (direction === 'next' && pageActuelle < totalPages) {
            pageActuelle++;
        } else if (direction === 'prev' && pageActuelle > 1) {
            pageActuelle--;
        }
        afficherPage(pageActuelle);
    }

    function filtrerGenerique() {
        const filters = @json(array_column($filters, 'id'));
        const lignes = Array.from(document.querySelectorAll('.filtrable-item'));
        const filterTags = document.getElementById('filterTags') ?? '';
        filterTags.innerHTML='';
        const activeFilterTags =[] ;
        let nombreVisible = 0;

        lignes.forEach(ligne => {
            let afficher = true;
            const ligneFiltres = ligne.getAttribute('data-filtres') != 'undefined' ? JSON.parse(ligne.getAttribute('data-filtres')) : [];
        

            filters.forEach(filtreId => {
                const filtreValeur = document.getElementById(filtreId)? document.getElementById(filtreId).value.trim().toLowerCase() : '';
                const ligneValeur = ligneFiltres[filtreId] !== undefined ? ligneFiltres[filtreId] : '';
                const ligneValeurString = ligneValeur ? ligneValeur.toString().toLowerCase() : '';
                // if (filtreValeur && !ligneValeurString.includes(filtreValeur)) {
                //     afficher = false;
                // }
                if (filtreValeur) {
                    const filtreEstNombre = !isNaN(filtreValeur);
                    const ligneEstNombre = !isNaN(ligneValeur);
                    if (filtreEstNombre && ligneEstNombre) {
                        if(parseFloat(filtreValeur) !== parseFloat(ligneValeur)){
                            afficher = false;
                        }
                    } else {
                        if (filtreValeur && !ligneValeurString.includes(filtreValeur)) {
                            afficher = false;
                        }
                    }
                }
            });

            if (afficher) {
                ligne.classList.remove('d-none');
                nombreVisible++;
            } else {
                ligne.classList.add('d-none');
            }
        });

        const nombreResultat = document.getElementById('count-resultats');
        const labelResultat = document.getElementById('count-label');
        if (nombreResultat) {
            nombreResultat.textContent = nombreVisible > 0 && nombreVisible < 10 ? '0'+nombreVisible : nombreVisible;
            labelResultat.textContent = nombreVisible>1 ? 'résultats.' :'résultat.' ;
        }

        const triColonne = document.getElementById('tri-colonne') ? document.getElementById('tri-colonne').value : null;
        const triOrdre = document.getElementById('tri-ordre') ? document.getElementById('tri-ordre').value : null;

        if (triColonne !== null) {
            const lignesVisibles = lignes.filter(ligne => !ligne.classList.contains('d-none'));
            lignesVisibles.sort((a, b) => {
                const aValeur = JSON.parse(a.getAttribute('data-filtres'))[triColonne] || '';
                const bValeur = JSON.parse(b.getAttribute('data-filtres'))[triColonne] || '';

                if (aValeur < bValeur) return triOrdre === 'asc' ? -1 : 1;
                if (aValeur > bValeur) return triOrdre === 'asc' ? 1 : -1;
                return 0;
            });

            const conteneur = document.getElementById('resultats');
            lignesVisibles.forEach(ligne => conteneur.appendChild(ligne));
        }

        lignesFiltrees = lignes.filter(ligne => !ligne.classList.contains('d-none'));
        pageActuelle = 1;
        afficherPage(pageActuelle);
        mettreAJourPagination(); //mettre à jour la pagination

        // Gestion des tags
        if (activeFilterTags.length  > 0) {
            activeFilterTags.forEach((tag, index) =>{

                const tagItem = createElement('span', {
                    classes: [],
                    attributes: {
                        'id': `tag${index}`
                    },
                    parent: filterTags
                });
                
                const tagItemClose = createElement('a', {
                    text: 'x',
                    classes: ['text-dark','me-1'],
                    attributes: {
                        'href':'#'
                    },
                    events: {
                        click : () => document.getElementById(`tag${index}`).classList.add('d-none')
                    },
                    parent: tagItem
                });
                
                const tagItemContent = createElement('span', {
                    text: tag,
                    classes: ['badge','fw-normal','fs-70','bg-dark','text-light','py-0','my-0'],
                    attributes: {
                    },
                    parent: tagItem
                });

            });
        }
        else{
            filterTags.innerHTML='';
        }

        // Afficher ou masquer le message "Aucun résultat trouvé"
        const aucunResultat = document.getElementById('aucun-resultat');
        if (nombreVisible > 0) {
            aucunResultat.classList.add('d-none');
        } else {
            aucunResultat.classList.remove('d-none');
        }

    }

    /**
     ** /generation du tableau
     */
    function generateTable(displayView='list') {

        if (tabDatas) {
            tabDatas.forEach((tabData, index) => {
                function addTableItems() {
                    //conteneur principal
                    const tableRowCover = createElement('div', {
                        classes: ['col','my-2','filtrable-item','px-1'],
                        attributes: {
                            'data-filtres': JSON.stringify(datafiltres[index]) 
                        },
                        parent: tableContainer
                    });

                    //conteneur cover
                    const tableRowCoverCover= createElement('div', {
                        classes: ['container-fluid'],
                        parent: tableRowCover
                    });

                    //conteneur secondaire
                    const bgTableRowContainer=index % 2==0 ? 'bg-coul4' : 'bg-white';
                    let classesTableRowContainer = [];               

                    if (displayView === 'grid') {
                        classesTableRowContainer=['row','row-cols-1','p-1','d-flex','flex-column','align-items-center','justify-content-start','rounded-2','position-relative','hover-t-coul1'];
                    } 
                    else {
                        classesTableRowContainer=['row','row-cols-3','p-1','d-flex','flex-row','flex-nowrap','align-items-center','justify-content-between','rounded-2','position-relative','hover-t-coul1'];
                    }

                    const tableRowContainer = createElement('div', {
                        classes: classesTableRowContainer,
                        parent: tableRowCoverCover
                    });
                    

                    //tbContainerBlockMedia                    
                    let classesTbContainerBlockMedia = [];                  

                    if (displayView === 'grid') {
                        classesTbContainerBlockMedia=['col','p-0'];
                    } 
                    else {
                        classesTbContainerBlockMedia=['col-2','col-lg-1','p-0'];
                    }
                    const tbContainerBlockMedia = createElement('div', {
                        classes: classesTbContainerBlockMedia,
                        parent: tableRowContainer
                    });

                    //tbContainerBlockMediaImage
                    if (tabData.image) {

                        let classesTbContainerBlockMediaImage = [];               

                        if (displayView === 'grid') {
                            classesTbContainerBlockMediaImage=['mtblock-rect','lazy-bg','rounded-2','m-0'];
                        } 
                        else {
                            classesTbContainerBlockMediaImage=['mtblock-sqr','lazy-bg','rounded-2','m-0'];
                        }

                        const tbContainerBlockMediaImage = createElement('div', {
                            classes: classesTbContainerBlockMediaImage,
                            attributes: {
                                // 'style': `background-image:url(${tabData.image})`,
                                'data-bg': `${tabData.image}`,
                            },
                            parent: tbContainerBlockMedia
                        });

                        //tbContainerBlockMediaImageBadge
                        if (tabData.badge) {
                            const badgeTypeClass=['info','warning','light'].includes(tabData.badge.type)? `text-bg-${tabData.badge.type}` : `bg-${tabData.badge.type}`;
                            const tbContainerBlockMediaImageBadge = createElement('span', {
                                text:tabData.badge.label,
                                classes: ['badge','rounded-pill','ms-2',badgeTypeClass],
                                attributes: {
                                'style':'font-size: 60%; font-weight:500'
                                },
                                parent: tbContainerBlockMediaImage
                            });
                        }
                        
                        /*
                        * Ajout de la progressbar circulaire si fournit
                        */
                        if (tabData.progressbar && tabData.progressbar['now'] > 0 && tabData.progressbar['type'] == 'circular') {
                            
                            const tbContainerBlockMediaImageProgressBar = createElement('div', {
                                classes: ['position-absolute','bottom-0', 'end-0','m-1'],
                                attributes: {
                                    style: `width:15%;`,
                                },
                                parent: tbContainerBlockMediaImage
                            });
                            createProgressBar(tabData.progressbar['now'], tbContainerBlockMediaImageProgressBar, { type: tabData.progressbar['type'] });
                        }
                        
                    }

                    //tbContainerBlockMediaVideo
                    if (tabData.video) {
                        const tbContainerBlockMediaVideo = createElement('div', {
                            classes: ['container-fluid','video-container','rounded-2'],
                            attributes: {
                            },
                            parent: tbContainerBlockMedia
                        });

                        const tbContainerBlockMediaVideoContent = createElement('video', {
                            classes: ['rounded-2'],
                            attributes: {
                                'id':`videocontent${index}`,
                                'muted':true,
                                'controls':true,
                            },
                            parent: tbContainerBlockMediaVideo
                        });
                        //lecture de la video en boucle
                        const videoContent=document.getElementById(`videocontent${index}`);
                        const startTime=1;
                        const endTime=10;

                        videoContent.addEventListener('play', function () {
                            videoContent.currentTime=startTime;
                        })
                        videoContent.addEventListener('timeupdate', function () {
                            if (videoContent.currentTime >= endTime) {
                                videoContent.currentTime = startTime;
                            }
                        })

                        // tbContainerBlockMediaVideoContent.autoplay = true;
                        const tbContainerBlockMediaVideoContentSource = createElement('source', {
                            classes: [],
                            attributes: {
                                'src':tabData.video,
                            },
                            parent: tbContainerBlockMediaVideoContent
                        });
                        
                    }

                    //tbContainerBlockMediaIcon
                    if (tabData.icon) {

                        const tbContainerBlockMediaIcon = createElement('div', {
                            classes: ['col-1','square'],
                            attributes: {
                            },
                            parent: tbContainerBlockMedia
                        });

                        const classeItem = ['square-content','bg-white','rounded-circle','text-center','border'];
                        const classeIcon = tabData.icon.split(" ");

                        const tbContainerBlockMediaIconContend = createElement('span', {
                            classes: classeItem.concat(classeIcon) ,
                            attributes: {
                                'style':'font-size: 150%; font-weight:normal'
                            },
                            parent: tbContainerBlockMediaIcon
                        });
                        
                    }

                    //tbContainerBlockMediaLetter
                    if (tabData.letter) {
                        const tbContainerBlockMediaLetter = createElement('div', {
                            classes: ['col-1','square','position-relative'],
                            attributes: {
                            },
                            parent: tbContainerBlockMedia
                        });

                        const tbContainerBlockMediaLetterContend = createElement('span', {
                            text: tabData.letter,
                            classes: ['square-content','bg-white','rounded-circle','text-uppercase','text-center','border'],
                            attributes: {
                                'style':'font-size: 150%; font-weight:normal'
                            },
                            parent: tbContainerBlockMediaLetter
                        });

                        //tbContainerBlockMediaLetter
                        if (tabData.badge) {
                            const badgeTypeClass=['info','warning','light'].includes(tabData.badge.type)? `text-bg-${tabData.badge.type}` : `bg-${tabData.badge.type}`;
                            const tbContainerBlockMediaIconBadge = createElement('span', {
                                text:tabData.badge.label,
                                classes: ['badge','rounded-pill','ms-2',badgeTypeClass],
                                attributes: {
                                'style':'font-size: 50%; font-weight:500;position:absolute;bottom:0;left:50%;transform:translateX(-50%)'
                                },
                                parent: tbContainerBlockMediaLetter
                            });
                        }
                        
                    }

                    //tbContainerBlockOthers: titre, options, actions et autres
                    let classesTbContainerBlockOthers = [];               
                    let attributesTbContainerBlockOthers = {}; 

                    //en mode grid, s'il ya une seule action, on ajoute un lien à tbContainerBlockOthers
                    if (Object.keys(tabData.actions).length === 1) {
                        Object.values(tabData.actions).forEach((action, indice) =>{
                            if (action.type === 'showModal') {
                                attributesTbContainerBlockOthers= {
                                    'type': 'button',
                                    'data-bs-toggle': 'modal',
                                    'data-bs-target': `#showModal${indice}`,
                                    'style' : "cursor:pointer"
                                };
                            }
                            else if( action.type === 'disabled' || action.type === null){
                                
                            }
                            else{
                                attributesTbContainerBlockOthers= {
                                    'onclick' : `window.location.href='${action.lien}'`,
                                    'style' : "cursor:pointer"
                                };
                            }                                
                        });
                        
                    }              

                    if (displayView === 'grid') {
                        classesTbContainerBlockOthers=['col','px-0','pt-1','d-flex','flex-row','flex-nowrap','align-items-start','justify-content-between'];
                    } 
                    else {
                        classesTbContainerBlockOthers=['col-9','col-lg-10','flex-grow-1','d-flex','flex-row','flex-nowrap','align-items-start','justify-content-between'];
                    }
                    const tbContainerBlockOthers = createElement('div', {
                        classes: classesTbContainerBlockOthers,
                        attributes: attributesTbContainerBlockOthers,
                        parent: tableRowContainer
                    });


                    //tbContainerBlockOthersTitre
                    const tbContainerBlockOthersTitre = createElement('div', {
                        classes: ['container-fluid','flex-grow-1','whitespace-nowrap','overflow-hidden','px-0'],
                        parent: tbContainerBlockOthers
                    });

                    /*
                    * Ajout de la progressbar linéaire si fournit
                    */
                    if (tabData.progressbar && tabData.progressbar['now'] > 0 && tabData.progressbar['type'] == 'linear') {
                        createProgressBar(tabData.progressbar['now'], tbContainerBlockOthersTitre, { type: tabData.progressbar['type'] });
                    }


                    /*
                    * ajout en fonction de la table options fournit
                    */
                    if (tabData.options) {
                        //tbContainerBlockOthersTitreOptions
                        const tbContainerBlockOthersTitreOptions = createElement('div', {
                            classes: ['whitespace-nowrap','overflow-hidden','m-0','p-0'],
                            attributes: {
                                'style':'line-height:1'
                            },
                            parent: tbContainerBlockOthersTitre
                        });
                        //tbContainerBlockOthersTitreOptionsContent
                        const options=tabData.options;
                        Object.values(options).forEach((option, indice) => {

                            if (option != null && option.label != null) {
                                if (indice > 0  && option != null) {
                                    //point de séparation
                                    createElement('span', {
                                        text: " ■ ",
                                        classes: ['fs-60'],
                                        attributes: {
                                            'style':'line-height:0;opacity:.5'
                                        },
                                        parent: tbContainerBlockOthersTitreOptions
                                    });
                                    
                                }
                                const tbContainerBlockOthersTitreOptionsContent = createElement('span', {
                                    text: `${option.label}`,
                                    classes: ['fs-60'],
                                        attributes: {
                                            'style':'line-height:0'
                                        },
                                    parent: tbContainerBlockOthersTitreOptions
                                });
                            }
                            
                        });
                    }

                    //tbContainerBlockOthersTitreContent
                    if (tabData.titre) {
                        let classesTbContainerBlockOthersTitreContent = [];         
                        let classesTbContainerBlockOthersSousTitreContent = [];         
                        if (displayView === 'grid') {
                            classesTbContainerBlockOthersTitreContent=['fs-90','fw-bold','my-0','fg-coul1','whitespace-wrap'];

                            classesTbContainerBlockOthersSousTitreContent=['fs-65','my-0','fg-coul3','whitespace-wrap'];
                        } 
                        else {
                            classesTbContainerBlockOthersTitreContent=['whitespace-nowrap','overflow-hidden','fs-90','fw-bold','my-0','fg-coul1'];

                            classesTbContainerBlockOthersSousTitreContent=['fs-65','my-0','fg-coul3','whitespace-wrap'];
                        }

                        const titre= tabData.titre.length > 70 ? `${tabData.titre.substring(0,70)}...` : tabData.titre 
                        const tbContainerBlockOthersTitreContent = createElement('h6', {
                            text: `${titre.charAt(0).toUpperCase()}${titre.slice(1)}`,
                            classes: classesTbContainerBlockOthersTitreContent,
                            attributes: {
                                'style':'line-height:normal;'
                            },
                            parent: tbContainerBlockOthersTitre
                        });

                        //sousTitre
                        if (tabData.sousTitre) {
                            const sousTitre= tabData.sousTitre.length > 120 ? `${tabData.sousTitre.substring(0,120)}...` : tabData.sousTitre 
                            const tbContainerBlockOthersSousTitreContent = createElement('p', {
                                text: `${sousTitre.charAt(0).toUpperCase()}${sousTitre.slice(1)}`,
                                classes: classesTbContainerBlockOthersSousTitreContent,
                                attributes: {
                                    'style':'line-height:normal;'
                                },
                                parent: tbContainerBlockOthersTitre
                            });
                        }
                    }

                    //ajout en fonction de la table actions fournit
                    if (tabData.actions && Object.keys(tabData.actions).length !== 0) {

                        //ajout en fonction de la table actions fournit
                        if (Object.keys(tabData.actions).length === 1) {
                            
                            
                            //tbContainerSingleBtnBlock
                            let classTbContainerSingleBtnBlock=[];
                            if (displayView === 'grid') {
                                classTbContainerSingleBtnBlock=['d-none'];
                            }
                            else {
                                classTbContainerSingleBtnBlock=['w-auto','px-0'];
                            }

                            const tbContainerSingleBtnBlock = createElement('div', {
                                classes: classTbContainerSingleBtnBlock,
                                // parent: tableRowContainer
                                parent: tbContainerBlockOthers
                            });
                        
                            const actions=tabData.actions;
                            Object.values(actions).forEach((action, indice) => {

                                //tbContainerSingleBtnBlockBtn
                                const tbContainerSingleBtnBlockBtn = createElement('a', {
                                    classes: ['bi','bi-chevron-compact-right','text-secondary','p-0'],
                                    attributes: {
                                        'type': 'button',
                                        'href':action.lien,
                                        'style':'font-size: 160%;'
                                    },
                                    parent: tbContainerSingleBtnBlock
                                }); 
                            });

                        }
                        else{

                            //tbContainerBtnBlockItem
                            const tbContainerBtnBlockItem = createElement('div', {
                                classes: ['dropdown','w-auto','px-0','align-self-center'],
                                // parent: tableRowContainer
                                parent: tbContainerBlockOthers
                            });
                        
                            //tbContainerBtnBlockItemBtn
                            const tbContainerBtnBlockItemBtn = createElement('btn', {
                                classes: ['border-0','fg-coul2','p-0'],
                                attributes: {
                                    'type': 'button',
                                    'data-bs-toggle':'dropdown',
                                    'aria-expanded' : 'false'
                                },
                                parent: tbContainerBtnBlockItem
                            });
                        
                            //tbContainerBtnBlockItemBtnIcone
                            const tbContainerBtnBlockItemBtnIcone = createElement('span', {
                                classes: ['bi','bi-three-dots-vertical','fs-6'],
                                parent: tbContainerBtnBlockItemBtn
                            });
                        
                            //tbContainerBtnBlockItemMenu
                            const tbContainerBtnBlockItemMenu = createElement('ul', {
                                classes: ['border-0','dropdown-menu','shadow-sm'],
                                parent: tbContainerBtnBlockItem
                            });

                            // ajout des boutons d'action
                            const actions=tabData.actions;
                            Object.values(actions).forEach((action, indice) => {

                                if(action != null){    
                                    //tbContainerBtnBlockItemMenuItem
                                    const tbContainerBtnBlockItemMenuItem = createElement('li', {
                                        classes: [],
                                        parent: tbContainerBtnBlockItemMenu
                                    });
                                    
                                    //tbContainerBtnBlockItemMenuItemLink
                                    const classeIcone = action != null && (action.icone).length> 0 ? action.icone.split(" ") : null;
                                    const classeItem = ['dropdown-item','fs-80'];
                                    const classeDisabledItem = ['dropdown-item','btn','disabled','fs-80'];
                                    
                                    if (action.type === 'disabled') {
                                        const tbContainerBtnBlockItemMenuItemLink = createElement('a', {
                                            text: `  ${action.label}`,
                                            classes: classeDisabledItem.concat(classeIcone),
                                            attributes: {
                                                'type': 'button',
                                            },
                                            parent: tbContainerBtnBlockItemMenuItem
                                        });
                                        
                                    }
                                    else if (action.type === 'destroy') {
                                        const addClasseItem = ['link-danger'];
                                        const classeDeleteBtn = classeItem.concat(addClasseItem);
                                        const tbContainerBtnBlockItemMenuItemLink = createElement('a', {
                                            text: `  ${action.label}`,
                                            classes: classeDeleteBtn.concat(classeIcone),
                                            attributes: {
                                                'type': 'button',
                                                // 'data-id': tabData.id,
                                                // 'data-lien': action.lien,
                                                'data-bs-toggle': 'modal',
                                                'data-bs-target': `#alertModal${index}`,
                                            },
                                            parent: tbContainerBtnBlockItemMenuItem
                                        });
                                        createAlert({alertType : 'warning', alertId : `alertModal${index}`,alertItemId : tabData.id,alertTitle : `Suppression de l'élément`,alertRoute : action.lien,bodyContent : `Vous êtes sur le point de supprimer <strong> ${tabData.titre} </strong>, Souhaitez-vous continuer ?`,cancelBtnLabel : 'Non',confirmBtnLabel : 'Oui'});
                                    }
                                    else if (action.type === 'showModal') {
                                        //tbContainerSubDatasBtn
                                        const tbContainerSubDatasBtn = createElement('a', {
                                            text: `  ${action.label}`,
                                            classes: classeItem.concat(classeIcone),
                                            attributes: {
                                                'type': 'button',
                                                'data-bs-toggle': 'modal',
                                                'data-bs-target': `#showModal${index}`,
                                            },
                                            parent: tbContainerBtnBlockItemMenuItem
                                        });
                                    }
                                    else {
                                        const tbContainerBtnBlockItemMenuItemLink = createElement('a', {
                                            text: `  ${action.label}`,
                                            classes: classeItem.concat(classeIcone),
                                            attributes: {
                                                'href': action.lien,
                                            },
                                            parent: tbContainerBtnBlockItemMenuItem
                                        });
                                        
                                    }
                                }

                            });
                        }
                        
                    }

                    //Dans le cas ou il ya des sous elements
                    if (tabData.subDatas && Object.keys(tabData.subDatas).length !== 0) {

                        const tabSubDisplay=tabData.subDatas.display ?? '';
                        const tabSubTitre=tabData.subDatas.titre ?? '';
                        const tabSubDatas=tabData.subDatas.datas ?? [];
                        const tabSubHeaders=tabData.subDatas.headers ?? [];
                        const tabSubBodies=tabData.subDatas.datas ?? [];
                        const tabSubFooters=tabData.subDatas.footers;

                        //tbContainerSubDatas
                        const tbContainerSubDatas = createElement('div', {
                            classes: ['w-auto','px-0'],
                            parent: tableRowContainer
                        });

                        // creation des sous elements
                        const subDatasContainer = createElement('div', {
                            classes: ['container-fluid','px-2','py-2'],
                            attributes: {
                                'style': 'min-height:50vh',
                            },
                        });

                        if (tabSubDisplay === 'array') {
                            createArray(subDatasContainer,'',tabSubHeaders,tabSubBodies,tabSubFooters)
                        } else {
                            tabSubDatas.forEach((tabSubData, subIndex) => {
                                
                                const bgContainer=subIndex % 2==0 ? 'bg-coul4' : 'bg-white';
                                const subDatasContainerItems= createElement('div', {
                                    classes: ['row','row-cols-3','p-1','d-flex','flex-row','flex-nowrap','align-items-center','justify-content-between','rounded-2','position-relative','hover-t-coul1',bgContainer],
                                    parent: subDatasContainer
                                });
                                const subDatasContainerItemsTitre= createElement('div', {
                                    classes: ['col-11'],
                                    parent: subDatasContainerItems
                                });
                                const subDatasContainerItemsTitreContent= createElement('h6', {
                                    text: tabSubData.titre,
                                    classes: ['whitespace-nowrap','overflow-hidden','fs-90','my-0','fg-coul1'],
                                    parent: subDatasContainerItemsTitre
                                });

                                //ajout en fonction de la table options fournit
                                if (tabSubData.options) {
                                    //subDatasContainerItemsTitreOptions
                                    const subDatasContainerItemsTitreOptions = createElement('div', {
                                        classes: ['my-0','whitespace-nowrap','overflow-hidden'],
                                        parent: subDatasContainerItemsTitre
                                    });
                                    //subDatasContainerItemsTitreOptionsContent
                                    const options=tabSubData.options;
                                    Object.values(options).forEach((option, indice) => {

                                        if (option != null && option.label != null) {
                                            if (indice > 0 && option.label != null) {
                                                //point de séparation
                                                createElement('span', {
                                                    text: " ■ ",
                                                    classes: ['fs-70', 'px-1', 'opacity-75'],
                                                    parent: subDatasContainerItemsTitreOptions
                                                });
                                                
                                            }

                                            const subDatasContainerItemsTitreOptionsContent = createElement('span', {
                                                text: option.label,
                                                classes: ['fs-70', 'text-capitalize'],
                                                parent: subDatasContainerItemsTitreOptions
                                            });
                                            }
                                        
                                    });
                                }

                                //ajout en fonction de la table actions fournit
                                if (tabSubData.actions && Object.keys(tabSubData.actions).length !== 0) {
                                    //tbContainerSubDatasBtnBlockItem
                                    const tbContainerSubDatasBtnBlockItem = createElement('div', {
                                        classes: ['dropdown','w-auto','px-0'],
                                        parent: subDatasContainerItems
                                    });

                                    //tbContainerSubDatasBtnBlockItemBtn
                                    const tbContainerSubDatasBtnBlockItemBtn = createElement('btn', {
                                        classes: ['border-0','fg-coul2','p-0'],
                                        attributes: {
                                            'type': 'button',
                                            'data-bs-toggle':'dropdown',
                                            'aria-expanded' : 'false'
                                        },
                                        parent: tbContainerSubDatasBtnBlockItem
                                    });

                                    //tbContainerSubDatasBtnBlockItemBtnIcone
                                    const tbContainerSubDatasBtnBlockItemBtnIcone = createElement('span', {
                                        classes: ['bi','bi-three-dots-vertical','fs-6'],
                                        parent: tbContainerSubDatasBtnBlockItemBtn
                                    });

                                    //tbContainerSubDatasBtnBlockItemMenu
                                    const tbContainerSubDatasBtnBlockItemMenu = createElement('ul', {
                                        classes: ['border-0','dropdown-menu','shadow-sm'],
                                        parent: tbContainerSubDatasBtnBlockItem
                                    });

                                    // ajout des boutons d'action
                                    const subActions=tabSubData.actions;
                                    Object.values(subActions).forEach((subAction, indice) => {

                                        //tbContainerSubDatasBtnBlockItemMenuItem
                                        const tbContainerSubDatasBtnBlockItemMenuItem = createElement('li', {
                                            classes: [],
                                            parent: tbContainerSubDatasBtnBlockItemMenu
                                        });
                                        
                                        //tbContainerSubDatasBtnBlockItemMenuItemLink
                                        const classeIcone = subAction.icone.split(" ");
                                        const classeItem = ['dropdown-item','fs-80'];
                                        const classeDisabledItem = ['dropdown-item','btn','disabled','fs-80'];
                                        
                                        if (subAction.type === 'disabled') {
                                            const tbContainerSubDatasBtnBlockItemMenuItemLink = createElement('a', {
                                                text: `  ${subAction.label}`,
                                                classes: classeDisabledItem.concat(classeIcone),
                                                attributes: {
                                                    'type': 'button',
                                                },
                                                parent: tbContainerSubDatasBtnBlockItemMenuItem
                                            });
                                            
                                        }                                    
                                        else if (subAction.type === 'destroy') {
                                            const addClasseItem = ['link-danger'];
                                            const classeDeleteBtn = classeItem.concat(addClasseItem);
                                            const tbContainerSubDatasBtnBlockItemMenuItemLink = createElement('a', {
                                                text: `  ${subAction.label}`,
                                                classes: classeDeleteBtn.concat(classeIcone),
                                                attributes: {
                                                    'type': 'button',
                                                    // 'data-id': tabSubData.id,
                                                    // 'data-lien': subAction.lien,
                                                    'data-bs-toggle': 'modal',
                                                    'data-bs-target': `#alertModal${subIndex}`,
                                                },
                                                parent: tbContainerSubDatasBtnBlockItemMenuItem
                                            });
                                            createAlert({alertType : 'warning', alertId : `alertModal${subIndex}`,alertItemId : tabSubData.id,alertTitle : `Suppression de l'élément`,alertRoute : subAction.lien,bodyContent : `Vous êtes sur le point de supprimer <strong> ${tabSubData.titre} </strong>, Souhaitez-vous continuer ?`,cancelBtnLabel : 'Non',confirmBtnLabel : 'Oui'});
                                        } else {
                                            const tbContainerSubDatasBtnBlockItemMenuItemLink = createElement('a', {
                                                text: `  ${subAction.label}`,
                                                classes: classeItem.concat(classeIcone),
                                                attributes: {
                                                    'href': subAction.lien,
                                                },
                                                parent: tbContainerSubDatasBtnBlockItemMenuItem
                                            });
                                            
                                        }

                                    });
                                }

                            });
                        }

                        //ajout du modal pour afficher les sous element
                        createModal(`showModal${index}`,tabData.subDatas.titre,subDatasContainer);
                    }

                }

                addTableItems();
            });
        }
        
    }


    /*
    ** Exporter les donnees JSON vers EXCEL
    */
    function exportToExcel(data, filename = 'export.xlsx') {
            // Convertir JSON en worksheet
        const worksheet = XLSX.utils.json_to_sheet(data);

        // Créer un workbook et ajouter le worksheet
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

        // Sauvegarder sous forme de fichier Excel
        XLSX.writeFile(workbook, filename);
    }


</script>










