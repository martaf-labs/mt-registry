<div class="mtblock-rect lazy-bg rounded-2 bg-coul4">
    <div class="position-absolute bg-coul4 rounded-2 px-2 py-4 d-flex flex-column justify-content-center align-items-center" style="width: 100%; height:100%">
        <span class="bi bi-image fg-coul3 opacity-25 mb-2" style="font-size:500%"></span>
        <span class="fg-coul3 opacity-25">{{ $slot }}</span>
    </div>
</div>