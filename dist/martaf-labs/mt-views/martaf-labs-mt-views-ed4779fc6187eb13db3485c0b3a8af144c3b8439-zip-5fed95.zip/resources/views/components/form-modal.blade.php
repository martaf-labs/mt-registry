@php
    $modalId = $modalId ?? 'modalselector';
    $items = $modalData ?? [];
    $modalSelectMode = $modalSelectMode ?? 'unique';
    $modalTitle = $modalTitle ?? 'Sélectionner...';
    $modalItem = $modalId;
    $modalItemName = $modalItemName ?? '';
    $modalSelectedItems = $modalSelectedItems ?? []; // Éléments pré-sélectionnés

    // Trier les éléments : les pré-sélectionnés viennent en premier
    // usort($items, function ($a, $b) use ($modalSelectedItems) {
    //     $aSelected = in_array($a['id'], $modalSelectedItems);
    //     $bSelected = in_array($b['id'], $modalSelectedItems);
    //     return $bSelected <=> $aSelected;
    // });
@endphp

<div class="container">
    <!-- Modal -->
    <div class="modal fade" id="{{ $modalId }}" tabindex="-1" aria-labelledby="{{ $modalId }}Label" aria-hidden="true"  data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg modal-select ">
            <div class="modal-content mtzoom-in">
                <div class="modal-header border-0 py-2  d-flex flex-column align-items-start">
                    <h6 class="modal-title" id="{{ $modalId }}Label">{{ $modalTitle }}...</h6>
                    <!-- Menu Bar -->
                    <div class="container d-flex justify-content-between align-items-center my-1 px-0">
                        <input type="text" id="searchBar{{ $modalItem }}" class="form-control me-2" placeholder="Rechercher..."/>
                    </div>
                </div>
                <div class="modal-body border-0">

                <!-- Item Grid -->
                <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-3">
                    @foreach($items as $item)
                    <div class="col item-card{{ $modalItem }} @if(in_array($item['id'], $modalSelectedItems)) selected{{ $modalItem }} @endif" data-{{ $modalItem }}-title="{{ strtolower($item['titre']) }}" data-{{ $modalItem }}-id="{{ $item['id'] }}" @if(isset($item['type'])) data-{{ $modalItem }}-type="{{ $item['type'] }}" @endif>
                        <div class="card pt-2 text-center border-0">
                            @if(!empty($item['image']))
                                <div class="container-fluid">
                                    <div class="mtblock-rect lazy-bg" data-bg="{{ $item['image'] }}"></div>
                                </div>
                            @else
                                <div class="placeholder-image d-flex align-items-center justify-content-center bg-secondary text-white">
                                    <span style="font-size: 200%">{{ strtoupper(substr($item['titre'], 0, 1)) }}</span>
                                </div>
                            @endif
                            <div class="card-body p-1">
                                <h6 class="card-title fs-80">{{ substr($item['titre'] ,0,40)}} @if(strlen($item['titre'])> 40) ... @endif</h6>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                </div>
                <div class="modal-footer border-0 py-1">
                <button type="button" class="btn btn-primary rounded-pill fs-90" id="{{ $modalItem }}importSelected"  data-bs-dismiss="modal">Valider</button>
                </div>
            </div>
        </div>
    </div>
</div>

<input id="modalSelectModeInput{{ $modalItem }}" type="hidden" value="{{ $modalSelectMode }}">

<style>
    .placeholder-image {
        height: 200px;
    }
    .item-card{{ $modalItem }}.selected{{ $modalItem }} .card {
        box-shadow: 0 0 8px var(--coul1), 0 0 2px var(--coul1) inset;
        cursor: pointer !important;
        transition: all 0.3s ease-in-out;
        transform: scale(1.01);
        background-color: rgba(var(--coul1), 0.04);
    }

    /* Effet au survol même quand sélectionné */
    .item-card{{ $modalItem }}.selected{{ $modalItem }} .card:hover {
        box-shadow: 0 0 10px var(--coul1), 0 0 3px var(--coul1) inset;
        transform: scale(1.02);
    }

    


</style>

<input type="hidden" id="selectedItemsInput{{ $modalItem }}" name="{{ $modalItemName }}" value="">

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const selectedLabel='selected{{ $modalItem }}';//terme utiliser pour designer les element selectionner pour eviter les conflit au cas ou le modal pourra etre appele plusieurs fois dans le meme programme
        const searchBar = document.getElementById('searchBar{{ $modalItem }}');
        const itemCards = document.querySelectorAll('.item-card{{ $modalItem }}');
        const selectedItemsInput = document.getElementById('selectedItemsInput{{ $modalItem }}');
        const modalSelectModeInput = document.getElementById('modalSelectModeInput{{ $modalItem }}');
        let selectedItems = modalSelectModeInput.value === 'multiple' ? [] : '';//variable pour les ids elements selectionnés
        let selectedTitle= '';//variable pour les ids elements selectionnés

        // Initialisation : Ajoutez les éléments déjà sélectionnés
        itemCards.forEach(card => {
            if (card.classList.contains(selectedLabel)) {
                const itemId = card.getAttribute('data-{{ $modalItem }}-id');
                const itemTitle = card.getAttribute('data-{{ $modalItem }}-title');
                const itemType = card.getAttribute('data-{{ $modalItem }}-type');
                if (modalSelectModeInput.value === 'multiple') {
                    if (itemType != null) {
                        selectedItems.push([itemId,itemType]); //le resultat est un tableau
                    } else {
                        selectedItems.push(itemId);
                    }
                } else {
                    if (itemType != null) {
                        selectedItems=[itemId,itemType]; //le resultat est un tableau
                        selectedTitle=itemTitle;
                    } else {
                        selectedItems=itemId;
                        selectedTitle=itemTitle;
                    }
                }
            }
        });

        // Mettez à jour le champ caché avec les IDs sélectionnés dès le départ
        selectedItemsInput.value = modalSelectModeInput.value === 'multiple' ? JSON.stringify(selectedItems) : selectedItems ;

        // Recherche dans la liste
        searchBar.addEventListener('input', () => {
            const query = searchBar.value.toLowerCase();
            itemCards.forEach(card => {
                const title = card.getAttribute('data-{{ $modalItem }}-title');
                card.style.display = title.includes(query) ? '' : 'none';
            });
        });

        // Sélection des éléments
        itemCards.forEach(card => {
            card.addEventListener('click', () => {

                const itemType = card.getAttribute('data-{{ $modalItem }}-type');
                const itemId = card.getAttribute('data-{{ $modalItem }}-id');
                const itemTitle= card.getAttribute('data-{{ $modalItem }}-title');
                if (modalSelectModeInput.value === 'multiple') {
                    card.classList.toggle(selectedLabel);
                    if (card.classList.contains(selectedLabel)) {
                        if (itemType != null) {
                            selectedItems.push([itemId,itemType]); //le resultat est un tableau
                        } else {
                            selectedItems.push(itemId);
                        }
                    } else {
                        const index = selectedItems.indexOf(itemId);
                        if (index > -1) selectedItems.splice(index, 1);
                    }
                } else {

                    if (card.classList.contains(selectedLabel)) {
                        card.classList.remove(selectedLabel);
                        selectedItems = '';
                        selectedTitle='';
                    }
                    else{
                        itemCards.forEach(c => c.classList.remove(selectedLabel));
                        card.classList.add(selectedLabel);
                        // selectedItems=card.getAttribute('data-{{ $modalItem }}-id');
                        // selectedTitle=card.getAttribute('data-{{ $modalItem }}-title');

                        if (itemType != null) {
                            selectedItems=[itemId,itemType]; //le resultat est un tableau
                            selectedTitle=itemTitle;
                        } else {
                            selectedItems=itemId;
                            selectedTitle=itemTitle;
                        }
                    }
                }
                // Mettez à jour le champ caché avec les IDs sélectionnés
                selectedItemsInput.value = modalSelectModeInput.value === 'multiple' || Array.isArray(selectedItems) ? JSON.stringify(selectedItems) : selectedItems ;
            });
        });

        // Mise à jour du label
        document.getElementById('{{ $modalItem }}importSelected').addEventListener('click', () => {

            if (modalSelectModeInput.value === 'multiple') {
                const selectedItemsCount = selectedItems.length;
                const selectedItemsConvert = selectedItemsCount < 10 ? `0${selectedItemsCount}` : selectedItemsCount ;
                if (selectedItems.length > 0) {
                    document.getElementById('{{ $modalItem }}label').innerText = selectedItemsCount > 1
                        ? `${selectedItemsConvert} sélections`
                        : `${selectedItemsConvert} sélection`;
                } else {
                    document.getElementById('{{ $modalItem }}label').innerText = `Aucune sélection...`;
                }
            } else {
                if (selectedItemsInput.value != '') {
                    document.getElementById('{{ $modalItem }}label').innerText =selectedTitle;
                } else {
                    document.getElementById('{{ $modalItem }}label').innerText = `Aucune sélection...`;
                }
            }
            
        });
    });

</script>
