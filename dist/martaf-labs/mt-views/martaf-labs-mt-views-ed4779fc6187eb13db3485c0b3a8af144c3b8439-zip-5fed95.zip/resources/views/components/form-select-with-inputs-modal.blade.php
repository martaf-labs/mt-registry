@php
    $modalId = $modalId ?? 'modalselector';
    $items = $modalData ?? [];
    $modalTitle = $modalTitle ?? 'Sélectionner...';
    $modalItem = $modalId;
    $modalItemName = $modalItemName ?? '';
    $modalSelectedItems = $modalSelectedItems ?? []; // Éléments pré-sélectionnés
@endphp

<div class="container my-3">
    <!-- Modal -->
    <div class="modal fade" id="{{ $modalId }}" tabindex="-1" aria-labelledby="{{ $modalId }}Label" aria-hidden="true"  data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
            <div class="modal-content mtzoom-in">
                <div class="modal-header border-0 py-2 d-flex flex-column align-items-start">
                    <h6 class="modal-title" id="{{ $modalId }}Label">{{ $modalTitle }}...</h6>
                    <!-- Menu Bar -->
                    <div class="container d-flex justify-content-between align-items-center my-1 px-0">
                        <input type="text" id="searchBar{{ $modalItem }}" class="form-control me-2" placeholder="Rechercher..."/>
                    </div>
                </div>
                <div class="modal-body border-0">
                <!-- Item Grid -->
                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-3">
                    @foreach($items as $item)
                    @php
                        // dd($modalSelectedItems);
                        // dd(in_array($item['dataKey'], $modalSelectedItems));
                    @endphp
                        <div class="col item-input-card{{ $modalItem }}" id="{{ $item['id'] }}Card">
                            <div class="card text-start border-0">
                                <div class="form-group p-2">
                                    <label for="{{ $item['id'] }}Input" class="form-label text-capitalize fs-80">
                                        <input type="checkbox" name="{{ $item['id'] }}CheckName" @if(in_array($item['dataKey'], $modalSelectedItems)) checked @endif id="{{ $item['id'] }}Check" class="item-input-check-card{{ $modalItem }}" data-{{ $modalItem }}-title="{{ strtolower($item['label']) }}" data-{{ $modalItem }}-id="{{ $item['id'] }}" data-{{ $modalItem }}-key="{{ $item['dataKey'] }}">
                                        {{ $item['label'] }}
                                    </label>

                                    <!-- element de type select -->
                                    @if (in_array($item['type'], ['select-multiple','select']))
                                        @php
                                            $listItem=$item['listItem']?? [];
                                            $itemOldvalue = $item['oldvalue'] ?? [];
                                        @endphp

                                        <select name="" id="{{ $item['id'] }}Input" class="form-select" @if($item['type'] === 'select-multiple') multiple @endif @if(!in_array($item['dataKey'], $modalSelectedItems)) disabled @endif>
                                            @foreach ($listItem as $key=>$value)
                                                <option @if($item['type'] === 'select-multiple') @selected(in_array($key,$itemOldvalue)) @else @selected($key == old($modalItemName, $itemOldvalue)) @endif value="{{ $key }}" class="text-capitalize">{{ $value }}</option>
                                            @endforeach
                                        </select>
                                    @else
                                        <!-- element de type text, number et autre -->
                                        @php
                                            $itemOldvalue = $item['oldvalue'] ?? '';
                                        @endphp
                                        <input type="{{ $item['type'] }}"  name="{{ $item['id'] }}CheckName" id="{{ $item['id'] }}Input" value="{{ $itemOldvalue }}" class="form-control" @if ($item['type']=='number') step="any" @endif @if(!in_array($item['dataKey'], $modalSelectedItems)) disabled @endif>
                                    @endif
                                    
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
                </div>
                <div class="modal-footer border-0 py-1">
                <button type="button" class="btn btn-primary rounded-pill fs-90" id="{{ $modalItem }}importSelected"  data-bs-dismiss="modal">Valider</button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .item-input-card{{ $modalItem }} .card {
        cursor: pointer;
    }
    .item-input-card{{ $modalItem }}.selected{{ $modalItem }} .card {
        border: 2px solid #0d6efd !important;
    }
</style>

<input type="hidden" id="selectedItemsInput{{ $modalItem }}" name="{{ $modalItemName }}" value="{{ json_encode($modalSelectedItems,true) }}">

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const selectedLabel='selected{{ $modalItem }}';//terme utiliser pour designer les element selectionner pour eviter les conflit au cas ou le modal pourra etre appele plusieurs fois dans le meme programme
        const searchBar = document.getElementById('searchBar{{ $modalItem }}');
        const itemCards = document.querySelectorAll('.item-input-check-card{{ $modalItem }}');
        // const itemCards = document.querySelectorAll('.item-input-card{{ $modalItem }}');
        let selectedItems = new Map();//variable pour les ids elements selectionnés
        const selectedItemsInput = document.getElementById('selectedItemsInput{{ $modalItem }}');
        let selectedTitle= '';//variable pour les ids elements selectionnés

        // Recherche dans la liste
        searchBar.addEventListener('input', () => {
            const query = searchBar.value.toLowerCase();
            itemCards.forEach(card => {
                const title = card.getAttribute('data-{{ $modalItem }}-title');
                const idCard = card.getAttribute('data-{{ $modalItem }}-id');
                let blockCard=document.getElementById(`${idCard}Card`)
                blockCard.style.display = title.includes(query) ? '' : 'none';
            });
        });

        // Sélection des éléments
        itemCards.forEach(card => {
            const itemId = card.getAttribute('data-{{ $modalItem }}-id');
            const itemKey = card.getAttribute('data-{{ $modalItem }}-key');
            const itemTitle= card.getAttribute('data-{{ $modalItem }}-title');
            const cardInput=document.getElementById(`${itemId}Input`)

            card.addEventListener('click', () => {
                // mise à jour de l'input
                if (cardInput.disabled==true) {
                    cardInput.disabled=false;
                } else {
                    cardInput.value=''; //on reinitialise la valeur du champ
                    cardInput.disabled=true
                }
            });
        });

        // Mise à jour du label
        document.getElementById('{{ $modalItem }}importSelected').addEventListener('click', () => {

            // Mettez à jour le champ caché avec les IDs sélectionnés
            itemCards.forEach(card => {
                if (card.checked === true) {
                    const itemId = card.getAttribute('data-{{ $modalItem }}-id');
                    const itemKey = card.getAttribute('data-{{ $modalItem }}-key');
                    const itemTitle = card.getAttribute('data-{{ $modalItem }}-title');
                    const itemInputValue = document.getElementById(`${itemId}Input`);

                    //recuperation des valeur n fonction des type de champ
                    if (itemInputValue.tagName.toLowerCase() === 'select' && itemInputValue.multiple) {
                        let valeur = Array.from(itemInputValue.options)
                        .filter(option => option.selected)
                        .map(option => option.value);

                        //ajout des element dans le map principal
                        if (valeur.length > 0) {
                            selectedItems.set(itemKey,valeur);
                        } 
                    } 
                    else {
                        const valeur = itemInputValue.value;
                        if (valeur.toString().length > 0) {
                            selectedItems.set(itemKey,valeur);
                        } 
                    }                  
                }
                else{
                    const itemKeyDeleted = card.getAttribute('data-{{ $modalItem }}-key');
                    //on essaye de supprimer la l'element du map si il existe
                    if (selectedItems.has(itemKeyDeleted)) {
                        selectedItems.delete(itemKeyDeleted);
                    }
                }
            });

            const selectedItemsCount = selectedItems.size;
            const selectedItemsConvert = selectedItemsCount < 10 ? `0${selectedItemsCount}` : selectedItemsCount ;

            if (selectedItems.size > 0) {
                document.getElementById('{{ $modalItem }}label').innerText = selectedItemsCount > 1
                    ? `${selectedItemsConvert} sélections`
                    : `${selectedItemsConvert} sélection`;
            } else {
                document.getElementById('{{ $modalItem }}label').innerText = `Aucune sélection...`;
            }


            selectedItemsInput.value =JSON.stringify(Object.fromEntries(selectedItems));
            // console.log(selectedItems);
            
        });
    });

</script>
