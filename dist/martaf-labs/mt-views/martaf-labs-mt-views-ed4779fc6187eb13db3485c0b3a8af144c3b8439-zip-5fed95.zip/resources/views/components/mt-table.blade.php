<style>
    /* Effet de survol sur les lignes du corps du tableau */
    .table-hover .row {
        cursor: pointer;
    }
    /* Effet de survol sur les lignes du corps du tableau avec ombre */
    .table-hover .row:hover {
        border-left: 3px solid var(--coul1);
        transition: all 0.1s ease; /* Transition douce pour le fond et l'ombre */
        font-weight: bolder;
    }
</style>

@props([
    'headers' => [],
    'rows' => [],
    'actions' => [], // Si tu veux passer des actions dynamiques 
])

@if (count($headers) > 0)
    <div class="container-fluid">
        {{-- En-tête --}}
        <div class="row row-cols-1 row-cols-lg-{{ count($headers) + 1 }}  d-none d-lg-flex flex-row flex-nowrap justify-content-between align-items-center fs-85">
            @foreach ($headers as $header)
                <div class="col col-lg-{{ $header['cols'] ?? 1 }} @if($loop->last) flex-grow-1 @endif  @if(!$loop->first && !$loop->last) text-center @endif  bg-t-coul1 fw-semibold border-bottom py-1 px-2 whitespace-nowrap overflow-x-hidden">

                    <!-- Ajout de l'espace vide en cas de puce sur les ligne de la colone-->
                    @if ($loop->first)
                            <!-- Version lg-->   
                            <div class="d-none d-lg-inline-block" style="width:35px">
                            </div>
                    @endif

                    @if (isset($header['icone']))
                        <i class="bi bi-apple ms-1"></i>
                    @endif
                    <span class="me-1">{{ $header['label'] }}</span>
                </div>
            @endforeach
        </div>

        {{-- Corps du tableau avec la classe "table-hover" --}}
        <div class="table-hover fs-85">
            @forelse ($rows as $row)
                <div class="row row-cols-1 row-cols-lg-{{ count($headers) + 1 }} mb-4 mb-lg-0">
                    @foreach ($headers as $key => $header)

                        @php
                            $rowkey=$row[$key];
                        @endphp

                        <div class="col col-lg-{{ $header['cols'] ?? 1 }} py-1 px-2 border-bottom @if($loop->parent->iteration % 2 === 0) bg-white @else bg-light @endif  @if($loop->last) flex-grow-1 @endif  @if(!$loop->first && !$loop->last) text-center @endif d-flex flex-column flex-lg-row flex-lg-nowrap justify-content-start justify-content-lg-between align-items-start align-items-lg-center">
                            {{-- Afficher les valeurs des lignes selon les clés des headers --}}
                            
                            @if (isset($rowkey['puce']))

                                @php
                                    $isImage=$rowkey['puce']['type']=='image'? true : false;
                                    $isIcon=$rowkey['puce']['type']=='icon'? true : false;
                                    $isLetter=$rowkey['puce']['type']=='letter'? true : false;
                                    $rowkeyPuceData=$rowkey['puce']['data'];
                                @endphp

                                @if ($isImage)    

                                    <!-- Version sm-->                        
                                    <div class="d-lg-none rounded-0 mb-2" style="width:30%">
                                        <div class="mtblock-rect lazy-bg" data-bg="{{ $rowkeyPuceData }}"></div>
                                    </div>  

                                    <!-- Version lg-->   
                                    <div class="d-none d-lg-inline-block rounded-1 me-2" style="width:45px">
                                        <div class="mtblock-sqr rounded-1 lazy-bg" data-bg="{{ $rowkeyPuceData }}"></div>
                                    </div>
                                @endif

                                @if ($isIcon || $isLetter)    

                                    <!-- Version  sm & lg-->                        
                                    <div class="p-0 me-1" style="width:35px">
                                        <div class="square">
                                            <span class="square-content bg-t-coul1 @if($isIcon) {{ $rowkeyPuceData }} @endif rounded-circle" style="font-size: 125%;">@if($isLetter) {{ $rowkeyPuceData }} @endif</span>
                                        </div>
                                    </div>  
                                    
                                @endif

                            @endif

                            <!-- configuration des badges -->
                            @php
                                $badgeTypeClass=null;
                            @endphp
                            @if (isset($rowkey['badge']))
                                @php
                                    $rowkeyBadge=$rowkey['badge'];
                                    $badgeTypeClass=in_array($rowkeyBadge['type'],['info','warning','light'])? "text-bg-$rowkeyBadge[type]" : "bg-$rowkeyBadge[type] text-light"; 
                                @endphp
                            @endif

                            <span class="d-inline-block d-lg-none fw-bold mb-1">{{ Str::ucfirst($header['label']) }}</span>

                            <span class="d-inline-block d-lg-none @if (!is_null($badgeTypeClass)){{ $badgeTypeClass }} rounded-pill text-center px-2 @else  fg-coul3 @endif">{{ Str::ucfirst($rowkey['label']) ?? 'N/A' }}</span>

                            <span class="d-none d-lg-inline-block w-100 lh-1 @if (!is_null($badgeTypeClass)){{ $badgeTypeClass }} rounded-pill text-center px-2 py-1 @endif">{{ Str::ucfirst($rowkey['label']) ?? 'N/A' }}</span>

                            @if ($loop->last)

                                @if(isset($row['actions']) && is_array($row['actions']))
                                    {{-- Colonne d'actions --}}
                                    <div class="d-flex flex-row justify-content-end align-self-end py-1 px-1">
                                        {{-- Actions à effectuer, comme des boutons --}}

                                        <div class="dropdown">
                                            <a class="btn btn-outline-primary btn-sm d-lg-none py-1 fs-90" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                Actions
                                                <i class="bi bi-box-arrow-in-up-right"></i>
                                            </a>
                                            @if (count($row['actions']) > 0)
                                                <a class="lnk-coul1 d-none d-lg-block fs-6" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="bi bi-three-dots-vertical"></i>
                                                </a>
                                            @endif
                                            <ul class="dropdown-menu p-0" style="">
                                                @foreach($row['actions'] as $action)
                                                    <li class="">
                                                        @if ($action['type'] === 'destroy')

                                                            <form action="{{ $action['lien'] }}" method="post" class="container-fluid d-flex flex-column justify-content-between align-items-center w-100 px-0 text-center">
                                                                @csrf
                                                                @method('delete')
                                                                <input type="hidden" name="id" value="{{ $action['id'] }}" style="width: 0px; height:0px; paddind:0; margin:0">

                                                                <div class="dropdown-item link link-danger fs-85  {{ $action['icone'] }}">
                                                                    <input type="submit" value="{{ $action['label'] }}" class="dropdown-item d-inline-block ms-1 px-0 text-start link link-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer définitivement ces données ?')">
                                                                </div>
                                                            </form>
                                                        @elseif ($action['type'] === 'disabled')
                                                            <a class="dropdown-item link fs-85 disabled" href="{{ $action['lien'] }}">
                                                                @isset($action['icone'])
                                                                    <i class="{{ $action['icone'] }} me-1"></i>
                                                                @endisset

                                                                {{ $action['label'] }}
                                                            </a>
                                                        @else
                                                            <a class="dropdown-item link fs-85" href="{{ $action['lien'] }}">
                                                                @isset($action['icone'])
                                                                    <i class="{{ $action['icone'] }} me-1"></i>
                                                                @endisset

                                                                {{ $action['label'] }}
                                                            </a>
                                                        @endif
                                                    </li>
                                                @endforeach
                                                
                                            </ul>
                                        </div>
                                    </div>
                                        
                                @endif
                                
                            @endif
                        </div>
                    @endforeach

                </div>
            @empty
                <div class="row">
                    <div class="col text-center text-muted py-3">
                        Aucun enregistrement trouvé.
                    </div>
                </div>
            @endforelse
        </div>
    </div>
@endif
