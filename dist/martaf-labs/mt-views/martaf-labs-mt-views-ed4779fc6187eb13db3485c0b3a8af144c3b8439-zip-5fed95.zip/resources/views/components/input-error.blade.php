@props(['messages'])

@if ($messages)
    <ul {{ $attributes->merge(['class' => 'fs-70']) }}>
        @foreach ((array) $messages as $message)
            <li>{{ $message }}</li>
        @endforeach
    </ul>
@endif
