<button {{ $attributes->merge(['type' => 'button', 'class' => 'btn-l-gradient-coul2 border-0 px-2 py-1 px-md-4 py-md-2 rounded-pill']) }}>
    {{ $slot }}
</button>