
<div {{ $attributes->merge(['class' => 'container bg-t-coul4 shadow-sm p-2 rounded-2']) }}>
    <h6 class="bi bi-chevron-right ps-1 fg-coul1-0 opacity-75 fs-90">{{ $label }}</h6>
    <div class="container-fluid d-flex flex-row flex-nowrap justify-between align-items-center">
        <span class="d-block shadow-ms me-3 fg-coul4" style="width: 40px">
            <span class="square d-block bg-coul1 rounded-circle">
                <span class="square-content {{ $icone }}">
                </span>
            </span>
        </span>
        <div class="d-flex flex-row flex-nowrap justify-between align-items-center">
            <span class="text-dark fs-1 fw-bold">{{ $nombre }}</span>  
            <p class="text-success fs-60 ms-1">@if($nombre>1) Disponibles @else Disponible @endif</p>                          
        </div>
    </div>
</div>