@php
    $id= (isset($id)) ? $id : '';
    $icone= (isset($icone)) ? $icone : '';
    $iconeWidth= (isset($iconeWidth)) ? $iconeWidth : '40';
    $iconeBg = (isset($iconeBg)) ? $iconeBg : 'bg-coul1';
    $iconeFg = (isset($iconeFg)) ? $iconeFg : 'fg-coul4';
    $labelFg = (isset($labelFg)) ? $labelFg : 'fg-coul4';
@endphp

<a {{ $attributes->merge(['id' => $id,'class' => 'd-flex flex-row flex-nowrap justify-content-start align-item-center px-2 py-1  ']) }}>
    <span class="d-block shadow-ms me-2" style="width: {{ $iconeWidth }}px">
        <span class="square d-block rounded-circle {{ $iconeBg }}">
            <span class="square-content {{ $icone }} {{ $iconeFg }}">
            </span>
        </span>
    </span>
    <span class="d-flex flex-column justify-content-center {{ $labelFg}}">{{ $slot }}</span>
</a>