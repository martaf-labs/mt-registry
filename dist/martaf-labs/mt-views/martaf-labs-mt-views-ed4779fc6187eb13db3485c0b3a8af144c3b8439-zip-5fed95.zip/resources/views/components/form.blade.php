
@php
    // Nettoyage session
    // session()->forget(['formSessionData']);

    //initiation variables
    $formDatas=$formDatas?? [];
    $action=$action?? ''; //route du formulaire

    $isMultiStep = $formDatas['__meta']['isMultiStep'] ?? false;
    $model = $formDatas['__meta']['model'] ?? null;
    $formSessionKey = !is_null($model)? "formSessionData.{$model}" : null;
    // $steps = $isMultiStep ? array_keys(array_filter($formDatas, 'is_array')) : [1];

    if(!is_null($formSessionKey) && !session()->has($formSessionKey)){
        session()->put("{$formSessionKey}.currentStep", 1);
    }

    //l'etape en cours
    // $currentStep =$isMultiStep && session()->has('currentStep')? (int) session('currentStep') : 1;//session en cours
    $currentStep =session()->has("{$formSessionKey}.currentStep") && session("{$formSessionKey}.currentStep") >= 1 ? session("{$formSessionKey}.currentStep") : null;//session en cours

    //elaboration des etapes
    $isFirstStep = $isMultiStep && $currentStep == $formDatas['__meta']['steps'][0] ? true : false ;
    $isLastStep = $isMultiStep && $currentStep == end($formDatas['__meta']['steps']) ? true : false ;

    //les element du formulaire
    $items=!is_null($currentStep)? $formDatas[$currentStep] : $formDatas;


@endphp


<style>
    #form .form-control,#form .form-select,#form .form-check-label,#form .form-check-input,#form .btn, #form .form-floating,#form span,#form ::placeholder,#form label{
        font-size: 90% !important;
    }
</style>

<form id="form" class="container-fluid @empty($items) d-none @endempty form px-0" action="{{ $action }}" method="post" enctype="multipart/form-data">

    @csrf
    @if( $mode == "edit")
        @method('PUT')
    @endif

    <div class="container-fluid px-0 d-flex flex-row flex-wrap justify-content-between align-items-start">
        @foreach ($items as $item)

            @php    
                //reconfiguration des elements de item pour eviter des erreur d'assignation
                $itemType=$item['type']?? '';
                $itemId=$item['id']?? '';
                $itemLabel=$item['label']?? '';
                $itemName=$item['name']?? '';
                $itemOldvalue=$item['oldvalue']?? '';
                $itemListItems=$item['listItems']?? [];
                $itemSelectItem=$item['selectItem']?? '';
                $itemModalTitle=$item['modalTitle']?? '';
                $itemCol=$item['col']?? 12;
                $isDisabledItem= $item['disabled']?? false;
                $itemModalSelectMode=$item['modalSelectMode']?? 'unique';
                $itemPlugins=$item['plugins']?? '';
                
                //recuperation et configuration des regle de validation
                $itemRules = $item['rules'] ?? '';
                $isRequired = Str::contains(is_array($itemRules) ? implode('|', $itemRules) : $itemRules, 'required');

            @endphp

            <div class="container-fluid @if (in_array($itemType,['checkbox'])) form-check @else form-floating px-0 px-lg-1 @endif my-2 col-12 col-lg-{{ $itemCol }}" style="@if($itemType=='hidden') width:0px;height:0px @endif">


                @if ($itemType=='text')
                    <!--champ de type text-->
                    <input type="text" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" @if($isDisabledItem) readonly @endif autofocus>
                @endif

                @if ($itemType=='email')
                    <!--champ de type email-->
                    @if (isset($login))
                        <input type="email" name="{{ $itemName }}" id="{{ $itemId }}" value="" class="form-control" autofocus>
                    @else
                        <input type="email" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" autofocus>
                    @endif
                @endif

                @if ($itemType=='password')
                    <!--champ de type email-->
                    @if (isset($login))
                        <input type="password" name="{{ $itemName }}" id="{{ $itemId }}" value="" placeholder="" class="form-control" autofocus>
                    @else
                        <input type="password" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" autofocus>
                    @endif
                @endif

                @if ($itemType=='tel')
                    <!--champ de type tel-->
                    <input type="tel" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" autofocus>
                @endif

                @if ($itemType=='number')
                    <!--champ de type number-->
                    <input type="number" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" @isset($item['min']) min="{{ $item['min'] }}" @endif @isset($item['max']) max="{{ $item['max'] }}" @endif  autofocus>
                @endif

                @if ($itemType=='float')
                    <!--champ de type float-->
                    {{-- <input type="text" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" autofocus> --}}
                    <input type="number" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" @isset($item['min']) min="{{ $item['min'] }}" @endif @isset($item['max']) max="{{ $item['max'] }}" @endif step="0.01" autofocus>
                @endif

                @if ($itemType=='hidden')
                    <!--champ de type hidden-->
                    <input type="hidden" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}">
                @endif

                @if ($itemType=='label')
                    <!--champ de type label-->
                    <h5 class="fw-bold">{{ $itemOldvalue }}</h5>
                @endif

                @if ($itemType=='datasTemp')
                    <!--champ de type datasTemp: pour les stocker les donnees temporaires neccessaire pour l'application-->
                    <div id="{{ $itemId }}" data-{{ $itemId }}= "{{ $item['data'] }}"></div>
                @endif

                @if ($itemType=='jsScript')
                    <!--champ de type jsScript: pour les stocker les scripts javascript-->

                    <script>
                        {!! $item['script'] !!}
                    </script>
                    
                @endif

                @if ($itemType=='date')
                    <!--champ de type date-->
                    <input type="date" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" placeholder="" class="form-control @error($itemName) is-invalid @enderror" autofocus @if($isDisabledItem) disabled @endif>
                @endif

                @if ($itemType=='datetime')
                    <!--champ de type datetime-->
                    <input type="datetime-local" name="{{ $item['name'] }}" id="{{ $item['id'] }}" value="{{ @old($item['name'],$item['oldvalue']) }}" class="form-control fs-90 custom-input rounded-2 @error($item['name']) is-invalid @enderror" autofocus @if($isDisabledItem) disabled @endif>
                @endif

                @if ($itemType=='checkbox')
                    <!--champ de type checkbox-->
                    <input type="checkbox" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" @checked($itemOldvalue == $item['selectItem']) class="form-check-input @error($itemName) is-invalid @enderror" autofocus>
                @endif

                @if ($itemType=='select')
                    <!--champ de type select-->
                    @php
                        $listItems=$item['listItems']?? [];
                    @endphp
                    <select name="{{ $itemName }}" id="{{ $itemId }}" aria-label="" class="form-select @error($itemName) is-invalid @enderror" onchange="{{ $item['onchange']?? '' }}" @if($isDisabledItem && $item['disabled']==true) disabled @endif autofocus>
                        <option value="">Aucun(e)</option>
                        @foreach ($listItems as $key=>$value)
                            <option  @selected($key == old($itemName, $itemOldvalue)) value="{{ $key }}" class="fw-bold">{{ $value }}</option>
                        @endforeach
                    </select>
                @endif

                @if ($itemType=='modal-select')
                
                    @php
                        $selectOldvalue=$item['oldvalue']?? [];
                        $selectModalData=$item['modalData']?? [];
                        $itemIdUnique=str_replace('-','',strtolower(Str::slug($itemId)));
                        $selectOldvalueTitre=$selectOldvalue['titre']?? "Aucune sélection...";
                    @endphp

                    <div class="container-fluid form-group my-0 pt-1 pb-3 bg-coul4 border rounded-2">
                        <label for="{{ $itemId }}" class="form-label my-0 py-0">
                            {{ ucfirst($itemLabel) }}
                            @if ($isRequired) <span class="text-danger">*</span> @endif
                        </label>
                        <!--bouton pour ouvrir le modal select-->
                        <button type="button" data-bs-toggle="modal" data-bs-target="#{{ $itemIdUnique }}" class="btn btn-coul1 w-100  text-center rounded-2 @if(count($selectModalData) == 0) disabled @endif">
                            <!-- <span class="bi bi-pencil"></span> --> 
                            <span id="{{ $itemIdUnique}}label" class="text-capitalize whitespace-nowrap overflow-hidden d-block">
                                @if($itemModalSelectMode === 'multiple')
                                    {{ ($mode === 'edit')? addZero(count($selectOldvalue))." selection(s)" : "Aucune sélection..." }} 
                                @else 
                                    {{ $selectOldvalueTitre }}
                                @endif
                            </span>
                        </button>
                    </div>

                    <x-form-modal :modalId="$itemIdUnique" :modalTitle="$item['modalTitle']" :modalSelectMode="$itemModalSelectMode" :modalData="$selectModalData"  :modalItemName="$itemName" :modalSelectedItems="$selectOldvalue"></x-form-modal> 
                    {{-- <input type="hidden" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}"> --}}
                @endif


                @if ($itemType=='select-multiple-simple')
                    <!-- Champ de type select-multiple avec option de tout cocher/décocher -->
                    <div class="custom-select-container">
                        <label for="{{ $itemId }}" class="form-label my-0 py-0">
                            {{ ucfirst($itemLabel) }}
                            @if ($isRequired) <span class="text-danger">*</span> @endif
                        </label>
                        <button type="button" class="btn btn-outline-secondary form-control px-2">
                            <span class="d-block whitespace-nowrap overflow-hidden" id="select-btn-{{ $itemId }}">{{ $item['listTitle'] }}</span>
                        </button>
                        <div id="select-dropdown-{{ $itemId }}" class="custom-select-dropdown rounded-2 p-2 shadow-sm" style="max-height: 50vh; overflow-y:scroll">
                            <div class="form-check d-flex flex-row flex-nowrap justify-content-end my-1 align-self-end">
                                <input class="form-check-input" type="checkbox" id="select-all-{{ $itemId }}">
                                <label class="form-check-label ms-1" for="select-all-{{ $itemId }}">Tout cocher / décocher</label>
                            </div>
                            <div class="row row-cols-1 mx-auto row-cols-2 p-1 shadow-sm rounded-2">
                                @foreach ($item['listItems'] as $key => $value)
                                    <div class="col form-check d-flex flex-row flex-nowrap justify-content-start my-1">
                                        <input class="form-check-input me-1" type="checkbox" value="{{ @old($itemName, $key) }}" @checked(in_array($key, array_keys($itemOldvalue))) id="option{{ $itemId }}-{{ $key }}" name="{{ $itemName }}[]" data-index="{{ $loop->index }}">
                                        <label class="form-check-label me-2" for="option{{ $itemId }}-{{ $key }}">{{ $value }}</label>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div id="selected-options-container-{{ $itemId }}"></div>

                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            const selectBtn = document.getElementById('select-btn-{{ $itemId }}');
                            const selectDropdown = document.getElementById('select-dropdown-{{ $itemId }}');
                            const checkboxes = document.querySelectorAll('#select-dropdown-{{ $itemId }} .form-check-input');
                            const selectAllCheckbox = document.getElementById('select-all-{{ $itemId }}');
                            let selectedOptions = @JSON(array_values($itemOldvalue));

                            // Affichage du texte initial
                            selectBtn.textContent = selectedOptions.length > 0 ? selectedOptions.join(', ') : '{{ $item['listTitle'] }}';

                            selectBtn.addEventListener('click', function() {
                                selectDropdown.classList.toggle('show');
                            });

                            document.addEventListener('click', function(event) {
                                if (!event.target.closest('.custom-select-container')) {
                                    selectDropdown.classList.remove('show');
                                }
                            });

                            // Mise à jour des options sélectionnées dans le bouton
                            checkboxes.forEach(function(checkbox) {
                                checkbox.addEventListener('change', function() {
                                    selectedOptions = [];
                                    selectBtn.innerHTML = '';
                                    checkboxes.forEach(function(box) {
                                        if (box.checked) {
                                            selectedOptions.push(box.nextElementSibling.textContent);
                                        }
                                    });
                                    selectBtn.textContent = selectedOptions.length > 0 ? selectedOptions.join(', ') : '{{ $item['listTitle'] }}';
                                });
                            });

                            // Gérer le comportement de "Tout cocher / décocher"
                            selectAllCheckbox.addEventListener('change', function() {
                                checkboxes.forEach(function(checkbox) {
                                    checkbox.checked = selectAllCheckbox.checked;
                                });
                                selectedOptions = selectAllCheckbox.checked ? Array.from(checkboxes).map(box => box.nextElementSibling.textContent) : [];
                                selectBtn.textContent = selectedOptions.length > 0 ? selectedOptions.join(', ') : '{{ $item['listTitle'] }}';
                            });
                        });
                    </script>
                @endif


                @if ($itemType=='select-multiple')

                    <!--champ de type select-multiple-->
                    <div class="custom-select-container">
                        <label for="{{ $itemId }}" class="form-label my-0 py-0">
                            {{ ucfirst($itemLabel) }}
                            @if ($isRequired) <span class="text-danger">*</span> @endif
                        </label>
                        <button type="button" id="select-btn" class="btn btn-outline-secondary form-control">{{ $item['listTitle'] }}</button>
                        <div id="select-dropdown" class="custom-select-dropdown rounded-2 p-2 shadow-sm" style="max-height: 50vh; overflow-y:scroll">
                            @foreach ($item['listItems'] as $key=>$value)
                                <div class="form-check d-flex flex-row flex-nowrap justify-content-between my-1">
                                    <div class="">
                                        <input class="form-check-input me-1" type="checkbox" value="{{ $key }}" id="option{{ $key }}" data-index="{{ $loop->index}}">
                                        <label class="form-check-label me-2" for="option{{ $key }}">{{ $value }}</label>
                                    </div>
                                        <input class="form-text-input form-control py-0 rounded-2" type="text" value="" id="inputOption{{ $key }}">
                                </div>
                            @endforeach
                        </div>
                    </div>
                    <div id="selected-options-container"></div>

                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            const selectBtn = document.getElementById('select-btn');
                            const selectDropdown = document.getElementById('select-dropdown');
                            const checkboxes = document.querySelectorAll('.form-check-input');
                            const textinputs = document.querySelectorAll('.form-text-input');
                            const selectedOptionsContainer = document.getElementById('selected-options-container');

                            // mise à jour des element de textinputs
                            textinputs.forEach(function(input){
                                input.classList.add('d-none');
                            });
                            
                            selectBtn.addEventListener('click', function() {
                                selectDropdown.classList.toggle('show');
                            });

                            document.addEventListener('click', function(event) {
                                if (!event.target.closest('.custom-select-container')) {
                                    selectDropdown.classList.remove('show');
                                }
                            });

                            checkboxes.forEach(function(checkbox) {
                                checkbox.addEventListener('change', function() {
                                    let selectedOptions = [];
                                    selectedOptionsContainer.innerHTML = '';
                                    checkboxes.forEach(function(box) {

                                        boxInput=textinputs[box.getAttribute('data-index')];
                                        if (box.checked) {
                                            selectedOptions.push(box.nextElementSibling.textContent);
                                            boxInput.classList.remove('d-none');
                                            boxInput.name = "{{ $itemName }}[" + box.value + "]";
                                            console.log(box.nextElementSibling.textContent)
                                        }
                                    });
                                    selectBtn.textContent = selectedOptions.length ? selectedOptions.join(', ') : '{{ $item['listTitle'] }}';
                                });
                            });
                        });
                    </script>
                @endif

                @if ($itemType=='select-with-inputs')

                    @php
                        $selectOldvalue=$item['oldvalue']?? [];
                        // dd($selectOldvalue);
                        $itemIdUnique=str_replace('-','',strtolower(Str::slug($itemId)));
                    @endphp

                    <div class="container-fluid form-group my-0 pt-1 pb-3 bg-coul4 border rounded-2">
                        <label for="{{ $itemId }}" class="form-label my-0 py-0">
                            {{ ucfirst($itemLabel) }}
                            @if ($isRequired) <span class="text-danger">*</span> @endif
                        </label>
                        <!--bouton pour ouvrir le modal select-->
                        <button type="button" data-bs-toggle="modal" data-bs-target="#{{ $itemIdUnique }}" class="btn btn-coul1 w-100 text-center  rounded-2">
                            <!-- <span class="bi bi-pencil"></span> --> 
                            <span id="{{ $itemIdUnique }}label" class="text-capitalize whitespace-nowrap overflow-hidden d-block">{{ ($mode === 'edit')? addZero(count($selectOldvalue))." selection(s)" : "Aucune sélection..." }}</span>
                        </button>
                    </div>

                    <x-form-select-with-inputs-modal :modalId="$itemIdUnique" :modalTitle="$item['modalTitle']" :modalData="$item['modalData']"  :modalItemName="$itemName" :modalSelectedItems="$selectOldvalue"></x-form-select-with-inputs-modal> 
                @endif


                @if ($itemType=='image' || $itemType=='images')
                    <!--champ de type image et image multiple-->
                    <div class="d-flex flex-row flex-nowrap justify-content-between align-items-center px-0">
                        <div class="container-fluid form-group my-0 pt-1 pb-3 bg-coul4 border rounded-2">
                            <label for="{{ $itemId }}" class="form-label my-0 py-0">
                                {{ ucfirst($itemLabel) }}
                                @if ($isRequired) <span class="text-danger">*</span> @endif
                                @if ($itemType=='image')
                                    <a type="button" data-bs-toggle="modal" data-bs-target="#preview{{  Str::slug($itemName) }}" class="link-primary ms-2 fs-80">voir <span class="bi bi-arrow-up-right"></span>
                                    </a>
                                @endif
                            </label>

                            @if ($itemType=='image')
                                <input type="file" accept="image/*" name="{{ $itemName }}" id="inputImage" value="{{ @old($itemName,$itemOldvalue) }}" class="form-control @error($itemName) is-invalid @enderror" autofocus>
                            @endif

                            @if ($itemType=='images')
                                <input type="file" name="{{ $itemName }}[]" class="form-control @error($itemName) is-invalid @enderror" multiple>
                            @endif

                            {{-- frame de previsualisation --}}
                            <x-preview-modal modalId="preview{{  Str::slug($itemName) }}" modalTitle="Aperçu...">                            
                                <img src="@if($mode == "edit") {{ $itemOldvalue }} @endif" alt="" class="img-fluid" id="imagePreview">
                            </x-preview-modal>
                        </div>
                        
                    </div>                 
                @endif 

                @if ($itemType=='document')
                    <!--champ de type document-->
                    <div class="d-flex flex-row flex-nowrap justify-content-between align-items-center px-0">
                        <div class="container-fluid form-group my-0 pt-1 pb-3 bg-coul4 border rounded-2">
                            <label for="{{ $itemId }}" class="form-label my-0 py-0">
                                {{ ucfirst($itemLabel) }}
                                @if ($isRequired) <span class="text-danger">*</span> @endif
                                @if ($itemType=='image')
                                    <a type="button" data-bs-toggle="modal" data-bs-target="#preview{{  Str::slug($itemName) }}" class="link-primary ms-2 fs-80">voir <span class="bi bi-arrow-up-right"></span>
                                    </a>
                                @endif
                            </label>
                            <input type="file" accept=".pdf,.doc,.docx" name="{{ $itemName }}" id="" value="{{ @old($itemName,$itemOldvalue) }}" class="form-control @error($itemName) is-invalid @enderror" autofocus>
                        </div>
                    </div>
                @endif


                @if ($itemType=='video')
                    <!--champ de type video-->
                    <div class="d-flex flex-row flex-nowrap justify-content-between align-items-center px-0">
                        <div class="container-fluid form-group px-0">
                            <label for="{{ $itemId }}" class="form-label">
                                {{ ucfirst($itemLabel) }}
                                @if ($isRequired) <span class="text-danger">*</span> @endif
                                <a type="button" data-bs-toggle="modal" data-bs-target="#previewVideo{{  Str::slug($itemName) }}" class="link-primary ms-2 fs-80">voir <span class="bi bi-arrow-up-right"></span></a>
                                </a>
                            </label>

                            @if($mode == "edit")
                                <input type="file" accept="video/*" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" class="form-control @error($itemName) is-invalid @enderror" autofocus>
                            @else
                                <input type="file" accept="video/*" name="{{ $itemName }}" id="{{ $itemId }}" value="{{ @old($itemName,$itemOldvalue) }}" class="form-control @error($itemName) is-invalid @enderror" required autofocus>
                            @endif   
                            <x-preview-modal modalId="previewVideo{{  Str::slug($itemName) }}" modalTitle="Apercu de la vidéo...">                            
                                <div class="container-fluid video-container rounded-2">
                                    <video class="" controls muted poster="" id="videoPreview">
                                        <source src="@if($mode == "edit") {{ $itemOldvalue }} @endif" type="">
                                    </video>
                                </div>
                                
                            </x-preview-modal>
                        </div>  
                    </div>  
                    
                @endif 

                @if ($itemType=='textarea')
                <!--champ de type textarea-->
                    <textarea name="{{ $itemName }}" id="{{ $itemId }}" rows="1" placeholder="" class="form-control @error($itemName) is-invalid @enderror" style="overflow:hidden; min-height: 40px;" autofocus>
                        {{ @old($itemName,$itemOldvalue) }}
                    </textarea>

                    <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            let textarea = document.getElementById('{{ $itemId }}');

                            function resizeTextarea() {
                                textarea.style.height = "auto"; // Réinitialise la hauteur
                                textarea.style.height = textarea.scrollHeight + "px"; // Ajuste la hauteur au contenu
                            }

                            // Écoute plusieurs événements pour détecter tout changement
                            textarea.addEventListener("input", resizeTextarea);
                            textarea.addEventListener("change", resizeTextarea);
                            textarea.addEventListener("keydown", resizeTextarea);
                            textarea.addEventListener("keyup", resizeTextarea);
                            textarea.addEventListener("paste", function () {
                                setTimeout(resizeTextarea, 0); // Attendre la fin du collage
                            });
                            textarea.addEventListener("cut", function () {
                                setTimeout(resizeTextarea, 0); // Attendre la fin de la suppression
                            });

                            // Ajuste la hauteur au chargement si un contenu est déjà présent
                            resizeTextarea();
                        });
                    </script>

                @endif

                @if ($itemType=='editor')
                    <!--champ de type editor : editeur de texte WYSIWYG-->
                    <textarea name="{{ $item['name'] }}" id="editor" class="form-control fs-90 custom-input rounded-2 @error($item['name']) is-invalid @enderror">
                        {{ @old($item['name'],$item['oldvalue']) }}
                    </textarea>

                    <script>
                        tinymce.init({
                            selector: '#editor', // Replace this CSS selector to match the placeholder element for TinyMCE
                            content_css: "{{ asset('css/style.css') }}",
                            plugins: '{{ $itemPlugins }}',
                            toolbar: 'undo redo | link image | code',
                            menubar: false,
                            
                            image_caption: true,
                            image_uploadtab: true,
                            image_dimensions: false, 
                            image_title: true,
                            images_file_types: 'jpeg,png,jpg,gif,webp,svg',                        
                            image_class_list: [
                                {title: 'Responsive', value: 'img-fluid'},
                            ],
                            // content_style: "img.responsive-img { width: 100%; height: auto; }",
                            content_style: `
                            img.responsive-img { 
                                max-width: 100% !important; 
                                height: auto !important; 
                                display: block !important; 
                            }`,

                            file_picker_callback: function (callback, value, meta) {
                            if (meta.filetype === 'image') {
                                var input = document.createElement('input');
                                input.setAttribute('type', 'file');
                                input.setAttribute('accept', 'image/*');
                                
                                input.onchange = function () {
                                var file = this.files[0];
                                var reader = new FileReader();
                                
                                reader.onload = function () {
                                    var id = 'blobid' + (new Date()).getTime();
                                    var blobCache = tinymce.activeEditor.editorUpload.blobCache;
                                    var blobInfo = blobCache.create(id, file, reader.result.split(',')[1]);
                                    blobCache.add(blobInfo);
                                    callback(blobInfo.blobUri(), { title: file.name });
                                };
                                
                                reader.readAsDataURL(file);
                                };
                                
                                input.click();
                            }
                        }
                    });
                    </script>
                @endif

                {{-- @if (!in_array($itemType,['hidden','container','modal-select'])) --}}
                @if (isset($itemLabel) && strlen($itemLabel)>0 && !in_array($itemType,['hidden','image','images','document','video','videos','container','modal-select','select-multiple','select-multiple-simple','select-with-inputs']))
                    <!--Label-->
                    <label for="@if (in_array($itemType,['editor'])) editor @else {{ $itemId }} @endif" class="@if (in_array($itemType,['editor'])) form-check-label @else form-label @endif">
                        {{ ucfirst($itemLabel) }}
                        @if ($isRequired) <span class="text-danger">*</span> @endif
                    </label>
                @endif

                @if ($itemType=='checkboxes')
                    <!--champ de type checkboxes: un groupe de checkboxes-->
                    <div class="row row-cols-1 row-cols-lg-2">
                        @forelse ($itemListItems as $key => $value)
                            <div class="col p-1">
                                <div class="form-check bg-white p-2 rounded-3 w-auto">
                                    <input type="checkbox" name="{{ $itemName }}" id="{{ $itemId }}{{ $key }}" value="{{ @old($itemName,$key) }}" @checked($itemOldvalue == $itemSelectItem) class="form-check-input ms-0 me-2 @error($itemName) is-invalid @enderror" autofocus>
                                    <label class="form-check-label" for="{{ $itemId }}{{ $key }}">
                                        {{ $value }}
                                </div>
                            </div>
                        @empty
                        @endforelse
                    </div>
                @endif

                @if ($itemType=='container')
                    <!--Block container à remplir avec du js-->
                    <div id="{{ $itemId}}" class="container-fluid">
                    </div>
                @endif

                @if (!in_array($itemType,['hidden']))
                    <!--message d'erreur-->
                    @error($itemName)
                        {{-- <p class="text-start fst-italic text-danger px-2 fs-80 mt-1">{{ $message }}</p> --}}
                        <div class="container mt-1">
                            <div class="alert alert-danger alert-dismissible fade show p-1 fs-80" role="alert">
                                {{ $message }}
                            </div>
                        </div>
                    @enderror
                @endif
                
                
            </div>
        @endforeach

        

    @if ($currentStep && $currentStep > 0)
        {{-- <input type="hidden" id="curentStepForm" name="currentStep" value="{{ @old('currentStep',$currentStep) }}"> --}}
        <input type="hidden" name="direction" id="form-direction" value="next">
    @endif

    </div>

    <div class="container px-1 px-lg-4 py-2 d-flex flex-row flex-nowrap justify-content-end align-items-center">
        
        @if ($isMultiStep && !$isFirstStep)
            <x-secondary-button type="submit" id="prevBtn" class="btn-coul3 me-2">
                <span class="bi bi-chevron-left me-0"></span>
                <span class="">Précédent</span>
            </x-secondary-button>
        @endif

        <x-secondary-button id="cancelBtn" class="btn-coul3" onclick="confirmCancel()">
            <span class="bi bi-x me-0"></span>
            <span class="">Annuler</span>
        </x-secondary-button>

        @if ($isMultiStep && !$isLastStep)
            <x-secondary-button type="submit" id="nextBtn" class="btn btn-outline-dark ms-2">
                <span class="">Suivant</span>
                <span class="bi bi-chevron-right me-0"></span>
            </x-secondary-button>
        @endif

        @if(!$isMultiStep || $isLastStep)
            <x-primary-button  type="submit" id="submitBtn" class="ms-2" onclick="return confirmSave()">
                <span class="bi bi-check me-0"></span>
                <span class="">Valider&nbsp;</span>
            </x-primary-button>
        @endif

        {{-- <x-secondary-button id="cancelBtn" class="btn-coul3 me-2" onclick="confirmCancel()">
            <span class="bi bi-x me-0"></span>
            <span class="">Annuler</span>
        </x-secondary-button>

        <x-primary-button id="submitBtn" class="" onclick="return confirmSave()">
            <span class="bi bi-check me-0"></span>
            <span class="">Valider&nbsp;</span>
        </x-primary-button> --}}
        
    </div>

    <script>
        //evenement direction
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');

        if(prevBtn){
            prevBtn.addEventListener('click',()=>{
                document.getElementById('form-direction').value='previous';
                // document.getElementById('curentStepForm').value="{{ $currentStep - 1 }}";
            });
        }

        if(nextBtn){
            nextBtn.addEventListener('click',()=>{
                document.getElementById('form-direction').value='next';
                // document.getElementById('curentStepForm').value="{{ $currentStep + 1 }}";
            });
        }

    </script>
    
    <script>

        function confirmSave() {
            return confirm("Êtes-vous sûr de vouloir soumettre ces données ?");
        }

        const currentUrl = "{!! request()->url() !!}".replace(/\/+$/, '');

        function confirmCancel() {

            if (confirm("Êtes-vous sûr de vouloir quitter le formulaire ?")) {
                const currentUrl = "{!! request()->url() !!}".replace(/\/+$/, '');

        const interval = setInterval(() => {
            setTimeout(() => {
                const newUrl = location.href.replace(/\/+$/, '');
                if (newUrl !== currentUrl) {
                    clearInterval(interval);
                    window.scrollTo(0, 0);
                    location.reload();
                } else {
                    history.back();
                }
            }, 100);
        }, 200);

            }
        }
    </script>  

</form>  

<script>
    document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('form');

    if (!form) return;

    form.addEventListener('submit', function (e) {
        // Affiche le loader
        if (window.mtLoader && typeof mtLoader.show === 'function') {
        mtLoader.show();
        }

        // Désactive tous les boutons de soumission
        form.querySelectorAll('button, input[type=submit]').forEach(btn => {
        btn.disabled = true;
        });
    });
    });
</script>
{{-- 
<script>
    // Fonction pour désactiver tous les boutons et liens
    document.addEventListener('DOMContentLoaded', function () {
        // Désactiver tous les boutons
        document.querySelectorAll('button').forEach(function (btn) {
            btn.disabled = true;
        });

        // Empêcher les liens d'être cliqués
        document.querySelectorAll('a').forEach(function (link) {
            link.dataset.href = link.getAttribute('href'); // stocke l'URL
            link.setAttribute('href', 'javascript:void(0)');
            link.classList.add('disabled-link');
        });
    });

    // Réactiver après chargement complet de la page
    window.addEventListener('load', function () {
        // Réactiver tous les boutons
        document.querySelectorAll('button').forEach(function (btn) {
            btn.disabled = false;
        });

        // Réactiver les liens
        document.querySelectorAll('a.disabled-link').forEach(function (link) {
            link.setAttribute('href', link.dataset.href);
            link.classList.remove('disabled-link');
        });
    });
</script> --}}


<script>
    //fonctiontions utilitaires
    
    /*--------------------------
    // isJsonString:
    Verifie si c'est une chaine json
    ----------------------*/    
    function isJsonString(str) {
        return (typeof str === "string") ? (() => {
            try {
                JSON.parse(str);
                return true;
            }
            catch {
                return false;
            }
        })() : false;
    }

    /*--------------------------
    // getValueOnPhpArray:
    cette fonction recupere la valeur d'une clé fournit dans un table php encodée en json
    ----------------------*/

    function getValueOnPhpArray(tableauJson, ...path) {
        let current = JSON.parse(tableauJson); 

        for (let key of path) {
            // Vérifier si la clé existe dans le niveau actuel
            if (current && key in current) {
                current = current[key];
            } else {
                return "Chemin non trouvé dans la structure";
            }
        }
        return current;
    }    
    /*--------------------------
    // mapArrayToIdLabel:
    cette fonction recupere un table php encodée en json, avec un index et retourne un tableau javascript au format: [{id:id, labe:label}]
    ----------------------*/

    function mapArrayToIdLabel(tableauJson, index) {
        let tableauDecode = isJsonString(tableauJson)? JSON.parse(tableauJson)[index] : tableauJson;  
        let tableauFinal=tableauDecode.map(item => {
            const key=Object.keys(item)[0];
            const value=item[key];
            return {id: parseInt(key),
            label: value}
        });
        return tableauFinal;
    }

    /*--------------------------
    // updateSelectField:
    cette fonction sert à mettre à jour un champ select
    ----------------------*/
    function updateSelectField(selectId, optionsArray) {
        const selectFied=document.getElementById(selectId);

        selectFied.innerHTML='' //supprime toute les données

        //ajout de l'option par defaut
        const defaultOption=document.createElement('option');
        defaultOption.text='Aucun(e)';
        defaultOption.value='';
        selectFied.appendChild(defaultOption);

        //ajout des autres options
        optionsArray.forEach(item =>{
            const option=document.createElement('option');
            option.value=item.id
            option.text=`${item.label}`;
            selectFied.appendChild(option);
        });
    }

    /*--------------------------
    // updateCheckboxes:
    cette fonction sert à mettre à jour un champ container de checkbox
    ----------------------*/
    function updateCheckboxes(containerId, items) {
        let container=document.getElementById(containerId);

        container.innerHTML='' //supprime toute les données

        //ajout des autres options
        items.forEach(item =>{
            let checkboxDiv=document.createElement('div');
            checkboxDiv.classeName='form-check';

            let checkbox=document.createElement('input');
            checkbox.type='checkbox';
            checkbox.id=`checkbox_${item.id}`;
            checkbox.value=item.id;
            checkbox.name=`${containerId}[]`;
            checkbox.classList.add('form-check-input');

            let label=document.createElement('label');
            label.htmlFor=checkbox.id;
            label.textContent=item.label;
            label.classList.add('form-check-label')
            label.classList.add('ms-1')
            
            checkboxDiv.appendChild(checkbox);
            checkboxDiv.appendChild(label);
            container.appendChild(checkboxDiv);
        });
    }
</script>

<script>
    //reactualisation de l'apercu de l'image
    let imagePreview=document.getElementById('imagePreview')?? null;
    let inputImage=document.getElementById('inputImage')?? null;

    if (imagePreview != null && inputImage != null) {
        inputImage.addEventListener('change', function(event){
            var file=event.target.files[0];
            var reader=new FileReader();
            reader.onload=function(event){
                imagePreview.src=event.target.result;
            };
            reader.readAsDataURL(file);
        });
        
    }

    //reactualisation de l'apercu de la video
    if (document.getElementById('inputVideo')) {
        document.getElementById('inputVideo').addEventListener('change', function(event) {
            const videoInput = event.target;
            const videoDisplay = document.getElementById('videoPreview');

            if (videoInput.files.length === 0) {
                alert('Please select a video file.');
                return;
            }

            const videoFile = videoInput.files[0];
            const videoURL = URL.createObjectURL(videoFile);

            videoDisplay.innerHTML = ''; // Clear any existing video
            const videoElement = document.createElement('video');
            videoElement.src = videoURL;
            videoElement.controls = true;
            videoDisplay.appendChild(videoElement);
        });
        
    }
    

</script>

<script>
    //script pour la compression des fichier
    document.addEventListener("DOMContentLoaded", function () {
        const imageInput = document.getElementById("inputImage")?? null;

        if (imageInput != null) {
            imageInput.addEventListener("change", function () {
                const file = imageInput.files[0];

                const reader = new FileReader();
                reader.onload = function (event) {
                    const img = new Image();
                    img.src = event.target.result;

                    img.onload = function () {
                        // Définir la largeur et la hauteur de la nouvelle image (par exemple, 800x600)
                        const maxWidth = 5184;
                        const maxHeight = 3888;
                        let width = img.width;
                        let height = img.height;

                        // Calculer les nouvelles dimensions en respectant les proportions
                        if (width > height) {
                            if (width > maxWidth) {
                                height *= maxWidth / width;
                                width = maxWidth;
                            }
                        } else {
                            if (height > maxHeight) {
                                width *= maxHeight / height;
                                height = maxHeight;
                            }
                        }

                        // Créer un canvas pour dessiner l'image compressée
                        const canvas = document.createElement("canvas");
                        canvas.width = width;
                        canvas.height = height;
                        const ctx = canvas.getContext("2d");
                        ctx.drawImage(img, 0, 0, width, height);

                        // Convertir le canvas en image compressée
                        canvas.toBlob(function (blob) {
                            // Créer un nouvel objet File pour l'image compressée
                            const compressedFile = new File([blob], file.name, {
                                type: file.type,
                                lastModified: Date.now()
                            });

                            // Créer un DataTransfer pour remplacer l'image d'origine
                            const dataTransfer = new DataTransfer();
                            dataTransfer.items.add(compressedFile);

                            // Remplacer le fichier dans le champ de l'image
                            imageInput.files = dataTransfer.files;

                            // Message d'information
                            // alert("L'image a été compressée avec succès. Vous pouvez maintenant soumettre le formulaire.");
                        }, file.type, 0.7); // 0.7 est la qualité de compression (70%)
                    };
                };

                reader.readAsDataURL(file);
            });            
        }
    });
</script>
