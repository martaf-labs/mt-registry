<div class="container px-0 py-2 py-lg-4">
    
    <div class="container-fluid d-flex flex-row flex-nowrap justify-content-between align-items-start px-0">

        @if(isset($titre) && strlen($titre) > 0)
            <h6 class="d-none d-lg-block opacity-75 fg-coul1 fw-bold fs-6">
                <span class="container-fluid d-flex flex-row flex-nowrap justify-content-between">
                    @isset($icone)
                        <span class="{{ $icone }} fg-coul1"><span class="">{!! $titre !!}</span></span>
                    @endisset
                    {{-- <span class="d-block bi bi-chevron-compact-right"></span> --}}
                </span>
            </h6>
            <h6 class="d-lg-none opacity-75 fg-coul1 fw-bold fs-90">
                <span class="container-fluid d-flex flex-row flex-nowrap justify-content-between">
                    @isset($icone)
                        <span class="{{ $icone }} fg-coul1"><span class="">{!! $titre !!}</span></span>
                    @endisset
                    {{-- <span class="d-block bi bi-chevron-compact-right"></span> --}}
                </span>
            </h6>
        @endif

        {{-- bouton d'options (optionnel) --}}
        @if (isset($options) && count($options)>0)
            <div class="dropdown w-auto"> 
                <a href="#" class="bg-none lnk-coul1 px-0 pe-2 py-0 px-lg-3 py-lg-1 fs-6" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    {{-- <span class="d-none d-lg-inline-block">Options</span> --}}
                    <span class="bi bi-three-dots"></span>
                </a>
                <div class="dropdown-menu border-0 shadow-lg">
                    @foreach ($options as $option)
                        <a class="nav-item nav-link text-center fs-4" href="{{ $option['lien'] }}">
                            <span class="{{ $option['icone'] }} d-block"></span>
                            <span class="d-block fs-60">{{ $option['label'] }}</span>
                        </a>
                    @endforeach
                </div>
            </div>
        @endif

    </div>
    
    <div class="container-lg">
        {{ $slot }}
    </div>
</div> 