<div {{ $attributes->merge(['id' => $id,'class' => 'container-fluid my-3 px-3 px-lg-4 py-4 rounded-5 shadow-sm']) }}>
    
    @isset($titre)
        <h6 class="fw-bold d-lg-flex flex-row flex-nowrap justify-content-start align-items-center">
            @isset($icone)
                <x-circle-item :icone="$icone" :titre="$titre"></x-circle-item>
            @endisset
        </h6>
    @endisset

    {{ $slot }}
    
</div>