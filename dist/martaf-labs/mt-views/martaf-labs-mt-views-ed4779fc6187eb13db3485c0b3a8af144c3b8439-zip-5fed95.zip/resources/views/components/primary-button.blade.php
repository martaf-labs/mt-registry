<button {{ $attributes->merge(['type' => 'submit', 'class' => 'btn-l-gradient-coul1 border-0 px-2 py-1 px-md-4 py-md-2 rounded-pill']) }}>
    {{ $slot }}
</button>
