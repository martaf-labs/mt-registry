<div class="modal fade" id="{{ $modalId }}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="{{ $modalId }}label" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content mtzoom-in">
            <div class="modal-header border-0 d-flex flex-row flex-nowrap justify-content-between align-items-center py-2">
                <h6 class="modal-title" id="{{ $modalId }}">{{ $modalTitle }}</h6>
            </div>
            <div class="modal-body row row-cols-1 border-0">
                <div class="col">
                    {{ $slot }}
                </div>
            </div>
            <div class="modal-footer border-0 py-1">
                <button type="button" class="btn btn-primary rounded-pill fs-90" id=""  data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>