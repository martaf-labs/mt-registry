<button {{ $attributes->merge(['type' => 'reset', 'class' => 'btn-coul3 border-0 px-4 py-1 rounded-pill']) }}>
    {{ $slot }}
</button>
