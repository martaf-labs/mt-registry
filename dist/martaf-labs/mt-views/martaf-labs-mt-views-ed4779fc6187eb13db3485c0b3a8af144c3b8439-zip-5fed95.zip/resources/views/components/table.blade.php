@props(['jsonParams'])

@php
    // Décodage des paramètres JSON passés au composant
    $params = json_decode($jsonParams, true);
    $tabType = $params['tabType'] ?? '';
    $tabDatas = $params['tabDatas'] ?? [];
    $filtres = $params['filtres'] ?? [];
    $datafiltres = $params['datafiltres'] ?? [];
@endphp

<x-filtre :filters="$filtres">
    
    <!-- Conteneur des résultats filtrés, initialement vide -->
    <div id="resultats" class="row @if(in_array($params['tabType'], ['image','video','annonce'])) row-cols-1 row-cols-md-2 row-cols-lg-4 @else row-cols-1 row-cols-lg-2 @endif px-2 mb-2" data-tab-datas='@json($tabDatas)' data-tab-type='@json($tabType)' data-filtres='@json($datafiltres)'>
        <!--les elements du tableau generer par le js s'affichent ici-->
    </div>


</x-filtre>
