{{--
    -------- search-form ----------
    Ce composant sert à inserer un modal de recherche dans le programme.
    Il peut etre inserer à plusieur endroit du meme programme.

    **code d'appel, exemple:
    <x-search-form :searchItems="$searchItems" display="center" searchButtonEnabled="true"></x-search-form>
    
    *-le code ci dessus doit etre inserer après le bouton ou le lien d'appel de la recherche
    *-ajouter la classe "mt-search-button" au bouton ou au lien de recherche
    *-les parametre du composant:
        -searchItems: represente le tableau contenant les données de la recherche; la structure est la suivante:
        
        $searchItems = [
            [
                "position" => "One"
                "label" => "Engins"
                "datas" => [
                    [
                        "titre" => "Tracteur Mercedes 3341",
                        "image" => "https://db.sgni-tchad.com/storage/enginUploads/xkEh2sIMoSslvYwKfp4EKOpDm9Olbi9cLeh7930i.jpg",
                        "lien" => "http://sgni-site-v02.test/engins/tracteur-mercedes-3341-16"
                    ]
                ]
            ]
        ];

    - exemple de mise en place du tableau de données
        $searchItems=[];

        // ajout des engins
        $searchItems['engin']=[
            'position' => 'One',  //two, three, four, five, etc.
            'label' => 'Engins',
            'datas' => [],
        ];
        
        $searchItems=array_values($searchItems);
--}}

@php
    $searchItems=$searchItems?? [];
    $searchButtonEnabled=$searchButtonEnabled?? false;
    // $searchMode=$searchItems?? 'sm';
    $display=$display?? 'left';
@endphp

@if ($searchButtonEnabled == false)
    <!-- Bouton pour ouvrir l'Off-Canvas -->
    <a type="button" id="buttonSmSearch" class="mt-search-button me-2" @if($display === 'center') data-bs-toggle="modal" @else  data-bs-toggle="offcanvas" @endif data-bs-target="#searchFrame" aria-controls="searchFrame">
        <div class="d-none d-lg-block" style="width:45px">
            <div class="square rounded-circle bg-coul4 fg-coul1">
                <span class="square-content rounded-circle bi bi-search"></span>
            </div>
        </div>
        <div class="d-lg-none" style="width:35px">
            <div class="square rounded-circle bg-coul4 fg-coul1">
                <span class="square-content rounded-circle bi bi-search"></span>
            </div>
        </div>
    </a>
@endif

@if ($display === 'center')
    <div class="modal fade" id="searchFrame" tabindex="-1" aria-labelledby="searchFrameLabel" aria-hidden="true"  data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
            <div class="modal-content mtzoom-in">
                <div class="modal-header border-0 pt-2 pb-1 d-flex flex-column align-items-start">
                    {{-- <h6 class="modal-title" id="searchFrameLabel">Recherche...</h6> --}}
                    <!-- Menu Bar -->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="position: absolute;top:15px;right:15px"></button>
                    <div class="container d-flex justify-content-between align-items-center my-2 px-1 px-lg-2">
                        <!-- Champ de recherche -->
                        <input type="text" id="searchInput" class="form-control border-0 border-bottom" placeholder="Tapez votre recherche..." style="border-radius: 0%; background-color:transparent;box-shadow:0 0 0 transparent;">
                    </div>
                </div>
                <div class="modal-body border-0 py-0" style="height: 75vh;overflow-y:auto">
                    <div class="accordion" id="resultsContainer" style="height:100%">
                    </div>
                </div>
                <div class="modal-footer border-0 py-1">
                </div>
            </div>
        </div>
    </div>
@else
    <!-- OffCanvas de recherche -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="searchFrame" aria-labelledby="searchFrameLabel">
        <div class="offcanvas-header">
            <!-- Champ de recherche -->
            <input type="text" id="searchInput" class="form-control custom-input rounded-pill me-5" placeholder="Rechercher...">
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">        
            <div class="accordion" id="resultsContainer">
            </div>
        </div>
    </div>
@endif

<script>
    
    // Liste des éléments à rechercher
    const searchItems = @json($searchItems);
    let searchCount=0;
    const resultsContainer = document.getElementById("resultsContainer");
    //reconfiguration du bouton de recherche si l'id est fournit
    const searchButtons=document.querySelectorAll('.mt-search-button')?? null;

    if (searchButtons != null) {
        searchButtons.forEach( button =>{
            button.setAttribute('id', 'buttonSmSearch');
            button.setAttribute('data-bs-toggle', 'modal');
            button.setAttribute('data-bs-target', '#searchFrame');
            button.setAttribute('aria-controls', 'searchFrame');
        });
        
    }

    document.addEventListener('DOMContentLoaded', function () {
        searchCount === 0? showLoadSearch() : '';
    });
    
    function showNoResult() {
        //affichage en cas de recherche vide
        const containerNull = createElement('div', {
            classes: ['container','d-flex', 'flex-column', 'justify-content-center', 'align-items-center', 'px-2', 'py-4'],
            attributes: {
                'style': 'height:100%'
            },
            parent: resultsContainer
        });
        const containerNullSpan = createElement('span', {
            classes: ['bi','bi-cloud-slash', 'opacity-50'],
            attributes: {
                'style': 'font-size:500%'
            },
            parent: containerNull
        });
        const containerNullSpanP = createElement('p', {
            text: "Aucun élément trouvé...",
            classes: ['opacity-50'],
            parent: containerNull
        });
    }
    
    function showLoadSearch() {
        //affichage à l'ouverture de la recherhe
        const containerNull = createElement('div', {
            classes: ['container','d-flex', 'flex-column', 'justify-content-center', 'align-items-center', 'px-2', 'py-4'],
            attributes: {
                'style': 'height:100%'
            },
            parent: resultsContainer
        });
        const containerNullSpan = createElement('span', {
            classes: ['bi','bi-search', 'opacity-50'],
            attributes: {
                'style': 'font-size:500%'
            },
            parent: containerNull
        });
        const containerNullSpanP = createElement('p', {
            text: "Tapez votre recherche...",
            classes: ['opacity-50'],
            parent: containerNull
        });
    }
    
    // Fonction pour filtrer et afficher les résultats de la recherche
    document.getElementById("searchInput").addEventListener("input", function() {
        const filter = document.getElementById("searchInput").value.toUpperCase();
        // Vider les résultats précédents
        resultsContainer.innerHTML = "";

        // Si la recherche est vide, ne rien afficher
        if (!filter) {
            return;
        }

        searchItems.forEach((searchItemData, mainIndex) => {
            const dataItems=searchItemData.datas;

            // Filtrer les éléments et afficher ceux qui correspondent
            const filteredItems = dataItems.filter(item => item.titre.toUpperCase().includes(filter));

            // mise à jour du nombre de resultat
            searchCount += filteredItems.length;

            if (filteredItems.length > 0) {
                
                //initiation des element
                const accordionItem = createElement('div', {
                    classes: ['accordion-item','border-0','py-0', 'my-0'],
                    parent: resultsContainer
                });

                const accordionHeader = createElement('h3', {
                    classes: ['accordion-header','border-bottom'],
                    parent: accordionItem
                });

                
                const collapsedable= (searchItems.length === 1 && mainIndex === 0) ? 'collapsed' : 'collapsed';
                const accordionButton = createElement('button', {
                    // text:`${searchItemData.label} (${filteredItems.length})`,
                    classes: ['accordion-button',collapsedable,'p-1'],
                    attributes: {
                        'type': 'button',
                        'data-bs-toggle': `collapse`,
                        'data-bs-target': `#collapse${searchItemData.position}`,
                        'aria-expanded': 'true',
                        'aria-controls': `collapse${searchItemData.position}`,
                    },
                    parent: accordionHeader
                });

                createElement('span',{
                    text: searchItemData.label,
                    classes: ['fw-bold','fs-80'],
                    parent: accordionButton
                })

                createElement('span',{
                    text: filteredItems.length,
                    classes: ['bg-coul3', 'fg-coul4', 'rounded-pill','ms-1','py-0','px-1','fs-70'],
                    parent: accordionButton
                })

                // const showable= (searchItems.length === 1 && mainIndex === 0) ? 'show' : 'noshow'; //seul le premie element est detaché
                const showable= (mainIndex === 0) ? 'show' : 'noshow'; //seul le premie element est detaché
                const accordionCollapse = createElement('div', {
                    classes: ['accordion-collapse', 'collapse',showable],
                    attributes: {
                        'id': `collapse${searchItemData.position}`,
                        'data-bs-parent': `#resultsContainer`,
                    },
                    parent: accordionItem
                });

                const accordionBody = createElement('div', {
                    classes: ['accordion-body'],
                    parent: accordionCollapse
                });

                //conteneur principal
                const tableMainRow = createElement('div', {
                    classes: ['row','row-cols-1','row-cols-lg-4'],
                    parent: accordionBody
                });

                // Si des résultats sont trouvés, les afficher
                filteredItems.forEach((searchItem, index) => {
                    function addSearchItems() {

                        //conteneur principal de l'element
                        const tableRowCover = createElement('div', {
                            classes: ['col','my-2'],
                            parent: tableMainRow
                        });

                        //conteneur cover
                        const tableRowCoverCover= createElement('a', {
                            classes: ['p-0',],
                            attributes: {
                                    'href': searchItem.lien,
                                },
                            parent: tableRowCover
                        });

                        //conteneur secondaire
                        const bgtableRowContainer=index % 2==0 ? 'bg-coul4' : 'bg-white';
                        const tableRowContainer = createElement('div', {
                            classes: ['row','row-cols-2','row-cols-lg-1','p-0','d-flex','flex-row','flex-nowrap','flex-lg-column','flex-lg-row','align-items-center','justify-content-between','rounded-2','position-relative','hover-t-coul1'],
                            parent: tableRowCoverCover
                        });

                        //tbContainerBlockMedia
                        const tbContainerBlockMedia = createElement('div', {
                            classes: ['col-2','col-lg-12','p-0','p-lg-1'],
                            parent: tableRowContainer
                        });

                        //tbContainerBlockMediaImage
                        if (searchItem.image) {
                            const tbContainerBlockMediaImage = createElement('div', {
                                classes: ['mtblock-rect','rounded-2','m-0'],
                                attributes: {
                                    // 'data-bg': `${searchItem.image}`,
                                    'style': `background-image:url(${searchItem.image})`,
                                },
                                parent: tbContainerBlockMedia
                            });
                            
                        }

                        //tbContainerBlockMediaVideo
                        if (searchItem.video) {
                            const tbContainerBlockMediaVideo = createElement('div', {
                                classes: ['container-fluid','video-container','rounded-circle'],
                                attributes: {
                                },
                                parent: tbContainerBlockMedia
                            });

                            const tbContainerBlockMediaVideoContent = createElement('video', {
                                classes: ['rounded-circle'],
                                attributes: {
                                    'autoplay':true,
                                    'muted':true
                                },
                                parent: tbContainerBlockMediaVideo
                            });

                            const tbContainerBlockMediaVideoContentSource = createElement('source', {
                                classes: [],
                                attributes: {
                                    'src':searchItem.video,
                                },
                                parent: tbContainerBlockMediaVideoContent
                            });
                            
                        }

                        //tbContainerBlockMediaIcon
                        if (searchItem.icon) {

                            const tbContainerBlockMediaIcon = createElement('div', {
                                classes: ['col-1','square'],
                                attributes: {
                                },
                                parent: tbContainerBlockMedia
                            });

                            const classeItem = ['square-content','bg-white','rounded-circle','text-center','border'];
                            const classeIcon = searchItem.icon.split(" ");

                            const tbContainerBlockMediaIconContend = createElement('span', {
                                classes: classeItem.concat(classeIcon) ,
                                attributes: {
                                    'style':'font-size: 150%; font-weight:normal'
                                },
                                parent: tbContainerBlockMediaIcon
                            });
                            
                        }

                        //tbContainerBlockMediaLetter
                        if (searchItem.letter) {
                            const tbContainerBlockMediaLetter = createElement('div', {
                                classes: ['col-1','square'],
                                attributes: {
                                },
                                parent: tbContainerBlockMedia
                            });

                            const tbContainerBlockMediaLetterContend = createElement('span', {
                                text: searchItem.letter,
                                classes: ['square-content','bg-white','rounded-circle','text-uppercase','text-center','border'],
                                attributes: {
                                    'style':'font-size: 150%; font-weight:normal'
                                },
                                parent: tbContainerBlockMediaLetter
                            });
                            
                        }

                        //tbContainerBlockTitre
                        const tbContainerBlockTitre = createElement('div', {
                            classes: ['col-10','col-lg-12','flex-grow','d-flex','flex-column','justify-content-center'],
                            parent: tableRowContainer
                        });

                        //tbContainerBlockTitreContent
                        if (searchItem.titre) {
                            const titre=searchItem.titre.length > 60 ? searchItem.titre.substring(0, 60) + "..." : searchItem.titre;
                            const tbContainerBlockTitreContent = createElement('h6', {
                                text: `${titre}`,
                                classes: ['fs-80','my-0','fg-coul1'],
                                attributes: {
                                    'style':'line-height:normal'
                                },
                                parent: tbContainerBlockTitre
                            });
                        }

                    }

                    addSearchItems();
                });
            }           
        });
        searchCount === 0? showNoResult() : '';
        searchCount=0; //on reeinitialise le compteur à chaque tour
    });
    
</script>
