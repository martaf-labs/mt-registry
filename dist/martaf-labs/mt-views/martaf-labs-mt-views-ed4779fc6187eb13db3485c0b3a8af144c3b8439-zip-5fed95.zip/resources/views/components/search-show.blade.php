@php

    $layout=getActiveLayout();//cette variable vide par defaut permet de determiner le layout en cours: app ou guest

    //variables de recherche
    $searchItems=[];
    
    if (isset($users) && count($users) > 0) {
        $userItem=[
            'label' => 'Utilisateurs',
            'icone' => getIcone('user'),
            'id' => 'users',
            'resultat' => $users,
            'resultatVideLabel' => "Aucun utilisateur trouvé",
        ];
        
        $searchItems['users']=$userItem; //ajout du tableau users
    }
    
    if (isset($categories) && count($categories) > 0) {
        $categorieItem=[
            'label' => 'Categories',
            'icone' => getIcone('categorie'),
            'id' => 'categories',
            'resultat' => $categories,
            'resultatVideLabel' => "Aucune categorie trouvée",
        ];
        
        $searchItems['categories']=$categorieItem; //ajout du tableau categories
    }
    
    if (isset($caracteristiques) && count($caracteristiques) > 0) {
        $caracteristiqueItem=[
            'label' => 'Caractéristiques',
            'icone' => getIcone('caracteristique'),
            'id' => 'caracteristiques',
            'resultat' => $caracteristiques,
            'resultatVideLabel' => "Aucune caractéristique trouvée",
        ];
        
        $searchItems['caracteristiques']=$caracteristiqueItem; //ajout du tableau caracteristiques
    }
    
    if (isset($engins) && count($engins) > 0) {
        $enginItem=[
            'label' => 'Engins',
            'icone' => getIcone('engin'),
            'id' => 'engins',
            'resultat' => $engins,
            'resultatVideLabel' => "Aucun engin trouvé",
        ];
        
        $searchItems['engins']=$enginItem; //ajout du tableau engins
    }
    
    if (isset($realisations) && count($realisations) > 0) {
        $realisationItem=[
            'label' => 'Réalisations',
            'icone' => getIcone('realisation'),
            'id' => 'realisations',
            'resultat' => $realisations,
            'resultatVideLabel' => "Aucune realisation trouvée",
        ];
        
        $searchItems['realisations']=$realisationItem; //ajout du tableau realisations
    }
    
    if (isset($videos) && count($videos) > 0) {
        $videoItem=[
            'label' => 'Vidéos',
            'icone' => getIcone('video'),
            'id' => 'videos',
            'resultat' => $videos,
            'resultatVideLabel' => "Aucune vidéo trouvée",
        ];
        
        $searchItems['videos']=$videoItem; //ajout du tableau videos
    }
    
    if (isset($images) && count($images) > 0) {
        $imageItem=[
            'label' => 'Images',
            'icone' => getIcone('image'),
            'id' => 'images',
            'resultat' => $images,
            'resultatVideLabel' => "Aucune image trouvée",
        ];
        
        $searchItems['images']=$imageItem; //ajout du tableau images
    }

@endphp

<div class="row row-cols-1 d-flex flex-column flex-nowrap justify-content-start align-items-center">         
    <div class="col">
        <nav class="w-100 scroll-container">
            <div class="nav nav-tabs mb-0 border-0 border-bottom content-wrapper d-inline-block px-2 px-lg-0" id="nav-tab" role="tablist">

                @foreach ($searchItems as $searchItem)
                    <button class="nav-link @if($loop->first) active @endif border-0 bg-none fs-80 d-inline-block px-1 w-auto" id="nav-{{ $searchItem['id'] }}-tab" data-bs-toggle="tab" data-bs-target="#{{ $searchItem['id'] }}" type="button" role="tab" aria-controls="nav-{{ $searchItem['id'] }}" aria-selected="true">
                        <span class="{{ $searchItem['icone'] }}"></span>
                        <span class="">{{ $searchItem['label'] }}</span>
                        <span class="badge bg-coul3 rounded-pill fw-normal ms-1">{{ addZero(count($searchItem['resultat'])) }}</span>
                    </button>
                @endforeach
                
            </div>
        </nav>
        <div class="tab-content mt-0 py-3 px-0 bg-coul4-0" id="nav-tabContent">
        
            @foreach ($searchItems as $searchItem)
                <div class="tab-pane fade @if($loop->first) show active @endif" id="{{ $searchItem['id'] }}" role="tabpanel" aria-labelledby="nav-{{ $searchItem['id'] }}-tab"> 
                    @if (count($searchItem['resultat'])>0)
                        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 d-flex flex-row justify-content-start align-items-start">

                            @if ($searchItem['id']=='users')
                                @foreach ($searchItem['resultat'] as $resultat)
                                @php
                                    $itemRoute=getRoute('users_show',['user'=>$resultat->id]);
                                @endphp
                                    <x-block-item :user="$resultat" :route="$itemRoute"></x-block-item>
                                @endforeach
                            @endif

                            @if ($searchItem['id']=='categories')
                                @foreach ($searchItem['resultat'] as $resultat)
                                @php
                                    $itemRoute=getRoute('categories_show',['categorie'=>$resultat->id]);
                                @endphp
                                    <x-block-item :categorie="$resultat" :route="$itemRoute"></x-block-item>
                                @endforeach
                            @endif

                            @if ($searchItem['id']=='engins')
                                @foreach ($searchItem['resultat'] as $resultat)
                                @php
                                    $itemRoute=($layout=='app') ? getRoute('engins_show',['engin'=>$resultat->id]) : getRoute('guest_engins_show',['slug'=>$resultat->slug, 'engin'=>$resultat->id]);
                                @endphp
                                    <div class="col my-2">
                                        <x-block-item :engin="$resultat" :route="$itemRoute" :markedTerm="$query"></x-block-item>
                                    </div>
                                @endforeach
                            @endif

                            @if ($searchItem['id']=='caracteristiques')
                                @foreach ($searchItem['resultat'] as $resultat)
                                @php
                                    $itemRoute=getRoute('caracteristiques_show',['caracteristique'=>$resultat->id]);
                                @endphp
                                    <x-block-item :caracteristique="$resultat" :route="$itemRoute"></x-block-item>
                                @endforeach
                            @endif

                            @if ($searchItem['id']=='realisations')
                                @foreach ($searchItem['resultat'] as $resultat)
                                @php
                                    $itemRoute=($layout=='app') ? getRoute('realisations_show',['realisation'=>$resultat->id]) : getRoute('guest_realisations_show',['slug'=>$resultat->slug, 'realisation'=>$resultat->id]);
                                @endphp
                                    <x-block-item :realisation="$resultat" :route="$itemRoute"></x-block-item>
                                @endforeach
                            @endif

                            @if ($searchItem['id']=='videos')
                                @foreach ($searchItem['resultat'] as $resultat)
                                @php
                                    $itemRoute=($layout=='app') ? getRoute('videos_show',['video'=>$resultat->id]) : getRoute('guest_videos_show',['slug'=>$resultat->slug, 'video'=>$resultat->id]);
                                @endphp
                                    <x-block-item :video="$resultat" :route="$itemRoute"></x-block-item>
                                @endforeach
                            @endif

                            @if ($searchItem['id']=='images')
                                @foreach ($searchItem['resultat'] as $resultat)
                                @php
                                    $itemRoute=getRoute('images_show',['image'=>$resultat->id]);
                                @endphp
                                    <x-block-item :image="$resultat" :route="$itemRoute" :markedTerm="$query"></x-block-item>
                                @endforeach
                            @endif
                            
                        </div>   
                        
                        <div class="container ms-0 me-auto mt-2">
                            {{-- @if ($searchItem['id']=='users')
                                {{ $users->links() }}
                            @endif --}}
                            {{-- @if ($searchItem['id']=='categories')
                                {{ $categories->links() }}
                            @endif
                            @if ($searchItem['id']=='engins')
                                {{ $engins->links() }}
                            @endif
                            @if ($searchItem['id']=='caracteristiques')
                                {{ $caracteristiques->links() }}
                            @endif
                            @if ($searchItem['id']=='realisations')
                                {{ $realisations->links() }}
                            @endif
                            @if ($searchItem['id']=='videos')
                                {{ $videos->links() }}
                            @endif
                            @if ($searchItem['id']=='images')
                                {{ $images->links() }}
                            @endif --}}
                        </div>
                    
                    @else
                        <div class="container d-flex flex-column justify-content-center align-items-center py-4 opacity-25">
                            <span class="{{ $searchItem['icone'] }}" style="font-size: 600%"></span>
                            <span class="">{{ $searchItem['resultatVideLabel'] }}...</span>
                        </div>
                    @endif      
                    
                </div>
            @endforeach

        </div>
    </div>


</div> 