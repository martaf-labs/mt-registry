{{--
    -------- notifications-modal ----------
    Ce composant sert à afficher et gerer les notifications des utilisateurs.

    **code d'appel, exemple:
    <x-notifications-modal display="center" notificationButtonEnabled="true"></x-notifications-modal>
    
    *-le code ci dessus doit etre inserer après le bouton ou le lien d'appel des notifications
    *-ajouter la classe "mt-notifications-button" au bouton ou au lien de notifications
    *-les parametres du composant:
--}}

@php
    //traintement des variables
    $user=auth()->user();
    $allNotifications=$user->notifications;
    $unreadNotifications=$user->unreadNotifications;
    $allNotificationsCount=count($allNotifications);
    $unreadNotificationsCount=count($unreadNotifications);
    $notificationButtonEnabled=$notificationButtonEnabled?? false;
    $display=$display?? 'left';
@endphp

@if ($notificationButtonEnabled == false)
    <!-- Bouton pour ouvrir l'Off-Canvas -->
    <a type="button" id="buttonSmNotification" class="mt-notifications-button me-2" @if($display === 'center') data-bs-toggle="modal" @else  data-bs-toggle="offcanvas" @endif data-bs-target="#notificationFrame" aria-controls="notificationFrame">
        <div class="d-none d-lg-block" style="width:45px">
            <div class="square rounded-circle bg-coul4 fg-coul1">
                <span class="square-content rounded-circle {{ getIcone('notification') }}"></span>
            </div>
        </div>
        <div class="d-lg-none" style="width:35px">
            <div class="square rounded-circle bg-coul4 fg-coul1">
                <span class="square-content rounded-circle {{ getIcone('notification') }}"></span>
            </div>
        </div>
    </a>
@endif

<div class="modal fade" id="notificationFrame" tabindex="-1" aria-labelledby="notificationFrameLabel" aria-hidden="true"  data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-md">
        <div class="modal-content mtzoom-in border-0">
            <div class="modal-header border-0 pt-2 pb-1 d-flex flex-column align-items-start bg-coul1">
                <h6 class="modal-title fw-bold py-1 fs-80 text-light text-uppercase" id="notificationFrameLabel">
                    <i class="{{ getIcone('notification') }} me-1"></i>
                    <span>{{ __('Notifications') }} (<span class="notifications-count-label">{{ addZero(auth()->user()->notifications->count()) }}</span>)</span>
                </h6>
                <button type="button" class="btn-close btn-close-white fs-80" data-bs-dismiss="modal" aria-label="Close" style="position: absolute;top:15px;right:15px;"></button>
            </div>
            <div class="modal-body border-0 py-2 overflow-hidden">
                
                <!-- Menu Bar -->
                <div class="container-fluid d-flex flex-row flex-nowrap justify-content-end align-items-start mb-2">
                    {{-- <button class="btn btn-outline-primary btn-sm fs-70" id="markAllReadBtn">{{ __('Toutes lues') }}</button> --}}
                </div>

                <div class="container-fluid scrollbar-hidden py-2 position-relative" style="height: 75vh;overflow-y:auto">
                
                    <!--loader -->
                    <div id="notificationLoader" class="position-absolute w-100 h-100 top-0 start-0 d-flex flex-column justify-content-center align-items-center" style="">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                    <div id="notification-list" class="container-fluid mx-auto row row-cols-1 d-flex flex-column justify-content-start align-items-start">

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>



<style>
    .notification-items:hover p {
        font-weight: 600;
        transition: all .3s ease-in-out;
    }
    .notification-items:hover{
        background-color: var(--tcoul1_0) !important;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        transition: all .2s ease-in-out;
    }
</style>


<script>
    
    document.addEventListener('DOMContentLoaded', async function(){

        let loader=document.getElementById("notificationLoader");
        let notificationsCountLabel=document.querySelectorAll('.notifications-count-label');

        async function displayNotifications() {

            loader.classList.remove('d-none');

            const notificationList = document.getElementById('notification-list'); 
            notificationList.innerHTML = '';
            
            // D'abord, on récupère le cookie CSRF de Sanctum
            await fetch('/sanctum/csrf-cookie', {credentials:'include'});

            //    Maintenant, on va lancer la demande des notifications
            try {
                const res = await fetch('/api/notifications', {credentials:'include'})
                if (!res.ok) {
                    console.error('Erreur!', res);
                    const text = await res.text();
                    return;
                }
                const data = await res.json();
                const notifications=data.notifications; 
                
                //mise à jour des labels de notification
                notificationsCountLabel.forEach(function(item){
                    item.textContent=addZero(notifications.length);
                });

                if(notifications.length > 0 )
                    notifications.forEach((notification) => {
                        // initialitaion des variables
                        const title=notification.data.title;
                        const message=notification.data.message;
                        const image=notification.data.image ?? "{{ asset('images/placeholder-user.jpg') }}";
                        const time=tempsEcoule(notification.created_at);
                        const isRead=notification.read_at == null ? false : true;

                        // Création de la ligne row
                        let notificationContainer = createElement('div', {
                            classes: ['col','notification-items','px-0','py-2','my-1','rounded-2', 'align-items-center', !isRead ? 'bg-t-coul1' : ''],
                            parent: notificationList
                        });

                        const notificationBody = createElement('div', {
                            classes: ['container-fluid','d-flex','flex-row','flex-nowrap', 'align-items-start', 'justify-content-start'],
                            parent: notificationContainer
                        });
                            // bodyBlockImg
                            const bodyBlockImg = createElement('div', {
                                classes: ['col-1'],
                                parent: notificationBody
                            });

                            const bodyBlockImgContent = createElement('div', {
                                classes: ['mtblock-sqr','rounded-pill'],
                                attributes: {
                                    style: `background-image: url('${image}')`
                                },
                                parent: bodyBlockImg
                            });

                        // bodyBlockText
                        const bodyBlockText = createElement('div', {
                            classes: ['col-10','flex-grow-1','d-flex','flex-column','align-items-start', 'justify-content-start'],
                            parent: notificationBody
                        });
                        const bodyBlockTextContent = createElement('p', {
                            classes: ['ps-2','text-start','m-0'],
                            attributes: {
                                style: 'font-size: 80%;'
                            },
                            parent: bodyBlockText
                        });
                        bodyBlockTextContent.innerHTML=message;

                        // block options
                        const bodyBlockTextOptions = createElement('div', {
                            classes: ['container','flex-grow-1','d-flex','flex-row','flex-nowrap','align-items-start', 'justify-content-end'],
                            parent: bodyBlockText
                        });

                        const timeElement = createElement('span', {
                            text: `il y a ${time}`,
                            classes: ['mx-1','text-muted','d-inline-block','align-self-start'],
                            attributes: { style: 'font-size:60%;' },
                            parent: bodyBlockTextOptions
                        });

                        //markAsReadLinkElement
                        if (!isRead) {
                            const markAsReadLinkElement = createElement('a', {
                                text: `Marquer comme lue`,
                                classes: ['mx-1','link','link-primary'],
                                attributes: { style: 'font-size:60%;cursor:pointer' },
                                events: {
                                    click: async function(){
                                        markAsReadNotifications([notification.id]);
                                        displayNotifications()
                                    }
                                },
                                parent: bodyBlockTextOptions
                            });
                        }

                        //deleteLinkElement
                        const deleteLinkElement = createElement('a', {
                            text: `Supprimer`,
                            classes: ['link','link-danger'],
                            attributes: { style: 'font-size:60%;cursor:pointer' },
                            events: {
                                click: async function(){
                                    deleteNotifications([notification.id]);
                                    displayNotifications()
                                }
                            },
                            parent: bodyBlockTextOptions
                        });

                    });
                else{
                    loader.classList.add('d-none');
                    showEmptyNotifications();
                }
            }
            catch (err) {
                console.error(err);
            }
            finally {
                //cacher le loader
                loader.classList.add('d-none');
            }

        }

        //fonction de la page no result
        function showEmptyNotifications() {

            const notificationList = document.getElementById('notification-list'); 
            notificationList.innerHTML = '';
            notificationList.classList.add('h-100');

            // block empty
            const blockEmpty = createElement('div', {
                classes: ['w-100','h-100','d-flex','flex-column','align-items-center', 'justify-content-center'],
                parent: notificationList
            });

            // block empty label
            const blockEmptyLabel = createElement('div', {
                classes: ['d-flex','flex-column','align-items-center', 'justify-content-center'],
                parent: blockEmpty
            });

            // block empty label icone
            let iconeNotif="{{ getIcone('notification-empty') }}".split(" ");
            let othersClasse=['d-block','text-secondary'];
            const blockEmptyLabelIcone = createElement('i', {
                classes: othersClasse.concat(iconeNotif) ,
                attributes: {
                    style: "font-size:800%;"
                },
                parent: blockEmpty
            });

            // block empty label text
            const blockEmptyLabelText = createElement('span', {
                text:"Aucune notification...",
                classes: ['d-block','text-secondary'],
                attributes: {
                    style: "font-size:80%;"
                },
                parent: blockEmpty
            });

        }

        displayNotifications();//lancement de l'affichage des element

        //reactualisation de l'affichage des element apres 60 s
        setInterval(() => {
            displayNotifications();
        }, 120000);
        
    });


</script>




<script>
    
    //reconfiguration du bouton de recherche si l'id est fournit
    const notificationButtons=document.querySelectorAll('.mt-notifications-button')?? null;

    if (notificationButtons != null) {
        notificationButtons.forEach( button =>{
            button.setAttribute('id', 'buttonSmNotification');
            button.setAttribute('data-bs-toggle', 'modal');
            button.setAttribute('data-bs-target', '#notificationFrame');
            button.setAttribute('aria-controls', 'notificationFrame');
        });
        
    }

</script>
