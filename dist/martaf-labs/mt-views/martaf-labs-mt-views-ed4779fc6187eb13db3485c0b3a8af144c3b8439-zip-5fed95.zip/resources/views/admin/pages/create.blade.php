@if (isset($model))

    @php
        //initialisation des variables
        $titre= $titre ?? '';
        $model= $model ?? '';
        $navItems = $navItems ?? null;
        $mode= $mode ?? 'create';
        $data = $data ?? [];
        $formDatas = $formDatas ?? [];
        $icone= getIcone($model);
        $params= $params?? [];

        $action= (Route::has('admin.'.Str::plural($model).'.store') ) ? getRoute(Str::plural($model).'_store',$params): null;

    @endphp

    <x-app-layout :titre="$titre" :icone="$icone" :navItems="$navItems">
        <div class="row row-cols-1 row-cols-lg-2">
            
            <div class="col col-lg-8">
                <x-section-page>

                    <div class="container p-2 bg-t-coul4">
                        {{-- <x-form :jsonParams="$jsonParams" mode="create" > </x-form> --}}
                        <x-form :formDatas="$formDatas" :mode="$mode" :action="$action" > </x-form>
                    </div>

                </x-section-page>
            </div>
        </div>

    </x-app-layout>
@else

    {{-- rediriger vers la page d'accueil --}}
    <script>
        window.location.href="{{ getRoute('admin') }}";
    </script>

@endif

