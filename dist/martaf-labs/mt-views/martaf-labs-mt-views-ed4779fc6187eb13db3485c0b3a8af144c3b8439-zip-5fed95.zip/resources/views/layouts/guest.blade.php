
<!doctype html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Site web de la société SGNI TCHAD, version 2.0">
        <meta name="author" content="Djoukeng Brice Marcello pour martaf">
        <meta name="generator" content="debuté le 11 juin 2024 par Brice Marcello pour martaf à N'Djaména">	

        <meta property="og:url"           content="{{ $ogUrl }}" />
        <meta property="og:type"          content="website" />
        <meta property="og:title"         content="{{ $ogTitle }}" />
        <meta property="og:description"   content="{{ $ogDescription }}" />
        <meta property="og:image" content="{{ $ogImage }}" />
        <link rel="icon" type="image/png" href="{{ asset('vendor/mt/images/fav-icone-SGNI.jpg') }}">
    
        <title> {{ config('app.name') }} &#124; {{ strip_tags($titre) }}</title></title>
        

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjàlcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>


        <link href="{{ asset('vendor/mt/css/bootstrap.min.css') }}" rel="stylesheet">
        <link href="{{ asset('vendor/mt/css/animate.min.css') }}" rel="stylesheet">
        <link href="{{ asset('vendor/mt/assets/bootstrap-icons-1.13.1/bootstrap-icons.min.css') }}" rel="stylesheet">
        <link href="{{ mt_shared('assets/css/common.css') }}" rel="stylesheet">
        <link href="{{ asset('vendor/mt/css/app.css') }}" rel="stylesheet">
        <script src="{{ asset('vendor/mt/assets/vendor/ckeditor5/ckeditor.js') }}"></script>

    </head>

    <body class="bg-coul4 p-3 p-lg-0 m-0" style="width:100%;height:100vh;">

        <main class="container-fluid p-0 m-0" style="height:100%">
            {{ $slot }}
        </main>  
        
        <script src="{{ asset('vendor/mt/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('vendor/mt/js/app.js') }}" defer></script>
        <script src="{{ mt_shared('assets/js/common.js') }}" defer></script>

    </body>
</html>
