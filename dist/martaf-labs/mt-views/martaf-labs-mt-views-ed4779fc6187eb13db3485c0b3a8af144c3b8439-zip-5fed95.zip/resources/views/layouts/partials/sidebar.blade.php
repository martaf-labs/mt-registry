
<style>

    /* sidebar-sm */
    .sidebar-sm{
        display: block !important;
        height: 100vh !important;
        width: 100% !important;
        margin: 0px 0px !important;
        padding: 0px 0px !important;
        background: rgba(0, 0, 0, .6) !important;
        position:fixed;
        top: 0;
        left:0;
        z-index: 3000 !important;
    }
    .sidebar-sm #sideBarContainer{
        display: block !important;
        height: 100% !important;
        width: 75% !important;
        margin: 0 auto 0 0 ;
        background: var(--coul4) !important;
    }

    /* Réduction de la taille de police en mode sidebar compact */
    .sidebar-sm .sidebar-item a {
        font-size: 90%;
    }

    /* Transition fluide pour le collapse de Bootstrap */
    .collapse {
        transition: height 0.3s ease, opacity 0.3s ease;
        overflow: hidden;
    }

    /* Style pour l'élément actif ou survolé */
    .sidebar-item-active,
    .sidebar-item:hover {
        background-color: var(--coul4);
        border-left: 3px solid var(--coul1);
        box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.05);
        border-radius: 10px;
    }

    /* Style du lien dans un item actif ou survolé */
    .sidebar-item-active .sidebar-item-link,
    .sidebar-item:hover .sidebar-item-link {
        font-weight: bold;
        color: var(--coul1);
    }

    /* Apparence de la sous-liste affichée */
    .sidebar .collapse.show {
        background-color: #ffffff;
        border-radius: 10px;
        padding: 5px 0;
    }

    /* Style pour sous-items actifs ou survolés */
    .sidebar-sub-items-active,
    .sidebar-sub-items:hover {
        background-color: var(--coul4);
        font-weight: bold;
        border-radius: 6px;
    }

    /* Lien des sous-items au survol ou actif */
    .sidebar-sub-items-link:hover,
    .sidebar-sub-items-link:focus {
        color: var(--coul1);
        text-decoration: none;
    }

    /* Ajout d’un effet au clic */
    .sidebar-item-link:active,
    .sidebar-sub-items-link:active {
        opacity: 0.8;
        transform: scale(0.98);
        transition: transform 0.1s ease;
    }

</style>


<!-- Sidebar (Visible en mode large) -->
<div id="sideBar" class="sidebar col-lg-2 d-none d-lg-block position-fixed p-2" style="height: calc(100vh - 70px);margin-top:10px;">
    <div id="sideBarContainer" class="container-fluid h-100 scrollbar-hidden" style="overflow-y: scroll">

        <div class="d-flex d-lg-none flex-row justify-content-between">
            <a href="{{ getRoute('admin') }}" class="d-flex d-md-none align-items-center me-lg-auto text-white text-decoration-none text-center rounded-2">
                <img class="" src="{{ asset(config("app.logo")) }}" alt="logo {{ config("app.name") }}"  height="30" class="">
                <span class="fs-5 fg-coul1 fw-bold ms-2" translate="no">{{ config("app.name") }}</span>
            </a>
            <button type="button" class="btn-close fs-90" aria-label="Close" onclick="closeSideBar()"></button>
        </div>

        
        @php 
            $sideBarItems = getSidebar()?? null; 
        @endphp

        @if (!is_null($sideBarItems) && count($sideBarItems) > 0)
            <nav class="d-flex flex-column align-items-start justify-content-start py-2 h-100">

                @if (isset($addItems) && count($addItems)>0)
                    <div class="dropdown w-auto mb-2 d-none d-lg-none"> 
                        <a href="#" class="btn btn-coul1 px-3 py-2 rounded-pill hover-shadow" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="bi bi-plus-lg"></span>
                            <span class="ms-2">Nouveau</span>
                        </a>
                        <ul class="dropdown-menu text-small">
                            {{-- @foreach ($addItems as $addItem)
                                <li>
                                    <a class="dropdown-item" href="{{ $addItem['route'] }}">
                                        <span class="{{ $addItem['icon'] }}"></span>
                                        <span class="ms-2">{{ $addItem['label'] }}</span>
                                    </a>
                                    </li>
                            @endforeach --}}
                            </ul>
                    </div>
                @endif

                <ul class="list-unstyled flex-grow-1 w-100 py-2 py-lg-auto overflow-y-auto" id="accordionSidebar">

                    {{-- @foreach ($sideBarItems as $sideBarItem)
                        @php
                            $itemId = Str::slug($sideBarItem['label']);
                            $itemActif = $sideBarItem['isActive'] ?? false;
                            $subItems = $sideBarItem['subItems'] ?? [];
                        @endphp

                        <li class="my-2 sidebar-item @if($itemActif) sidebar-item-active @endif @if($loop->last) mt-auto @endif">
                            @if (!empty($subItems))
                                <a type="button" class="sidebar-item-link btn d-inline-flex align-items-center justify-content-between w-100 collapsed border-0 lnk-coul1"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#{{ $itemId }}-collapse"
                                    aria-expanded="{{ $itemActif ? 'true' : 'false' }}"
                                    aria-controls="{{ $itemId }}-collapse">
                                    <span class="d-inline-block">
                                        <i class="{{ $sideBarItem['icon'] }} me-2"></i> {{ $sideBarItem['label'] }}
                                    </span>
                                    <i class="fs-70 d-inline-block fg-coul1 {{ $itemActif ? 'bi bi-caret-up-fill' : 'bi bi-caret-down' }}"></i>
                                </a>
                            @else
                                <a href="{{ $sideBarItem['route'] }}" class="sidebar-item-link btn d-inline-flex align-items-center justify-content-between w-100 collapsed border-0 lnk-coul1">
                                    <span class="d-inline-block">
                                        <i class="{{ $sideBarItem['icon'] }} me-2"></i> {{ $sideBarItem['label'] }}
                                    </span>
                                    @if (isset($sideBarItem['count']))
                                        <span class="px-1 d-inline-block bg-coul3 fg-coul4 rounded-pill fs-80">{{ $sideBarItem['count'] }}</span>
                                    @endif
                                </a>
                            @endif

                            @if (!empty($subItems))
                                <ul class="list-unstyled collapse @if($itemActif) show @endif" id="{{ $itemId }}-collapse" data-bs-parent="#accordionSidebar">
                                    @foreach ($subItems as $subItem)
                                        <li class="sidebar-sub-items px-1 d-block w-100 @if($subItem['isActive'] ?? false) sidebar-sub-items-active @endif">
                                            <a href="{{ $subItem['route'] }}" class="sidebar-sub-items-link px-1 w-100 fs-85 lnk-coul3 d-inline-flex align-items-center justify-content-between">
                                                <span class="d-inline-block">{{ $subItem['label'] }}</span>
                                                @if (isset($subItem['count']))
                                                    <span class="px-1 d-inline-block bg-coul3 fg-coul4 rounded-pill fs-70">{{ $subItem['count'] }}</span>
                                                @endif
                                            </a>
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                    @endforeach --}}
                    
                </ul>


                {{-- Élément en bas de la sidebar --}}
                <div class="mt-auto w-100 d-none d-lg-block">
                    <a href="" class="lnk-coul1 w-100 d-flex align-items-center">
                        <i class="bi {{ getIcone('parametre') }} me-2"></i> Parametres
                    </a>
                </div>

            </nav>
        @endif  

        
    </div>
</div>


<!-- Bottom Navigation Bar (Visible sur mobile seulement) -->
<div id="bottombar" class="bottombar w-100 fixed-bottom d-lg-none bg-light d-flex flex-column justify-content-end" style="box-shadow: 0px -4px 3px rgba(0, 0, 0, 0.05);">

    <nav class="navbar navbar-expand navbar-light justify-self-end py-0">
        <div class="navbar-nav w-100 d-flex justify-content-around align-items-end">

            <a class="nav-item nav-link text-center lh-1" id="toggleSideBar" href="#">
                <span class="bi bi-list fs-5"></span>
                <span class="d-block fs-65 mt-0 m-0 p-0 fw-bold">Menu</span>
            </a>

            {{-- @foreach ($bottomBarItems as $bottomBarItem)

                <a class="nav-item nav-link text-center lh-1" href="{{ $bottomBarItem['route'] ?? '#' }}">
                    <span class="{{ $bottomBarItem['icon'] }} fs-5"></span>
                    <span class="d-block fs-65 mt-0 pt-0 fw-bold">{{ $bottomBarItem['label'] }}</span>
                </a>
                
            @endforeach --}}
        </div>
    </nav>

</div>

<script>
    const toggleSideBar=document.getElementById('toggleSideBar');
    const sideBar=document.getElementById('sideBar');

    toggleSideBar.addEventListener('click',()=>{
        sideBar.classList.toggle('sidebar-sm');
    });

    //fermer la sidebar
    function closeSideBar() {
        if(sideBar) sideBar.classList.toggle('sidebar-sm');
    }
    
</script>

<script>
    
    /*
    # script sidebar and nav-bottom
    */ 

    function showSection(sectionId) {

        //redimentionement de la bottombar
        const bottombar = document.getElementById('bottombar');
        const section = document.getElementById(sectionId);

        if (section.classList.contains('d-none')) {

            section.style.transition="opacity 0.5s ease-in-out";

            setTimeout(function() {
                section.style.opacity=1;
                bottombar.classList.add('vh-100');
            }, 10);

            

            // Masquer toutes les sections
            document.querySelectorAll('.content-section').forEach(function(sec) {
                if (sec !== section) {
                    sec.style.opacity=0;

                    setTimeout(function() {
                        sec.classList.add('d-none');
                    }, 10);
                }
            });

            // Montrer la section sélectionnée
            section.classList.remove('d-none');

            // Mise à jour des classes actives pour la navigation
            document.querySelectorAll('.nav-link').forEach(function(link) {
                link.classList.remove('active');
            });

            document.querySelectorAll('.nav-link[href="#' + sectionId + '"]').forEach(function(link) {
                link.classList.add('active');
            });
        } 
        else {
            section.style.transition="opacity 0.5s ease-in-out";
            section.style.opacity=0;
            
            setTimeout(function() {
                section.classList.add('d-none');
                bottombar.classList.remove('vh-100');
            }, 10);
        }
    }

</script>
