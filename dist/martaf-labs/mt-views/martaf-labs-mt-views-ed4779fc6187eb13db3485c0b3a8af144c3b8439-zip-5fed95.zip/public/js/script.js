// =======================
// Pour maintenir l'utilisateur connecter
// =======================

setInterval(function() {
    fetch('/keep-alive'); // Envoie une requête au serveur pour garder la session active
}, 10 * 60 * 25000); // Toutes les 10 minutes

// =======================
// Pour Optimiser le chargement d'images
// =======================

document.addEventListener("DOMContentLoaded", function () {
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                loadImage(entry.target); // Charge l'image quand l'élément devient visible
                observer.unobserve(entry.target); // Arrêter l'observation après chargement
            }
        });
    }, {
        threshold: 0.1 // Seuil de 10% de l'élément visible avant de le charger
    });

    // Fonction pour charger l'image, qu'elle soit dans un <img> ou en arrière-plan
    function loadImage(element) {
        if (element.tagName === 'IMG') {
            const imgUrl = element.dataset.src;
            if (imgUrl) {
                element.src = imgUrl; // Appliquer la source à l'image
                element.classList.add('loaded'); // Ajouter une classe après chargement
            }
        } else if (element.classList.contains('lazy-bg')) {
            const bgUrl = element.dataset.bg;
            if (bgUrl) {
                fetch(bgUrl)
                    .then(response => response.blob())
                    .then(blob => {
                        const objectURL = URL.createObjectURL(blob);
                        element.style.backgroundImage = `url('${objectURL}')`; // Appliquer l'image d'arrière-plan
                        element.classList.add('loaded'); // Ajouter une classe après chargement
                    })
                    .catch(error => console.error('Erreur de chargement de l\'image de fond', error));
            }
        }
    }

    // Observer les éléments avec la classe 'lazy-img' (pour les images classiques)
    document.querySelectorAll('.lazy-img').forEach(element => observer.observe(element));

    // Observer les éléments avec la classe 'lazy-bg' (pour les images d'arrière-plan)
    document.querySelectorAll('.lazy-bg').forEach(element => observer.observe(element));
});



// =======================
// Bottombar
// =======================

function showPanelSection(sectionId) {
    //redimentionement de la bottombar
    const section = document.getElementById(sectionId);

    if (section.classList.contains('d-none')) {

        section.style.transition="opacity 0.5s ease-in-out";

        setTimeout(function() {
            section.style.opacity=1;
        }, 10);

        

        // Masquer toutes les sections
        document.querySelectorAll('.content-section').forEach(function(sec) {
            if (sec !== section) {
                sec.style.opacity=0;

                setTimeout(function() {
                    sec.classList.add('d-none');
                }, 10);
            }
        });

        // Montrer la section sélectionnée
        section.classList.remove('d-none');

        // Mise à jour des classes actives pour la navigation
        document.querySelectorAll('.nav-link').forEach(function(link) {
            link.classList.remove('active');
        });

        document.querySelectorAll('.nav-link[href="#' + sectionId + '"]').forEach(function(link) {
            link.classList.add('active');
        });
    } 
    else {
        section.style.transition="opacity 0.5s ease-in-out";
        section.style.opacity=0;
        
        setTimeout(function() {
            section.classList.add('d-none');
        }, 10);
    }
}


// =======================
// afficher et masquer les element
// =======================

document.querySelectorAll('.toggle-btn').forEach(button => {
    button.addEventListener('click', () => {
        const target = document.querySelector(button.getAttribute('data-target'));
        if (target) {
            target.classList.toggle('d-none');
        }
    });
});


// =======================
// createElement: cette fonction sert à generer les elements du DOM html
// =======================
function createElement(type, options = {}) {
    const element = document.createElement(type);

    if (options.text) {
        element.textContent = options.text;
    }

    // Ajout des classes sans erreurs
    if (options.classes) {
        element.classList.add(...options.classes);
    }

    if (options.attributes) {
        for (const [key, value] of Object.entries(options.attributes)) {
            element.setAttribute(key, value);
        }
    }

    if (options.events) {
        for (const [event, handler] of Object.entries(options.events)) {
            element.addEventListener(event, handler);
        }
    }

    if (options.children) {
        options.children.forEach(child => {
            element.appendChild(child);
        });
    }

    if (options.parent) {
        options.parent.appendChild(element);
    }

    return element;
}

//fonction pour generer les alerts
function createAlert({alertType='', alertId='' ,alertItemId='',alertTitle='' ,alertRoute='', bodyContent='', cancelBtnLabel='', confirmBtnLabel=''}={}) {

    //gestion des type d'alerte
    const icons = {'info':'bi bi-info-circle','warning':'bi bi-exclamation-triangle','error':'bi bi-exclamation-diamond'};

    const colors = {'info':'bg-success text-light','warning':'bg-danger text-light','error':'bg-warning text-light'};

    // Modal container
    const modal = createElement('div', {
        classes: ['modal', 'fade'],
        attributes: { id: alertId, tabindex: '-1', 'aria-hidden': 'true' }
    });

    // Modal dialog
    const modalDialog = createElement('div', {
        classes: ['modal-dialog']
    });

    // Modal content
    const modalContent = createElement('div', {
        classes: ['modal-content','border-0']
    });

    // Modal header
    const modalHeader = createElement('div', {
        classes: ['modal-header','py-2','border-0'].concat(colors[alertType].split(" "))
    });

    const modalTitle = createElement('h5', {
        classes: ['modal-title','fs-80','fw-normal'].concat(icons[alertType].split(" ")),
        // text: ` ${alertTitle}`
    });
    modalTitle.innerHTML=` ${alertTitle}`;

    const closeButton = createElement('button', {
        classes: ['btn-close'],
        attributes: { type: 'button', 'data-bs-dismiss': 'modal', 'aria-label': 'Close' }
    });

    modalHeader.appendChild(modalTitle);
    // modalHeader.appendChild(closeButton);

    // Modal body
    const modalBody = createElement('div', {
        classes: ['modal-body','fs-90','text-center'],
        // text: bodyContent
    });
    modalBody.innerHTML=bodyContent;

    // Modal footer
    const modalFooter = createElement('div', {
        classes: ['modal-footer','border-0', 'pt-0']
    });

    //ajout du formulaire
    // Crée l'élément du formulaire
    const alertForm = createElement('form', {
        attributes: { action: alertRoute, method: 'post' }
    });

    // Jeton CSRF
    const csrfToken = createElement('input', {
        attributes: { type: 'hidden', name: '_token', value: document.querySelector('meta[name="csrf-token"]').getAttribute('content') }
    });

    // Méthode HTTP (DELETE)
    const methodInput = createElement('input', {
        attributes: { type: 'hidden', name: '_method', value: 'delete' }
    });

    // Champ caché pour l'ID
    const idInput = createElement('input', {
        attributes: { type: 'hidden', name: 'id', value: alertItemId }
    });

    // Ajoute les éléments au formulaire
    alertForm.appendChild(csrfToken);
    alertForm.appendChild(methodInput);
    alertForm.appendChild(idInput);

    //block bouton
    const formBtn = createElement('div', {
        classes: ['container'],
    });

    const cancelBtn = createElement('button', {
        classes: ['btn','btn-coul3','px-4','py-1','rounded-pill', 'fs-90'],
        text: cancelBtnLabel,
        attributes: {type: 'button', 'data-bs-dismiss': 'modal'},
    });
    formBtn.appendChild(cancelBtn);

    cancelBtn.addEventListener('click', function() {
        modal.classList.remove('show');
        modal.style.display='none';
    });

    if (alertType === 'warning') {
        const confirmBtn = createElement('button', {
            classes: ['btn','btn-danger','px-4','py-1','ms-2','rounded-pill', 'fs-90'],
            text: confirmBtnLabel,
            attributes: {type: 'submit'},
        });
        formBtn.appendChild(confirmBtn);
    }

    alertForm.appendChild(formBtn);
    modalFooter.appendChild(alertForm);

    // Assemble modal
    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalContent.appendChild(modalFooter);
    modalDialog.appendChild(modalContent);
    modal.appendChild(modalDialog);

    // Add modal to the document
    document.body.appendChild(modal);

    return modal;
}

//fonction pour creer les modals
function createModal(modalId='',modalTitle='', bodyContent='') {

    // Modal container
    const modal = createElement('div', {
        classes: ['modal', 'fade'],
        attributes: { id: modalId, 'data-bs-backdrop':'static', 'data-bs-keyboard':'false', tabindex: '-1', 'aria-labelledby':`label${ modalId }`, 'aria-hidden':'true' }
    });

    // Modal dialog
    const modalDialog = createElement('div', {
        classes: ['modal-dialog','modal-dialog-centered', 'modal-dialog-scrollable']
    });

    // Modal content
    const modalContent = createElement('div', {
        classes: ['modal-content','border-0']
    });

    // Modal header
    const modalHeader = createElement('div', {
        classes: ['modal-header','py-2','border-0','bg-coul1']
    });

    const modalShowTitle = createElement('h5', {
        classes: ['modal-title','fs-90','fg-coul4'],
        text: ` ${modalTitle}`
    });

    const closeButton = createElement('button', {
        classes: ['btn-close'],
        attributes: { type: 'button', 'data-bs-dismiss': 'modal', 'aria-label': 'Close',}
    });

    modalHeader.appendChild(modalShowTitle);
    modalHeader.appendChild(closeButton);

    // Modal body
    const modalBody = createElement('div', {
        classes: ['modal-body','fs-90'],
        // text: bodyContent
    });
    // modalBody.innerHTML=bodyContent;
    modalBody.appendChild(bodyContent);

    // Modal footer
    const modalFooter = createElement('div', {
        classes: ['modal-footer','border-0', 'pt-0']
    });

    // Assemble modal
    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalContent.appendChild(modalFooter);
    modalDialog.appendChild(modalContent);
    modal.appendChild(modalDialog);

    // Add modal to the document
    document.body.appendChild(modal);

    return modal;
}