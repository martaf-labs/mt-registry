// Scripts unique au projet


// Fonction pour animer un texte spécifique
function animateText(element) {
    const text = element.textContent;
    element.textContent = ""; // Effacer le texte initial

    // Créer un tableau de span pour chaque caractère
    const spans = text.split("").map(char => {
        const span = document.createElement("span");
        span.textContent = char;
        span.style.opacity = 0; // Opacité initiale
        element.appendChild(span);
        return span;
    });

    let index = 0;
    const interval = 100; // Durée entre les animations (en ms)
    const delayAfterLoop = 2000; // Temps de latence à la fin de chaque boucle (en ms)
    let isAnimating = true;
    
    // Fonction pour animer l'opacité des caractères un par un
    function fadeCharacter() {
        if (!isAnimating) return; // Si en pause, ne pas exécuter l'animation

        if (index < spans.length) {
            spans[index].style.transition = "opacity 0.5s";
            spans[index].style.opacity = 1; // Passer à l'opacité 1
            index++;
        } else {
            // Réinitialiser après avoir fini l'animation
            isAnimating = false; // Mettre en pause l'animation
            setTimeout(() => {
                spans.forEach(span => span.style.opacity = 0);
                index = 0;
                isAnimating = true; // Reprendre l'animation après le délai
            }, delayAfterLoop);
        }
    }

    // Lancer l'animation à intervalles réguliers
    setInterval(fadeCharacter, interval);
}

// Démarrer l'animation pour chaque élément avec la classe "animated-text"
function startAnimations() {
    const animatedTextElements = document.querySelectorAll(".animated-text");
    animatedTextElements.forEach(element => animateText(element));
}

// Démarrer l'animation lorsque la page est chargée
window.onload = startAnimations;