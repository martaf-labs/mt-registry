// Scripts commun à d'autres projets

// =======================
// Pour maintenir l'utilisateur connecter
// =======================

setInterval(function() {
    fetch('/keep-alive'); // Envoie une requête au serveur pour garder la session active
}, 10 * 60 * 25000); // Toutes les 10 minutes


// =======================
// Fonction pour animer un texte spécifique
// =======================

function animateText(element) {
    const text = element.textContent;
    element.textContent = ""; // Effacer le texte initial

    // Créer un tableau de span pour chaque caractère
    const spans = text.split("").map(char => {
        const span = document.createElement("span");
        span.textContent = char;
        span.style.opacity = 0; // Opacité initiale
        element.appendChild(span);
        return span;
    });

    let index = 0;
    const interval = 100; // Durée entre les animations (en ms)
    const delayAfterLoop = 2000; // Temps de latence à la fin de chaque boucle (en ms)
    let isAnimating = true;
    
    // Fonction pour animer l'opacité des caractères un par un
    function fadeCharacter() {
        if (!isAnimating) return; // Si en pause, ne pas exécuter l'animation

        if (index < spans.length) {
            spans[index].style.transition = "opacity 0.5s";
            spans[index].style.opacity = 1; // Passer à l'opacité 1
            index++;
        } else {
            // Réinitialiser après avoir fini l'animation
            isAnimating = false; // Mettre en pause l'animation
            setTimeout(() => {
                spans.forEach(span => span.style.opacity = 0);
                index = 0;
                isAnimating = true; // Reprendre l'animation après le délai
            }, delayAfterLoop);
        }
    }

    // Lancer l'animation à intervalles réguliers
    setInterval(fadeCharacter, interval);
}

// Démarrer l'animation pour chaque élément avec la classe "animated-text"
function startAnimations() {
    const animatedTextElements = document.querySelectorAll(".animated-text");
    animatedTextElements.forEach(element => animateText(element));
}

// Démarrer l'animation lorsque la page est chargée
window.onload = startAnimations;

// =======================
// Pour gerer les compteurs animé
// =======================
const counters = document.querySelectorAll(".counter");

const startCounter = (counter) => {
    counter.innerText = "0";
    const target = +counter.getAttribute("data-target");
    const duration = 1000; // Durée de l'animation en ms
    const startTime = performance.now();

    const updateCounter = (currentTime) => {
        const elapsedTime = currentTime - startTime;
        const progress = Math.min(elapsedTime / duration, 1);
        counter.innerText = Math.ceil(progress * target);

        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        }
    };

    requestAnimationFrame(updateCounter);
};

// Observer pour relancer l'animation à chaque fois que l'élément devient visible
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            startCounter(entry.target);
        }
    });
}, { threshold: 0.5 }); // Lancer l'animation lorsque 50% de l'élément est visible

// Ajouter chaque compteur à l'observer
counters.forEach((counter) => observer.observe(counter));

// =======================
// Acordion personalisé
// ======================

document.querySelectorAll('.accordion-wrap').forEach(function (wrap) {
    wrap.addEventListener('click', function () {
        const children = this.children;
        const content = children[1]; // .accordion-text
        const header = children[0];  // .accordion-header

        // Toggle le texte (slideToggle)
        if (content.style.maxHeight) {
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + 'px';
        }

        // Toggle la classe barre sur le header
        header.classList.toggle('accordion-no-bar');

        // Supprimer les classes des autres accordéons
        document.querySelectorAll('.accordion-wrap').forEach(function (otherWrap) {
            if (otherWrap !== wrap) {
                const otherHeader = otherWrap.querySelector('.accordion-header');
                const otherIcon = otherHeader.querySelector('i');
                const otherContent = otherWrap.querySelector('.accordion-text');

                otherHeader.classList.remove('accordion-gold');
                if (otherIcon) otherIcon.classList.remove('rotate-bi');
                if (otherContent) otherContent.style.maxHeight = null;
            }
        });

        // Ajouter les classes à celui cliqué
        header.classList.toggle('accordion-gold');
        const icon = header.querySelector('.bi');
        if (icon) icon.classList.toggle('rotate-bi');
    });
});


// =======================
// Pour Optimiser le chargement d'images
// =======================

document.addEventListener("DOMContentLoaded", function () {
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                loadImage(entry.target); // Charge l'image quand l'élément devient visible
                observer.unobserve(entry.target); // Arrêter l'observation après chargement
            }
        });
    }, {
        threshold: 0.1 // Seuil de 10% de l'élément visible avant de le charger
    });

    // Fonction pour charger l'image, qu'elle soit dans un <img> ou en arrière-plan
    function loadImage(element) {
        if (element.tagName === 'IMG') {
            const imgUrl = element.dataset.src;
            if (imgUrl) {
                element.src = imgUrl; // Appliquer la source à l'image
                element.classList.add('loaded'); // Ajouter une classe après chargement
            }
        } else if (element.classList.contains('lazy-bg')) {
            const bgUrl = element.dataset.bg;
            if (bgUrl) {
                element.style.backgroundImage = `url('${bgUrl}')`; // Appliquer l'image d'arrière-plan
                element.classList.add('loaded'); // Ajouter une classe après chargement
            }
        }
    }

    // Observer les éléments avec la classe 'lazy-img' (pour les images classiques)
    document.querySelectorAll('.lazy-img').forEach(element => observer.observe(element));

    // Observer les éléments avec la classe 'lazy-bg' (pour les images d'arrière-plan)
    document.querySelectorAll('.lazy-bg').forEach(element => observer.observe(element));
});

// =======================
// Bottombar
// =======================

function showPanelSection(sectionId) {
    //redimentionement de la bottombar
    const section = document.getElementById(sectionId);

    if (section.classList.contains('d-none')) {

        section.style.transition="opacity 0.5s ease-in-out";

        setTimeout(function() {
            section.style.opacity=1;
        }, 10);

        

        // Masquer toutes les sections
        document.querySelectorAll('.content-section').forEach(function(sec) {
            if (sec !== section) {
                sec.style.opacity=0;

                setTimeout(function() {
                    sec.classList.add('d-none');
                }, 10);
            }
        });

        // Montrer la section sélectionnée
        section.classList.remove('d-none');

        // Mise à jour des classes actives pour la navigation
        document.querySelectorAll('.nav-link').forEach(function(link) {
            link.classList.remove('active');
        });

        document.querySelectorAll('.nav-link[href="#' + sectionId + '"]').forEach(function(link) {
            link.classList.add('active');
        });
    } 
    else {
        section.style.transition="opacity 0.5s ease-in-out";
        section.style.opacity=0;
        
        setTimeout(function() {
            section.classList.add('d-none');
        }, 10);
    }
}


// =======================
// afficher et masquer les element
// =======================

document.querySelectorAll('.toggle-btn').forEach(button => {
    button.addEventListener('click', () => {
        const target = document.querySelector(button.getAttribute('data-target'));
        if (target) {
            target.classList.toggle('d-none');
        }
    });
});

// =======================
// createElement: cette fonction sert à generer les elements du DOM html
// =======================

function createElement(type, options = {}) {
    const element = document.createElement(type);

    if (options.text) {
        element.textContent = options.text;
    }

    // Filtrer et appliquer les classes valides
    if (options.classes) {
        const classes = options.classes.filter((item) => item.trim() !== '');
        if (classes.length > 0) {
            element.classList.add(...classes);
        }
    }

    if (options.attributes) {
        for (const [key, value] of Object.entries(options.attributes)) {
            element.setAttribute(key, value);
        }
    }

    if (options.events) {
        for (const [event, handler] of Object.entries(options.events)) {
            element.addEventListener(event, handler);
        }
    }

    if (options.children) {
        options.children.forEach((child) => {
            element.appendChild(child);
        });
    }

    if (options.parent) {
        options.parent.appendChild(element);
    }

    return element;
}


// =======================
// fonction pour generer les alerts
// =======================

function createAlert({alertType='', alertId='' ,alertItemId='',alertTitle='' ,alertRoute='', bodyContent='', cancelBtnLabel='', confirmBtnLabel=''}={}) {

    //gestion des type d'alerte
    const icons = {'info':'bi bi-info-circle','warning':'bi bi-exclamation-triangle','error':'bi bi-exclamation-diamond'};

    const colors = {'info':'bg-success text-light','warning':'bg-danger text-light','error':'bg-warning text-light'};

    // Modal container
    const modal = createElement('div', {
        classes: ['modal', 'fade'],
        attributes: { id: alertId, tabindex: '-1', 'aria-hidden': 'true' }
    });

    // Modal dialog
    const modalDialog = createElement('div', {
        classes: ['modal-dialog']
    });

    // Modal content
    const modalContent = createElement('div', {
        classes: ['modal-content','border-0']
    });

    // Modal header
    const modalHeader = createElement('div', {
        classes: ['modal-header','py-2','border-0'].concat(colors[alertType].split(" "))
    });

    const modalTitle = createElement('h5', {
        classes: ['modal-title','fs-80','text-white','fw-normal'].concat(icons[alertType].split(" ")),
        // text: ` ${alertTitle}`
    });
    modalTitle.innerHTML=` ${alertTitle}`;

    const closeButton = createElement('button', {
        classes: ['btn-close'],
        attributes: { type: 'button', 'data-bs-dismiss': 'modal', 'aria-label': 'Close' }
    });

    modalHeader.appendChild(modalTitle);
    // modalHeader.appendChild(closeButton);

    // Modal body
    const modalBody = createElement('div', {
        classes: ['modal-body','fs-90','text-center'],
        // text: bodyContent
    });
    modalBody.innerHTML=bodyContent;

    // Modal footer
    const modalFooter = createElement('div', {
        classes: ['modal-footer','border-0', 'pt-0']
    });

    //ajout du formulaire
    // Crée l'élément du formulaire
    const alertForm = createElement('form', {
        attributes: { action: alertRoute, method: 'post' }
    });

    // Jeton CSRF
    const csrfToken = createElement('input', {
        attributes: { type: 'hidden', name: '_token', value: document.querySelector('meta[name="csrf-token"]').getAttribute('content') }
    });

    // Méthode HTTP (DELETE)
    const methodInput = createElement('input', {
        attributes: { type: 'hidden', name: '_method', value: 'delete' }
    });

    // Champ caché pour l'ID
    const idInput = createElement('input', {
        attributes: { type: 'hidden', name: 'id', value: alertItemId }
    });

    // Ajoute les éléments au formulaire
    alertForm.appendChild(csrfToken);
    alertForm.appendChild(methodInput);
    alertForm.appendChild(idInput);

    //block bouton
    const formBtn = createElement('div', {
        classes: ['container'],
    });

    const cancelBtn = createElement('button', {
        classes: ['btn','btn-coul3','px-4','py-1','rounded-pill', 'fs-90'],
        text: cancelBtnLabel,
        attributes: {type: 'button', 'data-bs-dismiss': 'modal'},
    });
    formBtn.appendChild(cancelBtn);

    cancelBtn.addEventListener('click', function() {
        modal.classList.remove('show');
        modal.style.display='none';
    });

    if (alertType === 'warning') {
        const confirmBtn = createElement('button', {
            classes: ['btn','btn-danger','px-4','py-1','ms-2','rounded-pill', 'fs-90'],
            text: confirmBtnLabel,
            attributes: {type: 'submit'},
        });
        formBtn.appendChild(confirmBtn);
    }

    alertForm.appendChild(formBtn);
    modalFooter.appendChild(alertForm);

    // Assemble modal
    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalContent.appendChild(modalFooter);
    modalDialog.appendChild(modalContent);
    modal.appendChild(modalDialog);

    // Add modal to the document
    document.body.appendChild(modal);

    return modal;
}


// =======================
// fonction pour creer les modals
// =======================

function createModal(modalId='',modalTitle='', bodyContent='') {

    // Modal container
    const modal = createElement('div', {
        classes: ['modal', 'fade'],
        attributes: { id: modalId, 'data-bs-backdrop':'static', 'data-bs-keyboard':'false', tabindex: '-1', 'aria-labelledby':`label${ modalId }`, 'aria-hidden':'true' }
    });

    // Modal dialog
    const modalDialog = createElement('div', {
        classes: ['modal-dialog','modal-dialog-centered', 'modal-dialog-scrollable','modal-lg']
    });

    // Modal content
    const modalContent = createElement('div', {
        classes: ['modal-content','border-0']
    });

    // Modal header
    const modalHeader = createElement('div', {
        classes: ['modal-header','py-2','border-0','bg-coul1']
    });

    const modalShowTitle = createElement('h5', {
        classes: ['modal-title','fs-80','fg-coul4', 'pe-4','whitespace-nowrap','overflow-hidden'],
        text: ` ${modalTitle}`
    });

    const closeButton = createElement('button', {
        classes: ['btn-close','fg-coul4'],
        attributes: { 
            type: 'button', 'data-bs-dismiss': 'modal', 'aria-label': 'Close',
            style: 'color:white',
        }
    });

    modalHeader.appendChild(modalShowTitle);
    modalHeader.appendChild(closeButton);

    // Modal body
    const modalBody = createElement('div', {
        classes: ['modal-body','fs-90'],
        // text: bodyContent
    });
    // modalBody.innerHTML=bodyContent;
    modalBody.appendChild(bodyContent);

    // Modal footer
    const modalFooter = createElement('div', {
        classes: ['modal-footer','border-0', 'pt-0']
    });

    // Assemble modal
    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modalContent.appendChild(modalFooter);
    modalDialog.appendChild(modalContent);
    modal.appendChild(modalDialog);

    // Add modal to the document
    document.body.appendChild(modal);

    return modal;
}


// =======================
// fonction pour creer les tableaux
// =======================

function createArray(parent='', arrayId='', headerDatas=null, bodyDatas=null, footerDatas=null) {

    // array
    const array= createElement('div', {
        classes: ['container-fluid'],
        attributes: {}
    });

    // arrayContainer
    const arrayContainer= createElement('div', {
        classes: [],
        attributes: {}
    });
    
    // entete du tableau
    if (headerDatas.length > 0) {

        const nbreColone= headerDatas.length;

        // arrayHeader
        const arrayHeader= createElement('div', {
            classes: ['row',`row-cols-${nbreColone}` ],
            attributes: {}
        });

        for (let i = 0; i < nbreColone; i++) {
            let textAlign= i==0 ? 'text-start' : 'text-center';
            // arrayHeaderCol
            const arrayHeaderCol= createElement('div', {
                classes: ['col','whitespace-nowrap','overflow-hidden', 'border', 'bg-light',textAlign],
            });
            
            // arrayHeaderColLabel
            const arrayHeaderColLabel= createElement('span', {
                text: headerDatas[i],
                classes: ['fw-bolder'],
            });

            // Ajout des elements
            arrayHeaderCol.appendChild(arrayHeaderColLabel);
            arrayHeader.appendChild(arrayHeaderCol);

        }
        arrayContainer.appendChild(arrayHeader);
    }
    
    // corps du tabbleau
    if (bodyDatas.length > 0) {
        bodyDatas.forEach((data, index) => {
            const nbreColone=data.length;
            // arrayBody
            const arrayBody= createElement('div', {
                classes: ['row',`row-cols-` ],
                attributes: {}
            });

            for (let i = 0; i < nbreColone; i++) {
                let textAlign= i==0 ? 'text-start' : 'text-center';
                // arrayBodyCol
                const arrayBodyCol= createElement('div', {
                    classes: ['col','whitespace-nowrap','overflow-hidden', 'border',textAlign],
                });
                
                // arrayBodyColLabel
                const arrayBodyColLabel= createElement('span', {
                    text: data[i],
                    classes: [],
                });

                // Ajout des elements
                arrayBodyCol.appendChild(arrayBodyColLabel);
                arrayBody.appendChild(arrayBodyCol);
                
            }
            
            arrayContainer.appendChild(arrayBody);

        });
    }

    // pieds du tableau: le footer peut prendre plusieurs lignes uniforme ou non
    if (footerDatas.length > 0) {

        let nbreLigne=footerDatas.length;

        for (let findex = 0; findex < nbreLigne ; findex++) {
            const element = footerDatas[findex];

            const nbreColone= element.length;

            // arrayFooter
            const arrayFooter= createElement('div', {
                classes: ['row',`row-cols-${nbreColone}` ],
                attributes: {}
            });

            for (let i = 0; i < nbreColone; i++) {
                let textAlign= i==0 ? 'text-start' : 'text-center';
                // arrayFooterCol
                const arrayFooterCol= createElement('div', {
                    classes: ['col','whitespace-nowrap','overflow-hidden', 'border', 'bg-light',textAlign],
                });
                
                // arrayFooterColLabel
                const arrayFooterColLabel= createElement('span', {
                    text: element[i],
                    classes: ['fw-bolder'],
                });

                // Ajout des elements
                arrayFooterCol.appendChild(arrayFooterColLabel);
                arrayFooter.appendChild(arrayFooterCol);

            }
            arrayContainer.appendChild(arrayFooter);
        }
        
    }

    array.appendChild(arrayContainer);

    // Add Array to the document
    parent.appendChild(array);

    return array;
}


// =======================
// createChart: Fonction pour les generer les graphiques, basé sur chart.js
// =======================

function createChart({ chartId, type, labels, datasets, title }) {

    // les differents types de chart: bar, line, pie, doughnut, polarArea, radar, bubble, scatter
    const ctx = document.getElementById(chartId)?.getContext('2d');
    if (!ctx) return;

    new Chart(ctx, {
        type,
        data: {
            labels,
            datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: !!title,
                    text: title
                },
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: ['bar', 'line', 'radar', 'scatter', 'bubble'].includes(type)
                ? {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
                : {} // Pas d'axe Y pour pie/doughnut
        }
    });
}

/**
 * Prépare les datasets en fonction du type de graphique
 */
function prepareDatasets(config) {
    const type = config.chartType;

    // Données déjà formatées ? On les retourne directement
    if (Array.isArray(config.chartDataSets)) return config.chartDataSets;

    // Cas particuliers : scatter et bubble
    if (['scatter', 'bubble'].includes(type)) {
        return [{
            label: config.chartDataSetLabel || 'Série',
            data: config.chartDataSetData || [],
            backgroundColor: getColor(0, 0.6),
            borderColor: getColor(0, 1),
        }];
    }

    // Pie, doughnut, polarArea : 1 dataset + tableau de couleurs
    if (['pie', 'doughnut', 'polarArea'].includes(type)) {
        return [{
            label: config.chartDataSetLabel || 'Répartition',
            data: config.chartDataSetData || [],
            backgroundColor: config.chartDataSetData.map((_, i) => getColor(i, 0.6)),
            borderWidth: 1
        }];
    }

    // Bar chart : chaque barre a sa propre couleur
    if (type === 'bar') {
        return [{
            label: config.chartDataSetLabel || 'Données',
            data: config.chartDataSetData || [],
            backgroundColor: config.chartDataSetData.map((_, i) => getColor(i, 0.6)),
            borderColor: config.chartDataSetData.map((_, i) => getColor(i, 1)),
            borderWidth: 1,
        }];
    }

    // Par défaut (line, radar, etc.)
    return [{
        label: config.chartDataSetLabel || 'Données',
        data: config.chartDataSetData || [],
        backgroundColor: getColor(0, 0.2),
        borderColor: getColor(0, 1),
        fill: false,
        tension: 0.3,
        pointBackgroundColor: getColor(0, 1)
    }];
}


/**
 * Génère une couleur dynamique
 */
function getColor(index = 0, opacity = 0.5) {
    const colors = [
        '255, 99, 132',   // Rouge
        '54, 162, 235',   // Bleu
        '255, 206, 86',   // Jaune
        '75, 192, 192',   // Vert-bleu
        '153, 102, 255',  // Violet
        '255, 159, 64'    // Orange
    ];
    return `rgba(${colors[index % colors.length]}, ${opacity})`;
}



// =======================
// createCircularProgressBar: generer les progres bar circulaire
// =======================
function createProgressBar(progress, parent = null, options = {}) {

    const type = options.type || 'circular';
    const duration = options.duration || 1000;
    let lineaBg = 'bg-primary';
    let circularBg = '#0d6efd';

    // Choix de couleur dynamique
    if (inRange(progress, 0, 25)) {
        lineaBg = 'bg-danger';
        circularBg = '#dc3545';
    }
    if (inRange(progress, 25, 50)) {
        lineaBg = 'bg-warning';
        circularBg = '#ffc107';
    }
    if (inRange(progress, 50, 100)) {
        lineaBg = 'bg-info';
        circularBg = '#0dcaf0';
    }
    if (progress === 100) {
        lineaBg = 'bg-success';
        circularBg = '#198754';
    }

    if (type === 'linear') {
        // Progress bar linéaire
        const bar = createElement('div', {
            classes: ['mt-progress-bar', 'rounded-pill', lineaBg],
            attributes: {
                role: 'progressbar',
                style: 'width: 0%',
                'aria-valuemin': 0,
                'aria-valuemax': 100,
                'aria-valuenow': 0
            },
            text: '0%'
        });

        const progressContainer = createElement('div', {
            classes: ['mt-progress', 'w-100', 'rounded-pill'],
            children: [bar],
            parent: parent
        });

        const start = performance.now();

        function animateLinear(timestamp) {
            const elapsed = timestamp - start;
            const ratio = Math.min(elapsed / duration, 1);
            const current = Math.round(progress * ratio);

            bar.style.width = `${current}%`;
            bar.setAttribute('aria-valuenow', current);
            bar.textContent = `${current}%`;

            if (ratio < 1) requestAnimationFrame(animateLinear);
        }

        requestAnimationFrame(animateLinear);

        return progressContainer;

    } else {
        // Progress bar circulaire
        const radius = 50;
        const strokeWidth = 12;
        const circumference = 2 * Math.PI * radius;
        const SVG_NS = "http://www.w3.org/2000/svg";

        function createSvgElement(type, attributes = {}) {
            const el = document.createElementNS(SVG_NS, type);
            for (const [key, value] of Object.entries(attributes)) {
                el.setAttribute(key, value);
            }
            return el;
        }

        const backgroundCircle = createSvgElement('circle', {
            cx: 60,
            cy: 60,
            r: radius,
            stroke: '#e6e6e6',
            'stroke-width': strokeWidth,
            fill: 'none'
        });

        const progressCircle = createSvgElement('circle', {
            cx: 60,
            cy: 60,
            r: radius,
            stroke: circularBg,
            'stroke-width': strokeWidth,
            fill: 'none',
            'stroke-dasharray': circumference,
            'stroke-dashoffset': circumference,
            'stroke-linecap': 'round',
            transform: 'rotate(-90 60 60)'
        });

        const svg = document.createElementNS(SVG_NS, 'svg');
        svg.setAttribute('viewBox', '0 0 120 120');
        svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
        svg.style.width = '100%';
        svg.style.height = 'auto';
        svg.appendChild(backgroundCircle);
        svg.appendChild(progressCircle);

        const text = createElement('div', {
            text: `0%`,
            classes: ['position-absolute', 'top-50', 'start-50', 'translate-middle', 'fw-bold'],
            attributes: {
                style: `
                    color: ${circularBg};
                    display: inline-block;
                    line-height: 1;
                    white-space: nowrap;
                    text-align: center;
                    padding: 0.25em 0.5em;
                    transition: font-size 0.2s ease;
                    pointer-events: none;
                `
            }
        });

        // Fonction pour adapter la taille du texte dynamiquement
        function resizeFont() {
            const containerWidth = container.offsetWidth;
            const fontSize = containerWidth * 0.2; // 20% du conteneur
            text.style.fontSize = `${fontSize}px`;
        }

        const container = createElement('div', {
            classes: ['position-relative', 'd-inline-block', 'text-center', 'w-100'],
            attributes: {
                style: 'max-width: 250px; aspect-ratio: 1 / 1'
            },
            children: [text],
            parent: parent
        });

        container.insertBefore(svg, text);

        // Observe les changements de taille
        new ResizeObserver(resizeFont).observe(container);
        resizeFont(); // Appel initial

        const start = performance.now();

        function animateCircular(timestamp) {
            const elapsed = timestamp - start;
            const ratio = Math.min(elapsed / duration, 1);
            const currentValue = Math.round(progress * ratio);
            const offset = circumference * (1 - currentValue / 100);

            progressCircle.setAttribute('stroke-dashoffset', offset);
            text.textContent = `${currentValue}%`;

            if (ratio < 1) requestAnimationFrame(animateCircular);
        }

        requestAnimationFrame(animateCircular);

        return container;
    }
}


// =======================
// inRange: pour verifier si un nombre appartien a une plage
// =======================
function inRange(nbre,min,max){
    return nbre>min && nbre<=max;
}

// =======================
// Gestion de l'effet zoom, mtzoom-in et mtzoom-out
// =======================

// document.addEventListener('DOMContentLoaded', () => {
//     const modals = document.querySelectorAll('.modal');

//     modals.forEach(modal => {
//         const modalContent = modal.querySelector('.modal-content');
//         if (!modalContent) return;

//         // Nettoyer les animations dès le clic sur le bouton
//         document.querySelectorAll(`[data-bs-toggle="modal"][data-bs-target="#${modal.id}"]`).forEach(btn => {
//             btn.addEventListener('click', () => {
//                 modalContent.classList.remove('mtzoom-in', 'mtzoom-out');
//                 modal.style.display = ''; // 🛠 Assure que le modal est réaffichable
//             });
//         });

//         // Animation d’entrée
//         modal.addEventListener('shown.bs.modal', () => {
//             modalContent.classList.remove('mtzoom-out');
//             void modalContent.offsetWidth;
//             modalContent.classList.add('mtzoom-in');
//         });

//         // Nettoyage des classes après animation
//         modalContent.addEventListener('animationend', () => {
//             modalContent.classList.remove('mtzoom-in', 'mtzoom-out');
//         });

//         // Animation de fermeture personnalisée
//         modal.addEventListener('hide.bs.modal', (e) => {
//             e.preventDefault();

//             modalContent.classList.remove('mtzoom-in');
//             void modalContent.offsetWidth;
//             modalContent.classList.add('mtzoom-out');

//             modalContent.addEventListener('animationend', function handleClose() {
//                 modalContent.removeEventListener('animationend', handleClose);

//                 // Fermeture manuelle
//                 const backdrop = document.querySelector('.modal-backdrop');
//                 if (backdrop) backdrop.remove();

//                 modal.classList.remove('show');
//                 modal.setAttribute('aria-hidden', 'true');
//                 modal.style.display = 'none'; // 👈 modal caché proprement

//                 document.body.classList.remove('modal-open');
//                 document.body.style = '';
//             });
//         });
//     });
// });


// =======================
// mt-loader
// =======================
document.addEventListener("DOMContentLoaded", () => {
    // Injecte le loader global
    const globalWrapper = document.createElement('div');
    globalWrapper.className = 'mt-loader-wrapper hidden';
    globalWrapper.innerHTML = `
    <div class="mt-loader">
        <div class="bounce-ball"></div>
        <div class="bounce-ball"></div>
        <div class="bounce-ball"></div>
    </div>
    `;
    document.body.appendChild(globalWrapper);

    // Crée un loader DOM prêt à être cloné dans des conteneurs
    const createLoader = () => {
    const wrapper = document.createElement('div');
    wrapper.className = 'mt-loader-wrapper local-loader hidden';
    wrapper.innerHTML = `
        <div class="mt-loader">
        <div class="bounce-ball"></div>
        <div class="bounce-ball"></div>
        <div class="bounce-ball"></div>
        </div>
    `;
    return wrapper;
    };

    window.mtLoader = {
    show(target = null) {
        if (!target) {
        globalWrapper.classList.remove('hidden');
        } else {
        let localLoader = target.querySelector('.mt-loader-wrapper.local-loader');
        if (!localLoader) {
            localLoader = createLoader();
            target.style.position = 'relative'; // Important pour le positionnement
            target.appendChild(localLoader);
        }
        localLoader.classList.remove('hidden');
        }
    },

    hide(target = null) {
        if (!target) {
        globalWrapper.classList.add('hidden');
        } else {
        const localLoader = target.querySelector('.mt-loader-wrapper.local-loader');
        if (localLoader) {
            localLoader.classList.add('hidden');
        }
        }
    }
    };
});


// =======================
// mt-notification
// =======================
function createNotification({ title, message, image, time = 'Just now',unreadCount=0}) {

    let notificationWrapper = document.querySelector('.mt-notification-wrapper');
    if (!notificationWrapper) {
        notificationWrapper = createElement('div', {
            classes: ['mt-notification-wrapper','d-flex','flex-column','align-items-center', 'justify-content-end',],
            attributes: { 
                id: 'mt-notification-wrapper',
                style: `position: fixed;bottom: 0;right: 0;padding: 1rem;z-index: 1055;width: 100%;max-width: 400px;height: auto;
                `
            },
            parent: document.body
        });
    }

    if (unreadCount > 0) {
        /**
         * notificationUnreadBlock
         */ 
        const notificationUnreadBlock = createElement('div', {
            classes: ['container','d-flex','justify-content-end','py-0', 'my-0'],
            parent: notificationWrapper
        });

        let unreadCountLabel= unreadCount > 1 ? `(${addZero(unreadCount)}) autres` : `(${addZero(unreadCount)}) autre` 
        // notificationUnreadBlockLink
        const notificationUnreadBlockLink = createElement('a', {
            text: `${unreadCountLabel}`,
            classes: ['link','primary-link','fs-70'],
            attributes: {
                href: '#'
            },
            parent: notificationUnreadBlock
        });
    }

    /**
     * notificationContainer
     */ 
    const notificationContainer = createElement('div', {
        classes: ['mt-notification','mt-1'],
        parent: notificationWrapper
    });

    // notificationHeader
    const notificationHeader = createElement('div', {
        classes: ['d-flex', 'align-items-center', 'justify-content-between', 'mb-3'],
        parent: notificationContainer
    });
    const titleElement = createElement('div', {
        text: title,
        classes: ['fw-medium'],
        attributes: { style: 'font-size:70%;' },
        parent: notificationHeader        
    });
    const closeButton = createElement('button', {
        classes: ['btn', 'btn-close'],
        attributes: {
            style: 'font-size:65%;cursor:pointer;',
            type: 'button'
        },
        events: {
            click: () => notificationWrapper.remove()
        },
        parent: notificationHeader
    });

    const notificationBody = createElement('div', {
        classes: ['container-fluid','d-flex','flex-row','flex-nowrap', 'align-items-start', 'justify-content-between'],
        parent: notificationContainer
    });

    if (image) {

        // bodyBlockImg
        const bodyBlockImg = createElement('div', {
            classes: ['col-2'],
            parent: notificationBody
        });
        const bodyBlockImgContent = createElement('div', {
            classes: ['mtblock-sqr','rounded-pill'],
            attributes: {
                style: `background-image: url('${image}')`
            },
            parent: bodyBlockImg
        });

    }
    // bodyBlockText
    const bodyBlockText = createElement('div', {
        classes: ['col-10','flex-grow-1','d-flex','flex-column','align-items-end', 'justify-content-between'],
        parent: notificationBody
    });
    const bodyBlockTextContent = createElement('p', {
        classes: ['ps-2','fw-semibold','m-0'],
        attributes: {
            style: 'font-size: 70%;'
        },
        parent: bodyBlockText
    });
    bodyBlockTextContent.innerHTML=message;

    const timeElement = createElement('span', {
        text: time,
        classes: ['text-primary','d-inline-block'],
        attributes: { style: 'font-size:60%;' },
        parent: bodyBlockText
    });


    setTimeout(() => {
        notificationWrapper.remove();
    }, 20000);
}

// =======================
// tempsEcoule
// =======================
function tempsEcoule(debut, fin = null, abrege = false, prefixe = true) {
    const dateDebut = new Date(debut);
    const dateFin = fin ? new Date(fin) : new Date();

    let diffMs = dateFin - dateDebut;
    const future = diffMs < 0;
    diffMs = Math.abs(diffMs);

    const secondes = Math.floor(diffMs / 1000);
    const minutes = Math.floor(diffMs / (1000 * 60));
    const heures = Math.floor(diffMs / (1000 * 60 * 60));
    const jours = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const semaines = Math.floor(jours / 7);
    const mois = Math.floor(jours / 30.44); // approximation
    const ans = Math.floor(jours / 365.25); // approximation

    function addZero(n) {
        return n < 10 ? '0' + n : n;
    }

    let valeur, label;

    if (secondes < 60) {
        valeur = secondes;
        label = abrege ? 's' : (valeur > 1 ? 'secondes' : 'seconde');
    } else if (minutes < 60) {
        valeur = minutes;
        label = abrege ? 'min' : (valeur > 1 ? 'minutes' : 'minute');
    } else if (heures < 24) {
        valeur = heures;
        label = abrege ? 'h' : (valeur > 1 ? 'heures' : 'heure');
    } else if (jours < 7) {
        valeur = jours;
        label = abrege ? 'j' : (valeur > 1 ? 'jours' : 'jour');
    } else if (jours < 30) {
        valeur = semaines;
        label = abrege ? 'sem' : (valeur > 1 ? 'semaines' : 'semaine');
    } else if (jours < 365) {
        valeur = mois;
        label = 'mois'; // même au singulier
    } else {
        valeur = ans;
        label = abrege ? 'an' : (valeur > 1 ? 'ans' : 'an');
    }

    const prefix = prefixe ? (future ? 'dans' : 'il y a ') : '';
    return prefix + addZero(valeur) + ' ' + label;
}

// =======================
// addZero
// =======================
function addZero(number) {
    if (number == 0) {
        return number;
    }
    if (number < 10) {
        return "0" + number;
    }

    if (number < 1000) {
        return number.toString();
    }

    if (number < 1000000) {
        return (number / 1000).toFixed(1) + "K";
    }

    if (number < 1000000000) {
        return (number / 1000000).toFixed(1) + "M";
    }

    return (number / 1000000000).toFixed(1) + "Md";
}

// =======================
// markAsReadNotifications: pour marquer une ou plusieurs notifications comme lues
// =======================
async function markAsReadNotifications(ids) {
    try {
        const res = await fetch('/api/notifications/mark-as-read', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ ids })
        });

        if (!res.ok) {
            console.error('Erreur!', res.status);
            return false;
        }

        return true;

    } catch (error) {
        console.error('Erreur!', error);
        return false;
    }
}

// =======================
// deleteNotifications: pour suprimer une ou plusieurs notifications
// =======================
async function deleteNotifications(ids) {
    try {
        const res = await fetch('/api/notifications/delete', {
            method: 'DELETE',
            credentials: 'include',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ ids })
        });

        if (!res.ok) {
            console.error('Erreur!', res.status);
            return false;
        }

        return true;

    } catch (error) {
        console.error('Erreur!', error);
        return false;
    }
}
