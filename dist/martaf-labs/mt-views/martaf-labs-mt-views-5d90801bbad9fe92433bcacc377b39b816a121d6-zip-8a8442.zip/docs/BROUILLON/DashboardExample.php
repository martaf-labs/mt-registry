<?php

namespace App\Livewire;

use App\Models\User;
use App\Models\Order;
use App\Models\Product;
use App\Models\Client;

/**
 * Exemple de Dashboard pour un projet hôte.
 *
 * Étend le Dashboard générique de mt-views et surcharge
 * uniquement ce qui est nécessaire pour ce projet.
 *
 * Enregistrement dans AppServiceProvider :
 *   Livewire::component('mt.dashboard', \App\Livewire\Dashboard::class);
 */
class Dashboard extends \Mt\MtViews\Livewire\Dashboard
{
    public function getTitle(): string
    {
        return 'Tableau de bord';
    }

    public function getSubtitle(): string
    {
        return 'Bienvenue sur votre espace de gestion';
    }

    public function getQuickActions(): array
    {
        return [
            [
                'label'   => 'Nouveau client',
                'icon'    => 'fa-solid fa-user-plus',
                'route'   => 'clients.create',
                'variant' => 'primary',
            ],
            [
                'label'   => 'Nouvelle commande',
                'icon'    => 'fa-solid fa-plus',
                'route'   => 'orders.create',
                'variant' => 'secondary',
            ],
        ];
    }

    public function getStats(): array
    {
        // ─── remplacer par de vraies requêtes ───
        $totalUsers    = User::count();
        $onlineUsers   = User::where('last_seen_at', '>=', now()->subMinutes(5))->count();
        $totalOrders   = Order::count();
        $pendingOrders = Order::where('status', 'pending')->count();
        $totalRevenue  = Order::where('status', 'completed')->sum('total');
        $totalClients  = Client::count();

        return [
            [
                'label'      => 'Utilisateurs',
                'value'      => $totalUsers,
                'icon'       => 'fa-solid fa-users',
                'color'      => 'primary',
                'change'     => '+12%',
                'changeType' => 'positive',
                'route'      => 'users.index',
                'details'    => [
                    ['label' => 'En ligne', 'value' => $onlineUsers],
                ],
            ],
            [
                'label'      => 'Commandes',
                'value'      => $totalOrders,
                'icon'       => 'fa-solid fa-box',
                'color'      => 'info',
                'change'     => '+5%',
                'changeType' => 'positive',
                'route'      => 'orders.index',
                'details'    => [
                    ['label' => 'En attente', 'value' => $pendingOrders],
                ],
            ],
            [
                'label'      => 'Revenus',
                'value'      => number_format($totalRevenue, 0, ',', ' ') . ' FCFA',
                'icon'       => 'fa-solid fa-chart-line',
                'color'      => 'success',
                'change'     => '+8%',
                'changeType' => 'positive',
            ],
            [
                'label'      => 'Clients',
                'value'      => $totalClients,
                'icon'       => 'fa-solid fa-handshake',
                'color'      => 'warning',
                'change'     => '-2%',
                'changeType' => 'negative',
                'route'      => 'clients.index',
            ],
        ];
    }

    public function getWidgets(): array
    {
        $recentOrders = Order::with('client')
            ->latest()
            ->take(6)
            ->get()
            ->map(fn($o) => [
                'title'        => 'Commande #' . $o->id,
                'meta'         => $o->client?->name . ' · ' . $o->created_at->diffForHumans(),
                'value'        => number_format($o->total, 0, ',', ' ') . ' F',
                'badge'        => [
                    'label'   => ucfirst($o->status),
                    'variant' => match($o->status) {
                        'completed' => 'success',
                        'pending'   => 'warning',
                        'cancelled' => 'danger',
                        default     => 'gray',
                    },
                ],
                'route'        => 'orders.show',
                'route_params' => $o->id,
            ])->toArray();

        $activity = [
            ['icon' => 'fa-solid fa-user-plus',  'text' => '<strong>Nouveau client</strong> enregistré', 'time' => 'Il y a 5 min'],
            ['icon' => 'fa-solid fa-box',         'text' => 'Commande <strong>#1234</strong> validée',    'time' => 'Il y a 12 min', 'badge' => ['label' => 'Validée', 'variant' => 'success']],
            ['icon' => 'fa-solid fa-file-invoice','text' => 'Facture <strong>#89</strong> générée',       'time' => 'Il y a 1h'],
            ['icon' => 'fa-solid fa-truck',       'text' => 'Livraison <strong>#77</strong> en cours',    'time' => 'Il y a 2h', 'badge' => ['label' => 'En cours', 'variant' => 'info']],
        ];

        $topProducts = Product::withCount('orders')
            ->orderByDesc('orders_count')
            ->take(5)
            ->get()
            ->map(fn($p) => [
                'label' => $p->name,
                'value' => $p->orders_count . ' ventes',
                'percent' => min(100, ($p->orders_count / max(1, Product::max('orders_count'))) * 100),
                'color' => 'primary',
            ])->toArray();

        return [
            // Widget 1 — liste commandes récentes (2 colonnes)
            [
                'type'     => 'list',
                'title'    => 'Commandes récentes',
                'subtitle' => 'Les 6 dernières commandes',
                'span'     => 2,
                'data'     => $recentOrders,
                'actions'  => [
                    ['label' => 'Voir tout', 'route' => 'orders.index'],
                ],
            ],

            // Widget 2 — fil d'activité (1 colonne)
            [
                'type'     => 'activity',
                'title'    => 'Activité récente',
                'subtitle' => 'Derniers événements',
                'span'     => 1,
                'data'     => $activity,
            ],

            // Widget 3 — graphique évolution mensuelle (2 colonnes)
            [
                'type'       => 'chart',
                'title'      => 'Évolution des commandes',
                'subtitle'   => 'Par mois — 12 derniers mois',
                'span'       => 2,
                'chart_type' => 'line',
                'height'     => '240px',
                'data'       => [
                    'labels'   => ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'],
                    'datasets' => [[
                        'label'           => 'Commandes',
                        'data'            => [12, 19, 14, 22, 18, 25, 30, 27, 35, 28, 32, 40],
                        'borderColor'     => 'rgb(var(--mt-primary))',
                        'backgroundColor' => 'rgba(var(--mt-primary), 0.08)',
                        'fill'            => true,
                        'tension'         => 0.4,
                        'borderWidth'     => 2,
                    ]],
                ],
            ],

            // Widget 4 — top produits avec barres de progression (1 colonne)
            [
                'type'     => 'progress',
                'title'    => 'Top produits',
                'subtitle' => 'Par nombre de ventes',
                'span'     => 1,
                'data'     => $topProducts,
                'actions'  => [
                    ['label' => 'Tous les produits', 'route' => 'products.index'],
                ],
            ],
        ];
    }
}
