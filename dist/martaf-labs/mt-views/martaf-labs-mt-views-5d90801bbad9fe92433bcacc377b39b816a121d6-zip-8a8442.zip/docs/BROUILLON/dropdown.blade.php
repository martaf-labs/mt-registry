{{--
|--------------------------------------------------------------------------
| mt-views :: Composant anonyme — Dropdown
|--------------------------------------------------------------------------
|
| Usage:
|
|   <x-mt-dropdown>
|       <x-slot:trigger>
|           <button>Mon déclencheur</button>
|       </x-slot:trigger>
|
|       <x-mt-dropdown.item icon="fa-solid fa-gauge" label="Tableau de Bord" :href="route('dashboard')" />
|       <x-mt-dropdown.item icon="fa-solid fa-user" label="Mon profil" :href="route('profile')" />
|       <x-mt-dropdown.divider />
|       <x-mt-dropdown.item icon="fa-solid fa-gear" label="Paramètres" :href="route('settings')" />
|   </x-mt-dropdown>
|
| Props disponibles :
|   align        → left | right (défaut: right)
|   width        → sm | md | lg | full (défaut: md)
|   offsetY      → décalage vertical en px (défaut: 8)
|
--}}

@props([
    'align'   => 'right',
    'width'   => 'md',
    'offsetY' => 8,
])

@php
    $alignClass = match($align) {
        'left'  => 'left-0',
        'right' => 'right-0',
        default => 'right-0',
    };

    $widthClass = match($width) {
        'sm'   => 'w-48',
        'md'   => 'w-64',
        'lg'   => 'w-80',
        'full' => 'w-full',
        default => 'w-64',
    };
@endphp

<div
    class="relative"
    x-data="{ open: false }"
    @click.away="open = false"
    @keydown.escape.window="open = false"
>

    {{-- ── Slot déclencheur ── --}}
    <div @click="open = !open" class="cursor-pointer select-none">
        {{ $trigger }}
    </div>

    {{-- ── Panneau dropdown ── --}}
    <div
        x-show="open"
        x-cloak
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 scale-95 -translate-y-1"
        x-transition:enter-end="opacity-100 scale-100 translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 scale-100 translate-y-0"
        x-transition:leave-end="opacity-0 scale-95 -translate-y-1"
        class="
            absolute z-50 {{ $alignClass }} {{ $widthClass }}
            mt-[{{ $offsetY }}px]
            origin-top-{{ $align === 'left' ? 'left' : 'right' }}

            rounded-2xl overflow-hidden
            bg-white dark:bg-[rgb(var(--mt-bg,28_28_35))]
            border border-gray-100 dark:border-white/8
            shadow-2xl shadow-black/10 dark:shadow-black/40
            ring-1 ring-black/5 dark:ring-white/5

            divide-y divide-gray-100 dark:divide-white/6
        "
        style="margin-top: {{ $offsetY }}px"
    >
        {{ $slot }}
    </div>

</div>
