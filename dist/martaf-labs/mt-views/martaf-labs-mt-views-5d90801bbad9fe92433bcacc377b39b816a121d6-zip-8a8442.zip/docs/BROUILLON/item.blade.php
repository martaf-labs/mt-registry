{{--
|--------------------------------------------------------------------------
| mt-views :: dropdown/item.blade.php
|--------------------------------------------------------------------------
|
| Props :
|   label    → texte affiché            (requis)
|   icon     → classe FontAwesome        (ex: "fa-solid fa-user")
|   href     → URL de destination        (défaut: "#")
|   wire     → utilise wire:navigate     (défaut: true)
|   danger   → style rouge pour actions destructives (défaut: false)
|   badge    → petit badge numérique (optionnel)
|   active   → marquer l'item actif (défaut: false)
|
--}}

@props([
    'label'  => '',
    'icon'   => null,
    'href'   => '#',
    'wire'   => true,
    'danger' => false,
    'badge'  => null,
    'active' => false,
])

@php
    $baseClass = '
        group flex items-center gap-3 w-full px-4 py-2.5 text-sm
        rounded-none transition-all duration-150 cursor-pointer
    ';

    $colorClass = $danger
        ? 'text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 focus:bg-red-50 dark:focus:bg-red-500/10'
        : ($active
            ? 'text-[rgb(var(--mt-secondary,59_130_246))] bg-[rgb(var(--mt-secondary,59_130_246))]/8 font-semibold'
            : 'text-gray-700 dark:text-white/70 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-white/5 focus:bg-gray-50 dark:focus:bg-white/5'
        );

    $iconColorClass = $danger
        ? 'text-red-400'
        : ($active
            ? 'text-[rgb(var(--mt-secondary,59_130_246))]'
            : 'text-gray-400 dark:text-white/30 group-hover:text-gray-500 dark:group-hover:text-white/60'
        );
@endphp

<a
    href="{{ $href }}"
    @if($wire) wire:navigate @endif
    class="{{ $baseClass }} {{ $colorClass }}"
    role="menuitem"
>
    @if($icon)
        <i class="{{ $icon }} {{ $iconColorClass }} w-4 text-center text-sm transition-colors duration-150"></i>
    @endif

    <span class="flex-1 truncate">{{ $label }}</span>

    @if($badge)
        <span class="
            inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5
            text-[10px] font-bold rounded-full
            bg-[rgb(var(--mt-secondary,59_130_246))]/15 text-[rgb(var(--mt-secondary,59_130_246))]
        ">{{ $badge }}</span>
    @endif

    @if($active)
        <i class="fa-solid fa-check text-[10px] text-[rgb(var(--mt-secondary,59_130_246))] opacity-80"></i>
    @endif
</a>
