# Système de langues — mt-views

## Fichiers à intégrer

```
mt-views/
├── config/
│   └── mt-views.php                  ← ajouter les clés de mt-views_additions.php
├── lang/
│   ├── fr/mt-views.php               ✅ prêt
│   ├── en/mt-views.php               ✅ prêt
│   └── ar/mt-views.php               ✅ prêt
├── routes/
│   └── web.php                       ✅ prêt (route GET locale switch)
├── src/
│   ├── Helpers/
│   │   └── MtLocale.php              ✅ prêt
│   ├── Http/Middleware/
│   │   └── SetMtLocale.php           ✅ prêt
│   ├── Livewire/
│   │   └── LocaleSwitcher.php        ✅ prêt
│   └── MtViewsServiceProvider.php   ← intégrer MtViewsServiceProvider_additions.php
└── resources/views/
    ├── components/
    │   └── locale-switcher.blade.php ✅ prêt (version Blade GET)
    └── livewire/
        └── locale-switcher.blade.php ✅ prêt (version Livewire)
```

---

## 1. Intégrer dans MtViewsServiceProvider.php

```php
// Dans register()
$this->app->singleton(\Mtech\MtViews\Helpers\MtLocale::class);

// Dans boot()
$this->loadTranslationsFrom(__DIR__ . '/../lang', 'mt-views');
$this->loadRoutesFrom(__DIR__ . '/../routes/web.php');

$this->publishes([
    __DIR__ . '/../lang' => $this->app->langPath('vendor/mt-views'),
], 'mt-views-lang');

// Appliquer la locale sauvegardée en session
$locale = \Mtech\MtViews\Helpers\MtLocale::get();
$this->app->setLocale($locale);

// Livewire component
\Livewire\Livewire::component('mt-views::locale-switcher', \Mtech\MtViews\Livewire\LocaleSwitcher::class);
```

---

## 2. Ajouter le middleware (projet hôte)

### Laravel 11+ (`bootstrap/app.php`)
```php
->withMiddleware(function (Middleware $middleware) {
    $middleware->appendToGroup('web', \Mtech\MtViews\Http\Middleware\SetMtLocale::class);
})
```

### Laravel 10 (`app/Http/Kernel.php`)
```php
protected $middlewareGroups = [
    'web' => [
        // ...
        \Mtech\MtViews\Http\Middleware\SetMtLocale::class,
    ],
];
```

---

## 3. Utilisation dans les layouts

### Version Livewire (recommandée, mise à jour sans reload)
```blade
<livewire:mt-views::locale-switcher />
```

### Version Blade + GET (plus simple, reload page)
```blade
<x-mt-views::locale-switcher />
{{-- ou aligné à gauche : --}}
<x-mt-views::locale-switcher align="left" />
```

---

## 4. Traduire les strings des composants

```blade
{{-- Avant --}}
<span>Rechercher...</span>

{{-- Après --}}
<span>{{ __('mt-views::mt-views.search') }}</span>

{{-- Ou avec le helper --}}
<span>{{ \Mtech\MtViews\Helpers\MtLocale::trans('search') }}</span>
```

---

## 5. Surcharger les traductions (projet hôte)

```bash
php artisan vendor:publish --tag=mt-views-lang
```

Cela copie les fichiers dans `lang/vendor/mt-views/` pour surcharge locale.

---

## 6. Ajouter une nouvelle locale

Dans `config/mt-views.php` du projet hôte :
```php
'available_locales' => [
    'fr' => ['label' => 'Français', 'flag' => '🇫🇷'],
    'en' => ['label' => 'English',  'flag' => '🇬🇧'],
    'ar' => ['label' => 'العربية',  'flag' => '🇹🇩'],
    'de' => ['label' => 'Deutsch',  'flag' => '🇩🇪'], // ← nouvelle langue
],
```

Créer le fichier `lang/vendor/mt-views/de/mt-views.php`.

---

## Support RTL (arabe)

Pour activer le RTL automatiquement dans les layouts, ajouter dans `master.blade.php` :
```blade
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}">
```
