# COMPOSANT BASE-PROFILE #

**Schéma fonctionnel des composants**
Profiles/GenericProfile -> 
Profiles/*{Model}*Profile -> 
Admin/*{Model}*ProfileComponent -> 


## STRUCTURE GLOBALE DE L'INTERFACE**


### SIDEBAR



### MODULES GLOBALS
ce sont des modules pouvant être intégré sur n'mporte quel section de la page

**I- SIDEBAR**
Les composants de la sideBar..

1. **requiredItemsList**

- *Implémentation*

```
protected function profileSideBar($model, $profileId=null) : array
    {
        $datas=[];

        $requiredIitems = [
            'formulaire' => [
                'status' => 'complete',
                'icon' => "fa-solid fa-file-pdf",
                'text' => "Formulaire",
                'subText' => 'Complété et signé',
            ],
            'acte-naissance' => [
                'status' => 'complete',
                'icon' => "fa-solid fa-file-pdf",
                'text' => "Acte de Naissance",
                'subText' => 'Photocopie authentique',
            ],
        ];
        //ajout du requiredItemsList
        $datas['requiredItemsList']=[
            'title' => "Documents exigés",
            'items' => $requiredIitems,
        ];
        return $datas ?? [];

    }

```
-> **Important**:
Les differents *status* des *items* de *requiredItemsList* sont: **completed, pending et missing**

---

2. **detailsItemsList**

- *Implémentation*

```
protected function profileSideBar($model, $profileId=null) : array
    {
        $datas=[];

        $detailsItems=$model->etudiantClasse->classe->frais->map(function($i){
            return [
                'text'=>Frais::types()[$i->type],
                'value'=>$i->formatMontant(true)
            ];
        })->toArray();

        $datas['detailsItemsList']=[
            'title' => "Frais d'inscription",
            'items' => $detailsItems,
            'total' => $model->fraisTotal(true),
            'infos' => "Le paiement par tranche est possible.",
        ];

        return $datas ?? [];

    }

```
-> **Important**:
Le composant utilisé: **details-items-list**

---

3. **actionsHistory**

- *Implémentation*

```
protected function profileSideBar($model, $profileId=null) : array
    {
        $datas=[];

        $historyItems=[
            'inscription' => [
                'status' => !is_null($model)? 'completed' : 'current',
                'text' => "Inscription soumise",
                'subText' => $model->created_at." par ".$model->user->userable->fullName(),
            ],
            'doc' => [
                'status' => 'current',
                'text' => "Documents reçus",
                'subText' => $model->created_at." par ".$model->user->userable->fullName(),
            ],
            'entretien' => [
                'status' => 'pending',
                'text' => "Entretien réalisé",
                'subText' => $model->created_at." par ".$model->user->userable->fullName(),
            ],
        ];

        $datas['actionsHistory']=[
            'title' => "Historique des actions",
            'items' => $historyItems,
        ];
        
        return $datas ?? [];

    }

```
-> **Important**:
Les differents *status* des *items* de *actionsHistory* sont: **completed, pending et current**.
Le composant utilisé: **actions-history**

---

**II- CONTENU PRINCIPAL**
Les composants du contenu principal..
1. **profileProcess**
Cette section permet de représenter un processus par étapes.

- *Implémentation*

```
protected function profileProcess($model) : array
    {
        return [
            'processus_inscription' =>[
                'title' => 'Processus d\'inscription',
                'steps' => [
                    'Soumission' => [
                        'status' => 'completed',
                        'icon' => 'fa-solid fa-check',
                        'text' => 'Soumission',
                        'subText' => $model->formatDate(),
                    ]
                ]
            ],
        ];

    }

    //utilisation du composant "step-indicator"

```

2. **personalInfos**
Cette section permet de représenter les informations personnelles.

- *Implémentation*

```
protected function personalInfos($model) : array
    {
        return [
            'model1' => [
                'title' => "informations du model1",
                'image' => nullable,
                'icone' => nullable,
                'fields' => [
                    'field1' => [
                        'type' => 'text',
                        'label' => 'LabelField1',
                        'value' => $model1->field1,
                        'col' => 6,
                    ],
                    'actions' => [
                        'action1' => [
                            'type' => 'typeAction1',
                            'label' => 'labelAction1',
                            'icon' => "iconAction1",
                            'route' => routeAction1,
                        ],
                    ],
                ],
            ],
        ];

    }

    /**
    *Important: Les action doivent utiliser les heroicons
    **/
```

---

■ actions
■ modules
