<?php

namespace Mt\MtViews\Database\Seeders;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Mt\MtViews\Enums\RolesUser;
use Mt\MtViews\Models\BaseUser;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        //recupération et enregistrement des permissions
        $models = [];

        $modelsOtherPath=base_path('vendor\mt\mt-views\src\Models\\');
        foreach (glob($modelsOtherPath . '/*.php') as $file) {

            $class = 'Mt\\MtViews\\Models\\' . pathinfo($file, \PATHINFO_FILENAME);

            if (class_exists($class) && is_subclass_of($class, Model::class)) {
                $models[] = $class;
            }
        }

        $modelsPath=base_path('vendor\mt\sgni-shared\src\Models\\');
        foreach (glob($modelsPath . '/*.php') as $file) {

            $class = 'Mt\\SgniShared\\Models\\' . pathinfo($file, \PATHINFO_FILENAME);

            if (class_exists($class) && is_subclass_of($class, Model::class)) {
                $models[] = $class;
            }
        }

        foreach ($models as $model) {

            $nameModel = basename($model);

            $permissions = ['voir', 'modifier', 'supprimer', 'contrôle total'];

            foreach ($permissions as $permissionName) {
                // Créer ou mettre à jour la permission
                Permission::firstOrCreate(
                    [
                        'name' => $permissionName.' '.$nameModel,
                        'guard_name' => 'web'
                    ],
                    // ['guard_name' => 'web'] // si on utilise "web" comme guard
                );
            }
        }


        // recuperation et enregistrement des rôles
        $roles = array_keys(RolesUser::options());

        // Créer les rôles
        foreach ($roles as $roleName) {
            $role = Role::firstOrCreate([
                'name' => $roleName,
                'guard_name' => 'web'
            ]);

            // Exemple : tous les rôles n'ont pas toutes les permissions: le "super-admin" a le controle totale (technique et administratif) de l'application et l'"admin" a le controle administratif seulement ;
            if ($roleName === RolesUser::DEVELOPPEUR->value  && $roleName === RolesUser::ADMINISTRATEUR->value) {
                $role->syncPermissions(Permission::all());
            }
        }
    }
}
