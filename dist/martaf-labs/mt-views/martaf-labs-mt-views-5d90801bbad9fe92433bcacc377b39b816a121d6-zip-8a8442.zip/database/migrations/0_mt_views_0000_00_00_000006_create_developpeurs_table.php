<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if(!Schema::hasTable('developpeurs')){
            Schema::create('developpeurs', function (Blueprint $table) {
                $table->id();
                $table->string('nom');
                $table->string('prenom');
                $table->string('sexe');
                $table->string('civilite');
                $table->string('naissance');
                $table->string('email')->unique(); 
                $table->string('telephone')->nullable();
                $table->string('image')->nullable();
                $table->string('specialite')->nullable();
                $table->text('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('developpeurs');
    }
};
