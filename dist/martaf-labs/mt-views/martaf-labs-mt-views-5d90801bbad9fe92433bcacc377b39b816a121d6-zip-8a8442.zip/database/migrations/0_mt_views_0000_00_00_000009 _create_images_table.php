<?php

use Mt\SgniShared\Models\Equipement;
use Mt\SgniShared\Models\Image;
use Mt\SgniShared\Models\Chantier;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if(!Schema::hasTable('images')){
            Schema::create('images', function (Blueprint $table) {
                $table->id();
                $table->string('model_type');
                $table->unsignedBigInteger('model_id');
                $table->string('type');
                $table->string('title')->nullable();
                $table->string('path');
                $table->text('description')->nullable();
                $table->integer('order')->default(0);
                $table->boolean('actif')->default(true);
                $table->boolean('is_featured')->default(false);
                $table->json('metadata')->nullable();
            
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('images');
    }
};
