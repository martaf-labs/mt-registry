<?php

namespace Mt\MtViews\View\Components;

use Illuminate\View\Component;

class Tinymce extends Component
{
    public $model;
    public $id;
    public $placeholder;

    public function __construct($model, $placeholder = '')
    {
        $this->model = $model;
        $this->placeholder = $placeholder;
        $this->id = 'tinymce-' . uniqid();
    }

    public function render()
    {
        return view('mt::components.tinymce');
    }
}
