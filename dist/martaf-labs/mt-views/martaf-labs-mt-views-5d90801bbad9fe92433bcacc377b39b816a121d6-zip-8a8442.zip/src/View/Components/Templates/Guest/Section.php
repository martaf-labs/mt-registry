<?php

namespace Mt\MtViews\View\Components\Templates\Guest;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class Section extends Component
{
    public string $title;
    public string $description;
    public ?string $classes = null;
    /**
     * Create a new component instance.
     */
    public function __construct($title='', $description='', $classes=null)
    {
        $this->title=$title;
        $this->description=$description;
        $this->classes=$classes;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('mt::components.templates.guest.section');
    }
}
