<?php

namespace Mt\MtViews\Helpers;

use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class MtLocale
{
    /**
     * Retourne la locale active (session > config > app.locale)
     */
    public static function get(): string
    {
        return Session::get('mt_locale', config('app.locale', App::getLocale()));
    }

    /**
     * Définit la locale active en session et pour l'app Laravel
     */
    public static function set(string $locale): void
    {
        $available = array_keys(static::available());

        if (! in_array($locale, $available)) {
            return;
        }

        Session::put('mt_locale', $locale);
        App::setLocale($locale);
    }

    /**
     * Retourne les locales disponibles depuis la config
     */
    public static function available(): array
    {
        $availableLocales = config('app.available_locales', ['fr']);

        $codesLocales = [
            'fr' => ['label' => 'Français', 'flag' => 'FR', 'icon' => 'language-fr'],
            'en' => ['label' => 'English', 'flag' => 'EN', 'icon' =>  'language-en'],
            'ar' => ['label' => 'العربية', 'flag' => 'AR', 'icon' => 'language-ar']
        ];

        return array_filter(
            $codesLocales,
            fn($code) => in_array($code, $availableLocales),
            ARRAY_FILTER_USE_KEY // Indique à PHP d'utiliser les clés ('fr', 'ar'...) pour le filtre
        );

    }

    /**
     * Traduit une clé du namespace mt-views
     */
    public static function trans(string $key, array $replace = []): string
    {
        return __("mt-views::mt-views.{$key}", $replace);
    }

    /**
     * Vérifie si une locale est la locale active
     */
    public static function is(string $locale): bool
    {
        return static::get() === $locale;
    }

    /**
     * Retourne les infos de la locale active
     */
    public static function current(): array
    {
        $locale = static::get();
        $upperLocale = Str::upper($locale);
        $available = static::available();

        return $available[$locale] ?? ['label' => $locale, 'flag' => $upperLocale, 'icon' => "language-$locale"];
    }
}
