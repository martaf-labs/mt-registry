<?php

use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Livewire\Component;
use Mt\MtViews\Enums\RolesUser;
use Mt\MtViews\Helpers\MtLocale;
use Mt\MtViews\Helpers\NavHelper;
use Mt\MtViews\Helpers\ViewHelper;
use Mt\MtViews\Models\User;
use Mt\MtViews\Notifications\HandleNotification;
use Mt\MtViews\Services\ModalService;
use Mt\MtViews\Support\IconManager;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;

/**
 * Recuperer un element de configuration de "mt-views"
 */
if (!function_exists('mt_config')) {
    function mt_config(string $key) {
        if (is_null($key)) {
            return '';
        }
        return config("mt-views.$key");
    }
}

/**
 * Recuperer le tableau des langues configurées
 */
if (!function_exists('get_available_locales')) {
    function get_available_locales() {
        
        return MtLocale::available();
    }
}

/**
 * Racourci de traduction pour le namespace mt-views.
 */
if (!function_exists('mt_translate')) {
    function mt_translate(string $key) {
        if (is_null($key)) {
            return '';
        }
        return MtLocale::trans($key);
    }
}

/**
 * convertir une chaine hexa en rgb
 */
if (!function_exists('hexaToRgb')) {
    /**
     * convertir une chaine hexadécimal en RGB
     * @param string $value
     */     
    function hexaToRgb(?string $value) {
        if (is_null($value)) {
            return '';
        }

        // on retire le # si présent
        $value = ltrim($value, '#');
        // on verifit si c'est un format hexadécimal(3 ou 6 caractères)
        if (ctype_xdigit($value) && strlen($value) === 3 || strlen($value) === 6) {
            
            if (strlen($value) === 3) {
                $r = hexdec(str_repeat(substr($value, 0, 1), 2));
                $g = hexdec(str_repeat(substr($value, 1, 1), 2));
                $b = hexdec(str_repeat(substr($value, 2, 1), 2));
            }
            else{
                $r = hexdec(substr($value, 0, 2));
                $g = hexdec(substr($value, 2, 2));
                $b = hexdec(substr($value, 4, 2));
            }
            return "$r, $g, $b";
        }

        return $value;
    }
}

/**
 * Layout actif
 */
if (!function_exists('getActiveLayout')) {
    function getActiveLayout() {
        return session('active_layout');
    }
}

/**
 * Niveau d'accès utilisateur
 */
if (!function_exists('get_access_level')) {
    function get_access_level() {
        $user = Auth::user();
        if (!$user) return 999;

        $roles = $user->roles;
        $levels = [];
        foreach ($roles as $role) {
            $levels[] = User::getAccessLevels()[$role->name] ?? 999;
        }
        return min($levels);
    }
}

if (!function_exists('has_access_level')) {
    function has_access_level($maxLevel) {
        return get_access_level() <= $maxLevel;
    }
}

if (!function_exists('has_role')) {
    function has_role(array $roles) {
        $user = Auth::user();
        if (!$user) return false;
        foreach ($roles as $role) {
            if ($user->hasRole($role)) return true;
        }
        return false;
    }
}

if (!function_exists('is_dev')) {
    function is_dev(): bool {
        return Auth::user()->hasRole(RolesUser::DEVELOPPEUR->value);
    }
}

if (!function_exists('is_admin')) {
    function is_admin(): bool {
        return Auth::user()->hasRole(RolesUser::ADMINISTRATEUR->value);
    }
}

if (!function_exists('can_access')) {
    function can_access($permission) {
        return auth()->check() && auth()->user()->hasPermissionTo($permission);
    }
}

/**
 * Gestion des viewItems
 */
if (!function_exists('viewItems')) {
    function viewItems(string $model, string $mainLabel): ViewHelper {
        return new ViewHelper($model, $mainLabel);
    }
}

/**
 * Gestion des navItems
 */
if (!function_exists('navItems')) {
    function navItems(string $model, string $mainLabel): NavHelper {
        return new NavHelper($model, $mainLabel);
    }
}

/**
 * Session formulaire
 */
if (!function_exists('formSession')) {
    function formSession(string $model) {
        return session("formSessionData.{$model}") ?? null;
    }
}

/**
 * Disque de stockage
 */
if (!function_exists('mt_get_storage_disk')) {
    function mt_get_storage_disk() {
        return config('app.storage_disk') ?? '';
    }
}

/**
 * chemin cdn
 */
if (!function_exists('cdn_path')) {
    function cdn_path($path)
    {
        return Storage::disk(mt_get_storage_disk())->url($path);//$cdnPath . '/' . ltrim($path, '/');
    }

}

/**
 * Assets partagés
 */
if (!function_exists('mt_shared')) {
    function mt_shared($path = '') {
        return rtrim(config('app.mt_shared_url'), '/') . '/' . ltrim($path, '/');
    }
}

/**
 * Résolution de chaîne ou constante
 */
if (!function_exists('resolve_string')) {
    function resolve_string($code) {
        if (!str_contains($code, '::')) return $code;
        [$class, $const] = explode('::', $code);
        if (class_exists($class) && defined("{$class}::{$const}")) return constant("{$class}::{$const}");
        return $code;
    }
}

if (!function_exists('resolve_count')) {
    function resolve_count($code) {
        return eval("return $code;");
    }
}

/**
 * Sidebar
 */
if (!function_exists('getSidebar')) {
    function getSidebar(): array {
        $sideBarItems = config('sidebar');
        $currentUrl = request()->fullUrl();
        $activeKey = null;

        foreach ($sideBarItems as &$item) {
            $item['key'] = $item['key'] ?? Str::slug($item['label']);
            $item['icon'] = isset($item['icon']) ? get_icone($item['icon']) : null;
            $item['count'] = isset($item['count']) ? add_zero(resolve_count($item['count'])) : null;
            $item['isActive'] = false;

            $itemParams = $item['params'] ?? [];
            foreach ($itemParams as $k => $v) if (str_contains($v, '::')) $itemParams[$k] = constant($v);

            if (isset($item['route'])) $item['route'] = mt_get_route($item['route'], $itemParams);

            if (!empty($item['route'])) {
                $currentPath = parse_url($currentUrl, PHP_URL_PATH);
                $itemPath = parse_url($item['route'], PHP_URL_PATH);
                if ($item['route'] === $currentUrl || $itemPath === $currentPath) {
                    $item['isActive'] = true;
                    $activeKey = $item['key'];
                }
            }

            if (!empty($item['subItems'])) {
                foreach ($item['subItems'] as &$sub) {
                    $sub['key'] = $sub['key'] ?? Str::slug($sub['label']);
                    $sub['icon'] = isset($sub['icon']) ? get_icone($sub['icon']) : null;
                    $sub['count'] = isset($sub['count']) ? add_zero(resolve_count($sub['count'])) : null;
                    $sub['isActive'] = false;

                    $subParams = $sub['params'] ?? [];
                    foreach ($subParams as $k => $v) if (str_contains($v, '::')) $subParams[$k] = constant($v);

                    if (isset($sub['route'])) $sub['route'] = mt_get_route($sub['route'], $subParams);

                    if (!empty($sub['route']) && $sub['route'] === $currentUrl) {
                        $sub['isActive'] = true;
                        $item['isActive'] = true;
                        $activeKey = $sub['key'];
                    }
                }
            }
        }

        if ($activeKey) session(['active_sidebar_key' => $activeKey]);
        return $sideBarItems;
    }
}

/**
 * Icônes et routes
 */
if (!function_exists('get_icone')) {
    function get_icone(string $item) {
        return config('app.icones')[$item] ?? '';
    }
}

if (!function_exists('mt_get_route')) {
    function mt_get_route(string $item, array $parametres = []): string
    {
        try {
            // Récupération du nom de la route dans le fichier de configuration
            $routeName = config('routes.' . $item);

            // Si la route n'est pas définie dans la configuration
            if (empty($routeName)) {
                return '';
            }

            // Vérifie si la route existe réellement dans Laravel
            if (!\Illuminate\Support\Facades\Route::has($routeName)) {
                return '';
            }

            // Retourne l'URL générée
            return route($routeName, $parametres);
        } catch (\Throwable $e) {
            // En cas d'erreur (ex: paramètres manquants), on retourne aussi une chaîne vide
            return '';
        }
    }
}


/**
 * Highlight texte
 */
if (!function_exists('markTerms')) {
    function markTerms(string $phrase='', string $expression='') {
        if (strlen($phrase) > 0 && strlen($expression) > 0) {
            return preg_replace_callback('/'.preg_quote($expression, '/').'/i', fn($matches) => '<mark>'.$matches[0].'</mark>', $phrase);
        }
        return '';
    }
}

/**
 * Verifier si le fichier dont le chemin est fournit existe
 */
if (!function_exists('mt_file_exists')) {

    function mt_file_exists(?string $path, ?string $disk = null, int $ttl = 300 // cache en secondes
    ): bool {

        $disk = mt_get_storage_disk();

        if(!is_string($path)){
            return false;
        }

        $path = trim($path);
        
        if ($path === '') {
            return false;
        }

        if ($path ==='/' || $path === '.' || $path === '..') {
            return false;
        }

        $cacheKey = 'file_exists:' . md5($disk . '|' . $path);

        return Cache::remember($cacheKey, $ttl, function () use ($path, $disk) {

            // 1. URL distante
            if (filter_var($path, FILTER_VALIDATE_URL)) {
                try {
                    $response = Http::timeout(5)->head($path);

                    if ($response->successful()) {
                        return true;
                    }

                    // fallback si HEAD refusé
                    if (in_array($response->status(), [403, 405])) {
                        $response = Http::timeout(5)->get($path);
                        return $response->successful();
                    }

                    return false;

                } catch (\Throwable $e) {
                    return false;
                }
            }

            // 2. Disk Laravel (S3, public, etc.)
            if ($disk) {
                try {
                    if (!Storage::disk($disk)->exists($path)) {
                        return false;
                    }

                    // éviter les dossiers
                    return !Str::endsWith($path, '/');

                } catch (\Throwable $e) {
                    return false;
                }
            }

            // 3. Fichier local (ultra rapide)
            return is_file($path);
        });
    }
}

/**
 * Notification
 */
if (!function_exists('notifier')) {
    function notifier($userIds, array $data) {
        $ids = is_array($userIds) ? $userIds : [$userIds];
        foreach ($ids as $id) {
            $user = User::find($id);
            if ($user) $user->notify(new HandleNotification(...$data));
        }
    }
}

/**
 * Format nombre
 */
if (!function_exists('add_zero')) {
    function add_zero($nbre): string {
        $nbre = (int)$nbre;
        if (0 < $nbre && $nbre < 10) return '0'.$nbre;
        if ($nbre < 1_000) return (string)$nbre;
        if ($nbre < 1_000_000) return round($nbre / 1_000, 1).'K';
        if ($nbre < 1_000_000_000) return round($nbre / 1_000_000, 1).'M';
        return round($nbre / 1_000_000_000, 1).'Md';
    }
}

/**
 * Vérification intervalle
 */
if (!function_exists('inRange')) {
    function inRange(int $val, int $min, int $max): int {
        return $val >= $min && $val <= $max;
    }
}

/**
 * Temps écoulé
 */
if (!function_exists('tempsEcoule')) {
    function tempsEcoule($debut, $fin = null, $abrege = false, $prefixe = false, $type = null) {
        try {
            $now = is_null($fin) ? Carbon::now() : Carbon::parse($fin);
            $debut = Carbon::parse($debut);
        } catch (\Exception $e) {
            return null;
        }

        $future = $debut->greaterThan($now);
        $ref1 = $future ? $now : $debut;
        $ref2 = $future ? $debut : $now;

        if ($type) {
            $type = strtolower($type);
            $val = 0;
            $label = '';

            switch ($type) {
                case 'seconde': case 's': $val = $ref1->diffInSeconds($ref2); $label = $abrege?'s':'seconde'.($val>1?'s':''); break;
                case 'minute': case 'min': $val = $ref1->diffInMinutes($ref2); $label = $abrege?'min':'minute'.($val>1?'s':''); break;
                case 'heure': case 'h': $val = $ref1->diffInHours($ref2); $label = $abrege?'h':'heure'.($val>1?'s':''); break;
                case 'jour': case 'j': $val = $ref1->diffInDays($ref2); $label = $abrege?'j':'jour'.($val>1?'s':''); break;
                case 'semaine': case 'sem': $val = floor($ref1->diffInDays($ref2)/7); $label = $abrege?'sem':'semaine'.($val>1?'s':''); break;
                case 'mois': $val = $ref1->diffInMonths($ref2); $label = 'mois'; break;
                case 'an': case 'annee': $val = $ref1->diffInYears($ref2); $label = $abrege?'an':'an'.($val>1?'s':''); break;
            }

            return ($prefixe ? ($future?'dans ':'il y a ') : '').add_zero($val).' '.$label;
        }

        $diff = $ref1->diff($ref2);
        $joursTotal = $ref1->diffInDays($ref2);
        $semaines = floor($joursTotal / 7);
        $resteJours = $joursTotal % 7;
        $parts = [];

        if ($diff->y > 0) $parts[] = add_zero($diff->y).' '.($abrege?'an':'an'.($diff->y>1?'s':''));
        if ($diff->m > 0) $parts[] = add_zero($diff->m).' mois';
        if ($semaines > 0) $parts[] = add_zero($semaines).' '.($abrege?'sem':'semaine'.($semaines>1?'s':''));
        if ($resteJours > 0) $parts[] = add_zero($resteJours).' '.($abrege?'j':'jour'.($resteJours>1?'s':''));
        if ($diff->h>0 && empty($parts)) $parts[] = add_zero($diff->h).' '.($abrege?'h':'heure'.($diff->h>1?'s':''));
        if ($diff->i>0 && empty($parts)) $parts[] = add_zero($diff->i).' '.($abrege?'min':'minute'.($diff->i>1?'s':''));
        if ($diff->s>0 && empty($parts)) $parts[] = add_zero($diff->s).' '.($abrege?'s':'seconde'.($diff->s>1?'s':''));

        $texte = implode(' et ', array_slice($parts,0,2));
        return $prefixe ? ($future?'dans '.$texte:'il y a '.$texte) : $texte;
    }
}


/**
 * affichage des alerts
 */
if (!function_exists('showAlert')) {
    function showAlert(string $type, string $message, bool $flash=true) {

        // on recupère le composant actuel
        $component=\Livewire\Livewire::current();
        

        if ($component) {
            switch ($type) {
                case 'success':
                    $component->dispatch('open-alert-modal',
                ModalService::success($message)
                    );
                    break;
                case 'error':
                    $component->dispatch('open-alert-modal',
                ModalService::error($message)
                    );
                    break;

                default:
                    break;
            }  
        }

        // if ($flash) {
        //     session()->flash('open-alert-modal', ModalService::success($message));
        // } else {
        //     \Livewire\Livewire::dispatch('open-alert-modal', ModalService::success($message));
        // }
        
    }
}


/**
 * Recuperer les initiales d'un mot ou d'une expression
 */
if (!function_exists('getInitials')) {
    function getInitials(?string $name, int $limit = 2, string $fallback = '..'): string
    {
        $name = trim($name ?? '');
        $name = Str::slug($name, '');

        if (empty($name)) return $fallback;

        $words = preg_split('/\s+/u', $name, -1, PREG_SPLIT_NO_EMPTY);
        
        if (count($words) === 1) {
            return mb_strtoupper(mb_substr($words[0], 0, $limit));
        }

        return collect($words)
            ->filter()
            ->map(fn ($word) => mb_strtoupper(mb_substr($word, 0, 1)))
            ->take($limit)
            ->implode('') ?: $fallback;
    }

}


/**
 * convertir une chaine de caratère en nombre
 */
if (!function_exists('toNumber')) {
    function toNumber(string $value): int|float|null
    {
        $value= trim($value ?? '');

        // remplacer virgule décimale par un point
        // Mais laisser les virgules de miliers

        if (strpos($value, ',') !== false && strpos($value, '.') === false ) {
            $value=str_replace(',', '.', $value);
        }

        // supprimer les espaces et séparateur de miliers
        $value = str_replace([' ', ','], [' ', ' '], $value);


        // verifier que c'est numérique
        if (!is_numeric($value)) {
            return null;
        }

        // Si c'est un entier
        if (ctype_digit($value)) {
            return (int)$value;
        }

        //sinon un float
        return (floor($value) == $value) ? (int)$value : $value;
    }

    if (! function_exists('mt_icon')) {
        /**
         * Recuperer l'icone (code svg)
         * @param string $name
         * @return array|string|null
         */
        function mt_icon(string $name): ?string
        {
            // 1. Override projet
            $customPath = resource_path("views/mt-icons/{$name}.svg");

            if (file_exists($customPath)) {
                return str_replace(
                    '<svg',
                    '<svg class="w-full h-full"',
                    file_get_contents($customPath)
                );
            }

            // 2. Icône du package
            $packagePath = dirname(__DIR__).'/../resources/views/icons/' . $name . '.svg';
            // dd($packagePath);

            if (file_exists($packagePath)) {
                return str_replace(
                    '<svg',
                    '<svg class="w-full h-full"',
                    file_get_contents($packagePath)
                );
            }

            return null;
        }
    }


    if (!function_exists('mt_icons')) {
        function mt_icons(): array
        {
            return IconManager::all();
        }
    }

    if (!function_exists('mt_icon_exists')) {
        function mt_icon_exists(string $name): bool
        {
            return IconManager::exists($name);
        }
    }


    if (!function_exists('mt_colors')) {
        /**
         * Récupère la liste de toutes les couleurs définies dans la configuration.
         *
         * @return array La liste des couleurs, ou un tableau vide si aucune configuration n'est trouvée.
         */
        function mt_colors(): array
        {
            return config('mt-views.default_colors', []);
        }
    }


    // helpers recherches

    if (!function_exists('mt_has_search')) {
        function mt_has_search(): bool
        {
            return !empty(config('mt-search.providers', []));
        }
    }

}


// incorporation des helpers
require_once __DIR__ . '/views-config-helpers.php';