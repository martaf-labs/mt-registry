<?php

namespace Mt\MtViews\Contracts;

interface HasBaseFormContract
{
    /**
     * @return array
     */
    public function fieldActions():array;
}