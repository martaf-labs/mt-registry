<?php

namespace Mt\MtViews\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Mt\MtViews\Contracts\ImageOptimizerContract;

class OptimizeImagesCommand extends Command
{
    protected $signature = 'mt:images:optimize
                            {path? : Sous-dossier à traiter (optionnel)}
                            {--disk= : Disque (défaut : config mt-views)}
                            {--webp : Forcer la génération WebP}
                            {--avif : Forcer la génération AVIF}
                            {--quality= : Qualité 1-100}
                            {--dry-run : Simuler sans modifier}';

    protected $description = '[mt-views] Optimise les images du disque de stockage';

    public function handle(ImageOptimizerContract $optimizer): int
    {
        $diskName = $this->option('disk') ?: config('mt-views.image_optimizer.disk', 'public');
        $path     = $this->argument('path') ?: '/';
        $dryRun   = $this->option('dry-run');

        $disk   = Storage::disk($diskName);
        $images = array_filter(
            $disk->allFiles($path),
            fn ($f) => in_array(strtolower(pathinfo($f, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif', 'webp'])
        );

        $total = count($images);

        if ($total === 0) {
            $this->warn('Aucune image trouvée dans ' . $path);
            return self::SUCCESS;
        }

        $this->info("🖼️  <fg=blue>[mt-views]</> {$total} image(s) sur le disque [{$diskName}]");

        if ($dryRun) {
            $this->warn('Mode --dry-run : aucune modification.');
            foreach ($images as $f) $this->line("  · {$f}");
            return self::SUCCESS;
        }

        $options = [];
        if ($this->option('webp'))    $options['convert_to_webp'] = true;
        if ($this->option('avif'))    $options['convert_to_avif'] = true;
        if ($this->option('quality')) $options['quality'] = ['jpg' => (int) $this->option('quality'), 'webp' => (int) $this->option('quality')];

        $bar        = $this->output->createProgressBar($total);
        $totalSaved = 0;
        $ok = $fail = 0;

        foreach ($images as $file) {
            $result = $optimizer->optimizePath($disk->path($file), $options);
            $result->success ? ($ok++ && ($totalSaved += $result->savedBytes())) : $fail++;
            $bar->advance();
        }

        $bar->finish();
        $this->newLine(2);

        $this->table(['Métrique', 'Valeur'], [
            ['✅ Optimisées',      $ok],
            ['❌ Erreurs',         $fail],
            ['💾 Espace économisé', $this->formatBytes($totalSaved)],
        ]);

        return self::SUCCESS;
    }

    private function formatBytes(int $b): string
    {
        if ($b < 1024)    return "{$b} B";
        if ($b < 1048576) return round($b / 1024, 2) . ' KB';
        return round($b / 1048576, 2) . ' MB';
    }
}
