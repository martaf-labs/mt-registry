<?php

namespace Mt\MtViews;

use Livewire\Livewire;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Mt\MtViews\Helpers\MtLocale;
use Mt\MtViews\Services\ModalService;

/**
 * MtViewsServiceProvider
 *
 * Service provider principal de mt-views.
 * Gère TOUTE l'interface graphique de l'écosystème martaf-labs :
 *
 *   - Composants Blade anonymes et de classe
 *   - Composants Livewire (UI, Auth, Settings, Search, Modals)
 *   - Layouts et vues partagées
 *   - Middlewares UI
 *   - Directives Blade personnalisées
 *   - Assets CSS/JS
 *
 * Principe : tout ce qui touche à l'affichage est ici.
 * La logique métier (models, services, migrations) est dans
 * les packages dédiés (mt-auth, mt-images, mt-search...).
 *
 * Dépend de : mt-foundation
 */
class MtViewsServiceProvider extends ServiceProvider
{
    /**
     * Chemin racine du package.
     */
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        $this->basePath = dirname(__DIR__);
    }

    /**
     * Enregistre les bindings dans le conteneur IoC.
     * Appelé avant boot(), idéal pour les bindings simples.
     */
    public function register(): void
    {
        // Configuration principale du package
        $this->mergeConfigFrom(
            $this->basePath . '/config/mt-views.php',
            'mt-views'
        );

        // Singleton pour la gestion des locales UI
        $this->app->singleton(MtLocale::class);

        // Singleton pour le service des modals
        $this->app->singleton(ModalService::class);
    }

    /**
     * Démarre les services du package.
     * Appelé après register(), une fois tous les providers chargés.
     */
    public function boot(): void
    {
        $viewsPath = $this->basePath . '/resources/views';
        $langPath  = $this->basePath . '/lang';

        // 1. Routes UI du package
        $this->registerRoutes();

        // 2. Vues avec namespace 'mt'
        //    Permet @include('mt::...') et les composants de classe
        $this->loadViewsFrom($viewsPath, 'mt');

        // 3. Composants Blade anonymes
        //    Permet <x-mt::button />, <x-mt::card />, etc.
        if (is_dir($viewsPath . '/components')) {
            Blade::anonymousComponentPath($viewsPath . '/components', 'mt');
        }

        // 4. Traductions
        $this->loadTranslationsFrom($langPath, 'mt-views');

        // 5. Middlewares
        $this->registerMiddlewares();

        // 6. Directives Blade personnalisées
        $this->registerBladeDirectives();

        // 7. Composants Livewire
        $this->registerLivewireComponents();

        // 8. Publication des ressources (console uniquement)
        if ($this->app->runningInConsole()) {
            $this->registerPublishing($viewsPath, $langPath);
        }
    }

    /**
     * Charge les routes UI du package.
     *
     * Note : les routes de recherche sont gérées par mt-search.
     */
    protected function registerRoutes(): void
    {
        $routesPath = $this->basePath . '/routes/web.php';

        if (file_exists($routesPath)) {
            $this->loadRoutesFrom($routesPath);
        }
    }

    /**
     * Enregistre les middlewares du package.
     *
     * mt.layout → contrôle le layout actif selon la route
     *
     * Note : SetMtLocale est géré par mt-auth car il dépend
     * de la session utilisateur (logique métier).
     */
    protected function registerMiddlewares(): void
    {
        $this->app['router']->aliasMiddleware(
            'mt.layout',
            \Mt\MtViews\Http\Middleware\SetActiveLayoutMiddleware::class
        );
    }

    /**
     * Enregistre les directives Blade personnalisées.
     *
     * @mtIcons  → inclut la feuille de style des icônes (mt-icons)
     * @mtAssets → inclut tous les assets CSS/JS du package
     */
    protected function registerBladeDirectives(): void
    {
        // Inclure les icônes mt-icons
        Blade::directive('mtIcons', function () {
            return "<?php echo '<link rel=\"stylesheet\" href=\"' . asset('vendor/mt/mt-icons/icons.css') . '\">'; ?>";
        });

        // Inclure tous les assets mt-views (CSS + JS)
        Blade::directive('mtAssets', function () {
            return "<?php echo '<link rel=\"stylesheet\" href=\"' . asset('vendor/mt/mt-views/css/mt-views.css') . '\">'
                . '<script src=\"' . asset('vendor/mt/mt-views/js/mt-views.js') . '\" defer></script>'; ?>";
        });
    }

    /**
     * Enregistre tous les composants Livewire du package.
     *
     * Convention de nommage : mt.{groupe}.{composant}
     *
     * Groupes :
     *   mt.auth.*      → authentification
     *   mt.settings.*  → paramètres utilisateur
     *   mt.modals.*    → modals génériques
     *   mt.forms.*     → formulaires
     *   mt.search.*    → interface de recherche (logique dans mt-search)
     */
    protected function registerLivewireComponents(): void
    {
        // ── Dashboard & Navigation ────────────────────────────────────────
        Livewire::component(
            'mt.mt-dashboard',
            \Mt\MtViews\Livewire\MtDashboard::class
        );
        Livewire::component(
            'mt.locale-switcher',
            \Mt\MtViews\Livewire\LocaleSwitcher::class
        );

        // ── Authentification ──────────────────────────────────────────────
        // Les vues sont ici, la logique métier est dans mt-auth
        Livewire::component(
            'mt.auth.login',
            \Mt\MtViews\Livewire\Auth\Login::class
        );
        Livewire::component(
            'mt.auth.register',
            \Mt\MtViews\Livewire\Auth\Register::class
        );
        Livewire::component(
            'mt.auth.forgot-password',
            \Mt\MtViews\Livewire\Auth\ForgotPassword::class
        );
        Livewire::component(
            'mt.auth.reset-password',
            \Mt\MtViews\Livewire\Auth\ResetPassword::class
        );
        Livewire::component(
            'mt.auth.verify-email',
            \Mt\MtViews\Livewire\Auth\VerifyEmail::class
        );

        // ── Modals génériques ─────────────────────────────────────────────
        Livewire::component(
            'mt.modals.confirm',
            \Mt\MtViews\Livewire\Modals\Confirm::class
        );
        Livewire::component(
            'mt.modals.alert',
            \Mt\MtViews\Livewire\Modals\Alert::class
        );
        Livewire::component(
            'mt.modals.flash-alert',
            \Mt\MtViews\Livewire\Modals\FlashAlert::class
        );
        Livewire::component(
            'mt.modals.select',
            \Mt\MtViews\Livewire\Modals\SelectModal::class
        );
        Livewire::component(
            'mt.modals.export',
            \Mt\MtViews\Livewire\Modals\DataExporterModal::class
        );
        Livewire::component(
            'mt.modals.image-upload',
            \Mt\MtViews\Livewire\Modals\ImageUpload::class
        );

        // ── Formulaires ───────────────────────────────────────────────────
        Livewire::component(
            'mt.forms.image-manager',
            \Mt\MtViews\Livewire\Forms\ImageManager::class
        );

        // ── Paramètres utilisateur ────────────────────────────────────────
        Livewire::component(
            'mt.settings.profile',
            \Mt\MtViews\Livewire\Settings\Profile::class
        );
        Livewire::component(
            'mt.settings.appearance',
            \Mt\MtViews\Livewire\Settings\Appearance::class
        );
        Livewire::component(
            'mt.settings.password',
            \Mt\MtViews\Livewire\Settings\Password::class
        );
        Livewire::component(
            'mt.settings.delete-user',
            \Mt\MtViews\Livewire\Settings\DeleteUserForm::class
        );
        Livewire::component(
            'mt.settings.two-factor',
            \Mt\MtViews\Livewire\Settings\TwoFactor::class
        );

        // ── Recherche ─────────────────────────────────────────────────────
        // Interface Livewire ici, logique et config dans mt-search
        Livewire::component(
            'mt.search.global',
            \Mt\MtViews\Livewire\Search\GlobalSearch::class
        );
        Livewire::component(
            'mt.search.results',
            \Mt\MtViews\Livewire\Search\SearchResults::class
        );
    }

    /**
     * Déclare les ressources publiables via vendor:publish.
     *
     * Tags disponibles :
     *   mt-views-config  → config/mt-views.php
     *   mt-views-lang    → lang/vendor/mt/mt-views/
     *   mt-views-views   → resources/views/vendor/mt/mt-views/
     *   mt-views-assets  → public/vendor/mt/mt-views/
     */
    protected function registerPublishing(string $viewsPath, string $langPath): void
    {
        // Configuration
        $this->publishes([
            $this->basePath . '/config/mt-views.php' => config_path('mt-views.php'),
        ], 'mt-views-config');

        // Traductions
        $this->publishes([
            $langPath => $this->app->langPath('vendor/mt/mt-views'),
        ], 'mt-views-lang');

        // Vues (pour personnalisation dans le projet)
        $this->publishes([
            $viewsPath => resource_path('views/vendor/mt/mt-views'),
        ], 'mt-views-views');

        // Assets CSS/JS compilés
        $this->publishes([
            $this->basePath . '/public/assets' => public_path('vendor/mt/mt-views'),
        ], 'mt-views-assets');
    }
}