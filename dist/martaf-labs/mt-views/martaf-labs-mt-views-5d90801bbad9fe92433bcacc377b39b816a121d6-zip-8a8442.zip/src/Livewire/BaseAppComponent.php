<?php

namespace Mt\MtViews\Livewire;

use Livewire\Component;
use Livewire\Attributes\Layout;

#[Layout('mt::components.layouts.app')]
class BaseAppComponent extends Component
{
    // Ici on peux ajouter des méthodes ou propriétés communes
}
