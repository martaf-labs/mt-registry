<?php

namespace Mt\MtViews\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Livewire\Component;
use Livewire\Form;
use Mt\MtViews\Contracts\ImageOptimizerContract;
use Mt\MtViews\Contracts\ImageModelContract;
use Mt\MtViews\Traits\HandlesModelDates;
use Mt\MtViews\Enums\TypesImage;

/**
 * Classe de base pour tous les Form Objects.
 * Définit la structure du formulaire et les méthodes génériques.
 */
abstract class GenericForm extends Form
{
    use HandlesModelDates;
    
    protected function saveImage(
        \Illuminate\Http\UploadedFile $file,
        string $directory,
        bool   $optimize = true
    ): array {  // ← retourne un tableau, pas juste le path

        if ($optimize && app()->bound(ImageOptimizerContract::class)) {
            $result = app(ImageOptimizerContract::class)
                ->optimizeUpload($file, ['output_directory' => $directory]);

            if ($result->success) {
                return [
                    'path'     => $result->storagePath,
                    'metadata' => [
                        'optimizer' => [
                            'variants'        => $result->variants,
                            'savings_percent' => $result->savingsPercent,
                            'optimized_at'    => now()->toIso8601String(),
                            'width'           => $result->metadata['width']  ?? null,
                            'height'          => $result->metadata['height'] ?? null,
                        ],
                    ],
                ];
            }
        }

        // Fallback sans optimisation
        return [
            'path'     => $file->store($directory, 'public'),
            'metadata' => [], // pas de metadata si pas d'optimisation
        ];
    }

    protected function handleImagePersistence(array $files = null, string $directory = 'uploads/'): void
    {
        // On vérifie la présence du fichier
        if (!isset($files)) {
            return;
        }

        foreach ($files as $file){

            if($file['path'] instanceof \Illuminate\Http\UploadedFile){

                // On exécute saveImage SANS afterCommit pour éviter que le fichier temp ne soit supprimé
                $imageData = $this->saveImage(
                    file: $file['path'],
                    directory: $directory,
                    optimize: $this->component->optimizeImages ?? true
                );

                $imageClass = app(ImageModelContract::class)->model();

                // Utilisation de updateOrCreate pour gérer l'édition et la création
                $newImage = $imageClass::updateOrCreate(
                    [
                        'model_type'  => $file['model_type'],
                        'model_id'    => $file['model_id'],
                        'is_featured' => true,
                        'type'        => TypesImage::PHOTO->value,
                        'title'       => $file['title'],
                        'path'        => $imageData['path'],
                        'metadata'    => $imageData['metadata'],
                        'order'       => 0,
                    ]
                ); 
                
            }           

        }

        
    }

    /**
     * Contient la définition de tous les champs du formulaire.
     * @var array
     */
    abstract public function schema(): array;

    /**
     * Hydrate le Form Object avec les données d'un modèle Eloquent existant.
     * @param Model $model
     * @return void
     */
    public function fillModel(Model $model): void
    {
        // Livewire Form gère déjà la plupart de l'hydratation.
        // On peut juste remplir les propriétés à partir du modèle.
        $this->fill($model->toArray());

        // On s'assure que toutes les propriétés du schéma sont initialisées
        foreach ($this->schema() as $field => $config) {
             if (!property_exists($this, $field)) {
                 $this->{$field} = $model->{$field} ?? null;
             }
        }

        // détecte automatiquement les champs date du model
        $this->bootHandlesModelDates($model);

        // convertit les dates automatiquement
        $this->hydrateDatesFromModel($model);
    }

     /**
     * Actions à exécuter quand un champ change
     * Format: ['champ_source' => [['action' => '...', 'target' => '...', 'value' => '...']]]
     */
    public function fieldActions(): array
    {
        return [];
    }

    /**
     * Définit la classe du modèle Eloquent associée à ce formulaire.
     * @return string
     */
    abstract public static function modelClass(): string;

    /**
     * Logique de sauvegarde/mise à jour du modèle.
     * Cette méthode est responsable de la validation, du traitement des fichiers, et de la persistance.
     * @param Model|null $model
     * @return Model
     */
    abstract public function save(Model $model = null): Model;

    /**
     * Logique de sauvegarde/mise à jour du modèle.
     * Cette méthode est responsable de la creation et de la mise à jour des images d'un modèle (s'il est fournit)
     * @param Model|null $model
     * @return null
     */
    
}