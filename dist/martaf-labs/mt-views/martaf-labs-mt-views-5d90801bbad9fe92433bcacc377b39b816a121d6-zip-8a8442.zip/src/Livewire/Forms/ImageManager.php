<?php

namespace Mt\MtViews\Livewire\Forms;

use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\On;
use Livewire\Attributes\Validate;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtViews\Contracts\ImageOptimizerContract;
use Mt\MtViews\DTOs\ImageOptimizationResult;
use Mt\MtViews\Enums\TypesImage;

/**
 * Composant Livewire 3 — Gestionnaire d'images mt-views.
 *
 * Remplace l'ancien mt.forms.image-manager avec :
 *  - Upload multiple drag & drop
 *  - Optimisation automatique (WebP, variantes, compression)
 *  - Galerie des images existantes avec suppression
 *  - Statistiques d'économie
 *  - Intégration avec les modèles qui utilisent HasImageOptimization
 *
 * Usage dans une vue Blade :
 *   <livewire:mt.forms.image-manager
 *       :model-type="get_class($post)"
 *       :model-id="$post->id"
 *       :image-type="\App\Models\Image::PHOTO"
 *   />
 *
 * Écouter les événements :
 *   #[On('mt:image-saved')]   → ['path' => ..., 'variants' => ...]
 *   #[On('mt:image-deleted')] → ['path' => ...]
 */
class ImageManager extends Component
{
    use WithFileUploads;

    // -------------------------------------------------------------------------
    // Props publiques
    // -------------------------------------------------------------------------

    /** Classe du modèle parent (ex: App\Models\Post) */
    public string $modelType = '';

    /** ID du modèle parent */
    public ?int $modelId = null;

    /** Type d'image (BaseImage::PHOTO, BaseImage::CERTIFICAT, etc.) */
    public string $imageType = TypesImage::PHOTO->value;

    /** Autoriser plusieurs images */
    public bool $multiple = true;

    /** Autoriser la suppression depuis l'interface */
    public bool $allowDelete = true;

    // -------------------------------------------------------------------------
    // État interne
    // -------------------------------------------------------------------------

    public array $uploads    = [];   // fichiers en attente
    public array $results    = [];   // résultats d'optimisation
    public array $existingImages = [];
    public bool  $loading    = false;
    public int   $progress   = 0;
    public string $activeTab = 'gallery';

    public array $stats = [
        'total'           => 0,
        'total_size_kb'   => 0,
        'avg_savings'     => 0,
        'webp_count'      => 0,
    ];

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    public function mount(
        string $modelType = '',
        ?int   $modelId   = null,
        string $imageType = TypesImage::PHOTO->value,
        bool   $multiple  = true,
        bool   $allowDelete = true,
    ): void {
        $this->modelType  = $modelType;
        $this->modelId    = $modelId;
        $this->imageType  = $imageType;
        $this->multiple   = $multiple;
        $this->allowDelete = $allowDelete;


        $this->loadExistingImages();
        $this->computeStats();
    }

    // -------------------------------------------------------------------------
    // Upload & optimisation
    // -------------------------------------------------------------------------

    public function updatedUploads(): void
    {
        $maxSize = mt_config('image_optimizer.max_upload_size', 10240);
        $this->validate([
            'uploads.*' => "image|max:{$maxSize}",
        ]);
    }

    public function optimizeAll(): void
    {
        if (empty($this->uploads)) return;

        $this->loading = true;
        $this->results = [];
        $total         = count($this->uploads);

        /** @var ImageOptimizerContract $optimizer */
        $optimizer = app(ImageOptimizerContract::class);

        foreach ($this->uploads as $index => $upload) {
            try {
                $result = $optimizer->optimizeUpload($upload);

                if ($result->success) {
                    // Sauvegarder dans le modèle Image si un contexte est fourni
                    $savedPath = $this->persistImage($result, $upload->getClientOriginalName());

                    $this->results[] = array_merge($result->toArray(), [
                        'filename'   => $upload->getClientOriginalName(),
                        'saved_path' => $savedPath,
                    ]);

                    $this->dispatch('mt:image-saved', [
                        'path'     => $result->storagePath,
                        'variants' => $result->variants,
                    ]);
                } else {
                    $this->results[] = [
                        'success'  => false,
                        'filename' => $upload->getClientOriginalName(),
                        'error'    => $result->error,
                    ];
                }
            } catch (\Throwable $e) {
                $this->results[] = [
                    'success'  => false,
                    'filename' => $upload->getClientOriginalName(),
                    'error'    => $e->getMessage(),
                ];
            }

            $this->progress = (int) (($index + 1) / $total * 100);
        }

        $this->uploads   = [];
        $this->loading   = false;
        $this->progress  = 0;
        $this->activeTab = 'gallery';

        $this->loadExistingImages();
        $this->computeStats();
    }

    // -------------------------------------------------------------------------
    // Gestion des images existantes
    // -------------------------------------------------------------------------

    public function deleteImage(string $path): void
    {
        if (!$this->allowDelete) return;

        app(ImageOptimizerContract::class)->delete($path);

        // Supprimer l'entrée en base si contexte disponible
        if ($this->modelType && $this->modelId) {
            $imageModel = $this->resolveImageModel();
            if ($imageModel) {
                $imageModel::where('model_type', $this->modelType)
                    ->where('model_id', $this->modelId)
                    ->where('path', $path)
                    ->first()
                    ?->delete();
            }
        }

        $this->loadExistingImages();
        $this->computeStats();
        $this->dispatch('mt:image-deleted', ['path' => $path]);
    }

    public function setFeatured(string $path): void
    {
        if (!$this->modelType || !$this->modelId) return;

        $imageModel = $this->resolveImageModel();
        if (!$imageModel) return;

        // Retirer is_featured de toutes, puis set sur celle-ci
        $imageModel::where('model_type', $this->modelType)
            ->where('model_id', $this->modelId)
            ->update(['is_featured' => false]);

        $imageModel::where('model_type', $this->modelType)
            ->where('model_id', $this->modelId)
            ->where('path', $path)
            ->update(['is_featured' => true]);

        $this->loadExistingImages();
    }

    // -------------------------------------------------------------------------
    // Helpers privés
    // -------------------------------------------------------------------------

    /**
     * Persiste le résultat dans le modèle Image (si contexte fourni).
     */
    private function persistImage(ImageOptimizationResult $result, string $originalName): string
    {
        if (!$this->modelType || !$this->modelId) {
            return $result->storagePath;
        }

        $imageModel = $this->resolveImageModel();
        if (!$imageModel) return $result->storagePath;

        $imageModel::create([
            'model_' => $this->modelType,
            'model_id'   => $this->modelId,
            'type'        => $this->imageType,
            'title'       => pathinfo($originalName, PATHINFO_FILENAME),
            'path'        => $result->storagePath,
            'actif'       => true,
            'metadata'    => [
                'optimizer' => [
                    'variants'        => $result->variants,
                    'savings_percent' => $result->savingsPercent,
                    'optimized_at'    => now()->toIso8601String(),
                    'width'           => $result->metadata['width']  ?? null,
                    'height'          => $result->metadata['height'] ?? null,
                ],
            ],
        ]);

        return $result->storagePath;
    }

    private function loadExistingImages(): void
    {
        if (!$this->modelType || !$this->modelId) {
            $this->existingImages = [];
            return;
        }

        $imageModel = $this->resolveImageModel();
        if (!$imageModel) return;

        $this->existingImages = $imageModel::where('model_type', $this->modelType)
            ->where('model_id', $this->modelId)
            ->where('type', $this->imageType)
            ->orderBy('order')
            ->orderBy('created_at', 'desc')
            ->get()
            ->map(fn ($img) => [
                'id'          => $img->id,
                'path'        => $img->path,
                'url'         => $img->image_url,
                'title'       => $img->title,
                'is_featured' => $img->is_featured,
                'is_optimized' => !empty($img->metadata['optimizer']['optimized_at']),
                'savings'     => $img->metadata['optimizer']['savings_percent'] ?? null,
                'webp_url'    => $img->getVariantUrl('webp') ?? null,
            ])
            ->all();
    }

    private function computeStats(): void
    {
        $total   = count($this->existingImages);
        $savings = collect($this->existingImages)->pluck('savings')->filter()->avg() ?? 0;
        $webp    = collect($this->existingImages)->filter(fn ($i) => $i['webp_url'])->count();

        $this->stats = [
            'total'         => $total,
            'avg_savings'   => round($savings, 1),
            'webp_count'    => $webp,
            'results_count' => count($this->results),
        ];
    }

    /**
     * Résout le modèle Image configuré dans mt-views.php (providers.images.model).
     */
    private function resolveImageModel(): ?string
    {
        $model = mt_config('providers.images.model');
        return ($model) ? $model : null;
    }

    // -------------------------------------------------------------------------
    // Render
    // -------------------------------------------------------------------------

    public function render()
    {
        return view('mt::livewire.forms.image-manager');
    }
}
