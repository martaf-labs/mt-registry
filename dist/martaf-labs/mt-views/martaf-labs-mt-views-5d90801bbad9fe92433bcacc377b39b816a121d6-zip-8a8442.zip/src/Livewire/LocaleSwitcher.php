<?php

namespace Mt\MtViews\Livewire;

use Livewire\Component;
use Mt\MtViews\Helpers\MtLocale;

class LocaleSwitcher extends Component
{
    public string $current;
    public array $locales = [];

    public function mount(): void
    {
        $this->current = MtLocale::get();
        $this->locales = MtLocale::available();
    }

    public function switchLocale(string $locale): void
    {
        MtLocale::set($locale);

        $this->current = MtLocale::get();

        // Notifie les autres composants Alpine/Livewire si besoin
        $this->dispatch('mt-locale-changed', locale: $locale);

        // Recharge la page pour que toutes les traductions s'appliquent
        $this->redirect(request()->header('Referer') ?? url()->current(), navigate: true);
    }

    public function render()
    {
        return view('mt::livewire.locale-switcher');
    }
}
