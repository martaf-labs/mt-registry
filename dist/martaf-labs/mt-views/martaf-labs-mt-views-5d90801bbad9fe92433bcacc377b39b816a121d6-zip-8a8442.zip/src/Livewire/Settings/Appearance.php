<?php

namespace Mt\MtViews\Livewire\Settings;

use Livewire\Component;
use Livewire\Attributes\Layout;
use Mt\MtViews\Livewire\BaseAppComponent;


class Appearance extends BaseAppComponent
{
      

    public function render()
    {
        return view('mt::livewire.settings.appearance');
    }
}
