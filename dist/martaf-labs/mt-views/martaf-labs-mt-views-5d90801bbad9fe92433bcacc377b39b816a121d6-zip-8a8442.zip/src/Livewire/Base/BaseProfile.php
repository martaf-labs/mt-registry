<?php

namespace Mt\MtViews\Livewire\Base;

use Livewire\Component;
use Livewire\Attributes\Layout;
use Mt\MtViews\Livewire\BaseAppComponent;

abstract class BaseProfile extends BaseAppComponent
{
    // Configuration de base
    public $model;
    public $model_plural;
    public $modelClass;
    public $config = [];
    public $title = '';
    public $navItems = null;

    public $id = null;
    public $data = null;

    // NOUVEAU: Gestion des modules
    public $activeModule = null;
    public $activeModuleData = null;

    // Données d'affichage
    public $profileDatas = [
        'sections' => [],
        'sidebar' => [],
        'actions' => [],
        'modules' => [] // NOUVEAU: modules additionnels
    ];

    // Éléments de configuration
    public $process = [];
    public $sections = [];
    public $sidebar = [];
    public $actions = [];
    public $modules = []; // NOUVEAU
    public $hasActions = false;
    public $hasModules = false; // NOUVEAU

    abstract public function profileClass(): string;

    /**
     * Obtenir l'instance du profile object
     */
    private function getProfileInstance()
    {
        $profileClass = $this->profileClass();
        return new $profileClass();
    }

    public function mount($id = null): void
    {
        $this->id = $id;

        // 1. Instanciation du Profile Object
        $profileInstance = $this->getProfileInstance();
        $this->modelClass = $profileInstance->modelClass();

        $this->data = !is_null($this->id) ? $this->modelClass::find($this->id) : null;
        $this->config = $profileInstance->configuration($this->data);

        // 2. Configuration de base
        $this->model = $this->config['model'];
        $this->model_plural = $this->config['model_plural'];
        $this->title = $this->config['title'];

        $this->navItems = $this->config['navItems'];

        // 4. Chargement des données
        $this->loadProfileData($profileInstance);

        // NOUVEAU: Initialiser le module actif
        $this->initializeActiveModule();
    }

    /**
     * NOUVEAU: Initialiser le module actif
     */
    private function initializeActiveModule(): void
    {
        if ($this->hasModules && count($this->modules) > 0) {
            $firstActiveModule = collect($this->modules)->firstWhere('active', true);
            $this->activeModule = $firstActiveModule['type'] ?? null;
            $this->loadActiveModuleData();
        }
    }

    /**
     * NOUVEAU: Charger les données du module actif
     */
    private function loadActiveModuleData(): void
    {
        if ($this->activeModule && $this->data) {
            $profileInstance = $this->getProfileInstance();
            $this->activeModuleData = $profileInstance->getModuleData($this->data, $this->activeModule);
        } else {
            $this->activeModuleData = null;
        }
    }

    /**
     * NOUVEAU: Changer le module actif
     */
    public function setActiveModule($moduleType): void
    {
        $this->activeModule = $moduleType;
        $this->loadActiveModuleData();
    }

    /**
     * Charger les données du profil
     */
    private function loadProfileData($profileInstance): void
    {
        if ($this->id && is_numeric($this->id)) {
            // Mode consultation d'un profil spécifique
            $this->data = $this->modelClass::find($this->id);
        } else {
            // Mode profil de l'utilisateur connecté
            $this->data = $this->getCurrentUserProfile();
        }

        if ($this->data) {
            $this->title = $this->config['title'];

            // Préparation des données d'affichage
            $this->navItems = $this->config['navItems'];

            // Préparation de la navigation
        } else {
            $this->prepareEmptyData();
        }
        $this->prepareProfileData($profileInstance);

    }

    /**
     * Obtenir contenu du titre(au cas où celui serait un array par exemple)
     */
    private function getTitleContent()
    {
        return is_array($this->title) ? $this->title ['content'] : $this->title;
    }

    /**
     * Obtenir le profil de l'utilisateur connecté
     */
    private function getCurrentUserProfile()
    {
        $profileInstance = $this->getProfileInstance();
        return $profileInstance->getCurrentUserProfile();
    }

    /**
     * Préparer les données du profil
     */
    private function prepareProfileData($profileInstance): void
    {
        $profileData = $profileInstance->getProfileData($this->data, $this->id);

        $this->process = $profileData['process'] ?? [];
        $this->sections = $profileData['sections'] ?? [];
        $this->sidebar = $profileData['sidebar'] ?? [];
        $this->actions = $profileData['actions'] ?? [];
        $this->modules = $profileData['modules'] ?? []; // NOUVEAU
        $this->hasActions = count($this->actions) > 0;
        $this->hasModules = count($this->modules) > 0; // NOUVEAU

        // Préparer les données pour la vue
        $this->profileDatas = [
            'process' => $this->process,
            'sections' => $this->sections,
            'sidebar' => $this->sidebar,
            'actions' => $this->actions,
            'modules' => $this->modules // NOUVEAU
        ];
    }


    /**
     * Préparer les données vides
     */
    private function prepareEmptyData(): void
    {
        $this->profileDatas = [
            'process' => [],
            'sections' => [],
            'sidebar' => [],
            'actions' => [],
            'modules' => [] // NOUVEAU
        ];
        $this->sections = [];
        $this->sidebar = [];
        $this->actions = [];
        $this->modules = []; // NOUVEAU
        $this->hasActions = false;
        $this->hasModules = false; // NOUVEAU
        $this->activeModule = null; // NOUVEAU
        $this->activeModuleData = null; // NOUVEAU
    }

    /**
     * Formater la valeur pour l'affichage
     */
    public function formatValue($field, $value): string
    {
        return $this->getProfileInstance()->formatValue($field, $value);
    }

    /**
     * Obtenir les actions disponibles
     */
    public function getActions(): array
    {
        return $this->actions;
    }

    /**
     * NOUVEAU: Obtenir les modules disponibles
     */
    public function getModules(): array
    {
        return $this->modules;
    }

    /**
     * Obtenir des statistiques ou informations rapides
     */
    public function getQuickStats(): array
    {
        if (method_exists($this->getProfileInstance(), 'getQuickStats') && $this->data) {
            return $this->getProfileInstance()->getQuickStats($this->data);
        }

        return [];
    }

    /**
     * NOUVEAU: Obtenir les données du module actif pour la vue
     */
    public function getActiveModuleDataProperty()
    {
        return $this->activeModuleData;
    }

    /**
     * NOUVEAU: Vérifier si un module est actif
     */
    public function isModuleActive($moduleType): bool
    {
        return $this->activeModule === $moduleType;
    }

    public function render()
    {
        $this->dispatch('page-title-changed', title: $this->getTitleContent());

        return view('mt::livewire.base.base-profile', [
            'process' => $this->process,
            'sections' => $this->sections,
            'sidebar' => $this->sidebar,
            'actions' => $this->actions,
            'modules' => $this->modules, // NOUVEAU
            'hasActions' => $this->hasActions,
            'hasModules' => $this->hasModules, // NOUVEAU
            'profileDatas' => $this->profileDatas,
            'isMyProfile' => !$this->id || $this->id == auth()->id(),
            'activeModule' => $this->activeModule, // NOUVEAU
            'activeModuleData' => $this->activeModuleData, // NOUVEAU
        ]);
    }
}
