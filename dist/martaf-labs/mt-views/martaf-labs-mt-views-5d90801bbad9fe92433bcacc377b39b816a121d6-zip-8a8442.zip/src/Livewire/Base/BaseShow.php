<?php

namespace Mt\MtViews\Livewire\Base;

use Livewire\Component;
use Livewire\Attributes\On;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Mt\MtViews\Livewire\BaseAppComponent;


abstract class BaseShow extends BaseAppComponent
{
    // Configuration de base
    public $model;
    public $model_plural;
    public $modelClass;
    public $title = '';
    public $navItems = null;

    #[Locked]
    public $id = null;
    public $data = null;

    // Données d'affichage (initialisées avec des tableaux vides)
    public $showDatas = [
        'fields' => [],
        'medias' => [],
        'metaDatas' => [],
        'actions' => []
    ];
    public $metaDatas = false;
    public $actions = [];
    public $hasActions = false;

    // Éléments de configuration
    public $fields = [];
    public $medias = [];

    // Écouteurs d'événements
    protected $listeners = [
        'refresh-data' => 'refreshShowData',
    ];

    abstract public function showClass(): string;

    /**
     * Obtenir l'instance du show object
     */
    private function getShowInstance()
    {
        $showClass = $this->showClass();
        return new $showClass();
    }

    public function mount($id = null): void
    {
        $this->id = $id;

        // 1. Instanciation du Show Object
        $showInstance = $this->getShowInstance();
        $config = $showInstance->configuration();

        // 2. Configuration de base
        $this->model = $config['model'];
        $this->model_plural = $config['model_plural'];
        $this->modelClass = $showInstance->modelClass();
        $this->title = $config['title'];

        // 3. Initialiser la navigation de base
        $this->navItems = navItems($this->model, $config['mainLabel'])->get();

        // 4. Chargement des données si ID fourni
        if ($this->id && is_numeric($this->id)) {
            $this->data = $this->modelClass::find($this->id);

            if ($this->data) {
                $this->title = $this->data->nom ?? $this->data->name ?? $this->data->titre ?? $this->title;

                // 5. Préparation des données d'affichage
                $this->prepareShowData($showInstance);

                // 6. Préparation de la navigation
                $this->prepareNavigation($config['mainLabel']);
            } else {
                // Données non trouvées, initialiser avec des valeurs par défaut
                $this->prepareEmptyData();
            }
        } else {
            // Pas d'ID, initialiser avec des valeurs par défaut
            $this->prepareEmptyData();
        }
    }

    /**
     * Préparer les données d'affichage
     */
    private function prepareShowData($showInstance): void
    {
        $showData = $showInstance->getShowData($this->data);

        $this->fields = $showData['fields'] ?? [];
        $this->medias = $showData['medias'] ?? [];
        $this->metaDatas = $showData['metaDatas'] ?? [];
        $this->actions = $showData['actions'] ?? [];
        $this->hasActions = count($this->actions) > 0;

        // Préparer les données pour la vue
        $this->showDatas = [
            'fields' => $this->fields,
            'medias' => $this->medias,
            'metaDatas' => $this->metaDatas,
            'actions' => $this->actions
        ];
    }

    /**
     * Préparer les données vides
     */
    private function prepareEmptyData(): void
    {
        $this->showDatas = [
            'fields' => [],
            'medias' => [],
            'metaDatas' => [],
            'actions' => []
        ];
        $this->fields = [];
        $this->medias = [];
        $this->metaDatas = [];
        $this->actions = [];
        $this->hasActions = false;
    }

    /**
     * Préparer la navigation
     */
    private function prepareNavigation($mainLabel): void
    {
        $this->navItems = navItems($this->model, $mainLabel)
            ->add($this->data->nom ?? $this->data->name ?? $this->data->titre ?? 'Détails', mt_get_route($this->model_plural . '_show', ['id' => $this->id]))
            ->add('Détails', '#')->get();
    }

    /**
     * Formater la valeur pour l'affichage
     */
    public function formatValue($field, $value): string
    {
        return $this->getShowInstance()->formatValue($field, $value);
    }

    /**
     * Obtenir les actions disponibles
     */
    public function getActions(): array
    {
        return $this->actions;
    }

    /**
     * Obtenir des informations supplémentaires
     */
    public function getAdditionalInfo(): array
    {
        if (method_exists($this->getShowInstance(), 'getAdditionalInfo') && $this->data) {
            return $this->getShowInstance()->getAdditionalInfo($this->data);
        }

        return [];
    }

    /**
     * Rafraîchir les données d'affichage
     */
    #[On('refresh-data')]
    public function refreshShowData()
    {
        $this->prepareShowData($this->getShowInstance());
    }

    public function render()
    {
        $this->dispatch('page-title-changed', title: $this->title);

        return view('mt::livewire.base.base-show', [
            'mainItems' => $this->fields,
            'medias' => $this->medias,
            'metaDatas' => $this->metaDatas,
            'actions' => $this->actions,
            'hasActions' => $this->hasActions,
            'showDatas' => $this->showDatas, // Assurer que showDatas est toujours défini
        ]);
    }
}
