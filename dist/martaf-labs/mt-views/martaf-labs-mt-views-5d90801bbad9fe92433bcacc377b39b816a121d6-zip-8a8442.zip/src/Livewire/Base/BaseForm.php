<?php

namespace Mt\MtViews\Livewire\Base;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\On;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtViews\Contracts\HasBaseFormContract;
use Mt\MtViews\Contracts\ImageOptimizerContract;
use Mt\MtViews\Helpers\MtLocale;
use Mt\MtViews\Livewire\BaseAppComponent;
use Mt\MtViews\Traits\WithFormSteps;

/**
 * Composant de base générique pour gérer les formulaires mono et multi-étapes.
 */

abstract class BaseForm extends BaseAppComponent
{
    use WithFileUploads, WithFormSteps;

    // Définitions abstraites, HasPersistentImages
    abstract public function formClass(): string;
    abstract public function getModelName(): string;
    abstract public function getPluralModelName(): string;
    abstract public function getRedirectRouteName(): string;
    abstract public function getModelNavItems($data = null): array;

    /** @var \Src\Livewire\Forms\GenericForm */
    public $form;
    public $modelClass  = null;
    public ?int $id = null;
    public string $mode = 'create';
    public bool $isSubmitting = false;
    public $persistent_images = []; //Propriété pour les images persistantes (temporaire pour upload)
    public $existing_images = []; //Propriété pour les images existantes (édition)
    public bool $optimizeImages = true; // ← persiste entre requêtes Livewire


    public function fieldActions() : array
    {
        if ($this->form instanceof HasBaseFormContract) {
            return $this->form->fieldActions();
        }
        return [];
    }

    public function mount(?int $id = null): void
    {
        $this->id = $id;
        $this->mode = is_numeric($this->id) ? 'edit' : 'create';

        // 1. Instanciation du Form Object
        $formClass = $this->formClass();
        $this->form = new $formClass($this, 'form');
        $this->modelClass = $this->form->modelClass();

        if (!is_null($this->modelData())) {
            $this->form->fillModel($this->modelData());
        }


        // 3. Initialiser l'état des étapes
        $this->hasSteps = count($this->steps()) > 1;
        $this->initializeAvailableSteps();
    }

    #[Computed]
    public function modelData() : ?Model
    {
        $modelData = null;  //attention , en mode 'create', $modelData doit etre "null"
        // 2. Hydratation en mode édition
        if ($this->mode === 'edit') {
            $modelData = $this->modelClass::findOrFail($this->id);
        }
        return $modelData;
    }

    #[Computed]
    public function navItems() : array
    {
        return $this->getModelNavItems($this->modelData());
    }

    /**
     * Formater les attributs du formulaire si néccessaire
     * @return void
     */
    public function formatFormAttributes()
    {
        
    }

    /**
     * Recupere les règles de validation d'un champ
     */
    public function getRules($field = null)
    {
        if(is_null($field)) {
            return $this->form->rules();
        }
        else{
            return $this->form->rules()[$field] ?? '';
        }
    }

    /**
     * Vérifie si un champ est requis
     */
    public function isRequired($field)
    {
        $allRules=$this->form->rules();

        if($this->hasSteps) {
            $allRules=$this->getStepRules($this->currentStep);
            $field='form.'.$field;
        }

        if(is_null($field) || !in_array($field, array_keys($allRules))) {
            return false;
        }
        else{
            $fieldRules = $allRules[$field];
            return Str::contains(is_array($fieldRules) ? implode('|',$fieldRules) : $fieldRules, 'required');
        }
    }

    /**
     * Mise à jour des champs de select entity
     */
    #[On('entity-selected')]
    public function updateEntity($fields)
    {
        foreach ($fields as $field => $value) {
            $this->form->$field = $value;
        }
    }

    /**
     * Obtient les champs à afficher pour l'étape/rénder actuel
     */
    public function getFieldsToDisplay(): array
    {
        
        $fields=$this->getCurrentStepFields();

        //ajout des marqueur pour las champs multilingue
        $availableLocales = get_available_locales();
        $model=$this->modelData();

        if (is_null($model)) {
            return $fields;
        }

        foreach ($fields as $key => $value) {
            if ($model->translatables && in_array($key, $model->translatables)) {
                $fields[$key]['multilingual']=true;

                //initialisation des champ multiligue si null
                if (is_null($this->form->$key)) {
                    foreach ($availableLocales as $lang => $options) {
                        $this->form->$key[$lang]='';
                    }
                }
            }
        }
        return $fields;
    }

    /**
     * Quand un champ est modifié
     */
    public function updatedForm($value, $key)
    {
        // Exécuter les actions Livewire si configurées
        if (!is_null($key)){
            $this->executeLivewireActions($key, $value);
        }

        // Émettre un événement pour Alpine.js
        $this->dispatch('field-updated',
            field: $key,
            value: $value,
            actions: $this->form->fieldActions()[$key] ?? []
        );

        // Gestion des étapes conditionnelles
        $this->handleStepConditions($key);
    }

    /**
     * Exécuter les actions côté Livewire
     */
    protected function executeLivewireActions(string $field = null, $value): void
    {
        if (is_null($field)) {
            return;
        }

        $actions = $this->form->fieldActions()[$field] ?? [];

        foreach ($actions as $action) {
            $this->executeLivewireAction($action, $field, $value);
        }
    }

    /**
     * Exécuter une action Livewire
     */
    protected function executeLivewireAction(array $action, string $field, $value): void
    {
        $type = $action['type'] ?? '';
        $target = $action['target'] ?? '';

        switch ($type) {
            case 'set':
                if ($target && isset($action['value'])) {
                    $this->form->{$target} = $action['value'];
                }
                break;

            case 'map':
                if ($target && isset($action['map'][$value])) {
                    $this->form->{$target} = $action['map'][$value];
                }
                break;

            case 'clear':
                if ($target) {
                    $this->form->{$target} = null;
                }
                break;

            case 'copy':
                if ($target) {
                    $this->form->{$target} = $value;
                }
                break;
        }
    }

    /**
     * Gérer les conditions des étapes
     */
    protected function handleStepConditions(?string $field): void
    {
        if(is_null($field)){
            return;
        }

        $criticalFields = method_exists($this->form, 'getCriticalFields') ? $this->form->getCriticalFields() : [];

        if (in_array($field, $criticalFields)) {
            $this->initializeAvailableSteps();

            // Recalculer les étapes virtuelles disponibles
            $availableVirtualSteps = array_keys($this->getStepsToDisplay());

            // Si l'étape courante n'est plus dans les étapes disponibles, aller à la prochaine
            if (!in_array($this->currentStep, $availableVirtualSteps)) {
                // Prendre la première étape disponible >= currentStep, sinon la dernière
                $next = collect($availableVirtualSteps)->first(fn($s) => $s >= $this->currentStep);
                $this->currentStep = $next ?? (count($availableVirtualSteps) > 0 ? end($availableVirtualSteps) : 1);
            }

            $this->dispatch('steps-updated');
        }
    }

    /**
     * Méthode de soumission qui délègue la sauvegarde au Form Object.
     */
    public function save()
    {
        $this->dispatch('form-submitting');
        
        // reconvertit vers format DB
        // $this->dehydrateDatesToModel($this->modelData());

        // Valider l'étape actuelle ou tout le formulaire
        if (!$this->validateStep($this->currentStep)) {
            $this->dispatch('form-submit-failed');
            return;
        }

        try {
            $savedItem = $this->form->save($this->modelData());

            if ($savedItem) {
                if ($this->mode === 'edit') {
                    showAlert('success', 'Élément modifié avec succès!');
                } else {
                    showAlert('success', 'Élément créé avec succès!');
                }
                
            }
            
            // session()->flash('success', $this->mode === 'edit' ?
            //     "{$this->getModelName()} mis à jour avec succès !" :
            //     "{$this->getModelName()} créé avec succès !"
            // );

            // Redirection vers la route d'index
            return $this->redirectRoute($this->getRedirectRouteName(), navigate: true);

        } catch (\Exception $e) {
            $this->dispatch('form-submit-failed');
            session()->flash('error', "Erreur : " . $e->getMessage());
        }
    }

    
    //**___________________________________


    /**
     * Méthode pour enregistrer et continuer (uniquement multi-step)
     */
    public function saveAndContinue()
    { 
        $this->isSubmitting = true;
        if ($this->hasMultipleSteps() && $this->validateStep($this->currentStep)) {
            $this->nextStep();
        } 
        $this->isSubmitting = false;
        // dd($this->isSubmitting);
    }

    public function render()
    {
        $title = $this->mode === 'edit' ? "Modifier {$this->getModelName()}" : "Ajouter {$this->getModelName()}";

        return view('mt::livewire.base.base-form', [
            'title' => $title,
            'schema' => $this->form->schema(),
            'displayFields' => $this->getFieldsToDisplay(),
            'hasMultipleSteps' => $this->hasMultipleSteps(),
            'stepsToDisplay' => $this->getStepsToDisplay(),
        ])->title($title);
    }
}
