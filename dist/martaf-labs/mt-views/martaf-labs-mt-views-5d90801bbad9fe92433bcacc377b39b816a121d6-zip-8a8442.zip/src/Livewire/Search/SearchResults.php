<?php

namespace Mt\MtViews\Livewire\Search;

use Livewire\Component;
use Mt\MtViews\Contracts\Searchable;

/**
 * Composant Livewire SearchResults
 *
 * Dédié à la page de résultats complète (/search?q=...).
 * Distinct de GlobalSearch (dropdown + modal dans le header).
 *
 * Enregistrement dans le ServiceProvider :
 *   Livewire::component('mt.search-results', SearchResults::class);
 *
 * Utilisation dans la vue results.blade.php :
 *   <livewire:mt.search-results :initial-query="$query" :initial-category="$category" />
 */
class SearchResults extends Component
{
    // ── Props (passées depuis la vue Blade parente) ─────────────────────

    /** Terme initial (depuis l'URL ?q=...) */
    public string $initialQuery = '';

    /** Catégorie initiale (depuis l'URL ?category=...) */
    public ?string $initialCategory = null;

    // ── State ───────────────────────────────────────────────────────────

    public string  $query          = '';
    public ?string $activeCategory = null;
    public int     $page           = 1;
    public array   $loadedResults  = [];
    public int     $totalResults   = 0;
    public bool    $searching      = false;
    public bool    $hasMore        = false;

    // ── Lifecycle ───────────────────────────────────────────────────────

    public function mount(string $initialQuery = '', ?string $initialCategory = null): void
    {
        $this->query          = $initialQuery;
        $this->activeCategory = $initialCategory;

        if (mb_strlen(trim($this->query)) >= config('mt-search.min_chars', 2)) {
            $this->runSearch();
        }
    }

    // ── Computed ────────────────────────────────────────────────────────

    /**
     * Liste des catégories disponibles (pour les filtres).
     */
    public function getCategoriesProperty(): array
    {
        $categories = [];
        foreach ($this->getProviders() as $class) {
            if ($this->implementsSearchable($class)) {
                $categories[] = [
                    'key'   => $class,
                    'label' => $class::searchCategory(),
                    'icon'  => $class::searchIcon(),
                    'color' => $class::searchColor(),
                ];
            }
        }
        return $categories;
    }

    // ── Actions ─────────────────────────────────────────────────────────

    /**
     * Déclenchée par wire:model.live — relance la recherche depuis la page 1.
     */
    public function updatedQuery(): void
    {
        $this->page          = 1;
        $this->loadedResults = [];
        $this->hasMore       = false;

        if (mb_strlen(trim($this->query)) < config('mt-search.min_chars', 2)) {
            $this->totalResults = 0;
            $this->searching    = false;
            return;
        }

        $this->searching = true;
        $this->runSearch();
        $this->searching = false;
    }

    /**
     * Change la catégorie active et relance la recherche.
     */
    public function setCategory(?string $category): void
    {
        $this->activeCategory = $category;
        $this->page           = 1;
        $this->loadedResults  = [];
        $this->hasMore        = false;

        if (mb_strlen(trim($this->query)) >= config('mt-search.min_chars', 2)) {
            $this->runSearch();
        }
    }

    /**
     * Déclenche la recherche manuellement (appelée depuis Alpine au mount).
     */
    public function searchFullPage(): void
    {
        $this->page          = 1;
        $this->loadedResults = [];
        $this->hasMore       = false;
        $this->runSearch();
    }

    /**
     * Charge la page suivante (Load More).
     */
    public function loadMore(): void
    {
        $this->page++;
        $this->runSearch(append: true);
    }

    /**
     * Vide la recherche.
     */
    public function clear(): void
    {
        $this->query          = '';
        $this->loadedResults  = [];
        $this->totalResults   = 0;
        $this->page           = 1;
        $this->hasMore        = false;
        $this->activeCategory = null;
    }

    // ── Core ────────────────────────────────────────────────────────────

    /**
     * Exécute la recherche paginée sur tous les providers.
     */
    protected function runSearch(bool $append = false): void
    {
        $q       = trim($this->query);
        $perPage = config('mt-search.per_page', 15);
        $offset  = ($this->page - 1) * $perPage;
        $items   = [];
        $total   = 0;

        foreach ($this->getProviders() as $class) {
            if (! $this->implementsSearchable($class)) continue;
            if ($this->activeCategory && $this->activeCategory !== $class) continue;

            $rows = $class::searchQuery($q)
                ->offset($offset)
                ->limit($perPage)
                ->get()
                ->map(fn ($model) => array_merge(
                    $model->toSearchResult(),
                    [
                        'category' => $class::searchCategory(),
                        'icon'     => $class::searchIcon(),
                        'color'    => $class::searchColor(),
                    ]
                ))
                ->toArray();

            $items = array_merge($items, $rows);
            $total += $class::searchQuery($q)->count();
        }

        $highlighted = $this->highlight($items, $q);

        $this->loadedResults = $append
            ? array_merge($this->loadedResults, $highlighted)
            : $highlighted;

        $this->totalResults = $total;
        $this->hasMore      = count($this->loadedResults) < $total;
    }

    // ── Helpers ─────────────────────────────────────────────────────────

    protected function highlight(array $items, string $query): array
    {
        if (trim($query) === '') return $items;

        $escaped = preg_quote($query, '/');

        return array_map(function (array $item) use ($escaped) {
            foreach (['title', 'subtitle'] as $field) {
                if (! empty($item[$field])) {
                    $item[$field] = preg_replace(
                        "/({$escaped})/iu",
                        '<mark class="search-highlight">$1</mark>',
                        $item[$field]
                    );
                }
            }
            return $item;
        }, $items);
    }

    protected function getProviders(): array
    {
        return config('mt-search.providers', []);
    }

    protected function implementsSearchable(string $class): bool
    {
        return class_exists($class)
            && in_array(Searchable::class, class_implements($class) ?: []);
    }

    // ── Render ──────────────────────────────────────────────────────────

    public function render()
    {
        return view('mt::livewire.search.search-results', [
            'categories' => $this->categories,
        ]);
    }
}