<?php

namespace Mt\MtViews\Livewire\Search;

use Illuminate\Support\Collection;
use Livewire\Component;
use Mt\MtViews\Contracts\Searchable;
use Livewire\Attributes\Computed;

/**
 * Composant Livewire GlobalSearch
 *
 * Enregistrement dans le ServiceProvider :
 *   Livewire::component('mt.global-search', GlobalSearch::class);
 *
 * Utilisation dans une vue Blade :
 *   <livewire:mt.global-search />
 *
 * Configuration dans config/mt.php :
 *   'search' => [
 *       'per_category' => 5,          // résultats max par catégorie en dropdown
 *       'per_page'     => 15,         // résultats par page en mode full-page
 *       'min_chars'    => 2,          // caractères min avant de lancer la recherche
 *       'debounce'     => 300,        // délai debounce en ms (géré côté Blade)
 *       'providers'    => [           // modèles searchables
 *           \App\Models\User::class,
 *           \App\Models\Product::class,
 *       ],
 *   ],
 */
class GlobalSearch extends Component
{
    // ── State ──────────────────────────────────────────────────────────────

    /** Terme de recherche saisi */
    public string $query = '';

    /** Catégorie active (null = toutes) */
    public ?string $activeCategory = null;

    /** Page courante pour la vue full-page */
    public int $page = 1;

    /** Résultats groupés par catégorie */
    public array $results = [];

    /** Total de résultats (full-page) */
    public int $totalResults = 0;

    /** Indique si une recherche est en cours */
    public bool $searching = false;

    /** Résultats déjà chargés (pour load more) */
    public array $loadedResults = [];

    /** A-t-on atteint la fin des résultats ? */
    public bool $hasMore = false;

    // ── Lifecycle ──────────────────────────────────────────────────────────

    public function mount(): void
    {
        $this->results      = [];
        $this->loadedResults = [];
    }

    // ── Computed ───────────────────────────────────────────────────────────

    /**
     * Liste des catégories disponibles à partir des providers configurés.
     */
    #[Computed]
    public function categories(): array
    {
        $categories = [];
        foreach ($this->getProviders() as $class) {
            if ($this->implementsSearchable($class)) {
                $categories[] = [
                    'key'   => $class,
                    'label' => $class::searchCategory(),
                    'icon'  => $class::searchIcon(),
                    'color' => $class::searchColor(),
                ];
            }
        }
        return $categories;
    }

    // ── Actions ────────────────────────────────────────────────────────────

    /**
     * Déclenchée en temps réel par le wire:model.live.debounce
     * Met à jour $query et relance la recherche dropdown.
     */
    public function updatedQuery(): void
    {
        $this->page          = 1;
        $this->loadedResults = [];
        $this->hasMore       = false;

        $minChars = config('mt-search.min_chars', 2);

        if (mb_strlen(trim($this->query)) < $minChars) {
            $this->results      = [];
            $this->totalResults = 0;
            $this->searching    = false;
            return;
        }

        $this->searching = true;
        $this->runSearch();
        $this->searching = false;
    }

    /**
     * Change la catégorie active et réinitialise les résultats.
     */
    public function setCategory(?string $category): void
    {
        $this->activeCategory = $category;
        $this->page           = 1;
        $this->loadedResults  = [];
        $this->hasMore        = false;

        if (mb_strlen(trim($this->query)) >= config('mt-search.min_chars', 2)) {
            $this->runSearch();
        }
    }

    /**
     * Charge plus de résultats (load more / pagination).
     */
    public function loadMore(): void
    {
        $this->page++;
        $this->runSearchFullPage(append: true);
    }

    /**
     * Recherche full-page (appelée depuis la page de résultats dédiée).
     */
    public function searchFullPage(): void
    {
        $this->page          = 1;
        $this->loadedResults = [];
        $this->hasMore       = false;
        $this->runSearchFullPage();
    }

    /**
     * Vide la recherche.
     */
    public function clear(): void
    {
        $this->query         = '';
        $this->results       = [];
        $this->loadedResults = [];
        $this->totalResults  = 0;
        $this->page          = 1;
        $this->hasMore       = false;
        $this->activeCategory = null;
    }

    // ── Core search logic ──────────────────────────────────────────────────

    /**
     * Recherche dropdown — résultats limités par catégorie.
     */
    protected function runSearch(): void
    {
        $q           = trim($this->query);
        $perCategory = config('mt-search.per_category', 5);
        $grouped     = [];
        $total       = 0;

        foreach ($this->getProviders() as $class) {
            if (! $this->implementsSearchable($class)) continue;
            if ($this->activeCategory && $this->activeCategory !== $class) continue;

            $items = $class::searchQuery($q)
                ->limit($perCategory)
                ->get()
                ->map(fn ($model) => $model->toSearchResult())
                ->toArray();

            if (count($items) > 0) {
                $grouped[] = [
                    'category' => $class::searchCategory(),
                    'icon'     => $class::searchIcon(),
                    'color'    => $class::searchColor(),
                    'class'    => $class,
                    'items'    => $this->highlight($items, $q),
                    'count'    => $class::searchQuery($q)->count(),
                ];
                $total += count($items);
            }
        }

        $this->results      = $grouped;
        $this->totalResults = $total;
    }

    /**
     * Recherche full-page avec pagination.
     */
    protected function runSearchFullPage(bool $append = false): void
    {
        $q       = trim($this->query);
        $perPage = config('mt-search.per_page', 15);
        $offset  = ($this->page - 1) * $perPage;
        $items   = [];
        $total   = 0;

        foreach ($this->getProviders() as $class) {
            if (! $this->implementsSearchable($class)) continue;
            if ($this->activeCategory && $this->activeCategory !== $class) continue;

            $results = $class::searchQuery($q)
                ->offset($offset)
                ->limit($perPage)
                ->get()
                ->map(fn ($model) => array_merge(
                    $model->toSearchResult(),
                    [
                        'category' => $class::searchCategory(),
                        'icon'     => $class::searchIcon(),
                        'color'    => $class::searchColor(),
                    ]
                ))
                ->toArray();

            $items = array_merge($items, $results);
            $total += $class::searchQuery($q)->count();
        }

        $highlighted = $this->highlight($items, $q);

        if ($append) {
            $this->loadedResults = array_merge($this->loadedResults, $highlighted);
        } else {
            $this->loadedResults = $highlighted;
        }

        $this->totalResults = $total;
        $this->hasMore      = count($this->loadedResults) < $total;
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    /**
     * Entoure les occurrences du terme dans title/subtitle avec <mark>.
     */
    protected function highlight(array $items, string $query): array
    {
        if (trim($query) === '') return $items;

        $escaped = preg_quote($query, '/');

        return array_map(function (array $item) use ($escaped) {
            foreach (['title', 'subtitle'] as $field) {
                if (! empty($item[$field])) {
                    $item[$field] = preg_replace(
                        "/({$escaped})/iu",
                        '<mark class="search-highlight">$1</mark>',
                        $item[$field]
                    );
                }
            }
            return $item;
        }, $items);
    }

    /**
     * Retourne les classes de providers configurés.
     */
    protected function getProviders(): array
    {
        return config('mt-search.providers', []);
    }

    /**
     * Vérifie qu'un modèle implémente bien Searchable.
     */
    protected function implementsSearchable(string $class): bool
    {
        return class_exists($class)
            && in_array(Searchable::class, class_implements($class) ?: []);
    }

    // ── Render ─────────────────────────────────────────────────────────────

    public function render()
    {
        return view('mt::livewire.search.global-search', [
            'categories' => $this->categories,
        ]);
    }
}
