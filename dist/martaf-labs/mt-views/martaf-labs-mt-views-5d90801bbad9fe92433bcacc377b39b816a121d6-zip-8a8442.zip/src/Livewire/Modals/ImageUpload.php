<?php

namespace Mt\MtViews\Livewire\Modals;

use Flux\Flux;
use Mt\MtViews\Models\BaseImage;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\Attributes\Validate;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ImageUpload extends Component
{
    use WithFileUploads;

    public $modelClass;
    public $isOpen = false;
    public $entity = null;
    public $entityId;
    public $maxFiles = 10;
    public $existingImages = [];

    #[Validate([
        'images.*' => 'image|max:10240|mimes:jpg,jpeg,png,gif,webp',
    ], message: [
        'images.*.image' => 'Le fichier doit être une image',
        'images.*.max' => 'L\'image ne doit pas dépasser 10MB',
        'images.*.mimes' => 'Formats acceptés: JPG, JPEG, PNG, GIF, WEBP',
    ])]
    public $images = [];

    protected $listeners = [
        'open-image-upload-modal' => 'openImageUploadModal',
        'refresh-images' => 'refreshImages',
    ];

    public function openImageUploadModal($modelClass, $entityId)
    {
        $this->entityId = $entityId;

        $modelClass=$this->modelClass;
        $this->entity=$modelClass::find($this->entityId);

        $this->existingImages = $this->entity->images;

        $this->isOpen = true;
        $this->reset('images');
        $this->resetValidation();
    }

    public function closeModal()
    {
        $this->isOpen = false;
        $this->reset(['modelClass', 'entityId', 'images', 'existingImages']);
        $this->resetValidation();
        $this->dispatch('imagesUpdated');
        $this->dispatch('refresh-data');
    }

    public function refreshImages($images)
    {
        $this->existingImages = $images;
    }

    public function updatedImages()
    {
        $this->validateOnly('images');

        // Limiter le nombre de fichiers
        if (count($this->images) > $this->maxFiles) {
            $this->addError('images', "Vous ne pouvez pas uploader plus de {$this->maxFiles} images à la fois.");
            $this->images = array_slice($this->images, 0, $this->maxFiles);
        }
    }

    public function removeTemporaryImage($index)
    {
        if (isset($this->images[$index])) {
            unset($this->images[$index]);
            $this->images = array_values($this->images); // Réindexer le tableau
        }
    }

    public function removeExistingImage($imageId)
    {
        
        try {
            // Trouver l'image dans les images existantes
            $imageToDelete = collect($this->existingImages)->firstWhere('id', $imageId);
            if ($imageToDelete) {
                // Supprimer le fichier physique
                if (Storage::disk(mt_get_storage_disk())->exists($imageToDelete['path'])) {
                   Storage::disk(mt_get_storage_disk())->delete($imageToDelete['path']);
                }

                // Supprimer de la base de données (adaptez selon votre structure)
                Image::find($imageId)->delete();

                // Mettre à jour la liste des images existantes
                $this->existingImages = $this->entity->images;

                $this->dispatch('notify', [
                    'type' => 'success',
                    'message' => 'Image supprimée avec succès'
                ]);

                $this->dispatch('imagesUpdated');
            }
        } catch (\Exception $e) {
            $this->dispatch('notify', [
                'type' => 'error',
                'message' => 'Erreur lors de la suppression de l\'image'
            ]);
        }
    }

    public function save()
    {

        $this->validate();

        $modelClass=$this->modelClass;
        $this->entity=$modelClass::find($this->entityId);
        $uploadedImages=[];
        if (empty($this->images)) {
            $this->addError('images', 'Veuillez sélectionner au moins une image');
            return;
        }

        try {

            foreach ($this->images as $image) {
                $path = $image->store('imageUploads', mt_get_storage_disk());

                if ($path) {

                    // Créer l'entrée en base de données
                    $imageModel = [
                        'nom' => uniqid(get_class($this->entity).'_'),
                        'path' => $path,
                        'user_id' => Auth::id(),
                    ];

                    $newImage=Image::create($imageModel);
                    if ($newImage) {
                        $this->entity->images()->syncWithoutDetaching($newImage->id);
                        $uploadedImages[]=$newImage->id;
                    }
                }
            }

            // Ajouter aux images existantes
            $this->existingImages = $this->entity->images;
            $this->dispatch('notify', [
                'type' => 'success',
                'message' => count($uploadedImages) . ' image(s) uploadée(s) avec succès'
            ]);

            $this->reset('images');
            $this->dispatch('imagesUpdated', $this->existingImages);
            $this->isOpen = false;
            // return redirect(request()->header('Referer'));

        } catch (\Exception $e) {
            $this->dispatch('notify', [
                'type' => 'error',
                'message' => 'Erreur lors de l\'upload des images: ' . $e->getMessage()
            ]);
        }
    }

    public function setAsMainImage($imageId)
    {
        // Mettre à jour l'image principale dans la base de données
        // Exemple:
        $imageChoisit=Image::find($imageId);
        $modelClass=$this->modelClass;
        $this->entity=$modelClass::find($this->entityId);
        $this->entity->update(['image' => $imageChoisit->path]);


        $this->dispatch('notify', [
            'type' => 'success',
            'message' => 'Image principale mise à jour'
        ]);

        $this->dispatch('imagesUpdated', $this->existingImages);
        $this->dispatch('refresh-data');
        $this->isOpen = false;
    }
    public function render(){
        return view("livewire.modals.image-upload");

    }
}
