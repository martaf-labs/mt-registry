<?php

namespace Mt\MtViews\Livewire\Modals;

use Livewire\Component;
use Livewire\Attributes\On;

class Confirm extends Component
{
    public $isOpen = false;
    public $title = 'Confirmation';
    public $message = 'Êtes-vous sûr de vouloir effectuer cette action ?';
    public $confirmText = 'Confirmer';
    public $cancelText = 'Annuler';
    public $variant = 'danger'; // danger, primary, success, warning
    public $icon = 'exclamation-triangle';
    public $action;
    public $actionParams = [];

    #[On('open-confirm-modal')]
    public function openConfirmModal($config)
    {
        $this->title = $config['title'] ?? $this->title;
        $this->message = $config['message'] ?? $this->message;
        $this->confirmText = $config['confirmText'] ?? $this->confirmText;
        $this->cancelText = $config['cancelText'] ?? $this->cancelText;
        $this->variant = $config['variant'] ?? $this->variant;
        $this->icon = $config['icon'] ?? $this->icon;
        $this->action = $config['action'] ?? null;
        $this->actionParams = $config['actionParams'] ?? [];
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
        $this->resetExcept(['isOpen']);
    }

    public function confirm()
    {
        if ($this->action) {
            // Émettre l'action avec les paramètres
            $this->dispatch($this->action, ...$this->actionParams);
        }

        $this->closeModal();
    }

    public function render()
    {
        return view('mt::livewire.modals.confirm');
    }
}
