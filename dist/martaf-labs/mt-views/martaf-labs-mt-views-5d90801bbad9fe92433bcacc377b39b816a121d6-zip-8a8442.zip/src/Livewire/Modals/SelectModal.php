<?php

namespace Mt\MtViews\Livewire\Modals;

use Livewire\Component;

class SelectModal extends Component
{
    public $items = [];
    public $selected = [];
    public $mode = 'single'; // 'single' ou 'multiple'
    public $showModal = false;

    public $label = 'Sélectionner un élément';

    public function mount($items = [], $mode = 'single', $label = null)
    {
        $this->mode = $mode;
        if ($label) $this->label = $label;
    }

    public function open()
    {
        $this->showModal = true;
    }

    public function close()
    {
        $this->showModal = false;
    }

    public function render()
    {
        return view('mt::livewire.modals.select-modal');
    }
}
