<?php

namespace Mt\MtViews\Livewire\Modals;

use Livewire\Component;

class Alert extends Component
{
    public $isOpen = false;
    public $title = 'Information';
    public $message = 'Opération effectuée avec succès.';
    public $buttonText = 'Fermer';
    public $variant = 'success'; // success, error, warning, info
    public $icon = 'check-circle';
    public $autoClose = false;
    public $autoCloseDelay = 3000;

    public function mount(){
        
        if (session()->has('open-alert-modal')) {
            $config = session('open-alert-modal');
            $this->openAlertModal($config);
        }
    }


    #[On('open-alert-modal')]
    public function openAlertModal($config)
    {
        $this->title = $config['title'] ?? $this->title;
        $this->message = $config['message'] ?? $this->message;
        $this->buttonText = $config['buttonText'] ?? $this->buttonText;
        $this->variant = $config['variant'] ?? $this->variant;
        $this->icon = $config['icon'] ?? $this->icon;
        $this->autoClose = $config['autoClose'] ?? $this->autoClose;
        $this->autoCloseDelay = $config['autoCloseDelay'] ?? $this->autoCloseDelay;

        $this->isOpen = true;

        // Fermeture automatique si activée
        if ($this->autoClose) {
            $this->dispatch('startAutoClose', delay: $this->autoCloseDelay);
        }
    }

    public function closeModal()
    {
        $this->isOpen = false;
        $this->resetExcept(['isOpen']);
    }

    public function render()
    {
        return view('mt::livewire.modals.alert');
    }
}
