<?php

namespace Mt\MtViews\Livewire\Auth;

use Mt\MtViews\Models\BaseUser;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Laravel\Fortify\Features;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

/**
 * Composant Livewire 3 — Authentification multi-variantes
 *
 * ─────────────────────────────────────────────────────────────────
 * SYSTÈME DE LAYOUT
 * Calqué sur le même procédé qu'ArticleShow :
 *   → chaque variante = un fichier Blade dédié
 *   → render() résout la vue dynamiquement : 'mt::livewire.auth.login.' . $layout
 *   → layout configuré via mt_config('login_layout') ou .env MT_LOGIN_LAYOUT
 *
 * Valeurs : 'classic' | 'split' | 'minimal' | 'immersive'
 * Défaut  : 'classic'
 * ─────────────────────────────────────────────────────────────────
 */
#[Layout('mt::components.layouts.auth')]
class Login extends Component
{
    public const LAYOUTS = ['classic', 'split', 'minimal', 'immersive'];

    // ── Layout ──────────────────────────────────────────────────
    public string $layout = 'classic';

    // ── État ────────────────────────────────────────────────────
    #[Validate('required|string|email|max:255', message: [
        'required' => "L'adresse e-mail est obligatoire.",
        'email'    => 'Veuillez entrer une adresse e-mail valide.',
        'max'      => "L'adresse e-mail ne doit pas dépasser 255 caractères.",
    ])]
    public string $email = '';

    #[Validate('required|string|min:8', message: [
        'required' => 'Le mot de passe est obligatoire.',
        'min'      => 'Le mot de passe doit contenir au moins 8 caractères.',
    ])]
    public string $password = '';

    public bool $remember = false;

    // ── Mount ───────────────────────────────────────────────────
    public function mount(): void
    {
        // Redirige si déjà connecté
        if (Auth::check()) {
            $this->redirectIntended(
                default: route('dashboard', absolute: false),
                navigate: true
            );
            return;
        }

        // Layout depuis la config (même pattern que mtblog_config('article-show.layout'))
        $configured   = mt_config('login.layout');
        $this->layout = in_array($configured, self::LAYOUTS, true) ? $configured : 'classic';
    }

    // ── Actions ─────────────────────────────────────────────────

    public function login(): void
    {
        $this->validate();
        $this->ensureIsNotRateLimited();

        $user = $this->validateCredentials();

        // Two-Factor Authentication (Fortify)
        if (
            class_exists(Features::class)
            && Features::canManageTwoFactorAuthentication()
            && method_exists($user, 'hasEnabledTwoFactorAuthentication')
            && $user->hasEnabledTwoFactorAuthentication()
        ) {
            Session::put([
                'login.id'       => $user->getKey(),
                'login.remember' => $this->remember,
            ]);
            $this->redirect(route('two-factor.login'), navigate: true);
            return;
        }

        Auth::login($user, $this->remember);

        // Session::regenerate() APRÈS Auth::login() — évite race condition CSRF Livewire 3
        Session::regenerate();
        RateLimiter::clear($this->throttleKey());

        $this->redirectIntended(
            default: route('dashboard', absolute: false),
            navigate: true
        );
    }

    // ── Helpers ─────────────────────────────────────────────────

    protected function validateCredentials(): BaseUser
    {
        /** @var BaseUser|null $user */
        $user = Auth::getProvider()->retrieveByCredentials([
            'email' => $this->email,
        ]);

        if (! $user || ! Auth::getProvider()->validateCredentials($user, [
            'password' => $this->password,
        ])) {
            RateLimiter::hit($this->throttleKey());
            $this->reset('password');

            throw ValidationException::withMessages([
                'email' => __('auth.failed'),
            ]);
        }

        return $user;
    }

    protected function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        event(new Lockout(request()));
        $seconds = RateLimiter::availableIn($this->throttleKey());

        throw ValidationException::withMessages([
            'email' => __('auth.throttle', [
                'seconds' => $seconds,
                'minutes' => (int) ceil($seconds / 60),
            ]),
        ]);
    }

    protected function throttleKey(): string
    {
        return Str::transliterate(
            Str::lower($this->email) . '|' . request()->ip()
        );
    }

    // ── Render ──────────────────────────────────────────────────

    /**
     * Même pattern qu'ArticleShow :
     * render() résout dynamiquement la vue selon $layout.
     */
    public function render(): \Illuminate\View\View
    {
        return view('mt::livewire.auth.login.' . $this->layout, [
            'hasLogo' => has_option_login('logo'),
            'hasRemember' => has_option_login('remember'),
            'hasPasswordReset' => has_option_login('password_reset') && \Illuminate\Support\Facades\Route::has('password.request'),
            'hasRegister'      => has_option_login('register') && \Illuminate\Support\Facades\Route::has('register'),
            'hasHome'          => has_option_login('home') && \Illuminate\Support\Facades\Route::has('home'),
        ]);
    }
}
