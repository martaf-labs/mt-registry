<?php

namespace Mt\MtViews\Traits;

trait WithFormSteps
{
    public int $currentStep = 1;
    public array $completedSteps = [];
    public bool $hasSteps = false;
    public array $availableSteps = [];

    /**
     * Définition des étapes du formulaire
     * Retourne un tableau vide pour les formulaires mono-étape
     */
    public function steps(): array
    {
        return []; // Par défaut, pas d'étapes
    }
    
    /**
     * Conditions pour afficher une étape
     * À surcharger dans le composant
     */
    public function stepCondition(int $step): bool
    {
        return true; // Par défaut, toutes les étapes sont visibles
    }
    
     /**
     * Initialise les étapes disponibles
     */
    public function initializeAvailableSteps(): void
    {
        $this->availableSteps = [];
        
        foreach ($this->steps() as $stepNumber => $stepConfig) {
            if ($this->stepCondition($stepNumber)) {
                $this->availableSteps[$stepNumber] = $stepConfig;
            }
        }
    }

    /**
     * Vérifie si le formulaire a plusieurs étapes
     */
    public function hasMultipleSteps(): bool
    {
        if (!$this->hasSteps) {
            $this->hasSteps = count($this->steps()) > 1;
        }
        return $this->hasSteps;
    }
    
    /**
    * Nombre total d'étapes disponibles
    */
    public function getAvailableStepsCount(): int
    {
        return count($this->availableSteps);
    }
    
    /**
     * Obtient le numéro réel de l'étape basé sur les étapes disponibles
     */
    public function getRealStepNumber(int $virtualStep): int
    {
        $availableSteps = array_keys($this->availableSteps);
        return $availableSteps[$virtualStep - 1] ?? $virtualStep;
    }
    
    /**
     * Obtient l'étape virtuelle basée sur le numéro réel
     */
    public function getVirtualStepNumber(int $realStep): int
    {
        $availableSteps = array_keys($this->availableSteps);
        $position = array_search($realStep, $availableSteps);
        return $position !== false ? $position + 1 : 1;
    }

       /**
     * Validation pour une étape spécifique
     */
    public function validateStep(int $step): bool
    {
        // Pour les formulaires mono-étape, validation complète
        if (!$this->hasMultipleSteps()) {
            $monoStepRules = [];
            foreach ($this->form->rules() as $key => $rule) {
                $monoStepRules["form.$key"] = $rule;
            }
            
            try {
                $this->validate($monoStepRules, $this->getStepMessages($step));
                return true;
            } catch (\Illuminate\Validation\ValidationException $e) {
                $this->dispatch('scroll-to-top');
                throw $e;
            }
        }
        $realStep = $this->getRealStepNumber($step);
        
        if (!isset($this->steps()[$realStep]['fields'])) {
            return true;
        }
        
        $stepRules = $this->getStepRules($realStep);
        if (empty($stepRules)) {
            return true;
        }

        try {
            $this->validate($stepRules, $this->getStepMessages($realStep));
            
            return true;
        } catch (\Illuminate\Validation\ValidationException $e) {
            $this->dispatch('scroll-to-top');
            throw $e;
        }
    }
    /**
     * Règles de validation pour une étape spécifique
     * (À surcharger dans le composant si nécessaire)
     */
    public function getStepRules(int $step): array
    {
        if (!$this->hasMultipleSteps()) {
            return $this->form->rules();
        }

        $stepRules = [];
        foreach ($this->form->rules()[$step] as $key => $rule) {
            $stepRules["form.$key"] = $rule;
        }

        $stepFields = $this->steps()[$step]['fields'] ?? [];

        // foreach ($stepFields as $field) {

        //     if (array_key_exists($field, $allRules)){
        //         // Si la règle est un tableau (ex: pour fichiers multiples)
        //         if (is_array($allRules[$field])) {
        //             foreach ($allRules[$field] as $subKey => $rule) {
        //                 $stepRules[$field.'.'.$subKey] = $rule;
        //             }
        //             unset($allRules[$field]);
        //         } else {
        //             $stepRules[$field] = $allRules[$field];
        //         }
        //     }
        // }
        // foreach ($stepFields as $field) {
        //     if (isset($allRules[$field])) {
        //         $stepRules[$field] = $allRules[$field];
        //     } elseif (isset($allRules[$field . '.*'])) {
        //         $stepRules[$field . '.*'] = $allRules[$field . '.*'];
        //     } elseif (isset($allRules[$field . '.fr'])) {
        //         $stepRules[$field . '.fr'] = $allRules[$field . '.fr'];
        //     } elseif (isset($allRules[$field . '.ar'])) {
        //         $stepRules[$field . '.ar'] = $allRules[$field . '.ar'];
        //     } elseif (isset($allRules[$field . '.en'])) {
        //         $stepRules[$field . '.en'] = $allRules[$field . '.en'];
        //     }
        // }
        return $stepRules;
    }

    /**
     * Messages de validation pour une étape spécifique
     * (À surcharger dans le composant si nécessaire)
     */
    public function getStepMessages(int $step): array
    {
        $allMessage=$this->form->messages();
        $stepMessage = [];
   
        if(array_key_exists($step, $allMessage)) {
            foreach ($this->form->messages()[$step] as $key => $msg) {
                $stepMessage["form.$key"] = $msg;
            }
        }
        else{
            foreach ($this->form->messages() as $key => $msg) {
                $stepMessage["form.$key"] = $msg;
            }
        }

        // dd('', $allMessage);
        // $stepMessage=in_array($step, array_keys($allMessage)) ? $allMessage[$step] : [];

        // $stepRules= $this->getStepRules($step);

        // foreach ($stepRules as $field => $rule) {
        //     if (!isset($stepRules[$field . '.fr'])) {
        //         $stepMessages[$field . '.fr'] = '';
        //     }
        // }

        return $stepMessage ?? [];
    }

    /**
     * Aller à une étape spécifique (par numéro virtuel)
     */
    public function goToStep(int $step): void
    {
        // Recalculer les étapes disponibles
        $this->initializeAvailableSteps();

        $stepsToDisplay = $this->getStepsToDisplay();
        $maxVirtual = count($stepsToDisplay);

        if (!$this->hasMultipleSteps() || $step < 1 || $step > $maxVirtual) {
            return;
        }

        // Valider l'étape actuelle avant d'avancer
        if ($step > $this->currentStep && !$this->validateStep($this->currentStep)) {
            return;
        }

        $this->currentStep = $step;

        // Marquer les étapes précédentes comme complétées
        $virtualStepNumbers = array_keys($stepsToDisplay);
        foreach ($virtualStepNumbers as $v) {
            if ($v < $step && !in_array($v, $this->completedSteps)) {
                $this->completedSteps[] = $v;
            }
        }

        $this->dispatch('step-changed', step: $step);
    }
    
    /**
     * Étape suivante
     */
    public function nextStep(): void
    {
        if (!$this->hasMultipleSteps()) {
            return;
        }

        if (!$this->validateStep($this->currentStep)) {
            return;
        }

        $this->completedSteps[] = $this->currentStep;

        // Recalculer les étapes disponibles avec les valeurs actuelles du formulaire
        $this->initializeAvailableSteps();

        // getStepsToDisplay() retourne les étapes indexées par numéro virtuel (1, 2, 3...)
        $stepsToDisplay = $this->getStepsToDisplay();
        $virtualStepNumbers = array_keys($stepsToDisplay);

        // Trouver le prochain numéro virtuel strictement après currentStep
        $nextVirtual = null;
        foreach ($virtualStepNumbers as $v) {
            if ($v > $this->currentStep) {
                $nextVirtual = $v;
                break;
            }
        }

        if (!is_null($nextVirtual)) {
            $this->currentStep = $nextVirtual;
            $this->dispatch('step-changed', step: $this->currentStep);
        }
    }
    
    /**
     * Étape précédente
     */
    public function previousStep(): void
    {
        if (!$this->hasMultipleSteps() || $this->currentStep <= 1) {
            return;
        }

        // Recalculer les étapes disponibles
        $this->initializeAvailableSteps();

        $stepsToDisplay = $this->getStepsToDisplay();
        $virtualStepNumbers = array_keys($stepsToDisplay);

        // Trouver le numéro virtuel strictement avant currentStep
        $prevVirtual = null;
        foreach (array_reverse($virtualStepNumbers) as $v) {
            if ($v < $this->currentStep) {
                $prevVirtual = $v;
                break;
            }
        }

        if (!is_null($prevVirtual)) {
            $this->currentStep = $prevVirtual;
            $this->dispatch('step-changed', step: $this->currentStep);
        }
    }
    
    /**
     * Vérifie si une étape est complétée
     */
    public function isStepCompleted(int $step): bool
    {
        return in_array($step, $this->completedSteps);
    }
    
    /**
     * Vérifie si une étape est active
     */
    public function isStepActive(int $step): bool
    {
        return $this->currentStep === $step;
    }
    
    /**
     * Vérifie si une étape est disponible
     */
    public function isStepAvailable(int $step): bool
    {
        return $this->shouldShowStep($step);
    }
    
    /**
     * Obtenir le pourcentage de progression
     */
    public function getProgressPercentage(): int
    {
        if (!$this->hasMultipleSteps()) {
            return 100;
        }

        $totalSteps = $this->getAvailableStepsCount();
        $completed = count($this->completedSteps);
        
        // Valider l'étape actuelle
        try {
            $this->validateStep($this->currentStep);
            $completed++;
        } catch (\Illuminate\Validation\ValidationException $e) {
            // L'étape n'est pas validée, on ne l'ajoute pas
        }
        
        return $totalSteps > 0 ? (int) round(($completed / $totalSteps) * 100) : 100;
    }
    
    /**
     * Obtenir les champs de l'étape actuelle
     */
    public function getCurrentStepFields(): array
    {
        if (!$this->hasMultipleSteps()) {
            return $this->form->schema(); // Tous les champs pour mono-étape
        }
        
        $realStep = $this->getRealStepNumber($this->currentStep);
        $schema = $this->form->schema();
        $currentStepFields = [];
        
        if (isset($this->steps()[$realStep]['fields'])) {
            foreach ($this->steps()[$realStep]['fields'] as $field) {
                if (isset($schema[$field])) {
                    $currentStepFields[$field] = $schema[$field];
                }
            }
        }
        // if ($realStep == 2) {
        //     dd($currentStepFields);
        // }
        
        return $currentStepFields;
    }
    
    /**
     * Obtient les étapes à afficher
     */
    public function getStepsToDisplay(): array
    {
        if (!$this->hasMultipleSteps()) {
            return [];
        }
        
        $stepsToDisplay = [];
        $virtualStep = 1;

        foreach ($this->steps() as $stepNumber => $stepConfig) {
            if ($this->stepCondition($stepNumber)) {
                $stepsToDisplay[$virtualStep] = array_merge($stepConfig, ['realStep' => $stepNumber]);
                $virtualStep++;
            }
        }
        
        return $stepsToDisplay;
    }
}