<div>
    @php
        $name= "data-exporter-modal";
    @endphp


    <flux:modal name="{{ $name }}" class="w-4xl" wire:model="isOpen"  :dismissible="false" :closable="true">

        <div>
            <flux:heading size="lg">
                📸 Exporter les données vers...
            </flux:heading>
            <flux:text class="my-4">
                Sélectionnez le format et les colonnes pour l'exportation
            </flux:text>
        </div>

        <div class="h-full w-full">
            <div class="space-y-4 h-full border-1 p-5 border-dashed rounded-lg border-zinc-300">

                <div class="p-6">
                    <!-- En-tête -->
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            Exporter les données
                        </h3>

                        @if($exportSuccess)
                            <div class="flex items-center gap-2 text-green-600 dark:text-green-400">
                                <flux:icon name="check-circle" class="w-5 h-5" />
                                <span class="text-sm font-medium">Export réussi</span>
                            </div>
                        @endif
                    </div>

                    <!-- Sélection du format -->
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Format d'export
                            </label>
                            <div class="grid grid-cols-2 md:grid-cols-5 gap-2">
                                @foreach([
                                    'excel' => ['color' => 'bg-green-50 border-green-200 text-green-700', 'icon' => '📊', 'label' => 'Excel'],
                                    // 'csv' => ['color' => 'bg-blue-50 border-blue-200 text-blue-700', 'icon' => '📝', 'label' => 'CSV'],
                                    'pdf' => ['color' => 'bg-red-50 border-red-200 text-red-700', 'icon' => '📄', 'label' => 'PDF'],
                                    // 'json' => ['color' => 'bg-yellow-50 border-yellow-200 text-yellow-700', 'icon' => '🔶', 'label' => 'JSON'],
                                    // 'xml' => ['color' => 'bg-purple-50 border-purple-200 text-purple-700', 'icon' => '📋', 'label' => 'XML'],
                                ] as $format => $config)
                                    <button
                                        type="button"
                                        wire:click="$set('selectedFormat', '{{ $format }}')"
                                        class="p-3 border-2 rounded-lg text-center transition-all duration-200 hover:scale-105 {{ $selectedFormat === $format ? 'ring-2 ring-offset-2 ring-primary-500 ' . $config['color'] : 'bg-white dark:bg-zinc-700 border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300' }}"
                                    >
                                        <div class="text-2xl mb-1">{{ $config['icon'] }}</div>
                                        <div class="text-sm font-medium">{{ $config['label'] }}</div>
                                    </button>
                                @endforeach
                            </div>
                        </div>

                        <div class="py-4">

                            <!-- Champs à exportés du -->
                            <flux:select wire:model.defer='selectedcolumns' multiple>

                                @forelse ($allowedcolumns as $field => $label)
                                    <option value="{{ $field }}" selected="{{ in_array($field, $selectedcolumns) }}">{{ $label }}</option>
                                @empty
                                    <option value="">Aucune les colones...</option>
                                @endforelse

                            </flux:select>


                            <!-- Nom du fichier -->
                            <flux:input type="text" wire:model="filename" label="Nom du fichier" />



                        </div>

                        <div class="flex items-center justify-between pt-4">
                            <div class="text-sm text-gray-500 dark:text-gray-400">
                                @if($data && count($data) > 0)
                                    {{ count($data) }} enregistrement(s) à exporter
                                @else
                                    Aucune donnée à exporter
                                @endif
                            </div>
                    </div>
                </div>

            </div>

        </div>

        <!-- Message d'erreur -->
        @if($exportMessage)
            <div class="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
                <div class="flex items-center">
                    <flux:icon name="exclamation-triangle" class="w-5 h-5 text-red-400 mr-2" />
                    <span class="text-sm text-red-700 dark:text-red-400">{{ $exportMessage }}</span>
                </div>
            </div>
        @endif

        <flux:spacer />

        <div class="flex justify-end gap-3 mt-4 pt-4">

            <flux:button
                variant="primary"
                icon="arrow-down-tray"
                wire:click="export"
                wire:loading.attr="disabled"
                wire:target="export"
                :disabled="count($data ?? []) === 0"
                class="bg-green-700 text-white hover:text-gray-900"
            >
                {{-- <flux:icon name="arrow-down-tray" class="w-4 h-4 mr-2" /> --}}
                <span wire:loading.remove wire:target="export">
                    Exporter en {{ strtoupper($selectedFormat) }}
                </span>
                <span wire:loading wire:target="export">
                    <flux:icon name="arrow-path" class="w-4 h-4 mr-2 animate-spin" />
                    Export en cours...
                </span>
            </flux:button>
        </div>
    </flux:modal>

</div>




