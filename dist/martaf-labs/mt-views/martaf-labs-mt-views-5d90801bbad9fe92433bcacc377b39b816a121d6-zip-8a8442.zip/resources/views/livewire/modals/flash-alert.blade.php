{{-- 
    Composant Livewire "flash-alert" :
    Ce composant permet d'afficher des messages flash (mtSuccess, mtError, mtWarning, mtInfo) de manière centralisée dans l'application.
    Il doit être inclus une seule fois dans le layout principal (ex: app.blade.php).
    Exemple d'utilisation dans un autre composant Livewire :
    Dans n’importe quel composant Livewire, tu fais :

    $this->dispatchBrowserEvent('flash', [
        'mtSuccess' => 'Opération réussie !',
        'mtError'   => null,
        'mtWarning' => null,
        'mtInfo'    => null,
    ]);

    Exemple pour un message d’erreur :

    $this->dispatchBrowserEvent('flash', [
        'mtError' => 'Une erreur est survenue !'
    ]);

        Le message s'affichera automatiquement dans le coin supérieur droit de l'écran et disparaîtra après 5 secondes.
--}}

<div 
    x-data="{ 
        success: null, 
        error: null, 
        warning: null, 
        info: null 
    }"
    x-show="success || error || warning || info"
    x-transition:enter="transition ease-out duration-300"
    x-transition:enter-start="opacity-0 transform -translate-y-2"
    x-transition:enter-end="opacity-100 transform translate-y-0"
    class="fixed top-4 right-4 z-50 max-w-md space-y-2"
    @flash.window="success = $event.detail.mtSuccess ?? null;
                    error   = $event.detail.mtError   ?? null;
                    warning = $event.detail.mtWarning ?? null;
                    info    = $event.detail.mtInfo    ?? null;
                    setTimeout(() => { success=null; error=null; warning=null; info=null }, 5000);">

    <!-- Success -->
    <template x-if="success">
        <div class="bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-200 dark:border-emerald-800 rounded-xl shadow-lg p-4 flex justify-between items-start">
            <div class="flex items-start">
                <i class="fa-solid fa-check-circle text-emerald-500 dark:text-emerald-400 mt-1"></i>
                <p class="ml-3 text-sm font-medium text-emerald-800 dark:text-emerald-200" x-text="success"></p>
            </div>
            <button @click="success=null" class="ml-4 text-emerald-500 dark:text-emerald-400 hover:text-emerald-700">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    </template>

    <!-- Error -->
    <template x-if="error">
        <div class="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-xl shadow-lg p-4 flex justify-between items-start">
            <div class="flex items-start">
                <i class="fa-solid fa-exclamation-circle text-red-500 dark:text-red-400 mt-1"></i>
                <p class="ml-3 text-sm font-medium text-red-800 dark:text-red-200" x-text="error"></p>
            </div>
            <button @click="error=null" class="ml-4 text-red-500 dark:text-red-400 hover:text-red-700">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    </template>

    <!-- Warning -->
    <template x-if="warning">
        <div class="bg-yellow-50 dark:bg-yellow-900/30 border border-yellow-200 dark:border-yellow-800 rounded-xl shadow-lg p-4 flex justify-between items-start">
            <div class="flex items-start">
                <i class="fa-solid fa-exclamation-triangle text-yellow-500 dark:text-yellow-400 mt-1"></i>
                <p class="ml-3 text-sm font-medium text-yellow-800 dark:text-yellow-200" x-text="warning"></p>
            </div>
            <button @click="warning=null" class="ml-4 text-yellow-500 dark:text-yellow-400 hover:text-yellow-700">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    </template>

    <!-- Info -->
    <template x-if="info">
        <div class="bg-blue-50 dark:bg-blue-95/3 border border-blue-2/3 dark:border-blue--8/3 rounded-xl shadow-lg p-[16px] flex justify-between items-start">
            <div class="flex items-start">
                <i class="fa-solid fa-info-circle text-blue--5/3 dark:text-blue--4/3 mt-[6px]"></i>
                <p class="ml-[12px] text-sm font-medium text-blue--8/3 dark:text-blue--2/3" x-text="info"></p>
            </div>
            <button @click="info=null" class="ml-[16px] text-blue--5/3 dark:text-blue--4/3 hover:text-blue--7/3">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    </template>

</div>
