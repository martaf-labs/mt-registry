<flux:modal
    wire:model="isOpen"
    class="w-96"
    :dismissible="false"
    :closable="false"
>
    <div class="text-center">
        <div class="flex flex-col items-center gap-4 p-6">
            <!-- Icône -->
            <div class="p-3 rounded-full {{
                match($variant) {
                    'danger' => 'bg-red-100 text-red-600 dark:bg-red-900/20 dark:text-red-400',
                    'primary' => 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',
                    'success' => 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400',
                    'warning' => 'bg-amber-100 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400',
                    default => 'bg-red-100 text-red-600 dark:bg-red-900/20 dark:text-red-400'
                }
            }}">
                <flux:icon name="{{ $icon }}" class="w-6 h-6" />
            </div>

            <!-- Titre -->
            <flux:heading size="lg">
                {{ $title }}
            </flux:heading>

            <!-- Message -->
            <flux:text class="mt-2">
                {!!  $message  !!}
            </flux:text>
        </div>
    </div>

    <div class="flex justify-center gap-3">
        <flux:button
            variant="filled"
            wire:click="closeModal"
            class="min-w-24"
        >
            {{ $cancelText }}
        </flux:button>

        <flux:button
            :variant="$variant"
            wire:click="confirm"
            class="min-w-24"
        >
            {{ $confirmText }}
        </flux:button>
    </div>
</flux:modal>
