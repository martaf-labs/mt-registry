<div 
    x-data="{
        showModal: @entangle('showModal'),
        mode: '{{ $mode }}',
        selected: @entangle('selected'),
        toggle(item) {
            if (this.mode === 'single') {
                this.selected = [item];
            } else {
                const i = this.selected.findIndex(s => s.id === item.id && s.type === item.type);
                if (i >= 0) this.selected.splice(i, 1);
                else this.selected.push(item);
            }
        },
        isSelected(item) {
            return this.selected.some(s => s.id === item.id && s.type === item.type);
        },
        clear() {
            this.selected = [];
        }
    }"
>
    <!-- Bouton d'ouverture -->
    <div class="flex items-center space-x-2">
        <button 
            type="button"
            class="px-3 py-1 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
            @click="showModal = true"
        >
            {{ $label }}
        </button>

        <!-- Résumé des sélections -->
        <template x-if="selected.length > 0">
            <div class="flex flex-wrap space-x-1">
                <template x-for="item in selected" :key="item.id + '-' + item.type">
                    <span class="px-2 py-1 bg-gray-200 text-xs rounded-md" x-text="item.name"></span>
                </template>
            </div>
        </template>
    </div>

    <!-- Champ caché synchronisé avec Livewire -->
    <input type="hidden" name="selected_items" x-model="JSON.stringify(selected)" wire:model="selected">

    <!-- MODAL -->
    <div 
        x-show="showModal" 
        x-transition
        class="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
    >
        <div 
            class="bg-white rounded-lg w-full max-w-md p-4 relative"
            @click.away="showModal = false"
        >
            <!-- En-tête -->
            <div class="flex justify-between items-center mb-2">
                <h3 class="text-lg font-semibold">Sélection des éléments</h3>
                <button @click="showModal = false" class="text-gray-500 hover:text-gray-700">✕</button>
            </div>

            <!-- Liste des éléments -->
            <div class="max-h-64 overflow-y-auto">
                @foreach ($items as $item)
                    <div 
                        class="p-2 border rounded mb-1 cursor-pointer transition"
                        :class="isSelected({id: {{ $item['id'] }}, type: '{{ $item['type'] }}'}) ? 'bg-blue-200 border-blue-500' : 'hover:bg-gray-100'"
                        @click="toggle({id: {{ $item['id'] }}, type: '{{ $item['type'] }}', titre: '{{ $item['titre'] }}'})"
                    >
                        {{ $item['titre'] }}
                        <span class="text-xs text-gray-500">({{ $item['type'] }})</span>
                    </div>
                @endforeach
            </div>

            <!-- Pied de modal -->
            <div class="flex justify-between mt-3 text-sm">
                <button @click="clear()" class="text-gray-500 hover:underline">Tout effacer</button>
                <button 
                    @click="showModal = false"
                    class="px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                    Valider
                </button>
            </div>
        </div>
    </div>
</div>
