<div>
    @php
        $entityId= $entityId ?? null;
        // $existingImages= !is_null($existingImages)? (is_array($existingImages)? $existingImages : json_decode($existingImages, true)) : [];
        $countExistingImages = !is_array($existingImages)? $existingImages?->count() : 0;
        $name= "upload-images-modal" //$modalName ?? $entityType.'-'.$entityId;
        // $maxFiles= $maxFiles ?? 20;
        // $images= $images ?? [];
    @endphp


    <flux:modal name="{{ $name }}" class="w-2xl" wire:model="isOpen" max-width="4xl" :dismissible="false" :closable="false">

        <div>
            <flux:heading size="lg">
                📸 Gestion des images
            </flux:heading>
            <flux:text class="my-4">
                Ajoutez ou supprimez des images pour l'entité
            </flux:text>
        </div>

        <div>
            <div class="space-y-6">
                <!-- Zone d'upload -->
                <div class="border-2 border-dashed border-zinc-300 dark:border-zinc-600 rounded-xl p-6 text-center transition-colors duration-200 hover:border-blue-400 dark:hover:border-blue-500">
                    <div class="flex flex-col items-center justify-center gap-3">
                        <div class="p-3 rounded-full bg-blue-50 dark:bg-blue-900/20">
                            <flux:icon name="cloud-arrow-up" class="w-8 h-8 text-blue-600 dark:text-blue-400" />
                        </div>

                        <div>
                            <p class="text-sm font-medium text-zinc-900 dark:text-white">
                                Inserer vos images ici
                            </p>
                            <p class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
                                PNG, JPG, GIF, WEBP jusqu'à 10MB
                            </p>
                            <p class="text-xs text-zinc-400 dark:text-zinc-500">
                                Maximum {{ $maxFiles }} images
                            </p>
                        </div>

                        <flux:input type="file"
                            wire:model="images"
                            multiple
                            accept="image/*"
                            class="mt-4"
                        >
                            <flux:button variant="primary" size="sm">
                                <flux:icon name="folder-open" class="w-4 h-4 mr-2" />
                                Parcourir les fichiers
                            </flux:button>
                        </flux:input>
                    </div>

                    <!-- Erreurs de validation -->
                    @error('images.*')
                        <p class="mt-3 text-sm text-red-600 dark:text-red-400">
                            {{ $message }}
                        </p>
                    @enderror
                    @error('images')
                        <p class="mt-3 text-sm text-red-600 dark:text-red-400">
                            {{ $message }}
                        </p>
                    @enderror
                </div>

                <!-- Aperçu des nouvelles images -->
                @if(count($images ?? []) > 0)
                    <flux:spacer />
                    <flux:heading level="3">
                        📋 Images à uploader ({{ count($images?? []) }})
                    </flux:heading>
                    <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
                        @foreach($images as $index => $image)
                        <div class="relative group">
                            <div class="overflow-hidden rounded-lg aspect-square bg-zinc-100 dark:bg-zinc-700">
                                <img
                                    src="{{ $image->temporaryUrl() }}"
                                    alt="Aperçu"
                                    class="object-cover w-full h-full transition-transform duration-200 group-hover:scale-105"
                                />
                            </div>
                            <button
                                type="button"
                                wire:click="removeTemporaryImage({{ $index }})"
                                class="absolute top-1 right-1 p-1 text-white transition-colors duration-200 bg-red-500 rounded-full hover:bg-red-600"
                                title="Supprimer"
                            >
                                <flux:icon name="x-mark" class="w-3 h-3" />
                            </button>
                            <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400 truncate">
                                {{ $image->getClientOriginalName() }}
                            </div>
                        </div>
                        @endforeach
                    </div>
                @endif

                <!-- Images existantes -->
                @if($countExistingImages > 0)
                    <flux:spacer />

                    <flux:heading level="4">
                        🗂️ Images existantes ({{ $countExistingImages }})
                    </flux:heading>
                    <flux:text>Cliquez pour définir comme image principale</flux:text>
                    <flux:spacer />

                    <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 my-3 py-4">
                        @foreach($existingImages as $image)
                        <div class="relative group">
                            <div class="overflow-hidden rounded-lg aspect-square bg-zinc-100 dark:bg-zinc-700">
                                <img
                                    src="{{ $image?->imageUrl() }}"
                                    alt="{{ $image?->nom }}"
                                    class="object-cover w-full h-full transition-all duration-200 cursor-pointer group-hover:scale-105"
                                />
                                <div class="absolute inset-0 transition-opacity duration-200 bg-blue-500 opacity-0 group-hover:opacity-20"></div>
                            </div>

                            <!-- Badge image principale -->
                            @if(isset($image['is_main']) && $image['is_main'])
                            <div class="absolute top-1 left-1">
                                <span class="px-1.5 py-0.5 text-xs font-medium text-white bg-blue-600 rounded-full">
                                    ★
                                </span>
                            </div>
                            @endif

                            <button
                                type="button"
                                wire:click="setAsMainImage('{{ $image?->id }}')"
                                wire:confirm="Souhaitez-vous choisir comme image principale ?"
                                class="absolute top-1 left-1 p-1 text-white transition-colors duration-200 bg-yellow-500 rounded-full opacity-0 group-hover:opacity-100 hover:bg-teal-600"
                                title="Désigner comme image principale"
                            >
                                <flux:icon name="star" class="w-3 h-3" />
                            </button>

                            <button
                                type="button"
                                wire:click="removeExistingImage('{{ $image?->id }}')"
                                wire:confirm="Êtes-vous sûr de vouloir supprimer cette image ?"
                                class="absolute top-1 right-1 p-1 text-white transition-colors duration-200 bg-red-500 rounded-full opacity-0 group-hover:opacity-100 hover:bg-red-600"
                                title="Supprimer l'image"
                            >
                                <flux:icon name="trash" class="w-3 h-3" />
                            </button>

                            <div class="mt-1 space-y-1">
                                <div class="text-xs text-zinc-500 dark:text-zinc-400 truncate">
                                    {{ $image?->nom}}
                                </div>
                                @if(isset($image['size']))
                                <div class="text-xs text-zinc-400 dark:text-zinc-500">
                                    {{ number_format($image['size'] / 1024, 0) }} KB
                                </div>
                                @endif
                            </div>
                        </div>
                        @endforeach
                    </div>

                @else
                <!-- État vide -->
                <div class="py-8 text-center">
                    <p class="mt-3 text-sm text-zinc-500 dark:text-zinc-400">
                        Aucune image n'a été ajouté pour le moment
                    </p>
                </div>
                @endif
            </div>
        </div>

        <flux:spacer />

        <div class="flex justify-end gap-3 mt-4 pt-4">
            <flux:button
                @click="$flux.modal('{{ $name }}').close()"
            >
                Annuler
            </flux:button>

            <flux:button
                variant="primary"
                wire:click="save"
                wire:loading.attr="disabled"
                wire:target='images'
                :disabled="count($images ?? []) === 0"
            >
                <flux:icon
                    name="arrow-path"
                    class="w-4 h-4 mr-2 animate-spin"
                    wire:loading
                    wire:target="save"
                />
                <span wire:loading.remove wire:target="save">
                    Uploader ({{ count($images) }})
                </span>
                <span wire:loading wire:target="save">
                    Upload en cours...
                </span>
            </flux:button>
        </div>
    </flux:modal>

</div>




