<div class="min-h-screen mt-bg">

    {{-- ══════════════════════════════════════════════════════
         HEADER
    ══════════════════════════════════════════════════════ --}}
    <div class="px-6 py-6 sm:px-8" style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.5)">
        <div class="mx-auto max-w-7xl">
            <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <p class="text-xs font-medium mt-text-muted">
                        {{ $greeting }},
                        <span class="mt-text-primary font-semibold">{{ auth()->user()?->name ?? 'Utilisateur' }}</span>
                    </p>
                    <h1 class="text-2xl font-bold mt-text">{{ $title }}</h1>
                    <p class="mt-0.5 text-xs mt-text-muted">{{ $subtitle }}</p>
                </div>

                @if(count($quickActions) > 0)
                <div class="flex flex-wrap items-center gap-2">
                    <div class="hidden lg:block">
                        <x-mt::actions.grid :actions="$quickActions" visible="1" size="sm" />
                    </div>
                    <div class="lg:hidden">
                        <x-mt::actions.floating :actions="$quickActions" visible="4"/>
                    </div>
                    {{-- @foreach($quickActions as $action)
                        @if(isset($action['route']))
                            <a href="{{ $action['route'] }}" wire:navigate
                               class="mt-btn mt-btn-{{ $action['variant'] ?? 'secondary' }} mt-btn-sm">
                                @if(isset($action['icon'])) <i class="{{ $action['icon'] }} mr-1.5"></i> @endif
                                {{ $action['label'] }}
                            </a>
                        @elseif(isset($action['method']))
                            <button wire:click="{{ $action['method'] }}"
                                    class="mt-btn mt-btn-{{ $action['variant'] ?? 'secondary' }} mt-btn-sm">
                                @if(isset($action['icon'])) <i class="{{ $action['icon'] }} mr-1.5"></i> @endif
                                {{ $action['label'] }}
                            </button>
                        @endif
                    @endforeach --}}
                </div>
                @endif
            </div>
        </div>
    </div>

    <div class="px-6 py-8 sm:px-8">
        <div class="mx-auto space-y-8 max-w-7xl">

            {{-- ══════════════════════════════════════════════════════
                 STATS CARDS — grille dynamique selon le nombre
            ══════════════════════════════════════════════════════ --}}
            @if(count($stats) > 0)
            @php
                $colClass = match($statsCols) {
                    2 => 'sm:grid-cols-2',
                    3 => 'sm:grid-cols-2 lg:grid-cols-3',
                    default => 'sm:grid-cols-2 lg:grid-cols-4',
                };

                shuffle($stats);
                $stats= array_slice($stats, 0, 4);
            @endphp
            <div class="grid grid-cols-1 gap-4 {{ $colClass }}">
                @foreach($stats as $stat)
                @php
                    $colorVar = match($stat['color'] ?? 'primary') {
                        'success' => 'var(--mt-success)',
                        'warning' => 'var(--mt-warning)',
                        'danger'  => 'var(--mt-danger)',
                        'info'    => 'var(--mt-info)',
                        'gray'    => 'var(--mt-text)',
                        default   => 'var(--mt-primary)',
                    };
                    $isPositive = ($stat['changeType'] ?? 'neutral') === 'positive';
                    $isNegative = ($stat['changeType'] ?? 'neutral') === 'negative';
                    $hasRoute   = isset($stat['route']);
                @endphp

                @if($hasRoute) <a href="{{ $stat['route'] }}" wire:navigate class="block group">
                @else <div class="group">
                @endif
                    <div class="relative h-full overflow-hidden p-5 rounded-2xl mt-card transition-all duration-200 hover:shadow-md"
                         style="border-left: 3px solid rgb({{ $colorVar }});">

                        <div class="flex items-start justify-between">
                            <div class="flex-1 min-w-0 pr-3">
                                <p class="text-xs font-medium uppercase mt-text-muted truncate">
                                    {{ $stat['label'] }}
                                </p>
                                <p class="mt-1.5 text-2xl lg:text-3xl font-bold mt-text leading-none truncate">
                                    {{ $stat['value'] }}
                                </p>
                            </div>
                            <div class="flex-shrink-0 p-3 rounded-xl transition-all duration-200 group-hover:scale-110"
                                 style="background: rgba({{ $colorVar }}, 0.1)">
                                <i class="{{ $stat['icon'] }} text-lg" style="color: rgb({{ $colorVar }})"></i>
                            </div>
                        </div>

                        @if(!empty($stat['details']) || isset($stat['change']))
                        <div class="flex items-center justify-between mt-3 flex-nowrap gap-1.5">
                            @if(!empty($stat['details']))
                            <div class="flex flex-wrap gap-1">
                                @php
                                    shuffle($stat['details']);
                                @endphp
                                @foreach(array_slice($stat['details'], 2) as $detail)
                                @if($detail['value'] !== '')
                                <span class="px-2 py-0.5 text-xs rounded-full mt-badge mt-badge-gray">
                                    {{ $detail['value'] }} {{ $detail['label'] }}
                                </span>
                                @else
                                <span class="px-2 py-0.5 text-xs rounded-full mt-badge mt-badge-gray">
                                    {{ $detail['label'] }}
                                </span>
                                @endif
                                @endforeach
                            </div>
                            @endif

                            @if(isset($stat['change']))
                            <span class="inline-flex items-center gap-1 text-xs font-semibold"
                                  style="color: {{ $isPositive ? 'rgb(var(--mt-success))' : ($isNegative ? 'rgb(var(--mt-danger))' : 'rgba(var(--mt-text),0.5)') }}">
                                <i class="fa-solid fa-arrow-{{ $isPositive ? 'up' : ($isNegative ? 'down' : 'right') }} text-[10px]"></i>
                                {{ $stat['change'] }}
                            </span>
                            @endif
                        </div>
                        @endif

                        {{-- Hover glow --}}
                        <div class="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none rounded-2xl"
                             style="background: radial-gradient(circle at top right, rgba({{ $colorVar }}, 0.06), transparent 70%)">
                        </div>
                    </div>
                @if($hasRoute) </a>
                @else </div>
                @endif
                @endforeach
            </div>
            @endif

            {{-- ══════════════════════════════════════════════════════
                 WIDGETS — grille 3 colonnes
            ══════════════════════════════════════════════════════ --}}
            @if(count($widgets) > 0)
            <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
                @foreach($widgets as $widget)
                @php
                    $span = $widget['span'] ?? 1;
                    $spanClass = match($span) {
                        3 => 'lg:col-span-3',
                        2 => 'lg:col-span-2',
                        default => 'lg:col-span-1',
                    };
                @endphp

                <div class="{{ $spanClass }}">
                    <div class="h-full rounded-2xl mt-card overflow-hidden flex flex-col">

                        {{-- Widget Header --}}
                        <div class="flex items-center justify-between px-0 py-1 flex-shrink-0"
                             style="">
                            <div class="min-w-0">
                                <h3 class="text-sm font-semibold mt-text truncate">{{ $widget['title'] }}</h3>
                                @if(isset($widget['subtitle']))
                                    <p class="text-xs mt-text-muted mt-0.5">{{ $widget['subtitle'] }}</p>
                                @endif
                            </div>
                            @if(!empty($widget['actions']))
                            <div class="flex items-center gap-3 ml-3 flex-shrink-0">

                                <x-mt::actions.grid :actions="$widget['actions']" visible="0" size="sm" />
                                {{-- @foreach($widget['actions'] as $wAction)
                                    @if(isset($wAction['route']))
                                        <a href="{{ $wAction['route'] }}" wire:navigate
                                           class="text-xs font-medium mt-text-primary hover:opacity-75 transition-opacity whitespace-nowrap">
                                            {{ $wAction['label'] }}
                                        </a>
                                    @elseif(isset($wAction['method']))
                                        <button wire:click="{{ $wAction['method'] }}"
                                                class="text-xs font-medium mt-text-primary hover:opacity-75 transition-opacity whitespace-nowrap">
                                            {{ $wAction['label'] }}
                                        </button>
                                    @endif
                                @endforeach --}}
                            </div>
                            @endif
                        </div>

                        {{-- Widget Body --}}
                        <div class="flex-1 px-0 py-3 overflow-hidden">

                            {{-- ── TYPE : LIST ──────────────────────────── --}}
                            @if($widget['type'] === 'list')
                                @if(empty($widget['data']))
                                    <div class="flex flex-col items-center justify-center py-8 mt-text-muted h-full">
                                        <i class="fa-solid fa-inbox text-3xl mb-3" style="opacity:0.25"></i>
                                        <p class="text-xs">Aucun élément</p>
                                    </div>
                                @else
                                <div class="space-y-0 -mx-5 overflow-y-auto max-h-full">
                                    @foreach($widget['data'] as $item)
                                    @php $itemUrl = $item['route']; @endphp
                                    @if($itemUrl)
                                    <a href="{{ $itemUrl }}" wire:navigate
                                       class="flex items-center gap-3 px-5 py-3 transition-colors"
                                       onmouseover="this.style.background='rgba(var(--mt-text),0.03)'"
                                       onmouseout="this.style.background=''">
                                    @else
                                    <div class="flex items-center gap-3 px-5 py-3">
                                    @endif

                                        {{-- Avatar / icône / initiales --}}
                                        @if(isset($item['image']))
                                            <img src="{{ $item['image'] }}" alt="{{ $item['title'] }}"
                                                 class="w-9 h-9 rounded-lg object-cover flex-shrink-0">
                                        @elseif(isset($item['icon']))
                                            <div class="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-bg-secondary-light">
                                                <i class="{{ $item['icon'] }} text-sm mt-text-primary"></i>
                                            </div>
                                        @elseif(isset($item['initials']))
                                            <div class="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold text-white"
                                                 style="background: rgb(var(--mt-primary))">
                                                {{ $item['initials'] }}
                                            </div>
                                        @endif

                                        {{-- Contenu --}}
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm font-medium mt-text truncate">{{ $item['title'] }}</p>
                                            @if(isset($item['meta']))
                                                <p class="text-xs mt-text-muted truncate">{{ $item['meta'] }}</p>
                                            @endif
                                        </div>

                                        {{-- Badge / valeur --}}
                                        @if(isset($item['badge']))
                                            <x-mt::badge
                                                :label="$item['badge']['label']"
                                                :variant="$item['badge']['variant'] ?? 'gray'"
                                            />
                                        @elseif(isset($item['value']))
                                            <span class="text-sm font-semibold mt-text flex-shrink-0 ml-2">
                                                {{ $item['value'] }}
                                            </span>
                                        @endif

                                    @if($itemUrl) </a> @else </div> @endif
                                    @endforeach
                                </div>
                                @endif

                            {{-- ── TYPE : CHART ─────────────────────────── --}}
                            @elseif($widget['type'] === 'chart')
                                <div style="height: {{ $widget['height'] ?? '250px' }}">
                                    <canvas id="chart-{{ $loop->index }}"></canvas>
                                </div>
                                @push('scripts')
                                <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    if (typeof Chart === 'undefined') {
                                        // Charger Chart.js si absent
                                        const s = document.createElement('script');
                                        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js';
                                        s.onload = () => initChart{{ $loop->index }}();
                                        document.head.appendChild(s);
                                    } else {
                                        initChart{{ $loop->index }}();
                                    }

                                    function initChart{{ $loop->index }}() {
                                        const ctx = document.getElementById('chart-{{ $loop->index }}');
                                        if (!ctx) return;

                                        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
                                        const style  = getComputedStyle(document.documentElement);
                                        const primary    = style.getPropertyValue('--mt-primary').trim();
                                        const textColor  = style.getPropertyValue('--mt-text').trim();
                                        const borderC    = style.getPropertyValue('--mt-ui-card-border').trim();

                                        const chartType = '{{ $widget['chart_type'] ?? 'bar' }}';
                                        const showLegend = {{ isset($widget['legend']) && $widget['legend'] ? 'true' : 'false' }};

                                        const data = @json($widget['data']);

                                        const tooltipBg = isDark ? 'rgba(30,30,30,0.97)' : 'rgba(255,255,255,0.97)';

                                        new Chart(ctx, {
                                            type: chartType,
                                            data: data,
                                            options: {
                                                responsive: true,
                                                maintainAspectRatio: false,
                                                plugins: {
                                                    legend: {
                                                        display: showLegend,
                                                        labels: {
                                                            color: `rgba(${textColor}, 0.7)`,
                                                            boxWidth: 12,
                                                            padding: 16,
                                                            font: { size: 11 },
                                                        }
                                                    },
                                                    tooltip: {
                                                        backgroundColor: tooltipBg,
                                                        titleColor: `rgb(${textColor})`,
                                                        bodyColor: `rgba(${textColor}, 0.7)`,
                                                        borderColor: `rgb(${borderC})`,
                                                        borderWidth: 1,
                                                        padding: 12,
                                                        boxPadding: 6,
                                                        usePointStyle: true,
                                                        callbacks: {
                                                            label: function(ctx) {
                                                                return ' ' + ctx.dataset.label + ' : ' + ctx.parsed.y;
                                                            }
                                                        }
                                                    }
                                                },
                                                scales: chartType === 'doughnut' || chartType === 'pie' ? {} : {
                                                    y: {
                                                        beginAtZero: true,
                                                        grid: {
                                                            color: `rgba(${borderC}, 0.4)`,
                                                            drawBorder: false,
                                                        },
                                                        ticks: {
                                                            color: `rgba(${textColor}, 0.55)`,
                                                            font: { size: 11 },
                                                            padding: 8,
                                                        }
                                                    },
                                                    x: {
                                                        grid: { display: false },
                                                        ticks: {
                                                            color: `rgba(${textColor}, 0.55)`,
                                                            font: { size: 11 },
                                                            maxRotation: 0,
                                                        }
                                                    }
                                                },
                                                animation: {
                                                    duration: 600,
                                                    easing: 'easeInOutQuart',
                                                }
                                            }
                                        });

                                        // Sync avec le toggle dark mode
                                        const observer = new MutationObserver(() => {
                                            // Simple reload du canvas au changement de thème
                                            ctx.style.opacity = '0';
                                            setTimeout(() => { ctx.style.opacity = '1'; }, 150);
                                        });
                                        observer.observe(document.documentElement, {
                                            attributes: true, attributeFilter: ['data-theme']
                                        });
                                    }
                                });
                                </script>
                                @endpush

                            {{-- ── TYPE : ACTIVITY ──────────────────────── --}}
                            @elseif($widget['type'] === 'activity')
                                @if(empty($widget['data']))
                                    <div class="flex flex-col items-center justify-center py-8 mt-text-muted h-full">
                                        <i class="fa-solid fa-clock-rotate-left text-3xl mb-3" style="opacity:0.25"></i>
                                        <p class="text-xs">Aucune activité récente</p>
                                    </div>
                                @else
                                <div class="space-y-4 overflow-y-auto max-h-full">
                                    @foreach($widget['data'] as $activity)
                                    <div class="flex items-start gap-3">
                                        <div class="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center mt-1"
                                             style="background: rgba(var(--mt-primary), 0.1)">
                                            <i class="{{ $activity['icon'] ?? 'fa-solid fa-circle-dot' }} text-[10px]"
                                               style="color: rgb(var(--mt-primary))"></i>
                                        </div>
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm mt-text leading-snug">
                                                {!! $activity['text'] !!}
                                            </p>
                                            <p class="text-xs mt-text-muted mt-0.5">{{ $activity['time'] }}</p>
                                        </div>
                                        @if(isset($activity['badge']))
                                            <x-mt::badge
                                                :label="$activity['badge']['label']"
                                                :variant="$activity['badge']['variant'] ?? 'gray'"
                                            />
                                        @endif
                                    </div>
                                    @endforeach
                                </div>
                                @endif

                            {{-- ── TYPE : STAT GROUP ────────────────────── --}}
                            @elseif($widget['type'] === 'stat_group')
                                <div class="space-y-2">
                                    @foreach($widget['data'] as $item)
                                    <div class="flex items-center justify-between py-2.5"
                                         style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.5)">
                                        <div class="flex items-center gap-2">
                                            @if(isset($item['icon']))
                                                <i class="{{ $item['icon'] }} text-xs mt-text-muted w-4 text-center"></i>
                                            @endif
                                            <span class="text-sm mt-text-muted">{{ $item['label'] }}</span>
                                        </div>
                                        <div class="flex items-center gap-2">
                                            <span class="text-sm font-semibold mt-text">{{ $item['value'] }}</span>
                                            @if(isset($item['badge']))
                                                <x-mt::badge
                                                    :label="$item['badge']['label']"
                                                    :variant="$item['badge']['variant'] ?? 'gray'"
                                                />
                                            @endif
                                        </div>
                                    </div>
                                    @endforeach
                                </div>

                            {{-- ── TYPE : PROGRESS ──────────────────────── --}}
                            @elseif($widget['type'] === 'progress')
                                <div class="space-y-4 overflow-y-auto max-h-full">
                                    @foreach($widget['data'] as $item)
                                    @php
                                        $pct = min(100, max(0, $item['percent'] ?? 0));
                                        $pColorVar = match($item['color'] ?? 'primary') {
                                            'success' => 'var(--mt-success)',
                                            'warning' => 'var(--mt-warning)',
                                            'danger'  => 'var(--mt-danger)',
                                            'info'    => 'var(--mt-info)',
                                            'gray'    => 'var(--mt-text)',
                                            default   => 'var(--mt-primary)',
                                        };
                                    @endphp
                                    <div>
                                        <div class="flex items-center justify-between mb-1.5">
                                            <div class="flex items-center gap-2 min-w-0">
                                                @if(isset($item['icon']))
                                                    <i class="{{ $item['icon'] }} text-xs flex-shrink-0"
                                                       style="color: rgb({{ $pColorVar }})"></i>
                                                @endif
                                                <span class="text-sm mt-text truncate">{{ $item['label'] }}</span>
                                            </div>
                                            <div class="flex items-center gap-2 flex-shrink-0 ml-2">
                                                @if(isset($item['value']))
                                                    <span class="text-xs font-medium mt-text-muted">{{ $item['value'] }}</span>
                                                @endif
                                                <span class="text-xs font-bold" style="color: rgb({{ $pColorVar }})">
                                                    {{ $pct }}%
                                                </span>
                                            </div>
                                        </div>
                                        <div class="w-full h-1.5 rounded-full mt-bg-secondary">
                                            <div class="h-1.5 rounded-full transition-all duration-700"
                                                 style="width: {{ $pct }}%; background: rgb({{ $pColorVar }})">
                                            </div>
                                        </div>
                                        @if(isset($item['meta']))
                                            <p class="text-xs mt-text-muted mt-1">{{ $item['meta'] }}</p>
                                        @endif
                                    </div>
                                    @endforeach
                                </div>

                            {{-- ── TYPE : CUSTOM ────────────────────────── --}}
                            @elseif($widget['type'] === 'custom')
                                @if(isset($widget['view']))
                                    @include($widget['view'], $widget['view_data'] ?? [])
                                @endif
                            @endif

                        </div>

                        {{-- Widget Footer optionnel --}}
                        @if(isset($widget['footer']))
                        <div class="px-5 py-3 text-xs mt-text-muted flex-shrink-0"
                             style="border-top: 1px solid rgb(var(--mt-ui-card-border)); background: rgba(var(--mt-text), 0.02)">
                            {{ $widget['footer'] }}
                        </div>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
            @endif

            {{-- État vide --}}
            @if(count($stats) === 0 && count($widgets) === 0)
            <div class="py-24 text-center">
                <div class="inline-flex items-center justify-center w-20 h-20 rounded-full mb-6 mt-bg-secondary">
                    <i class="fa-solid fa-gauge text-3xl mt-text-muted"></i>
                </div>
                <h3 class="text-lg font-semibold mt-text mb-2">Dashboard non configuré</h3>
                <p class="text-sm mt-text-muted max-w-sm mx-auto">
                    Étendez <code class="mt-badge mt-badge-gray px-1.5 py-0.5 rounded text-xs">Mt\MtViews\Livewire\Dashboard</code>
                    et surchargez <code class="mt-badge mt-badge-gray px-1.5 py-0.5 rounded text-xs">getStats()</code>
                    et <code class="mt-badge mt-badge-gray px-1.5 py-0.5 rounded text-xs">getWidgets()</code>.
                </p>
            </div>
            @endif

        </div>
    </div>
</div>
