<div
    x-data="{
        isDragging: false,
        handleDrop(e) {
            this.isDragging = false;
            if (e.dataTransfer.files.length) {
                @this.uploadMultiple('uploads', e.dataTransfer.files);
            }
        }
    }"
    class="h-full overflow-hidden rounded-2xl"
>

    {{-- ===== TABS ===== --}}
    <div class="flex rounded-full" style="background: rgba(var(--mt-text), 0.02)">
        @foreach ([
            'gallery' => ['label' => 'Galerie',    'icon' => 'mt-icon-images',       'badge' => $stats['total']],
            'upload'  => ['label' => 'Upload',     'icon' => 'mt-icon-upload'],
            'results' => ['label' => 'Résultats',  'icon' => 'mt-icon-chart-simple', 'badge' => $stats['results_count'] ?? 0, 'disabled' => $stats['results_count'] === 0],
        ] as $tab => $tabInfo)
            <button
                wire:click="$set('activeTab', '{{ $tab }}')"
                class="flex items-center gap-1 lg:gap-1.5 p-1.5 lg:px-4 lg:py-2.5 rounded-full text-xs lg:text-sm lg:font-medium transition-colors -mb-px"
                style="{{ $activeTab === $tab
                    ? 'color: rgb(var(--mt-primary)); background: rgb(var(--mt-bg))'
                    : 'color: rgba(var(--mt-text), 0.5);' }}"
                @if(!empty($tabInfo['disabled']) && $tabInfo['disabled']) disabled @endif
            >
                <i class="{{ $tabInfo['icon'] }} text-xs"></i>
                {{ $tabInfo['label'] }}
                @if (!empty($tabInfo['badge']) && $tabInfo['badge'] > 0)
                    <span class="ml-0.5 px-1.5 py-0.5 text-xs rounded-full"
                          style="{{ $activeTab === $tab
                            ? 'background: rgba(var(--mt-primary), 0.12); color: rgb(var(--mt-primary))'
                            : 'background: rgba(var(--mt-text), 0.08); color: rgba(var(--mt-text), 0.6)' }}">
                        {{ add_zero($tabInfo['badge']) }}
                    </span>
                @endif
            </button>
        @endforeach
    </div>

    <div class="h-full px-2 py-5 overflow-y-auto lg:pb-12 lg:p-5">

        {{-- ============================= --}}
        {{-- TAB : GALERIE                 --}}
        {{-- ============================= --}}
        @if ($activeTab === 'gallery')
            @if (count($existingImages) === 0)
                <div class="flex flex-col items-center justify-center py-12 mt-text-muted">
                    <i class="mb-3 text-4xl mt-icon-image"></i>
                    <p class="mb-3 text-sm">Aucune image pour l'instant...</p>
                    <button wire:click="$set('activeTab', 'upload')" class="mt-btn mt-btn-sm mt-btn-outline mt-rounded-full">
                        <i class="mr-1 mt-icon-plus"></i>
                        Ajouter des images
                    </button>
                </div>
            @else
                <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
                    @foreach ($existingImages as $img)
                        <div class="relative overflow-hidden group aspect-square rounded-xl"
                             style="{{ $img['is_featured']
                                ? 'border: 2px solid rgb(var(--mt-warning))'
                                : 'border: 2px solid transparent' }}
                             background: rgba(var(--mt-text), 0.05)">

                            {{-- <img
                                src="{{ $img['url'] }}"
                                alt="{{ $img['titre'] }}"
                                class="object-cover w-full h-full transition-transform duration-200 group-hover:scale-105"
                                loading="lazy"
                            /> --}}
                            <x-mt::image-loader
                                src="{{ $img['url'] }}"
                                alt="{{ $img['titre'] }}"
                                class="aspect-square"
                            />

                            {{-- Badge is_featured --}}
                            @if ($img['is_featured'])
                                <div class="absolute top-1.5 left-1.5 hidden lg:block" style="color: rgb(var(--mt-warning))">
                                    <x-mt::icon name="star"/>
                                </div>
                            @endif

                            {{-- Badge WebP --}}
                            @if ($img['webp_url'])
                                <div class="absolute top-1.5 right-1.5 text-white text-xs px-1.5 py-0.5 rounded-full font-medium  hidden"
                                     style="background: rgba(var(--mt-info), 0.9)">
                                    WebP
                                </div>
                            @endif

                            {{-- Badge savings --}}
                            @if ($img['savings'])
                                <div class="absolute bottom-1.5 left-1.5 text-white text-xs px-1.5 py-0.5 rounded-full"
                                     style="background: rgba(var(--mt-success), 0.9)">
                                    -{{ round($img['savings']) }}%
                                </div>
                            @endif

                            {{-- Actions hover --}}
                            <div class="absolute inset-0 flex items-center justify-center gap-2 transition-all duration-200 opacity-0 bg-black/0 group-hover:bg-black/40 group-hover:opacity-100">
                                @if (!$img['is_featured'])
                                    <button
                                        wire:click="setFeatured('{{ $img['path'] }}')"
                                        title="Définir comme principale"
                                        class="flex items-center justify-center w-8 h-8 transition-opacity rounded-full shadow hover:opacity-80"
                                        style="background: rgb(var(--mt-warning))"
                                    >
                                        <x-mt::icon name="star" class="text-white" />
                                    </button>
                                @endif
                                @if ($allowDelete)
                                    <button
                                        wire:click="deleteImage('{{ $img['path'] }}')"
                                        wire:confirm="Supprimer cette image et toutes ses variantes ?"
                                        title="Supprimer"
                                        class="flex items-center justify-center w-8 h-8 transition-opacity rounded-full shadow hover:opacity-80"
                                        style="background: rgb(var(--mt-danger))"
                                    >
                                        <x-mt::icon name="trash" class="text-white" />
                                    </button>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        @endif

        {{-- ============================= --}}
        {{-- TAB : UPLOAD                  --}}
        {{-- ============================= --}}
        @if ($activeTab === 'upload')
            <div class="space-y-4">

                <div>
                    <x-mt::form.file-upload
                        id="mt-img-input-{{ $this->getId() }}"
                        wire:model="uploads"
                        item-type="image"
                        :multiple="$multiple"
                    />
                </div>

                {{-- Erreurs validation --}}
                @error('uploads.*')
                    <div class="flex items-center gap-2 p-3 text-sm rounded-lg mt-alert mt-alert-danger">
                        <i class="flex-shrink-0 fa-solid fa-circle-exclamation"></i>
                        {{ $message }}
                    </div>
                @enderror

                {{-- Aperçu fichiers sélectionnés --}}
                @if (count($uploads) > 0)
                    <div class="flex items-center gap-3 p-3 text-sm rounded-lg"
                         style="background: rgba(var(--mt-info), 0.08); border: 1px solid rgba(var(--mt-info), 0.2)">
                        <i class="mt-icon-images mt-text-info"></i>
                        <span class="font-medium mt-text-info">
                            {{ add_zero(count($uploads)) }} fichier{{ count($uploads) > 1 ? 's' : '' }} prêt{{ count($uploads) > 1 ? 's' : '' }}
                        </span>
                        <button wire:click="$set('uploads', [])" class="ml-auto transition-opacity mt-text-info hover:opacity-75">
                            <i class="mt-icon-x"></i>
                        </button>
                    </div>
                @endif

                {{-- Barre de progression --}}
                @if ($loading && $progress > 0)
                    <div class="space-y-1.5">
                        <div class="flex justify-between text-xs mt-text-muted">
                            <span>Optimisation en cours…</span>
                            <span class="font-medium">{{ $progress }}%</span>
                        </div>
                        <div class="w-full h-2 overflow-hidden rounded-full mt-bg-secondary">
                            <div class="h-2 transition-all duration-300 rounded-full"
                                 style="width: {{ $progress }}%; background: rgb(var(--mt-primary))">
                            </div>
                        </div>
                    </div>
                @endif


                {{-- Bouton optimiser --}}
                <x-mt::button
                    wire:click="optimizeAll"
                    loading="optimizeAll"
                    variant="success"
                    icon="fa-solid fa-bolt"
                    disabled="{{ count($uploads) === 0 }}"
                >
                    <span wire:loading.remove wire:target="optimizeAll">
                        Optimiser {{ count($uploads) > 0 ? add_zero(count($uploads)) . ' image' . (count($uploads) > 1 ? 's' : '') : '' }}
                    </span>
                    <span wire:loading wire:target="optimizeAll" class="flex items-center gap-2">
                        Traitement…
                    </span>
                </x-mt::button>
                    
                
            </div>
        @endif

        {{-- ============================= --}}
        {{-- TAB : RÉSULTATS               --}}
        {{-- ============================= --}}
        @if ($activeTab === 'results')
            @if (count($results) === 0)
                <div class="flex flex-col items-center justify-center py-12 mt-text-muted">
                    <i class="mb-3 text-4xl mt-icon-chart-simple"></i>
                    <p class="text-sm">Les résultats d'optimisation apparaîtront ici</p>
                </div>
            @else
                <div class="space-y-2">
                    @foreach ($results as $result)
                        <div class="flex items-center gap-3 p-3 rounded-xl"
                             style="{{ $result['success']
                                ? 'background: rgba(var(--mt-success), 0.06); border: 1px solid rgba(var(--mt-success), 0.15)'
                                : 'background: rgba(var(--mt-danger), 0.06); border: 1px solid rgba(var(--mt-danger), 0.15)' }}">

                            <div class="flex items-center justify-center flex-shrink-0 w-8 h-8 rounded-full"
                                 style="{{ $result['success']
                                    ? 'background: rgba(var(--mt-success), 0.12)'
                                    : 'background: rgba(var(--mt-danger), 0.12)' }}">
                                <i class="{{ $result['success'] ? 'fa-solid fa-check' : 'fa-solid fa-xmark' }} text-xs"
                                   style="color: {{ $result['success'] ? 'rgb(var(--mt-success))' : 'rgb(var(--mt-danger))' }}"></i>
                            </div>

                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium truncate mt-text">
                                    {{ $result['filename'] ?? basename($result['original_path'] ?? '') }}
                                </p>
                                @if ($result['success'])
                                    <p class="text-xs mt-text-muted">
                                        {{ number_format(($result['original_size'] ?? 0) / 1024, 1) }} KB
                                        → {{ number_format(($result['optimized_size'] ?? 0) / 1024, 1) }} KB
                                        @if (!empty($result['variants']))
                                            · {{ add_zero(count($result['variants'])) }} variante{{ count($result['variants']) > 1 ? 's' : '' }}
                                        @endif
                                    </p>
                                @else
                                    <p class="text-xs truncate mt-text-danger">{{ $result['error'] ?? 'Erreur inconnue' }}</p>
                                @endif
                            </div>

                            @if ($result['success'] && isset($result['savings_percent']))
                                <div class="flex-shrink-0 text-right">
                                    <span class="text-sm font-bold mt-text-success">
                                        -{{ $result['savings_percent'] }}%
                                    </span>
                                </div>
                            @endif
                        </div>
                    @endforeach

                    {{-- Résumé global --}}
                    @php
                        $successCount = add_zero(collect($results)->where('success', true)->count());
                        $avgSavings   = collect($results)->where('success', true)->avg('savings_percent');
                    @endphp
                    @if ($successCount > 0)
                        <div class="flex items-center justify-between p-4 mt-4 rounded-xl"
                             style="background: rgba(var(--mt-info), 0.08); border: 1px solid rgba(var(--mt-info), 0.15)">
                            <span class="text-sm mt-text-info">
                                <strong>{{ $successCount }}</strong> image{{ $successCount > 1 ? 's' : '' }} optimisée{{ $successCount > 1 ? 's' : '' }}
                            </span>
                            <span class="text-sm font-bold mt-text-success">
                                Économie moyenne : -{{ round($avgSavings, 1) }}%
                            </span>
                        </div>
                    @endif
                </div>
            @endif
        @endif

    </div>
</div>
