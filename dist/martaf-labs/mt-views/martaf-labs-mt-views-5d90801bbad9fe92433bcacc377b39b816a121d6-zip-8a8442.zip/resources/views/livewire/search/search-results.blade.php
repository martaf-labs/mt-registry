{{--
    Vue partielle du composant SearchResults
    ─────────────────────────────────────────
    Rendue par SearchResults::render()
    Intégrée dans mt::search.results via <livewire:mt.search-results />
--}}
<div>

    {{-- Filtres catégories --}}
    <div class="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none mt-4"
        x-show="categories.length > 1">

        @if(count($categories) > 1)
            <button
                wire:click="setCategory(null)"
                class="results-filter-btn {{ $activeCategory === null ? 'active' : '' }}">
                <i class="fa-solid fa-layer-group text-[10px] mr-1.5"></i> Tout
            </button>

            @foreach($categories as $cat)
                <button
                    wire:click="setCategory('{{ addslashes($cat['key']) }}')"
                    class="results-filter-btn {{ $activeCategory === $cat['key'] ? 'active' : '' }}">
                    <i class="{{ $cat['icon'] }} text-[10px] mr-1.5"></i>
                    {{ $cat['label'] }}
                </button>
            @endforeach
        @endif

    </div>

    {{-- Stats --}}
    <p class="text-sm text-gray-500 dark:text-gray-400 mt-3"
    x-show="'{{ strlen(trim($query)) }}' >= '{{ config('mt-search.min_chars', 2) }}'">

        @if($searching)
            <span class="flex items-center gap-2">
                <svg class="animate-spin w-3.5 h-3.5 text-blue-500" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                </svg>
                Recherche en cours…
            </span>
        @else
            <span>
                <span class="font-semibold text-gray-900 dark:text-white">{{ $totalResults }}</span>
                résultat{{ $totalResults !== 1 ? 's' : '' }}
                pour <span class="font-semibold text-gray-900 dark:text-white">«{{ strip_tags($query) }}»</span>
            </span>
        @endif

    </p>

    {{-- Corps résultats --}}
    <div class="mt-6 space-y-2">

        {{-- Skeleton --}}
        @if($searching && count($loadedResults) === 0)
            @for($i = 0; $i < 8; $i++)
                <div class="flex items-center gap-4 p-4 bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 animate-pulse">
                    <div class="w-11 h-11 rounded-xl bg-gray-200 dark:bg-gray-700 flex-shrink-0"></div>
                    <div class="flex-1 space-y-2">
                        <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                        <div class="h-3 bg-gray-100 dark:bg-gray-800 rounded w-1/2"></div>
                    </div>
                    <div class="flex-shrink-0 space-y-1.5">
                        <div class="h-3 w-16 bg-gray-100 dark:bg-gray-800 rounded ml-auto"></div>
                        <div class="h-5 w-20 bg-gray-200 dark:bg-gray-700 rounded-full ml-auto"></div>
                    </div>
                </div>
            @endfor
        @endif

        {{-- Aucun résultat --}}
        @if(!$searching && count($loadedResults) === 0 && strlen(trim($query)) >= config('mt-search.min_chars', 2))
            <div class="text-center py-20">
                <div class="w-20 h-20 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center mx-auto mb-5 shadow-sm">
                    <i class="fa-solid fa-face-sad-tear text-3xl text-gray-300 dark:text-gray-600"></i>
                </div>
                <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">Aucun résultat</h2>
                <p class="text-gray-500 dark:text-gray-400 text-sm max-w-sm mx-auto">
                    Aucun résultat pour <span class="font-semibold text-gray-700 dark:text-gray-300">«{{ strip_tags($query) }}»</span>.
                    <br>Essayez d'autres termes ou vérifiez l'orthographe.
                </p>
                @if($activeCategory)
                    <button wire:click="setCategory(null)"
                            class="mt-5 px-4 py-2 text-sm text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors font-medium">
                        <i class="fa-solid fa-xmark mr-1.5"></i>Retirer le filtre catégorie
                    </button>
                @endif
            </div>
        @endif

        {{-- Liste des résultats --}}
        @foreach($loadedResults as $idx => $item)
            <a
                href="{{ $item['url'] }}"
                x-data
                @click="$dispatch('search-result-clicked', {{ json_encode(['title' => strip_tags($item['title']), 'url' => $item['url'], 'category' => $item['category'] ?? null]) }})"
                class="results-item group"
                wire:key="result-{{ $idx }}-{{ $item['id'] ?? $idx }}"
                wire:navigate
            >
                {{-- Avatar --}}
                <div class="flex-shrink-0">
                    @if(!empty($item['avatar']))
                        
                    <x-mt::image-loader :src="$item['avatar']" :alt="$item['title']" class="w-11 h-11 rounded-xl" />

                    @else
                        <div class="w-11 h-11 rounded-xl flex items-center justify-center text-sm font-bold text-white flex-shrink-0 bg-cat-{{ $item['color'] ?? 'gray' }}">
                            {{ strtoupper(substr(strip_tags($item['avatar_text'] ?? $item['title']), 0, 2)) }}
                        </div>
                    @endif
                </div>

                {{-- Contenu --}}
                <div class="flex-1 min-w-0">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <p class="text-sm font-semibold text-gray-900 dark:text-white truncate leading-snug">
                                {!! $item['title'] !!}
                            </p>
                            @if(!empty($item['subtitle']))
                                <p class="text-sm text-gray-500 dark:text-gray-400 truncate mt-0.5">
                                    {!! $item['subtitle'] !!}
                                </p>
                            @endif
                        </div>
                        <div class="flex-shrink-0 text-right">
                            @if(!empty($item['meta']))
                                <p class="text-xs text-gray-400 dark:text-gray-500 whitespace-nowrap mb-1.5">
                                    {{ $item['meta'] }}
                                </p>
                            @endif
                            @if(!empty($item['category']))
                                <span class="results-cat-badge badge-{{ $item['color'] ?? 'gray' }} inline-flex items-center gap-1">
                                    <i class="{{ $item['icon'] ?? 'fa-solid fa-circle' }} text-[9px]"></i>
                                    <span class="text-[10px] font-semibold capitalize">{{ $item['category'] }}</span>
                                </span>
                            @endif
                        </div>
                    </div>
                </div>

                {{-- Flèche hover --}}
                <div class="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div class="w-7 h-7 rounded-lg bg-gray-100 dark:bg-gray-700 group-hover:bg-blue-50 dark:group-hover:bg-blue-900/30 flex items-center justify-center transition-colors">
                        <i class="fa-solid fa-arrow-right text-xs text-gray-400 group-hover:text-blue-500 transition-colors"></i>
                    </div>
                </div>
            </a>
        @endforeach

        {{-- Load More --}}
        @if($searching && count($loadedResults) > 0)
            <div class="flex flex-col items-center justify-center gap-2 py-4 text-sm text-gray-500 dark:text-gray-400">
                <svg class="animate-spin w-4 h-4 text-blue-500" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                </svg>
                Chargement…
            </div>
        @endif

        @if(!$searching && $hasMore)
            <div class="pt-6 text-center">
                <button
                    wire:click="loadMore"
                    wire:loading.attr="disabled"
                    wire:target="loadMore"
                    class="inline-flex items-center gap-2.5 px-6 py-3 text-sm font-medium
                        text-blue-600 dark:text-blue-400
                        bg-white dark:bg-gray-800
                        border border-gray-200 dark:border-gray-700
                        rounded-2xl shadow-sm
                        hover:bg-blue-50 dark:hover:bg-blue-900/20
                        hover:border-blue-300 dark:hover:border-blue-700
                        disabled:opacity-60 disabled:cursor-wait
                        transition-all"
                >
                    <span wire:loading.remove wire:target="loadMore">
                        <i class="fa-solid fa-chevron-down text-xs mr-1"></i>
                        Charger plus
                        <span class="text-xs text-gray-400 dark:text-gray-500 ml-1">
                            ({{ $totalResults - count($loadedResults) }} restants)
                        </span>
                    </span>
                    <span wire:loading wire:target="loadMore" class="flex items-center gap-2">
                        <svg class="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                        </svg>
                        Chargement…
                    </span>
                </button>
            </div>
        @endif

        {{-- Fin des résultats --}}
        @if(!$searching && !$hasMore && count($loadedResults) > 0)
            <div class="pt-6 pb-4 text-center">
                <div class="inline-flex items-center gap-3 text-xs text-gray-400 dark:text-gray-600">
                    <div class="w-16 h-px bg-gray-200 dark:bg-gray-700"></div>
                    <span>
                        Fin — <span class="font-medium">{{ $totalResults }}</span>
                        résultat{{ $totalResults !== 1 ? 's' : '' }} au total
                    </span>
                    <div class="w-16 h-px bg-gray-200 dark:bg-gray-700"></div>
                </div>
            </div>
        @endif

    </div>
</div>