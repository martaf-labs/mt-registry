{{--
    Page de résultats complète — mt::search.results
    ─────────────────────────────────────────────────
    Route : GET /search?q=terme&category=App\Models\User

    Dans routes/search.php (ou routes/web.php) :
        Route::get('/search', function () {
            return view('mt::search.results', [
                'query'    => request('q', ''),
                'category' => request('category'),
            ]);
        })->name('search.index')->middleware(['web', 'auth']);
--}}

<x-mt::layouts.master>

<div
    x-data="mtSearchResultsPage()"
    x-init="init()"
    @search-result-clicked.window="addToHistory($event.detail)"
    class="min-h-screen bg-gray-50 dark:bg-gray-950"
>

    {{-- ══════════════════════════════════════════════
         HERO — champ de recherche + breadcrumb
         ══════════════════════════════════════════════ --}}
    <div class="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

            {{-- Breadcrumb --}}
            <div class="flex items-center gap-2 text-sm text-gray-400 dark:text-gray-500 mb-4">
                <a href="{{ route('dashboard') }}" wire:navigate
                   class="hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                    <i class="fa-solid fa-house text-xs"></i>
                </a>
                <i class="fa-solid fa-chevron-right text-[10px]"></i>
                <span class="text-gray-600 dark:text-gray-300 font-medium">Recherche</span>
                @if($query)
                    <i class="fa-solid fa-chevron-right text-[10px]"></i>
                    <span class="text-gray-900 dark:text-white font-semibold truncate max-w-[200px]">
                        {{ $query }}
                    </span>
                @endif
            </div>

            {{-- Champ principal (lié au composant Livewire via wire:model sur le composant enfant) --}}
            <div class="relative max-w-2xl">
                <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 text-base pointer-events-none z-10"></i>
                <input
                    x-ref="pageInput"
                    type="text"
                    value="{{ $query }}"
                    @input.debounce.{{ config('mt-search.debounce', 300) }}ms="
                        $dispatch('search-query-updated', { query: $event.target.value })
                    "
                    @keydown.enter.prevent="$dispatch('search-query-updated', { query: $refs.pageInput.value })"
                    placeholder="Affiner la recherche…"
                    class="results-main-input w-full pl-12 pr-12 py-3.5 text-base"
                    autocomplete="off"
                >
                <button
                    x-show="$refs.pageInput && $refs.pageInput.value"
                    @click="$refs.pageInput.value = ''; $dispatch('search-query-updated', { query: '' }); $refs.pageInput.focus()"
                    class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
                    x-cloak>
                    <i class="fa-solid fa-times-circle text-lg"></i>
                </button>
            </div>

        </div>
    </div>


    {{-- ══════════════════════════════════════════════
         COMPOSANT LIVEWIRE — SearchResults
         Il gère : filtres, stats, liste, load more
         ══════════════════════════════════════════════ --}}
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8"
         @search-query-updated.window="syncUrl($event.detail.query)">

        {{-- État vide — aucune query --}}
        @if(strlen(trim($query)) < config('mt-search.min_chars', 2))
            <div class="text-center py-20" id="empty-state">
                <div class="w-20 h-20 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center mx-auto mb-5 shadow-sm">
                    <i class="fa-solid fa-magnifying-glass text-3xl text-gray-300 dark:text-gray-600"></i>
                </div>
                <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">Lancez une recherche</h2>
                <p class="text-gray-500 dark:text-gray-400 text-sm max-w-sm mx-auto">
                    Tapez au moins {{ config('mt-search.min_chars', 2) }} caractères pour rechercher dans toute l'application.
                </p>

                {{-- Historique --}}
                <div x-show="history.length > 0" class="mt-10 max-w-lg mx-auto text-left">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-xs font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500">
                            Recherches récentes
                        </h3>
                        <button @click="clearHistory()"
                                class="text-xs text-blue-500 hover:text-blue-700 dark:hover:text-blue-300 transition-colors">
                            Tout effacer
                        </button>
                    </div>
                    <div class="space-y-1.5">
                        <template x-for="(item, idx) in history" :key="idx">
                            <a :href="item.url" wire:navigate
                               class="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white dark:bg-gray-800
                                      border border-gray-100 dark:border-gray-700
                                      hover:border-blue-200 dark:hover:border-blue-800
                                      hover:bg-blue-50/40 dark:hover:bg-blue-900/10
                                      transition-all group shadow-sm">
                                <div class="w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center flex-shrink-0 text-gray-400">
                                    <i class="fa-solid fa-clock-rotate-left text-xs"></i>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-800 dark:text-gray-200 truncate" x-text="item.title"></p>
                                    <p x-show="item.category" class="text-xs text-gray-400 dark:text-gray-500 truncate" x-text="item.category"></p>
                                </div>
                                <button @click.prevent.stop="removeFromHistory(idx)"
                                        class="opacity-0 group-hover:opacity-100 p-1 rounded-lg text-gray-400
                                               hover:text-gray-600 dark:hover:text-gray-200
                                               hover:bg-gray-100 dark:hover:bg-gray-700 transition-all">
                                    <i class="fa-solid fa-times text-xs"></i>
                                </button>
                            </a>
                        </template>
                    </div>
                </div>
            </div>
        @endif

        {{-- ── Composant Livewire SearchResults ──
             Rendu uniquement si une query est présente.
             Il écoute l'événement 'search-query-updated' pour se synchroniser
             avec le champ input du hero ci-dessus.
        --}}
        @if(strlen(trim($query)) >= config('mt-search.min_chars', 2))
            <livewire:mt.search-results
                :initial-query="$query"
                :initial-category="$category ?? null"
                wire:key="search-results-{{ md5($query . ($category ?? '')) }}"
            />
        @endif

    </div>

</div>


{{-- ══════════════════════════════════════════════
     STYLES
     ══════════════════════════════════════════════ --}}
@push('styles')
<style>
    /* ── Champ principal ── */
    .results-main-input {
        background: white; border: 1.5px solid #e5e7eb; border-radius: 14px;
        color: #111827; outline: none;
        box-shadow: 0 1px 4px rgba(0,0,0,.04);
        transition: border-color .15s, box-shadow .15s;
    }
    .dark .results-main-input { background: #1f2937; border-color: #374151; color: #f9fafb; }
    .results-main-input:focus { border-color: #3b82f6; box-shadow: 0 0 0 4px rgba(59,130,246,.12); }
    .dark .results-main-input:focus { box-shadow: 0 0 0 4px rgba(59,130,246,.18); }
    .results-main-input::placeholder { color: #9ca3af; }

    /* ── Filtres ── */
    .results-filter-btn {
        display: inline-flex; align-items: center;
        padding: 5px 12px; border-radius: 20px;
        font-size: 12px; font-weight: 500; white-space: nowrap;
        color: #6b7280; background: white; border: 1.5px solid #e5e7eb;
        cursor: pointer; transition: all .15s;
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
    }
    .dark .results-filter-btn { color: #9ca3af; background: #1f2937; border-color: #374151; }
    .results-filter-btn:hover { border-color: #d1d5db; background: #f9fafb; color: #374151; }
    .dark .results-filter-btn:hover { border-color: #4b5563; background: #374151; color: #d1d5db; }
    .results-filter-btn.active { background: #eff6ff; color: #2563eb; border-color: #93c5fd; box-shadow: 0 0 0 2px rgba(59,130,246,.1); }
    .dark .results-filter-btn.active { background: rgba(37,99,235,.15); color: #60a5fa; border-color: rgba(96,165,250,.4); }

    /* ── Item résultat ── */
    .results-item {
        display: flex; align-items: center; gap: 14px;
        padding: 14px 16px; background: white;
        border: 1.5px solid #f3f4f6; border-radius: 16px;
        text-decoration: none;
        box-shadow: 0 1px 3px rgba(0,0,0,.04);
        transition: all .15s ease;
    }
    .dark .results-item { background: #1f2937; border-color: #374151; }
    .results-item:hover {
        border-color: #bfdbfe;
        box-shadow: 0 4px 12px rgba(59,130,246,.08), 0 1px 3px rgba(0,0,0,.04);
        transform: translateY(-1px);
    }
    .dark .results-item:hover { border-color: rgba(96,165,250,.3); box-shadow: 0 4px 12px rgba(59,130,246,.12); }

    /* ── Badge catégorie ── */
    .results-cat-badge { display: inline-flex; align-items: center; gap: 3px; padding: 3px 8px; border-radius: 20px; }
    .badge-blue   { background:#dbeafe; color:#2563eb; }
    .badge-green  { background:#dcfce7; color:#16a34a; }
    .badge-purple { background:#ede9fe; color:#7c3aed; }
    .badge-orange { background:#ffedd5; color:#ea580c; }
    .badge-red    { background:#fee2e2; color:#dc2626; }
    .badge-teal   { background:#ccfbf1; color:#0d9488; }
    .badge-pink   { background:#fce7f3; color:#db2777; }
    .badge-gray   { background:#f3f4f6; color:#6b7280; }
    .dark .badge-blue   { background:rgba(37,99,235,.2);   color:#93c5fd; }
    .dark .badge-green  { background:rgba(22,163,74,.2);   color:#86efac; }
    .dark .badge-purple { background:rgba(124,58,237,.2);  color:#c4b5fd; }
    .dark .badge-orange { background:rgba(234,88,12,.2);   color:#fdba74; }
    .dark .badge-red    { background:rgba(220,38,38,.2);   color:#fca5a5; }
    .dark .badge-teal   { background:rgba(13,148,136,.2);  color:#5eead4; }
    .dark .badge-pink   { background:rgba(219,39,119,.2);  color:#f9a8d4; }
    .dark .badge-gray   { background:#374151; color:#9ca3af; }

    /* ── Avatars ── */
    .bg-cat-blue   { background:#3b82f6; }
    .bg-cat-green  { background:#22c55e; }
    .bg-cat-purple { background:#8b5cf6; }
    .bg-cat-orange { background:#f97316; }
    .bg-cat-red    { background:#ef4444; }
    .bg-cat-teal   { background:#14b8a6; }
    .bg-cat-pink   { background:#ec4899; }
    .bg-cat-gray   { background:#6b7280; }

    /* ── Highlight ── */
    mark.search-highlight {
        background: #fef08a; color: #713f12;
        border-radius: 2px; padding: 0 1px; font-weight: 600;
    }
    .dark mark.search-highlight { background: rgba(234,179,8,.3); color: #fde047; }

    .scrollbar-none { scrollbar-width: none; }
    .scrollbar-none::-webkit-scrollbar { display: none; }
</style>
@endpush


{{-- ══════════════════════════════════════════════
     ALPINE — gestion historique + sync URL
     ══════════════════════════════════════════════ --}}
@push('scripts')
<script>
function mtSearchResultsPage() {
    return {
        history: [],

        init() {
            this.loadHistory();
        },

        // Sync l'URL sans rechargement quand la query change
        syncUrl(query) {
            const url = new URL(window.location.href);
            query
                ? url.searchParams.set('q', query)
                : url.searchParams.delete('q');
            window.history.replaceState({}, '', url.toString());
        },

        // ── Historique localStorage ────────────────────
        loadHistory() {
            try {
                const raw = localStorage.getItem('mt_search_history');
                this.history = raw ? JSON.parse(raw) : [];
            } catch { this.history = []; }
        },

        addToHistory(detail) {
            const entry = {
                title:    detail.title ?? '',
                url:      detail.url ?? '#',
                category: detail.category ?? null,
            };
            this.history = [
                entry,
                ...this.history.filter(h => h.url !== entry.url),
            ].slice(0, {{ config('mt-search.history_limit', 8) }});
            localStorage.setItem('mt_search_history', JSON.stringify(this.history));
        },

        removeFromHistory(idx) {
            this.history.splice(idx, 1);
            localStorage.setItem('mt_search_history', JSON.stringify(this.history));
        },

        clearHistory() {
            this.history = [];
            localStorage.removeItem('mt_search_history');
        },
    };
}
</script>
@endpush

</x-mt::layouts.master>