<div>
    @if (count($locales) > 1)
    <x-mt::dropdown>
        <x-slot name="trigger">
            <button class="p-2 rounded-lg mt-btn-icon"
            :aria-label="'{{ mt_translate('change_language') }}'"
            >
                <x-mt::icon name="{{ $locales[$current]['icon'] ?? 'language' }}" />
            </button>
        </x-slot>
        <x-mt::dropdown.menu>
            @foreach ($locales as $code => $info)
                <x-mt::dropdown.item
                    method="switchLocale('{{ $code }}')"
                    :label="$info['label']"
                />
            @endforeach
        </x-mt::dropdown.menu>
    </x-mt::dropdown>
    @endif
</div>
