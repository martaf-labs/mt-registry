 <div class="flex flex-col gap-6">
    <x-auth-header :title="__('Mot de passe oublié')" :description="__('Entrez votre e-mail pour recevoir un lien de réinitialisation de mot de passe')" />

    <!-- Session Status -->
    <x-auth-session-status class="text-center" :status="session('status')" />

    <form method="POST" wire:submit="sendPasswordResetLink" class="flex flex-col gap-6">
        <!-- Email Address -->
        <flux:input
            wire:model="email"
            :label="__('Addresse e-mail')"
            type="email"
            required
            autofocus
            placeholder="email@example.com"
        />

        <flux:button variant="primary" type="submit" class="w-full">{{ __('Envoyer le lien de réinitialisation') }}</flux:button>
    </form>

    <div class="space-x-1 rtl:space-x-reverse text-center text-sm text-zinc-400">
        <span>{{ __('Ou, retour à') }}</span>
        <flux:link :href="route('login')" wire:navigate>{{ __('connexion') }}</flux:link>
    </div>
</div>
