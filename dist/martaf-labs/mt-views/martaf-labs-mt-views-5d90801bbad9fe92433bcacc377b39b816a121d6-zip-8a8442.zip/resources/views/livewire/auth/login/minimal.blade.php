{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : minimal                                                ║
║  Vue    : login/minimal.blade.php                                ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : colonne unique étroite, sans card, fond nu          ║
║              accent typographique, trait --mt-secondary          ║
║  Usage     : blog corporate, lettre, app minimaliste, newsletter ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@section('title', 'Connexion')

<div class="flex min-h-screen items-center justify-center p-4 mt-bg">
    <div class="w-full max-w-xs space-y-10">

        {{-- En-tête : app name + retour --}}
        <div class="flex items-center justify-between">
            <a href="{{ $hasHome ? route('home') : '#' }}" wire:navigate
               class="flex items-center gap-1.5 text-xs text-gray-400 dark:text-white/30
                      hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <i class="fa-solid fa-arrow-left text-[10px]"></i>
                Retour
            </a>
            <span class="text-xs font-bold uppercase tracking-widest text-[rgb(var(--mt-secondary))]">
                {{ mt_config('app_name') }}
            </span>
        </div>

        {{-- Titre --}}
        <div class="space-y-4">
            <div class="w-10 h-[3px] rounded-full"
                 style="background: rgb(var(--mt-secondary));"></div>
            <h1 class="text-4xl font-black text-gray-900 dark:text-white leading-tight">
                Connexion
            </h1>
            <p class="text-sm text-gray-500 dark:text-white/40 leading-relaxed">
                Entrez vos informations pour continuer.
            </p>
        </div>

        {{-- Formulaire (sans card) --}}
        @include('mt::livewire.auth.login.partials._form')

        {{-- Liens --}}
        @include('mt::livewire.auth.login.partials._footer-links')

    </div>
</div>
