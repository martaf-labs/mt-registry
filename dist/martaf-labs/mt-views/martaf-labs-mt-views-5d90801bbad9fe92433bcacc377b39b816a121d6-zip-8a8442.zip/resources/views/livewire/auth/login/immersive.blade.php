{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : immersive                                              ║
║  Vue    : login/immersive.blade.php                              ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : image de fond plein écran + overlay dégradé         ║
║              formulaire glassmorphism centré sur l'image         ║
║  Usage     : lifestyle, tourisme, hôtellerie, agence créative    ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@section('title', 'Connexion')

<div class="relative flex min-h-screen items-center justify-center p-4 overflow-hidden">

    {{-- ── FOND : image asset ou dégradé mt-primary --}}
    @if(mt_config('assets.login_bg'))
        <img src="{{ asset(mt_config('assets.login_bg')) }}"
             alt=""
             class="absolute inset-0 w-full h-full object-cover">
    @else
        <div class="absolute inset-0"
             style="background: linear-gradient(135deg, rgb(var(--mt-primary)) 0%, rgb(var(--mt-secondary)) 100%);"></div>
    @endif

    {{-- ── Overlay sombre --}}
    <div class="absolute inset-0 bg-black/55"></div>

    {{-- ── Motif de points discret --}}
    <div class="absolute inset-0 opacity-[0.06]"
         style="background-image: radial-gradient(circle, #fff 1px, transparent 1px);
                background-size: 28px 28px;"></div>

    {{-- ── CARD GLASS ─────────────────────────────────────────── --}}
    <div class="relative w-full max-w-sm"
         style="background: rgba(255,255,255,0.08);
                backdrop-filter: blur(24px);
                -webkit-backdrop-filter: blur(24px);
                border: 1px solid rgba(255,255,255,0.18);
                border-radius: 1.25rem;
                box-shadow: 0 25px 50px rgba(0,0,0,0.4);">

        {{-- Liseré top accent --}}
        <div class="absolute top-0 left-8 right-8 h-[1px]"
             style="background: linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent);"></div>

        <div class="p-8 space-y-7">

            {{-- Logo + titre --}}
            <div class="text-center space-y-3">
                @if(mt_config('assets.logos.svg'))
                    <img src="{{ asset(mt_config('assets.logos.svg')) }}"
                         alt="{{ mt_config('app_name') }}"
                         class="h-9 w-auto mx-auto brightness-0 invert">
                @else
                    <div class="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center mx-auto">
                        <span class="text-white font-black text-xl">
                            {{ strtoupper(substr(mt_config('app_name'), 0, 1)) }}
                        </span>
                    </div>
                @endif
                <div>
                    <h1 class="text-2xl font-black text-white">Connexion</h1>
                    <p class="text-sm text-white/55 mt-1">
                        Accédez à votre espace {{ mt_config('app_name') }}
                    </p>
                </div>
            </div>

            {{-- Status session --}}
            <x-mt::auth-session-status class="text-sm text-white/80" :status="session('status')" />

            {{-- Formulaire --}}
            <form wire:submit="login" class="space-y-5">

                <x-mt::form.input
                    wire:model="email"
                    :label="__('Adresse e-mail')"
                    type="email"
                    required autofocus
                    autocomplete="email"
                    placeholder="email@exemple.com"
                    class="bg-white/10 border-white/20 text-white placeholder:text-white/35
                           focus:border-white/60 focus:ring-white/20"
                />

                <div>
                    <x-mt::form.input
                        wire:model="password"
                        :label="__('Mot de passe')"
                        type="password"
                        required
                        autocomplete="current-password"
                        :placeholder="__('••••••••')"
                        viewable
                        class="bg-white/10 border-white/20 text-white placeholder:text-white/35
                               focus:border-white/60 focus:ring-white/20"
                    />
                    @if($hasPasswordReset)
                        <div class="flex justify-end mt-1.5">
                            <a href="{{ route('password.request') }}" wire:navigate
                               class="text-xs text-white/50 hover:text-white transition-colors">
                                Mot de passe oublié ?
                            </a>
                        </div>
                    @endif
                </div>

                <x-mt::form.toggle wire:model="remember" :label="__('Rester connecté')"
                    class="text-white/60" />

                <x-mt::button
                    variant="primary"
                    type="submit"
                    endIcon="chevron-right"
                    loading="login"
                    data-test="login-button"
                    class="w-full"
                    style="background: rgba(255,255,255,0.2); border-color: rgba(255,255,255,0.3);
                           backdrop-filter: blur(8px);"
                >
                    {{ mt_translate('login') }}
                </x-mt::button>
            </form>

            {{-- Liens --}}
            @if($hasRegister || $hasHome)
                <div class="pt-4 border-t border-white/10 text-center space-y-2 text-sm">
                    @if($hasRegister)
                        <p class="text-white/50">
                            Pas de compte ?
                            <a href="{{ route('register') }}" wire:navigate
                               class="text-white font-semibold hover:underline ml-1">
                                S'inscrire
                            </a>
                        </p>
                    @endif
                    @if($hasHome)
                        <a href="{{ route('home') }}" wire:navigate
                           class="block text-xs text-white/35 hover:text-white/60 transition-colors">
                            ← {{ mt_config('app_name') }}
                        </a>
                    @endif
                </div>
            @endif

        </div>
    </div>

</div>
