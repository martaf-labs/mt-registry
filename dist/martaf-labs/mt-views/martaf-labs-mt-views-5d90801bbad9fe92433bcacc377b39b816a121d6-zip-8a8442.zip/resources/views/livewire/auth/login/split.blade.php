{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : split                                                  ║
║  Vue    : login/split.blade.php                                  ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : panneau marque 60% gauche · formulaire 40% droite   ║
║  Accent    : dégradé --mt-primary → --mt-secondary               ║
║  Usage     : corporate, SaaS, consulting, plateforme B2B         ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@section('title', 'Connexion')

<div class="flex min-h-screen w-full">

    {{-- ══ PANNEAU GAUCHE — BRANDING ══════════════════════════════ --}}
    <div class="relative hidden lg:flex lg:w-3/5 flex-col justify-between p-14 overflow-hidden"
         style="background: linear-gradient(135deg, rgb(var(--mt-primary)) 0%, rgb(var(--mt-secondary)) 100%);">

        {{-- Cercles décoratifs --}}
        <div class="absolute -bottom-24 -right-24 w-96 h-96 rounded-full opacity-20"
             style="background: rgba(255,255,255,0.3);"></div>
        <div class="absolute -bottom-10 -right-10 w-56 h-56 rounded-full opacity-10"
             style="background: rgba(255,255,255,0.4);"></div>
        <div class="absolute top-1/3 -left-16 w-48 h-48 rounded-full opacity-10"
             style="background: rgba(255,255,255,0.3);"></div>

        {{-- Logo --}}
        <div class="relative">
            @if(mt_config('assets.logos.svg'))
                <img src="{{ asset(mt_config('assets.logos.svg')) }}"
                     alt="{{ mt_config('app_name') }}"
                     class="h-8 w-auto brightness-0 invert">
            @else
                <span class="text-white font-bold text-sm tracking-widest uppercase opacity-90">
                    {{ mt_config('app_name') }}
                </span>
            @endif
        </div>

        {{-- Citation centrale --}}
        <div class="relative space-y-6">
            <div class="w-12 h-[2px] bg-white opacity-50 rounded-full"></div>
            <blockquote class="text-white text-4xl font-black leading-tight max-w-md">
                Votre espace,<br>
                votre <span class="opacity-70">avenir.</span>
            </blockquote>
            <p class="text-white/60 text-sm leading-relaxed max-w-xs">
                Accédez à l'ensemble de vos outils et ressources en un seul endroit.
            </p>
        </div>

        {{-- Footer --}}
        <div class="relative flex items-center gap-3">
            <div class="flex-1 h-px bg-white/20"></div>
            <span class="text-white/40 text-xs tracking-widest uppercase">
                Sécurisé & Confidentiel
            </span>
        </div>

    </div>

    {{-- ══ PANNEAU DROIT — FORMULAIRE ════════════════════════════ --}}
    <div class="flex flex-1 flex-col justify-center px-8 py-14 sm:px-14 mt-bg">

        {{-- Mobile : logo --}}
        <div class="lg:hidden mb-10">
            @if(mt_config('assets.logos.svg'))
                <img src="{{ asset(mt_config('assets.logos.svg')) }}"
                     alt="{{ mt_config('app_name') }}" class="h-8 w-auto">
            @else
                <span class="font-bold text-gray-900 dark:text-white text-sm tracking-widest uppercase">
                    {{ mt_config('app_name') }}
                </span>
            @endif
        </div>

        <div class="mx-auto w-full max-w-sm space-y-8">

            <div class="space-y-1">
                <h1 class="text-3xl font-black text-gray-900 dark:text-white">Connexion</h1>
                <p class="text-sm text-gray-500 dark:text-white/40">
                    Entrez vos identifiants pour accéder à votre espace
                </p>
            </div>

            @include('mt::livewire.auth.login.partials._form')

            @include('mt::livewire.auth.login.partials._footer-links')

        </div>
    </div>

</div>
