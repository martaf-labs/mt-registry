{{--
  Partial : _footer-links.blade.php
  Liens secondaires (inscription, retour accueil).
  Données : $hasRegister, $hasHome
--}}

@if($hasRegister || $hasHome)
<div class="space-y-3 text-center text-sm">

    @if($hasRegister)
        <p class="text-gray-500 dark:text-white/40">
            Pas encore de compte ?
            <a href="{{ route('register') }}" wire:navigate
               class="font-semibold text-[rgb(var(--mt-secondary))] hover:underline underline-offset-2 ml-1">
                Inscrivez-vous
            </a>
        </p>
    @endif

    @if($hasHome)
        <a href="{{ route('home') }}" wire:navigate
           class="block text-xs text-gray-400 dark:text-white/25
                  hover:text-[rgb(var(--mt-secondary))] transition-colors">
            ← Retour à {{ mt_config('app_name') }}
        </a>
    @endif

</div>
@endif
