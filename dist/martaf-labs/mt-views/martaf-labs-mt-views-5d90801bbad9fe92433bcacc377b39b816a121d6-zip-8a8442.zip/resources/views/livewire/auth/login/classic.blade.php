{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : classic                                                ║
║  Vue    : login/classic.blade.php                                ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : card centrée, logo en haut, formulaire standard     ║
║  Usage     : blog généraliste, application SaaS, back-office     ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@section('title', 'Connexion')

<div class="flex items-center justify-center min-h-screen p-4 mt-bg">

    <div class="w-full max-w-sm">

        @if ($hasLogo)
        {{-- Logo --}}
        <div class="flex flex-col items-center mb-8">
            @if(mt_config('png'))
                <img src="{{ asset(mt_config('assets.logos.svg')) }}"
                     alt="{{ mt_config('app_name') }}"
                     class="w-auto h-10 mb-4">
            @else
                <div class="flex items-center justify-center w-12 h-12 mb-4 rounded-2xl mt-bg-primary">
                    <span class="text-xl font-black text-white">
                        {{ strtoupper(substr(mt_config('app_name'), 0, 1)) }}
                    </span>
                </div>
            @endif
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
                {{ mt_config('app_name') }}
            </h1>
        </div>
        @endif

        {{-- Card --}}
        <div class="space-y-6 border border-gray-100 mt-bg rounded-2xl dark:border-white/6 p-7">

            <div class="space-y-1">
                <h2 class="text-lg font-bold text-gray-900 dark:text-white">Connexion</h2>
                <p class="text-sm text-gray-500 dark:text-white/40">
                    Entrez vos identifiants pour accéder à votre espace
                </p>
            </div>

            @include('mt::livewire.auth.login.partials._form')

        </div>

        {{-- Liens secondaires --}}
        <div class="mt-5">
            @include('mt::livewire.auth.login.partials._footer-links')
        </div>

    </div>
</div>
