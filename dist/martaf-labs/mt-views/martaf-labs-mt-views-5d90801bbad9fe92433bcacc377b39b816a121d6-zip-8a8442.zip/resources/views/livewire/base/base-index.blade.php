<div>

    @php

        $features = $indexDatas['features'] ?? [];

        $firstColumnField = $firstColumn['field'] ?? [];
        $firstColumnLabel = $firstColumn['label'] ?? '';

        $canAddImages = $indexDatas['canAddImages'] ?? false;
        $showFilters = $indexDatas['showFilters'] ?? false;

        $hasMainActions = count($mainActions) > 0;
        $searchable = $features['searchable'] ?? true;

        $availableFilters = $filtersData['availableFilters'] ?? [];
        $activeFilters = $filtersData['activeFilters'] ?? [];
        $filterValues = $filtersData['filterValues'] ?? [];
        $activeFiltersCount = $filtersData['activeFiltersCount'] ?? 0;
        $filterOptions = $filtersData['filterOptions'] ?? [];
    @endphp

    <div class="min-h-screen py-3 lg:py-6">
        <div class="px-2 mx-auto max-w-7xl lg:px-8">

            <div class="hidden lg:block">
                <x-mt::breadcrumbs
                    :title="$title"
                    :datas="$navItems"
                    :actions="$mainActions"
                ></x-mt::breadcrumbs>
            </div>

            <div class="lg:hidden">
                <x-mt::actions.floating :actions="$mainActions" visible="4"/>
            </div>

            @if (!empty($this->columns()) && $items->count() > 0)
            <!-- Statistiques -->
            <div class="grid hidden grid-cols-1 gap-6 mb-8 md:grid-cols-2 lg:grid-cols-4" wire:ignore>
                @foreach($statistics as $stat)
                <div class="p-6 transition-all duration-200 rounded-xl hover:shadow-sm mt-card">
                    <div class="flex items-center justify-start">
                        <div class="p-3 mr-4 rounded-lg mt-bg-secondary">
                            <i class="{{ $stat['icon'] ?? 'rectangle-stack' }} mt-text-primary text-xl"></i>
                        </div>
                        <div>
                            <p class="mb-1 text-sm font-medium mt-text-muted">
                                {{ $stat['label'] }}
                            </p>
                            <p class="text-2xl font-bold mt-text">
                                {{ add_zero($stat['value']) }}
                            </p>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            @endif

            @if (!empty($this->columns()) && $items->count() > 0)
            <!-- Barre de recherche et filtres -->
            <div class="py-2 lg:mb-3">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:gap-4">
                    <div class="flex lg:gap-3">
                        @if(!empty($searchableFields))
                        <div class="w-full ml-auto mr-0 lg:basis-2/3">
                            <div class="hidden lg:block">
                                <x-mt::form.input type="search" placeholder="Rechercher..." icon="magnifying-glass" wire:model.live="search" />
                            </div>
                            <div class="block lg:hidden">
                                <x-mt::form.input type="search" size="sm" placeholder="Rechercher..." icon="magnifying-glass" wire:model.live="search" class="rounded-full" />
                            </div>
                        </div>

                        <div class="hidden basis-1/3 lg:block">
                            @php
                                $nberPerPages = $total > 20 ? range(10, min($total, 100), 10) : [10, 20, 50];
                            @endphp
                            <x-mt::form.select wire:model.live="perPage">
                                @foreach ($nberPerPages as $nber)
                                    <option value="{{ $nber }}">{{ $nber }}</option>
                                @endforeach
                            </x-mt::form.select>
                        </div>
                        @endif
                    </div>

                    <div class="justify-end flex-grow">
                        <div class="flex justify-end gap-2">
                            @if($showFilters && count($availableFilters) > 0)
                            <flux:button
                                icon="funnel"
                                wire:click="toggleFilters"
                                :badge="$activeFiltersCount > 0 ? (string) $activeFiltersCount : null"
                                :variant="$activeFiltersCount > 0 ? 'primary' : 'ghost'">
                                Filtres
                            </flux:button>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Panneau des filtres -->
                @if($showFilters && count($availableFilters) > 0)
                <div x-data="{ open: @entangle('showFilters') }" x-show="open"
                    x-transition:enter="transition ease-out duration-200"
                    x-transition:enter-start="opacity-0 transform -translate-y-2"
                    x-transition:enter-end="opacity-100 transform translate-y-0"
                    x-transition:leave="transition ease-in duration-150"
                    x-transition:leave-start="opacity-100 transform translate-y-0"
                    x-transition:leave-end="opacity-0 transform -translate-y-2"
                    class="p-4 mt-4 rounded-lg mt-card">

                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-sm font-medium mt-text">Filtres</h3>
                        <div class="flex gap-2">
                            <flux:button size="sm" variant="primary" wire:click="applyFilters" icon="check">
                                Appliquer
                            </flux:button>
                            @if($activeFiltersCount > 0)
                            <flux:button size="sm" variant="ghost" wire:click="resetAllFilters" icon="x-mark">
                                Réinitialiser
                            </flux:button>
                            @endif
                        </div>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
                        @foreach($availableFilters as $filterKey => $filterConfig)
                            @php
                                $filterType = $filterConfig['type'] ?? 'select';
                                $filterLabel = $filterConfig['label'] ?? $filterKey;
                                $isMultiple = $filterConfig['multiple'] ?? false;
                                $filterOptions = $filterConfig['options'] ?? [];
                                $currentValue = $filterValues[$filterKey] ?? '';
                            @endphp

                            <div class="space-y-2">
                                <label class="text-xs mt-label">{{ $filterLabel }}</label>

                                @if($filterType === 'select')
                                    <flux:select
                                        wire:model="filterValues.{{ $filterKey }}"
                                        :multiple="$isMultiple"
                                        size="sm">
                                        <flux:select.option value="">Tous</flux:select.option>
                                        @foreach($filterOptions as $value => $label)
                                            <flux:select.option value="{{ $value }}">{{ $label }}</flux:select.option>
                                        @endforeach
                                    </flux:select>

                                @elseif($filterType === 'range')
                                    <div class="flex gap-2">
                                        <flux:input type="number" placeholder="Min" wire:model="filterValues.{{ $filterKey }}_min" size="sm" :min="$filterConfig['min'] ?? ''" :max="$filterConfig['max'] ?? ''" />
                                        <flux:input type="number" placeholder="Max" wire:model="filterValues.{{ $filterKey }}_max" size="sm" :min="$filterConfig['min'] ?? ''" :max="$filterConfig['max'] ?? ''" />
                                    </div>

                                @elseif($filterType === 'date')
                                    <flux:input type="date" wire:model="filterValues.{{ $filterKey }}" size="sm" />

                                @elseif($filterType === 'checkbox')
                                    <div class="space-y-1 overflow-y-auto max-h-32">
                                        @foreach($filterOptions as $value => $label)
                                            <label class="flex items-center space-x-2 text-xs">
                                                <input
                                                    type="checkbox"
                                                    value="{{ $value }}"
                                                    wire:model="filterValues.{{ $filterKey }}"
                                                    class="rounded mt-checkbox"
                                                >
                                                <span class="mt-text">{{ $label }}</span>
                                            </label>
                                        @endforeach
                                    </div>
                                @endif

                                @if(!empty($activeFilters[$filterKey]) ||
                                    (!empty($activeFilters[$filterKey.'_min']) || !empty($activeFilters[$filterKey.'_max'])))
                                    <div class="flex justify-end">
                                        <button
                                            type="button"
                                            wire:click="resetFilter('{{ $filterKey }}')"
                                            class="text-xs transition-opacity mt-text-danger hover:opacity-75"
                                        >
                                            <flux:icon name="x-mark" class="size-3" />
                                        </button>
                                    </div>
                                @endif
                            </div>
                        @endforeach
                    </div>
                </div>
                @endif
            </div>
            @endif

            <!-- Tableau -->
            <div class="w-full overflow-hidden">
                @if (!empty($this->columns()) && $items->count() > 0)
                <div class="w-full overflow-x-auto rounded-xl" style="border-color: rgb(var(--mt-ui-card-border))">
                    <table class="w-full min-w-[60%] border-collapse text-xs">
                        <thead style="">
                            <tr>
                                <!-- Première colonne -->
                                @if(isset($firstColumn) && !is_null($firstColumnField))
                                @php
                                    $sortIcon = ($sortBy === $firstColumnField) ? "chevron-".($sortDirection === 'asc' ? 'up' : 'down') : "arrows-up-down";
                                    $isSortable = $this->isSortableField($firstColumnField);
                                @endphp
                                <th class="lg:px-4 py-2 lg:py-3 text-left text-xs font-medium mt-text-muted cursor-pointer w-full lg:min-w-[30%] lg:max-w-[40%] sticky left-0 z-20"
                                   @if($isSortable) wire:click="setSort('{{ $firstColumnField }}')" @endif>
                                    <div class="flex items-center gap-1">
                                        <span>{{ Illuminate\Support\Str::ucfirst($firstColumnLabel) }}</span>
                                        @if ($isSortable)
                                        <x-mt::icon name="{{ $sortIcon }}" class="size-4" />
                                        @endif
                                    </div>
                                </th>
                                @endif

                                @foreach($othersColumns as $columnField => $column)
                                    @php
                                        $columnLabel = $column['label'];
                                        $icon = ($sortBy === $columnField) ? "chevron-".($sortDirection === 'asc' ? 'up' : 'down') : "arrows-up-down";
                                        $isSortable = $this->isSortableField($columnField);
                                    @endphp
                                <th class="hidden py-2 text-xs font-medium text-left cursor-pointer lg:table-cell lg:px-4 lg:py-3 mt-text-muted whitespace-nowrap"
                                    @if($isSortable) wire:click="setSort('{{ $columnField }}')" @endif>
                                    <div class="flex items-center gap-1">
                                        <span>{{ Illuminate\Support\Str::ucfirst($columnLabel) }}</span>
                                        @if ($isSortable)
                                            <x-mt::icon name="{{ $icon }}" class="size-4" />
                                        @endif
                                    </div>
                                </th>
                                @endforeach

                                {{-- colonnes cachées --}}
                                @foreach ($hiddenColumns as $column)
                                    <th class="hidden"></th>
                                @endforeach

                                @if(count($this->getRowActions(1)) > 0)
                                <th class="sticky right-0 z-20 py-2 pr-2 text-xs font-medium text-left lg:w-20 lg:px-4 lg:py-3 mt-text-muted whitespace-nowrap mt-bg">
                                    <span class="hidden lg:block">Actions</span>
                                    <span class="sr-only">Actions</span>
                                </th>
                                @endif
                            </tr>
                        </thead>
                        <tbody class="relative" style="--tw-divide-color: rgb(var(--mt-ui-card-border)); border-color: rgb(var(--mt-ui-card-border))">

                            @foreach($items as $item)
                                @php
                                    $rowActions = $this->getRowActions($item->id);
                                    $itemColumns = $this->columns($item->id);
                                    $itemFirstColumn = $itemColumns['firstColumn'] ?? [];
                                    $itemOthersColumns = $itemColumns['othersColumns'] ?? [];
                                    $itemHiddenColumns = $itemColumns['hiddenColumns'] ?? [];
                                @endphp

                                <tr wire:key="item-{{ $item->id }}-{{ $item->updated_at->timestamp }}"
                                    class="transition-opacity duration-200 @if ($loop->index % 2 == 0) mt-bg-primary-soft @endif hover:border-b border-[rgb(var(--mt-ui-card-border))]">

                                    <!-- Première colonne -->
                                    @if(!empty($itemFirstColumn))
                                    @php
                                        $firstColumnValue        = $itemFirstColumn['value'] ?? '---';
                                        $firstColumnMetaDatas    = $itemFirstColumn['metaDatas'] ?? [];
                                        $firstColumnLabel        = $itemFirstColumn['label'];
                                        $firstColumnShowImage    = $itemFirstColumn['showImage'] ?? false;
                                        $firstColumnImage        = $itemFirstColumn['image'] ?? false;
                                        $firstColumnShowIcon     = $itemFirstColumn['showIcon'] ?? false;
                                        $firstColumnIcon         = $itemFirstColumn['icon'] ?? '';
                                        $firstColumnColor        = $itemFirstColumn['color'] ?? '';
                                        $firstColumnShowLetters  = $firstColumn['showLetters'] ?? false;
                                        $firstColumnLetters      = $itemFirstColumn['letters'] ?? false;
                                    @endphp

                                    <td class="lg:px-4 py-3 w-full lg:min-w-[30%] lg:max-w-[40%] sticky left-0 z-10">
                                        <div class="flex items-center gap-3">
                                            @if($firstColumnShowImage || $firstColumnShowLetters || $firstColumnIcon)
                                                <x-mt::avatar
                                                    :name="$firstColumnLetters"
                                                    :image="$firstColumnImage"
                                                    :icon="$firstColumnIcon"
                                                    size="10"
                                                    rounded="lg"
                                                />
                                            @endif

                                            <div class="flex-1 min-w-0">
                                                <div class="text-xs font-medium mt-text lg:text-sm">
                                                    {{ Illuminate\Support\Str::limit($firstColumnValue, 85) }}
                                                </div>
                                                @if(!empty($firstColumnMetaDatas))
                                                    <div class="text-[9px] lg:text-xs mt-text-muted truncate">
                                                        @foreach ($firstColumnMetaDatas as $metadata)
                                                            <span>{{ $metadata }}</span> @if(!$loop->last) • @endif
                                                        @endforeach
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </td>
                                    @endif

                                    @foreach($itemOthersColumns as $column)
                                    @php
                                        $columnValue   = $column['value'] ?? '---';
                                        $badgeDatas    = $column['badgeDatas'] ?? [];
                                    @endphp
                                    <td class="hidden lg:table-cell p-1.5 lg:px-4 lg:py-3 text-xs lg:text-sm mt-text whitespace-nowrap">
                                        @if (!empty($badgeDatas))
                                        @php
                                            $columnBadge      = $badgeDatas ?? null;
                                            $columnBadgeType  = $columnBadge['type'] ?? 'secondary';
                                            $columnBadgeLabel = $columnBadge['label'] ?? $columnValue;
                                        @endphp
                                        <x-mt::badge :label="$columnBadgeLabel" :type="$columnBadgeType" rounded="full" />
                                        @else
                                        {{ Illuminate\Support\Str::ucfirst($columnValue) }}
                                        @endif
                                    </td>
                                    @endforeach

                                    {{-- colonnes cachées --}}
                                    @foreach ($itemHiddenColumns as $column)
                                        <td class="hidden">
                                            <span>{{ $column['value'] }}</span>
                                        </td>
                                    @endforeach

                                    @if(count($rowActions) > 0)
                                    <td class="right-0 z-10 duration-200 lg:sticky lg:px-4 lg:py-3 focus-within:z-10 group-transition-opacity">
                                        <div class="flex items-center justify-end w-full">
                                            <x-mt::dropdown>
                                                <x-slot:trigger>
                                                    <button title="Plus d'actions" class="py-0 text-lg">
                                                        <i class="mt-icon-ellipsis-vertical"></i>
                                                    </button>
                                                </x-slot:trigger>

                                                <x-mt::dropdown.menu>
                                                @foreach ($rowActions as $action)
                                                    @php
                                                        $actionType    = $action['type'] ?? 'route';
                                                        $actionRoute   = $action['route'] ?? '#';
                                                        $actionMethod  = $action['method'] ?? '';
                                                        $actionParams  = $action['params'] ?? '';
                                                        $actionLabel   = $action['label'] ?? '';
                                                        $actionIcon    = $action['icon'] ?? '';
                                                        $actionVariant = $action['variant'] ?? 'default';
                                                    @endphp

                                                    @if ($actionType == 'route')
                                                    <x-mt::dropdown.item
                                                        wire:navigate
                                                        href="{{ $actionRoute }}"
                                                        :icon="$actionIcon"
                                                        :variant="$actionVariant"
                                                        :label="$actionLabel">
                                                    </x-mt::dropdown.item>
                                                    @endif

                                                    @if ($actionType == 'livewire')
                                                    <x-mt::dropdown.item
                                                        method="{{ $actionMethod }}({{ $actionParams }})"
                                                        :icon="$actionIcon"
                                                        :variant="$actionVariant"
                                                        :label="$actionLabel">
                                                    </x-mt::dropdown.item>
                                                    @endif
                                                @endforeach
                                                </x-mt::dropdown.menu>
                                            </x-mt::dropdown>
                                        </div>
                                    </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                @else

                <div class="py-12 text-center">
                    <x-mt::empty-state
                        title="Aucun élément trouvé !"
                        icon="mt-icon-list"
                        description="Essayez de modifier vos critères de recherche ou de filtres"
                    >
                    @if($search || $activeFiltersCount > 0)
                    <x-mt::button variant="outline" icon="mt-icon-circle-notch" wire:click="$set('search', '')">
                        Réinitialiser la recherche
                    </x-mt::button>
                    @endif
                    </x-mt::empty-state>
                </div>
                @endif

                <!-- Pagination -->
                @if(!empty($this->columns()) && $items->hasPages() && $items->count() > 0)
                <div class="px-2 py-4">
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        @if ($items->total() > 0)
                            <div class="text-xs mt-text-muted">
                                Affichage de {{ $items->firstItem() }} à {{ $items->lastItem() }} sur {{ $items->total() }} éléments
                            </div>
                        @else
                            <div class="text-sm mt-text-muted">
                                Aucun élément à afficher
                            </div>
                        @endif

                        <style>
                            .paginate-nav, .paginate-nav div, .paginate-nav button, .paginate-nav span {
                                background-color: transparent !important;
                                box-shadow: none !important;
                            }
                            .paginate-nav p { display: none !important; visibility: hidden !important; }
                        </style>
                        <div class="paginate-nav">
                            {{ $items->links() }}
                        </div>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>

    {{-- Modals --}}
    @if ($canAddImages)
    <div x-data="{ open: false }"
        wire:on="image-data-updated"="$refresh"
        x-on:open-image-manager.window="
            open = true;
            @this.set('modelClass', $event.detail.modelClass);
            @this.set('modelId', $event.detail.modelId);
        ">
        <x-mt::modal name="image-manager-modal" title="Gerer les images" x-show="open" icon="mt-icon-image">
            <livewire:mt.forms.image-manager
                {{-- :modelClass="$modelClass" --}}
                {{-- :modelId="$modelId" --}}
                :key="'img-'.class_basename($modelClass).'-'.$modelId"
                :model-type="class_basename($modelClass)"
                :model-id="$modelId"
                image-type="{{ Mt\MtViews\Enums\TypesImage::PHOTO->value }}"
                :multiple="true"
                :allow-delete="true"
            />
        </x-mt::modal>
    </div>
    @endif

    <script>
        document.addEventListener('livewire:initialized', () => {
            Livewire.on('hide-flash-after-delay', () => {
                setTimeout(() => { @this.hideFlash(); }, 5000);
            });
        });

        document.addEventListener('click', (event) => {
            const filtersPanel = document.querySelector('[x-data] [x-show]');
            const filtersButton = document.querySelector('[wire\\:click="toggleFilters"]');
            if (filtersPanel && filtersButton && !filtersPanel.contains(event.target) && !filtersButton.contains(event.target)) {
                @this.set('showFilters', false);
            }
        });
    </script>

</div>