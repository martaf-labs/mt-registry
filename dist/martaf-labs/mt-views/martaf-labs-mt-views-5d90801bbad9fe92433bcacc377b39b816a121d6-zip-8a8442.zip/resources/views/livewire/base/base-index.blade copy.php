<div>

    @php
        $firstColumn = $indexDatas['firstColumn'];
        $othersColumns = $indexDatas['othersColumns'];
        $features = $indexDatas['features'] ?? [];

        $firstColumnField = $firstColumn['field'];
        $firstColumnSubtitleFields = $firstColumn['subtitleFields'] ?? [];
        $firstColumnLabel = $firstColumn['label'];
        $firstColumnShowImage = $firstColumn['showImage'] ?? false;
        $firstColumnImage = $firstColumn['image'] ?? false;
        $firstColumnShowIcon = $firstColumn['showIcon'] ?? false;
        $firstColumnIcon = $firstColumn['icon'] ?? '';
        $firstColumnShowLetters = $firstColumn['showLetters'] ?? false;

        // Traitement des $actions
        $createAction = $indexDatas['createAction'] ?? false;
        $editAction = $indexDatas['editAction'] ?? false;
        $showAction = $indexDatas['showAction'] ?? false;
        $deleteAction = $indexDatas['deleteAction'] ?? false;
        $showProfileAction = $indexDatas['showProfileAction'] ?? false;
        $canAddImages = $indexDatas['canAddImages'] ?? false;
        $showFilters = $indexDatas['showFilters'] ?? false;

        $hasActions = count($actions) > 0;
        $searchable = $features['searchable'] ?? true;

        // Données des filtres
        $availableFilters = $filtersData['availableFilters'] ?? [];
        $activeFilters = $filtersData['activeFilters'] ?? [];
        $filterValues = $filtersData['filterValues'] ?? []; // Nouvelles valeurs temporaires
        $activeFiltersCount = $filtersData['activeFiltersCount'] ?? 0;
        $filterOptions = $filtersData['filterOptions'] ?? [];
    @endphp

    <div class="min-h-screen bg-white dark:bg-zinc-800 py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            <!-- Messages flash -->
            {{-- @if($flashMessage)
            <div class="mb-6">
                <x-alert :type="$flashType" :message="$flashMessage" />
            </div>
            @endif --}}

            <x-mt::breadcrumbs
                :title="$title"
                :datas="$navItems"
                :actions="$actions"
            ></x-mt::breadcrumbs>

            <!-- Statistiques -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8" wire:ignore>
                @foreach($statistics as $stat)
                <div class="bg-white dark:bg-zinc-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 transition-all duration-200 hover:shadow-sm">
                    <div class="flex items-center justify-start">
                        <div class="bg-{{ $stat['color'] ?? 'blue' }}-100 p-3 rounded-lg mr-4">
                            <i class="{{ $stat['icon'] ?? 'rectangle-stack' }} text-{{ $stat['color'] ?? 'blue' }}-500 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
                                {{ $stat['label'] }}
                            </p>
                            <p class="text-2xl font-bold text-zinc-800 dark:text-white">
                                {{ add_zero($stat['value']) }}
                            </p>
                        </div>
                        {{-- <div class="flex-shrink-0">
                            <div class="w-12 h-12 bg-gradient-to-br from-{{ $stat['color'] ?? 'blue' }}-100 to-{{ $stat['color'] ?? 'blue' }}-200 dark:from-{{ $stat['color'] ?? 'blue' }}-900 dark:to-{{ $stat['color'] ?? 'blue' }}-800 rounded-lg flex items-center justify-center">
                                <i class="w-6 h-6 {{ $stat['icon'] ?? 'rectangle-stack' }} text-{{ $stat['color'] ?? 'blue' }}-600 dark:text-{{ $stat['color'] ?? 'blue' }}-400"></i>
                            </div>
                        </div> --}}
                    </div>
                </div>
                @endforeach
            </div>

            @if ($items->count() > 0)
            <!-- Barre de recherche et filtres -->
            <div class="bg-white dark:bg-zinc-800 py-2 mb-3">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="flex gap-3">
                        @if(!empty($searchableFields))
                        <div class="basis-2/3">
                            <flux:input placeholder="Rechercher..." icon="magnifying-glass" wire:model.live="search" />
                        </div>

                        <div class="basis-1/3">
                            @php
                                $nberPerPages = $total > 20 ? range(10, min($total, 100), 10) : [10, 20, 50];
                            @endphp

                            <flux:select wire:model.live="perPage">
                                @foreach ($nberPerPages as $nber)
                                    <flux:select.option value="{{ $nber }}">{{ $nber }}</flux:select.option>
                                @endforeach
                            </flux:select>
                        </div>
                        @endif
                    </div>

                    <div class="flex-grow justify-end">
                        <div class="flex justify-end gap-2">
                            @if($showFilters && count($availableFilters) > 0)
                            <flux:button
                                icon="funnel"
                                wire:click="toggleFilters"
                                :badge="$activeFiltersCount > 0 ? (string) $activeFiltersCount : null"
                                :variant="$activeFiltersCount > 0 ? 'primary' : 'ghost'">
                                Filtres
                            </flux:button>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Panneau des filtres -->
                @if($showFilters && count($availableFilters) > 0)
                <div x-data="{ open: @entangle('showFilters') }" x-show="open" x-transition:enter="transition ease-out duration-200"
                    x-transition:enter-start="opacity-0 transform -translate-y-2"
                    x-transition:enter-end="opacity-100 transform translate-y-0"
                    x-transition:leave="transition ease-in duration-150"
                    x-transition:leave-start="opacity-100 transform translate-y-0"
                    x-transition:leave-end="opacity-0 transform -translate-y-2"
                    class="mt-4 p-4 bg-gray-50 dark:bg-zinc-700 rounded-lg border border-gray-200 dark:border-gray-600">

                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-sm font-medium text-gray-900 dark:text-white">Filtres</h3>
                        <div class="flex gap-2">
                            <flux:button size="sm" variant="primary" wire:click="applyFilters" icon="check">
                                Appliquer
                            </flux:button>
                            @if($activeFiltersCount > 0)
                            <flux:button size="sm" variant="ghost" wire:click="resetAllFilters" icon="x-mark">
                                Réinitialiser
                            </flux:button>
                            @endif
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        @foreach($availableFilters as $filterKey => $filterConfig)
                            @php
                                $filterType = $filterConfig['type'] ?? 'select';
                                $filterLabel = $filterConfig['label'] ?? $filterKey;
                                $isMultiple = $filterConfig['multiple'] ?? false;
                                $filterOptions = $filterConfig['options'] ?? [];
                                $currentValue = $filterValues[$filterKey] ?? '';
                            @endphp

                            <div class="space-y-2">
                                <label class="block text-xs font-medium text-gray-700 dark:text-gray-300">
                                    {{ $filterLabel }}
                                </label>

                                @if($filterType === 'select')
                                    <flux:select
                                        wire:model="filterValues.{{ $filterKey }}"
                                        :multiple="$isMultiple"
                                        size="sm">
                                        <flux:select.option value="">Tous</flux:select.option>
                                        @foreach($filterOptions as $value => $label)
                                            <flux:select.option value="{{ $value }}">{{ $label }}</flux:select.option>
                                        @endforeach
                                    </flux:select>

                                @elseif($filterType === 'range')
                                    <div class="flex gap-2">
                                        <flux:input
                                            type="number"
                                            placeholder="Min"
                                            wire:model="filterValues.{{ $filterKey }}_min"
                                            size="sm"
                                            :min="$filterConfig['min'] ?? ''"
                                            :max="$filterConfig['max'] ?? ''"
                                        />
                                        <flux:input
                                            type="number"
                                            placeholder="Max"
                                            wire:model="filterValues.{{ $filterKey }}_max"
                                            size="sm"
                                            :min="$filterConfig['min'] ?? ''"
                                            :max="$filterConfig['max'] ?? ''"
                                        />
                                    </div>

                                @elseif($filterType === 'date')
                                    <flux:input
                                        type="date"
                                        wire:model="filterValues.{{ $filterKey }}"
                                        size="sm"
                                    />

                                @elseif($filterType === 'checkbox')
                                    <div class="space-y-1 max-h-32 overflow-y-auto">
                                        @foreach($filterOptions as $value => $label)
                                            <label class="flex items-center space-x-2 text-xs">
                                                <input
                                                    type="checkbox"
                                                    value="{{ $value }}"
                                                    wire:model="filterValues.{{ $filterKey }}"
                                                    class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-zinc-700"
                                                >
                                                <span class="text-gray-700 dark:text-gray-300">{{ $label }}</span>
                                            </label>
                                        @endforeach
                                    </div>
                                @endif

                                @if(!empty($activeFilters[$filterKey]) ||
                                    (!empty($activeFilters[$filterKey.'_min']) || !empty($activeFilters[$filterKey.'_max'])))
                                    <div class="flex justify-end">
                                        <button
                                            type="button"
                                            wire:click="resetFilter('{{ $filterKey }}')"
                                            class="text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                                        >
                                            <flux:icon name="x-mark" class="size-3" />
                                        </button>
                                    </div>
                                @endif
                            </div>
                        @endforeach
                    </div>

                    <!-- Filtres actifs -->
                    @if($activeFiltersCount > 0)
                    <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="text-xs text-gray-600 dark:text-gray-400">Filtres actifs :</span>
                            @foreach($availableFilters as $filterKey => $filterConfig)
                                @php
                                    $filterValue = $activeFilters[$filterKey] ?? '';
                                    $filterLabel = $filterConfig['label'] ?? $filterKey;
                                    $filterOptions = $filterConfig['options'] ?? [];
                                @endphp

                                @if(!empty($filterValue) ||
                                    (!empty($activeFilters[$filterKey.'_min']) || !empty($activeFilters[$filterKey.'_max'])))
                                    <div class="inline-flex items-center gap-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs px-2 py-1 rounded-full">
                                        <span class="font-medium">{{ $filterLabel }}:</span>

                                        @if($filterConfig['type'] === 'range')
                                            @if(!empty($activeFilters[$filterKey.'_min']) && !empty($activeFilters[$filterKey.'_max']))
                                                <span>{{ $activeFilters[$filterKey.'_min'] }} - {{ $activeFilters[$filterKey.'_max'] }}</span>
                                            @elseif(!empty($activeFilters[$filterKey.'_min']))
                                                <span>≥ {{ $activeFilters[$filterKey.'_min'] }}</span>
                                            @elseif(!empty($activeFilters[$filterKey.'_max']))
                                                <span>≤ {{ $activeFilters[$filterKey.'_max'] }}</span>
                                            @endif
                                        @elseif(is_array($filterValue))
                                            <span>{{ implode(', ', array_map(function($val) use ($filterOptions) {
                                                return $filterOptions[$val] ?? $val;
                                            }, $filterValue)) }}</span>
                                        @else
                                            <span>{{ $filterOptions[$filterValue] ?? $filterValue }}</span>
                                        @endif

                                        <button
                                            type="button"
                                            wire:click="resetFilter('{{ $filterKey }}')"
                                            class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                                        >
                                            <flux:icon name="x-mark" class="size-3" />
                                        </button>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                    @endif
                </div>
                @endif
            </div>
            @endif

            <!-- Tableau -->
            <div class="bg-white dark:bg-zinc-800 overflow-hidden">
                @if($items->count() > 0)
                <div class="relative overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
                    <table class="w-full min-w-full text-xs">
                        <thead class="relative border-b border-gray-200 dark:border-gray-700 dark:bg-zinc-800">
                            <tr>
                                <!-- Première colonne personnalisable -->
                                @if(isset($firstColumn) && !is_null($firstColumnField))
                                @php
                                    $sortIcon = ($sortBy === $firstColumnField) ? "chevron-".($sortDirection === 'asc' ? 'up' : 'down') : "arrows-up-down";
                                    $isSortable=$this->isSortableField($firstColumnField)
                                @endphp

                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer min-w-64 sticky left-0 bg-white dark:bg-zinc-800"
                                   @if($isSortable) wire:click="setSort('{{ $firstColumnField }}')" @endif>
                                    <div class="flex items-center gap-1">
                                        @if ($firstColumnIcon)
                                        <i class="{{ $firstColumnIcon }}" class="size-4"></i>
                                        @endif
                                        <span>{{ $firstColumnLabel }}</span>
                                        @if ($isSortable)
                                        <i class="{{ $sortIcon }}" class="size-4"></i>
                                        @endif
                                    </div>
                                </th>
                                @endif

                                @foreach($othersColumns as $column)
                                    @php
                                        $columnField = $column['field'];
                                        $columnLabel = $column['label'];
                                        $icon = ($sortBy === $columnField) ? "chevron-".($sortDirection === 'asc' ? 'up' : 'down') : "arrows-up-down";
                                        $isSortable=$this->isSortableField($columnField)
                                    @endphp

                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer whitespace-nowrap"
                                    @if($isSortable) wire:click="setSort('{{ $columnField }}')" @endif>
                                    <div class="flex items-center gap-1">
                                        <span>{{ $columnLabel }}</span>

                                        @if ($isSortable)
                                            <i class="{{ $icon }}" class="size-4"></i>
                                        @endif
                                    </div>
                                </th>
                                @endforeach

                                {{-- colonnes cachées --}}
                                @foreach ($hiddenColumns as $column)
                                    <th class="hidden"></th>
                                @endforeach

                                @if($hasActions)
                                <th class="w-20 px-4 py-3 whitespace-nowrap sticky right-0 z-10 bg-white dark:bg-zinc-800">
                                    Actions
                                </th>
                                @endif
                            </tr>
                        </thead>
                        <tbody class="relative divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-zinc-800">

                            @if($loading)
                            <!-- Loader centré dans le body du tableau -->
                            <div wire:loading
                                class="absolute inset-0 flex items-center justify-center bg-white/80 dark:bg-zinc-800/80 backdrop-blur-sm z-20">
                                <div class="text-center">
                                    <div class="animate-spin rounded-full h-10 w-10 border-4 border-t-blue-600 border-zinc-300 dark:border-zinc-600 dark:border-t-blue-400 mx-auto"></div>
                                    <p class="mt-3 text-sm text-gray-600 dark:text-gray-400 font-medium">Traitement en cours...</p>
                                </div>
                            </div>
                            @endif

                            @foreach($items as $item)
                                <tr wire:key="item-{{ $item->id }}-{{ $item->updated_at->timestamp }}"
                                    class="hover:bg-zinc-50 dark:hover:bg-zinc-700/50 transition-colors duration-150 group">

                                    <!-- Première colonne personnalisable -->
                                    @if(isset($firstColumn) && !empty($firstColumnField))
                                    <td class="px-4 py-3 min-w-32 max-w-48 sticky left-0 bg-white dark:bg-zinc-800 group-hover:bg-zinc-50 dark:group-hover:bg-zinc-700/50">
                                        <div class="flex items-center gap-3">
                                            @if($firstColumnShowImage || $firstColumnShowLetters)

                                                <x-mt::avatar
                                                    name="{{ $this->getEntityTitle($item, $firstColumnField) }}"
                                                    image="{{ $this->getEntityImage($item, $firstColumnImage) }}"
                                                    size="10"
                                                />

                                            @elseif($firstColumnShowIcon)
                                                <div class="h-10 w-10 bg-zinc-100 dark:bg-zinc-700 rounded-lg flex items-center justify-center flex-shrink-0">
                                                    <i class="{{ $firstColumnIcon }} w-4 h-4 text-gray-600 dark:text-gray-400"></i>
                                                </div>
                                            @endif

                                            <div class="min-w-0 flex-1">
                                                <div class="font-medium text-zinc-800 dark:text-white text-sm">
                                                    {{ Illuminate\Support\Str::limit($this->getEntityTitle($item, $firstColumnField), 85) }}
                                                </div>
                                                @if(!empty($firstColumnSubtitleFields))
                                                    <div class="text-xs text-gray-500 dark:text-gray-400 truncate">
                                                        {{ Illuminate\Support\Str::limit($this->getEntitySubtitle($item, $firstColumnSubtitleFields), 85) }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </td>
                                    @endif

                                    @foreach($othersColumns as $column)
                                    @php
                                        $columnField = $column['field'];
                                        $badgeDatas = $column['badgeDatas'] ?? [];
                                    @endphp

                                    <td class="px-4 py-3 text-sm text-zinc-800 dark:text-gray-100 whitespace-nowrap">
                                        @if (!empty($badgeDatas))
                                        @php
                                            $itemColumnField=method_exists($item, $columnField) ? $item->$columnField() : $item->$columnField;
                                            $columnBadge = $badgeDatas[$itemColumnField] ?? null;
                                            $columnBadgeType = $columnBadge['type'] ?? 'secondary';
                                            $columnBadgeLabel = $columnBadge['label'] ?? $this->getEntityTitle($item, $columnField);
                                        @endphp
                                        <x-mt::badge :label="$columnBadgeLabel" :type="$columnBadgeType" rounded="full" />
                                        @else
                                        {{ $this->getEntityTitle($item, $columnField) }}
                                        @endif
                                    </td>
                                    @endforeach

                                    {{-- colonnes cachées --}}
                                    @foreach ($hiddenColumns as $column)
                                        <td class="hidden">
                                            <span>{{ $this->getEntityTitle($item, $column['field']) }}</span>
                                        </td>
                                    @endforeach

                                    @if($hasActions)
                                    <td class="px-4 py-3 whitespace-nowrap sticky right-0 z-10 bg-white dark:bg-zinc-800 group-hover:bg-zinc-50 dark:group-hover:bg-zinc-700/50">
                                        <div class="flex justify-end gap-1">
                                            <!-- Bouton d'options avec menu déroulant -->
                                            <flux:dropdown>
                                                <flux:button variant="ghost" size="sm" icon="ellipsis-vertical" title="Plus d'actions"></flux:button>

                                                <flux:menu>
                                                    @if ($showAction)
                                                    <flux:menu.item icon="arrow-right-start-on-rectangle"
                                                        wire:navigate href="{{ mt_get_route($model_plural.'_show', ['id' => $item->id]) }}">
                                                        Détails
                                                    </flux:menu.item>
                                                    @endif

                                                    {{-- @if ($showProfileAction)
                                                    <flux:menu.item icon="arrow-right-start-on-rectangle"
                                                        wire:navigate href="{{ route('settings.profile') }}">
                                                        Profile
                                                    </flux:menu.item>
                                                    @endif --}}

                                                    @if ($editAction)
                                                    <flux:menu.item icon="pencil-square"
                                                        wire:navigate href="{{ mt_get_route($model_plural.'_edit', ['id' => $item->id]) }}">
                                                        Modifier
                                                    </flux:menu.item>
                                                    @endif

                                                    @if ($canAddImages)
                                                    <flux:menu.item icon="photo"
                                                        wire:click="addImages('{{ $modelClass }}', {{ $item->id }})">
                                                        Ajouter des images
                                                    </flux:menu.item>
                                                    @endif

                                                    {{-- autres actions personnalisées --}}
                                                    @foreach ($customActions as $action)

                                                        @php
                                                            $isDispatchAction=$action['type' ?? ''] == 'dispatchAction'; //bouton qui execute une fonction du composant
                                                        @endphp

                                                        @if ($isDispatchAction)
                                                        @php
                                                            $ActionEvent=$action['event'];
                                                            $paramsType=$action['params']['type'];
                                                            $paramsValue=10;//getFieldValue($item, $action['params']['type']);
                                                        @endphp

                                                            <flux:menu.item
                                                                wire:click="$dispatch('{{ $ActionEvent }}',{{  json_encode([$paramsType => $paramsValue]) }})">
                                                                <i class="{{ $action['icon'] ?? '' }}"></i>
                                                                {{ $action['label'] }}
                                                            </flux:menu.item>

                                                        @else
                                                        <flux:menu.item 
                                                            wire:navigate href="{{ $action['route'] ?? '' }}"
                                                            wire:click="{{ $action['click'] }}({{ $item->id ?? '' }})">
                                                            <i class="{{ $action['icon'] ?? '' }}"></i>
                                                            {{ $action['label'] }}
                                                        </flux:menu.item>

                                                        @endif
                                                    @endforeach

                                                    @if ($deleteAction)
                                                    <flux:menu.separator/>
                                                    <flux:menu.item icon="trash" variant="danger"
                                                        wire:click="confirmDelete({{ $item->id }})">
                                                        Supprimer
                                                    </flux:menu.item>
                                                    @endif
                                                </flux:menu>
                                            </flux:dropdown>
                                        </div>
                                    </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                @else
                <div class="rounded-xl border border-gray-200 dark:border-gray-700 text-center py-12">
                    <div class="mx-auto w-24 h-24 bg-zinc-100 dark:bg-zinc-700 rounded-full flex items-center justify-center mb-4">
                        {{-- <i class="{{ get_icone($model) }}" class="size-12"/> --}}
                    </div>
                    <h3 class="text-lg font-medium text-zinc-800 dark:text-white mb-2">
                        Aucun élément trouvé
                    </h3>
                    @if($search || $activeFiltersCount > 0)
                    <p class="text-gray-500 dark:text-gray-400 mb-4">Essayez de modifier vos critères de recherche ou de filtres</p>
                    <flux:button icon="arrow-path" wire:click="$set('search', '')">
                        Réinitialiser la recherche
                    </flux:button>
                    @elseif($createAction)
                    <flux:button icon="plus" href="{{ mt_get_route($model_plural.'_create') }}" variant="primary" wire:navigate>
                        Ajouter un premier élément
                    </flux:button>
                    @endif
                </div>
                @endif

                <!-- Pagination -->
                @if($items->hasPages())
                <div class="px-2 py-4">
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                        {{-- Texte personnalisé --}}
                        @if ($items->total() > 0)
                            <div class="text-xs text-gray-700 dark:text-gray-300">
                                Affichage de {{ $items->firstItem() }} à {{ $items->lastItem() }} sur {{ $items->total() }} éléments
                            </div>
                        @else
                            <div class="text-sm text-gray-500 dark:text-gray-400">
                                Aucun élément à afficher
                            </div>
                        @endif

                        {{-- Liens de pagination --}}
                        <style>
                            .paginate-nav, .paginate-nav div, .paginate-nav button, .paginate-nav span{
                                background-color: transparent !important;
                                box-shadow: none !important;
                            }
                            .paginate-nav p{
                                display: none !important;
                                visibility: hidden !important;
                            }
                        </style>
                        <div class="paginate-nav">
                            {{ $items->links() }}
                        </div>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>

    {{-- ajout des modals --}}
    @if ($canAddImages)
    <mt::livewire:modals.image-upload :modelClass="$modelClass" />
    @endif

    @if ($exportAction)
        <mt::livewire:modals.data-exporter-modal
            modelName="{{ $model ?? false }}"
        />
    @endif

    <script>
        // Écouteur pour masquer les messages flash après délai
        document.addEventListener('livewire:initialized', () => {
            Livewire.on('hide-flash-after-delay', () => {
                setTimeout(() => {
                    @this.hideFlash();
                }, 5000);
            });
        });

        // Fermer les filtres quand on clique en dehors
        document.addEventListener('click', (event) => {
            const filtersPanel = document.querySelector('[x-data] [x-show]');
            const filtersButton = document.querySelector('[wire\\:click="toggleFilters"]');

            if (filtersPanel && filtersButton && !filtersPanel.contains(event.target) && !filtersButton.contains(event.target)) {
                @this.set('showFilters', false);
            }
        });
    </script>

</div>
