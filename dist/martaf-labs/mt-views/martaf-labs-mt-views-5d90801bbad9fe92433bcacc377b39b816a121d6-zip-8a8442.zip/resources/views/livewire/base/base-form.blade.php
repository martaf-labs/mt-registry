{{-- <div x-data="formActions(@js($this->fieldActions()))"> --}}
<div>
    @php
        $displayFields = $this->getFieldsToDisplay() ?? [];
        $allSchema = $schema ?? [];

        $fileFields = [];
        $editorFields = [];
        $hiddenFields = [];
        $otherFields = [];
        $footerFields = [];
        
        foreach($displayFields as $key => $item) {
            $type = $item['type'] ?? 'text';
            if (in_array($type, ['image-legend','image','images','file','video','document','modal-select'])) {
                $fileFields[$key] = $item;
            } elseif (in_array($type, ['editor','textarea'])) {
                $editorFields[$key] = $item;
            } elseif (in_array($type, ['toggle'])) {
                $footerFields[$key] = $item;
            } elseif ($type === 'hidden') {
                $hiddenFields[$key] = $item;
            } else {
                $otherFields[$key] = $item;
            }
        }
        
        $availableLocales = get_available_locales();
        // $codesLangues = get_available_locales();
        $isEdit = $mode == 'edit';
        
        $hasMultipleSteps = $this->hasMultipleSteps();
        $stepsToDisplay = $this->getStepsToDisplay();
        $totalDisplayedSteps = count($stepsToDisplay);
        
        $currentRealStep = null;
        if ($hasMultipleSteps && isset($stepsToDisplay[$currentStep])) {
            $currentRealStep = $stepsToDisplay[$currentStep]['realStep'] ?? $currentStep;
        }

        $hasActions = !empty($this->fieldActions());
    @endphp

    

    <div class="min-h-screen p-2 lg:px-6">

        <!-- Overlay sauvegarde -->
        <div wire:loading wire:target="save"
        class=" flex items-center justify-center mt-overlay">
            <div class="p-8 text-center">
                <div class="mx-auto mb-4 mt-spinner mt-spinner-lg"></div>
                <p class="font-semibold mt-text-muted">Sauvegarde en cours...</p>
            </div>
        </div>

        <div class="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
            
            @php
                $stepTitle = $title;  
                $stepDescription = $description ?? '';  

                if ($hasMultipleSteps) {
                    $stepInfo = $stepsToDisplay[$currentStep];
                    $stepTitle = ['content' => $stepInfo['title']];
                }
            @endphp

            <div class="hidden lg:block">            
                <x-mt::breadcrumbs
                    :title="$stepTitle"
                    :description="$stepDescription"
                    :datas="$this->navItems() ?? []" 
                />
            </div>

            <div class="grid grid-cols-1 gap-2 lg:grid-cols-4">

                <div class="space-y-8 lg:col-span-3">
                    <x-mt::form.toaster />

                    @if($hasMultipleSteps && $totalDisplayedSteps > 0)
                        <div class="mb-5">
                            <x-mt::form.stepper :current="$currentStep" :steps="$stepsToDisplay" />
                        </div>
                    @endif
                </div>
                {{-- Formulaire Principal --}}
                <div class="space-y-8 lg:col-span-3">
                    <x-mt::form submit="save" loadingTarget="save" x-data="{ showErrors: false }" 
                        x-on:validation-failed.window="showErrors = true; $nextTick(() => { $el.scrollIntoView({ behavior: 'smooth', block: 'start' }); })">
                        @csrf
                        @if($mode === 'edit') @method('PUT') @endif

                        <div class="flex flex-col gap-2 lg:flex-row lg:gap-8">
                            <div class="lg:w-2/3 grow">
                                
                                <!-- COLONNE GAUCHE -->
                                <x-mt::form.step step="{{ $hasMultipleSteps ? $currentStep : 1 }}" current="{{ $hasMultipleSteps ? $currentRealStep : 1 }}">
                                    
                                    <x-mt::form.fieldset>
                                        <div class="grid grid-cols-1 gap-6 md:grid-cols-6">
                                            @foreach($otherFields as $field => $item)
                                                @php
                                                    $itemType = $item['type'] ?? '';
                                                    $itemId = 'input_'.$field;
                                                    $itemLabel = $item['label'] ?? '';
                                                    $itemName = "form.$field";
                                                    $itemOptions = $item['options'] ?? [];
                                                    $itemCol = $item['col'] ?? 12;
                                                    $isDisabledItem = $item['disabled'] ?? false;
                                                    $itemHelp = $item['help'] ?? null;
                                                    $isRequired = $this->isRequired($field);
                                                    $itemOldvalue = $form->{$field} ?? '';
                                                    $isMultilangualField = $item['multilingual'] ?? false;
                                                @endphp

                                                <div class="@if($itemCol==12) md:col-span-6
                                                        @elseif($itemCol==9) md:col-span-4
                                                        @elseif($itemCol==6) md:col-span-3
                                                        @elseif($itemCol==4) md:col-span-2
                                                        @elseif($itemCol==3) md:col-span-1
                                                        @else md:col-span-1 @endif"
                                                    wire:key="field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                                    @if ($isMultilangualField) x-data="{ activeTab: 'fr' }" @endif>

                                                    <x-mt::form.fieldset>

                                                        @if(!in_array($itemType,['toggle']))
                                                        <x-mt::form.label :value="$itemLabel" :required="$isRequired" :isMultilangualField="$isMultilangualField" :availableLocales="$availableLocales" />
                                                        @endif

                                                        @if(in_array($itemType,['text','email','password','tel','number','float']))
                                                            @php
                                                                $inputType = $itemType;
                                                                switch ($itemType) {
                                                                    case 'float': $inputType = 'number'; break;
                                                                    default: $inputType = $itemType; break;
                                                                }
                                                                $step = $itemType==='float' ? '0.01' : null;
                                                            @endphp

                                                            @if ($isMultilangualField)
                                                                @foreach($availableLocales as $lang => $langOptions)
                                                                    @php
                                                                        $itemMultiLangName = $itemName.'.'.$lang;
                                                                        $itemMultiLangPlaceholder = $item['placeholder'] ?? "{$itemLabel} en {$langOptions['label']}";
                                                                    @endphp
                                                                    <div x-show="activeTab === '{{ $lang }}'" x-cloak>
                                                                        <x-mt::form.input type="{{ $inputType }}"
                                                                            wire:model="{{ $itemMultiLangName }}"
                                                                            x-on:change.debounce.300ms="$dispatch('field-changed', { field: '{{ $field }}.{{ $lang }}', value: $event.target.value })"
                                                                            placeholder="{{ $itemMultiLangPlaceholder }}"
                                                                            :help="$itemHelp"
                                                                            :error="$errors->first($itemMultiLangName)"
                                                                            :invalid="$errors->has($itemMultiLangName)"
                                                                            :required="$isRequired" />
                                                                    </div>
                                                                @endforeach
                                                            @else
                                                                <x-mt::form.input 
                                                                    :type="$inputType"
                                                                    wire:model="{{ $itemName }}"
                                                                    x-on:change.debounce.300ms="$dispatch('field-changed', { field: '{{ $field }}', value: $event.target.value })"
                                                                    placeholder="{{ $item['placeholder'] ?? $itemLabel }}"
                                                                    :help="$itemHelp"
                                                                    :error="$errors->first($itemName)"
                                                                    :invalid="$errors->has($itemName)"
                                                                    :required="$isRequired"
                                                                />
                                                            @endif
                                                        @endif

                                                        @if($itemType=='datetime')
                                                            <x-mt::form.date-picker 
                                                                type="datetime-local"
                                                                model="{{ $itemName }}" 
                                                                icon="fa-solid fa-calendar-day"
                                                                :help="$itemHelp"
                                                                :error="$errors->first($itemName)"
                                                                :invalid="$errors->has($itemName)"
                                                                :required="$isRequired"
                                                            />
                                                        @endif

                                                        @if($itemType=='date')
                                                            <x-mt::form.date-picker 
                                                                type="date"
                                                                model="{{ $itemName }}" 
                                                                icon="fa-solid fa-calendar-day"
                                                                :help="$itemHelp"
                                                                :error="$errors->first($itemName)"
                                                                :invalid="$errors->has($itemName)"
                                                                :required="$isRequired"
                                                            />
                                                        @endif

                                                        @if($itemType=='select')
                                                            <x-mt::form.select 
                                                                wire:model="{{ $itemName }}" 
                                                                id="{{ $itemId }}"
                                                                :help="$itemHelp"
                                                                :error="$errors->first($itemName)"
                                                                :invalid="$errors->has($itemName)"
                                                                :required="$isRequired"
                                                            >
                                                                <option value="">Sélectionner...</option>
                                                                @foreach($itemOptions as $key => $value)
                                                                    <option value="{{ $key }}">{{ $value }}</option>
                                                                @endforeach
                                                            </x-mt::form.select>
                                                        @endif

                                                        <!-- CHECKBOX -->
                                                        @if($itemType == 'checkbox')
                                                            <div class="flex items-center">
                                                                <input 
                                                                    type="checkbox" 
                                                                    wire:model="{{ $itemName }}"
                                                                    x-on:change="$dispatch('field-changed', { field: '{{ $field }}', value: $event.target.checked })"
                                                                    id="{{ $itemId }}"
                                                                    class="rounded mt-checkbox">
                                                                <label for="{{ $itemId }}" class="ml-2 text-sm mt-text">
                                                                    {{ $item['checkbox_label'] ?? $itemLabel }}
                                                                </label>
                                                            </div>
                                                        @endif

                                                        <!-- RADIO -->
                                                        @if($itemType == 'radio')
                                                            <div class="space-y-2">
                                                                @foreach($itemOptions as $key => $value)
                                                                    <div class="flex items-center">
                                                                        <input 
                                                                            type="radio" 
                                                                            wire:model="{{ $itemName }}"
                                                                            x-on:change="$dispatch('field-changed', { field: '{{ $field }}', value: '{{ $key }}' })"
                                                                            value="{{ $key }}"
                                                                            id="{{ $itemId }}_{{ $key }}"
                                                                            class="mt-radio">
                                                                        <label for="{{ $itemId }}_{{ $key }}" class="ml-2 text-sm mt-text">
                                                                            {{ $value }}
                                                                        </label>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        @endif

                                                        <!-- ICON PICKER -->
                                                        @if($itemType == 'icon-picker')
                                                            <div>
                                                                <x-mt::form.input-picker 
                                                                    :model="$itemName"
                                                                    :icon="$itemOldvalue" 
                                                                    pickerIcon="fa-solid fa-icons" 
                                                                    :help="$itemHelp"
                                                                    :error="$errors->first($itemName)"
                                                                    :invalid="$errors->has($itemName)"
                                                                    :required="$isRequired"
                                                                >
                                                                    @foreach(mt_icons() as $icon)
                                                                        <button type="button" @click="$wire.set('{{ $itemName }}', '{{ $icon }}'); open = false;">
                                                                            <i class="{{ $icon }}"></i>
                                                                        </button>
                                                                    @endforeach
                                                                </x-mt::form.input-picker>
                                                            </div>
                                                        @endif

                                                        <!-- COLOR PICKER -->
                                                        @if($itemType == 'color-picker')
                                                            <div>
                                                                <x-mt::form.input-picker 
                                                                    :model="$itemName"
                                                                    :color="$itemOldvalue"
                                                                    :help="$itemHelp"
                                                                    :error="$errors->first($itemName)"
                                                                    :invalid="$errors->has($itemName)"
                                                                    :required="$isRequired"
                                                                >
                                                                    @foreach(mt_colors() as $color)
                                                                        <button type="button" @click="$wire.set('{{ $itemName }}', '{{ $color }}'); open = false;"
                                                                            class="w-10 h-10 rounded-lg shadow-sm"
                                                                            style="background-color: {{ $color }}; border: 1px solid rgb(var(--mt-ui-card-border))">
                                                                        </button>
                                                                    @endforeach
                                                                </x-mt::form.input-picker>
                                                            </div>
                                                        @endif

                                                    </x-mt::form.fieldset>
                                                </div>
                                            @endforeach
                                        </div>
                                        
                                        @if(count($editorFields) > 0)
                                        <!-- EDITORS FIELDS -->
                                            <div class="grid grid-cols-1 gap-6 mt-4">
                                                @foreach($editorFields as $field => $item)
                                                    @php
                                                        $itemType = $item['type'] ?? '';
                                                        $itemId = 'input_'.$field;
                                                        $itemLabel = $item['label'] ?? '';
                                                        $itemName = "form.$field";
                                                        $itemOptions = $item['options'] ?? [];
                                                        $itemCol = $item['col'] ?? 12;
                                                        $isDisabledItem = $item['disabled'] ?? false;
                                                        $itemHelp = $item['help'] ?? null;
                                                        $isRequired = $this->isRequired($field);
                                                        $itemOldvalue = $form->{$field} ?? '';
                                                        $isMultilangualField = $item['multilingual'] ?? false;
                                                    @endphp

                                                    <div class="@if($itemCol==12) md:col-span-2 @else md:col-span-1 @endif space-y-2" 
                                                        wire:key="editor-field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                                        @if ($isMultilangualField) x-data="{ activeTab: 'fr' }" @endif>

                                                        <x-mt::form.fieldset>
                                                            <x-mt::form.label :value="$itemLabel" :required="$isRequired" :isMultilangualField="$isMultilangualField" :availableLocales="$availableLocales" />

                                                            @if ($isMultilangualField)
                                                                @foreach($availableLocales as $lang => $langOptions)
                                                                    @php
                                                                        $itemMultiLangEditorName = $itemName.'.'.$lang;
                                                                        $itemMultiLangEditorPlaceholder = $item['placeholder'] ?? "{$itemLabel} en {$langOptions['label']}";
                                                                    @endphp
                                                                    <div x-show="activeTab === '{{ $lang }}'" x-cloak>
                                                                        @if($itemType=='textarea')
                                                                            <x-mt::form.textarea
                                                                                wire:model="{{ $itemMultiLangEditorName }}"
                                                                                rows="auto"
                                                                                placeholder="{{ $itemMultiLangEditorPlaceholder }}"                         
                                                                                :help="$itemHelp"
                                                                                :error="$errors->first($itemName)"
                                                                                :invalid="$errors->has($itemName)"
                                                                                :required="$isRequired"
                                                                                
                                                                            />
                                                                        @endif
                                                                        @if($itemType=='editor')
                                                                            <x-mt::tinymce :model="$itemMultiLangEditorName" placeholder="{{ $itemMultiLangEditorPlaceholder}}">
                                                                                {!! $itemOldvalue ?? '' !!}
                                                                            </x-mt::tinymce>
                                                                        @endif
                                                                    </div>
                                                                @endforeach
                                                            @else
                                                                @if($itemType=='textarea')
                                                                    <x-mt::form.textarea
                                                                        wire:model="{{ $itemName }}"
                                                                        id="{{ $itemId }}"
                                                                        rows="auto"
                                                                        placeholder="{{ $item['placeholder'] ?? '' }}"
                                                                        :help="$itemHelp"
                                                                        :error="$errors->first($itemName)"
                                                                        :invalid="$errors->has($itemName)"
                                                                        :required="$isRequired"
                                                                        
                                                                    />
                                                                @endif
                                                                @if($itemType=='editor')
                                                                    <x-mt::tinymce :model="$itemName" placeholder="{{ $item['placeholder'] ?? '' }}">
                                                                        {!! $itemOldvalue ?? '' !!}
                                                                    </x-mt::tinymce>
                                                                @endif
                                                            @endif

                                                        </x-mt::form.fieldset>

                                                    </div>
                                                @endforeach
                                            </div>
                                        @endif
                                        
                                        <!-- FOOTER FIELDS -->
                                        @if(count($footerFields) > 0)
                                            <div class="grid grid-cols-1 gap-6 mt-5 md:grid-cols-6">
                                                @foreach($footerFields as $field => $item)
                                                    @php
                                                        $itemType = $item['type'] ?? '';
                                                        $itemId = 'input_'.$field;
                                                        $itemLabel = $item['label'] ?? '';
                                                        $itemName = "form.$field";
                                                        $itemOptions = $item['options'] ?? [];
                                                        $itemCol = $item['col'] ?? 12;
                                                        $isDisabledItem = $item['disabled'] ?? false;
                                                        $itemHelp = $item['help'] ?? null;
                                                        $isRequired = $this->isRequired($field);
                                                        $itemOldvalue = $form->{$field} ?? '';
                                                        $isMultilangualField = $item['multilingual'] ?? false;
                                                    @endphp

                                                    <div class="@if($itemCol==12) md:col-span-6
                                                        @elseif($itemCol==9) md:col-span-4
                                                        @elseif($itemCol==6) md:col-span-3
                                                        @elseif($itemCol==4) md:col-span-2
                                                        @elseif($itemCol==3) md:col-span-1
                                                        @else md:col-span-1 @endif space-y-2" 
                                                        wire:key="editor-field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                                        @if ($isMultilangualField) x-data="{ activeTab: 'fr' }" @endif>

                                                        <!-- TOGGLE -->
                                                        @if($itemType == 'toggle')
                                                            <div>
                                                                <x-mt::form.toggle
                                                                    label="{{ $itemLabel }}" 
                                                                    model="{{ $itemName }}"
                                                                    id="{{ $itemId }}" 
                                                                    :help="$itemHelp"
                                                                    :error="$errors->first($itemName)"
                                                                    :invalid="$errors->has($itemName)"
                                                                    :required="$isRequired"
                                                                />
                                                            </div>
                                                        @endif

                                                    </div>
                                                @endforeach
                                            </div>
                                        @endif

                                        <!-- Hidden Fields -->
                                        @foreach($hiddenFields as $field => $item)
                                            <input type="hidden" wire:model="form.{{ $field }}" wire:key="hidden-{{ $field }}-step-{{ $currentStep }}" />
                                        @endforeach
                                    </x-mt::form.fields>
                                </x-mt::form.step>

                            </div>

                            <div class="w-auto">
                                <!-- COLONNE DROITE : fichiers / modal-select -->
                                @if(count($fileFields) > 0)
                                <div>
                                    <div class="sticky top-6 rounded-xl" style="">
                                        <div class="space-y-6">
                                            @foreach($fileFields as $field => $item)
                                                @php
                                                    $itemType = $item['type'] ?? '';
                                                    $itemId = 'input_'.$field;
                                                    $itemLabel = $item['label'] ?? '';
                                                    $itemName = "form.$field";
                                                    $itemOptions = $item['options'] ?? [];
                                                    $itemCol = $item['col'] ?? 12;
                                                    $isDisabledItem = $item['disabled'] ?? false;
                                                    $itemHelp = $item['help'] ?? null;
                                                    $isRequired = $this->isRequired($field);
                                                    $itemOldvalue = $form->{$field} ?? $item['oldvalue'] ?? null;
                                                    $isFileField = in_array($itemType, ['image', 'images', 'file', 'video', 'document']);
                                                    $isMultiple = $itemType === 'images' || ($item['isMultiple'] ?? false);
                                                    $hasExistingFile = ($mode === 'edit') && !empty($itemOldvalue);
                                                @endphp

                                                <div wire:key="file-field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}" class="pt-3">

                                                    @if(in_array($itemType, ['image', 'images', 'video', 'document']))
                                                        @php
                                                            $isMultiple = $item['isMultiple'] ?? false;
                                                            $acceptMap = [
                                                                'image'    => 'image/*',
                                                                'images'   => 'image/*',
                                                                'video'    => 'video/*',
                                                                'document' => '.pdf,.doc,.docx,.xls,.xlsx,.txt',
                                                            ];
                                                            $accept = $acceptMap[$itemType] ?? '*/*';
                                                            $placeholderMap = [
                                                                'image'    => 'Ajouter une image...',
                                                                'images'   => 'Ajouter des images...',
                                                                'video'    => 'Ajouter une vidéo...',
                                                                'document' => 'Ajouter un document...',
                                                            ];
                                                            $placeholderText = $placeholderMap[$itemType] ?? 'Ajouter un fichier...';
                                                        @endphp

                                                        <x-mt::form.file-upload
                                                            :name="$itemName"
                                                            wire:model="{{ $itemName }}"
                                                            :item-type="$itemType"
                                                            :label="$itemLabel"
                                                            :help="$itemHelp"
                                                            :error="$errors->first($itemName)"
                                                            :invalid="$errors->has($itemName)"
                                                            :required="$isRequired"
                                                            :old-value="$itemOldvalue ?? null"
                                                            :placeholder="$placeholderText"
                                                            max-size="3"
                                                        />
                                                        
                                                    @endif

                                                    @if($itemType == 'image-legend')
                                                        <x-mt::form.textarea
                                                            wire:model="{{ $itemName }}"
                                                            rows="auto"
                                                            label="Légende de l'image"
                                                            placeholder="Entrez la légende de l'image"
                                                            :help="$itemHelp"
                                                            :error="$errors->first($itemName)"
                                                            :invalid="$errors->has($itemName)"
                                                            :required="$isRequired"                                                        
                                                        />
                                                    @endif

                                                    <!-- MODAL SELECT -->
                                                    @if(in_array($itemType, ['modal-select']))
                                                        @php
                                                            $selectMode = $item['selectMode'] ?? 'single';
                                                            $modalFields = $item['modalFields'] ?? [];
                                                            $modalDatas = $item['modalDatas'] ?? [];
                                                            $modelClass = $form->modelClass();
                                                        @endphp
                                                        <livewire:modals.entity-selector
                                                            :name="$field"
                                                            :modelClass="$modelClass"
                                                            :relationName="$item['name'] ?? ''"
                                                            :selectMode="$selectMode"
                                                            :label="$itemLabel"
                                                            :modalDatas="$modalDatas"
                                                            :modalFields="$modalFields"
                                                            wire:key="modal-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                                        />
                                                    @endif

                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>

                        <!-- BOUTONS D'ACTION -->
                        <x-slot name="actions">
                            <div class="flex flex-col w-full gap-4 sm:flex-row sm:items-center sm:justify-between @if(!$hasMultipleSteps) sm:justify-end @endif">
                                @if($hasMultipleSteps && $totalDisplayedSteps > 0)
                                <div class="flex gap-3">
                                    @if($currentStep > 1)
                                        <x-mt::button
                                            icon="chevron-left"
                                            type="button"
                                            :loading="'previousStep'"
                                            variant="outline"
                                            wire:click="previousStep"
                                            label="Précédent"
                                        />
                                    @endif
                                    
                                    @if($currentStep < $totalDisplayedSteps)
                                        <x-mt::button
                                            endIcon="chevron-right"
                                            type="button"
                                            :loading="'nextStep'"
                                            variant="outline"
                                            wire:click="nextStep"
                                            label="Suivant"
                                        />
                                    @endif
                                </div>
                                @endif

                                <!-- Boutons d'action -->
                                <div class="flex justify-end gap-3">
                                    <x-mt::button
                                        icon="x"
                                        href="{{ route($this->getRedirectRouteName()) ?? route('dashboard') }}"
                                        variant="danger"
                                        class="mt-btn-outline-danger"
                                        label="Annuler"
                                    />
                                        
                                    @if($hasMultipleSteps && $totalDisplayedSteps > 0 && $currentStep < $totalDisplayedSteps)
                                        <x-mt::button
                                            icon="disk"
                                            type="button"
                                            :loading="'saveAndContinue'"
                                            variant="primary"
                                            wire:click="saveAndContinue"
                                            label="Enregistrer et continuer"
                                        />
                                    @else
                                        <x-mt::button
                                            icon="{{ $mode === 'edit' ? 'pencil' : 'disk' }}"
                                            type="button"
                                            :loading="'save'"
                                            wire:click="save"
                                            variant="success"                                            
                                            label="{{ $mode === 'edit' ? 'Modifier' : 'Enregistrer' }}"
                                        />
                                    @endif
                                </div>
                            </div>
                        </x-slot>
                    </x-mt::form>
                </div>

                {{-- Colonne aide (cachée) --}}
                <div class="hidden space-6">
                    <div class="sticky top-6 rounded-xl" style="border: 1px solid rgb(var(--mt-ui-card-border))">
                        <div class="p-6 shadow-xl rounded-3xl mt-bg-primary" style="color: #fff">
                            <h3 class="mb-2 text-lg font-bold">Besoin d'aide ?</h3>
                            <p class="mb-4 text-sm" style="opacity: 0.8">Consultez notre guide de configuration pour optimiser votre profil.</p>
                            <x-mt::button variant="secondary" size="sm" class="w-full">
                                Lire le guide
                            </x-mt::button>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    {{-- <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('formActions', (fieldActions = {}) => ({
                fieldValues: {},
                currentActions: fieldActions,
                
                init() {
                    this.$el.addEventListener('field-changed', (e) => {
                        this.onFieldChanged(e.detail.field, e.detail.value);
                    });
                    this.$watch('$wire.form', (formData) => {
                        this.fieldValues = formData;
                        this.updateFieldVisibility();
                    }, { deep: true });
                    if (this.$wire.form) { this.fieldValues = this.$wire.form; }
                    this.updateFieldVisibility();
                },
                
                onFieldChanged(field, value) {
                    if (field.startsWith('form.')) { field = field.replace('form.', ''); }
                    this.fieldValues[field] = value;
                    this.executeFieldActions(field, value);
                    this.updateFieldVisibility();
                },
                
                executeFieldActions(field, value) {
                    const actions = this.currentActions[field] || [];
                    actions.forEach((action, index) => { this.executeAction(action, field, value); });
                },
                
                executeAction(action, field, value) {
                    const type = action.type || 'set';
                    const target = action.target;
                    if (!target) { console.warn('Action sans target:', action); return; }
                    switch(type) {
                        case 'set':     if (action.value !== undefined) { this.setFieldValue(target, action.value); } break;
                        case 'map':     if (action.map && action.map[value] !== undefined) { this.setFieldValue(target, action.map[value]); } break;
                        case 'clear':   this.setFieldValue(target, null); break;
                        case 'copy':    this.setFieldValue(target, value); break;
                        case 'show_if':
                        case 'hide_if': break;
                        case 'enable_if':  this.toggleFieldDisabled(target, !this.evaluateCondition(action.condition, value)); break;
                        case 'disable_if': this.toggleFieldDisabled(target, this.evaluateCondition(action.condition, value)); break;
                        default: console.warn(`Type d'action inconnu: ${type}`);
                    }
                },
                
                setFieldValue(field, value) {
                    this.$wire.set(`form.${field}`, value);
                    this.fieldValues[field] = value;
                    this.highlightField(field);
                    this.$wire.$commit();
                },
                
                toggleFieldDisabled(field, disabled) {
                    const selectors = [
                        `select[name="form.${field}"]`, `select[wire\\:model="form.${field}"]`,
                        `input[name="form.${field}"]`,  `input[wire\\:model="form.${field}"]`,
                        `textarea[name="form.${field}"]`, `textarea[wire\\:model="form.${field}"]`
                    ];
                    selectors.forEach(selector => {
                        document.querySelectorAll(selector).forEach(input => {
                            input.disabled = disabled;
                            input.classList.toggle('opacity-50', disabled);
                            input.classList.toggle('cursor-not-allowed', disabled);
                        });
                    });
                },
                
                updateFieldVisibility() {
                    Object.entries(this.currentActions).forEach(([sourceField, actions]) => {
                        const sourceValue = this.fieldValues[sourceField];
                        actions.forEach(action => {
                            if (action.type === 'show_if' || action.type === 'hide_if') {
                                const shouldShow = this.evaluateCondition(action.condition, sourceValue);
                                const element = document.querySelector(`[data-field="${action.target}"]`);
                                if (element) {
                                    const isHidden = element.classList.contains('hidden');
                                    const shouldBeHidden = action.type === 'show_if' ? !shouldShow : shouldShow;
                                    if (shouldBeHidden !== isHidden) {
                                        element.classList.toggle('hidden', shouldBeHidden);
                                        if (!shouldBeHidden) { this.animateFieldAppearance(element); }
                                    }
                                }
                            }
                        });
                    });
                },
                
                evaluateCondition(condition, value) {
                    if (condition === undefined) return true;
                    if (!Array.isArray(condition) && typeof condition !== 'object' && typeof condition !== 'function') return value == condition;
                    if (Array.isArray(condition)) return condition.includes(value);
                    if (typeof condition === 'object') {
                        const operator = condition.operator || 'equals';
                        const compareValue = condition.value;
                        switch(operator) {
                            case 'equals':      return value == compareValue;
                            case 'not_equals':  return value != compareValue;
                            case 'greater_than':return value > compareValue;
                            case 'less_than':   return value < compareValue;
                            case 'contains':    return String(value).includes(compareValue);
                            case 'starts_with': return String(value).startsWith(compareValue);
                            case 'ends_with':   return String(value).endsWith(compareValue);
                            case 'empty':       return !value;
                            case 'not_empty':   return !!value;
                            default:            return false;
                        }
                    }
                    return false;
                },
                
                highlightField(field) {
                    const element = document.querySelector(`[data-field="${field}"]`);
                    if (element) {
                        element.style.outline = `2px solid rgba(var(--mt-primary), 0.5)`;
                        setTimeout(() => { element.style.outline = ''; }, 1000);
                    }
                },
                
                animateFieldAppearance(element) {
                    element.classList.add('opacity-0', 'translate-y-2');
                    setTimeout(() => { element.classList.remove('opacity-0', 'translate-y-2'); }, 10);
                }
            }));
        });
    </script> --}}
</div>
