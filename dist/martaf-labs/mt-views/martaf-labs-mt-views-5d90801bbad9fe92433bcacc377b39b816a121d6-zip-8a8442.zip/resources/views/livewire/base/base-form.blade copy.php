<div  x-data="formActions(@js($this->fieldActions()))">
    @php
        // Récupérer les champs à afficher pour l'étape actuelle
        $displayFields = $this->getFieldsToDisplay() ?? [];
        $allSchema = $schema ?? [];

        // Organiser les champs par type
        $fileFields = [];
        $editorFields = [];
        $hiddenFields = [];
        $otherFields = [];
        $footerFields = [];
        
        foreach ($displayFields as $key => $item) {
            $type = $item['type'] ?? 'text';
            if (in_array($type, ['image','images','file','video','document','modal-select'])) {
                $fileFields[$key] = $item;
            } elseif (in_array($type, ['editor','textarea'])) {
                $editorFields[$key] = $item;
            } elseif (in_array($type, ['toggle'])) {
                $footerFields[$key] = $item;
            } elseif ($type === 'hidden') {
                $hiddenFields[$key] = $item;
            } else {
                $otherFields[$key] = $item;
            }
        }
        
        $availableLocales = config('app.available_locales');
        $codesLangues = ['fr' => 'Français', 'ar' => 'العربية', 'en' => 'Anglais'];
        $isEdit = $mode == 'edit';
        
        // Gestion des étapes
        $hasMultipleSteps = $this->hasMultipleSteps();
        $stepsToDisplay = $this->getStepsToDisplay();
        $totalDisplayedSteps = count($stepsToDisplay);
        
        // Trouver l'étape réelle correspondant à l'étape virtuelle actuelle
        $currentRealStep = null;
        if ($hasMultipleSteps && isset($stepsToDisplay[$currentStep])) {
            $currentRealStep = $stepsToDisplay[$currentStep]['realStep'] ?? $currentStep;
        }

        $hasActions = !empty($this->fieldActions());

    @endphp

    <!-- Overlay sauvegarde -->
    @if($isSubmitting)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-white/80 dark:bg-zinc-800/80">
        <div class="text-center">
            <div class="w-12 h-12 mx-auto mb-4 border-b-2 border-blue-600 rounded-full animate-spin"></div>
            <p class="font-semibold text-zinc-600 dark:text-zinc-400">Sauvegarde en cours...</p>
        </div>
    </div>
    @endif

    <div class="min-h-screen py-6 bg-zinc-50 dark:bg-zinc-800">
        <div class="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
            <x-mt::breadcrumbs :title="$title" :datas="$this->navItems() ?? []" />

            @if (session()->has('success'))
            <div class="p-4 mb-6 border border-green-200 rounded-lg bg-green-50 dark:bg-green-900/30 dark:border-green-800">
                <div class="flex items-center gap-3">
                    <i class="text-green-600 bi bi-check-circle dark:text-green-400"></i>
                    <span class="text-green-800 dark:text-green-300">{{ session('success') }}</span>
                </div>
            </div>
            @endif

            @if (session()->has('error'))
            <div class="p-4 mb-6 border border-red-200 rounded-lg bg-red-50 dark:bg-red-900/30 dark:border-red-800">
                <div class="flex items-center gap-3">
                    <i class="text-red-600 bi bi-exclamation-triangle dark:text-red-400"></i>
                    <span class="text-red-800 dark:text-red-300">{{ session('error') }}</span>
                </div>
            </div>
            @endif

            <!-- Barre de progression (uniquement pour multi-step avec étapes affichées) -->
            @if($hasMultipleSteps && $totalDisplayedSteps > 0)
            <div class="p-6 mb-6 bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700"
                 x-data x-on:steps-updated.window="$nextTick(() => { $el.scrollIntoView({ behavior: 'smooth', block: 'start' }); })">
                
                <!-- Barre de progression linéaire -->
                <div class="mb-6">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm font-medium text-zinc-700 dark:text-zinc-300">
                            Progression : {{ $this->getProgressPercentage() }}%
                        </span>
                        <span class="text-sm font-medium text-zinc-600 dark:text-zinc-400">
                            Étape {{ $currentStep }} sur {{ $totalDisplayedSteps }}
                        </span>
                    </div>
                    <div class="w-full h-2 overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-700">
                        <div 
                            class="h-full transition-all duration-500 ease-out bg-blue-600 rounded-full" 
                            style="width: {{ $this->getProgressPercentage() }}%">
                        </div>
                    </div>
                </div>

                <!-- Étapes -->
                <div class="flex flex-wrap justify-between gap-4">
                    @foreach($stepsToDisplay as $virtualStep => $stepConfig)
                        @php
                            $realStep = $stepConfig['realStep'] ?? $virtualStep;
                            $isAvailable = $this->stepCondition($realStep);
                            $isActive = $this->isStepActive($virtualStep);
                            $isCompleted = $this->isStepCompleted($virtualStep);
                        @endphp

                        <button
                            type="button"
                            wire:click="goToStep({{ $virtualStep }})"
                            @if(!$isAvailable) disabled @endif
                            @class([
                                'flex-1 min-w-[120px] flex flex-col items-center p-4 rounded-lg transition-all duration-300 relative',
                                'bg-blue-50 dark:bg-blue-900/30 border-2 border-blue-500 shadow-md' => $isActive,
                                'bg-white dark:bg-zinc-700 border-2 border-zinc-300 dark:border-zinc-600' => !$isActive && $isCompleted,
                                'bg-zinc-50 dark:bg-zinc-800 border-2 border-zinc-200 dark:border-zinc-700 hover:border-zinc-300 dark:hover:border-zinc-600' => !$isActive && !$isCompleted && $isAvailable,
                                'bg-zinc-100 dark:bg-zinc-900 border-2 border-zinc-300 dark:border-zinc-700 opacity-40 cursor-not-allowed' => !$isAvailable,
                            ])
                            wire:key="step-button-{{ $virtualStep }}-{{ $realStep }}-{{ $isAvailable ? 'available' : 'unavailable' }}"
                        >
                            <!-- Icône de verrou si non disponible -->
                            @if(!$isAvailable)
                            <div class="absolute -top-1 -right-1">
                                <i class="text-xs text-zinc-500 bi bi-lock"></i>
                            </div>
                            @endif

                            <!-- Numéro/icône de l'étape -->
                            <div class="flex items-center justify-center w-10 h-10 mb-3 rounded-full"
                                @class([
                                    'bg-blue-100 dark:bg-blue-800 text-blue-600 dark:text-blue-300' => $isActive,
                                    'bg-green-100 dark:bg-green-800 text-green-600 dark:text-green-300' => $isCompleted,
                                    'bg-zinc-100 dark:bg-zinc-700 text-zinc-500 dark:text-zinc-400' => !$isActive && !$isCompleted && $isAvailable,
                                    'bg-zinc-200 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-600' => !$isAvailable,
                                ])>
                                @if($isCompleted && !$isActive)
                                    <i class="text-lg bi bi-check-lg"></i>
                                @else
                                    <span class="font-bold">{{ $virtualStep }}</span>
                                @endif
                            </div>
                            
                            <!-- Titre -->
                            <span class="text-sm font-medium text-center"
                                @class([
                                    'text-blue-700 dark:text-blue-300' => $isActive,
                                    'text-green-700 dark:text-green-300' => $isCompleted && !$isActive,
                                    'text-zinc-600 dark:text-zinc-400' => !$isActive && !$isCompleted && $isAvailable,
                                    'text-zinc-400 dark:text-zinc-600' => !$isAvailable,
                                ])>
                                {{ $stepConfig['title'] }}
                            </span>
                        </button>
                    @endforeach
                </div>
            </div>

            <!-- Titre de l'étape actuelle -->
            @if(isset($stepsToDisplay[$currentStep]))
            <div class="p-6 mb-6 bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                <h2 class="text-2xl font-bold text-zinc-800 dark:text-white">
                    <i class="bi bi-{{ $stepsToDisplay[$currentStep]['icon'] ?? 'circle' }} mr-2"></i>
                    {{ $stepsToDisplay[$currentStep]['title'] }}
                </h2>
                @if(isset($stepsToDisplay[$currentStep]['description']))
                    <p class="mt-2 text-zinc-600 dark:text-zinc-400">
                        {{ $stepsToDisplay[$currentStep]['description'] }}
                    </p>
                @endif
                
                <!-- Avertissement si l'étape n'est pas disponible mais affichée -->
                @if(!$this->stepCondition($currentRealStep))
                <div class="p-3 mt-4 border border-yellow-200 rounded-lg bg-yellow-50 dark:bg-yellow-900/30 dark:border-yellow-800">
                    <div class="flex items-center gap-2">
                        <i class="text-yellow-600 bi bi-exclamation-triangle dark:text-yellow-400"></i>
                        <span class="text-yellow-800 dark:text-yellow-300">
                            Cette étape n'est plus disponible avec les données actuelles.
                        </span>
                    </div>
                </div>
                @endif
            </div>
            @endif
            @endif

            <x-mt::form.form-container submit="save" loadingTarget="save"  x-data="{ showErrors: false }" 
                  x-on:validation-failed.window="showErrors = true; $nextTick(() => { $el.scrollIntoView({ behavior: 'smooth', block: 'start' }); })">
                @csrf
                @if($mode === 'edit') @method('PUT') @endif

                <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
                    <!-- COLONNE GAUCHE -->
                    <div class="grid grid-cols-1 p-6 bg-white border shadow-sm lg:col-span-2 dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700" 
                         data-step-container
                         x-data x-on:step-changed.window="$el.scrollIntoView({ behavior: 'smooth', block: 'start' })">
                        
                            <flux:fieldset>
                                <div class="grid grid-cols-1 gap-6 md:grid-cols-6">
                                    @foreach($otherFields as $field => $item)
                                        @php
                                            $itemType = $item['type'] ?? '';
                                            $itemId = 'input_'.$field;
                                            $itemLabel = $item['label'] ?? '';
                                            $itemName = "form.$field";
                                            $itemOptions = $item['options'] ?? [];
                                            $itemCol = $item['col'] ?? 12;
                                            $isDisabledItem = $item['disabled'] ?? false;
                                            $itemHelp = $item['help'] ?? null;
                                            $isRequired = $this->isRequired($field);
                                            $itemOldvalue = $form->{$field} ?? '';
                                            $isMultilangualField = $item['multilingual'] ?? false;
                                        @endphp

                                        <div class="@if($itemCol==12) md:col-span-6
                                                @elseif($itemCol==9) md:col-span-4
                                                @elseif($itemCol==6) md:col-span-3
                                                @elseif($itemCol==4) md:col-span-2
                                                @elseif($itemCol==3) md:col-span-1
                                                @else md:col-span-1 @endif"
                                            wire:key="field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                            @if ($isMultilangualField) x-data="{ activeTab: 'fr' }" @endif>

                                            <flux:field>

                                                @if(!in_array($itemType,['toggle']))
                                                <flux:label>
                                                    <strong>{{ $itemLabel }}</strong>
                                                    @if($isRequired)<span class="font-bold text-red-500 ps-1">*</span>@endif

                                                     @if($hasActions)
                                                    <span class="ml-2 text-xs text-blue-500" title="Ce champ a des actions associées">
                                                        <i class="bi bi-arrow-right-circle"></i>
                                                    </span>
                                                    @endif

                                                    @if($isMultilangualField)
                                                        <nav class="flex -mb-px space-x-2 overflow-x-auto ms-3">
                                                            @foreach($availableLocales as $langCode)
                                                                @php
                                                                    $isMultilingualFieldRequired = $this->isRequired($field.'.'.$langCode);
                                                                @endphp
                                                                <button
                                                                    type="button"
                                                                    @click="activeTab = '{{ $langCode }}'"
                                                                    class="px-1 py-1 text-sm font-medium transition-colors duration-200 border-b-2 whitespace-nowrap rounded-t-md"
                                                                    :class="{
                                                                        'border-primary-500 text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/20': activeTab === '{{ $langCode }}',
                                                                        'border-transparent text-zinc-500 hover:text-zinc-700 hover:border-zinc-300 dark:text-zinc-400 dark:hover:text-zinc-300': activeTab !== '{{ $langCode }}'
                                                                    }"
                                                                >
                                                                    {{ $langCode }}
                                                                    @if($isMultilingualFieldRequired)<span class="font-medium text-red-500 ps-1/2">*</span>@endif
                                                                </button>
                                                            @endforeach
                                                        </nav>
                                                    @endif
                                                </flux:label>
                                                @endif

                                                @if(in_array($itemType,['text','email','password','tel','number','float','date','datetime']))
                                                    @php
                                                        $inputType = $itemType;

                                                        switch ($itemType) {
                                                            case 'float':
                                                                $inputType = 'number';
                                                                break;
                                                            case 'datetime':
                                                                $inputType = 'datetime-local';
                                                                break;
                                                            default:
                                                                $inputType = $itemType;
                                                                break;
                                                        }

                                                        $step = $itemType==='float' ? '0.01' : null;
                                                    @endphp

                                                    @if ($isMultilangualField)
                                                        @foreach ($availableLocales as $lang)
                                                            @php
                                                                $itemMultiLangName = $itemName.'.'.$lang;
                                                                $itemMultiLangPlaceholder = $item['placeholder'] ?? "{$itemLabel} en {$codesLangues[$lang]}";
                                                            @endphp

                                                            <div x-show="activeTab === '{{ $lang }}'" x-cloak>
                                                                <flux:input type="{{ $inputType }}"
                                                                    wire:model="{{ $itemMultiLangName }}"
                                                                    x-on:change.debounce.300ms="$dispatch('field-changed', { 
                                                                        field: '{{ $field }}.{{ $lang }}', 
                                                                        value: $event.target.value 
                                                                    })"
                                                                    placeholder="{{ $itemMultiLangPlaceholder }}"
                                                                    :invalid="$errors->has($itemMultiLangName)"
                                                                    :required="$isRequired" />
                                                            </div>
                                                        @endforeach
                                                    @else
                                                        <x-mt::form.input 
                                                            :type="$inputType"
                                                            wire:model="{{ $itemName }}"
                                                             x-on:change.debounce.300ms="$dispatch('field-changed', { 
                                                                field: '{{ $field }}', 
                                                                value: $event.target.value 
                                                            })"
                                                            placeholder="{{ $item['placeholder'] ?? $itemLabel }}"
                                                            {{-- :invalid="$errors->has($itemName)" --}}
                                                             />
                                                    @endif
                                                @endif

                                                @if($itemType=='select')

                                                    <x-mt::form.select 
                                                        {{-- label="Pays"  --}}
                                                        wire:model="{{ $itemName }}" 
                                                        id="{{ $itemId }}"
                                                        {{-- :error="$errors->first($itemName)" --}}
                                                    >
                                                        <option value="">Sélectionner...</option>
                                                        @foreach($itemOptions as $key => $value)
                                                            <option value="{{ $key }}">{{ $value }}</option>
                                                        @endforeach
                                                    </x-mt::form.select>
                                                            
                                                    {{-- <flux:select 
                                                        wire:model="{{ $itemName }}" 
                                                        id="{{ $itemId }}"
                                                        x-on:change="$dispatch('field-changed', { 
                                                            field: '{{ $field }}', 
                                                            value: $event.target.value 
                                                        })"
                                                        :disabled="$isDisabledItem" 
                                                        :invalid="$errors->has($itemName)" 
                                                        :required="$isRequired">
                                                        <option value="">Sélectionner...</option>
                                                        @foreach($itemOptions as $key => $value)
                                                            <option value="{{ $key }}">{{ $value }}</option>
                                                        @endforeach
                                                    </flux:select> --}}
                                                @endif

                                                 <!-- CHECKBOX -->
                                                @if($itemType == 'checkbox')
                                                    <div class="flex items-center">
                                                        <input 
                                                            type="checkbox" 
                                                            wire:model="{{ $itemName }}"
                                                            x-on:change="$dispatch('field-changed', { 
                                                                field: '{{ $field }}', 
                                                                value: $event.target.checked 
                                                            })"
                                                            id="{{ $itemId }}"
                                                            class="w-4 h-4 text-blue-600 rounded border-zinc-300 focus:ring-blue-500">
                                                        <label for="{{ $itemId }}" class="ml-2 text-sm text-zinc-700 dark:text-zinc-300">
                                                            {{ $item['checkbox_label'] ?? $itemLabel }}
                                                        </label>
                                                    </div>
                                                @endif

                                                <!-- RADIO -->
                                                @if($itemType == 'radio')
                                                    <div class="space-y-2">
                                                        @foreach($itemOptions as $key => $value)
                                                            <div class="flex items-center">
                                                                <input 
                                                                    type="radio" 
                                                                    wire:model="{{ $itemName }}"
                                                                    x-on:change="$dispatch('field-changed', { 
                                                                        field: '{{ $field }}', 
                                                                        value: '{{ $key }}' 
                                                                    })"
                                                                    value="{{ $key }}"
                                                                    id="{{ $itemId }}_{{ $key }}"
                                                                    class="w-4 h-4 text-blue-600 border-zinc-300 focus:ring-blue-500">
                                                                <label for="{{ $itemId }}_{{ $key }}" class="ml-2 text-sm text-zinc-700 dark:text-zinc-300">
                                                                    {{ $value }}
                                                                </label>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                @endif
                                                

                                                <!-- ICON -->
                                                @if($itemType == 'icon-picker')
                                                    <div class="">
                                                        
                                                        <x-mt::form.input-picker 
                                                            :model="$itemName"
                                                            :icon="$itemOldvalue" 
                                                            pickerIcon="fa-solid fa-icons" 
                                                            {{-- help="Choisissez une icône" --}}
                                                            :error="$errors->first($itemName)"
                                                        >
                                                            @foreach(mtIcons() as $icon)
                                                                <button type="button" @click="$wire.set('{{ $itemName }}', '{{ $icon }}'); open = false;">
                                                                    <i class="{{ $icon }}"></i>
                                                                </button>
                                                            @endforeach
                                                        </x-mt::form.input-picker>
                                                        
                                                    </div>
                                                @endif

                                                <!-- COLOR -->
                                                @if($itemType == 'color-picker')
                                                    <div class="">
                                                        <x-mt::form.input-picker 
                                                            :model="$itemName"
                                                            :color="$itemOldvalue"
                                                            {{-- help="Choisissez une couleur" --}}
                                                            :error="$errors->first($itemName)"
                                                        >
                                                            @foreach(mtColors() as $color)
                                                                <button type="button" @click="$wire.set('{{ $itemName }}', '{{ $color }}'); open = false;" class="w-10 h-10 border-white rounded-lg shadow-sm border-1 dark:border-zinc-500" style="background-color: {{ $color }}">
                                                                </button>
                                                            @endforeach
                                                        </x-mt::form.input-picker>
                                                        
                                                    </div>
                                                @endif

                                                <!-- MESSAGE D'AIDE -->
                                                @if($itemHelp)
                                                    <flux:description> {{ $itemHelp }} </flux:description>
                                                @endif

                                                <!-- MESSAGE D'ERREUR -->
                                                @error($itemName)
                                                    <flux:error name="{{ $itemName }}" />
                                                @enderror

                                            </flux:field>
                                        </div>
                                    @endforeach
                                </div>
                                
                                @if(count($editorFields) > 0)
                                <!-- EDITORS FIELDS -->
                                    <div class="grid grid-cols-1 gap-6 mt-4">
                                        @foreach($editorFields as $field => $item)
                                            @php
                                                $itemType = $item['type'] ?? '';
                                                $itemId = 'input_'.$field;
                                                $itemLabel = $item['label'] ?? '';
                                                $itemName = "form.$field";
                                                $itemOptions = $item['options'] ?? [];
                                                $itemCol = $item['col'] ?? 12;
                                                $isDisabledItem = $item['disabled'] ?? false;
                                                $itemHelp = $item['help'] ?? null;
                                                $isRequired = $this->isRequired($field);
                                                $itemOldvalue = $form->{$field} ?? '';
                                                $isMultilangualField = $item['multilingual'] ?? false;
                                            @endphp

                                            <div class="@if($itemCol==12) md:col-span-2 @else md:col-span-1 @endif space-y-2" 
                                                 wire:key="editor-field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                                 @if ($isMultilangualField) x-data="{ activeTab: 'fr' }" @endif>

                                                <flux:field>
                                                    <flux:label>
                                                        <strong>{{ $itemLabel }}</strong>
                                                        @if($isRequired)<span class="font-bold text-red-500 ps-1">*</span>@endif

                                                        @if($isMultilangualField)
                                                            <nav class="flex -mb-px space-x-2 overflow-x-auto ms-3">
                                                                @foreach($availableLocales as $langCode)

                                                                    @php
                                                                        $isMultilingualFieldRequired = $this->isRequired($field.'.'.$langCode);
                                                                    @endphp

                                                                    <button
                                                                        type="button"
                                                                        @click="activeTab = '{{ $langCode }}'"
                                                                        class="px-1 py-1 text-sm font-medium transition-colors duration-200 border-b-2 whitespace-nowrap rounded-t-md"
                                                                        :class="{
                                                                            'border-primary-500 text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/20': activeTab === '{{ $langCode }}',
                                                                            'border-transparent text-zinc-500 hover:text-zinc-700 hover:border-zinc-300 dark:text-zinc-400 dark:hover:text-zinc-300': activeTab !== '{{ $langCode }}'
                                                                        }"
                                                                    >
                                                                        {{ $langCode }}
                                                                        @if($isMultilingualFieldRequired)<span class="font-medium text-red-500 ps-1/2">*</span>@endif
                                                                    </button>
                                                                @endforeach
                                                            </nav>
                                                        @endif
                                                    </flux:label>

                                                    @if ($isMultilangualField)
                                                        @foreach ($availableLocales as $lang)
                                                            @php
                                                                $itemMultiLangEditorName = $itemName.'.'.$lang;
                                                                $itemMultiLangEditorPlaceholder = $item['placeholder'] ?? "{$itemLabel} en {$codesLangues[$lang]}";
                                                            @endphp

                                                            <div x-show="activeTab === '{{ $lang }}'" x-cloak>
                                                                @if($itemType=='textarea')
                                                                    <x-mt::form.textarea
                                                                        wire:model="{{ $itemMultiLangEditorName }}"
                                                                        rows="auto"
                                                                        placeholder="{{ $itemMultiLangEditorPlaceholder }}"
                                                                        style="overflow:hidden; min-height:300px;"
                                                                    />
                                                                @endif

                                                                @if($itemType=='editor')
                                                                    <x-tinymce :model="$itemMultiLangEditorName" placeholder="{{ $itemMultiLangEditorPlaceholder}}">
                                                                        {!! $itemOldvalue ?? '' !!}
                                                                    </x-tinymce>
                                                                @endif
                                                            </div>
                                                        @endforeach
                                                    @else
                                                        @if($itemType=='textarea')
                                                            <x-mt::form.textarea
                                                                wire:model="{{ $itemName }}"
                                                                id="{{ $itemId }}"
                                                                rows="auto"
                                                                placeholder="{{ $item['placeholder'] ?? '' }}"
                                                                style="overflow:hidden; min-height:10px;"
                                                            />
                                                        @endif

                                                        @if($itemType=='editor')
                                                            <x-tinymce :model="$itemName" placeholder="{{ $item['placeholder'] ?? '' }}">
                                                                {!! $itemOldvalue ?? '' !!}
                                                            </x-tinymce>
                                                        @endif
                                                    @endif

                                                </flux:field>

                                                <!-- MESSAGE D'AIDE -->
                                                @if($itemHelp)
                                                    <flux:description> {{ $itemHelp }} </flux:description>
                                                @endif

                                                <!-- MESSAGE D'ERREUR -->
                                                @error($itemName)
                                                    <flux:error name="{{ $itemName }}" />
                                                @enderror

                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                                
                                <!-- FOOTER FIELDS -->
                                @if(count($footerFields) > 0)
                                    <div class="grid grid-cols-1 gap-6 mt-5 md:grid-cols-6">
                                        @foreach($footerFields as $field => $item)
                                            @php
                                                $itemType = $item['type'] ?? '';
                                                $itemId = 'input_'.$field;
                                                $itemLabel = $item['label'] ?? '';
                                                $itemName = "form.$field";
                                                $itemOptions = $item['options'] ?? [];
                                                $itemCol = $item['col'] ?? 12;
                                                $isDisabledItem = $item['disabled'] ?? false;
                                                $itemHelp = $item['help'] ?? null;
                                                $isRequired = $this->isRequired($field);
                                                $itemOldvalue = $form->{$field} ?? '';
                                                $isMultilangualField = $item['multilingual'] ?? false;
                                            @endphp

                                            <div class="@if($itemCol==12) md:col-span-6
                                                @elseif($itemCol==9) md:col-span-4
                                                @elseif($itemCol==6) md:col-span-3
                                                @elseif($itemCol==4) md:col-span-2
                                                @elseif($itemCol==3) md:col-span-1
                                                @else md:col-span-1 @endif space-y-2" 
                                                 wire:key="editor-field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                                 @if ($isMultilangualField) x-data="{ activeTab: 'fr' }" @endif>

                                                <!-- TOGGLE -->
                                                @if($itemType == 'toggle')
                                                    <div class="">
                                                        <x-mt::form.toggle
                                                            label="{{ $itemLabel }}" 
                                                            model="{{ $itemName }}"
                                                            id="{{ $itemId }}"
                                                        />
                                                    </div>
                                                @endif


                                                <!-- MESSAGE D'AIDE -->
                                                @if($itemHelp)
                                                    <flux:description> {{ $itemHelp }} </flux:description>
                                                @endif

                                                <!-- MESSAGE D'ERREUR -->
                                                @error($itemName)
                                                    <flux:error name="{{ $itemName }}" />
                                                @enderror

                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                            </flux:fieldset>

                        <!-- Hidden Fields -->
                        @foreach($hiddenFields as $field => $item)
                            <input type="hidden" wire:model="form.{{ $field }}" wire:key="hidden-{{ $field }}-step-{{ $currentStep }}" />
                        @endforeach
                    </div>

                    <!-- COLONNE DROITE : fichiers / modal-select -->
                    @if(count($fileFields) > 0)
                        <div>
                            <div class="sticky bg-white shadow-sm top-6 dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                                <div class="space-y-6">
                                    @foreach($fileFields as $field => $item)
                                        @php
                                            $itemType = $item['type'] ?? '';
                                            $itemId = 'input_'.$field;
                                            $itemLabel = $item['label'] ?? '';
                                            $itemName = "form.$field";
                                            $itemOptions = $item['options'] ?? [];
                                            $itemCol = $item['col'] ?? 12;
                                            $isDisabledItem = $item['disabled'] ?? false;
                                            $itemHelp = $item['help'] ?? null;
                                            $isRequired = $this->isRequired($field);
                                            $itemOldvalue = $form->{$field} ?? '';
                                            $isFileField = in_array($itemType, ['image', 'images', 'file', 'video', 'document']);
                                            $isMultiple = $itemType === 'images' || ($item['isMultiple'] ?? false);
                                            $hasExistingFile = ($mode === 'edit') && !empty($itemOldvalue);
                                        @endphp

                                        <div wire:key="file-field-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}" class="p-3 space-y-3">

                                            <!-- UPLOAD IMAGE, VIDEO, DOCUMENT -->
                                            @if( in_array($itemType, ['image', 'images', 'video', 'document']))
                                                @php
                                                    $isMultiple = $item['isMultiple'] ?? false;
                                                    $acceptMap = [
                                                        'image' => 'image/*',
                                                        'images' => 'image/*',
                                                        'video' => 'video/*',
                                                        'document' => '.pdf,.doc,.docx,.xls,.xlsx,.txt',
                                                    ];
                                                    $accept = $acceptMap[$itemType] ?? '*/*';

                                                    $placeholderMap = [
                                                        'image' => 'Ajouter une image...',
                                                        'images' => 'Ajouter des images...',
                                                        'video' => 'Ajouter une vidéo...',
                                                        'document' => 'Ajouter un document...',
                                                    ];
                                                    $placeholderText = $placeholderMap[$itemType] ?? 'Ajouter un fichier...';
                                                @endphp

                                                <label for="{{ $itemId }}" class="block text-sm font-medium text-zinc-700 dark:text-zinc-300">
                                                    {{ $itemLabel }}
                                                    @if($isRequired) <span class="text-red-500 ps-1">*</span> @endif
                                                </label>

                                                <div
                                                    x-data="{
                                                        previews: @js($hasExistingFile ? [
                                                            [
                                                                'type' => str_contains($itemType, 'image') ? 'image' : 'file',
                                                                'url' => str_contains($itemType, 'image') ? asset("storage/$itemOldvalue") : null,
                                                                'name' => basename($itemOldvalue)
                                                            ]
                                                        ] : []),
                                                        isUploading: false,
                                                        fileChosen(event) {
                                                            const files = Array.from(event.target.files);
                                                            const newPreviews = files.map(file => {
                                                                return file.type.startsWith('image/')
                                                                    ? { type: 'image', url: URL.createObjectURL(file), name: file.name }
                                                                    : { type: 'file', url: null, name: file.name };
                                                            });

                                                            @if($isMultiple)
                                                                this.previews = [...this.previews, ...newPreviews];
                                                            @else
                                                                this.previews = newPreviews;
                                                            @endif
                                                        },
                                                        removePreview(index) {
                                                            this.previews.splice(index, 1);
                                                            // Réinitialiser l'input file
                                                            if (this.$refs.fileInput) {
                                                                this.$refs.fileInput.value = '';
                                                            }
                                                        }
                                                    }"
                                                    class="p-6 text-center transition-colors duration-200 border-2 border-dashed border-zinc-300 dark:border-zinc-600 rounded-xl hover:border-blue-400 dark:hover:border-blue-500"
                                                >

                                                    <div class="flex flex-col items-center justify-center gap-3">

                                                        {{-- Loader --}}
                                                        <template x-if="isUploading">
                                                            <div class="flex flex-col items-center">
                                                                <div class="w-8 h-8 border-b-2 border-blue-600 rounded-full animate-spin"></div>
                                                                <p class="mt-2 text-sm text-zinc-600 dark:text-zinc-400">Téléchargement en cours...</p>
                                                            </div>
                                                        </template>

                                                        {{-- Aperçus --}}
                                                        <template x-for="(preview, index) in previews" :key="index">
                                                            <div class="relative">
                                                                <template x-if="preview.type === 'image'">
                                                    <img :src="preview.url" :alt="preview.name" class="object-cover w-20 h-20 rounded-lg shadow-md">
                                                                </template>

                                                                <template x-if="preview.type !== 'image'">
                                                                    <div class="flex items-center justify-center w-20 h-20 overflow-hidden text-xs border rounded-lg text-zinc-700 dark:text-zinc-300">
                                                                        <span x-text="preview.name"></span>
                                                                    </div>
                                                                </template>
                                                            </div>
                                                        </template>

                                                        {{-- Zone de dépôt si aucun fichier --}}
                                                        <template x-if="!previews.length && !isUploading">
                                                            <div class="flex flex-col items-center justify-center gap-3">
                                                                <div class="p-3 rounded-full bg-blue-50 dark:bg-blue-900/20">
                                                                    <svg class="w-8 h-8 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                                                    </svg>
                                                                </div>
                                                                <div>
                                                                    <p class="text-sm font-medium text-zinc-900 dark:text-white">
                                                                        {{ $placeholderText }}
                                                                    </p>
                                                                    <p class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
                                                                        @if(str_contains($accept, 'image'))
                                                                            PNG, JPG, GIF, WEBP jusqu'à 3MB
                                                                        @elseif(str_contains($accept, 'video'))
                                                                            MP4, MOV, AVI jusqu'à 50MB
                                                                        @else
                                                                            PDF, DOC, XLS, TXT jusqu'à 10MB
                                                                        @endif
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </template>

                                                        {{-- Input fichier --}}
                                                        <input
                                                            type="file"
                                                            x-ref="fileInput"
                                                            wire:model="{{ $itemName }}"
                                                            @if($isMultiple) multiple @endif
                                                            accept="{{ $accept }}"
                                                            @change="fileChosen"
                                                            x-on:livewire-upload-start="isUploading = true"
                                                            x-on:livewire-upload-finish="isUploading = false"
                                                            x-on:livewire-upload-error="isUploading = false"
                                                            class="hidden"
                                                            id="{{ $itemId }}"
                                                        >

                                                        <label for="{{ $itemId }}" class="mt-4">
                                                            <span class="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md cursor-pointer hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path>
                                                                </svg>
                                                                Parcourir les fichiers
                                                            </span>
                                                        </label>

                                                    </div>
                                                </div>
                                            @endif

                                            <!-- MODAL SELECT -->
                                            @if(in_array($itemType, ['modal-select']))
                                                @php
                                                    $selectMode = $item['selectMode'] ?? 'single';
                                                    $modalFields = $item['modalFields'] ?? [];
                                                    $modalDatas = $item['modalDatas'] ?? [];
                                                    $modelClass = $form->modelClass();
                                                @endphp

                                                <livewire:modals.entity-selector
                                                    :name="$field"
                                                    :modelClass="$modelClass"
                                                    :relationName="$item['name'] ?? ''"
                                                    :selectMode="$selectMode"
                                                    :label="$itemLabel"
                                                    :modalDatas="$modalDatas"
                                                    :modalFields="$modalFields"
                                                    wire:key="modal-{{ $field }}-step-{{ $currentStep }}-{{ $mode }}"
                                                />
                                            @endif

                                            <!-- MESSAGE D'AIDE -->
                                            @if($itemHelp)
                                                <flux:description> {{ $itemHelp }} </flux:description>
                                            @endif

                                            <!-- MESSAGE D'ERREUR -->
                                            @error($itemName)
                                                <flux:error name="{{ $itemName }}" />
                                            @enderror

                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    @endif
                </div>

                <!-- BOUTONS D'ACTION class="p-6 mt-8 bg-white shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700" -->
                <x-slot name="actions">
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <!-- Boutons de navigation (uniquement pour multi-step) -->
                        @if($hasMultipleSteps && $totalDisplayedSteps > 0)
                        <div class="flex gap-3">
                            @if($currentStep > 1)
                                <x-mt::button icon="arrow-left" type="button" variant="secondary" wire:click="previousStep" wire:loading.attr="disabled">
                                    Précédent
                                </x-mt::button>
                            @endif
                            
                            @if($currentStep < $totalDisplayedSteps)
                                <flux:button icon="arrow-right" type="button" variant="primary" wire:click="nextStep" wire:loading.attr="disabled">
                                    Suivant
                                </flux:button>
                            @endif
                        </div>
                        @endif

                        <!-- Boutons d'action -->
                        <div class="flex gap-3">
                            <x-mt::button
                                icon="fa-solid fa-undo"
                                href="{{ route($this->getRedirectRouteName() ) ?? route('dashboard') }}"
                                variant="secondary"
                                label="Annuler"
                            />
                                
                            @if($hasMultipleSteps && $totalDisplayedSteps > 0 && $currentStep < $totalDisplayedSteps)
                                <x-mt::button
                                    icon="fa-solid fa-save"
                                    type="button"
                                    loading="saveAndContinue"
                                    variant="primary"
                                    wire:click="saveAndContinue"
                                    label="Enregistrer et continuer"
                                />
                            @else
                                <x-mt::button
                                    icon="fa-solid @if($mode === 'edit') fa-edit @else fa-floppy-disk @endif"
                                    type="submit"
                                    loading="save"
                                    variant="primary"
                                >
                                    @if(!$isSubmitting)
                                        {{ $mode === 'edit' ? 'Modifier' : 'Enregistrer' }}
                                    @else
                                        {{ $mode === 'edit' ? 'Modification...' : 'Création...' }}
                                    @endif
                                </x-mt::button>
                            @endif
                        </div>
                    </div>
                </x-slot>
            </x-mt::form.form-container>
        </div>
    </div>
</div>

<!-- Script Alpine.js généraliste CORRIGÉ -->
<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('formActions', (fieldActions = {}) => ({
            // Stockage local des valeurs
            fieldValues: {},
            
            // Actions courantes
            currentActions: fieldActions,
            
            init() {
                
                // Écouter les changements de champ
                this.$el.addEventListener('field-changed', (e) => {
                    this.onFieldChanged(e.detail.field, e.detail.value);
                });
                
                // Observer les changements Livewire
                this.$watch('$wire.form', (formData) => {
                    this.fieldValues = formData;
                    this.updateFieldVisibility();
                }, { deep: true });
                
                // Initialiser les valeurs
                if (this.$wire.form) {
                    this.fieldValues = this.$wire.form;
                }
                
                // Mettre à jour la visibilité initiale
                this.updateFieldVisibility();
            },
            
            onFieldChanged(field, value) {
                
                // Supprimer le préfixe "form." si présent
                if (field.startsWith('form.')) {
                    field = field.replace('form.', '');
                }
                
                // Mettre à jour la valeur locale
                this.fieldValues[field] = value;
                
                // Exécuter les actions pour ce champ
                this.executeFieldActions(field, value);
                
                // Mettre à jour la visibilité
                this.updateFieldVisibility();
            },
            
            executeFieldActions(field, value) {
                const actions = this.currentActions[field] || [];
                
                actions.forEach((action, index) => {
                    this.executeAction(action, field, value);
                });
            },
            
            executeAction(action, field, value) {
                const type = action.type || 'set';
                const target = action.target;
                
                if (!target) {
                    console.warn('Action sans target:', action);
                    return;
                }
                
                
                switch(type) {
                    case 'set':
                        if (action.value !== undefined) {
                            this.setFieldValue(target, action.value);
                        }
                        break;
                        
                    case 'map':
                        if (action.map && action.map[value] !== undefined) {
                            this.setFieldValue(target, action.map[value]);
                        }
                        break;
                        
                    case 'clear':
                        this.setFieldValue(target, null);
                        break;
                        
                    case 'copy':
                        this.setFieldValue(target, value);
                        break;
                        
                    case 'show_if':
                    case 'hide_if':
                        // Géré par updateFieldVisibility()
                        break;
                        
                    case 'enable_if':
                        this.toggleFieldDisabled(target, !this.evaluateCondition(action.condition, value));
                        break;
                        
                    case 'disable_if':
                        this.toggleFieldDisabled(target, this.evaluateCondition(action.condition, value));
                        break;
                        
                    default:
                        console.warn(`Type d'action inconnu: ${type}`);
                }
            },
            
            setFieldValue(field, value) {
                
                // Utiliser $wire.set pour mettre à jour Livewire
                this.$wire.set(`form.${field}`, value);
                
                // Mettre à jour la valeur locale
                this.fieldValues[field] = value;
                
                // Feedback visuel
                this.highlightField(field);
                
                // Forcer la mise à jour de Livewire
                this.$wire.$commit();
            },
            
            toggleFieldDisabled(field, disabled) {
                
                // Trouver tous les inputs pour ce champ
                const selectors = [
                    `select[name="form.${field}"]`,
                    `select[wire\\:model="form.${field}"]`,
                    `input[name="form.${field}"]`,
                    `input[wire\\:model="form.${field}"]`,
                    `textarea[name="form.${field}"]`,
                    `textarea[wire\\:model="form.${field}"]`
                ];
                
                selectors.forEach(selector => {
                    const inputs = document.querySelectorAll(selector);
                    inputs.forEach(input => {
                        input.disabled = disabled;
                        input.classList.toggle('opacity-50', disabled);
                        input.classList.toggle('cursor-not-allowed', disabled);
                    });
                });
            },
            
            updateFieldVisibility() {
                
                Object.entries(this.currentActions).forEach(([sourceField, actions]) => {
                    const sourceValue = this.fieldValues[sourceField];
                    
                    actions.forEach(action => {
                        if (action.type === 'show_if' || action.type === 'hide_if') {
                            const shouldShow = this.evaluateCondition(
                                action.condition, 
                                sourceValue
                            );
                            
                            const element = document.querySelector(`[data-field="${action.target}"]`);
                            if (element) {
                                const isHidden = element.classList.contains('hidden');
                                const shouldBeHidden = action.type === 'show_if' ? !shouldShow : shouldShow;
                                
                                if (shouldBeHidden !== isHidden) {
                                    element.classList.toggle('hidden', shouldBeHidden);
                                    
                                    // Animation
                                    if (!shouldBeHidden) {
                                        this.animateFieldAppearance(element);
                                    }
                                }
                            }
                        }
                    });
                });
            },
            
            evaluateCondition(condition, value) {
                if (condition === undefined) return true;
                
                // Condition simple (valeur unique)
                if (!Array.isArray(condition) && typeof condition !== 'object' && typeof condition !== 'function') {
                    return value == condition;
                }
                
                // Condition array (valeur dans liste)
                if (Array.isArray(condition)) {
                    return condition.includes(value);
                }
                
                // Condition objet (opérateur)
                if (typeof condition === 'object') {
                    const operator = condition.operator || 'equals';
                    const compareValue = condition.value;
                    
                    switch(operator) {
                        case 'equals': return value == compareValue;
                        case 'not_equals': return value != compareValue;
                        case 'greater_than': return value > compareValue;
                        case 'less_than': return value < compareValue;
                        case 'contains': return String(value).includes(compareValue);
                        case 'starts_with': return String(value).startsWith(compareValue);
                        case 'ends_with': return String(value).endsWith(compareValue);
                        case 'empty': return !value;
                        case 'not_empty': return !!value;
                        default: return false;
                    }
                }
                
                return false;
            },
            
            highlightField(field) {
                const element = document.querySelector(`[data-field="${field}"]`);
                if (element) {
                    element.classList.add('ring-2', 'ring-blue-500', 'ring-opacity-50');
                    setTimeout(() => {
                        element.classList.remove('ring-2', 'ring-blue-500', 'ring-opacity-50');
                    }, 1000);
                }
            },
            
            animateFieldAppearance(element) {
                element.classList.add('opacity-0', 'translate-y-2');
                setTimeout(() => {
                    element.classList.remove('opacity-0', 'translate-y-2');
                }, 10);
            }
        }));
    });
</script>