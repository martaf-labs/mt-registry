{{-- <div class="flex aspect-square size-8 items-center justify-center rounded-md text-accent-foreground">
    <x-app-logo-icon class="size-7 fill-current text-white dark:text-black" />
</div> --}}
<div class="ms-1 grid flex-1 text-start text-lg">
    <span class="mb-0.5 truncate leading-tight font-bold">{{ config('app.short_name') }}</span>
</div>
