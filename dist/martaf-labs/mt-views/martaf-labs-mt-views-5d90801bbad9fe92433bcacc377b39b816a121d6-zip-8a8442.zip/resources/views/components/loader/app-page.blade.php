
    <!-- Overlay de chargement" -->
    <div wire:loading wire:target="save,saveAndContinue" 
     class="fixed inset-0 z-50 flex items-center justify-center mt-overlay">
        <div class="p-8 text-center mt-card rounded-2xl">
            <div class="mx-auto mb-4 mt-spinner mt-spinner-lg"></div>
            <p class="font-semibold mt-text-muted">Sauvegarde en cours...</p>
        </div>
    </div>