
{{-- 
<x-mt::dropdown align="right" width="64">
    <x-slot name="trigger">
        <button class="flex items-center gap-3 p-1 pr-4 bg-zinc-100 dark:bg-zinc-900 rounded-full hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-all group">
            <img src="https://ui-avatars.com/api/?name=Admin" class="w-8 h-8 rounded-full border-2 border-white dark:border-zinc-800 shadow-sm" alt="Avatar">
            <span class="text-xs font-black uppercase tracking-widest text-zinc-700 dark:text-zinc-300">Mon Compte</span>
            <i class="fa-solid fa-chevron-down text-[10px] text-zinc-400 group-hover:translate-y-0.5 transition-transform"></i>
        </button>
    </x-slot>

    <x-slot name="content">
        <!-- Section Info -->
        <div class="px-3 py-2 mb-1 border-b border-zinc-100 dark:border-zinc-800/50">
            <p class="text-[9px] font-black uppercase tracking-widest text-zinc-400">Connecté en tant que</p>
            <p class="text-xs font-bold text-zinc-900 dark:text-zinc-100">admin@monprojet.com</p>
        </div>

        <!-- Liens -->
        <x-mt::dropdown-link icon="fa-solid fa-user-gear">Mon Profil</x-mt::dropdown-link>
        <x-mt::dropdown-link icon="fa-solid fa-bell">Notifications</x-mt::dropdown-link>
        
        <div class="my-1 border-t border-zinc-100 dark:border-zinc-800/50"></div>
        
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <x-mt::dropdown-link icon="fa-solid fa-right-from-bracket" class="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10">
                Déconnexion
            </x-mt::dropdown-link>
        </form>
    </x-slot>
</x-mt::dropdown> --}}

@props([
    'align' => 'right', 
    'width' => 'auto', 
    'contentClasses' => 'py-2 bg-white/90 dark:bg-zinc-950/90 backdrop-blur-xl'
])

@php
switch ($align) {
    case 'left':
        $alignmentClasses = 'ltr:origin-top-left rtl:origin-top-right start-0';
        break;
    case 'top':
        $alignmentClasses = 'origin-bottom bottom-full mb-2';
        break;
    case 'right':
    default:
        $alignmentClasses = 'ltr:origin-top-right rtl:origin-top-left end-0';
        break;
}

// Gestion flexible de la largeur
$widthClass = match ($width) {
    '48' => 'w-48',
    '56' => 'w-56',
    '64' => 'w-64',
    '72' => 'w-72',
    default => $width,
};
@endphp

<div class="relative" 
     x-data="{ open: false }" 
     @click.outside="open = false" 
     @close.stop="open = false"
     @keydown.escape.window="open = false">
    
    {{-- Déclencheur --}}
    <div @click="open = ! open" class="cursor-pointer">
        {{ $trigger }}
    </div>

    {{-- Menu Dropdown --}}
    <div x-show="open"
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 translate-y-2 scale-95"
            x-transition:enter-end="opacity-100 translate-y-0 scale-100"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100 translate-y-0 scale-100"
            x-transition:leave-end="opacity-0 translate-y-2 scale-95"
            class="absolute z-[100] mt-3 {{ $widthClass }} {{ $alignmentClasses }}"
            style="display: none;"
            @click="open = false">
        <div class="rounded-md border border-zinc-200/50 dark:border-zinc-800/50 shadow-sm shadow-zinc-500/10 dark:shadow-none overflow-hidden bg-white/90 dark:bg-zinc-800/90 backdrop-blur text-zinc-600 hover:text-blue-600 {{ $contentClasses }}">
            <div class="flex flex-col gap-0.5 p-1.5">
                {{ $content }}
            </div>
        </div>
    </div>
</div>