{{--
    Composant : Recap Item
    Affiche un résumé avec icône, label et valeur numérique.

    Usage :
    <x-mt::recap-item 
        label="Équipements" 
        :nombre="42" 
        icon="fa-solid fa-truck" 
    />
--}}

@props([
    'label'  => '',
    'nombre' => 0,
    'icon'   => 'fa-solid fa-circle',
])

<div {{ $attributes->merge(['class' => 'mt-card mt-card-sm flex items-center gap-3']) }}>

    {{-- Icône --}}
    <span class="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center mt-bg-secondary">
        <i class="{{ $icon }} mt-text-primary"></i>
    </span>

    {{-- Contenu --}}
    <div class="flex-1 min-w-0">
        <p class="text-xs mt-text-muted truncate">{{ $label }}</p>
        <div class="flex items-baseline gap-1.5">
            <span class="text-2xl font-bold mt-text">{{ $nombre }}</span>
            <span class="text-xs mt-text-success">
                {{ $nombre > 1 ? 'Disponibles' : 'Disponible' }}
            </span>
        </div>
    </div>

</div>
