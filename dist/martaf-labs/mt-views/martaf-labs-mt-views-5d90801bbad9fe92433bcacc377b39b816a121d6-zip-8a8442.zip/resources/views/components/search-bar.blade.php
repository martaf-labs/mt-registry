{{-- 
<div class="space-y-10">
    <x-mt::search-bar 
        model="searchQuery" 
        placeholder="Rechercher une spécification (Titre, valeur...)"
        :results="$filteredResults"
    />

    <div class="grid grid-cols-1 gap-4">
    </div>
    </div>
 --}}

@props([
    'model' => 'search',
    'placeholder' => 'Rechercher un élément...',
    'shortcut' => 'K',
    'results' => []
])

<div x-data="{ 
    isFocused: false,
    showResults: false,
    search: @entangle($model)
}" 
class="relative w-full max-w-2xl mx-auto group">
    
    {{-- Container Principal --}}
    <div class="relative flex items-center transition-all duration-500 rounded-2xl border bg-white dark:bg-zinc-950 shadow-sm overflow-hidden"
         :class="isFocused ? 'border-blue-500 ring-4 ring-blue-500/10 shadow-xl scale-[1.01]' : 'border-zinc-200 dark:border-zinc-800'">
        
        {{-- Icône de recherche animée --}}
        <div class="pl-5 pr-3 py-4 flex items-center justify-center transition-colors"
             :class="isFocused ? 'text-blue-500' : 'text-zinc-400'">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
        </div>

        {{-- Input --}}
        <input 
            type="text"
            wire:model.live.debounce.300ms="{{ $model }}"
            @focus="isFocused = true; showResults = true"
            @blur="setTimeout(() => { isFocused = false; showResults = false }, 200)"
            @keydown.escape="showResults = false; $el.blur()"
            @keydown.window.prevent.cmd.k="$el.focus()"
            @keydown.window.prevent.ctrl.k="$el.focus()"
            placeholder="{{ $placeholder }}"
            class="w-full py-4 pr-12 bg-transparent border-none focus:ring-0 text-sm font-bold text-zinc-800 dark:text-zinc-100 placeholder:text-zinc-400 placeholder:font-medium"
        >

        {{-- Raccourci Clavier (Badge) --}}
        <div class="absolute right-4 flex items-center gap-1 opacity-100 group-hover:opacity-0 transition-opacity duration-300">
            <kbd class="hidden sm:inline-flex items-center px-2 py-1 bg-zinc-100 dark:bg-zinc-800 text-[10px] font-black text-zinc-500 rounded-md border border-zinc-200 dark:border-zinc-700">
                ⌘ {{ $shortcut }}
            </kbd>
        </div>

        {{-- Loader Livewire --}}
        <div wire:loading wire:target="{{ $model }}" class="absolute right-4">
            <svg class="animate-spin h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
        </div>
    </div>

    {{-- Dropdown des résultats (Glassmorphism) --}}
    <div x-show="showResults && search.length > 1" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 translate-y-2 scale-95"
         x-transition:enter-end="opacity-100 translate-y-0 scale-100"
         x-transition:leave="transition ease-in duration-100"
         x-transition:leave-start="opacity-100 translate-y-0 scale-100"
         x-transition:leave-end="opacity-0 translate-y-2 scale-95"
         x-cloak
         class="absolute z-50 w-full mt-3 p-2 bg-white/90 dark:bg-zinc-950/90 backdrop-blur-xl border border-zinc-200 dark:border-zinc-800 rounded-3xl shadow-2xl overflow-hidden">
        
        <div class="max-h-80 overflow-y-auto custom-scrollbar">
            @if(count($results) > 0)
                @foreach($results as $result)
                    <div class="flex items-center justify-between p-3 rounded-2xl hover:bg-blue-50 dark:hover:bg-blue-500/10 cursor-pointer group/item transition-all">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-500 group-hover/item:text-blue-500 transition-colors">
                                <i class="{{ $result['icon'] ?? 'fa-solid fa-cube' }} text-sm"></i>
                            </div>
                            <div class="flex flex-col">
                                <span class="text-xs font-bold text-zinc-900 dark:text-zinc-100">{{ $result['title'] }}</span>
                                <span class="text-[10px] text-zinc-400 font-medium">{{ $result['category'] }}</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-right text-[10px] text-zinc-300 group-hover/item:translate-x-1 transition-transform"></i>
                    </div>
                @endforeach
            @else
                <div class="py-12 text-center text-zinc-400">
                    <i class="fa-solid fa-face-frown text-2xl mb-2 opacity-20"></i>
                    <p class="text-xs font-bold uppercase tracking-widest">Aucun résultat trouvé</p>
                </div>
            @endif
        </div>
    </div>
</div>