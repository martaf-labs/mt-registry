@props([
    'title',
    'id',
    'open' => false,
    'icon' => null,
    'exclusive' => false,
])

<div x-data="{ 
        expanded: @js($open),
        id: @js($id),
        toggle() {
            if (@js($exclusive)) {
                if (this.expanded) {
                    this.expanded = false;
                } else {
                    this.$dispatch('close-others', { except: this.id });
                    this.expanded = true;
                }
            } else {
                this.expanded = !this.expanded;
            }
        }
     }" 
     x-on:close-others.window="if (@js($exclusive) && $event.detail.except !== id) expanded = false"
     role="region"
     class="group mb-3 transition-all duration-500 rounded-lg mt-bg"
     style="border: 1px solid rgb(var(--mt-ui-card-border))">
    
    <button @click="toggle()"
            :aria-expanded="expanded"
            class="flex items-center justify-between w-full px-5 py-4 text-left outline-none">
        
        <div class="flex items-center gap-4">
            @if($icon)
                <div class="w-11 h-11 rounded-2xl flex items-center justify-center transition-all duration-500"
                     :style="expanded 
                        ? 'background: rgb(var(--mt-primary)); color: #fff; transform: rotate(6deg)'
                        : 'background: rgba(var(--mt-text), 0.06); color: rgba(var(--mt-text), 0.4)'">
                    <i class="{{ $icon }} text-lg"></i>
                </div>
            @endif
            
            <div class="flex flex-col">
                <span class="text-md font-bold transition-colors mt-text"
                      :style="expanded ? 'color: rgb(var(--mt-primary))' : ''">
                    {{ $title }}
                </span>
                @if(isset($subtitle))
                    <span x-show="!expanded" class="text-xs font-normal mt-text-muted mt-0.5">
                        {{ $subtitle }}
                    </span>
                @endif
            </div>
        </div>

        {{-- Chevron --}}
        <div class="relative flex items-center justify-center w-8 h-8 rounded-full transition-all duration-500"
             :style="expanded 
                ? 'transform: rotate(180deg); background: rgba(var(--mt-primary), 0.08)'
                : 'background: rgba(var(--mt-text), 0.05)'">
            <svg class="w-4 h-4 transition-colors" 
                 :style="expanded ? 'color: rgb(var(--mt-primary))' : 'color: rgba(var(--mt-text), 0.5)'"
                 fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7" />
            </svg>
        </div>
    </button>

    <div x-show="expanded" x-collapse x-cloak>
        <div class="px-5 pb-5 pt-0">
            <div class="mt-text-muted" style="border-top: 1px solid rgba(var(--mt-ui-card-border), 0.5); padding-top: 1rem">
                {{ $slot }}
            </div>
        </div>
    </div>
</div>
