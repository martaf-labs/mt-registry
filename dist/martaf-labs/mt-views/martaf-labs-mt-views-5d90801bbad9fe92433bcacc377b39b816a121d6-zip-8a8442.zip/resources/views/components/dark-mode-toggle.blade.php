
{{-- dark-mode-toggle.blade.php --}}
{{-- Fonctionne grâce au themeManager() déclaré sur <html> dans master.blade.php --}}
<div class="p-1">
    @if(mt_has_dark_mode())
    <button @click="darkMode = !darkMode"
        class="p-2 text-gray-500 transition-all rounded-lg group dark:text-white/50 dark:hover:text-white/70 dark:hover:bg-white/5"
        :title="darkMode ? 'Passer au mode clair' : 'Passer au mode sombre'">

        <!-- Icône Soleil (mode sombre actif) -->
        <x-mt::icon x-show="darkMode" x-cloak name="sun"
            class="w-10 h-10 transition-transform duration-300 text-amber-400 group-hover:rotate-45" />

        <!-- Icône Lune (mode clair actif) -->
        <x-mt::icon x-show="!darkMode" x-cloak name="moon"
            class="w-10 h-10 text-gray-600 transition-transform duration-300 group-hover:-rotate-12" />
    </button>
    @endif    
</div>