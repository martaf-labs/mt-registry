@props(['steps'])

<div class="step-indicator">
    @foreach ($steps as $step)
        @php
            $isFirst = $loop->first;
            $isLast = $loop->last;
            $stepNumber = $loop->iteration;
            $status = $step['status'] ?? 'pending';

            // Classes pour le cercle
            $circleClasses = [
                'completed' => 'bg-emerald-500 text-white border-emerald-500 shadow-lg shadow-emerald-500/20',
                'active' => 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-600/30',
                'pending' => 'bg-white text-gray-400 border-gray-300 dark:bg-gray-800 dark:border-gray-600',
                'error' => 'bg-red-500 text-white border-red-500 shadow-lg shadow-red-500/20',
            ];

            // Classes pour la ligne de connexion
            $lineClasses = [
                'completed' => 'bg-emerald-500',
                'active' => 'bg-gradient-to-r from-emerald-500 to-blue-600',
                'pending' => 'bg-gray-300 dark:bg-gray-600',
                'error' => 'bg-red-500',
            ];

            // Icônes par défaut selon le statut
            $defaultIcons = [
                'completed' => 'fas fa-check',
                'active' => 'fas fa-spinner fa-spin',
                'pending' => 'fas fa-circle',
                'error' => 'fas fa-exclamation',
            ];

            $icon = $step['icon'] ?? $defaultIcons[$status] ?? 'fas fa-circle';
            $isCompleted = $status === 'completed';
            $isActive = $status === 'active';
            $hasError = $status === 'error';
            $showNumber = !isset($step['icon']) && str_contains($icon, 'fa-circle');
        @endphp

        <!-- Élément de timeline -->
        <div class="step-item relative group"
             x-data="{ hover: false }"
             @mouseenter="hover = true"
             @mouseleave="hover = false">
            
            <!-- Conteneur principal pour mobile -->
            <div class="flex items-start">
                <!-- Colonne gauche (cercles + lignes) -->
                <div class="relative flex flex-col items-center mr-4 md:mr-6">
                    <!-- Ligne verticale au-dessus (sauf pour le premier) -->
                    @if(!$isFirst)
                        <div class="absolute -top-4 left-1/2 w-0.5 h-4 -translate-x-1/2
                                    {{ $lineClasses[$status] ?? $lineClasses['pending'] }}
                                    transition-all duration-500 ease-out z-0"></div>
                    @endif

                    <!-- Cercle indicateur -->
                    <div class="relative z-10">
                        <div class="step-circle w-10 h-10 rounded-full border-2 flex items-center justify-center
                                    {{ $circleClasses[$status] ?? $circleClasses['pending'] }}
                                    transition-all duration-300 ease-out group-hover:scale-110
                                    {{ $isActive ? 'ring-4 ring-blue-600/20 animate-pulse-ring' : '' }}
                                    {{ $hasError ? 'animate-shake' : '' }}">
                            
                            @if($showNumber)
                                <span class="step-number font-semibold text-sm">{{ $stepNumber }}</span>
                            @else
                                <i class="{{ $icon }} text-sm"></i>
                            @endif

                            <!-- Badge pour statut actif -->
                            @if($isActive)
                                <span class="absolute -top-1 -right-1 w-3 h-3 bg-blue-600 rounded-full
                                            animate-ping opacity-75"></span>
                            @endif

                            <!-- Badge pour erreur -->
                            @if($hasError)
                                <span class="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full
                                            animate-pulse"></span>
                            @endif
                        </div>

                        <!-- Tooltip au hover (desktop seulement) -->
                        <div class="hidden md:block absolute -top-12 left-1/2 transform -translate-x-1/2 px-3 py-2
                                    bg-gray-900 dark:bg-gray-700 text-white text-xs rounded-lg opacity-0 invisible
                                    group-hover:opacity-100 group-hover:visible transition-all duration-200
                                    whitespace-nowrap z-20 shadow-xl pointer-events-none">
                            {{ $step['text'] ?? 'Étape ' . $stepNumber }}
                            <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-2 h-2
                                        bg-gray-900 dark:bg-gray-700 rotate-45"></div>
                        </div>
                    </div>

                    <!-- Ligne verticale en dessous (sauf pour le dernier) -->
                    @if(!$isLast)
                        <div class="absolute top-10 left-1/2 w-0.5 h-4 -translate-x-1/2
                                    {{ $isCompleted ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600' }}
                                    transition-all duration-500 ease-out z-0"></div>
                    @endif
                </div>

                <!-- Colonne droite (contenu) -->
                <div class="step-content flex-1 pt-1 min-w-0">
                    <div class="mb-2">
                        <h4 class="step-title font-semibold text-sm md:text-base mb-1 
                                {{ $isActive ? 'text-blue-700 dark:text-blue-400' : ($isCompleted ? 'text-emerald-700 dark:text-emerald-400' : 'text-gray-700 dark:text-gray-300') }}
                                transition-colors duration-300">
                            {{ $step['text'] ?? 'Étape ' . $stepNumber }}
                        </h4>

                        @if(!empty($step['subText']))
                            <p class="step-description text-xs md:text-sm text-gray-600 dark:text-gray-400 leading-relaxed
                                    transition-opacity duration-300">
                                {{ $step['subText'] }}
                            </p>
                        @endif
                    </div>

                    <!-- Badge de statut -->
                    @if($isCompleted || $isActive || $hasError)
                        <div class="mt-1 hidden">
                            @if($isCompleted)
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs
                                            font-medium bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300">
                                    <i class="fas fa-check mr-1 text-xs"></i>
                                    Terminé
                                </span>
                            @elseif($isActive)
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs
                                            font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300">
                                    <i class="fas fa-spinner fa-spin mr-1 text-xs"></i>
                                    En cours
                                </span>
                            @elseif($hasError)
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs
                                            font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300">
                                    <i class="fas fa-exclamation-triangle mr-1 text-xs"></i>
                                    Erreur
                                </span>
                            @endif
                        </div>
                    @endif
                </div>
            </div>
        </div>
    @endforeach
</div>

<style>
    /* Animation pour le pulse du cercle actif */
    @keyframes pulse-ring {
        0% {
            box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.5);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(59, 130, 246, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(59, 130, 246, 0);
        }
    }

    /* Animation pour secouer en cas d'erreur */
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-2px); }
        20%, 40%, 60%, 80% { transform: translateX(2px); }
    }

    .animate-pulse-ring {
        animation: pulse-ring 2s infinite;
    }

    .animate-shake {
        animation: shake 0.5s ease-in-out;
    }

    /* ========== VERSION DESKTOP ========== */
    @media (min-width: 769px) {
        .step-indicator {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            position: relative;
            padding: 2rem 1rem;
            width: 100%;
            gap: 0;
        }

        .step-item {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
            min-width: 0;
            padding: 0 0.5rem;
        }

        /* Desktop - retour à la version horizontale */
        .step-item > .flex.items-start {
            flex-direction: column;
            align-items: center;
            width: 100%;
        }

        .step-item .relative.flex-col {
            margin-right: 0;
            margin-bottom: 1rem;
        }

        /* Lignes horizontales pour desktop */
        .step-item:not(:first-child)::before {
            content: '';
            position: absolute;
            left: -50%;
            right: 50%;
            top: 20px; /* Centre du cercle */
            height: 2px;
            background: linear-gradient(to right, 
                transparent 0%,
                {{ $lineClasses[$status] ?? '#e5e7eb' }} 50%,
                transparent 100%);
            z-index: 0;
        }

        .step-item:not(:last-child)::after {
            content: '';
            position: absolute;
            left: 50%;
            right: -50%;
            top: 20px; /* Centre du cercle */
            height: 2px;
            background: linear-gradient(to left, 
                transparent 0%,
                {{ $isCompleted ? '#10b981' : '#e5e7eb' }} 50%,
                transparent 100%);
            z-index: 0;
        }

        /* Cacher les lignes verticales sur desktop */
        .step-item .relative.flex-col > div.absolute {
            display: none !important;
        }

        /* Contenu centré sous le cercle */
        .step-content {
            text-align: center !important;
            padding-top: 0 !important;
            max-width: 180px;
            width: 100%;
        }

        .step-title {
            font-size: 0.875rem;
        }

        .step-description {
            font-size: 0.75rem;
        }
    }

    /* ========== VERSION MOBILE ========== */
    @media (max-width: 768px) {
        .step-indicator {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            padding: 1rem 0;
            width: 100%;
        }

        .step-item {
            width: 100%;
        }

        /* Version verticale avec cercles alignés à gauche */
        .step-item > .flex.items-start {
            width: 100%;
        }

        /* Ligne verticale continue pour mobile */
        .step-indicator::before {
            content: '';
            position: absolute;
            left: 35px; /* 20px (mr-4) + 15px (demi-cercle) */
            top: 0;
            bottom: 0;
            width: 2px;
            background: linear-gradient(to bottom, 
                transparent 0%,
                #e5e7eb 10%,
                #e5e7eb 90%,
                transparent 100%);
            z-index: 0;
        }

        .dark .step-indicator::before {
            background: linear-gradient(to bottom, 
                transparent 0%,
                #4b5563 10%,
                #4b5563 90%,
                transparent 100%);
        }

        /* Positionnement des cercles sur la ligne */
        .step-item .relative.flex-col {
            position: relative;
            z-index: 10;
        }

        /* Ajustement des cercles pour être sur la ligne */
        .step-circle {
            background-color: white !important;
            border-width: 3px !important;
        }

        .dark .step-circle {
            background-color: #1f2937 !important;
        }

        /* Contenu aligné à droite */
        .step-content {
            padding-left: 0.5rem;
            padding-right: 1rem;
        }

        .step-title {
            font-size: 0.9375rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .step-description {
            font-size: 0.8125rem;
            line-height: 1.4;
        }

        /* Ajustement des badges pour mobile */
        .step-content > div:last-child span {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
    }

    /* ========== VERSION TABLETTE ========== */
    @media (min-width: 640px) and (max-width: 768px) {
        .step-item .relative.flex-col {
            margin-right: 2rem;
        }

        .step-content {
            padding-left: 1rem;
        }

        .step-title {
            font-size: 1rem;
        }

        .step-description {
            font-size: 0.875rem;
        }
    }

    /* Dark mode */
    .dark .step-circle.pending {
        background-color: #1f2937;
        border-color: #4b5563;
        color: #9ca3af;
    }

    .dark .step-tooltip {
        background-color: #374151;
    }

    .dark .step-tooltip > div {
        background-color: #374151;
    }

    /* Hover effects */
    .step-item:hover .step-circle {
        transform: scale(1.1);
    }

    /* Utilitaires */
    .min-w-0 {
        min-width: 0;
    }

    .step-content {
        word-break: break-word;
        overflow-wrap: break-word;
    }
</style>