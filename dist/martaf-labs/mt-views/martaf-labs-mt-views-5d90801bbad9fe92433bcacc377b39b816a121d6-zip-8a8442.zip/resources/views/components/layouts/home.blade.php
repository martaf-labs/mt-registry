<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="{{ asset('favicon.ico') }}" sizes="any">
        <link rel="icon" href="{{ asset('favicon.svg') }}" type="image/svg+xml">
        <link rel="apple-touch-icon" href="{{ asset('apple-touch-icon.png') }}">

        @include('components.layouts.guest.head')
    </head>
    <body class="min-h-screen w-full relative bg-white dark:bg-slate-950 transition-colors duration-500">

        <div class="fixed inset-0 z-0 pointer-events-none">
            <div class="absolute inset-0
                bg-[linear-gradient(to_right,#e5e7eb_1px,transparent_1px),linear-gradient(to_bottom,#e5e7eb_1px,transparent_1px)]
                dark:bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)]
                bg-[size:4rem_4rem]
                opacity-40 dark:opacity-20">
            </div>

            <div class="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-sky-500/10 dark:bg-sky-500/[0.05] blur-[120px] rounded-full"></div>
            <div class="absolute bottom-[10%] right-[-5%] w-[500px] h-[500px] bg-indigo-500/10 dark:bg-indigo-500/[0.05] blur-[120px] rounded-full"></div>
        </div>

        <!-- Scroll Progress Bar -->
        <div id="scroll-bar"
            class="fixed top-0 left-0 z-100 h-1.5 bg-blue-900 animate-pulse transition-all duration-200 ease-out"
            style="width: 0%;"
        ></div>


        {{-- bouton chamgement mode --}}
        <div x-data="{
            darkMode: localStorage.getItem('theme') === 'dark',
            toggleTheme() {
                this.darkMode = !this.darkMode;
                if (this.darkMode) {
                    document.documentElement.classList.add('dark');
                    localStorage.setItem('theme', 'dark');
                } else {
                    document.documentElement.classList.remove('dark');
                    localStorage.setItem('theme', 'light');
                }
            }
        }"
        x-init="if (darkMode) document.documentElement.classList.add('dark')"
        class="fixed left-0 top-1/2 -translate-y-1/2 z-[100]">

        <button @click="toggleTheme()"
            class="relative flex items-center justify-center w-12 h-12 bg-white/10 dark:bg-slate-900/50 backdrop-blur-xl border border-r-0 border-white/20 dark:border-sky-500/30 rounded-r-2xl shadow-2xl group transition-all duration-300 hover:w-16 hover:bg-sky-500 group">

                <template x-if="!darkMode">
                    <i class="fa-solid fa-sun text-orange-400 group-hover:text-white transition-colors duration-300 text-xl"></i>
                </template>

                <template x-if="darkMode">
                    <i class="fa-solid fa-moon text-sky-400 group-hover:text-white transition-colors duration-300 text-xl"></i>
                </template>

                <span class="absolute left-full ml-4 px-2 py-1 bg-slate-800 text-white text-[10px] rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap">
                    Basculer le mode
                </span>
            </button>
        </div>

        <main id="main-container">

            {{ $slot }}

        </main>

        {{-- @fluxScripts --}}

        <script>
            const scrollBar = document.getElementById('scroll-bar');

            window.addEventListener('scroll', () => {
                const scrollTop = window.scrollY;
                const scrollHeight =
                    document.documentElement.scrollHeight -
                    document.documentElement.clientHeight;

                const progress = (scrollTop / scrollHeight) * 100;
                scrollBar.style.width = `${progress}%`;
            });
        </script>


        <script>
            // Animation au chargement de la page
            document.addEventListener('DOMContentLoaded', function() {
                // Animation des éléments avec délai
                const fadeElements = document.querySelectorAll('.fade-in, .stagger-item');
                fadeElements.forEach(el => {
                    el.classList.add('visible');
                });

                // Effet de parallaxe sur le scroll
                window.addEventListener('scroll', function() {
                    const scrolled = window.pageYOffset;
                    const parallaxElements = document.querySelectorAll('.floating-shape, .particle');

                    parallaxElements.forEach((el, index) => {
                        const speed = 0.3 + (index * 0.1);
                        const yPos = -(scrolled * speed);
                        el.style.transform = `translateY(${yPos}px) ${el.style.transform.split(' ').slice(1).join(' ')}`;
                    });
                });

                // Effets de survol améliorés
                document.querySelectorAll('.entity-card').forEach(card => {
                    card.addEventListener('mouseenter', function() {
                        this.style.transform = 'translateY(-12px) scale(1.02)';
                    });

                    card.addEventListener('mouseleave', function() {
                        this.style.transform = 'translateY(0) scale(1)';
                    });
                });
            });
        </script>

        <!-- OWL CAROUSEL SCRIPTS -->
        <script src="{{ asset('js/jquery-3.7.1.min.js') }}"></script>
        <script src="{{ asset('vendor/OwlCarousel2-2.3.4/dist/owl.carousel.min.js') }}"></script>


        <script>
            $(document).ready(function(){
                $(".owl-carousel").owlCarousel({
                    loop: true,              // Scroll infini
                    margin: 30,              // Espace entre les items
                    nav: true,               // Flèches gauche/droite
                    dots: false,             // Bullets en bas
                    autoplay: true,          // Défilement automatique
                    autoplayTimeout: 3000,   // Intervalle auto-défilement
                    autoplayHoverPause: true,// Pause au survol
                    lazyLoad: true,          // Chargement paresseux des images
                    responsive: {
                        0: { items: 1 },    // Mobile
                        640: { items: 2 },  // Tablette
                        1024: { items: 3 }  // Desktop
                    }
                });
            });
        </script>

    </body>
</html>
