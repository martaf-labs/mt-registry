
        
        <link rel="icon" href="{{ asset(mt_config('assets.favicons.ico')) }}" sizes="any">
        <link rel="icon" href="{{ asset(mt_config('assets.favicons.svg')) }}" type="image/svg+xml">
        <link rel="apple-touch-icon" href="{{ asset(mt_config('assets.favicons.png')) }}">

        <title>@yield('title'){{ mt_config('seo.title_suffix') }}</title>



        @env('local')
            <!-- En développement : utilisation de Vite -->
            @vite(['resources/css/app.css', 'resources/js/app.js'])

            <link rel="stylesheet" href="{{ asset('vendor/fontawesome-free-6-4-2/css/all.min.css') }}">

        @else
            <!-- En production : chargement direct des assets compilés -->
            @php
                $manifest = json_decode(file_get_contents(public_path('build/manifest.json')), true);
            @endphp

            @if(isset($manifest['resources/css/app.css']))
            <link rel="stylesheet" href="{{ asset('build/' . $manifest['resources/css/app.css']['file']) }}">
            @endif

            @if(isset($manifest['resources/js/app.js']))
            <script type="module" src="{{ asset('build/' . $manifest['resources/js/app.js']['file']) }}"></script>
            @endif

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        @endenv

        @if (mt_config('assets.google_font_url'))
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="{{ mt_config('assets.google_font_url') }}" rel="stylesheet">
        @endif
        
        <style>
            :root {
                --font-mt-heading:{!! mt_config('assets.font_heading') !!};
                --font-mt-body:{!! mt_config('assets.font_body') !!};
            }
            body {
                font-family: var(--font-mt-body);
            }
            h1,h2,h3,h4,h5,h6 {
                font-family: var(--font-mt-heading);
            }

            /* :root{
                --mt-primary:{{ hexToRgb(mt_config('colors.light.primary')) }};
                --mt-bg:{{ hexToRgb(mt_config('colors.light.bg')) }};
            } */

            /* mode sombre automatique */ 
            /* @media(prefers-color-sheme: dark){
                :root{
                    --mt-primary:{{ hexToRgb(mt_config('colors.dark.primary')) }};
                    --mt-bg:{{ hexToRgb(config('colors.dark.bg')) }};
                }   
            } */

            /* .dark :root{
                --mt-primary:{{ hexToRgb(mt_config('colors.dark.primary')) }};
                --mt-bg:{{ hexToRgb(mt_config('colors.dark.bg')) }};
            } */


        </style>

        <style>
            :root {
                --primary: #209CDC;
                --primary-dark: #45b5ec;
                --secondary: #000000;
                --accent: #45b5ec;
            }

            body {
                font-family: 'Montserrat', sans-serif;
                scroll-behavior: smooth;
            }
        </style>

        <!-- Script pour écouter les changements de titre -->
        <script>
            document.addEventListener('livewire:init', () => {
                Livewire.on('page-title-changed', (event) => {
                    document.title = event.title;
                });
            });
        </script>

        {{-- @fluxAppearance --}}
