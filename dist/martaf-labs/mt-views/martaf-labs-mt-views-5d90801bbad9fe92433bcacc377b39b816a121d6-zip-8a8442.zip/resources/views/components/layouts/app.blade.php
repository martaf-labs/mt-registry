<x-mt::layouts.master>
    <div class="h-full antialiased" x-data="{ 
        sidebarOpen: window.innerWidth >= 1024,
        sidebarCollapsed: false,
        mobileMenuOpen:   false,
        mobileSearchOpen: false,
        mobileNotifOpen:  false,

        get sidebarWidth() {
            if (window.innerWidth < 1024) return 0;
            return this.sidebarCollapsed ? 80 : 256;
        },

        init() {
            window.addEventListener('resize', () => {
                if (window.innerWidth >= 1024) {
                    this.sidebarOpen = true;
                    this.mobileMenuOpen = false;
                } else {
                    this.sidebarOpen = false;
                    this.sidebarCollapsed = false;
                }
            });
            const savedState = localStorage.getItem('sidebarCollapsed');
            if (savedState !== null) this.sidebarCollapsed = savedState === 'true';
        }
    }" 
    x-init="init();
             $watch('sidebarCollapsed', val => localStorage.setItem('sidebarCollapsed', val));
             ">


    {{-- ═══════════════════════════════════════════════════
         DESKTOP SIDEBAR
         ═══════════════════════════════════════════════════ --}}
    <aside class="fixed top-0 left-0 z-50 flex-col hidden h-full transition-all duration-300 ease-in-out shadow-xl lg:shadow-none lg:flex mt-bg mt-border"
           :class="{ 'w-64': !sidebarCollapsed, 'w-20': sidebarCollapsed }">

        <div class="flex items-center justify-between flex-shrink-0 h-16 px-4"
         {{-- style="border-bottom: 1px solid rgb(var(--mt-ui-card-border)) --}}
         ">
            <a href="{{ route('dashboard') }}" class="flex items-center space-x-2 overflow-hidden">
                <span x-show="!sidebarCollapsed" class="text-xl font-bold uppercase truncate mt-text">
                    {{ mt_config('app_name') }}
                </span>
            </a>
            <button @click="sidebarCollapsed = !sidebarCollapsed"
                    class="flex p-1.5 rounded-lg transition-colors mt-btn-icon">
                <i class="text-sm transition-transform duration-300 mt-icon-chevron-left" :class="{ 'rotate-180': sidebarCollapsed }"></i>
            </button>
        </div>

        <nav class="flex-1 px-3 py-4 overflow-y-auto scrollbar-thin">
            @php 
                $sidebarItems = getSidebar();
            @endphp
            <div class="mb-4">
                <h3 x-show="!sidebarCollapsed" class="px-3 mb-2 text-xs font-semibold tracking-wider uppercase mt-text-muted">
                    {{ __('Menu principal') }}
                </h3>
                <div class="space-y-1">
                    @foreach ($sidebarItems as $item)
                        @php
                            $itemRoute  = $item['route'] ?? '';
                            $itemIcon   = $item['icon'] ?? 'fa-solid fa-circle';
                            $subItems   = $item['subItems'] ?? [];
                            $itemCount  = $item['count'] ?? null;
                            $isActive   = request()->routeIs($itemRoute.'*') ||
                                          (!empty($subItems) && collect($subItems)->contains(fn($s) => request()->routeIs($s['route'].'*')));
                            $badgeColors = $itemCount > 10 ? 'mt-badge mt-badge-danger'
                                         : ($itemCount > 5  ? 'mt-badge mt-badge-warning'
                                         : 'mt-badge mt-badge-info');
                        @endphp
                        @if(!empty($subItems))
                            <div x-data="{ open: {{ $isActive ? 'true' : 'false' }} }" class="space-y-1">
                                <button @click="open = !open"
                                        class="flex items-center justify-between w-full px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 {{ $isActive ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}"
                                        :class="{ 'justify-center': sidebarCollapsed }" :title="sidebarCollapsed ? '{{ __($item['label']) }}' : ''">
                                    <div class="flex items-center min-w-0" :class="{ 'justify-center': sidebarCollapsed }">
                                        <span class="flex-shrink-0 w-5 h-5 mt-text-muted" :class="{ 'mr-0': sidebarCollapsed, 'mr-3': !sidebarCollapsed }">
                                            <x-mt::icon :name="$itemIcon" />
                                        </span>
                                        <span x-show="!sidebarCollapsed" class="truncate">{!! __($item['label']) !!}</span>
                                    </div>
                                    <template x-if="!sidebarCollapsed">
                                        <span class="flex-shrink-0 ml-2 text-xs transition-transform duration-200" :class="{ 'rotate-180': open }">
                                            <x-mt::icon name="chevron-down" />
                                        </span>
                                    </template>
                                </button>
                                <div x-show="open && !sidebarCollapsed" x-collapse.duration.200ms class="pl-4 space-y-1">
                                    @foreach ($subItems as $subItem)
                                        @php
                                            $subRoute  = $subItem['route'] ?? '';
                                            $subIcon   = $subItem['icon'] ?? 'fa-solid fa-circle';
                                            $subCount  = $subItem['count'] ?? null;
                                            $subActive = request()->routeIs($subRoute.'*');
                                            $subBadge  = $subCount > 10 ? 'mt-badge mt-badge-danger' : ($subCount > 5 ? 'mt-badge mt-badge-warning' : 'mt-badge mt-badge-info');
                                        @endphp
                                        <a href="{{ $subRoute }}" wire:navigate class="flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors {{ $subActive ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}">
                                            <div class="flex items-center min-w-0">
                                                <x-mt::icon :name="$subIcon" class="flex-shrink-0 mr-3 mt-text-muted" />
                                                <span class="truncate">{!! __($subItem['label']) !!}</span>
                                            </div>
                                            @if($subCount)<span class="{{ $subBadge }} flex-shrink-0 ml-2">{{ $subCount }}</span>@endif
                                        </a>
                                    @endforeach
                                </div>
                            </div>
                        @else
                            <a href="{{ $itemRoute }}" wire:navigate class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 relative {{ $isActive ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}" :class="{ 'justify-center': sidebarCollapsed }" :title="sidebarCollapsed ? '{{ __($item['label']) }}' : ''">
                                <div class="flex items-center min-w-0" :class="{ 'justify-center': sidebarCollapsed }">
                                    <span class="{{ $itemIcon }} w-5 h-5 flex-shrink-0 mt-text-muted" :class="{ 'mr-0': sidebarCollapsed, 'mr-3': !sidebarCollapsed }">
                                        <x-mt::icon :name="$itemIcon" />
                                    </span>
                                    <span x-show="!sidebarCollapsed" class="truncate">{!! __($item['label']) !!}</span>
                                </div>
                                @if($itemCount)
                                    <span x-show="!sidebarCollapsed" class="{{ $badgeColors }} flex-shrink-0 ml-2">{{ $itemCount }}</span>
                                    <span x-show="sidebarCollapsed" class="{{ $badgeColors }} absolute -top-1 -right-1">{{ $itemCount }}</span>
                                @endif
                            </a>
                        @endif
                    @endforeach
                </div>
            </div>

            @if (\Illuminate\Support\Facades\Route::has('home'))   
            <div>
                <a href="{{ mt_get_route('home') }}" wire:navigate class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 relative {{ $isActive ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}" :class="{ 'justify-center': sidebarCollapsed }" :title="sidebarCollapsed ? '{{ __($item['label']) }}' : ''">
                    <div class="flex items-center min-w-0" :class="{ 'justify-center': sidebarCollapsed }">
                        <span class="flex-shrink-0 w-5 h-5 mt-text-muted" :class="{ 'mr-0': sidebarCollapsed, 'mr-3': !sidebarCollapsed }">
                            <x-mt::icon name="arrow-left" />
                        </span>
                        <span x-show="!sidebarCollapsed" class="truncate">Retour vers le site</span>
                    </div>
                </a>
            </div>        
            @endif
        </nav>

        <div class="flex-shrink-0 p-4"
        {{-- style="border-top: 1px solid rgb(var(--mt-ui-card-border)) --}}
        ">
            <div x-data="{ profileOpen: false }" class="relative">
                <button @click="profileOpen = !profileOpen" class="flex items-center w-full px-3 py-2 text-sm transition-colors rounded-lg mt-btn-ghost-muted" :class="{ 'justify-center': sidebarCollapsed }">
                    <span class="flex items-center justify-center flex-shrink-0 w-8 h-8 text-white rounded-lg bg-gradient-to-br from-blue-500 to-purple-600">{{ getInitials(auth()->user()?->fullName()) }}</span>
                    <template x-if="!sidebarCollapsed">
                        <div class="flex-1 min-w-0 ml-3 text-left">
                            <p class="font-medium truncate mt-text">{{ auth()->user()?->fullName() }}</p>
                            <p class="text-xs truncate mt-text-muted">{{ auth()->user()?->email }}</p>
                        </div>
                    </template>
                    <span x-show="!sidebarCollapsed" class="flex-shrink-0 ml-2 text-xs transition-transform duration-200 mt-text-muted" :class="{ 'rotate-180': profileOpen }">
                        <x-mt::icon name="chevron-up"/>
                    </span>
                </button>
                
                <div x-show="profileOpen" @click.away="profileOpen = false"
                     x-transition:enter="transition ease-out duration-100" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
                     x-transition:leave="transition ease-in duration-75" x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
                     class="absolute left-0 w-full mb-2 rounded-lg shadow-lg bottom-full mt-card" :class="{ 'w-48': sidebarCollapsed }" x-cloak>
                    <div class="">
                        <div x-show="sidebarCollapsed" class="px-4 py-2" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                            <p class="text-sm font-medium truncate mt-text">{{ auth()->user()?->fullName() }}</p>
                            <p class="text-xs truncate mt-text-muted">{{ auth()->user()?->email }}</p>
                        </div>
                        {{-- <a href="{{ route('settings.profile') }}" wire:navigate class="flex items-center px-4 py-2 text-sm mt-text mt-btn-ghost-muted">
                            <x-mt::icon name="gear" class="mr-3 mt-text-muted" />{{ __('Settings') }}
                        </a> --}}
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="flex items-center w-full px-4 py-2 text-sm mt-text-danger hover:bg-red-50" style="--hover-bg: rgba(var(--mt-danger), 0.06)">
                                <x-mt::icon name="logout" class="w-5 mr-3 mt-text-danger"></x-mt::icon>{{ __('Log Out') }}
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </aside>


    {{-- ═══════════════════════════════════════════════════
         CONTENU PRINCIPAL
         ═══════════════════════════════════════════════════ --}}
    <div class="flex flex-col min-h-screen transition-all duration-300"
         :style="window.innerWidth >= 1024 ? 'padding-left:' + sidebarWidth + 'px' : 'padding-left:0'">

        {{-- ── DESKTOP header ── --}}
        <header class="sticky top-0 z-30 flex-shrink-0 hidden lg:flex backdrop-blur-md mt-bg" style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
            <div class="w-full px-8 py-1">
                <div class="flex items-center justify-between">
                    <div></div>
                    <div class="flex items-center flex-shrink-0 space-x-2">
                        
                        <div>
                            <livewire:mt.global-search />
                        </div>

                        {{-- dropdown langues --}}
                        <livewire:mt.locale-switcher />

                        {{-- toggle dark mode --}}
                        <x-mt::dark-mode-toggle />

                        {{-- dropdown notifications --}}
                        <x-mt::dropdown>
                            <x-slot name="trigger">
                                <button class="relative p-2 rounded-lg mt-btn-icon">
                                    <x-mt::icon name="bell" />
                                    <span class="absolute w-2 h-2 rounded-full top-1 right-1 animate-pulse" style="background: rgb(var(--mt-danger))"></span>
                                </button>
                            </x-slot>
                            <x-mt::dropdown.menu>
                                <x-mt::dropdown.section label="Notifications" />
                                <x-mt::dropdown.divider />
                                <p class="p-3 text-sm mt-text-muted">Aucune notification pour le moment.</p>
                            </x-mt::dropdown.menu>
                        </x-mt::dropdown>

                    </div>
                </div>
            </div>
        </header>


        {{-- ════════════════════════════════════════════════
             MOBILE TOP BAR
             ════════════════════════════════════════════════ --}}
        <header class="sticky top-0 z-30 flex-shrink-0 h-12 lg:hidden mob-topbar backdrop-blur-md mt-bg">
            <div class="flex items-center h-full gap-1 px-0">

                @isset ($title)
                    {{-- Flèche retour --}}
                    <button onclick="history.back()" class="text-sm mob-top-btn" aria-label="Retour">
                        <x-mt::icon name="arrow-left" />
                    </button>

                    {{-- Titre de la page --}}
                    <div class="flex justify-start flex-1">
                        @php
                            $pageTitle = null;
                            foreach(getSidebar() as $_item) {
                                if (request()->routeIs(($_item['route'] ?? '').'*')) { $pageTitle = __($_item['label']); break; }
                                foreach(($_item['subItems'] ?? []) as $_sub) {
                                    if (request()->routeIs(($_sub['route'] ?? '').'*')) { $pageTitle = __($_sub['label']); break 2; }
                                }
                            }
                            $pageTitle = $pageTitle ?? mt_config('app_name');
                        @endphp
                    
                        <h1 class="mob-topbar-title truncate max-w-[180px] text-sm font-semibold mt-text">{{ $title ?? '' }}</h1>
                    </div>                
                @endisset
            </div>
        </header>


        {{-- Main --}}
        <main class="flex-1 overflow-y-auto">{{ $slot }}</main>
    </div>

    
    {{-- ============================================================
        MOBILE BOTTOM NAVIGATION
        ============================================================ --}}
    <div x-data="mobileSheetsManager()" 
        x-init="init()"
        class="lg:hidden">
        
        {{-- Barre de navigation mobile --}}
        <nav class="fixed bottom-0 left-0 right-0 z-[9999] mt-bg mob-bottom-nav" 
            style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
            <div class="flex items-center justify-around px-1 mob-nav-bar">

                {{-- Menu --}}
                <button @click="openSheet('menu')"
                        class="mob-nav-item">
                    <div class="mob-nav-pill" :class="activeSheet === 'menu' ? 'active' : ''">
                        <x-mt::icon name="hamburger" />
                    </div>
                    <span class="mob-nav-lbl" :class="activeSheet === 'menu' ? 'on' : ''">Menu</span>
                </button>

                {{-- Recherche  @click="openSheet('search')"--}}
                <button
                        class="mob-nav-item">
                    <div class="mob-nav-pill" :class="activeSheet === 'search' ? 'active' : ''">
                        <x-mt::icon name="magnifying-glass" />
                    </div>
                    <span class="mob-nav-lbl" :class="activeSheet === 'search' ? 'on' : ''">Recherche</span>
                </button>

                {{-- Notifications @click="openSheet('notifications')" --}}
                <button
                        class="mob-nav-item">
                    <div class="relative mob-nav-pill" :class="activeSheet === 'notifications' ? 'active' : ''">
                        <x-mt::icon name="bell" />
                        <span class="mob-notif-dot"></span>
                    </div>
                    <span class="mob-nav-lbl" :class="activeSheet === 'notifications' ? 'on' : ''">Notifs</span>
                </button>

                {{-- Paramètres --}}
                <button @click="openSheet('settings')"
                        class="mob-nav-item">
                    <div class="relative mob-nav-pill" :class="activeSheet === 'settings' ? 'active' : ''">
                        <x-mt::icon name="gear" />
                    </div>
                    <span class="mob-nav-lbl" :class="activeSheet === 'settings' ? 'on' : ''">Paramètres</span>
                </button>

            </div>
        </nav>

        {{-- ============================================================
            SHEET: MENU
            ============================================================ --}}
        <div x-show="activeSheet === 'menu'" class="fixed inset-0 z-[998]" x-cloak>
            
            <!-- Overlay -->
            <div x-show="activeSheet === 'menu'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('menu')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <!-- Sheet Content -->
            <div x-show="activeSheet === 'menu'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="translate-y-full"
                x-transition:enter-end="translate-y-0"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="translate-y-0"
                x-transition:leave-end="translate-y-full"
                class="fixed bottom-[68px] left-0 right-0 rounded-t-3xl shadow-2xl max-h-[85vh] flex flex-col mt-bg"
                style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                
                <!-- Handle -->
                <div class="flex justify-center flex-shrink-0 pt-3 pb-1">
                    <div class="w-12 h-1 rounded-full" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>

                <!-- Header -->
                <div class="flex items-center justify-between flex-shrink-0 px-5 py-4" 
                    style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                    <div class="flex items-center gap-3">
                        <span class="flex items-center justify-center w-10 h-10 text-sm font-bold text-white rounded-xl bg-gradient-to-br from-sky-500 to-sky-800">
                            {{ getInitials(auth()->user()?->fullName()) }}
                        </span>
                        <div>
                            <p class="text-sm font-semibold leading-tight mt-text">{{ auth()->user()?->fullName() }}</p>
                            <p class="text-xs mt-text-muted">{{ auth()->user()?->email }}</p>
                        </div>
                    </div>
                    <button @click="closeSheet('menu')" 
                            class="flex items-center justify-center w-8 h-8 rounded-full mt-btn-icon">
                        <i class="text-xs fa-solid fa-times"></i>
                    </button>
                </div>

                <!-- Navigation items -->
                <div class="flex-1 overflow-y-auto py-2 px-3 space-y-0.5">
                    @foreach(getSidebar() as $_mi)
                        @php
                            $mr    = $_mi['route'] ?? '#';
                            $mic   = $_mi['icon'] ?? 'fa-solid fa-circle';
                            $ml    = $_mi['label'] ?? '';
                            $mc    = $_mi['count'] ?? null;
                            $msub  = $_mi['subItems'] ?? [];
                            $mact  = request()->routeIs($mr.'*') || (!empty($msub) && collect($msub)->contains(fn($s) => request()->routeIs($s['route'].'*')));
                        @endphp
                        @if(!empty($msub))
                            <div x-data="{ o: {{ $mact ? 'true' : 'false' }} }">
                                <button @click="o = !o"
                                        class="flex items-center justify-between w-full px-3 py-3 rounded-xl text-sm font-medium transition-colors {{ $mact ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}">
                                    <div class="flex items-center gap-3">
                                        <span class="w-8 h-8 rounded-xl flex items-center justify-center text-sm {{ $mact ? 'mt-bg-primary' : 'mt-bg-secondary mt-text-muted' }}" style="{{ $mact ? 'color:#fff' : '' }}">
                                            <x-mt::icon name="{{ $mic }}" />
                                        </span>
                                        {!! __($ml) !!}
                                    </div>
                                    <i class="text-xs transition-transform duration-200 fa-solid fa-chevron-down mt-text-muted" :class="{ 'rotate-180': o }"></i>
                                </button>
                                <div x-show="o" x-collapse.duration.150ms class="pl-12 space-y-0.5 pt-0.5">
                                    @foreach($msub as $_si)
                                        @php $sr = $_si['route'] ?? '#'; $sa = request()->routeIs($sr.'*'); $sc = $_si['count'] ?? null; @endphp
                                        <a href="{{ $sr }}" wire:navigate @click="closeSheet('menu')"
                                        class="flex items-center justify-between px-3 py-2.5 rounded-xl text-sm transition-colors {{ $sa ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}">
                                            <div class="flex items-center gap-2.5">
                                                <x-mt::icon name="{{ $_si['icon'] }}" class="w-4 mt-text-muted" />
                                                {!! __($_si['label']) !!}
                                            </div>
                                            @if($sc)<span class="mt-badge mt-badge-info">{{ $sc }}</span>@endif
                                        </a>
                                    @endforeach
                                </div>
                            </div>
                        @else
                            <a href="{{ $mr }}" wire:navigate @click="closeSheet('menu')"
                            class="flex items-center justify-between px-3 py-3 rounded-xl text-sm font-medium transition-colors {{ $mact ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}">
                                <div class="flex items-center gap-3">
                                    <span class="w-8 h-8 rounded-xl flex items-center justify-center text-sm {{ $mact ? 'mt-bg-primary' : 'mt-bg mt-text-muted' }}" style="{{ $mact ? 'color:#fff' : '' }}">
                                        <x-mt::icon name="{{ $mic }}" />
                                    </span>
                                    {!! __($ml) !!}
                                </div>
                                @if($mc)<span class="mt-badge mt-badge-info">{{ $mc }}</span>@endif
                            </a>
                        @endif
                    @endforeach
                </div>

                <!-- Footer -->
                <div class="flex-shrink-0 w-full p-4" style="border-top: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <x-mt::button type="submit" label="Déconnexion" icon="logout" size="sm" class="mt-btn-outline-danger" />
                    </form>
                </div>
            </div>
        </div>

        {{-- ============================================================
            SHEET: RECHERCHE
            ============================================================ --}}
        <div x-show="activeSheet === 'search'" class="fixed inset-0 z-[998]" x-cloak>
            
            <div x-show="activeSheet === 'search'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('search')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <div x-show="activeSheet === 'search'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="translate-y-full"
                x-transition:enter-end="translate-y-0"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="translate-y-0"
                x-transition:leave-end="translate-y-full"
                class="fixed bottom-[68px] left-0 right-0 rounded-t-3xl shadow-2xl max-h-[60vh] mt-bg"
                style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                
                <div class="flex justify-center pt-3 pb-1">
                    <div class="w-12 h-1 rounded-full" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>
                
                <div class="px-5 pt-2 pb-6">
                    <h3 class="mb-3 text-lg font-semibold mt-text">Rechercher</h3>
                    <div class="relative">
                        <x-mt::form.input type="search" 
                            placeholder="Pages, commandes, contacts…"
                            x-model="searchQuery"
                            @keyup.enter="performSearch()"
                            icon="magnifying-glass"
                            />
                    </div>
                    
                    <div x-show="searchResults.length > 0" x-cloak class="mt-4 space-y-2">
                        <template x-for="result in searchResults" :key="result.id">
                            <a :href="result.url" 
                            @click="closeSheet('search')"
                            class="flex items-center gap-3 p-3 transition-colors rounded-xl hover:mt-bg-primary-soft">
                                <i :class="result.icon" class="w-5 text-center mt-text-muted"></i>
                                <div>
                                    <p class="text-sm font-medium mt-text" x-text="result.title"></p>
                                    <p class="text-xs mt-text-muted" x-text="result.description"></p>
                                </div>
                            </a>
                        </template>
                    </div>
                    
                    <div x-show="searchQuery && searchResults.length === 0" x-cloak class="mt-8 text-center">
                        <i class="text-4xl fa-solid fa-search mt-text-muted opacity-30"></i>
                        <p class="mt-2 text-sm mt-text-muted">Aucun résultat trouvé</p>
                    </div>
                </div>
            </div>
        </div>

        {{-- ============================================================
            SHEET: NOTIFICATIONS
            ============================================================ --}}
        <div x-show="activeSheet === 'notifications'" class="fixed inset-0 z-[998]" x-cloak>
            
            <div x-show="activeSheet === 'notifications'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('notifications')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <div x-show="activeSheet === 'notifications'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="translate-y-full"
                x-transition:enter-end="translate-y-0"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="translate-y-0"
                x-transition:leave-end="translate-y-full"
                class="fixed bottom-[68px] left-0 right-0 rounded-t-3xl shadow-2xl max-h-[75vh] flex flex-col mt-bg"
                style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                
                <div class="flex justify-center flex-shrink-0 pt-3 pb-1">
                    <div class="w-12 h-1 rounded-full" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>
                
                <div class="flex items-center justify-between flex-shrink-0 px-5 py-4" 
                    style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                    <h3 class="text-base font-semibold mt-text">Notifications</h3>
                    <span @click="markAllAsRead()" 
                        class="text-xs font-medium transition-opacity cursor-pointer mt-text-primary hover:opacity-80">
                        Tout lire
                    </span>
                </div>
                
                <div class="flex-1 overflow-y-auto divide-y" style="--tw-divide-color: rgba(var(--mt-ui-card-border), 0.4)">
                    <div class="flex items-start gap-3 px-5 py-4 transition-colors hover:mt-bg-primary-soft" 
                        style="background: rgba(var(--mt-info), 0.05)">
                        <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" 
                            style="background: rgba(var(--mt-info), 0.12)">
                            <i class="text-sm fa-solid fa-cart-shopping" style="color: rgb(var(--mt-info))"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium mt-text">Nouvelle commande #1234</p>
                            <p class="text-xs mt-text-muted mt-0.5">Un nouveau client vient de passer commande.</p>
                            <p class="text-[11px] mt-1 font-medium mt-text-primary">Il y a 5 minutes</p>
                        </div>
                        <div class="flex-shrink-0 w-2 h-2 mt-2 rounded-full" style="background: rgb(var(--mt-info))"></div>
                    </div>
                    
                    <div class="flex items-start gap-3 px-5 py-4 transition-colors hover:mt-bg-primary-soft">
                        <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" 
                            style="background: rgba(139,92,246, 0.12)">
                            <i class="text-sm fa-solid fa-comment" style="color: rgb(139,92,246)"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium mt-text">Message de Jean Dupont</p>
                            <p class="text-xs mt-text-muted mt-0.5">Pouvez-vous rappeler dès que possible ?</p>
                            <p class="text-[11px] mt-text-muted mt-1">Il y a 15 minutes</p>
                        </div>
                    </div>
                </div>
                
                <div class="flex-shrink-0 p-4" style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                    <a href="#" @click="closeSheet('notifications')" 
                    class="block w-full py-2.5 text-sm font-medium text-center rounded-xl transition-colors mt-text-primary hover:mt-bg-primary-soft">
                        Voir toutes les notifications
                    </a>
                </div>
            </div>
        </div>

        {{-- ============================================================
            SHEET: PARAMÈTRES
            ============================================================ --}}
        <div x-show="activeSheet === 'settings'" class="fixed inset-0 z-[998]" x-cloak>
            
            <div x-show="activeSheet === 'settings'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('settings')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <div x-show="activeSheet === 'settings'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="translate-y-full"
                x-transition:enter-end="translate-y-0"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="translate-y-0"
                x-transition:leave-end="translate-y-full"
                class="fixed bottom-[68px] left-0 right-0 rounded-t-3xl shadow-2xl max-h-[80vh] flex flex-col mt-bg"
                style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                
                <div class="flex justify-center flex-shrink-0 pt-3 pb-1">
                    <div class="w-12 h-1 rounded-full" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>
                
                <div class="flex items-center justify-between flex-shrink-0 px-5 py-4" 
                    style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                    <h3 class="text-base font-semibold mt-text">Paramètres</h3>
                    <button @click="closeSheet('settings')" 
                            class="flex items-center justify-center w-8 h-8 rounded-full mt-btn-icon">
                        <i class="text-xs fa-solid fa-times"></i>
                    </button>
                </div>
                
                <div class="flex-1 overflow-y-auto divide-y" style="--tw-divide-color: rgba(var(--mt-ui-card-border), 0.4)">

                    @if(mt_has_dark_mode())
                    <!-- Thème -->
                    <div class="flex items-center justify-between px-5 py-4">
                        <div class="flex items-center gap-3">
                            <div class="flex items-center justify-center rounded-full w-9 h-9" 
                                style="background: rgba(var(--mt-primary), 0.12)">
                                <i class="text-sm fa-solid fa-moon" style="color: rgb(var(--mt-primary))"></i>
                            </div>
                            <div>
                                <p class="text-sm font-medium mt-text">Mode sombre</p>
                                <p class="text-xs mt-text-muted">Basculer l'apparence</p>
                            </div>
                        </div>
                        <button @click="toggleTheme()" 
                                class="relative min-w-[44px] h-6 rounded-full transition-all duration-200
                                {{-- Couleurs Light --}}
                                bg-[rgb(var(--mt-ui-card-border))] 
                                {{-- Focus & Checked --}}
                                peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[rgba(var(--mt-success),0.2)] 
                                peer-checked:bg-[rgb(var(--mt-success))]
                                {{-- Thumb (le point blanc via pseudo-élément 'after') --}}
                                after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                                after:bg-white after:rounded-full after:h-5 after:w-5 
                                after:transition-all after:duration-200"
                                :class="darkMode ? 'bg-primary after:translate-x-[20px]' : 'bg-gray-300 after:translate-x-[0px]'">
                            <span class="sr-only">Toggle theme</span>
                            {{-- <span class="inline-block w-4 h-4 transition-transform duration-200 transform bg-white rounded-full" --}}
                                {{-- :class="darkMode ? 'translate-x-6' : 'translate-x-1'"></span> --}}
                        </button>
                        
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- ============================================================
        ALPINE COMPONENT - VERSION CORRIGÉE SANS $watch
        ============================================================ --}}
    <script>
    function mobileSheetsManager() {
        return {
            activeSheet: null,
            searchQuery: '',
            searchResults: [],
            darkMode: document.documentElement.classList.contains('dark'),
            
            init() {
                // console.log('Mobile sheets manager initialized');
                
                // Écouter les changements de classe dark sur le document
                const observer = new MutationObserver((mutations) => {
                    mutations.forEach((mutation) => {
                        if (mutation.attributeName === 'class') {
                            this.darkMode = document.documentElement.classList.contains('dark');
                        }
                    });
                });
                
                observer.observe(document.documentElement, { attributes: true });
            },
            
            openSheet(sheetName) {
                // console.log('Opening sheet:', sheetName);
                
                if (this.activeSheet === sheetName) {
                    this.activeSheet = null;
                } else {
                    this.activeSheet = sheetName;
                    
                    if (sheetName === 'search') {
                        // Reset search when opening
                        this.searchQuery = '';
                        this.searchResults = [];
                        
                        // Focus on search input after animation
                        setTimeout(() => {
                            const input = document.querySelector('input[type="search"]');
                            if (input) input.focus();
                        }, 300);
                    }
                }
            },
            
            closeSheet(sheetName) {
                if (this.activeSheet === sheetName) {
                    this.activeSheet = null;
                }
            },
            
            performSearch() {
                if (!this.searchQuery.trim()) {
                    this.searchResults = [];
                    return;
                }
                
                // Exemple de recherche - À remplacer par votre logique
                const mockResults = [
                    { id: 1, title: 'Tableau de bord', description: 'Accéder au tableau de bord', icon: 'fa-solid fa-chart-line', url: '/dashboard' },
                    { id: 2, title: 'Commandes', description: 'Gérer vos commandes', icon: 'fa-solid fa-shopping-cart', url: '/orders' },
                    { id: 3, title: 'Profile', description: 'Modifier votre profil', icon: 'fa-solid fa-user', url: '/profile' },
                    { id: 4, title: 'Paramètres', description: 'Configuration du compte', icon: 'fa-solid fa-gear', url: '/settings' }
                ];
                
                this.searchResults = mockResults.filter(result => 
                    result.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                    result.description.toLowerCase().includes(this.searchQuery.toLowerCase())
                );
            },
            
            toggleTheme() {
                this.darkMode = !this.darkMode;
                const theme = this.darkMode ? 'dark' : 'light';
                localStorage.setItem('theme', theme);
                
                if (this.darkMode) {
                    document.documentElement.classList.add('dark');
                } else {
                    document.documentElement.classList.remove('dark');
                }
            },
            
            markAllAsRead() {
                // console.log('Toutes les notifications ont été marquées comme lues');
                // Ajoutez votre logique ici
            }
        };
    }
    </script>

    <style>
    [x-cloak] { display: none !important; }

    .bg-primary {
        background-color: rgb(var(--mt-primary));
    }

    .translate-x-1 {
        transform: translateX(0.25rem);
    }

    .translate-x-6 {
        transform: translateX(1.5rem);
    }
    </style>
    
    
    <!-- Modals Livewire -->
    {{-- <livewire:mt.modals.confirm />
    <livewire:mt.modals.alert /> --}}

    @push('styles')
    <style>
        [x-cloak] { display: none !important; }
        html, body { height: 100%; margin: 0; padding: 0; }
        .backdrop-blur-md { backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); }

        .scrollbar-thin::-webkit-scrollbar { width: 6px; }
        .scrollbar-thin::-webkit-scrollbar-track { background: transparent; }
        .scrollbar-thin::-webkit-scrollbar-thumb { background: rgb(var(--mt-ui-card-border)); border-radius: 3px; }
        .scrollbar-thin { scrollbar-width: thin; scrollbar-color: rgb(var(--mt-ui-card-border)) transparent; }

        /* ── Mobile top bar ── */
        .mob-top-btn {
            width: 30px; height: 30px;
            display: flex; align-items: center; justify-content: center;
            border-radius: 12px; border: none; background: transparent;
            cursor: pointer; color: rgb(var(--mt-text)); font-size: 17px;
            transition: background 0.12s, transform 0.1s;
            -webkit-tap-highlight-color: transparent;
            flex-shrink: 0;
        }
        .mob-top-btn:active { background: rgba(var(--mt-text), 0.08); transform: scale(0.88); }

        /* ── Bottom nav ── */
        .mob-bottom-nav {
            height: calc(68px + env(safe-area-inset-bottom, 0px));
        }
        .mob-nav-item {
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            gap: 3px; flex: 1; padding: 6px 2px;
            border: none; background: transparent; cursor: pointer; text-decoration: none;
            -webkit-tap-highlight-color: transparent;
            transition: transform 0.12s ease;
        }
        .mob-nav-item:active { transform: scale(0.88); }

        /* Pill highlight */
        .mob-nav-pill {
            width: 48px; height: 30px; border-radius: 15px;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; color: rgba(var(--mt-text), 0.4);
            transition: background 0.2s, color 0.2s;
        }
        .mob-nav-pill.active {
            background: rgba(var(--mt-primary), 0.12);
            color: rgb(var(--mt-primary));
        }

        /* Label */
        .mob-nav-lbl {
            font-size: 10px; font-weight: 500;
            color: rgba(var(--mt-text), 0.4);
            line-height: 1; transition: color 0.2s;
        }
        .mob-nav-lbl.on { color: rgb(var(--mt-primary)); font-weight: 700; }

        /* Notif dot */
        .mob-notif-dot {
            position: absolute; top: 3px; right: 6px;
            width: 7px; height: 7px;
            background: rgb(var(--mt-danger)); border-radius: 50%;
            border: 1.5px solid rgb(var(--mt-bg));
        }

        /* Main padding on mobile */
        @media (max-width: 1023px) {
            main { padding-bottom: calc(76px + env(safe-area-inset-bottom, 0px)); }
        }
    </style>
    @endpush

    @push('scripts')


    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.directive('collapse', (el) => {
                const d = 200;
                el._x_transition = {
                    enter: (done) => {
                        el.style.height = '0'; el.style.overflow = 'hidden';
                        requestAnimationFrame(() => {
                            el.style.height = el.scrollHeight + 'px';
                            el.style.transition = `height ${d}ms ease-in-out`;
                            setTimeout(() => { el.style.height = ''; el.style.overflow = ''; done(); }, d);
                        });
                    },
                    leave: (done) => {
                        el.style.height = el.scrollHeight + 'px'; el.style.overflow = 'hidden';
                        requestAnimationFrame(() => {
                            el.style.height = '0';
                            el.style.transition = `height ${d}ms ease-in-out`;
                            setTimeout(done, d);
                        });
                    }
                };
            });
        });
    </script>
    @endpush
    </div>


</x-mt::layouts.master>