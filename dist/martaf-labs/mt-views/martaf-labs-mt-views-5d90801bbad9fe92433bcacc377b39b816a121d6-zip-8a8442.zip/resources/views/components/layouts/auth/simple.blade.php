<x-mt::layouts.master>
    <div class="min-h-screen bg-red-500">
        <div class="w-full">
            {{ $slot }}
        </div>
    </div>
</x-mt::layouts.master>
