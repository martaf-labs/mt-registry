<x-mt::layouts.auth.simple :title="$title ?? null">
    {{ $slot }}
</x-mt::layouts.auth.simple>
