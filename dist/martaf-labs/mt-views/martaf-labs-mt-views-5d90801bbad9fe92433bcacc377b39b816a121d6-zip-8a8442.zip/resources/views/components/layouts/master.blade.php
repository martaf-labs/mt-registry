<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}"
    dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}"
    x-data
    class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="@yield('meta_description', mt_config('seo.description'))">

    {{-- ================= SEO ================= --}}
    {{-- <meta property="og:type" content="@yield('og_type', mt_config('seo.og.type'))">
    <meta property="og:url" content="@yield('og_url', url()->current())">
    <meta property="og:site_name" content="@yield('og_site_name', mt_config('seo.og.site_name'))">
    <meta property="og:title" content="@yield('og_title', mt_config('app_name'))">
    <meta property="og:description" content="@yield('og_description', mt_config('seo.description'))">
    <meta property="og:image" content="@yield('og_image', asset(mt_config('assets.logos.jpg')))">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="{{ mt_config('seo.og.twitter_handle') }}">
    <meta name="twitter:title" content="@yield('og_title', mt_config('app_name'))">
    <meta name="twitter:description" content="@yield('og_description', mt_config('seo.description'))">
    <meta name="twitter:image" content="@yield('og_image', asset(mt_config('assets.logos.jpg')))"> --}}

    {{-- ================= FAVICONS ================= --}}
    {{-- <link rel="icon" href="{{ asset(mt_config('assets.favicons.ico')) }}" sizes="any">
    <link rel="icon" href="{{ asset(mt_config('assets.favicons.svg')) }}" type="image/svg+xml">
    <link rel="apple-touch-icon" href="{{ asset(mt_config('assets.favicons.png')) }}">

    <title>@yield('title', $title ?? mt_config('app_name'))</title> --}}



    
    {{-- ══ SEO ═══════════════════════════════════════════════════ --}}
    <title>
        @hasSection('title')
            @yield('title') — {{ mt_config('app_name') }}
        @else
            {{ mt_config('app_name') }}
        @endif
    </title>

    <meta name="description" content="@hasSection('meta_description')
        @yield('meta_description')
    @else
        {{ mt_config('seo.description') ?? "Site d'information et d'analyses." }}
    @endif">

    <meta name="robots" content="index, follow">
    <meta name="author" content="{{  mt_config('app_name') }}">

    <link rel="canonical" href="@hasSection('og_url')
        @yield('og_url')
    @else
        {{ url()->current() }}
    @endif">

    {{-- ══ Open Graph ═════════════════════════════════════════════ --}}
    <meta property="og:type"        content="@hasSection('og_type') @yield('og_type') @else website @endif">
    <meta property="og:site_name"   content="@yield('og_site_name', mt_config('seo.og.site_name'))">
    <meta property="og:locale"      content="{{ str_replace('-', '_', app()->getLocale()) }}">
    <meta property="og:url"         content="@hasSection('og_url') @yield('og_url') @else {{ url()->current() }} @endif">
    <meta property="og:title"       content="@hasSection('og_title') @yield('og_title') @else {{ mt_config('app_name') }} @endif">
    <meta property="og:description" content="@hasSection('og_description') @yield('og_description') @else {{ mt_config('seo.description') ?? "Site d'information et d'analyses." }} @endif">

    @hasSection('og_image')
    <meta property="og:image"        content="@yield('og_image')">
    <meta property="og:image:width"  content="1200">
    <meta property="og:image:height" content="630">
    @endif

    {{-- ══ Twitter Card ═══════════════════════════════════════════ --}}
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:site"        content="{{ mt_config('seo.og.twitter_handle') }}">
    <meta name="twitter:title"       content="@hasSection('og_title') @yield('og_title') @else {{ mt_config('app_name') }} @endif">
    <meta name="twitter:description" content="@hasSection('og_description') @yield('og_description') @else {{ mt_config('seo.description') ?? "Site d'information et d'analyses." }} @endif">

    @hasSection('og_image')
    <meta name="twitter:image" content="@yield('og_image')">
    @endif


    {{-- ================= PACKAGE + PROJECT ASSETS ================= --}}
    @include('mt::partials.assets')

    {{-- ================= FONTS ================= --}}
    @if (mt_config('assets.google_font_url'))
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="{{ mt_config('assets.google_font_url') }}" rel="stylesheet">
    @endif

    @if(mt_has_dark_mode())
    {{-- ================= CRITICAL: DARK MODE ANTI-FLASH ================= --}}
    <script>
        (function () {
            const stored = localStorage.getItem('theme');
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (stored === 'dark' || (!stored && prefersDark)) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        })();
    </script>
    @endif

    {{-- ================= THEME VARS (PHP → CSS variables) ================= --}}
    <style>
        :root {
            --mt-light-primary:   {{ hexaToRgb(mt_config('colors.light.primary')) }};
            --mt-light-secondary: {{ hexaToRgb(mt_config('colors.light.secondary')) }};
            --mt-light-bg:        {{ hexaToRgb(mt_config('colors.light.bg')) }};
            --mt-light-text:      {{ hexaToRgb(mt_config('colors.light.text')) }};

            --mt-dark-primary:    {{ hexaToRgb(mt_config('colors.dark.primary')) }};
            --mt-dark-secondary:  {{ hexaToRgb(mt_config('colors.dark.secondary')) }};
            --mt-dark-bg:         {{ hexaToRgb(mt_config('colors.dark.bg')) }};
            --mt-dark-text:       {{ hexaToRgb(mt_config('colors.dark.text')) }};

            --font-mt-heading: {!! hexaToRgb(mt_config('assets.font_heading')) !!};
            --font-mt-body:    {!! hexaToRgb(mt_config('assets.font_body')) !!};

            /* paddings */
            --xs-padding: 0.375rem 0.75rem;
            --sm-padding: 0.4rem 0.8rem;
            --md-padding: 0.425rem 1.25rem;
            --lg-padding: 0.75rem 1.5rem;
            --xl-padding: 1rem 2rem;
            --2xl-padding: 1.5rem;

            /* font-sizes */
            --xs-fs: 0.75rem;
            --sm-fs: 0.875rem;
            --md-fs: 1rem;
            --lg-fs: 1.125rem;
            --xl-fs: 1.25rem;
            --2xl-fs: 1.5rem;
            
            /* Nouvelles variables Tailwind-like */
            --mt-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --mt-shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --mt-shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --mt-shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
            --mt-shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
            
            --mt-animation-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
            --mt-animation-smooth: cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Vos styles CSS existants restent identiques */
        :root {
            --mt-primary:   var(--mt-light-primary);
            --mt-secondary: var(--mt-light-secondary);
            --mt-bg:        var(--mt-light-bg);
            --mt-text:      var(--mt-light-text);
            --mt-ui-card-bg:      255, 255, 255;
            --mt-ui-card-border:  229, 229, 229;
            --mt-ui-input-bg:     255, 255, 255;
            --mt-ui-input-border: 212, 212, 212;
            --mt-danger:   239, 68,  68;
            --mt-success:  34,  197, 94;
            --mt-warning:  245, 158, 11;
            --mt-info:     59,  130, 246;
            --mt-space-xs:  0.25rem;
            --mt-space-sm:  0.5rem;
            --mt-space-md:  1rem;
            --mt-space-lg:  1.5rem;
            --mt-space-xl:  2rem;
            --mt-space-2xl: 3rem;
            --mt-radius-sm:   0.35rem;
            --mt-radius-md:   0.5rem;
            --mt-radius-lg:   0.75rem;
            --mt-radius-xl:   1rem;
            --mt-radius-2xl:  1.5rem;
            --mt-radius-full: 999px;
            --mt-transition:      0.2s ease;
            --mt-transition-slow: 0.35s ease;
            --mt-transition-smooth: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .dark {
            --mt-primary:   var(--mt-dark-primary);
            --mt-secondary: var(--mt-dark-secondary);
            --mt-bg:        var(--mt-dark-bg);
            --mt-text:      var(--mt-dark-text);
            --mt-ui-card-bg:      var(--mt-dark-bg);
            --mt-ui-card-border:  50 50 50;
            --mt-ui-input-bg:     var(--mt-dark-bg);
            --mt-ui-input-border: var(--mt-ui-card-border);
        }

        body {
            box-sizing:       border-box;
            font-family:      var(--font-mt-body);
            background-color: rgb(var(--mt-bg));
            color:            rgb(var(--mt-text));
            scroll-behavior:  smooth;
            transition:       var(--mt-transition-smooth);
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        
        *,
        *::before,
        *::after {
            box-sizing: inherit;
        }

        h1, h2, h3, h4, .font-heading {
            font-family: var(--font-mt-heading);
        }

        /* =============================================================
        MT-VIEWS — CLASSES UTILITAIRES STYLE TAILWIND
        ============================================================= */

        /* -------------------------------------------------------------
        1. TYPOGRAPHIE AMÉLIORÉE
        ------------------------------------------------------------- */
        .mt-h1 {
            font-family:     var(--font-mt-heading);
            font-size:       2.25rem;
            font-weight:     700;
            color:           rgb(var(--mt-text));
            line-height:     1.2;
            letter-spacing:  -0.02em;
        }
        .mt-h2 {
            font-family:     var(--font-mt-heading);
            font-size:       1.875rem;
            font-weight:     600;
            color:           rgb(var(--mt-text));
            line-height:     1.3;
            letter-spacing:  -0.015em;
        }
        .mt-h3 {
            font-family:     var(--font-mt-heading);
            font-size:       1.5rem;
            font-weight:     600;
            color:           rgb(var(--mt-text));
            line-height:     1.4;
        }
        .mt-h4 {
            font-family:     var(--font-mt-heading);
            font-size:       1.25rem;
            font-weight:     600;
            color:           rgb(var(--mt-text));
            line-height:     1.5;
        }

        .mt-text         { color: rgb(var(--mt-text)); font-family: var(--font-mt-body); }
        .mt-text-secondary { color: rgb(var(--mt-secondary)); }
        .mt-text-primary { color: rgb(var(--mt-primary)); }
        .mt-text-muted   { color: rgba(var(--mt-text), 0.65); }
        .mt-text-danger  { color: rgb(var(--mt-danger)); }
        .mt-text-success { color: rgb(var(--mt-success)); }
        .mt-text-warning { color: rgb(var(--mt-warning)); }
        .mt-text-info    { color: rgb(var(--mt-info)); }

        .mt-text-xs { font-size: var(--xs-fs); line-height: calc(1 / 0.75); }
        .mt-text-sm { font-size: var(--sm-fs); line-height: calc(1.25 / 0.875); }
        .mt-text-md { font-size: var(--md-fs); line-height: calc(1.5 / 1); }
        .mt-text-lg { font-size: var(--lg-fs); line-height: calc(1.75 / 1.125); }
        .mt-text-xl { font-size: var(--xl-fs); line-height: calc(1.75 / 1.25); }
        .mt-text-2xl { font-size: var(--2xl-fs); line-height: calc(2 / 1.5); }

        .mt-font-light   { font-weight: 300; }
        .mt-font-normal  { font-weight: 400; }
        .mt-font-medium  { font-weight: 500; }
        .mt-font-semibold { font-weight: 600; }
        .mt-font-bold    { font-weight: 700; }

        /* -------------------------------------------------------------
        2. BACKGROUNDS AMÉLIORÉS
        ------------------------------------------------------------- */
        .mt-bg           { background-color: rgb(var(--mt-bg)) !important; }
        .mt-bg-primary   { background-color: rgb(var(--mt-primary)); }
        .mt-bg-secondary { background-color: rgb(var(--mt-secondary)); }
        .mt-bg-card      { background-color: rgb(var(--mt-ui-card-bg)); }
        .mt-bg-danger    { background-color: rgba(var(--mt-danger),  0.12); }
        .mt-bg-success   { background-color: rgba(var(--mt-success), 0.12); }
        .mt-bg-warning   { background-color: rgba(var(--mt-warning), 0.12); }
        .mt-bg-info      { background-color: rgba(var(--mt-info),    0.12); }
        /* soft */
        .mt-bg-card-soft  { background-color: rgba(var(--mt-ui-card-bg), 0.08); }
        .mt-bg-primary-soft  { background-color: rgba(var(--mt-primary), 0.08); }
        .mt-bg-secondary-soft  { background-color: rgba(var(--mt-secondary), 0.08); }

        /* light */
        .mt-bg-card-light  { background-color: rgba(var(--mt-ui-card-bg), 0.15); }
        .mt-bg-primary-light { background-color: rgba(var(--mt-primary), 0.15); }
        .mt-bg-secondary-light { background-color: rgba(var(--mt-secondary), 0.15); }
        
        /* Nouveaux fonds avec opacité */
        .mt-bg-primary\/10 { background-color: rgba(var(--mt-primary), 0.1); }
        .mt-bg-primary\/20 { background-color: rgba(var(--mt-primary), 0.2); }
        .mt-bg-primary\/30 { background-color: rgba(var(--mt-primary), 0.3); }

        /* -------------------------------------------------------------
        3. BORDERS & SHADOWS
        ------------------------------------------------------------- */
        .mt-border         { border: 1px solid rgb(var(--mt-ui-card-border)); }
        .mt-border-2       { border: 2px solid rgb(var(--mt-ui-card-border)); }
        .mt-border-primary { border-color: rgb(var(--mt-primary)); }
        .mt-border-danger  { border-color: rgb(var(--mt-danger)); }
        .mt-border-success { border-color: rgb(var(--mt-success)); }
        .mt-border-warning { border-color: rgb(var(--mt-warning)); }
        
        .mt-border-t       { border-top: 1px solid rgb(var(--mt-ui-card-border)); }
        .mt-border-r       { border-right: 1px solid rgb(var(--mt-ui-card-border)); }
        .mt-border-b       { border-bottom: 1px solid rgb(var(--mt-ui-card-border)); }
        .mt-border-l       { border-left: 1px solid rgb(var(--mt-ui-card-border)); }

        .mt-rounded-sm   { border-radius: var(--mt-radius-sm); }
        .mt-rounded      { border-radius: var(--mt-radius-md); }
        .mt-rounded-md   { border-radius: var(--mt-radius-md); }
        .mt-rounded-lg   { border-radius: var(--mt-radius-lg); }
        .mt-rounded-xl   { border-radius: var(--mt-radius-xl); }
        .mt-rounded-2xl  { border-radius: var(--mt-radius-2xl); }
        .mt-rounded-full { border-radius: var(--mt-radius-full); }
        
        /* Ombres style Tailwind */
        .mt-shadow-sm  { box-shadow: var(--mt-shadow-sm); }
        .mt-shadow     { box-shadow: var(--mt-shadow-md); }
        .mt-shadow-md  { box-shadow: var(--mt-shadow-md); }
        .mt-shadow-lg  { box-shadow: var(--mt-shadow-lg); }
        .mt-shadow-xl  { box-shadow: var(--mt-shadow-xl); }
        .mt-shadow-2xl { box-shadow: var(--mt-shadow-2xl); }
        .mt-shadow-none { box-shadow: none; }
        
        .mt-shadow-primary { box-shadow: 0 0 0 3px rgba(var(--mt-primary), 0.15); }
        .mt-shadow-danger  { box-shadow: 0 0 0 3px rgba(var(--mt-danger), 0.15); }
        .mt-shadow-success { box-shadow: 0 0 0 3px rgba(var(--mt-success), 0.15); }

        /* -------------------------------------------------------------
        4. BOUTONS STYLE TAILWIND
        ------------------------------------------------------------- */
        .mt-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            /* gap: 0.5rem; */
            font-family: var(--font-mt-body);
            /* font-weight: 500; */
            /* line-height: 1.5; */
            /* padding: 0.625rem 1.25rem; */
            border: 1px solid transparent;
            border-radius: var(--mt-radius-lg);
            cursor: pointer;
            text-decoration: none;
            white-space: nowrap;
            transition: var(--mt-transition-smooth);
            position: relative;
            overflow: hidden;
        }
        
        /* Effet ripple style Tailwind */
        .mt-btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .mt-btn:active::before {
            width: 200%;
            height: 200%;
        }
        
        .mt-btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.05);
        }
        
        .mt-btn:active {
            transform: translateY(0);
            filter: brightness(0.98);
        }
        
        .mt-btn:disabled,
        .mt-btn[disabled] {
            opacity: 0.5;
            cursor: not-allowed;
            pointer-events: none;
            transform: none;
        }

        /* Tailles Tailwind-like */
        .mt-btn-xs { padding: var(--xs-padding); font-size: var(--mt-text-xs); border-radius: var(--mt-radius-sm); }
        .mt-btn-sm { padding: var(--sm-padding); font-size: var(--sm-fs); border-radius: var(--mt-radius-md); }
        .mt-btn-md { padding: var(--md-padding); font-size: var(--mt-text-md); border-radius: var(--mt-radius-md) }
        .mt-btn-lg { padding: var(--lg-padding); font-size: var(--mt-text-lg); border-radius: var(--mt-radius-lg); }
        .mt-btn-xl { padding: var(--xl-padding); font-size: var(--mt-text-xl); border-radius: var(--mt-radius-lg); }
        .mt-btn-block { width: 100%; justify-content: center; }

        /* Variantes couleur améliorées */
        .mt-btn-primary {
            background-color: rgb(var(--mt-primary));
            border-color: rgb(var(--mt-primary));
            color: #fff;
            box-shadow: var(--mt-shadow-sm);
        }
        .mt-btn-primary:hover {
            background-color: rgba(var(--mt-primary), 0.9);
            box-shadow: var(--mt-shadow-md);
        }
        
        .mt-btn-secondary {
            background-color: rgb(var(--mt-secondary));
            border-color: rgb(var(--mt-secondary));
            color: rgb(var(--mt-dark-text));
            box-shadow: var(--mt-shadow-sm);
        }
        
        .mt-btn-danger {
            background-color: rgb(var(--mt-danger));
            border-color: rgb(var(--mt-danger));
            color: #fff;
        }
        .mt-btn-danger:hover {
            background-color: rgba(var(--mt-danger), 0.9);
        }
        
        .mt-btn-success {
            background-color: rgb(var(--mt-success));
            border-color: rgb(var(--mt-success));
            color: #fff;
        }
        
        .mt-btn-warning {
            background-color: rgb(var(--mt-warning));
            border-color: rgb(var(--mt-warning));
            color: #1a1a1a;
        }
        
        .mt-btn-info {
            background-color: rgb(var(--mt-info));
            border-color: rgb(var(--mt-info));
            color: #fff;
        }

        /* Outline style Tailwind */
        .mt-btn-outline {
            background-color: transparent;
            border-color: rgb(var(--mt-bg-card));
            color: rgb(var(--mt-bg-card));
            box-shadow: none;
        }
        .mt-btn-outline:hover {
            background-color: rgba(var(--mt-bg-card), 0.1);
            border-color: rgb(var(--mt-bg-card));
            color: rgb(var(--mt-bg-card));
            transform: translateY(-1px);
        }
        
        .mt-btn-outline-danger {
            background-color: transparent;
            border-color: rgb(var(--mt-danger));
            color: rgb(var(--mt-danger));
        }
        .mt-btn-outline-danger:hover {
            background-color: rgba(var(--mt-danger), 0.1);
            color: rgb(var(--mt-danger));
        }

        /* Ghost style Tailwind */
        .mt-btn-ghost {
            background-color: transparent;
            border-color: transparent;
            color: rgb(var(--mt-primary));
            box-shadow: none;
        }
        .mt-btn-ghost:hover {
            background-color: rgba(var(--mt-primary), 0.1);
            transform: translateY(-1px);
        }
        
        .mt-btn-ghost-muted {
            background-color: transparent;
            border-color: transparent;
            color: rgba(var(--mt-text), 0.65);
        }
        .mt-btn-ghost-muted:hover {
            background-color: rgba(var(--mt-text), 0.08);
            color: rgb(var(--mt-text));
        }

        /* Boutons icônes */
        .mt-btn-icon {
            padding: 0.625rem;
            background-color: transparent;
            border-color: transparent;
            color: rgb(var(--mt-text));
            border-radius: var(--mt-radius-md);
            line-height: 1;
            text-align:center;
        }
        .mt-btn-icon:hover {
            background-color: rgba(var(--mt-primary), 0.1);
            /* transform: scale(1.05); */
        }
        .mt-btn-icon-sm { padding: var(--sm-padding); font-size: var(--sm-fs); }
        .mt-btn-icon-lg { padding: var(--lg-padding); }

        /* -------------------------------------------------------------
        5. FORMULAIRES STYLE TAILWIND
        ------------------------------------------------------------- */
        .mt-label {
            display: flex;
            font-size: 0.875rem;
            font-weight: 500;
            color: rgb(var(--mt-text));
            margin-bottom: 0.5rem;
        }
        .mt-label-required::after {
            content: ' *';
            color: rgb(var(--mt-danger));
        }

        .mt-input,
        .mt-select,
        .mt-textarea {
            width: 100%;
            background-color: rgb(var(--mt-ui-input-bg));
            border: 1px solid rgb(var(--mt-ui-input-border));
            border-radius: var(--mt-radius-md);
            padding: 0.625rem 0.875rem;
            font-size: 0.9375rem;
            font-family: var(--font-mt-body);
            color: rgb(var(--mt-text));
            outline: none;
            transition: var(--mt-transition-smooth);
            appearance: none;
        }
        
        .mt-input:hover,
        .mt-select:hover,
        .mt-textarea:hover {
            border-color: rgba(var(--mt-primary), 0.5);
        }
        
        .mt-input:focus,
        .mt-select:focus,
        .mt-textarea:focus {
            border-color: rgb(var(--mt-primary));
            box-shadow: 0 0 0 3px rgba(var(--mt-primary), 0.15);
            outline: none;
        }
        
        .mt-input:disabled,
        .mt-select:disabled,
        .mt-textarea:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background-color: rgba(var(--mt-ui-input-bg), 0.5);
        }
        
        .mt-input-error,
        .mt-select-error,
        .mt-textarea-error { 
            border-color: rgb(var(--mt-danger)); 
        }
        .mt-input-error:focus,
        .mt-select-error:focus,
        .mt-textarea-error:focus {
            border-color: rgb(var(--mt-danger));
            box-shadow: 0 0 0 3px rgba(var(--mt-danger), 0.15);
        }

        /* Tailles des inputs */
        .mt-input-sm, .mt-select-sm { 
            padding: 0.375rem 0.75rem; 
            font-size: 0.875rem; 
        }
        .mt-input-lg, .mt-select-lg { 
            padding: 0.75rem 1rem;   
            font-size: 1rem; 
        }

        .mt-textarea { 
            resize: vertical; 
            min-height: 100px; 
        }

        /* Checkbox & Radio style Tailwind */
        .mt-checkbox,
        .mt-radio {
            width: 1rem;
            height: 1rem;
            accent-color: rgb(var(--mt-primary));
            cursor: pointer;
            flex-shrink: 0;
            transition: var(--mt-transition);
        }
        
        .mt-checkbox:hover,
        .mt-radio:hover {
            transform: scale(1.05);
        }

        /* Input groups */
        .mt-form-group { 
            display: flex; 
            flex-direction: column; 
            gap: 0.5rem; 
        }
        .mt-input-group { 
            display: flex; 
            align-items: stretch; 
        }
        .mt-input-addon {
            display: flex;
            align-items: center;
            padding: 0 0.875rem;
            background-color: rgb(var(--mt-ui-card-border));
            border: 1px solid rgb(var(--mt-ui-input-border));
            color: rgb(var(--mt-text));
            font-size: 0.875rem;
            white-space: nowrap;
        }
        .mt-input-addon:first-child {
            border-right: none;
            border-radius: var(--mt-radius-md) 0 0 var(--mt-radius-md);
        }
        .mt-input-addon:last-child {
            border-left: none;
            border-radius: 0 var(--mt-radius-md) var(--mt-radius-md) 0;
        }
        .mt-input-group .mt-input { 
            border-radius: 0; 
            flex: 1; 
        }
        .mt-input-group .mt-input:first-child { border-radius: var(--mt-radius-md) 0 0 var(--mt-radius-md); }
        .mt-input-group .mt-input:last-child { border-radius: 0 var(--mt-radius-md) var(--mt-radius-md) 0; }

        .mt-hint { 
            font-size: 0.75rem; 
            color: rgba(var(--mt-text), 0.55); 
            margin-top: 0.25rem;
        }
        .mt-error { 
            font-size: 0.75rem; 
            color: rgb(var(--mt-danger)); 
            margin-top: 0.25rem;
        }
        .mt-success-msg { 
            font-size: 0.75rem; 
            color: rgb(var(--mt-success)); 
            margin-top: 0.25rem;
        }

        /* -------------------------------------------------------------
        6. CARDS STYLE TAILWIND
        ------------------------------------------------------------- */
        .mt-card {
            background-color: rgb(var(--mt-ui-card-bg));
            border: 1px solid rgb(var(--mt-ui-card-border));
            border-radius: var(--mt-radius-lg);
            padding: var(--mt-space-lg);
            transition: var(--mt-transition-smooth);
        }
        .mt-card-sm   { padding: var(--mt-space-md); border-radius: var(--mt-radius-md); }
        .mt-card-lg   { padding: var(--mt-space-xl); border-radius: var(--mt-radius-xl); }
        .mt-card-flat { border: none; box-shadow: none; }
        
        .mt-card-header {
            padding-bottom: var(--mt-space-md);
            margin-bottom: var(--mt-space-md);
            border-bottom: 1px solid rgb(var(--mt-ui-card-border));
        }
        .mt-card-footer {
            padding-top: var(--mt-space-md);
            margin-top: var(--mt-space-md);
            border-top: 1px solid rgb(var(--mt-ui-card-border));
        }
        .mt-card-hover {
            cursor: pointer;
            transition: var(--mt-transition-smooth);
        }
        .mt-card-hover:hover {
            transform: translateY(-4px);
            box-shadow: var(--mt-shadow-lg);
            border-color: rgba(var(--mt-primary), 0.3);
        }

        /* -------------------------------------------------------------
        7. BADGES STYLE TAILWIND
        ------------------------------------------------------------- */
        .mt-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.375rem;
            padding: 0.25rem 0.75rem;
            border-radius: var(--mt-radius-full);
            font-size: 0.75rem;
            font-weight: 500;
            line-height: 1.25;
            white-space: nowrap;
            transition: var(--mt-transition);
        }
        .mt-badge-sm { padding: 0.125rem 0.625rem; font-size: 0.6875rem; }
        .mt-badge-lg { padding: 0.375rem 1rem; font-size: 0.875rem; }

        .mt-badge-primary { background-color: rgba(var(--mt-primary), 0.12); color: rgb(var(--mt-primary)); }
        .mt-badge-success { background-color: rgba(var(--mt-success), 0.12); color: rgb(var(--mt-success)); }
        .mt-badge-danger  { background-color: rgba(var(--mt-danger), 0.12); color: rgb(var(--mt-danger)); }
        .mt-badge-warning { background-color: rgba(var(--mt-warning), 0.12); color: rgb(var(--mt-warning)); }
        .mt-badge-info    { background-color: rgba(var(--mt-info), 0.12); color: rgb(var(--mt-info)); }
        .mt-badge-gray    { background-color: rgb(var(--mt-ui-card-border)); color: rgb(var(--mt-text)); }
        
        .mt-badge-dot::before {
            content: '';
            display: inline-block;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: currentColor;
        }

        /* -------------------------------------------------------------
        8. ALERTES STYLE TAILWIND
        ------------------------------------------------------------- */
        .mt-alert {
            display: flex;
            gap: 0.75rem;
            align-items: flex-start;
            padding: 1rem;
            border-radius: var(--mt-radius-lg);
            font-size: 0.9375rem;
            line-height: 1.5;
            transition: var(--mt-transition);
        }
        .mt-alert-info {
            background-color: rgba(var(--mt-info), 0.1);
            border: 1px solid rgba(var(--mt-info), 0.2);
            color: rgb(var(--mt-info));
        }
        .mt-alert-success {
            background-color: rgba(var(--mt-success), 0.1);
            border: 1px solid rgba(var(--mt-success), 0.2);
            color: rgb(var(--mt-success));
        }
        .mt-alert-danger {
            background-color: rgba(var(--mt-danger), 0.1);
            border: 1px solid rgba(var(--mt-danger), 0.2);
            color: rgb(var(--mt-danger));
        }
        .mt-alert-warning {
            background-color: rgba(var(--mt-warning), 0.1);
            border: 1px solid rgba(var(--mt-warning), 0.2);
            color: rgb(var(--mt-warning));
        }
        .mt-alert-title { font-weight: 600; margin-bottom: 0.25rem; }

        /* -------------------------------------------------------------
        9. LAYOUT & CONTAINERS
        ------------------------------------------------------------- */
        .mt-container { 
            width: 100%; 
            max-width: 1280px; 
            margin: 0 auto; 
            padding: 0 var(--mt-space-lg); 
        }
        .mt-container-sm { max-width: 640px; }
        .mt-container-md { max-width: 768px; }
        .mt-container-lg { max-width: 1024px; }
        .mt-container-xl { max-width: 1280px; }
        .mt-container-2xl { max-width: 1536px; }

        .mt-section    { padding: var(--mt-space-2xl) 0; }
        .mt-section-sm { padding: var(--mt-space-xl) 0; }
        .mt-section-lg { padding: calc(var(--mt-space-2xl) * 2) 0; }

        .mt-divider {
            border: none;
            border-top: 1px solid rgb(var(--mt-ui-card-border));
            margin: var(--mt-space-lg) 0;
        }
        .mt-divider-vertical {
            border: none;
            border-left: 1px solid rgb(var(--mt-ui-card-border));
            align-self: stretch;
            margin: 0 var(--mt-space-md);
        }

        /* Flex & Grid utilities */
        .mt-flex { display: flex; }
        .mt-inline-flex { display: inline-flex; }
        .mt-grid { display: grid; }
        .mt-block { display: block; }
        .mt-inline-block { display: inline-block; }
        .mt-hidden { display: none; }
        
        .mt-flex-col { flex-direction: column; }
        .mt-flex-row { flex-direction: row; }
        .mt-flex-wrap { flex-wrap: wrap; }
        
        .mt-justify-start { justify-content: flex-start; }
        .mt-justify-end { justify-content: flex-end; }
        .mt-justify-center { justify-content: center; }
        .mt-justify-between { justify-content: space-between; }
        .mt-justify-around { justify-content: space-around; }
        
        .mt-items-start { align-items: flex-start; }
        .mt-items-end { align-items: flex-end; }
        .mt-items-center { align-items: center; }
        .mt-items-stretch { align-items: stretch; }
        
        .mt-gap-0 { gap: 0; }
        .mt-gap-1 { gap: 0.25rem; }
        .mt-gap-2 { gap: 0.5rem; }
        .mt-gap-3 { gap: 0.75rem; }
        .mt-gap-4 { gap: 1rem; }
        .mt-gap-5 { gap: 1.25rem; }
        .mt-gap-6 { gap: 1.5rem; }

        /* -------------------------------------------------------------
        10. TABLES STYLE TAILWIND
        ------------------------------------------------------------- */
        .mt-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9375rem;
            color: rgb(var(--mt-text));
        }
        .mt-table th {
            text-align: left;
            font-weight: 600;
            font-size: 0.8125rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: rgba(var(--mt-text), 0.7);
            padding: 0.75rem 1rem;
            border-bottom: 1px solid rgb(var(--mt-ui-card-border));
        }
        .mt-table td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid rgb(var(--mt-ui-card-border));
            vertical-align: middle;
        }
        .mt-table tbody tr:last-child td { border-bottom: none; }
        .mt-table-hover tbody tr {
            transition: var(--mt-transition);
        }
        .mt-table-hover tbody tr:hover {
            background-color: rgba(var(--mt-primary), 0.04);
        }
        .mt-table-sm th,
        .mt-table-sm td { padding: 0.5rem 0.75rem; font-size: 0.875rem; }
        
        .mt-table-striped tbody tr:nth-child(odd) {
            background-color: rgba(var(--mt-ui-card-border), 0.3);
        }

        /* -------------------------------------------------------------
        11. SPACING UTILITAIRES
        ------------------------------------------------------------- */
        /* Padding */
        .mt-p-0 { padding: 0; }
        .mt-p-1 { padding: var(--mt-space-xs); }
        .mt-p-2 { padding: var(--mt-space-sm); }
        .mt-p-3 { padding: var(--mt-space-md); }
        .mt-p-4 { padding: var(--mt-space-lg); }
        .mt-p-5 { padding: var(--mt-space-xl); }
        .mt-p-6 { padding: var(--mt-space-2xl); }
        
        .mt-px-0 { padding-left: 0; padding-right: 0; }
        .mt-px-1 { padding-left: var(--mt-space-xs); padding-right: var(--mt-space-xs); }
        .mt-px-2 { padding-left: var(--mt-space-sm); padding-right: var(--mt-space-sm); }
        .mt-px-3 { padding-left: var(--mt-space-md); padding-right: var(--mt-space-md); }
        .mt-px-4 { padding-left: var(--mt-space-lg); padding-right: var(--mt-space-lg); }
        .mt-px-5 { padding-left: var(--mt-space-xl); padding-right: var(--mt-space-xl); }
        .mt-px-6 { padding-left: var(--mt-space-2xl); padding-right: var(--mt-space-2xl); }
        
        .mt-py-0 { padding-top: 0; padding-bottom: 0; }
        .mt-py-1 { padding-top: var(--mt-space-xs); padding-bottom: var(--mt-space-xs); }
        .mt-py-2 { padding-top: var(--mt-space-sm); padding-bottom: var(--mt-space-sm); }
        .mt-py-3 { padding-top: var(--mt-space-md); padding-bottom: var(--mt-space-md); }
        .mt-py-4 { padding-top: var(--mt-space-lg); padding-bottom: var(--mt-space-lg); }
        .mt-py-5 { padding-top: var(--mt-space-xl); padding-bottom: var(--mt-space-xl); }
        .mt-py-6 { padding-top: var(--mt-space-2xl); padding-bottom: var(--mt-space-2xl); }
        
        /* Margin */
        .mt-m-0 { margin: 0; }
        .mt-m-1 { margin: var(--mt-space-xs); }
        .mt-m-2 { margin: var(--mt-space-sm); }
        .mt-m-3 { margin: var(--mt-space-md); }
        .mt-m-4 { margin: var(--mt-space-lg); }
        .mt-m-5 { margin: var(--mt-space-xl); }
        .mt-m-6 { margin: var(--mt-space-2xl); }
        
        .mt-mx-auto { margin-left: auto; margin-right: auto; }
        .mt-my-auto { margin-top: auto; margin-bottom: auto; }

        /* -------------------------------------------------------------
        12. ANIMATIONS & TRANSITIONS
        ------------------------------------------------------------- */
        .mt-transition { transition: var(--mt-transition-smooth); }
        .mt-transition-all { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .mt-transition-colors { transition: background-color 0.2s, border-color 0.2s, color 0.2s; }
        .mt-transition-transform { transition: transform 0.2s; }
        
        .mt-scale-95:hover { transform: scale(0.95); }
        .mt-scale-105:hover { transform: scale(1.05); }
        .mt-rotate-90 { transform: rotate(90deg); }
        .mt-rotate-180 { transform: rotate(180deg); }
        
        /* Skeleton loader */
        .mt-skeleton {
            background: linear-gradient(
                90deg,
                rgb(var(--mt-ui-card-border)) 25%,
                rgba(var(--mt-ui-card-border), 0.8) 50%,
                rgb(var(--mt-ui-card-border)) 75%
            );
            background-size: 200% 100%;
            animation: mt-skeleton-loading 1.5s ease-in-out infinite;
            border-radius: var(--mt-radius-md);
        }
        @keyframes mt-skeleton-loading {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
        
        /* Spinner */
        .mt-spinner {
            width: 1.25rem;
            height: 1.25rem;
            border: 2px solid rgba(var(--mt-primary), 0.2);
            border-top-color: rgb(var(--mt-primary));
            border-radius: 50%;
            animation: mt-spin 0.6s linear infinite;
            display: inline-block;
            flex-shrink: 0;
        }
        .mt-spinner-sm { width: 0.875rem; height: 0.875rem; border-width: 1.5px; }
        .mt-spinner-lg { width: 1.75rem; height: 1.75rem; border-width: 2.5px; }
        @keyframes mt-spin {
            to { transform: rotate(360deg); }
        }
        
        /* Overlay */
        .mt-overlay {
            position: fixed;
            inset: 0;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            z-index: 9999;
            animation: mt-fade-in 0.2s ease;
        }
        @keyframes mt-fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* -------------------------------------------------------------
        13. ACCESSIBILITÉ & UTILITAIRES
        ------------------------------------------------------------- */
        .mt-sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
        
        .mt-focus-ring:focus-visible {
            outline: 2px solid rgb(var(--mt-primary));
            outline-offset: 2px;
            border-radius: var(--mt-radius-sm);
        }
        
        .mt-cursor-pointer { cursor: pointer; }
        .mt-cursor-not-allowed { cursor: not-allowed; }
        .mt-select-none { user-select: none; }
        .mt-pointer-events-none { pointer-events: none; }
        
        .mt-relative { position: relative; }
        .mt-absolute { position: absolute; }
        .mt-fixed { position: fixed; }
        .mt-sticky { position: sticky; }
        
        .mt-inset-0 { top: 0; right: 0; bottom: 0; left: 0; }
        .mt-top-0 { top: 0; }
        .mt-right-0 { right: 0; }
        .mt-bottom-0 { bottom: 0; }
        .mt-left-0 { left: 0; }
        
        .mt-z-10 { z-index: 10; }
        .mt-z-20 { z-index: 20; }
        .mt-z-30 { z-index: 30; }
        .mt-z-40 { z-index: 40; }
        .mt-z-50 { z-index: 50; }
        
        .mt-w-full { width: 100%; }
        .mt-h-full { height: 100%; }
        .mt-min-h-screen { min-height: 100vh; }
        
        .mt-overflow-hidden { overflow: hidden; }
        .mt-overflow-auto { overflow: auto; }
        .mt-overflow-scroll { overflow: scroll; }

        /* Media queries */
        @media (prefers-reduced-motion: reduce) {
            .mt-btn,
            .mt-card-hover,
            .mt-input,
            .mt-select,
            .mt-textarea,
            .mt-skeleton,
            .mt-spinner,
            body,
            * {
                transition: none !important;
                animation: none !important;
            }
        }
        
        /* Responsive text */
        @media (max-width: 768px) {
            .mt-h1 { font-size: 1.875rem; }
            .mt-h2 { font-size: 1.5rem; }
            .mt-h3 { font-size: 1.25rem; }
            .mt-container { padding: 0 var(--mt-space-md); }
        }
    </style>

    <x-mt::head.tinymce-config />

    @if(mt_has_dark_mode())
    {{-- ================= ALPINE THEME MANAGER CORRIGÉ ================= --}}
    <script>
        // Fonction globale pour appliquer le thème
        window.applyTheme = function(theme) {
            if (theme === 'dark') {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        };

        // Fonction pour obtenir le thème actuel
        window.getCurrentTheme = function() {
            const stored = localStorage.getItem('theme');
            if (stored) return stored;
            return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        };

        document.addEventListener('alpine:init', () => {
            Alpine.data('themeManager', () => ({
                darkMode: document.documentElement.classList.contains('dark'),

                init() {
                    // Initialiser depuis localStorage ou préférence système
                    const savedTheme = localStorage.getItem('theme');
                    if (savedTheme) {
                        this.darkMode = savedTheme === 'dark';
                    } else {
                        this.darkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
                    }
                    
                    // Appliquer le thème initial
                    window.applyTheme(this.darkMode ? 'dark' : 'light');

                    // Surveiller les changements de darkMode
                    this.$watch('darkMode', (val) => {
                        const theme = val ? 'dark' : 'light';
                        localStorage.setItem('theme', theme);
                        window.applyTheme(theme);
                    });

                    // Écouter les changements de préférence système
                    window.matchMedia('(prefers-color-scheme: dark)')
                        .addEventListener('change', e => {
                            if (!localStorage.getItem('theme')) {
                                this.darkMode = e.matches;
                            }
                        });

                    // Écouter l'événement de navigation Livewire pour maintenir le thème
                    Livewire.hook('morph.updated', () => {
                        const currentTheme = window.getCurrentTheme();
                        window.applyTheme(currentTheme);
                        this.darkMode = currentTheme === 'dark';
                    });

                    // Alternative pour les navigations normales
                    document.addEventListener('livewire:navigated', () => {
                        const currentTheme = window.getCurrentTheme();
                        window.applyTheme(currentTheme);
                        this.darkMode = currentTheme === 'dark';
                    });
                },

                toggleTheme() {
                    this.darkMode = !this.darkMode;
                }
            }));
        });

        // Script de secours pour s'assurer que le thème persiste après chaque chargement
        document.addEventListener('DOMContentLoaded', () => {
            const currentTheme = window.getCurrentTheme();
            window.applyTheme(currentTheme);
        });
    </script>
    @endif
</head>

<body class="min-h-screen antialiased" @if(mt_has_dark_mode()) x-data="themeManager()" @endif>
    {{ $slot }}

    @livewireScripts
    @stack('scripts')

    {{-- ================= LIVEWIRE TITLE UPDATE ================= --}}
    <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('page-title-changed', (event) => {
                document.title = event.title;
            });
        });
    </script>
</body>
</html>