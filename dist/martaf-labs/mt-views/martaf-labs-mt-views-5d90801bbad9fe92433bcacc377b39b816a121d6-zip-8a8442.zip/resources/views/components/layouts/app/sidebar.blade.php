
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark">
    <head>
        @include('mt::partials.head')
    </head>
    <body class="min-h-screen bg-white dark:bg-zinc-800">

        {{-- <flux:header>
            <flux:sidebar.toggle class="lg:hidden">

            </flux:sidebar.toggle>
        </flux:header> --}}

        <div x-data="{ sidebarCollapsed: false }" class="flex">
            <!-- Bouton de pliage/dépliage (visible sur desktop) -->
            {{-- <button
                @click="sidebarCollapsed = !sidebarCollapsed"
                class="z-40 items-center justify-center hidden w-6 h-6 transition-all duration-300 border rounded-full lg:fixed lg:flex bg-zinc-200 dark:bg-zinc-700 border-zinc-300 dark:border-zinc-600 hover:bg-zinc-300 dark:hover:bg-zinc-600"
                :class="sidebarCollapsed ? 'lg:left-4 top-4' : 'lg:left-64 top-4'"
                x-cloak
            >
                <svg x-show="!sidebarCollapsed" class="w-3 h-3 text-zinc-600 dark:text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                </svg>
                <svg x-show="sidebarCollapsed" class="w-3 h-3 text-zinc-600 dark:text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                </svg>
            </button> --}}

            <flux:sidebar
                x-show="!sidebarCollapsed"
                :class="sidebarCollapsed ? 'lg:-translate-x-full' : 'lg:translate-x-0'"
                class="overflow-y-auto transition-transform duration-300 ease-in-out border-e border-zinc-200 bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-800 scrollbar-thin scrollbar-thumb-zinc-300 dark:scrollbar-thumb-zinc-600 scrollbar-track-transparent hover:scrollbar-thumb-zinc-400 dark:hover:scrollbar-thumb-zinc-500"
                sticky stashable
            >
                <flux:sidebar.toggle class="lg:hidden" icon="x-mark" />

                <a href="{{ route('dashboard') }}" class="flex items-center space-x-2 me-5 rtl:space-x-reverse" wire:navigate>
                    <x-mt::app-logo />
                </a>

                <flux:navlist variant="outline">
                    <flux:navlist.group :heading="__('Menu principal')" class="grid">
                        @php
                            $sidebarItems = getSidebar();
                        @endphp

                        @foreach ($sidebarItems as $item)
                            @php
                                $itemRoute = $item['route'] ?? '';
                                $itemIcon = $item['icon'] ?? '';
                                $subItems = $item['subItems'] ?? [];
                                $itemCount = $item['count'] ? add_zero($item['count']) : null;
                                $isActive = request()->routeIs($itemRoute . '*') ||
                                        (!empty($subItems) && collect($subItems)->contains(fn($sub) => request()->routeIs($sub['route'] . '*')));

                                // Déterminer la couleur du badge selon la valeur
                                $getBadgeColor = function($count) {
                                    if ($count > 10) return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
                                    if ($count > 5) return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
                                    return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
                                };
                            @endphp

                            @if (!empty($subItems))
                                <flux:navlist.group
                                    heading="{!! __($item['label']) !!}"
                                    expandable
                                    :expanded="false"
                                >
                                    @foreach ($subItems as $subItem)
                                        @php
                                            $subItemRoute = $subItem['route'] ?? '';
                                            $subItemIcon = $subItem['icon'] ?? '';
                                            $subItemCount = $subItem['count'] ? add_zero($subItem['count']) : null;
                                            $subIsActive = request()->routeIs($subItemRoute . '*');
                                        @endphp

                                        <flux:navlist.item
                                            :href="$subItemRoute"
                                            wire:navigate
                                            badge="{{ $subItemCount ?? '' }}"
                                            badge:variant="outline"
                                            badge:color="lime"
                                        >
                                            {!! __($subItem['label']) !!}
                                        </flux:navlist.item>
                                    @endforeach

                                </flux:navlist.group>
                            @else
                                <flux:navlist.item
                                    :href="$itemRoute"
                                    wire:current='bg-zinc-500'
                                    wire:navigate
                                    badge="{{ $itemCount ?? '' }}"
                                    badge:variant="outline"
                                    badge:color="lime"
                                >
                                    <i class="{{ $itemIcon }}"></i>
                                    {!! __($item['label']) !!}
                                </flux:navlist.item>
                            @endif
                        @endforeach
                    </flux:navlist.group>
                </flux:navlist>

                <flux:spacer />

                {{-- <flux:navlist variant="outline">
                    <flux:navlist.item icon="folder-git-2" href="https://github.com/laravel/livewire-starter-kit" target="_blank">
                    {{ __('Repository') }}
                    </flux:navlist.item>

                    <flux:navlist.item icon="book-open-text" href="https://laravel.com/docs/starter-kits#livewire" target="_blank">
                    {{ __('Documentation') }}
                    </flux:navlist.item>
                </flux:navlist> --}}

                <!-- Desktop User Menu -->
                <flux:dropdown class="hidden lg:block" position="bottom" align="start">
                    <flux:profile
                        :name="auth()->user()->userable->fullName()"
                        :initials="auth()->user()->initials()"
                        icon:trailing="chevrons-up-down"
                    />

                    <flux:menu class="w-[220px]">
                        <flux:menu.radio.group>
                            <div class="p-0 text-sm font-normal">
                                <div class="flex items-center gap-2 px-1 py-1.5 text-start text-sm">
                                    <span class="relative flex w-8 h-8 overflow-hidden rounded-lg shrink-0">
                                        <span
                                            class="flex items-center justify-center w-full h-full text-black rounded-lg bg-neutral-200 dark:bg-neutral-700 dark:text-white"
                                        >
                                            {{ auth()->user()->initials() }}
                                        </span>
                                    </span>

                                    <div class="grid flex-1 text-sm leading-tight text-start">
                                        <span class="font-semibold truncate">{{ auth()->user()->name }}</span>
                                        <span class="text-xs truncate">{{ auth()->user()->email }}</span>
                                    </div>
                                </div>
                            </div>
                        </flux:menu.radio.group>

                        <flux:menu.separator />

                        <flux:menu.radio.group>
                            <flux:menu.item :href="route('settings.profile')" icon="cog" wire:navigate>{{ __('Settings') }}</flux:menu.item>
                        </flux:menu.radio.group>

                        <flux:menu.separator />

                        <form method="POST" action="{{ route('logout') }}" class="w-full">
                            @csrf
                            <flux:menu.item as="button" type="submit" icon="arrow-right-start-on-rectangle" class="w-full">
                                {{ __('Log Out') }}
                            </flux:menu.item>
                        </form>
                    </flux:menu>
                </flux:dropdown>
            </flux:sidebar>

            <!-- Contenu principal -->
            <div class="flex-1 min-w-0" :class="sidebarCollapsed ? 'lg:ml-0' : ''">
                <!-- Mobile User Menu -->
                <flux:header class="lg:hidden">
                    <flux:sidebar.toggle class="lg:hidden" icon="bars-2" inset="left" />

                    <flux:spacer />

                    <flux:dropdown position="top" align="end">
                        <flux:profile
                            :initials="auth()->user()->initials()"
                            icon-trailing="chevron-down"
                        />

                        <flux:menu>
                            <flux:menu.radio.group>
                                <div class="p-0 text-sm font-normal">
                                    <div class="flex items-center gap-2 px-1 py-1.5 text-start text-sm">
                                        <span class="relative flex w-8 h-8 overflow-hidden rounded-lg shrink-0">
                                            <span
                                                class="flex items-center justify-center w-full h-full text-black rounded-lg bg-neutral-200 dark:bg-neutral-700 dark:text-white"
                                            >
                                                {{ auth()->user()->initials() }}
                                            </span>
                                        </span>

                                        <div class="grid flex-1 text-sm leading-tight text-start">
                                            <span class="font-semibold truncate">{{ auth()->user()->userable->fullName() }}</span>
                                            <span class="text-xs truncate">{{ auth()->user()->email }}</span>
                                        </div>
                                    </div>
                                </div>
                            </flux:menu.radio.group>

                            <flux:menu.separator />

                            <flux:menu.radio.group>
                                <flux:menu.item :href="route('settings.profile')" icon="cog" wire:navigate>{{ __('Settings') }}</flux:menu.item>
                        </flux:menu.radio.group>

                            <flux:menu.separator />

                            <form method="POST" action="{{ route('logout') }}" class="w-full">
                                @csrf
                                <flux:menu.item as="button" type="submit" icon="arrow-right-start-on-rectangle" class="w-full">
                                    {{ __('Log Out') }}
                                </flux:menu.item>
                            </form>
                        </flux:menu>
                    </flux:dropdown>
                </flux:header>

                {{ $slot }}
            </div>
        </div>

        <!-- Inclure les modals -->
        <livewire:mt.modals.confirm />
        <livewire:mt.modals.alert />

        @fluxScripts

        <style>
            /* Styles pour la scrollbar personnalisée */
            .scrollbar-thin::-webkit-scrollbar {
                width: 6px;
            }

            .scrollbar-thin::-webkit-scrollbar-track {
                background: transparent;
            }

            .scrollbar-thin::-webkit-scrollbar-thumb {
                border-radius: 3px;
                opacity: 0;
                transition: opacity 0.3s ease;
            }

            .scrollbar-thin:hover::-webkit-scrollbar-thumb {
                opacity: 1;
            }

            /* Pour Firefox */
            .scrollbar-thin {
                scrollbar-width: thin;
                scrollbar-color: transparent transparent;
            }

            .scrollbar-thin:hover {
                scrollbar-color: rgb(161 161 170) transparent;
            }

            .dark .scrollbar-thin:hover {
                scrollbar-color: rgb(82 82 91) transparent;
            }

            /* Masquer les éléments Alpine.js pendant le chargement */
            [x-cloak] {
                display: none !important;
            }
        </style>

    </body>
</html>
