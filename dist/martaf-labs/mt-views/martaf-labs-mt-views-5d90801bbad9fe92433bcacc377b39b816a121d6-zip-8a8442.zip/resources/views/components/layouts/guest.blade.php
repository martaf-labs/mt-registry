<x-mt::layouts.master>
    @push('styles')
    <style>
        .progress-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            box-shadow: 0 1px 3px 0 rgb(0,0,0,0.1);
            background: linear-gradient(90deg, rgba(var(--mt-primary)), rgba(var(--mt-secondary)));
            z-index: 1000;
            transition: width 0.2s ease;
        }
    </style>
    @endpush

    <!-- Progress bar -->
    <div class="progress-bar" id="progressBar"></div>

    {{ $slot }}

    @push('scripts')
        <script>            
            // Progress bar
            window.onscroll = function() {
                let winScroll = document.body.scrollTop || document.documentElement.scrollTop;
                let height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                let scrolled = (winScroll / height) * 100;
                document.getElementById("progressBar").style.width = scrolled + "%";
            };
        </script>
    @endpush
</x-mt::layouts.master>