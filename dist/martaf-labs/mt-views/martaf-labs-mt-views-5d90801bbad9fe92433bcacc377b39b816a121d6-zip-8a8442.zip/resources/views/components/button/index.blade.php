@props([
    'href' => null, 
    'variant' => 'primary', 
    'size' => 'md',        
    'label' => null,     
    'loading' => null,     
    'icon' => null,
    'endIcon' => null,
    'error' => null,
    'help' => null,
    'disabled' => false,
])

@php
$baseClasses = "w-full mt-btn group inline-flex items-center justify-center transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed";

$variants = [
    'primary'   => 'mt-btn-primary',
    'secondary' => 'mt-btn-secondary',
    'dangerr'   => 'mt-btn-dangerr',
    'success'   => 'mt-btn-success',
    'warning'   => 'mt-btn-warning',
    'info'      => 'mt-btn-info',
    'outline'   => 'mt-btn-outline',
    'ghost'     => 'mt-btn-ghost',
];

$sizes = [
    'sm' => 'mt-btn-sm',
    'md' => 'mt-btn-md',
    'lg' => 'mt-btn-lg',
];

$classes = $baseClasses
    . ' ' . ($variants[$variant] ?? $variants['primary'])
    . ' ' . ($sizes[$size]);

$tag = $href ? 'a' : 'button';
@endphp

@php
    // Sécurité : Si loading est vide, on ne veut SURTOUT pas de wire:target vide
    $target = (is_string($loading) && !empty($loading)) ? $loading : null;

    // configuration de l'icone
    $icon = mt_icon_exists($icon ?? '') ? "mt-icon-$icon" : $icon;
    $endIcon = mt_icon_exists($endIcon ?? '') ? "mt-icon-$endIcon" : $endIcon;
@endphp

<div class="inline-flex flex-col w-full">
    <{{ $tag }}
        @if($href) 
            href="{{ $href }}" wire:navigate 
        @endif

        {{ $attributes->merge(['class' => $classes, 'style' => '']) }}

        {{-- On n'applique les attributs de chargement que si une cible valide existe --}}
        @if($target)
            wire:loading.attr="disabled"
            wire:target="{{ $target }}"
        @endif

        @if($disabled) disabled @endif
    >
        {{-- 1. Le Spinner : Utilisation de .inline-block pour éviter les conflits CSS --}}
        @if($target)
            <i class="mr-1 transition duration-150 ease-in-out mt-icon-circle-notch fa-spin" 
               wire:loading.inline-block 
               wire:target="{{ $target }}"
               style="display: none;"> {{-- Forcé à caché par défaut au premier rendu --}}
            </i>
        @endif

        {{-- 2. L'icône (cachée au clic) --}}
        @if($icon)
            <i class="{{ $icon }} mr-1 group-hover:-translate-x-1 transition duration-150 ease-in-out" 
               @if($target) wire:loading.remove wire:target="{{ $target }}" @endif>
            </i>
        @endif
        
        <span>{{ $label ?? $slot }}</span>

        @if($endIcon)
            <i class=" {{ $endIcon }} ml-1 group-hover:translate-x-1 transition duration-150 ease-in-out" 
               @if($target) wire:loading.remove wire:target="{{ $target }}" @endif>
            </i>
        @endif
    </{{ $tag }}>
    
</div>