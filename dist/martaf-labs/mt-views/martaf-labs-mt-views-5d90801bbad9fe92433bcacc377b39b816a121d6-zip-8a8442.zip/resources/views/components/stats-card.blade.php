{{-- 
    Composant : Stats Card
    Usage :
    <x-mt::stats-card 
        title="Total Engins" 
        value="124" 
        icon="fa-truck" 
        color="primary"
    />
    
    Couleurs supportées : primary, success, warning, danger, info, gray
    Ou en passant directement une variable CSS : color="var(--mt-primary)"
--}}

@props([
    'title',
    'value',
    'icon',
    'color' => 'primary',
])

@php
    // Mapping vers les variables mt-*
    $colorMap = [
        'primary' => ['bg' => 'var(--mt-primary)',  'text' => 'var(--mt-primary)'],
        'success' => ['bg' => 'var(--mt-success)',  'text' => 'var(--mt-success)'],
        'warning' => ['bg' => 'var(--mt-warning)',  'text' => 'var(--mt-warning)'],
        'danger'  => ['bg' => 'var(--mt-danger)',   'text' => 'var(--mt-danger)'],
        'info'    => ['bg' => 'var(--mt-info)',      'text' => 'var(--mt-info)'],
        'gray'    => ['bg' => 'var(--mt-text)',      'text' => 'var(--mt-text)'],
        // Rétrocompatibilité anciens noms
        'blue'    => ['bg' => 'var(--mt-primary)',  'text' => 'var(--mt-primary)'],
        'emerald' => ['bg' => 'var(--mt-success)',  'text' => 'var(--mt-success)'],
        'amber'   => ['bg' => 'var(--mt-warning)',  'text' => 'var(--mt-warning)'],
        'red'     => ['bg' => 'var(--mt-danger)',   'text' => 'var(--mt-danger)'],
        'purple'  => ['bg' => 'var(--mt-info)',     'text' => 'var(--mt-info)'],
    ];

    $resolved = $colorMap[$color] ?? $colorMap['primary'];
    $bgVar    = $resolved['bg'];
    $textVar  = $resolved['text'];
@endphp

<div class="rounded-xl p-4 transition-transform hover:scale-[1.02] mt-card"
     style="border-left: 3px solid rgb({{ $bgVar }})">
    <div class="flex items-center justify-between">

        <div class="space-y-1">
            <p class="text-xs font-medium uppercase tracking-wider mt-text-muted">{{ $title }}</p>
            <p class="text-2xl font-bold tracking-tight mt-text">{{ $value }}</p>
        </div>

        <div class="p-3 rounded-lg" style="background: rgba({{ $bgVar }}, 0.1)">
            <i class="fa-solid {{ $icon }} text-2xl" style="color: rgb({{ $bgVar }})"></i>
        </div>

    </div>
</div>
