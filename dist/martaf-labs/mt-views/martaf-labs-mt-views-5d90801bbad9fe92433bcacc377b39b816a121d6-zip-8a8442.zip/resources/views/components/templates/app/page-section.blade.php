@props([
    'title' => null,
    'actions' => null,
])

<div class="mb-6 bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
    <div class="px-6 pt-6 border-gray-200">
        <div class="flex items-center justify-between">
            <h3 class="mb-4 py-1 text-sm font-medium truncate text-gray-600 dark:text-white">{{ Str::ucfirst($title) }}</h3>

            @if ($actions)

            <!-- Action liées au personalInfos -->
            <x-mt::actions.grid :actions="$actions"> </x-mt::actions.grid>
        
            @endif

        </div>
    </div>
    <div class="px-6 pb-6">
       {{ $slot }}
    </div>
</div>