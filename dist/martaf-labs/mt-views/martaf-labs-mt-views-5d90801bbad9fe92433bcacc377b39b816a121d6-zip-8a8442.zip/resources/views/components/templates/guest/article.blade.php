@props([
    'data' => null,
    'title' => '',
    'details' => '',
    'image' => null,
    'specifications' => [],
    'price' => null,
    'status' => 'available',
    'type' => null,
    'actionLabel' => 'Voir détails',
    'route' => '#',
    'badgeColor' => null,
    'theme' => 'blue',
    'animated' => true,
    'animationDelay' => 0,
])

<div 
    @if($animated) 
        style="animation-delay: {{ $animationDelay }}ms" 
        class="flex flex-col bg-white/60 dark:bg-slate-900/50 rounded-[2.5rem] border border-gray-100 dark:border-white/10 hover:shadow-2xl hover:shadow-sky-500/10 dark:hover:border-sky-500/50 transition-all duration-500 group overflow-hidden h-full animate-in fade-in slide-in-from-bottom-4 backdrop-blur-sm"
    @else
        class="flex flex-col bg-white dark:bg-slate-900/50 rounded-[2.5rem] border border-gray-100 dark:border-white/10 shadow-sm hover:shadow-2xl hover:shadow-sky-500/10 dark:hover:border-sky-500/50 transition-all duration-500 group overflow-hidden h-full backdrop-blur-sm"
    @endif
>
    <div class="relative aspect-[4/3] overflow-hidden m-3 rounded-[2rem]">
        {{-- <img src="{{ $image }}" 
             class="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" 
             alt="{{ $title }}" loading="lazy"> --}}
             <x-mt::image-loader :src="$image" :alt="$title" class="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
        
        @if($type)
            <div class="absolute top-4 left-4">
                <span class="px-4 py-1.5 bg-white/90 dark:bg-slate-900/80 backdrop-blur-md text-sky-600 dark:text-sky-400 text-[10px] font-bold uppercase tracking-widest rounded-full shadow-sm border dark:border-white/10">
                    {{ $type }}
                </span>
            </div>
        @endif

        <div class="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-6">
            {{-- <span class="text-white text-sm font-bold flex items-center gap-2">
                {{ $actionLabel }} <i class="fa-solid fa-arrow-right text-xs"></i>
            </span> --}}
        </div>
    </div>

    <div class="p-6 pt-2 flex flex-col grow">
        <div class="grow">
            <h3 class="text-xl font-extrabold text-slate-800 dark:text-white group-hover:text-sky-500 dark:group-hover:text-sky-400 transition-colors duration-300 line-clamp-1">
                <a href="{{ $route }}" wire:navigate>
                    {{ $title }}
                </a>
            </h3>

            @if($details)
                <p class="mt-2 text-sm text-gray-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                    {{ $details }}
                </p>
            @endif

            @if(!empty($specifications))
                <div class="mt-2 grid grid-cols-2 lg:grid-cols-1 gap-y-3 gap-x-4 border-t border-gray-100 dark:border-white/5 pt-4">
                    @foreach(array_slice($specifications, 0, 4) as $spec)
                        <div class="flex flex-col border-b border-gray-50 dark:border-white/5 last:border-0 pb-0.5">
                            <span class="text-[10px] uppercase font-bold text-gray-400 dark:text-slate-500 group-hover:text-sky-400 transition-colors">
                                {{ $spec['label'] }}
                            </span>
                            <span class="text-xs font-bold text-slate-700 dark:text-slate-200">
                                {{ $spec['value'] }}
                            </span>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>

        @if ($route)
        <div class="mt-3 flex items-center justify-between">
            @if($price)
                <div class="flex flex-col">
                    <span class="text-[10px] text-gray-400 dark:text-slate-500 font-bold uppercase tracking-tighter">À partir de</span>
                    <span class="text-lg font-black text-slate-900 dark:text-white">
                        {{ $price }} <small class="text-[10px] font-medium opacity-60">/jour</small>
                    </span>
                </div>
            @endif

            <a href="{{ $route }}" class="text-sky-400 font-semibold text-sm hover:text-sky-300 flex items-center gap-2" wire:navigate>
                {{ $actionLabel }} <i class="fa-solid fa-arrow-right text-xs"></i>
            </a>
        </div>
        @endif
    </div>
</div>