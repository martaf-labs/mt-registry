<div
    x-data="{
        open: false,
        lockScroll(state) {
            document.body.style.overflow = state ? 'hidden' : '';
        }
    }"
    x-on:open-modal.window="if ($event.detail === '{{ $id }}') { open = true; lockScroll(true); }"
    x-on:close-modal.window="open = false; lockScroll(false)"
    x-on:keydown.escape.window="open = false; lockScroll(false)"
    x-cloak
>
    <div
        x-show="open"
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 backdrop-blur-0"
        x-transition:enter-end="opacity-100 backdrop-blur-md"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100 backdrop-blur-md"
        x-transition:leave-end="opacity-0 backdrop-blur-0"
        class="fixed inset-0 bg-slate-950/60 z-[60]"
        @click="open = false; lockScroll(false)"
    ></div>

    <div
        x-show="open"
        class="fixed inset-0 z-[70] flex items-center justify-center p-4 sm:p-6"
    >
        <div 
            x-show="open"
            x-transition:enter="transition ease-out duration-500"
            x-transition:enter-start="opacity-0 scale-95 translate-y-8"
            x-transition:enter-end="opacity-100 scale-100 translate-y-0"
            x-transition:leave="transition ease-in duration-300"
            x-transition:leave-start="opacity-100 scale-100 translate-y-0"
            x-transition:leave-end="opacity-0 scale-95 translate-y-8"
            class="relative w-full {{ $maxWidth ?? 'max-w-2xl' }} bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-[0_35px_60px_-15px_rgba(0,0,0,0.5)] border border-slate-200 dark:border-white/10 h-[90vh] flex flex-col overflow-hidden pb-10"
        >
            
            <div class="absolute -top-24 -left-24 w-48 h-48 bg-sky-500/10 blur-[60px] rounded-full pointer-events-none"></div>

            <div class="relative flex items-center justify-between px-8 py-6 shrink-0 border-b border-slate-100 dark:border-white/5">
                <div>
                    <h2 class="text-md text-slate-800 dark:text-white ">
                        {{ $title }}<span class="text-sky-500">.</span>
                    </h2>
                    <p class="text-xs text-slate-400 font-medium mt-1">{{ $subtitle?? '' }}</p>
                </div>

                <button @click="open = false; lockScroll(false)"
                        class="group p-3 rounded-full bg-slate-100 dark:bg-white/5 text-slate-400 hover:text-white hover:bg-sky-500 transition-all duration-300">
                    <svg class="w-5 h-5 group-hover:rotate-90 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <div class="relative px-8 py-6 overflow-y-auto custom-scrollbar text-slate-700 dark:text-slate-300">
                {{ $slot }}
            </div>

            @isset($footer)
                <div class="px-8 py-5 border-t border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-slate-950/50 backdrop-blur-xl shrink-0 flex justify-end gap-4">
                    {{ $footer }}
                </div>
            @endisset
        </div>
    </div>

    <style>
        /* Scrollbar personnalisée pour le Dark Mode */
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 10px;
        }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #1e293b;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #0ea5e9;
        }
    </style>
</div>