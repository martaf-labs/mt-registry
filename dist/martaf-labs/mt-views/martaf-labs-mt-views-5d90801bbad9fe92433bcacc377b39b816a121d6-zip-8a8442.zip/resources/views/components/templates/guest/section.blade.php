@props([
    'title' => false,
    'description' => false,
    'subtitle' => false,
    'classes' => null,
    'show' => true,
])

<section class="@if($show)relative py-8 lg:py-16 overflow-hidden bg-transparent transition-colors duration-500 max-w-7xl mx-auto {{ $classes }}@endif">
    
@if($show)
    <div class="relative z-10 px-3 mx-auto lg:px-8">
        
        <div class="flex flex-col justify-between gap-10 mb-16 lg:flex-row lg:items-end lg:mb-24">
            
            <div class="max-w-3xl lg:space-y-6">
                @if($subtitle)
                    <div class="inline-flex items-center space-x-3 group">
                        <span class="w-6 h-px transition-all duration-300 bg-sky-500/50 group-hover:w-10"></span>
                        <span class="text-sky-600 dark:text-sky-400 font-bold text-xs uppercase tracking-[0.3em]">
                            {{ $subtitle }}
                        </span>
                    </div>
                @endif

                @if($title)
                    <h2 class="text-4xl lg:text-7xl font-black text-sky-500 dark:text-white tracking-tighter leading-[0.95] transition-colors">
                        {{ $title }} <span class="inline-block ms-1 text-slate-900 dark:text-sky-500 animate-pulse-slow">.</span>
                    </h2>
                @endif
            </div>

            @if($description)
                <div class="max-w-md lg:py-2 lg:pl-6 border-l border-slate-200 dark:border-slate-700/50 lg:pl-8">
                    <p class="text-base font-light leading-relaxed sm:text-lg text-slate-600 dark:text-slate-400">
                        {{ $description }}
                    </p>
                </div>
            @endif
        </div>

        <div class="relative">
            <div class="absolute w-12 h-12 border-t border-l pointer-events-none -top-6 -left-6 border-sky-500/20 dark:border-sky-500/40 rounded-tl-xl"></div>
            <div class="absolute w-12 h-12 border-b border-r pointer-events-none -bottom-6 -right-6 border-sky-500/20 dark:border-sky-500/40 rounded-br-xl"></div>
            
            <div class="relative">
                {{ $slot }}
            </div>
        </div>

    </div>

    <style>
        @keyframes pulse-slow {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(1.1); }
        }
        .animate-pulse-slow {
            animation: pulse-slow 3s ease-in-out infinite;
        }
    </style>
@endif
</section>