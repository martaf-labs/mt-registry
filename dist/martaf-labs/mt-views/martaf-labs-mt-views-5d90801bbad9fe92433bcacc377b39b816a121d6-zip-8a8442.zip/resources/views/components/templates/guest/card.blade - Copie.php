@props([
    'data' => null,
    'title' => '',
    'details' => '',
    'image' => null,
    'caracteristiques' => [], // Tableau de caractéristiques
    'price' => null,
    'status' => 'available',
    'type' => 'default',
    'actionLabel' => 'Voir details',
    'route' => '#',
    'badgeColor' => null,
    'theme' => 'blue',
    'animated' => true, // Option pour activer/désactiver les animations
    'animationDelay' => 0, // Délai d'animation personnalisable
])


<div class="flex flex-col items-start justify-between">
    <div class="overflow-hidden rounded-lg h-[300px] w-full">
        <img src="{{ $image }}" class=" h-full w-full object-cover bg-gray-800/50 hover:scale-105 backdrop-blur-lg shadow-md hover:shadow-2xl transition delay-150 duration-300 ease-in-out" alt="{{ $title }}">
    </div>
    {{-- <div class="flex items-center gap-x-4 text-xs">
        <time datetime="2020-03-16" class="text-gray-400">Mar 16, 2020</time>
        <a href="#" class="relative z-10 rounded-full bg-gray-800/60 px-3 py-1.5 font-medium text-gray-300 hover:bg-gray-800">Marketing</a>
    </div> --}}
    <div class="group relative grow">
        <h3 class="mt-3 text-lg/6 font-semibold text-sky-500 group-hover:text-gray-300">
            <a href="{{ $route }}">
            <span class="absolute inset-0"></span>
            {{ $title }}
            </a>
        </h3>
        <p class="mt-3 line-clamp-3 text-sm/6 text-gray-400">{{ $details }}</p>
    </div>
    {{-- <div class="relative mt-8 flex items-center gap-x-4 justify-self-end">
        <img src="https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="" class="size-10 rounded-full bg-gray-800" />
        <div class="text-sm/6">
            <p class="font-semibold text-white">
            <a href="#">
                <span class="absolute inset-0"></span>
                Michael Foster
            </a>
            </p>
            <p class="text-gray-400">Co-Founder / CTO</p>
        </div>
    </div> --}}
</div>


{{-- <div class="relative group flex-grow transition-all w-56 h-[400px] duration-500 hover:w-full">
    <img class="h-full w-full object-cover object-right"
        src="{{ $image }}"
        alt="image">
    <div class="absolute inset-0 flex flex-col justify-end p-10 text-white bg-black/50 opacity-0 group-hover:opacity-100 transition-all duration-300">
        <h1 class="text-3xl">{{ $title }}</h1>
        <p class="text-sm">{{ $details }}</p>
    </div>
</div> --}}
