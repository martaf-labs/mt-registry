@props([
    'actions' => false,
    'visible' => 1,
    'size' => "md"
])

@if($actions)

    @php
        $visible = intVal($visible);
        $visibleActions=$visible != 0 ? array_slice($actions, 0,$visible) : [];
        $hiddenActions=$visible != 0 ? array_slice($actions, $visible) : $actions;
    @endphp

    <div class="flex justify-end items-center gap-2 flex-nowrap">
        @if(count($visibleActions) > 0) 
            @foreach ($visibleActions as $action)
                @php $actionIcon=$action['icon'] ?? $action['icone'] ?? ''; @endphp
                @if (is_array($action))
                    @if (isset($action['lien']) || isset($action['route']))                
                    <x-mt::button href="{{ $action['lien'] ?? $action['route'] ?? '#' }}" icon="{{ $actionIcon }}" size="{{ $size }}" variant="{{ $action['variant'] ?? 'outline' }}" style="">
                        {{ $action['label'] ?? '' }}
                    </x-mt::button> 
                    @endif
                    
                    @if (isset($action['method']))
                    <x-mt::button wire:click="{{ $action['method'] ?? '' }}" size="{{ $size }}" icon="{{ $actionIcon }}" variant="{{ $action['variant'] ?? 'outline' }}" style="">
                        {{ $action['label'] ?? '' }}
                    </x-mt::button> 
                    @endif
                @endif
            @endforeach
        @endif
        

        @if (count($hiddenActions) > 0)
        <x-mt::dropdown>                
            <x-slot:trigger>
                <button icon="" class="mt-btn-icon mt-btn-icon-sm mt-icon-ellipsis-vertical" title="Plus d'actions" style="">
                    {{-- <x-mt::icon name="ellipsis-vertical" /> --}}
                </button>
            </x-slot:trigger>

                <x-mt::dropdown.menu>
                @foreach ($hiddenActions as $action)
                    @php $actionIcon = $action['icon'] ?? $action['icone'] ?? ''; @endphp
                    @if (is_array($action))
                        <x-mt::dropdown.item
                            href="{{ $action['lien'] ?? $action['route'] ?? '#'}}"
                            :icon="$actionIcon"
                            variant="{{ $action['variant'] ?? 'secondary' }}"
                            label="{{ $action['label'] ?? '' }}" 
                        />
                    @endif
                @endforeach
            </x-mt::dropdown.menu>
        </x-mt::dropdown>
        @endif

    </div>
@endif