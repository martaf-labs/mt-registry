@props([
    'icon' => null,
    'label' => null,
])
<button {{ $attributes->merge(['class' => 'flex w-full items-center gap-2 px-3 py-2 text-xs text-zinc-600 dark:text-zinc-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-500/10 rounded-xl transition-all duration-200 group']) }}>
    @if(isset($icon))
        <i class="{{ $icon }} text-sm text-zinc-400 group-hover:text-blue-500 transition-colors"></i>
    @endif
    @if ($label)
        <span class="truncate">{{ $label }}</span>
    @else
        <span>{{ $slot }}</span>
    @endif
</button>
