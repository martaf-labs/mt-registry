@props([
    'items' => false,
    'total' => false,
    'infos' => false,
])

@if ($items)

@php
    $itemsCount=count($items);
@endphp

<div>
    
    <div class="space-y-4">
        
    @forelse ($items as $item)

    <div class="flex justify-between">
        <span class="text-gray-600 text-xs">{{ $item['text'] }}</span>
        <span class="font-medium text-xs">{{ $item['value'] }}</span>
    </div>
        
    @empty
        
    @endforelse

    @if ($total)
        <div class="border-t border-gray-200 pt-3 mt-3">
            <div class="flex justify-between text-xs">
                <span class="text-gray-600">Total</span>
                <span class="font-medium">{{ $total }}</span>
            </div>
        </div>
    @endif

    </div>
    
    @if($infos)
    <div class="mt-4 flex items-center text-xs text-gray-600">
        <i class="fas fa-info-circle mr-2 text-blue-500"></i>
        <span>{{ $infos }}</span>
    </div>
    @endif
</div>
@endif