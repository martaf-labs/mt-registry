@props([
    'items' => false
])

@if ($items)

@php
    $itemsCount=count($items);
@endphp

<div>
    
    <div class="space-y-4">
        <div class="timeline">
            
            @forelse ($items as $item)

            <div class="timeline-item {{ $item['status'] }}">
                <p class="text-sm font-medium text-gray-900">{{ $item['text'] }}</p>
                <p class="text-xs text-gray-500">{{ $item['subText'] }}</p>
            </div>
                
            @empty
                
            @endforelse

        </div>
    </div>
</div>
@endif

<style>
    /* Timeline styles */
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        .timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background-color: #e5e7eb;
        }
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -25px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: #3b82f6;
            border: 2px solid white;
            box-shadow: 0 0 0 3px #3b82f6;
        }
        .timeline-item.completed::before {
            background-color: #10b981;
            box-shadow: 0 0 0 3px #10b981;
        }
        .timeline-item.current::before {
            background-color: #f59e0b;
            box-shadow: 0 0 0 3px #f59e0b;
        }
        .timeline-item.pending::before {
            background-color: #ef4444;
            box-shadow: 0 0 0 3px #ef4444;
        }
        
</style>

{{-- <script>
    // Animation des éléments au chargement
    document.addEventListener('DOMContentLoaded', function() {
        const timelineItems = document.querySelectorAll('.timeline-item');
        timelineItems.forEach((item, index) => {
            item.style.animationDelay = `${index * 0.2}s`;
            item.classList.add('animate-fade-in');
        });
        
        // Mise à jour de la progression des documents
        updateDocumentProgress();
    });       
</script> --}}