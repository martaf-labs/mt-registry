{{--
| mt-views :: dropdown/section.blade.php
| Label de groupe d'items.
| Usage : <x-mt::dropdown.section label="Navigation" />
--}}

@props(['label' => ''])

<p class="px-4 pt-3 pb-1 text-[10px] font-bold uppercase tracking-widest select-none mt-text-muted">
    {{ $label }}
</p>
