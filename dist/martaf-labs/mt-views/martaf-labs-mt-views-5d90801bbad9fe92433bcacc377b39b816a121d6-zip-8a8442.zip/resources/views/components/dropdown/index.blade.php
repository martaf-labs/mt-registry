{{--
| mt-views :: Composant anonyme — Dropdown
|
| Usage:
|   <x-mt::dropdown>
|       <x-slot:trigger>
|           <button>Mon déclencheur</button>
|       </x-slot:trigger>
|       <x-mt::dropdown.item icon="fa-solid fa-gauge" label="Tableau de Bord" :href="route('dashboard')" />
|       <x-mt::dropdown.divider />
|       <x-mt::dropdown.item icon="fa-solid fa-gear" label="Paramètres" :href="route('settings')" />
|   </x-mt::dropdown>
|
| Props :
|   align   → left | right (défaut: right)
|   width   → sm | md | lg | full (défaut: md)
|   offsetY → décalage vertical en px (défaut: 8)
--}}

@props([
    'align'   => 'right',
    'width'   => 'md',
    'offsetY' => 8,
])

@php
    $widthClass = match($width) {
        'sm'   => 'min-w-24 max-w-48',
        'md'   => 'min-w-32 max-w-64',
        'lg'   => 'min-w-48 max-w-80',
        'full' => 'min-w-64 max-w-full',
        default => 'min-w-32 max-w-64',
    };
@endphp

<div
    class="relative"
    :class="open ? 'z-50' : 'z-auto'"
    x-data="{ open: false }"
    @click.away="open = false"
    @keydown.escape.window="open = false"
>

    {{-- Slot déclencheur --}}
    <div x-ref="trigger" @click="open = !open" class="relative z-10 cursor-pointer">
        {{ $trigger }}
    </div>

    {{-- Panneau dropdown --}}
    <template x-teleport="body">
        <div
            x-show="open"
            x-cloak
            x-anchor.bottom-end="$refs.trigger"
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-150"
            x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95"
            class="absolute z-[999] {{ $widthClass }} rounded-2xl overflow-hidden shadow-lg mt-bg"
            style="border: 1px solid rgba(var(--mt-ui-card-border), 0.8)"
            @click.away="open = false"
        >
            <div class="divide-y" style="--tw-divide-color: rgba(var(--mt-ui-card-border), 0.6)">
                {{ $slot }}
            </div>
        </div>
    </template>

</div>
