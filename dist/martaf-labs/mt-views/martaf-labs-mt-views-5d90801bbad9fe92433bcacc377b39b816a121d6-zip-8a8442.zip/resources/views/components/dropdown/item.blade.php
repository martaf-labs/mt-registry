{{--
| mt-views :: dropdown/item.blade.php
|
| Props :
|   label   → texte affiché
|   icon    → classe FontAwesome (ex: "fa-solid fa-user")
|   href    → URL de destination (défaut: null → button)
|   method  → méthode Livewire (si pas de href)
|   variant → default | danger
|   badge   → petit badge numérique (optionnel)
|   active  → marquer l'item actif (défaut: false)
--}}

@props([
    'label'   => '',
    'icon'    => null,
    'href'    => null,
    'method'  => null,
    'variant' => 'default',
    'badge'   => null,
    'active'  => false,
])

@php
    $label  = Illuminate\Support\Str::ucfirst($label);
    $danger = $variant === 'danger';
    $iconExists=mt_icon_exists($icon ?? '');

    $baseClass = 'group flex items-center gap-3 w-full px-2 lg:px-4 py-2.5 text-sm text-start rounded-lg transition-all duration-150 cursor-pointer';
@endphp

@if($href)
    <a
        href="{{ $href }}"
        wire:navigate
        class="{{ $baseClass }}"
        role="menuitem"
        @if($danger)
            style="color: rgb(var(--mt-danger))"
            onmouseover="this.style.background='rgba(var(--mt-danger),0.08)'"
            onmouseout="this.style.background=''"
        @elseif($active)
            style="color: rgb(var(--mt-primary)); background: rgba(var(--mt-primary),0.08); font-weight: 600"
        @else
            style="color: rgba(var(--mt-text), 0.75)"
            onmouseover="this.style.background='rgba(var(--mt-text),0.05)'; this.style.color='rgb(var(--mt-text))'"
            onmouseout="this.style.background=''; this.style.color='rgba(var(--mt-text),0.75)'"
        @endif
    >
        @if($icon)
            {{-- <x-mt::icon name="{{ $icon }}" class="flex-shrink-0 transition-colors duration-150"
                style="color: {{ $danger ? 'rgb(var(--mt-danger))' : ($active ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text),0.35)') }}" /> --}}
            <i class="{{ $iconExists? "mt-icon-$icon" : $icon }} flex-shrink-0 transition-colors duration-150"
                style="color: {{ $danger ? 'rgb(var(--mt-danger))' : ($active ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text),0.35)') }}"></i>
        @endif

        <span class="flex-1 truncate">{{ $label }}</span>

        @if($badge)
            <span class="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5 text-[10px] font-bold rounded-full mt-badge mt-badge-primary">
                {{ $badge }}
            </span>
        @endif

        @if($active)
            <x-mt::icon name="check" class="text-[10px] opacity-80" style="color: rgb(var(--mt-primary))" />
        @endif
    </a>
@else
    <button
        @if($method) wire:click='{{ $method }}' @endif
        class="{{ $baseClass }}"
        role="menuitem"
        @if($danger)
            style="color: rgb(var(--mt-danger))"
            onmouseover="this.style.background='rgba(var(--mt-danger),0.08)'"
            onmouseout="this.style.background=''"
        @elseif($active)
            style="color: rgb(var(--mt-primary)); background: rgba(var(--mt-primary),0.08); font-weight: 600"
        @else
            style="color: rgba(var(--mt-text), 0.75)"
            onmouseover="this.style.background='rgba(var(--mt-text),0.05)'; this.style.color='rgb(var(--mt-text))'"
            onmouseout="this.style.background=''; this.style.color='rgba(var(--mt-text),0.75)'"
        @endif
    >
        @if($icon)
            {{-- <x-mt::icon name="{{ $icon }}" class="flex-shrink-0 text-sm text-center transition-colors duration-150"
                style="color: {{ $danger ? 'rgb(var(--mt-danger))' : ($active ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text),0.35)') }}" /> --}}
                
            <i class="{{ $iconExists? "mt-icon-$icon" : $icon }} flex-shrink-0 transition-colors duration-150"
                style="color: {{ $danger ? 'rgb(var(--mt-danger))' : ($active ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text),0.35)') }}"></i>
        @endif

        <span class="flex-1 truncate">{{ $label }}</span>

        @if($badge)
            <span class="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5 text-[10px] font-bold rounded-full mt-badge mt-badge-primary">
                {{ $badge }}
            </span>
        @endif

        @if($active)
            <x-mt::icon name="check" class="text-[10px] opacity-80" style="color: rgb(var(--mt-primary))" />
        @endif
    </button>
@endif

@if (!$href && !$method)
    <div class="">
        {{ $slot }}
    </div>
@endif
