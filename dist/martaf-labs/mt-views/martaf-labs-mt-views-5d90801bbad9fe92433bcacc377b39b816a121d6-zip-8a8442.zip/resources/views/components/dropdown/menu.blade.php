{{--
| mt-views :: dropdown/menu.blade.php
| Conteneur des items du dropdown.
--}}
<div class="p-2 mt-bg">
    {{ $slot }}
</div>
