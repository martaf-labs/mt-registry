@props([
    'label' => null,
    'model' => null,
    'options' => [],
    'error' => null,
    'help' => null,
    'required' => false
])

<div class="w-full">
    @if($label)
        <x-mt::form.label :value="$label" :required="$required" />
    @endif

    <div {{ $attributes->merge(['class' => 'grid grid-cols-1 gap-3 sm:grid-cols-2']) }}>
        @foreach($options as $value => $optionLabel)
            @php
                $title = is_array($optionLabel) ? $optionLabel['title'] : $optionLabel;
                $description = is_array($optionLabel) ? ($optionLabel['description'] ?? null) : null;
                $icon = is_array($optionLabel) ? ($optionLabel['icon'] ?? null) : null;
            @endphp

            <label class="relative flex p-4 border cursor-pointer rounded-xl transition-all group mt-bg"
                style="{{ $error 
                    ? 'border-color: rgb(var(--mt-danger))' 
                    : 'border-color: rgb(var(--mt-ui-card-border))' }}"
                onmouseover="this.style.borderColor='rgb(var(--mt-primary))'"
                onmouseout="this.style.borderColor='{{ $error ? 'rgb(var(--mt-danger))' : 'rgb(var(--mt-ui-card-border))' }}'">
                
                <input type="radio" 
                       @if($model) wire:model="{{ $model }}" @endif
                       value="{{ $value }}" 
                       class="mt-radio mt-1">
                
                <div class="ml-3">
                    <span class="block text-sm font-semibold mt-text transition-colors">
                        @if($icon) <i class="{{ $icon }} mr-1"></i> @endif
                        {{ $title }}
                    </span>
                    @if($description)
                        <span class="block text-xs mt-text-muted mt-1">{{ $description }}</span>
                    @endif
                </div>

                <div class="absolute inset-0 border-2 border-transparent rounded-xl pointer-events-none"></div>
            </label>
        @endforeach
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-2" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-2" />
    @endif
</div>
