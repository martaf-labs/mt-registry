{{--
    Composant : Champ caché (Hidden Input)
    Usage : <x-mt::form.hidden model="user_id" value="12" />
--}}

@props(['model' => null, 'value' => null])

<input type="hidden" 
       @if($model) wire:model="{{ $model }}" @endif
       @if($value) value="{{ $value }}" @endif
       {{ $attributes }}>