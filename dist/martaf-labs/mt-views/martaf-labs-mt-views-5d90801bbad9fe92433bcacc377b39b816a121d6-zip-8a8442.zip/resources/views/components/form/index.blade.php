@props([
    'id' => null,
    'submit' => null,
    'loadingTarget' => "save",
    'withCard' => false
])

@php
    $loadingTarget = $loadingTarget ?? $submit;
@endphp

<div {{ $attributes->merge(['class' => 'w-full']) }}>
    <form 
        @if($submit) wire:submit.prevent="{{ $submit }}" @endif
        @if($id) id="{{ $id }}" @endif
    >
        @if ($errors->any())
            <div class="p-4 mb-6 rounded-r-lg mt-alert mt-alert-danger"
                 style="border-left: 4px solid rgb(var(--mt-danger))">
                <div class="flex">
                    <i class="flex-shrink-0 fa-solid fa-circle-exclamation"></i>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium">
                            Il y a {{ $errors->count() }} erreur(s) dans le formulaire
                        </h3>
                    </div>
                </div>
            </div>
        @endif
        
        <div @class([
            'mt-card p-6 rounded-2xl relative' => $withCard,
        ])>
            {{ $slot }}

            @if(isset($actions))
                <div class="flex items-center justify-start w-full gap-3 pt-6 mt-8"
                     style="">
                    {{ $actions }}
                </div>
            @endif
        </div>
    </form>

    {{-- @if($loadingTarget)
        <div wire:loading wire:target="{{ $loadingTarget }}"
             class="fixed inset-0 z-50 backdrop-blur-[1px] flex items-center justify-center pointer-events-none"
             style="background: rgba(var(--mt-bg), 0.6)">
            <div class="flex items-center gap-3 p-4 shadow-xl rounded-xl mt-card">
                <div class="mt-spinner"></div>
                <span class="text-sm font-medium mt-text">Traitement en cours...</span>
            </div>
        </div>
    @endif --}}
</div>
