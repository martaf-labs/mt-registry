{{--
    Composant : Icon Picker (selecteur d'icone)
    Hérite de "input-picker"
    Usage : 
    <x-mt::form.icon-picker 
        label="Icône" 
        model="item.icon" 
        :icon="$item['icon']" 
        suggestAction="generateIcon"
        help="Choisissez une icône ou laissez l'IA suggérer"
        :error="$errors->first('item.icon')"
    />
--}}

@props([
    'label' => '',
    'model' => '',
    'icon' => null,
    'color' => null, 
    'pickerIcon' => 'fa-solid fa-icons', 
    'suggestAction' => null, 
    'suggestLabel' => 'Suggérer',
    'error' => null,
    'help' => null
])

<x-mt::form.input-picker 
    :model="$model"
    :icon="$icon" 
    :label="$label" 
    :pickerIcon="$pickerIcon"
    :error="$error"
    :help="$help"
>
    {{-- @foreach(mt_icons() as $icon)
        <button type="button"
                @click="$wire.set('{{ $model }}', '{{ $icon }}'); open = false;"
                class="p-2 rounded-lg transition-colors mt-btn-icon mt-btn-icon-sm">
            <i class="{{ $icon }}"></i>
        </button>
    @endforeach --}}
</x-mt::form.input-picker>
