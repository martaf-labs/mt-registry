@props([
    'legend' => null, 
    'icon' => null, 
    'description' => null,
    'error' => null,
    'help' => null
])

<fieldset {{ $attributes->merge(['class' => 'relative rounded-2xl transition-colors']) }}
    style="{{ $error ? 'border-color: rgb(var(--mt-danger)); background: rgba(var(--mt-danger), 0.03)' : 'border-color: rgb(var(--mt-ui-card-border))' }}">
    
    @if($legend)
        <legend class="inline-flex items-center px-3 py-1 text-sm font-bold rounded-lg"
            style="{{ $error 
                ? 'background: rgba(var(--mt-danger), 0.12); color: rgb(var(--mt-danger))' 
                : 'background: rgb(var(--mt-secondary)); color: rgb(var(--mt-primary))' }}">
            @if($icon) <i class="{{ $icon }} mr-2"></i> @endif
            {{ $legend }}
        </legend>
    @endif

    @if($description)
        <p class="mb-6 text-sm mt-text-muted">{{ $description }}</p>
    @endif

    <div class="space-y-5">
        {{ $slot }}
    </div>

    @if($error || $help)
        <div class="pt-4 mt-6" style="border-top: 1px solid rgba(var(--mt-ui-card-border), 0.5)">
            @if($error)
                <x-mt::form.feedback type="error" variant="inline" :message="$error" />
            @elseif($help)
                <x-mt::form.feedback type="help" variant="inline" :message="$help" />
            @endif
        </div>
    @endif
</fieldset>
