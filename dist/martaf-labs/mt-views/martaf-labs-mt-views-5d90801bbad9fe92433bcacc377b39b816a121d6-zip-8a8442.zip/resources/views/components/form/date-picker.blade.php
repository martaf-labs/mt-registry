@props([
    'label' => null,
    'type'  => 'date',
    'model' => null,
    'icon'  => null,
    'error' => null,
    'help'  => null,
    'required' => false
])

<div class="w-full" x-data="{ value: @if ($model) @entangle($model) @else null @endif, isFocused: false }">
    @if($label)
        <x-mt::form.label :value="$label" :required="$required" />
    @endif

    <div class="relative group">
        <div class="absolute inset-y-0 left-0 flex items-center pl-4 transition-colors duration-200 pointer-events-none"
             :class="isFocused ? 'mt-text-primary' : 'mt-text-muted'">
            <i class="{{ $icon ?? ($type === 'time' ? 'fa-solid fa-clock' : 'fa-solid fa-calendar-alt') }} text-sm"></i>
        </div>

        <input 
            type="{{ $type }}"
            x-model="value"
            @focus="isFocused = true"
            @blur="isFocused = false"
            {{ $attributes->merge([
                'class' => 'mt-input pl-11 ' . ($error ? 'mt-input-error' : '')
            ]) }}
            style="color-scheme: dark;{{ $icon ? 'padding-left:3rem ' : '' }}"
        >

        <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none mt-text-muted">
            <i class="text-xs fa-solid fa-angle-down"></i>
        </div>
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1.5" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1.5" />
    @endif
</div>

<style>
    input[type="date"]::-webkit-calendar-picker-indicator,
    input[type="datetime-local"]::-webkit-calendar-picker-indicator {
        background: transparent;
        bottom: 0; color: transparent; cursor: pointer;
        height: auto; left: 0; position: absolute;
        right: 0; top: 0; width: auto;
    }
</style>
