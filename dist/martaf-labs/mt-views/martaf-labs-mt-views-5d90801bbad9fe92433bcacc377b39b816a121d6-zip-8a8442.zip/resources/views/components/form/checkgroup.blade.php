@props([
    'label' => null,
    'model' => null,
    'options' => [],
    'error' => null,
    'help' => null,
    'required' => false
])

<div class="w-full">
    @if($label)
        <x-mt::form.label :value="$label" :required="$required" />
    @endif

    <div {{ $attributes->merge(['class' => 'grid grid-cols-1 gap-3 sm:grid-cols-2']) }}>
        @foreach($options as $value => $optionLabel)
            @php
                $title = is_array($optionLabel) ? $optionLabel['title'] : $optionLabel;
                $description = is_array($optionLabel) ? ($optionLabel['description'] ?? null) : null;
            @endphp

            <label class="relative flex p-4 border cursor-pointer rounded-xl transition-all group mt-bg"
                style="{{ $error 
                    ? 'border-color: rgb(var(--mt-danger))' 
                    : 'border-color: rgb(var(--mt-ui-card-border))' }}">
                
                <input type="checkbox" 
                       @if($model) wire:model="{{ $model }}" @endif
                       value="{{ $value }}" 
                       class="mt-checkbox mt-1 rounded">
                
                <div class="ml-3">
                    <span class="block text-sm font-semibold mt-text transition-colors">
                        {{ $title }}
                    </span>
                    @if($description)
                        <span class="block text-xs mt-text-muted mt-1">
                            {{ $description }}
                        </span>
                    @endif
                </div>
            </label>
        @endforeach
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-2" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-2" />
    @endif
</div>
