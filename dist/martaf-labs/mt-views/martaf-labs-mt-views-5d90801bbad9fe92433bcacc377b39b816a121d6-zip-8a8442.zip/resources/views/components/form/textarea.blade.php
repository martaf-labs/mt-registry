@props([
    'label' => null, 
    'model' => null, 
    'rows'  => 4,
    'error' => null,
    'help'  => null,
    'required' => false,
    'size' => 'md'
])

@php
    $sizeClasses = ['sm' => 'mt-input-sm', 'md' => '', 'lg' => 'mt-input-lg'];
    $textareaSizeClass = $sizeClasses[$size] ?? '';
@endphp

<div class="w-full">
    @if($label)
        <x-mt::form.label :value="$label" :required="$required" />
    @endif
    
    <div class="relative">
        <textarea 
            x-data="{
                resize() {
                    $el.style.height = 'auto';
                    $el.style.height = $el.scrollHeight + 'px';
                }
            }"
            x-init="resize()"
            @input="resize()"
            @if($model) wire:model="{{ $model }}" @endif
            rows="{{ $rows }}"
            {{ $attributes->merge([
                'class' => 'mt-textarea ' . $textareaSizeClass . ' ' . ($error ? 'mt-textarea-error' : '')
            ]) }}
            style="overflow:hidden; min-height: 80px;"
        ></textarea>

        @if($error)
            <div class="absolute pointer-events-none top-3 right-3 mt-text-danger">
                <i class="fa-solid fa-circle-exclamation"></i>
            </div>
        @endif
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1.5" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1.5" />
    @endif
</div>
