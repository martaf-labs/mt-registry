{{--
    Composant : Badge / Tag
    Usage : 
    <x-mt::badge variant="success">Payé</x-mt::badge>
    <x-mt::badge variant="warning" dot>En attente</x-mt::badge>
    <x-mt::badge variant="info" icon="fa-solid fa-sync fa-spin">Traitement</x-mt::badge>
--}}

@props([
    'variant' => 'info', // success, danger, warning, info, gray
    'dot' => false,
    'icon' => null,
    'label' => null,
    'rounded' => 'full', // full, md, lg
])

@php
    $variantClass = [
        'success'   => 'mt-badge-success',
        'danger'    => 'mt-badge-danger',
        'warning'   => 'mt-badge-warning',
        'info'      => 'mt-badge-info',
        'gray'      => 'mt-badge-gray',
        'primary'   => 'mt-badge-primary',
        'secondary' => 'mt-badge-gray',
    ][$variant] ?? 'mt-badge-info';

    $roundedClass = [
        'full' => 'mt-rounded-full',
        'md'   => 'mt-rounded',
        'lg'   => 'mt-rounded-lg',
    ][$rounded] ?? 'mt-rounded-full';
@endphp

<span {{ $attributes->merge(['class' => 'mt-badge ' . $variantClass . ' ' . $roundedClass]) }}>
    @if($dot)
        <span class="mt-badge-dot"></span>
    @endif

    @if($icon)
        <i class="{{ $icon }} mr-1 text-[10px]"></i>
    @endif

    {{ $label ?? $slot }}
</span>
