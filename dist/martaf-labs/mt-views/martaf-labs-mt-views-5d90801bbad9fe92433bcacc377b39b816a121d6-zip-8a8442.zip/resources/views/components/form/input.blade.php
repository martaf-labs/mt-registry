@props([
    'label' => null,
    'type'  => 'text',
    'model' => null,
    'icon'  => null,
    'error' => null,
    'help'  => null,
    'required'  => false,
    'size'  => 'md',
])

@php
    $sizeClasses = [
        'sm' => 'mt-input-sm',
        'md' => '',
        'lg' => 'mt-input-lg',
    ];
    $inputSizeClass = $sizeClasses[$size] ?? '';
@endphp

<div class="w-full">
    @if($label)
        <x-mt::form.label :value="$label" :size="$size" :required="$required" />
    @endif

    <div class="relative">
        @if($icon)
            <div class="absolute inset-y-0 left-0 flex items-center pl-2 pointer-events-none lg:pl-4 mt-text-muted">
                <x-mt::icon :name="$icon" class="text-sm" />
            </div>
        @endif

        <input 
            type="{{ $type }}"
            @if($model) wire:model="{{ $model }}" @endif
            @if($required) required @endif
            {{ $attributes->merge([
                'class' => 'mt-input ' . $inputSizeClass . ' ' .
                    ($icon ? 'pl-8 lg:pl-16 ' : '') .
                    ($error ? 'mt-input-error' : '')
            ]) }}

            style="{{ $icon ? 'padding-left:3rem ' : '' }}"
        >
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1.5" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1.5" />
    @endif
</div>
