<div class="overflow-x-auto rounded-2xl mt-card">
    <table {{ $attributes->merge(['class' => 'w-full text-sm text-left']) }}>
        @if(isset($head))
            <thead style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                <tr class="[&>th]:px-6 [&>th]:py-4 [&>th]:font-bold">
                    <tr class="[&>th]:px-6 [&>th]:py-4 [&>th]:font-bold [&>th]:mt-text-muted [&>th]:text-xs [&>th]:uppercase [&>th]:tracking-wider"
                        style="background: rgba(var(--mt-text), 0.03)">
                        {{ $head }}
                    </tr>
                </tr>
            </thead>
        @endif
        
        <tbody class="divide-y" style="border-color: rgb(var(--mt-ui-card-border))">
            {{ $slot }}
        </tbody>
    </table>
</div>
