@props([
    'label' => '',
    'model' => '',
    'icon' => null, 
    'color' => null, 
    'pickerIcon' => 'fa-solid fa-palette', 
    'suggestAction' => null, 
    'suggestLabel' => 'Suggérer',
    'error' => null,
    'help' => null
])

<div {{ $attributes->merge(['class' => 'w-full']) }}>
    <div class="flex items-center justify-between mb-2">
        @if($label)
            <label class="mt-label">{{ $label }}</label>
        @endif

        @if($suggestAction)
            <button type="button"
                    wire:click="{{ $suggestAction }}"
                    wire:loading.attr="disabled"
                    class="inline-flex items-center text-xs font-medium transition-opacity mt-text-primary hover:opacity-75">
                <i class="mr-1 fa-solid fa-magic" wire:loading.remove wire:target="{{ $suggestAction }}"></i>
                <i class="mr-1 fa-solid fa-circle-notch fa-spin" wire:loading wire:target="{{ $suggestAction }}"></i>
                {{ $suggestLabel }}
            </button>
        @endif
    </div>

    <div class="relative" x-data="{ open: false }">
        <div class="flex gap-2">
            <div class="relative flex-1">
                @if($icon)
                    <div class="absolute -translate-y-1/2 left-3 top-1/2 mt-text-muted">
                        <i class="{{ $icon }}"></i>
                    </div>
                @endif

                @if($color)
                    <div class="absolute -translate-y-1/2 left-3 top-1/2">
                        <span class="px-3 py-1 rounded-full" style="background-color: {{ $color }}"></span>
                    </div>
                @endif

                <x-mt::form.input
                type="text"
                :icon="$icon"
                wire:model="{{ $model }}"
                {{ $attributes->whereDoesntStartWith(['wire:model', 'class']) }}
                />

                {{-- <x-mt:form.input type="text"
                       @if($model) wire:model="{{ $model }}" @endif
                       {{ $attributes->whereDoesntStartWith(['wire:model', 'class']) }}
                       class="mt-input {{ $icon || $color ? 'pl-10' : '' }} {{ $error ? 'mt-input-error' : '' }}"
                       :icon="$icon"
                    /> --}}
            </div>

            <button type="button"
                    @click="open = !open"
                    class="px-4 py-2.5 rounded-xl transition-colors mt-btn-icon"
                    style="border: 1px solid {{ $error ? 'rgb(var(--mt-danger))' : 'rgb(var(--mt-ui-card-border))' }}">
                <i class="{{ $pickerIcon }}"></i>
            </button>
        </div>

        <div x-show="open"
             @click.away="open = false"
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 scale-95"
             x-transition:enter-end="opacity-100 scale-100"
             class="absolute right-0 z-[60] w-72 p-4 mt-2 overflow-y-auto shadow-2xl max-h-80 rounded-2xl mt-card">
            
            <div class="flex flex-wrap gap-2">
                {{ $slot }}
            </div>
        </div>
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-2" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-2" />
    @endif
</div>
