@props([
    'href' => null, 
    'variant' => 'primary', 
    'size' => 'md',        
    'label' => null,     
    'loading' => null,     
    'icon' => null,
    'endIcon' => null,
    'error' => null,
    'help' => null,
    'disabled' => false,
])

@php
    $baseClasses = "mt-btn bg-red inline-flex items-center justify-center font-medium transition disabled:opacity-50 disabled:cursor-not-allowed";

    $variants = [
        'primary'   => 'mt-btn-primary',
        'secondary' => 'mt-btn-secondary',
        'danger'    => 'mt-btn-danger',
        'ghost'     => 'mt-btn-ghost',
    ];

    $sizes = [
        'sm' => 'mt-btn-sm',
        'md' => 'mt-btn-md',
        'lg' => 'mt-btn-lg',
    ];

    $classes = $baseClasses
        . ' ' . ($variants[$variant] ?? $variants['primary'])
        . ' ' . ($sizes[$size] ?? $sizes['md']);
@endphp

<div class="inline-flex flex-col">
    
    @php $tag = $href ? 'a' : 'button'; @endphp

    <{{ $tag }}
        @if($href) href="{{ $href }}" wire:navigate @endif
        {{ $attributes->merge(['class' => $classes, 'type' => 'button']) }}
        @if($loading) wire:loading.attr="disabled" wire:target="{{ $loading }}" @endif
        @if($disabled) disabled @endif
    >
        {{-- Spinner --}}
        {{-- @if($loading)
            <x-mt::icon name="circle-notch" class="mr-2 animate-spin"
               wire:loading wire:target="{{ $loading }}"></x-mt::icon>
        @endif --}}

        {{-- Icon --}}
        @if($icon)
            <x-mt::icon name="{{ $icon }}" class="mr-2" />
        @endif
        
        <span>{{ $label ?? $slot }}</span>
        
        {{-- End Icon --}}
        @if($endIcon)
            <x-mt::icon :name="$endIcon" class="ml-2" />
            
        @endif

    </{{ $tag }}>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-2" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-2" />
    @endif

</div>






{{--
    Composant : Bouton d'Action avec états de chargement
    Usage : 
    <x-mt::button 
        variant="primary" 
        icon="fa-solid fa-save" 
        loading="saveData" 
        wire:click="saveData"
        help="Enregistre les modifications actuelles"
    >
        Enregistrer
    </x-mt::button>

    Variantes : primary, secondary, danger, ghost
    Tailles : xs, sm, md, lg
--}}

@props([
    'href' => null, 
    'variant' => 'secondary', 
    'size'    => 'md',        
    'label' => null,     
    'loading' => null,     
    'icon'    => null,
    'endIcon'    => null, //icone de fin
    'error'   => null,
    'help'    => null,
    'disabled' => false, // Ajout de la prop disabled
])

@php
    $baseClasses = "inline-flex items-center justify-center font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed group transition-opacity duration-150 hover:opacity-50";
    
    $variants = [
        'primary'   => 'bg-green-600 text-white hover:bg-green-700 shadow-sm shadow-green-200 dark:shadow-none',
        'secondary' => 'border border-gray-700 text-gray-700 dark:text-gray-300',
        'danger'    => 'bg-red-600 text-white hover:bg-red-700 shadow-sm shadow-red-200 dark:shadow-none',
        'ghost'     => 'text-gray-600 hover:bg-gray-100 dark:text-gray-400',
    ];

    $sizes = [
        'sm' => 'px-3 py-1.5 text-xs rounded-lg',
        'md' => 'px-4 py-2.5 text-sm rounded-xl',
        'lg' => 'px-6 py-3 text-md  rounded-xl',
    ];

    $classes = $baseClasses . ' ' . ($variants[$variant] ?? $variants['primary']) . ' ' . ($sizes[$size] ?? $sizes['md']);
@endphp

<div class="inline-flex flex-col">
    @if ($href)

    <a href="{{ $href }}" wire:navigate
        {{ $attributes->merge(['class' => $classes, 'type' => 'button']) }}
        @if($loading) wire:loading.attr="disabled" wire:target="{{ $loading }}" @endif
        @if($disabled) disabled @endif
    >
        {{-- Spinner de chargement --}}
        @if($loading)
            <i class="mr-2 fa-solid fa-circle-notch fa-spin" wire:loading wire:target="{{ $loading }}"></i>
        @endif

        {{-- Icône (masquée si chargement en cours sur ce bouton) --}}
        @if($icon)
            <i class="mr-2 {{ $icon }}" 
               @if($loading) wire:loading.remove wire:target="{{ $loading }}" @endif>
            </i>
        @endif
        
        @if ($label)        
            <span>{{ $label }}</span>
        @else
             <span>{{ $slot }}</span>
        @endif
        
        @if($endIcon)
            <i class="ml-2 {{ $endIcon }}" 
               @if($loading) wire:loading.remove wire:target="{{ $loading }}" @endif>
            </i>
        @endif
    </a>

    @else

    <button 
        {{ $attributes->merge(['class' => $classes, 'type' => 'button']) }}
        @if($loading) wire:loading.attr="disabled" wire:target="{{ $loading }}" @endif
        @if($disabled) disabled @endif
    >
        {{-- Spinner de chargement --}}
        @if($loading)
            <i class="mr-2 fa-solid fa-circle-notch fa-spin" wire:loading wire:target="{{ $loading }}"></i>
        @endif

        {{-- Icône (masquée si chargement en cours sur ce bouton) --}}
        @if($icon)
            <i class="mr-2 {{ $icon }}" 
               @if($loading) wire:loading.remove wire:target="{{ $loading }}" @endif>
            </i>
        @endif
        
        @if ($label)        
            <span>{{ $label }}</span>
        @else
             <span>{{ $slot }}</span>
        @endif
        
        @if($endIcon)
            <i class="ml-2 {{ $endIcon }}" 
               @if($loading) wire:loading.remove wire:target="{{ $loading }}" @endif>
            </i>
        @endif
    </button>
    
    @endif
    

    {{-- Messages de feedback sous le bouton --}}
    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-2" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-2" />
    @endif
</div>

