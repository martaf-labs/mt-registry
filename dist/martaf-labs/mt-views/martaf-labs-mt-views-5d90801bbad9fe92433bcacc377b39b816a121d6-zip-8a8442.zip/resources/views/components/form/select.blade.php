@props([
    'label' => null,
    'model' => null,
    'error' => null,
    'help'  => null,
    'multiple' => false,
    'size' => 'md',
    'required' => false
])

@php
    
    $sizeClasses = [
        'sm' => 'mt-select-sm',
        'md' => '',
        'lg' => 'mt-select-lg',
    ];
    $selectSizeClass = $sizeClasses[$size] ?? '';
@endphp

<div class="w-full">
    @if($label)
        <x-mt::form.label :value="$label" :size="$size" :required="$required" />
    @endif

    <div class="relative">
        <select 
            @if($multiple) multiple @endif
            @if($model) wire:model="{{ $model }}" @endif
            @if($required) required @endif
            {{ $attributes->merge([
                'class' => 'mt-select ' . $selectSizeClass . ' ' .
                    ($multiple ? 'min-h-[120px] p-2 ' : 'appearance-none ') .
                    ($error ? 'mt-select-error' : '')
            ]) }}
            
        >
            {{ $slot }}
        </select>

        @if(!$multiple)
            <div class="absolute inset-y-0 right-0 flex items-center px-4 pointer-events-none mt-text-muted">
                <x-mt::icon name="chevron-down" class="text-xs" />
            </div>
        @endif
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" />
    @endif
</div>
