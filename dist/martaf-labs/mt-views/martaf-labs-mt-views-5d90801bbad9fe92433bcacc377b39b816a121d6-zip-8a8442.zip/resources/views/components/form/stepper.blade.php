@props([
    'steps' => [],
    'current' => 1
])

<div class="w-full py-4">
    <div class="relative flex items-center justify-start gap-2">
        {{-- Ligne de fond --}}
        {{-- <div class="absolute top-1/2 left-0 w-full h-0.5 -translate-y-1/2" --}}
             {{-- style="background: rgb(var(--mt-ui-card-border))"></div> --}}

        {{-- Ligne de progression --}}
        {{-- <div class="absolute top-1/2 left-0 h-0.5 -translate-y-1/2 transition-all duration-500"
             style="width: {{ (($current - 1) / (max(count($steps) - 1, 1))) * 100 }}%; background: rgb(var(--mt-primary))"></div> --}}

        @foreach($steps as $index => $stepInfo)
            @php 
                $stepNum = $index;
                $isCompleted = $current > $stepNum;
                $isActive = $current === $stepNum;
            @endphp

            <div class="relative z-10 flex flex-col items-center">
                <div class="flex items-center justify-center w-10 h-10 transition-all duration-300 border-2 rounded-full"
                     style="
                        @if($isActive)
                            background: rgba(var(--mt-primary), 0.2);
                            border-color: rgb(var(--mt-primary));
                            color: rgb(var(--mt-primary));
                        @elseif($isCompleted)
                            background: rgb(var(--mt-bg));
                            border-color: rgb(var(--mt-primary));
                            color: rgb(var(--mt-primary));
                        @else
                            background: rgb(var(--mt-bg));
                            border-color: rgb(var(--mt-ui-card-border));
                            color: rgba(var(--mt-text), 0.4);
                        @endif
                     ">
                    @if($isCompleted)
                        <x-mt::icon name="check" />
                    @else
                        <span class="text-sm font-bold">{{ $stepNum }}</span>
                    @endif
                </div>
            </div>
        @endforeach
    </div>
</div>
