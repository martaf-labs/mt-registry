@props([
    'label' => null,
    'model' => null,
    'options' => [],
    'placeholder' => 'Sélectionner...',
    'error' => null,
    'help' => null
])

<div class="w-full" x-data="{
    open: false,
    search: '',
    selectedId: @entangle($model),
    options: {{ json_encode($options) }},
    get filteredOptions() {
        if (this.search === '') return this.options;
        return Object.fromEntries(
            Object.entries(this.options).filter(([id, label]) => 
                label.toLowerCase().includes(this.search.toLowerCase())
            )
        );
    },
    get selectedLabel() {
        return this.options[this.selectedId] || '';
    }
}">
    @if($label)
        <x-mt::form.label :value="$label" />
    @endif

    <div class="relative">
        <div class="relative">
            <input type="text"
                   class="mt-input"
                   style="{{ $error ? 'border-color: rgb(var(--mt-danger))' : '' }}"
                   :placeholder="selectedLabel || '{{ $placeholder }}'"
                   x-model="search"
                   @click="open = true"
                   @click.away="open = false; search = ''">
            
            <div class="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none mt-text-muted">
                <i class="fa-solid fa-magnifying-glass text-xs" x-show="!open"></i>
                <i class="fa-solid fa-chevron-up text-xs" x-show="open"></i>
            </div>
        </div>

        <div x-show="open" 
             x-transition
             class="absolute z-[110] w-full mt-2 overflow-hidden shadow-2xl rounded-2xl max-h-60 overflow-y-auto mt-card"
             style="border: 1px solid rgb(var(--mt-ui-card-border))">
            
            <template x-for="(label, id) in filteredOptions" :key="id">
                <button type="button"
                        @click="selectedId = id; open = false; search = ''"
                        class="w-full px-4 py-2.5 text-left text-sm transition-colors flex items-center justify-between mt-text mt-btn-ghost">
                    <span x-text="label"></span>
                    <i class="fa-solid fa-check mt-text-primary opacity-0" :class="selectedId == id ? 'opacity-100' : ''"></i>
                </button>
            </template>

            <div x-show="Object.keys(filteredOptions).length === 0" class="px-4 py-8 text-center mt-text-muted">
                <i class="fa-solid fa-face-frown mb-2 block"></i>
                Aucun résultat pour "<span x-text="search"></span>"
            </div>
        </div>
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1.5" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1.5" />
    @endif
</div>
