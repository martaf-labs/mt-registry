@props([
    'label' => null,
    'model' => null,
    'onclick' => null,
    'error' => null,
    'help'  => null,
    'required' => false,
])

<div class="w-full">
    <label class="inline-flex items-start cursor-pointer group">
        {{-- Input caché (L'ordre est crucial pour 'peer') --}}
        <input type="checkbox" 
               @if($model) wire:model="{{ $model }}" @endif
               @if($onclick) wire:click="{{ $onclick }}" @endif
               @if($required) required @endif
               {{ $attributes->merge(['class' => 'sr-only peer']) }}
        >
        
        {{-- Le Switch (Track) --}}
        <div class="relative min-w-[44px] h-6 rounded-full transition-all duration-200
                    {{-- Couleurs Light --}}
                    bg-[rgb(var(--mt-ui-card-border))] 
                    {{-- Focus & Checked --}}
                    peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[rgba(var(--mt-success),0.2)] 
                    peer-checked:bg-[rgb(var(--mt-success))]
                    {{-- Thumb (le point blanc via pseudo-élément 'after') --}}
                    after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                    after:bg-white after:rounded-full after:h-5 after:w-5 
                    after:transition-all after:duration-200
                    peer-checked:after:translate-x-[20px]">
        </div>
        
        {{-- Texte et Feedback --}}
        <div class="ml-3">
            @if($label)
                <x-mt::form.label :value="$label" :required="$required" />
            @endif

            @if($error)
                <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1" />
            @elseif($help)
                <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1" />
            @endif
        </div>
    </label>
</div>