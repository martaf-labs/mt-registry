@props([
    'type' => 'info',
    'message' => null,
    'variant' => 'block',
    'dismissible' => false,
])

@php
    $config = [
        'info' => [
            'icon'   => 'fa-solid fa-circle-info',
            'block'  => 'mt-alert mt-alert-info',
            'inline' => 'mt-text-info',
        ],
        'error' => [
            'icon'   => 'fa-solid fa-circle-exclamation',
            'block'  => 'mt-alert mt-alert-danger',
            'inline' => 'mt-text-danger',
        ],
        'success' => [
            'icon'   => 'fa-solid fa-circle-check',
            'block'  => 'mt-alert mt-alert-success',
            'inline' => 'mt-text-success',
        ],
        'warning' => [
            'icon'   => 'fa-solid fa-triangle-exclamation',
            'block'  => 'mt-alert mt-alert-warning',
            'inline' => 'mt-text-warning',
        ],
        'help' => [
            'icon'   => 'fa-solid fa-question-circle',
            'block'  => 'mt-alert',
            'inline' => 'mt-text-muted',
        ],
    ][$type] ?? [];
@endphp

@if($variant === 'block')
    <div x-data="{ show: true }" 
         x-show="show" 
         {{ $attributes->merge(['class' => $config['block']]) }}
         role="alert">
        
        <i class="{{ $config['icon'] }} mt-0.5 flex-shrink-0"></i>
        
        <div class="flex-1 text-sm font-medium">
            {{ $message ?? $slot }}
        </div>

        @if($dismissible)
            <button @click="show = false" type="button" class="ml-auto p-1.5 inline-flex h-8 w-8 rounded-lg transition-opacity hover:opacity-70">
                <i class="fa-solid fa-xmark"></i>
            </button>
        @endif
    </div>
@else
    <div {{ $attributes->merge(['class' => 'flex items-center mt-1.5 text-xs ' . $config['inline']]) }}>
        <i class="{{ $config['icon'] }} mr-1.5"></i>
        <span>{{ $message ?? $slot }}</span>
    </div>
@endif
