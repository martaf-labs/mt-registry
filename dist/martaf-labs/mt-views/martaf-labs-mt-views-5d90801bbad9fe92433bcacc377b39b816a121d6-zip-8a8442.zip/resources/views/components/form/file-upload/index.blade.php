@props([
    'id'        => null,
    'name'        => '',
    'itemType'    => 'file',
    'multiple'    => false,
    'accept'      => null,
    'oldValue'    => null,
    'placeholder' => null,
    'maxSize'     => null,
    'label'       => null,
    'required'    => false,
    'hint'        => null,
    'error'       => null,
    'size'        => 'md',
])

@php
    $itemId = $id ?? 'mt-upload-' . $name . '-' . uniqid();

    $resolvedAccept = $accept ?? match(true) {
        str_contains($itemType, 'image') => 'image/*',
        str_contains($itemType, 'video') => 'video/*',
        default                          => '.pdf,.doc,.docx,.xls,.xlsx,.txt',
    };

    $resolvedPlaceholder = $placeholder ?? match(true) {
        str_contains($itemType, 'image') => 'Glissez votre image ici',
        str_contains($itemType, 'video') => 'Glissez votre vidéo ici',
        default                          => 'Glissez vos fichiers ici',
    };

    $formatHint = match(true) {
        str_contains($itemType, 'image') => 'PNG, JPG, GIF, WEBP · max ' . ($maxSize ?? '3') . ' Mo',
        str_contains($itemType, 'video') => 'MP4, MOV, AVI · max ' . ($maxSize ?? '50') . ' Mo',
        default                          => 'PDF, DOC, XLS, TXT · max ' . ($maxSize ?? '10') . ' Mo',
    };

    $hasExistingFile = !empty($oldValue);
    $isExistingImage = $hasExistingFile && str_contains($itemType, 'image');

    $typeIcon = match(true) {
        str_contains($itemType, 'image') => 'mt-icon-image',
        str_contains($itemType, 'video') => 'mt-icon-video',
        default                          => 'mt-icon-file',
    };

    // Récupère le nom du wire:model ex: "photo" ou "form.avatar"
    $wireModelName = $attributes->whereStartsWith('wire:model')->first();
@endphp

<div
    x-data="{
        previews: @js($hasExistingFile ? [[
            'type' => str_contains($itemType, 'image') ? 'image' : 'file',
            'url'  => str_contains($itemType, 'image') ? asset('storage/' . $oldValue) : null,
            'name' => basename($oldValue),
        ]] : []),
        isUploading: false,
        isDragging:  false,
        wireModel:   @js($wireModelName),
        isMultiple:  @js((bool) $multiple),

        fileChosen(event) {
            const files = Array.from(event.target.files);
            if (!files.length) return;

            {{-- Aperçu immédiat côté client --}}
            const newPreviews = files.map(file => (
                file.type.startsWith('image/')
                    ? { type: 'image', url: URL.createObjectURL(file), name: file.name }
                    : { type: 'file',  url: null,                      name: file.name }
            ));

            @if($multiple)
                this.previews = [...this.previews, ...newPreviews];
            @else
                this.previews = newPreviews;
            @endif

            {{-- Upload via @this avec callbacks explicites --}}
            this.isUploading = true;
            const self = this;

            @if($multiple)
                @this.uploadMultiple(
                    this.wireModel,
                    event.target.files,
                    function()  { self.isUploading = false; },   {{-- finish --}}
                    function()  { self.isUploading = false; },   {{-- error --}}
                    function(e) {}                                {{-- progress --}}
                );
            @else
                @this.upload(
                    this.wireModel,
                    event.target.files[0],
                    function()  { self.isUploading = false; },   {{-- finish --}}
                    function()  { self.isUploading = false; },   {{-- error --}}
                    function(e) {}                                {{-- progress --}}
                );
            @endif
        },

        removePreview(index) {
            this.previews.splice(index, 1);
            if (this.$refs.fileInput) this.$refs.fileInput.value = '';
        },

        onDrop(event) {
            this.isDragging = false;
            const dt = event.dataTransfer;
            if (dt && dt.files.length) {
                this.$refs.fileInput.files = dt.files;
                this.$refs.fileInput.dispatchEvent(new Event('change'));
            }
        },
    }"
    class="w-full"
>

    @if($label)
        <x-mt::form.label :value="$label" :size="$size" :required="$required" />
    @endif

    {{-- Zone drag & drop --}}
    <label
        for="{{ $itemId }}"
        @dragover.prevent="isDragging = true"
        @dragleave.prevent="isDragging = false"
        @drop.prevent="onDrop($event)"
        :style="isDragging
            ? 'border-color: rgb(var(--mt-primary)); background: rgba(var(--mt-primary), 0.05); transform: scale(1.01)'
            : 'border-color: rgb(var(--mt-ui-card-border))'"
        class="group relative flex flex-col items-center justify-center w-full
               min-h-[160px] px-6 py-8 cursor-pointer
               border-2 border-dashed rounded-2xl
               transition-all duration-200 ease-out"
        style="background: rgba(var(--mt-text), 0.02)"
    >

        {{-- Loader upload --}}
        <template x-if="isUploading">
            <div class="flex flex-col items-center gap-3 py-2">
                <div class="relative w-12 h-12">
                    <div class="absolute inset-0 border-2 rounded-full"
                         style="border-color: rgba(var(--mt-ui-card-border), 0.5)"></div>
                    <div class="absolute inset-0 border-2 border-transparent rounded-full animate-spin"
                         style="border-top-color: rgb(var(--mt-primary))"></div>
                    <div class="absolute flex items-center justify-center rounded-full inset-2"
                         style="background: rgba(var(--mt-primary), 0.1)">
                        <i class="{{ $typeIcon }} text-sm" style="color: rgb(var(--mt-primary))"></i>
                    </div>
                </div>
                <div class="text-center">
                    <p class="text-sm font-medium mt-text">Téléchargement en cours…</p>
                    <p class="text-xs mt-text-muted mt-0.5">Veuillez patienter</p>
                </div>
            </div>
        </template>

        {{-- Aperçus fichiers --}}
        <template x-if="!isUploading && previews.length > 0">
            <div class="w-full">
                <div class="flex flex-wrap justify-center gap-3 mb-4">
                    <template x-for="(preview, index) in previews" :key="index">
                        <div class="relative group/item">

                            {{-- Image --}}
                            <template x-if="preview.type === 'image'">
                                <div class="w-20 h-20 overflow-hidden shadow-md rounded-xl"
                                     style="ring: 2px solid rgb(var(--mt-ui-card-border))">
                                    <img :src="preview.url" :alt="preview.name" class="object-cover w-full h-full">
                                </div>
                            </template>

                            {{-- Fichier non-image --}}
                            <template x-if="preview.type !== 'image'">
                                <div class="w-20 h-20 rounded-xl flex flex-col items-center justify-center gap-1.5 mt-bg-secondary"
                                     style="border: 1px solid rgb(var(--mt-ui-card-border))">
                                    <i class="{{ $typeIcon }} text-xl mt-text-muted"></i>
                                    <span
                                        x-text="preview.name.length > 10 ? preview.name.substring(0,9)+'…' : preview.name"
                                        class="text-[10px] mt-text-muted text-center px-1 leading-tight"
                                    ></span>
                                </div>
                            </template>

                            {{-- Bouton supprimer --}}
                            <button
                                type="button"
                                @click.prevent="removePreview(index)"
                                class="absolute -top-1.5 -right-1.5
                                       w-5 h-5 rounded-full flex items-center justify-center
                                       text-white shadow-md
                                       opacity-0 group-hover/item:opacity-100
                                       scale-75 group-hover/item:scale-100
                                       transition-all duration-150"
                                style="background: rgb(var(--mt-danger))"
                            >
                                <i class="mt-icon-x text-[9px]"></i>
                            </button>

                        </div>
                    </template>
                </div>

                <div class="text-center">
                    <p class="text-xs mt-text-muted">
                        @if($multiple) Cliquez pour ajouter d'autres fichiers
                        @else Cliquez pour remplacer le fichier
                        @endif
                    </p>
                </div>
            </div>
        </template>

        {{-- Zone vide — état initial --}}
        <template x-if="!isUploading && previews.length === 0">
            <div class="flex flex-col items-center gap-4 text-center pointer-events-none select-none">

                <div class="relative">
                    <div class="flex items-center justify-center transition-colors duration-200 w-14 h-14 rounded-2xl"
                         style="background: rgba(var(--mt-primary), 0.08)">
                        <i class="{{ $typeIcon }} text-2xl transition-transform duration-200"
                           style="color: rgb(var(--mt-primary))"></i>
                    </div>
                    <div class="absolute flex items-center justify-center w-5 h-5 rounded-full shadow-sm -top-1 -right-1"
                         style="background: rgb(var(--mt-primary))">
                        <i class="mt-icon-arrow-up text-white text-[8px] transition-transform duration-200"></i>
                    </div>
                </div>

                <div>
                    <p class="text-sm font-medium mt-text">{{ $resolvedPlaceholder }}</p>
                    <p class="mt-0.5 text-xs mt-text-muted">
                        ou <span class="font-medium underline-offset-2 hover:underline"
                                 style="color: rgb(var(--mt-primary))">parcourez vos fichiers</span>
                    </p>
                    <p class="mt-2 text-[11px] mt-text-muted" style="opacity: 0.5">{{ $formatHint }}</p>
                </div>

            </div>
        </template>

    </label>

    {{-- Input fichier caché — SANS wire:model, SANS les listeners livewire-upload-* --}}
    <input
        type="file"
        id="{{ $itemId }}"
        x-ref="fileInput"
        @if($multiple) multiple @endif
        accept="{{ $resolvedAccept }}"
        @change="fileChosen($event)"
        class="sr-only"
    >

    {{-- Erreur --}}
    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-2" />
    @endif

</div>