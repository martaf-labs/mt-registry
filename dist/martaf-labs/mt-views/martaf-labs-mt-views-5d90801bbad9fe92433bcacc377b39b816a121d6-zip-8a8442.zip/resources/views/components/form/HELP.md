# 📚 Guide d'utilisation des Composants Blade

Ce projet utilise une bibliothèque de composants personnalisés située dans `resources/views/components/`. Tous les composants supportent nativement le **Dark Mode** (via Tailwind `dark:`) et sont optimisés pour **Laravel Livewire**.

---

## 1. `x-input-picker` (Sélecteur avec Input)
Un composant hybride permettant la saisie manuelle et la sélection via un menu déroulant (dropdown).

**Usage :**
```html
<x-input-picker 
    label="Icône" 
    model="champs.0.icone"
    :icon="$icone_actuelle"
    pickerIcon="fa-solid fa-palette"
    suggestAction="suggererIcone(0)"
>
    @foreach($options as $val => $label)
        <button type="button" @click="$wire.set('model', '{{ $val }}'); open = false;">
            <i class="{{ $val }}"></i>
        </button>
    @endforeach
</x-input-picker>

. x-feedback (Alertes et Aide)Gère l'affichage des erreurs, informations, succès et messages d'aide.Types disponibles : info, error, success, warning, helpVarianteUsageblock (défaut)Grandes bannières d'alerte.inlinePetits messages sous les inputs.Exemple :HTML<x-feedback type="success" message="Action réussie !" dismissible />

<x-feedback type="error" variant="inline" :message="$errors->first('email')" />
3. x-button (Bouton Intelligent)Gère les variantes de style et l'état de chargement Livewire automatiquement.Props :variant : primary (bleu), secondary (blanc/gris), danger (rouge), ghost (transparent).size : sm, md, lg.loading : Nom de la fonction wire:click à surveiller pour afficher le spinner.Exemple :HTML<x-button variant="primary" loading="save" wire:click="save" icon="fa-solid fa-save">
    Enregistrer
</x-button>
4. x-textarea (Champ Multi-ligne)Une zone de texte stylisée avec gestion automatique des erreurs.Exemple :HTML<x-textarea 
    label="Description" 
    model="description" 
    rows="6" 
    placeholder="Parlez-nous de vous..." 
/>
5. x-radio-group (Sélecteur sous forme de Cartes)Remplace les boutons radio classiques par des cartes cliquables plus modernes.Usage :HTML@php
    $options = [
        'pro' => ['title' => 'Professionnel', 'description' => 'Accès complet'],
        'perso' => ['title' => 'Personnel', 'description' => 'Usage limité']
    ];
@endphp

<x-radio-group label="Type de compte" model="account_type" :options="$options" />
6. x-fieldset (Conteneur Logique)Permet de grouper des éléments de formulaire avec une légende et une icône.Exemple :HTML<x-fieldset 
    legend="Sécurité" 
    icon="fa-solid fa-lock" 
    description="Gérez vos paramètres de confidentialité."
>
    <x-input-picker ... />
</x-fieldset>
🛠 Installation & DépendancesTailwind CSS : Assurez-vous d'avoir les couleurs primary configurées dans votre tailwind.config.js.Alpine.js : Requis pour le fonctionnement du Picker, du Fieldset et du Button (inclus par défaut avec Livewire).FontAwesome : Les composants utilisent les classes fa-solid pour les icônes.Exemple de configuration Tailwind :JavaScript// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9ff',
          600: '#0284c7', // Couleur principale
          700: '#0369a1',
        },
      },
    },
  },
}

Ce document permet à n'importe quel développeur de l'équipe de comprendre l'interface 



<!-- Exemple de mise en œuvre complète (Livewire)
Voici comment assembler le tout dans une vue pour créer un formulaire multi-étapes professionnel : -->

<div class="max-w-2xl mx-auto p-8 bg-white dark:bg-zinc-900 rounded-3xl shadow-sm border border-gray-100 dark:border-zinc-800">
    
    {{-- 1. Le Stepper --}}
    <x-mt::form.stepper :current="$step" :steps="['Profil', 'Détails', 'Finalisation']" />

    <form wire:submit.prevent="save" class="mt-12">
        
        {{-- Étape 1 --}}
        <x-mt::form.step :step="1" :current="$step">
            <x-mt::form.input label="Prénom" model="firstname" icon="fa-solid fa-user" />
            <x-mt::form.input label="Nom" model="lastname" />
        </x-mt::form.step>

        {{-- Étape 2 --}}
        <x-mt::form.step :step="2" :current="$step">
            <x-mt::form.radio-group label="Type de compte" model="account_type" :options="['pro' => 'Professionnel', 'perso' => 'Personnel']" />
            <x-mt::form.textarea label="Votre bio" model="bio" />
        </x-mt::form.step>

        {{-- Étape 3 --}}
        <x-mt::form.step :step="3" :current="$step">
            <x-mt::form.empty-state title="Presque fini !" description="Vérifiez vos informations avant de confirmer." icon="fa-solid fa-rocket" />
        </x-mt::form.step>

        {{-- Navigation --}}
        <div class="flex justify-between mt-10 pt-6 border-t border-gray-100 dark:border-zinc-800">
            @if($step > 1)
                <x-mt::button variant="ghost" wire:click="$set('step', {{ $step - 1 }})" icon="fa-solid fa-arrow-left">
                    Précédent
                </x-mt::button>
            @else
                <div></div> {{-- Spacer --}}
            @endif

            @if($step < 3)
                <x-mt::button wire:click="$set('step', {{ $step + 1 }})">
                    Suivant <i class="fa-solid fa-arrow-right ml-2 text-xs"></i>
                </x-mt::button>
            @else
                <x-mt::button variant="primary" type="submit" loading="save">
                    Confirmer et Créer
                </x-mt::button>
            @endif
        </div>
    </form>
</div>