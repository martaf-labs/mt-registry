{{--
    Composant : Step (Conteneur d'étape)
    Usage : 
    <x-mt::form.step :step="1" :current="$step">
        <x-mt::form.input label="Nom" model="name" />
    </x-mt::form.step>
--}}

@props(['step', 'current'])

<div x-show="{{ $current }} == {{ $step }}"
     x-transition:enter="transition ease-out duration-300"
     x-transition:enter-start="opacity-0 translate-x-8"
     x-transition:enter-end="opacity-100 translate-x-0"
     x-transition:leave="transition ease-in duration-200"
     x-transition:leave-start="opacity-100 translate-x-0"
     x-transition:leave-end="opacity-0 -translate-x-8"
     style="display: none;"
     {{ $attributes->merge(['class' => 'space-y-6']) }}>
    {{ $slot }}
</div>
