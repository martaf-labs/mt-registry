@props([
    'value' => null, 
    'required' => false,
    'isMultilangualField' => false,
    'availableLocales' => [],
    'help' => null,
    'size' => 'md',
])

@php
    $sizeClasses = ['sm' => 'text-xs', 'md' => 'text-sm', 'lg' => 'text-base'];
    $fontSize = $sizeClasses[$size] ?? $sizeClasses['md'];
@endphp

<div {{ $attributes->merge(['class' => "mt-label flex items-center justify-start w-full $fontSize"]) }}>
    <span class="inline-block">
        {{ $value ?? $slot }}
        @if($required)
            <span class="ml-1 mt-text-danger" title="Ce champ est obligatoire">*</span>
        @endif
    </span>

    @if($isMultilangualField && count(get_available_locales()) > 1)
        <nav class="flex space-x-2 overflow-x-auto ms-3">
            @foreach(get_available_locales() as $langCode => $langOptions)
                <button
                    type="button"
                    @click="activeTab = '{{ $langCode }}'"
                    class="px-1 py-1 text-sm font-medium transition-colors duration-200 border-b-2 whitespace-nowrap rounded-t-md"
                    :class="{
                        'border-[rgb(var(--mt-primary))] text-[rgb(var(--mt-primary))] bg-[rgba(var(--mt-primary),0.08)]': activeTab === '{{ $langCode }}',
                        'border-transparent mt-text-muted': activeTab !== '{{ $langCode }}'
                    }"
                >
                    {{ $langCode }}
                    @if($loop->first && $required)<span class="font-medium mt-text-danger ps-1/2">*</span>@endif
                </button>
            @endforeach
        </nav>
    @endif

    @if($help)
        <span x-data="{ tooltip: false }" class="relative ml-2">
            <i @mouseenter="tooltip = true" 
               @mouseleave="tooltip = false" 
               class="fa-solid fa-circle-question mt-text-muted cursor-help text-[10px]"></i>
            
            <div x-show="tooltip" 
                 x-transition 
                 class="absolute z-50 w-48 p-2 mt-2 text-xs font-normal rounded-lg shadow-xl -left-1 bottom-6 mt-card mt-text"
                 style="display: none;">
                {{ $help }}
                <div class="absolute w-2 h-2 rotate-45 -bottom-1 left-2 mt-bg-card"></div>
            </div>
        </span>
    @endif
</div>
