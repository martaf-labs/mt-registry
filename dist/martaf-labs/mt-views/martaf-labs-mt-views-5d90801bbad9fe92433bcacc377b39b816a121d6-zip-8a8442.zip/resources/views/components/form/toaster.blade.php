<div x-data="{ 
    notifications: [],
    add(e) {
        const id = Date.now();
        const notification = { id, type: e.detail.type || 'info', message: e.detail.message, show: false };
        this.notifications.push(notification);
        setTimeout(() => { 
            const index = this.notifications.findIndex(n => n.id === id);
            if(index !== -1) this.notifications[index].show = true; 
        }, 10);
        setTimeout(() => { this.remove(id) }, 5000);
    },
    remove(id) {
        const index = this.notifications.findIndex(n => n.id === id);
        if(index !== -1) {
            this.notifications[index].show = false;
            setTimeout(() => { this.notifications = this.notifications.filter(n => n.id !== id); }, 300);
        }
    }
}"
@toast.window="add($event)"
class="fixed top-5 right-5 z-[200] flex flex-col gap-3 w-full max-w-sm">
    
    <template x-for="notification in notifications" :key="notification.id">
        <div x-show="notification.show"
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="translate-x-full opacity-0"
             x-transition:enter-end="translate-x-0 opacity-100"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0 translate-y-2"
             class="relative p-4 rounded-2xl shadow-2xl flex items-center gap-3 transition-all mt-card"
             :style="{
                'border-left': notification.type === 'success' ? '3px solid rgb(var(--mt-success))' :
                               notification.type === 'error'   ? '3px solid rgb(var(--mt-danger))' :
                               notification.type === 'warning' ? '3px solid rgb(var(--mt-warning))' :
                               '3px solid rgb(var(--mt-info))'
             }">
            
            <div class="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center"
                 :style="{
                    'background': notification.type === 'success' ? 'rgba(var(--mt-success), 0.12)' :
                                  notification.type === 'error'   ? 'rgba(var(--mt-danger), 0.12)' :
                                  notification.type === 'warning' ? 'rgba(var(--mt-warning), 0.12)' :
                                  'rgba(var(--mt-info), 0.12)',
                    'color': notification.type === 'success' ? 'rgb(var(--mt-success))' :
                             notification.type === 'error'   ? 'rgb(var(--mt-danger))' :
                             notification.type === 'warning' ? 'rgb(var(--mt-warning))' :
                             'rgb(var(--mt-info))'
                 }">
                <i class="fa-solid" :class="{
                    'fa-check': notification.type === 'success',
                    'fa-xmark': notification.type === 'error',
                    'fa-triangle-exclamation': notification.type === 'warning',
                    'fa-info':  notification.type === 'info',
                }"></i>
            </div>

            <div class="flex-1">
                <p class="text-sm font-semibold mt-text" x-text="notification.message"></p>
            </div>

            <button @click="remove(notification.id)" class="mt-text-muted hover:opacity-75 transition-opacity mt-btn-icon mt-btn-icon-sm">
                <i class="fa-solid fa-xmark text-xs"></i>
            </button>
        </div>
    </template>
</div>
