@props([
    'items' => false,
    'progressChart' => 'line',
])

@if ($items)

@php
    $existsItemsCount=count(array_filter($items, function($item){
        return $item['status'] == 'completed';
    }));
    $itemsCount=count($items);
@endphp

<div>
    
    <div class="space-y-4">
        
    @forelse ($items as $item)

    @php
        $itemStatus=$item['status'];
        $itemColor='';       
        $itemIcon='';
        switch ($itemStatus) {
            case 'completed':
                $itemIcon="fas fa-check-circle doc-completed";
                $itemColor="green";
                break;
            case 'missing':
                $itemIcon="fas fa-times-circle doc-missing";
                $itemColor="red";
                break;  
            case 'pending':
                $itemIcon="fas fa-clock doc-pending";
                $itemColor="yellow";
                break;            
            default:
                break;
        }

    @endphp

    <div class="flex items-center justify-between">
        <div class="flex items-center">
            <div class="mr-3">
                <i class="{{ $item['icon'] }} text-{{ $itemColor }}-500 text-md"></i>
            </div>
            <div>
                <p class="font-medium text-sm text-gray-900 dark:text-white">{{ $item['text'] }}</p>
                <p class="text-xs text-gray-500">{{ $item['subText'] }}</p>
            </div>
        </div>
        <span class="text-{{ $itemColor }}-600">
            <i class="{{ $itemIcon }}"></i>
        </span>
    </div>
        
    @empty
        
    @endforelse
    </div>
    
    @php
        $existsItemsCount=count(array_filter($items, function($item){
            return $item['status'] == 'completed';
        }));

        $itemsCount=count($items);

        $progressPercent=intVal(($existsItemsCount * 100) / $itemsCount);
        $progressText= $existsItemsCount."/".$itemsCount." ".(($itemsCount > 1) ? '' : '');
        $color =''; 

        if ($progressPercent <= 25) {
            $color = 'red';
        }
        elseif ($progressPercent > 25 && $progressPercent <= 50) {
            $color = 'yellow';
        }
        elseif ($progressPercent > 50 && $progressPercent <= 75) {
            $color = 'orange';
        }
        elseif ($progressPercent > 75 && $progressPercent <= 99) {
            $color = 'lime';
        }
        else {
            if ($progressPercent == 100) {
                $color = 'green';
            }
        }
        
    @endphp

    <div class="mt-4 pt-4 border-t border-gray-200">
        <div class="flex justify-between text-sm">
            <span class="text-gray-600 text-xs">Progression</span>
            <span class="font-medium text-xs text-{{ $color }}-600">{{ $progressText }}</span>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-2 mt-1">
            @if($progressChart == 'line')
            <div class="bg-{{ $color }}-500 h-2 rounded-full animate-pulse" style="width: {{  $progressPercent }}%"></div>
            @endif
        </div>
    </div>
</div>
@endif