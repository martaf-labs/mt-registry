@php

    $markedTerm=(isset($markedTerm)) ? $markedTerm : '';

    //variables de du block d'element
    $block=[];
    $blockModel='';
    
    if (isset($user)) {
        
        $blockModel="user";
        $defautOptions=[
            'role'=>[
                'label'=>ucwords($user->role),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
        ];

        $block=[
            'titre' => (strlen($markedTerm)>0)? markTerms($user->name, $markedTerm) : $user->name,
            'image' => $user->imageUrl(),
            'route' => (isset($route)) ? $route : '' ,
            'options' => (isset($options)) ? $options : $defautOptions ,
        ];
        
    }

    if (isset($categorie)) {
        
        $blockModel="categorie";
        $defautOptions=[
            'engins'=>[
                'label'=>count($categorie->engins),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
        ];

        $block=[
            'titre' => (strlen($markedTerm)>0)? markTerms($categorie->nom, $markedTerm) : $categorie->nom,
            'icone' => 'bi bi-tag',
            'route' => (isset($route)) ? $route : '' ,
            'options' => (isset($options)) ? $options : $defautOptions ,
        ];
        
    }
    
    if (isset($engin)) {
        
        $blockModel="engin";
        $defautOptions=[
            'statut'=>[
                'label'=>ucwords($engin->statut),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
            'etat'=>[
                'label'=>"Etat: ".ucwords($engin->etat),
                'class'=>'fg-coul1 fst-italic',
            ],
        ];

        $block=[
            'titre' => (strlen($markedTerm)>0)? markTerms($engin->nom, $markedTerm) : $engin->nom,
            'image' => $engin->imageUrl(),
            'route' => (isset($route)) ? $route : '' ,
            'options' => (isset($options)) ? $options : $defautOptions ,
        ];
        
    }

    if (isset($caracteristique)) {
        
        $blockModel="caracteristique";
        $defautOptions=[
            'nombreengin'=>[
                'label'=>count($caracteristique->engins),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
        ];

        $block=[
            'titre' => (strlen($markedTerm)>0)? markTerms($caracteristique->nom, $markedTerm) : $caracteristique->nom,
            'icone' => 'bi bi-tag',
            'route' => (isset($route)) ? $route : '' ,
            'options' => (isset($options)) ? $options : $defautOptions ,
        ];
        
    }
    
    if (isset($realisation)) {
        
        $blockModel="realisation";
        $defautOptions=[
            'statut'=>[
                'label'=>ucwords($realisation->statut),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
        ];

        $block=[
            'titre' => (strlen($markedTerm)>0)? markTerms($realisation->titre, $markedTerm) : $realisation->titre,
            'image' => $realisation->imageUrl(),
            'route' => (isset($route)) ? $route : '' ,
            'options' => (isset($options)) ? $options : $defautOptions ,
        ];
        
    }

    if (isset($image)) {
        
        $blockModel="image";
        $defautOptions=[];

        $block=[
            'titre' => (strlen($markedTerm)>0)? markTerms($image->nom, $markedTerm) : $image->nom,
            'image' => $image->imageUrl(),
            'route' => (isset($route)) ? $route : '' ,
            'options' => (isset($options)) ? $options : $defautOptions ,
        ];
        
    }

    if (isset($video)) {
        
        $blockModel="video";
        $defautOptions=[
            'vues'=>[
                'label'=>($video->vues>1) ? add_zero($video->vues).' Vues' : add_zero($video->vues+0).' Vue',
                'class'=>'bi bi-eye',
            ]
        ];

        $block=[
            'titre' => (strlen($markedTerm)>0)? markTerms($video->titre, $markedTerm) : $video->titre,
            'image' => $video->imageUrl(),
            'video' => $video->videoUrl(),
            'route' => (isset($route)) ? $route : '' ,
            'options' => (isset($options)) ? $options : $defautOptions ,
        ];
        
    }


@endphp

@if (isset($block) && count($block) >0)
    <a href="{{ $block['route'] }}" class="">
        <div class="container-fluid">
            
            @if (in_array($blockModel, ['categorie', 'caracteristique']))
                <div class="px-2 py-1 shadow-sm rounded-1 d-flex flex-row flex-nowrap justify-content-between">
                    @isset($block['titre'])
                        <span class="fg-coul3 fs-80">{!! \Illuminate\Support\Str::substr( $block['titre'], 0, 60) !!} @if(strlen($block['titre'] ) > 60) ... @endif</span>
                    @endisset
                    @isset($block['options'])
                        @foreach ($block['options'] as $blockOption)
                            @if(!$loop->first) | @endif <span class="{{ $blockOption['class'] }} fs-80"> {{ $blockOption['label'] }}</span>
                        @endforeach
                    @endisset
                </div>
            @else

                @if ($blockModel=='video')
                    <div class="container-fluid video-container rounded-1">
                        <video class="" controls muted poster="">
                            <source src="{{ $block['video'] }}" type="">
                        </video>
                    </div>
                @else
                    <div class="@if(in_array($blockModel,['user'])) mtblock-sqr rounded-circle @else mtblock-rect rounded-1 @endif" style="background-image:url({{ $block['image'] }});">
                    </div>
                @endif

                <div class="px-1 d-flex flex-column  @if(in_array($blockModel,['user'])) align-items-center @else align-items-start @endif justify-content-start overflow-hidden">
                    @isset($block['options'])
                        <div class="">
                            @foreach ($block['options'] as $blockOption)
                            @if(!$loop->first) | @endif <span class="{{ $blockOption['class'] }} fs-80"> {{ $blockOption['label'] }}</span>
                            @endforeach
                        </div>
                    @endisset
        
                    @isset($block['titre'])
                        <h6 class="fg-coul3 fs-80">{!! \Illuminate\Support\Str::substr( $block['titre'], 0, 60) !!} @if(strlen($block['titre'] ) > 60) ... @endif</h6>
                    @endisset
                    
                </div>
            @endif

        </div>
    </a>
@endif
