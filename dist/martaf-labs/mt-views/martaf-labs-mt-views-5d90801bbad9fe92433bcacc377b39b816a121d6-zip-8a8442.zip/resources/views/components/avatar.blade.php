@props([
    'name' => '',
    'image' => null,
    'icon' => null,
    'size' => '12',
    'rounded' => 'full',
    'variant' => 'gray',
])

@php
    // $initials = collect(explode(' ', trim($name)))
    //     ->filter()
    //     ->map(fn ($w) => mb_strtoupper(mb_substr($w, 0, 1)))
    //     ->take(2)
    //     ->implode('') ?: 'NA';
    $initials = getInitials($name);
@endphp

<div class="relative h-{{ $size }} w-{{ $size }} flex items-center justify-center rounded-{{ $rounded }} mt-bg-primary-light overflow-hidden ">
    
    @if ($image)
    {{-- <img
        src="{{ $image ? $image : '' }}"
        alt="{{ $name }}"
        class="absolute inset-0 object-cover w-full h-full"
     lseifnerror="this.remove();"
     loading="lazy"
    />   --}}
    <x-mt::image-loader
        src="{{ $image ? $image : '' }}"
        alt="{{ $name }}"
        class="absolute inset-0 object-cover w-full h-full"
        lseifnerror="this.remove();"
        />
    @elseif ($icon)
    <x-mt::icon name="{{ $icon }}" class="text-[{{ 20 + $size }}px] font-semibold mt-text"></x-mt::icon>
    @else
    <span class="text-[{{ 10 + $size }}px] font-semibold mt-text">
        {{ $initials }}
    </span>
    @endif
</div>
