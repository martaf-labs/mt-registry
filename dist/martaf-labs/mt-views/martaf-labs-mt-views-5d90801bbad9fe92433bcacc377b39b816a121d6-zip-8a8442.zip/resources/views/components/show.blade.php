@props(['jsonParams'])

@php
    $layout=getActiveLayout();//cette variable vide par defaut permet de determiner le layout en cours: app ou guest

    //decodages de la variable json parametres du composant
    $params=json_decode($jsonParams, true); //convertir tout les element de parametre en objet

    if (isset($params['user'])) {
        //recuperation de l'element
        $user= ($params['user'] >0 ) ? App\Models\User::findOrFail($params['user']) : [];

        $showTitre=$user->name;
        $showImage=$user->imageUrl();
        $showDetails=$user->details;

        //autres
        $othersFields=[
            'nom'=>$user->name,
            'role'=>$user->role,
        ];
    }       

    if (isset($params['categorie'])) {
        //recuperation de l'element
        $categorie= ($params['categorie'] >0 ) ? App\Models\Categorie::findOrFail($params['categorie']) : [];

        $showTitre=$categorie->nom;
        $showImage='';
        $showDetails=$categorie->details;

        //autres
        $othersFields=[
            'nom'=>$categorie->nom,
            'articles'=>add_zero(count($categorie->articles)),
        ];
    }    
    

    if (isset($params['article'])) {
        //recuperation de l'element
        $article= ($params['article'] >0 ) ? App\Models\Article::findOrFail($params['article']) : [];
        $showId=$article->id;
        $showTitre=$article->titre;
        $showIntro=$article->intro;
        $showImage=$article->imageUrl();
        $showLegende=$article->legende;
        $showOthersImages=$article->images;
        $showDetails=$article->details;

        $showOptions=[
            'categorie'=>[
                'label'=>Str::ucfirst($article->categorie->nom),
                'class'=>'bg-coul2 fg-coul4 px-2 py-1 rounded-1',
            ],
            'user'=>[
                'label'=>Str::ucfirst(Str::substr($article->user->name, 0, 15)),
                'class'=>'bi bi-person',
            ],
            'created_at'=>[
                'label'=>$article->creerLe(),
                'class'=>'bi bi-calendar',
            ],
            'vues'=>[
                'label'=> add_zero($article->vues),
                'class'=>'bi bi-eye',
            ],
        ];

    }

    
    if (isset($params['image'])) {
        //recuperation de l'element
        $image= ($params['image'] >0 ) ? App\Models\Image::findOrFail($params['image']) : [];
        
        $showId=$image->id;
        $showTitre=$image->nom;
        $showImage=$image->imageUrl();
        $showDetails=$image->details;
        
        $showOptions=[
            'user'=>[
                'label'=>Str::ucfirst(Str::substr($image->user->name, 0, 15)),
                'class'=>'bi bi-person',
            ],
            'created_at'=>[
                'label'=>$image->creerLe(),
                'class'=>'bi bi-calendar',
            ],
        ];

    }
    
    
    if (isset($params['video'])) {
        //recuperation de l'element
        $video= ($params['video'] >0 ) ? App\Models\Video::findOrFail($params['video']) : [];

        $showId=$video->id;
        $showTitre=$video->titre;
        $showVideo=$video->videoUrl();
        // $showImage=$video->imageUrl();
        $showDetails=$video->details;
        
        $showOptions=[
            'statut'=>[
                'label'=>Str::ucfirst($video->statut),
                'class'=>'bg-coul2 fg-coul4 px-2 py-1 rounded-1',
            ],
            'user'=>[
                'label'=>Str::ucfirst(Str::substr($video->user->name, 0, 15)),
                'class'=>'bi bi-person',
            ],
            'created_at'=>[
                'label'=>$video->creerLe(),
                'class'=>'bi bi-calendar',
            ],
            'vues'=>[
                'label'=> add_zero($video->vues),
                'class'=>'bi bi-eye',
            ],
        ];
    }
    
    
    if (isset($params['annonce'])) {
        //recuperation de l'element
        $annonce= ($params['annonce'] >0 ) ? App\Models\Annonce::findOrFail($params['annonce']) : [];
        
        $showId=$annonce->id;
        $showTitre=$annonce->titre;
        $showImage=$annonce->imageUrl();
        $showDetails=$annonce->details;
        
        $showOptions=[
            'statut'=>[
                'label'=>Str::ucfirst($annonce->statut),
                'class'=>'bg-coul2 fg-coul4 px-2 py-1 rounded-1',
            ],
            'user'=>[
                'label'=>Str::ucfirst(Str::substr($annonce->user->name, 0, 15)),
                'class'=>'bi bi-person',
            ],
            'created_at'=>[
                'label'=>$annonce->creerLe(),
                'class'=>'bi bi-calendar',
            ],
            'vues'=>[
                'label'=> add_zero($annonce->vues),
                'class'=>'bi bi-eye',
            ],
        ];

    }
    

    //gestion des variables
    $othersFields=(isset($othersFields)) ? $othersFields : [];


@endphp

<div class="row row-cols-1 row-cols-lg-2 mb-3">
    
    <div class="col col-lg-9 px-0">
        
        <div class="container-fluid p-2">

            <div class="container-fluid p-0">
                <div class="">
                    
                    <div class="container-fluid pt-2">
                        <h6 class="d-lg-none fw-bold fg-coul1">{{ $showTitre }}</h6>
                        <h4 class="d-none d-lg-block fw-bold fg-coul1">{{ $showTitre }}</h4>
                    </div>

                    @isset($showOptions)
                        <div class="container-fluid mb-3 fs-60">
                            @foreach ($showOptions as $showOption)
                                @if(!$loop->first)  <span class="px-1"> </span> @endif <span class="{{ $showOption['class'] }}"> {{ $showOption['label'] }}</span>
                            @endforeach
                        </div>
                    @endisset
                    
                </div>
                @isset($showIntro)
                    <div class="container-fluid">
                        <p class="fw-bold fs-80 text-justify d-lg-none my-2">{!! $showIntro !!}</p>
                        <p class="fw-bold fs-5 text-justify d-none d-lg-block my-2">{!! $showIntro!!}</p>
                    </div>
                @endisset
            </div>

            @if (isset($params['video']))              
            <x-block-item type="no-caption" :video="$video->id" route="#"></x-block-item>
            @else
                <div class="container-fluid">
                <img src="{{ $showImage }}" alt="{{ $showTitre }}" class="img-fluid" style="width: 100%">
                    {{-- <div class="image-container">
                        <img src="{{ $showImage }}" alt="{{ $showTitre }}" class="">
                    </div> --}}
                    @if(isset($showLegende) && $showLegende != null)
                        <figcaption class=""> {{ $showLegende }}</figcaption>
                    @endif
                    
                </div>
            @endif

            @if (isset($showDetails) && $showDetails != '')
                <div class="mt-3 container-fluid" style="">
                    <div class="d-lg-none my-2">{!! str_replace(['<p>',"\'"], ["<p class='fs-80 text-justify'>","'"], $showDetails) !!}</div>

                    <div class="d-none d-lg-block my-2">{!! str_replace(['<p>',"\'"], ["<p class='fs-6 text-justify'>","'"], $showDetails) !!}</div>
                    
                    @if ($layout=='guest')
                        <!-- ShareThis BEGIN -->
                            <div class="sharethis-inline-share-buttons"></div>
                        <!-- ShareThis END -->
                    @endif
                </div>
            @endif
        </div>

    </div>

    @if ($layout=='guest')
        <!--espace publicité 3-->
        <div class="col col-lg-3">
            <div class="container-fluid sticky-lg-top px-2" style="top:100px">
                <h6 class="fg-coul1 border-bottom fs-90">Fil Facebook</h6>
                <div class="fb-page" data-href="https://www.facebook.com/bandeinfo" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/bandeinfo" class="fb-xfbml-parse-ignore fs-80"><a href="https://www.facebook.com/bandeinfo">Bande Info</a></blockquote></div>
            </div>
        </div>
    @endif

</div>

@if ($layout=='guest' && isset($params['article']))
    <!--//////// suggestion  /////-->
    <x-section id="subjectArticle" class="bg-coul4 shadow-0" titre="A découvrir également...">

        <div class="row row-cols-1">

            <div class="col">
                <div class="row row-cols-2 row-cols-lg-4 mt-4">

                    @php
                        //selection de 12 article aleatoires
                        $subjectArticles=App\Models\Article::where('statut','publié')
                            ->whereNotIn('id',[$showId])
                            ->inRandomOrder()
                            ->take(12)
                            ->get();
                    @endphp
            
                    @foreach ($subjectArticles as $subjectArticle)
                    
                        <div class="col mb-2 p-1">
                            <a class="mtblock" href="{{ mt_get_route('guest_articles_show', ['slug' => $subjectArticle->slug, 'article' => $subjectArticle->id]) }}" >
                                <div class="mtblock-rect lazy-bg hover-ty5" data-bg="{{ $subjectArticle->imageUrl() }}">
                                </div>
                                <div class="container-fluid p-0 pt-1">
                                    <div class="container-fluid p-0 fs-60 fg-coul2-0">
                                        <span class="bi bi-calendar"> {{ $subjectArticle->creerLe() }}</span>
                                        <span class="px-1"></span>
                                        <span class="bi bi-eye"> {{ add_zero($subjectArticle->vues) }}{{ $subjectArticle->vues > 1 ? " vues" : " vue" }}</span>
                                    </div>
                                    <h6 class="fg-coul1 mtblock-title fs-70 fw-bold" style="line-height: 1.3">{{ strlen($subjectArticle->titre) > 60 ? substr($subjectArticle->titre, 0, 60)."..." : $subjectArticle->titre }}</h6>
                                </div>
                            </a>
                        
                        </div>
            
                    @endforeach
                    
                </div>
            </div>

        </div>

    </x-section>
@endif

