@props([
    'title',
    'description',
])

<div class="flex flex-col w-full text-center">
    <h1 class="text-lg font-bold mt-text">{{ $title }}</h1>
    <p class="text-sm mt-text" >{{ $description }}</p>
</div>
