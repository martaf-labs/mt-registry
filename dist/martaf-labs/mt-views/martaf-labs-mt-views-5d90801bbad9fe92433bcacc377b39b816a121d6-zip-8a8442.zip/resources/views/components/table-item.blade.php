@props(['jsonParamsTab'])

@php

    //decodages de la variable json parametres du composant
    $paramsTab=json_decode($jsonParamsTab, true); //convertir tout les element de parametre en objet

    $tabDeletePassword = (isset($tabDeleteButton['password'])) ? $tabDeleteButton['password'] : '';

    //variables d'element
    $tabItemModel='';
    $tabItem=[];


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'user') {

        $user= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\User::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="user";
        $defaultOptions=[
            'role'=>[
                'label'=>ucwords($user->role),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
        ];

        $tabItemId=$user->id;
        $tabItemTitre=$user->name;
        $tabItemImage=$user->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('users_edit',['user'=>$user->id]);
        $tabItemShowRoute=mt_get_route('users_show',['user'=>$user->id]);
        $tabItemDestroyRoute=mt_get_route('users_destroy');
    }    


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'employe') {

        $employe= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Personnel::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="employe";
        $defaultOptions=[
            'poste'=>[
                'label'=>ucwords($employe->poste),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
            'statut'=>[
                'label'=>ucwords($employe->statut),
                'class'=>'bg-coul3 fg-coul4 px-2 rounded-pill',
            ],
        ];

        $tabItemId=$employe->id;
        $tabItemTitre=$employe->nom.' '.$employe->prenom;
        $tabItemImage=$employe->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('employes_edit',['employe'=>$employe->id]);
        $tabItemShowRoute=mt_get_route('employes_show',['employe'=>$employe->id]);
        $tabItemDestroyRoute=mt_get_route('employes_destroy');
    }       


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'partenaire') {

        $partenaire= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Partenaire::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="partenaire";
        $defaultOptions=[];

        $tabItemId=$partenaire->id;
        $tabItemTitre=$partenaire->nom.' '.$partenaire->prenom;
        $tabItemImage=$partenaire->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('partenaires_edit',['partenaire'=>$partenaire->id]);
        $tabItemShowRoute=mt_get_route('partenaires_show',['partenaire'=>$partenaire->id]);
        $tabItemDestroyRoute=mt_get_route('partenaires_destroy');
    }    


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'fournisseur') {

        $fournisseur= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Fournisseur::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="fournisseur";
        $defaultOptions=[];

        $tabItemId=$fournisseur->id;
        $tabItemTitre=$fournisseur->nom.' '.$fournisseur->prenom;
        $tabItemImage=$fournisseur->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('fournisseurs_edit',['fournisseur'=>$fournisseur->id]);
        $tabItemShowRoute=mt_get_route('fournisseurs_show',['fournisseur'=>$fournisseur->id]);
        $tabItemDestroyRoute=mt_get_route('fournisseurs_destroy');
    }    


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'client') {

        $client= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Client::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="client";
        $defaultOptions=[];

        $tabItemId=$client->id;
        $tabItemTitre=$client->nom.' '.$client->prenom;
        $tabItemImage=$client->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('clients_edit',['client'=>$client->id]);
        $tabItemShowRoute=mt_get_route('clients_show',['client'=>$client->id]);
        $tabItemDestroyRoute=mt_get_route('clients_destroy');
    }    


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'categorie') {

        $categorie= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Categorie::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="categorie";
        $defaultOptions=[
            'engins'=>[
                'label'=>addzero(count($categorie->engins)),
                'class'=>'fg-coul3',
            ],
        ];

        $tabItemId=$categorie->id;
        $tabItemTitre=$categorie->nom;
        $tabItemImage='';
        $tabItemIcone=get_icone('categorie');
        $tabItemEditRoute=mt_get_route('categories_edit',['categorie'=>$categorie->id]);
        $tabItemShowRoute='';//mt_get_route('categories_show',['slug'=>$categorie->slug,'categorie'=>$categorie->id]);
        $tabItemDestroyRoute=mt_get_route('categories_destroy');
    }    


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'engin') {

        $engin= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Engin::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="engin";
        $defaultOptions=[
            'statut'=>[
                'label'=>ucwords($engin->statut),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
            'etat'=>[
                'label'=>"Etat: ".ucwords($engin->etat),
                'class'=>'fg-coul3',
            ],
        ];

        $tabItemId=$engin->id;
        $tabItemTitre=$engin->nom;
        $tabItemImage=$engin->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('engins_edit',['engin'=>$engin->id]);
        $tabItemShowRoute=mt_get_route('engins_show',['slug'=>$engin->slug,'engin'=>$engin->id]);
        $tabItemDestroyRoute=mt_get_route('engins_destroy');
    }


    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'caracteristique') {

        $caracteristique= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Caracteristique::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="caracteristique";
        $defaultOptions=[
            'engins'=>[
                'label'=>addzero(count($caracteristique->engins)),
                'class'=>'fg-coul3',
            ],
        ];

        $tabItemId=$caracteristique->id;
        $tabItemTitre=$caracteristique->nom;
        $tabItemImage='';
        $tabItemIcone=get_icone('caracteristique');
        $tabItemEditRoute=mt_get_route('caracteristiques_edit',['caracteristique'=>$caracteristique->id]);
        $tabItemShowRoute='';//mt_get_route('caracteristiques_show',['slug'=>$caracteristique->slug,'caracteristique'=>$caracteristique->id]);
        $tabItemDestroyRoute=mt_get_route('caracteristiques_destroy');
    }    

    

    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'chantier') {

        $chantier= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Chantier::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="chantier";
        $defaultOptions=[
            'statut'=>[
                'label'=>ucwords($chantier->statut),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
            'debut'=>[
                'label'=>"Début: ".ucwords($chantier->dateDebut()),
                'class'=>'fg-coul3',
            ],
            'date_fin'=>[
                'label'=>"Fin: ".ucwords(($chantier->date_fin != null) ? $chantier->dateFin() : "?" ,
                ),
                'class'=>'fg-coul3',
            ],
        ];


        $tabItemId=$chantier->id;
        $tabItemTitre=$chantier->titre;
        $tabItemImage=$chantier->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('chantiers_edit',['chantier'=>$chantier->id]);
        $tabItemShowRoute=mt_get_route('chantiers_show',['chantier'=>$chantier->id]);
        $tabItemDestroyRoute=mt_get_route('chantiers_destroy');
    }  

    

    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'image') {

        $image= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Image::findOrFail($paramsTab['tabItemId']) : [];
        $tabItemModel="image";
        $defaultOptions=[
            'statut'=>[
                'label'=>ucwords($image->statut),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
        ];


        $tabItemId=$image->id;
        $tabItemTitre=$image->nom;
        $tabItemImage=$image->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('images_edit',['image'=>$image->id]);
        $tabItemShowRoute=mt_get_route('images_show',['slug'=>$image->slug,'image'=>$image->id]);
        $tabItemDestroyRoute=mt_get_route('images_destroy');
    }  

    

    if (isset($paramsTab) && $paramsTab['tabItemModel'] == 'video') {

        $video= (isset($paramsTab['tabItemId']) && $paramsTab['tabItemId'] >0 ) ? App\Models\Video::findOrFail($paramsTab['tabItemId']) : [];

        $tabItemModel="video";
        $defaultOptions=[
            'statut'=>[
                'label'=>ucwords($video->statut),
                'class'=>'bg-coul1 fg-coul4 px-2 rounded-pill',
            ],
        ];


        $tabItemId=$video->id;
        $tabItemTitre=$video->titre;
        $tabItemVideo=$video->videoUrl();
        $tabItemImage=$video->imageUrl();
        $tabItemIcone='';
        $tabItemEditRoute=mt_get_route('videos_edit',['video'=>$video->id]);
        $tabItemShowRoute=mt_get_route('videos_show',['slug'=>$video->slug,'video'=>$video->id]);
        $tabItemDestroyRoute=mt_get_route('videos_destroy');
    }  



    //variables de mise en place
    $tabId= (isset($tabItemId)) ? $tabItemId : '';
    $tabTitre= (isset($tabTitre)) ? $tabTitre : $tabItemTitre;
    $tabImage= (isset($tabImage)) ? $tabImage : $tabItemImage;
    $tabIcone= (isset($tabIcone)) ? $tabIcone : $tabItemIcone;
    $tabOptions= (isset($tabOptions)) ? $tabOptions : $defaultOptions;
    $tabEditRoute= (isset($tabEditRoute)) ? $tabEditRoute : $tabItemEditRoute;
    $tabShowRoute= (isset($tabShowRoute)) ? $tabShowRoute : $tabItemShowRoute;
    $tabDestroyRoute= (isset($tabDestroyRoute)) ? $tabDestroyRoute : $tabItemDestroyRoute;

@endphp

<div class="row @if (in_array($paramsTab['tabItemModel'], ['image','video'])) row-cols-1 px-1 @else  row-cols-3 p-1 @endif d-flex flex-row flex-nowrap align-items-center justify-content-between bg-t-coul4-0 rounded-2 position-relative hover-t-coul1">
    
    @if (in_array($paramsTab['tabItemModel'], ['image','video']))
        <div class="col p-0">
            @if($paramsTab['tabItemModel'] == 'image')
                <x-block-item :image="$image" route="" :options=[]></x-block-item>
            @endif
            @if($paramsTab['tabItemModel'] == 'video')
                <x-block-item :video="$video" route="" :options=[]></x-block-item>
            @endif
        </div> 
    @else

        @if(isset($tabImage) && strlen($tabImage)>0)
            <div class="col-2 col-lg-1 p-0">
                <div class="mtblock-sqr rounded-2 m-0" style="background-image:url({{ $tabImage }});"></div>
                {{-- <x-block-item :video="$video" route="" :options=[]></x-block-item> --}}
            </div>
        @endif
        @if(isset($tabIcone) && strlen($tabIcone)>0)
            <div class="col-1 col-lg-1 p-0">
                <x-circle-item :icone="$tabIcone"></x-circle-item>
            </div>
        @endif

        <div class="col-9 col-lg-10 flex-grow-1">
            @if(isset($tabTitre) && strlen($tabTitre)>0)
                <h6 class="whitespace-nowrap overflow-hidden me-lg-1 fs-80 my-0">{{ ucwords(Str::substr( $tabTitre, 0, 60)) }} @if(strlen($tabTitre) > 60) ... @endif</h6>
            @endif
            
            @if(isset($tabOptions) && count($tabOptions)>0)
                <div class="my-0">
                    @foreach ($tabOptions as $tabOption)
                        @if(!$loop->first) <span class="mx-1"></span> @endif<span class="{{ $tabOption['class'] }} fs-70"> {{ Str::substr($tabOption['label'], 0, 10) }} @if(strlen($tabOption['label']) > 10) ... @endif</span> 
                    @endforeach
                </div>
            @endif
        </div>
    @endif

    <!--dropdown button-->
    <div class="@if (in_array($paramsTab['tabItemModel'], ['image','video'])) ms-1 @else col-1 d-flex flex-column align-items-end @endif rounded-pill w-auto" style="@if (in_array($paramsTab['tabItemModel'], ['image','video'])) position:absolute; top:5px; right:2px @else top:0; right:2px @endif ;background-color:rgba('255,255,255,.0');">
        <div class="dropdown">
            <button class="btn border-0 fg-coul2 p-0 @if (in_array($paramsTab['tabItemModel'], ['image','video'])) bg-coul4 rounded-pill me-1 @endif" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="bi @if (in_array($paramsTab['tabItemModel'], ['image','video'])) bi-three-dots-vertical @else bi-three-dots-vertical @endif fs-5 "></span>
            </button>
            
            <ul class="dropdown-menu shadow-lg py-0 px-0">

                @php
                    $tabButtons=[
                        'editButton'=>[
                            'addClass'=>'',
                            'label'=>'Modifier',
                            'icone'=>get_icone('modifier'),
                            'lien'=>$tabEditRoute,
                        ],
                        'showButton'=>[
                            'addClass'=>'',
                            'label'=>'Détails',
                            'icone'=>get_icone('voir'),
                            'lien'=>$tabShowRoute,
                        ],
                    ];

                    $tabDeleteButton=[
                        'addClass'=>'bg-danger fg-coul4',
                        'label'=>'Supprimer',
                        'icone'=>get_icone('supprimer'),
                        'lien'=>$tabDestroyRoute,
                        'titre'=>"Attention",
                        'id'=>$tabId,
                        'message'=>"Vous êtes sur le point de supprimer <br> <strong> $tabTitre </strong> ! <br> Souhaitez-vous continuer ?",
                    ];
                @endphp
                @foreach ($tabButtons as $tabButton)
                    <li>
                        <a class="dropdown-item {{ $tabButton['addClass'] }}" href="{{ $tabButton['lien'] }}">
                            <span class="{{ $tabButton['icone'] }}"></span>
                            <span class="ms-2">{{ $tabButton['label'] }}</span>
                        </a>
                    </li>
                @endforeach

                <li>
                    <a class="dropdown-item {{ $tabDeleteButton['addClass'] }}" type="button" data-bs-toggle="modal" data-bs-target="#alertModal{{ $loop->index }}">
                        <span class="bi bi-{{ $tabDeleteButton['icone'] }}"></span>
                        <span class="ms-2">{{ $tabDeleteButton['label'] }}</span>
                    </a>
                </li>
            
            </ul>
            
        </div>
        
        @isset($tabDeleteButton)
        @php
            $alertType="warning";
        @endphp
            <x-alert :alertType="$alertType" :alertTitle="$tabDeleteButton['titre']" :alertRoute="$tabDeleteButton['lien']" :alertAddId="$loop->index" :alertId="$tabDeleteButton['id']" :alertPassword="$tabDeletePassword">
                {{ $tabDeleteButton['message'] }}
            </x-alert>
        @endisset

    </div>
</div>
