{{-- 
    Usage :
    <x-mt::card title="Mon Titre" icon="fa-user">
        <x-slot name="header"> (Optionnel : remplace le titre par défaut) </x-slot>
        Mon contenu ici
        <x-slot name="footer"> (Optionnel) </x-slot>
    </x-mt::card>
--}}

@props(['title' => null, 'icon' => null])

<div {{ $attributes->merge(['class' => 'bg-white dark:bg-zinc-800 rounded-2xl border border-gray-200 dark:border-zinc-700 shadow-sm overflow-hidden']) }}>
    
    @if($title || isset($header))
        <div class="px-6 py-4 border-b border-gray-200 dark:border-zinc-700 bg-gray-50/50 dark:bg-zinc-800/50">
            @if(isset($header))
                {{ $header }}
            @else
                <div class="flex items-center gap-2">
                    @if($icon)
                        <i class="fa-solid {{ $icon }} text-gray-400"></i>
                    @endif
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        {{ $title }}
                    </h3>
                </div>
            @endif
        </div>
    @endif

    <div class="p-6">
        {{ $slot }}
    </div>

    @if(isset($footer))
        <div class="px-6 py-4 bg-gray-50 dark:bg-zinc-900/50 border-t border-gray-200 dark:border-zinc-700">
            {{ $footer }}
        </div>
    @endif
</div>