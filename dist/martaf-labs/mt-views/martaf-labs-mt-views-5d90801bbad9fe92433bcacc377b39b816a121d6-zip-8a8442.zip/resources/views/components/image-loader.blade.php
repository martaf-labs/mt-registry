{{-- ce composant affiche une image avec un effet de chargement (squelette) tant que l'image n'est pas complètement chargée. Il utilise Alpine.js pour gérer l'état de chargement et appliquer les classes CSS appropriées pour l'effet de transition. --}}

@props(['src' => null, 'alt' => '', 'disk' => mt_get_storage_disk()])

@php
    $exists = mt_file_exists($src, $disk);
@endphp

<div x-data="{ loaded: false, error: '{{ !$exists }}' }" 
     {{ $attributes->merge(['class' => 'relative bg-gray-200 overflow-hidden']) }}>
    
    {{-- Placeholder de chargement --}}
    <div x-show="!loaded && !error" class="absolute inset-0 flex items-center justify-center bg-gray-300 animate-pulse">
        <svg class="w-8 h-8 text-gray-400 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </div>

    @if (!$exists)
    {{-- Icône d'erreur (Fallback) --}}
    <div x-show="error" x-cloak class="absolute inset-0 flex flex-col items-center justify-center p-2 text-gray-400 bg-gray-100">
        <svg class="w-10 h-10" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
        </svg>
        {{-- <span class="text-[10px] mt-1 uppercase font-bold">Fichier indisponible</span> --}}
    </div>
    
    @else

    {{-- Image --}}
    <img src="{{ $src }}" 
         alt="{{ strip_tags($alt) }}"
         x-init="loaded = $el.complete"
         @load="loaded = true"
         x-on:error="error = true; loaded = true"
         x-show="!error"
         :class="loaded ? 'opacity-100' : 'opacity-0'"
         {{-- class="object-cover w-full h-full transition-opacity duration-500 ease-in-out" --}}
         class="object-cover object-top w-full h-full transition-transform duration-200 wbject-full o group-hover:scale-105"
         >  
    @endif
</div>