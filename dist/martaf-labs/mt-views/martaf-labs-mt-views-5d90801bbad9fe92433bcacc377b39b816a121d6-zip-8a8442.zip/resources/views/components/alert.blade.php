@php
    $alertId= (isset($alertId)) ? $alertId : '0';
    $alertAddId= (isset($alertAddId)) ? $alertAddId : '';
    $alertRoute= (isset($alertRoute)) ? $alertRoute : '';
    $alertPassword= (isset($alertPassword)) ? $alertPassword : '';
@endphp

@isset($alertType)
    <div class="modal fade" id="alertModal{{ $alertAddId }}" tabindex="-1" aria-labelledby="alertModalLabel{{ $alertAddId }}" aria-hidden="true">
        <div class="modal-dialog shadow-lg rounded-2">
            <div class="modal-content mtzoom-in border-0">
                <div class="modal-header py-1 px-2 bg-success @if (in_array($alertType ,['warning','error'])) bg-danger @endif">
                    <h6 class="modal-title fs-90 fg-coul4" id="alertModalLabel{{ $alertAddId }}">
                        <span class="{{ get_icone('info') }}"> </span>
                        <span class="">{{ $alertTitle }}</span>
                    </h6>
                </div>
                <div class="modal-body py-2 d-flex flex-column justify-content-center align-items-center">
                    <p class="text-center m-0">{!! html_entity_decode($slot) !!}</p>
                </div>
                <div class="modal-footer py-1 px-2 border-0">
                    
                    @if ($alertType=='success')
                        <div class="container d-flex flex-row flex-nowrap justify-content-end align-items-center">
                            <button id="alertModalCloseBtn{{ $alertAddId }}" type="button" class="btn btn-coul3 px-3 py-1 rounded-pill" data-bs-dismiss="modal" autofocus><span class="bi bi-x me-1">D'accord</button>
                        </div>
                    @endif
                    
                    @if ($alertType=='error')
                        <div class="container d-flex flex-row flex-nowrap justify-content-end align-items-center">
                            <button id="alertModalCloseBtn{{ $alertAddId }}" type="button" class="btn btn-danger px-3 py-1 rounded-pill" data-bs-dismiss="modal" autofocus><span class="bi bi-x me-1">D'accord</button>
                        </div>
                    @endif

                    @if ($alertType=='warning')
                        <form action="{{ $alertRoute }}" method="post" class="container-fluid d-flex flex-column justify-content-between align-items-center">
                            @csrf
                            @method('delete')

                            <div class="container mb-3">
                            
                                @if ($alertPassword != '')
                                    <div class="form-group px-1">
                                        <x-text-input id="password" class="" type="password" name="password" required/>
                                        <x-input-error :messages="$errors->get('password')" class="" />
                                    </div>
                                @endif
                                
                                <input type="hidden" name="id" value="{{ $alertId }}">
                            </div>

                            <div class="container d-flex flex-row flex-nowrap justify-content-end align-items-center">
                                <button id="alertModalCloseBtn{{ $alertAddId }}" type="button" class="btn btn-coul3 px-4 py-1 rounded-pill" data-bs-dismiss="modal"><span class="bi bi-x me-1">Non</button>
                                <button type="submit" class="btn btn-danger ms-2 px-4 py-1 rounded-pill" autofocus><span class="bi bi-check me-1">Oui</button>
                            </div>
                        </form>
                    @endif
                    
                </div>
            </div>
        </div>
    </div>

@endisset
