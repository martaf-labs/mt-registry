@props([
    'type' => 'secondary', // correspond à 'gray' dans Tailwind
    'label' => null,
    'rounded' => 'md',
])

@php
$colors = [
    'primary'   => 'bg-blue-50 text-blue-700 inset-ring inset-ring-blue-700/10 dark:bg-blue-400/10 dark:text-blue-400 dark:inset-ring-blue-400/30',
    'secondary' => 'bg-gray-50 text-gray-600 inset-ring inset-ring-gray-500/10 dark:bg-gray-400/10 dark:text-gray-400 dark:inset-ring-gray-400/20',
    'success'   => 'bg-green-50 text-green-700 inset-ring inset-ring-green-600/20 dark:bg-green-400/10 dark:text-green-400 dark:inset-ring-green-500/20',
    'danger'    => 'bg-red-50 text-red-700 inset-ring inset-ring-red-600/10 dark:bg-red-400/10 dark:text-red-400 dark:inset-ring-red-400/20',
    'warning'   => 'bg-yellow-50 text-yellow-800 inset-ring inset-ring-yellow-600/20 dark:bg-yellow-400/10 dark:text-yellow-500 dark:inset-ring-yellow-400/20',
    'info'      => 'bg-indigo-50 text-indigo-700 inset-ring inset-ring-indigo-700/10 dark:bg-indigo-400/10 dark:text-indigo-400 dark:inset-ring-indigo-400/30',
    'light'     => 'bg-white text-gray-800 inset-ring inset-ring-gray-200/50 dark:bg-gray-800/10 dark:text-gray-300 dark:inset-ring-gray-700/20',
    'dark'      => 'bg-gray-900 text-gray-100 inset-ring inset-ring-gray-700/20 dark:bg-gray-950 dark:text-gray-200 dark:inset-ring-gray-900/20',
];

$colorClasses = $colors[$type] ?? $colors['secondary'];
@endphp

<span {{ $attributes->merge([
    'class' => "inline-flex items-center rounded-{$rounded} px-2 py-1 text-xs font-medium $colorClasses"
]) }}>
    {{ Illuminate\Support\Str::ucfirst($label) ?? $slot }}
</span>
