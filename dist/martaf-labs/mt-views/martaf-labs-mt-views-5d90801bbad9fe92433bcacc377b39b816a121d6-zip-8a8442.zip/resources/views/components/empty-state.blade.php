@props([
    'title'       => 'Aucune donnée disponible',
    'description' => null,
    'icon'        => 'fa-solid fa-inbox',
])

<div {{ $attributes->merge(['class' => 'flex flex-col items-center justify-center p-4 lg:p-12 text-center border-2 border-dashed rounded-3xl'])
    }} style="border-color: rgb(var(--mt-ui-card-border))">

    {{-- Icône --}}
    <div class="flex items-center justify-center w-20 h-20 mb-6 rounded-full mt-bg-secondary-light">
        <i class="{{ $icon }} text-3xl mt-text-muted"></i>
    </div>

    {{-- Titre --}}
    <h3 class="text-md font-semibold mt-text">
        {{ $title }}
    </h3>

    {{-- Description --}}
    @if($description)
        <p class="max-w-xs mt-2 text-sm mt-text-muted">
            {{ $description }}
        </p>
    @endif

    {{-- Slot (actions, boutons...) --}}
    @if($slot->isNotEmpty())
        <div class="mt-8">
            {{ $slot }}
        </div>
    @endif

</div>
