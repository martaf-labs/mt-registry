{{--
    Composant : Modal (Fenêtre de dialogue)
    Usage : 
    <div x-data="{ open: false }">
        <x-mt::button @click="open = true">Ouvrir</x-mt::button>
        <x-mt::modal name="my-modal" title="Confirmer la suppression">
            <p>Êtes-vous sûr de vouloir supprimer cet élément ?</p>
            <x-slot name="footer">
                <x-mt::button variant="secondary" @click="open = false">Annuler</x-mt::button>
                <x-mt::button variant="danger" wire:click="delete">Supprimer</x-mt::button>
            </x-slot>
        </x-mt::modal>
    </div>
--}}

@props([
    'name',
    'title'    => null,
    'icon'     => null,
    'maxWidth' => '4xl',
])

@php
    $maxWidthClass = [
        'sm'  => 'sm:max-w-sm',
        'md'  => 'sm:max-w-md',
        'lg'  => 'sm:max-w-lg',
        'xl'  => 'sm:max-w-xl',
        '2xl' => 'sm:max-w-2xl',
        '4xl' => 'sm:max-w-4xl',
    ][$maxWidth] ?? 'sm:max-w-4xl';
@endphp

<div x-modelable="open" {{ $attributes }}>
    <div
        x-show="open"
        class="fixed inset-0 z-[200] overflow-y-auto"
        style="display: none;"
    >
        {{-- Overlay --}}
        <div
            x-show="open"
            x-transition:enter="ease-out duration-300"
            x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100"
            x-transition:leave="ease-in duration-200"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0"
            @click="open = false"
            class="fixed inset-0 transition-all transform backdrop-blur-sm"
            style="background: rgba(var(--mt-bg), 0.1)"
        >
            <div class="absolute inset-0" style="background: rgba(0,0,0,0.5)"></div>
        </div>

        {{-- Contenu --}}
        <div
            x-show="open"
            x-transition:enter="ease-out duration-300"
            x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
            x-transition:leave="ease-in duration-200"
            x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
            x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            class="flex items-center justify-center min-h-full p-4 text-center sm:p-0"
        >
            <div class="relative w-full overflow-hidden transition-all transform rounded-3xl shadow-2xl {{ $maxWidthClass }} text-left pb-6 mt-bg"
                 style="border: 1px solid rgb(var(--mt-ui-card-border))">

                {{-- Header --}}
                <div class="sticky flex items-center justify-between px-6 py-4"
                     >
                    @if($title)
                        <h3 class="mt-2 text-sm font-normal lg:font-bold lg:text-md mt-text" style="opacity: 0.85">
                            @if($icon) <i class="mr-2 {{ $icon }}"></i> @endif
                            {{ $title }}
                        </h3>
                    @endif
                    <button
                        @click="open = false; $dispatch('close-modal', { name: '{{ $name }}' })"
                        class="ml-auto mt-btn-icon mt-btn-icon-sm">
                        <x-mt::icon name="x" />
                    </button>
                </div>

                {{-- Body --}}
                <div class=" h-[70vh] lg:h-[80vh] p-2 lg:px-6 lg:py-3 overflow-y-auto">
                    {{ $slot }}
                </div>

                {{-- Footer --}}
                @if(isset($footer))
                    <div class="flex justify-end gap-3 px-6 pt-4 pb-1"
                         style="border-top: 1px solid rgb(var(--mt-ui-card-border)); background: rgba(var(--mt-text), 0.02)">
                        {{ $footer }}
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
