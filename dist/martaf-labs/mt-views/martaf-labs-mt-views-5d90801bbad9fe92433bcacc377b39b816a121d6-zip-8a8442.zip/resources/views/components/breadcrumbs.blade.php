@props([
    'title' => null,
    'metaInfos' => null,
    'description' => '',
    'datas' => [],
    'actions' => false,
])

@php
    $titleContent = is_array($title) ? ($title['content'] ?? '') : $title;
    $titleIcon    = is_array($title) ? ($title['icon'] ?? false) : false;
    $metaInfos    = is_array($title) ? ($title['metaInfos'] ?? $metaInfos) : $metaInfos;

    $hasDatas = !empty($datas);
    $firstData = $hasDatas ? reset($datas) : null;
    $lastData  = $hasDatas ? end($datas) : null;
    
    // On garde la logique de réduction si plus de 5 éléments
    $overDatas = count($datas) > 5 ? array_slice($datas, 1, -1) : [];
@endphp

<div {{ $attributes->merge(['class' => 'mb-6']) }}>
    <div class="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        
        <div class="flex-1 min-w-0">
            {{-- Fil d'Ariane HTML/Tailwind --}}
            @if ($hasDatas)
                <nav class="flex mb-3" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center text-[11px]">
                        {{-- Accueil --}}
                        <li class="inline-flex items-center">
                            <a href="{{ route('dashboard') }}" class="transition-colors text-zinc-500 hover:text-primary-600 dark:text-zinc-400 dark:hover:text-white">
                                <i class="mt-icon-home"></i>
                            </a>
                        </li>

                        @if (!empty($overDatas))
                            {{-- Premier élément après accueil --}}
                            <li>
                                <div class="flex items-center">
                                    <i class="mt-icon-chevron-right text-[9px] text-zinc-400"></i>
                                    <a href="{{ $firstData['lien'] ?? '#' }}" class="text-zinc-500 hover:text-primary-600 dark:text-zinc-400 dark:hover:text-white">
                                        {{ Illuminate\Support\Str::limit($firstData['label'], 15) }}
                                    </a>
                                </div>
                            </li>

                            {{-- Dropdown Ellipsis --}}
                            <li x-data="{ open: false }" class="relative">
                                <div class="flex items-center">
                                    <i class="fa-solid fa-chevron-right text-[9px] text-zinc-400"></i>
                                    <button @click="open = !open" class="px-1 transition-colors rounded text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800">
                                        <i class="mt-icon-ellipsis-horizontal"></i>
                                    </button>
                                    
                                    <div x-show="open" @click.away="open = false" 
                                         class="absolute left-0 z-50 w-48 py-1 mt-8 bg-white border rounded-lg shadow-xl dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
                                        @foreach ($overDatas as $data)
                                            <a href="{{ $data['lien'] ?? '#' }}" class="block px-4 py-2 text-[12px] text-zinc-700 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800">
                                                {{ Illuminate\Support\Str::ucfirst($data['label']) }}
                                            </a>
                                        @endforeach
                                    </div>
                                </div>
                            </li>

                            {{-- Dernier élément --}}
                            <li aria-current="page">
                                <div class="flex items-center">
                                    <i class="mt-icon-chevron-right text-[9px] text-zinc-400"></i>
                                    <span class="text-zinc-900 dark:text-white">
                                        {{ Illuminate\Support\Str::ucfirst(Illuminate\Support\Str::limit($lastData['label'], 25)) }}
                                    </span>
                                </div>
                            </li>
                        @else
                            {{-- Liste courte --}}
                            @foreach ($datas as $data)
                                <li>
                                    <div class="flex items-center">
                                        <i class="mt-icon-chevron-right text-[9px] text-zinc-400"></i>
                                        @if($loop->last)
                                            <span class="text-zinc-900 dark:text-white">{{ Illuminate\Support\Str::limit($data['label'], 30) }}</span>
                                        @else
                                            <a href="{{ $data['lien'] ?? '#' }}" class="text-zinc-500 hover:text-primary-600 dark:text-zinc-400 dark:hover:text-white">
                                                {{ Illuminate\Support\Str::ucfirst(Illuminate\Support\Str::limit($data['label'] ?? '', 20)) }}
                                            </a>
                                        @endif
                                    </div>
                                </li>
                            @endforeach
                        @endif
                    </ol>
                </nav>
            @endif

            {{-- Titre et Meta --}}
            <div class="space-y-1">
                <h1 class="flex items-center gap-2 text-xl font-bold mt-text-primary">
                    {{-- @if ($titleIcon)
                        <i class="{{ $titleIcon }} text-primary-500/90 text-lg"></i>
                    @endif --}}
                    <span class="truncate">{{ $titleContent }}</span>
                </h1>
                
                @if($description)
                    <p class="max-w-3xl text-xs leading-normal mt-text">
                        {{ $description }}
                    </p>
                @endif

                @if ($metaInfos)
                    <div class="flex flex-wrap items-center mt-1 gap-x-3 gap-y-1">
                        @foreach ($metaInfos as $info)
                            @if(($info['type'] ?? '') === 'badge')
                                <x-mt::badge 
                                    :label="$info['label']"
                                    :variant="$info['variant'] ?? 'info'" 
                                    :dot="isset($info['dot'])"
                                    class="px-2 py-0.5 text-[10px]"
                                />
                            @else
                                <span class="flex items-center text-[11px] font-semibold text-zinc-400 dark:text-zinc-500">
                                    @if(isset($info['icon']))
                                        <i class="{{ $info['icon'] }} mr-1.5 opacity-70"></i>
                                    @endif
                                    {{ $info['label'] }}
                                </span>
                            @endif
                        @endforeach
                    </div>
                @endif
            </div>
        </div>

        {{-- Actions --}}
        @if($actions)
            <div class="flex items-center justify-end origin-right transform scale-95 md:self-end">
                <x-mt::actions.grid :actions="$actions" visible="4" />
            </div>
        @endif
    </div>
</div>