@props([
    'name',
    'class' => 'w-5 h-5',
])

@php
    $svg = mt_icon($name);
@endphp

<span {{ $attributes->merge(['class' => $class]) }}>
    @if($svg)
        {!! $svg !!}
    @else
        {{-- Icône manquante, on laisse l'espace vide mais réservé --}}
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="none">
            <rect width="24" height="24" fill="none"/>
        </svg>
    @endif
</span>