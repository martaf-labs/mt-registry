<!-- Page Loader -->
<div id="page-loader"
     style="display:flex"
     class="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900 backdrop-blur-sm bg-opacity-80">

    <!-- Logo + animation -->
    <div class="flex flex-col items-center gap-6">

        <!-- Logo -->
        <div class="relative">
            <img src="{{ asset('logo-white.png') }}" alt="SGNI TCHAD" 
                 class="h-16 w-auto animate-pulse" />
        </div>

        <!-- Barre de progression -->
        <div class="w-48 h-1 bg-slate-700 rounded-full overflow-hidden">
            <div id="loader-bar"
                 class="h-full bg-sky-500 rounded-full"
                 style="width:0%; transition: width 0.4s ease">
            </div>
        </div>

        <!-- Texte -->
        <p class="text-slate-400 text-sm tracking-widest uppercase animate-pulse">
            Chargement...
        </p>
    </div>
</div>

<script>
    // Barre de progression simulée
    const bar = document.getElementById('loader-bar');
    const loader = document.getElementById('page-loader');
    let width = 0;

    const interval = setInterval(() => {
        width += Math.random() * 15;
        if (width >= 90) { width = 90; clearInterval(interval); }
        bar.style.width = width + '%';
    }, 200);

    // Quand la page est chargée
    window.addEventListener('load', () => {
        clearInterval(interval);
        bar.style.width = '100%';

        setTimeout(() => {
            loader.style.transition = 'opacity 0.5s ease';
            loader.style.opacity = '0';
            setTimeout(() => loader.style.display = 'none', 500);
        }, 300);
    });
</script>