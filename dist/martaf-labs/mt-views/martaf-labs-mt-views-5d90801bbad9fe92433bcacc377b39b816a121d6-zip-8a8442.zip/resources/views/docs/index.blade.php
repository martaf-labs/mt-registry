<x-mt::layouts.app>
    @section('title', 'Documentation')


<div class="p-6 space-y-6">
    <div class="grid grid-cols-4 gap-6 border-bottom">
        <div class="">
            <x-mt::form.label
                value="Date de naissance"
                required="true"
            />

            <x-mt::form.date-picker 
                type="date"
                icon="fa-solid fa-calendar-day"
                required="true"
            />
        </div>
    </div>

    <div class="grid grid-cols-4 gap-6 border-bottom">

        <x-mt::button label="Bouton primary" variant="primary" icon="chevron-right" />
        <x-mt::button label="Bouton secondary" variant="secondary" endIcon="chevron-right" />
        <x-mt::button label="Bouton danger" variant="danger" endIcon="chevron-right" />
        <x-mt::button label="Bouton success" variant="success" endIcon="chevron-right" />
        <x-mt::button label="Bouton warning" variant="warning" endIcon="chevron-right" />
        <x-mt::button label="Bouton info" variant="info" endIcon="chevron-right" />
        <x-mt::button label="Bouton outline" variant="outline" endIcon="chevron-right" />
        <x-mt::button label="Bouton ghost" variant="ghost" endIcon="chevron-right" />

    </div>
</div>

</x-mt::layouts.app>