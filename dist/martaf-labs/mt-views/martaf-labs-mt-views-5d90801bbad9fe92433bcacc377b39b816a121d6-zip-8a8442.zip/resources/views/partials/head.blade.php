<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>{{ $title ?? config('app.name') }}</title>

{{-- Favicons --}}
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

{{-- Fonts --}}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
    /* :root{
        --mt-primary:{{ hexToRgb(config('mt-views.colors.light.primary')) }};
        --mt-bg:{{ hexToRgb(config('mt-views.colors.light.bg')) }};
    }

    /* mode sombre automatique */ 
    /* @media(prefers-color-sheme: dark){
        :root{
            --mt-primary:{{ hexToRgb(config('mt-views.colors.dark.primary')) }};
            --mt-bg:{{ hexToRgb(config('mt-views.colors.dark.bg')) }};
        }   
    } */

    /* .dark :root{
        --mt-primary:{{ hexToRgb(config('mt-views.colors.dark.primary')) }};
        --mt-bg:{{ hexToRgb(config('mt-views.colors.dark.bg')) }};
    } */ */

</style>

{{-- CSS du package mt-views --}}
{{-- @if(config('mt-views.load_css'))
    <link rel="stylesheet" href="{{ asset('vendor/mt/mt.css') }}">
@endif

@if(config('mt-views.load_js'))
    <script src="{{ asset('vendor/mt/mt.js') }}" defer></script>
@endif --}}


{{-- FontAwesome (si réellement nécessaire globalement) --}}
<link rel="stylesheet" href="{{ asset('vendor/fontawesome-free-7.1.0-web/css/fontawesome.min.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/fontawesome-free-7.1.0-web/css/brands.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/fontawesome-free-7.1.0-web/css/solid.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/fontawesome-free-7.1.0-web/css/sharp-thin.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/fontawesome-free-7.1.0-web/css/sharp-duotone-thin.css') }}">

{{-- CSS / JS du projet hôte (optionnel) --}}
{{-- @hasSection('vite') --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])
{{-- @endif --}}

{{-- Permet aux vues du projet d'injecter leurs styles --}}
@stack('styles')
@stack('scripts')

{{-- Config spécifique package --}}
<x-mt::head.tinymce-config />

{{-- Livewire dynamic title --}}
<script>
    document.addEventListener('livewire:init', () => {
        Livewire.on('page-title-changed', (event) => {
            if (event?.title) {
                document.title = event.title;
            }
        });
    });
</script>

{{-- Extension visuelle optionnelle --}}
@fluxAppearance
