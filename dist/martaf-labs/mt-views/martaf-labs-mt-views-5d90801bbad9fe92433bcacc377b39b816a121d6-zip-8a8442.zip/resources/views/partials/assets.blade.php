{{-- assets.blade.php — corrigé --}}

{{-- @if(mt_config('assets.load_project_assets'))
    @if (file_exists(public_path('build/manifest.json')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @endif
@endif --}}

{{-- Chargement du manifest du package mt-views --}}
{{-- @php
    $mtManifestPath = public_path('vendor/mt/build/.vite/manifest.json');
    $mtManifest = file_exists($mtManifestPath)
        ? json_decode(file_get_contents($mtManifestPath), true)
        : [];
@endphp

@if(isset($mtManifest['resources/css/mt-views.css']))
    <link rel="stylesheet" href="{{ asset('vendor/mt/build/' . $mtManifest['resources/css/mt-views.css']['file']) }}">
@endif --}}

@env('local')
    <!-- En développement : utilisation de Vite -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <link rel="stylesheet" href="{{ asset('vendor/mt/mt-views/fontawesome-free-7.1.0-web/css/all.css') }}">
@else
    <!-- En production : chargement direct des assets compilés -->
    @php
        $manifest = json_decode(file_get_contents(public_path('build/manifest.json')), true);
    @endphp

    @if(isset($manifest['resources/css/app.css']))
    <link rel="stylesheet" href="{{ asset('build/' . $manifest['resources/css/app.css']['file']) }}">
    @endif

    @if(isset($manifest['resources/js/app.js']))
    <script type="module" src="{{ asset('build/' . $manifest['resources/js/app.js']['file']) }}"></script>
    @endif

    {{-- ajout du lien fontawesome 7 : kit personnalisé mt-fa-icons--}}
    <script src="https://kit.fontawesome.com/7b5c5ebcb4.js" crossorigin="anonymous"></script>
    

@endenv

{{-- ================= BUILDS DU PACKAGE (mt-views.css / mt-views.js) ================= --}}
@mtAssets

@stack('styles')