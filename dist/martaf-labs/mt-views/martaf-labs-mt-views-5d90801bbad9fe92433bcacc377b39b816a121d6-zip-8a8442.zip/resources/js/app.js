// app.js — corrigé
// import Alpine from 'alpinejs';
import './theme'; // enregistrer themeManager AVANT Alpine.start()

// window.Alpine = Alpine;
// Alpine.start();