# PACKAGE mt-views,

initié le Mercredi 06 Août 2025, à N'Djaména
mt-views est un package Laravel destiné à centraliser toutes les vues Blade partagées utilisées dans plusieurs projets Laravel. Il inclut des layouts standards, des composants Blade personnalisés (alertes, boutons, modals…), des partials réutilisables (headers, footers, sidebars), et d'autres structures visuelles communes.

L'objectif est de faciliter la cohérence visuelle, d'accélérer le développement, et de maintenir un design unifié à travers tous les projets Laravel.

##   Pour versionner, c-a-d creer un tag git:
git tag -a v1.0.1 -m "Version 1.0.1 - premier release stable du package mt-views"
git push origin v1.0.1

## Pour recreer la version taguée:
git add .
git commit -m "Fix compatibility with Laravel 11 and 12"
git tag -a v1.0.2 -m "Compatible with Laravel 11 & 12"
git push origin v1.0.2

## pour supprimer un tag:
git tag -d 1.0.2
git push origin :refs/tags/1.0.2

## supprimer tous les tag en locaux  et distants:
#!/bin/bash

# Supprimer tous les tags locaux
git tag -l | xargs git tag -d

# Supprimer tous les tags distants
git tag -l | xargs git tag -d
git tag -l | xargs -n 1 git push --delete origin
echo "✅ Tous les tags locaux et distants ont été supprimés."

# Pour revenir à n'importe quelle version du package à tout momment
git checkout v1.0.1(version desirée)


################
##############-----------------[10-12-2025]---------#####################
# Migration vers la Version 2.0.1 du package
################

## CHANGEMENT MAJEURS

### LES REQUIS
-> Laravel 12
-> Livewire 3(AlpineJs Intégré)
-> Flux 2
-> Tailwindcss 4
-> Icones: Fontawesome V.7.* 

### LES INTEGRATIONS
1. Intégration de *Livewire 3*

```
"require": {
    "livewire/livewire": "^3.0"
}
```

## Etapes
1. Modification du fichier fichier *composer.json* dans le package pour définir la nouvelle

```
"version": "2.0.1",
```

2. Creation d'un tag Git pour la version 2.0.1

```
git add .
git commit -m "Version 2.0.1 - migration vers mt-views v2.0.1"
git tag v2.0.1

```

3. Pousser les tags

```
git push --tags

```

## Intégration aux projets

1. Ajout du package dans le *composer.json*

```
"require": {
    "livewire/livewire": "dev-main" (si c'est toujour en developpement)
}
---

<!-- **Pour le developpement local** -->
Créer un fichier **composer.local.json** et y ajouter le code suivant
"repositories": [

        {
            "type": "path",
            "url": "../mt-packages/laravel/mt-views",
            "options": {
                "symlink": true
            }
        }
    ],
//Important: le fichier **composer.local.json** doit etre ajouter à *.gitignore* car n'est utile qu'en locale
//ceci c'est pour eviter de faire *composer upadate mt-views* à chaque modification du package

<!-- **Pour le developpement en production** -->

"repositories": [
    {
        "type": "vcs",
        "url": "git@github.com:martaf96/mt-views.git"
    }
],

```

2. Ajout de l'authentification comme le package est privé:

```
composer config --global --auth github-oauth.com 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 //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

//le token "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 " est generer depuis mon github
```

3. Installer le package dans le projet:

```
// En local:
composer require mt/mt-views:*

//En production
composer required mt/mt-views:version (version="dev-main" si on souhaite la version en developpement)
```

4. Import du tailwind css du package dans le projet:
Ajout de la directine: **@import "../../vendor/mt/mt-views/resources/css/tailwind.css";** dans le **ressources/css/app.css** du projet



import { defineConfig } from 'vite'

export default defineConfig({
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        mt: 'resources/css/mt.css',  // CSS principal du package
        'mt-js': 'resources/js/mt.js', // JS principal du package
      },
      output: {
        // Le nom du fichier final CSS / JS
        assetFileNames: ({ name }) => {
          if (name && name.endsWith('.css')) {
            return 'mt.css'
          }
          return '[name].[hash].[ext]'
        },
        entryFileNames: ({ name }) => {
          if (name === 'mt-js') return 'mt.js'
          return '[name].[hash].js'
        },
      },
    },
  },
})


