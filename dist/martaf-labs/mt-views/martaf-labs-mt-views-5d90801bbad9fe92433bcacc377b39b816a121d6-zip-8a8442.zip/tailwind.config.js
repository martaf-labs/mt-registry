// /** @type {import('tailwindcss').Config} */
// export default {
//   content: [
//     './resources/js/**/*.js',       // JS avec classes dynamiques
//     './resources/views/**/*.blade.php' // Blade si tu veux purger les classes
//   ],
//   theme: {
//     extend: {},
//   },
//   plugins: [],
// }

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './resources/**/*.blade.php',
    './resources/**/*.js',
    './resources/**/*.vue',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};