<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['web'])->group(function () {
    Route::get('/search', function () {
        return view('mt::livewire.search.results', [
            'query'    => request('q', ''),
            'category' => request('category'),
        ]);
    })->name('search.index');
});