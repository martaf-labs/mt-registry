<?php

use Illuminate\Support\Facades\Route;
use Mt\MtViews\Http\Controllers\ImageUploadController;
use Illuminate\Http\Request;
use Mt\MtViews\Helpers\MtLocale;


/**
 * Route GET pour changer la locale sans Livewire.
 * Utilisée par le composant Blade anonyme <x-mt-views::locale-switcher />.
 *
 * Enregistrement dans MtViewsServiceProvider::boot() :
 *   $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
 */
Route::get('/mt/locale/{locale}', function (Request $request, string $locale) {
    MtLocale::set($locale);

    $redirect = $request->query('redirect', url()->previous('/'));

    // Sécurité : on ne redirige que vers des URLs internes
    if (! str_starts_with($redirect, config('app.url'))) {
        $redirect = '/';
    }

    return redirect($redirect);
})
->name('mt.locale.switch')
->middleware('web');

// route mt-icons
Route::get('/mt-icons', function () {

    $path =dirname(__DIR__).'/resources/views/icons';

    $icons = collect(scandir($path))
        ->filter(fn ($file) => str_ends_with($file, '.svg'))
        ->map(fn ($file) => str_replace('.svg', '', $file))
        ->values();

    return view('mt::icons.index', compact('icons'));
});

Route::get('/mt-docs', function () {
    return view('mt::docs.index');
});

// route upload image de tinymce
// Route::post('/admin/upload-image', [ImageUploadController::class, 'upload'])->name('image.upload');
Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    Route::post('upload-image', [ImageUploadController::class, 'upload'])->name('image.upload');
});