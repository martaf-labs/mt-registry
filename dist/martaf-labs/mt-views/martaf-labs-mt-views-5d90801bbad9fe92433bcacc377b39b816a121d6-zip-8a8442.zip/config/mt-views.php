<?php

/*_______________________
|--------------------------------------------------------------------------
| Fichier de configuration insdispensable pour le bon fonctionnement du package "mt-views"
|--------------------------------------------------------------------------
|
|_________________________________
*/

return [

    /*
    |--------------------------------------------------------------------------
    | Définit le layout Blade par défaut utilisé dans l'application.
    |--------------------------------------------------------------------------
    */
    'default_layout' => 'guest',

    'layouts' => [
        'admin*' => 'app',
        'dashboard*' => 'app',
    ],

    /*
    |--------------------------------------------------------------------------
    | Chargement automatique des assets CSS/JS.
    |--------------------------------------------------------------------------
    */
    'load_css' => true,
    'load_js'  => true,

    /*
    |--------------------------------------------------------------------------
    | app name
    |--------------------------------------------------------------------------
    */
    'app_name' => env('APP_NAME', 'Mt Project'),

    /*
    |--------------------------------------------------------------------------
    | SEO meta
    |--------------------------------------------------------------------------
    */
    'seo' => [
        'title_suffix' => env('SEO_TITLE_SUFFIX', 'MT Views'),
        'description' => env('SEO_DESCRIPTION', 'MT Views est un package laravel, pour facilliter le developpement des applications et site web'),
        
        'og' => [
            'type' => env('OG_TYPE', 'website'),
            'site_name' => env('APP_NAME', 'website'),
            'twitter_handle' => env('TWITTER_HANDLE', 'twitter_handle'),
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Assets
    |--------------------------------------------------------------------------
    */
    'assets' => [
        'load_package_assets' => true,
        'load_project_assets' => true,
        'favicons' => [
            'ico' => env('FAVICON_ICO', 'favicon.ico'),
            'svg' => env('FAVICON_SVG', 'favicon.svg'),
            'png' => env('FAVICON_PNG', 'favicon.png'),
        ],
        'logos' => [
            'jpg' => env('LOGO_JPG', 'logo.jpg'),
            'svg' => env('LOGO_SVG', 'logo.svg'),
            'png' => env('LOGO_PNG', 'logo.png'),
        ],
        'font_heading' => "'Montserrat', 'san-serif'",
        'font_body' => "'Montserrat', 'san-serif'",
        'google_font_url' => env('GOOGLE_FONT_URL', '"https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;700&display=swap"'),
        'fontawesome_icons_url' => env('FONTAWESOME_ICONS_URL', "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.1.0/css/all.min.css"),
        'fontawesome_icons_path' => env('FONTAWESOME_ICONS_PATH', ),
    ],

    /*
    |--------------------------------------------------------------------------
    | dark mode
    |--------------------------------------------------------------------------
    */
    'enable_dark_mode' => env('ENABLE_DARK_MODE', false),


    /*
    |--------------------------------------------------------------------------
    | vues
    |--------------------------------------------------------------------------
    */
    'enable_dashboard' => env('ENABLE_DASHBOARD', true),

    /*
    |--------------------------------------------------------------------------
    | Configuration de l'affichage des vues pour les articles (ex: vue login)
    |--------------------------------------------------------------------------
    */

    //vue login
    'login' => [
        'layout'    => env('MTVIEWS_LOGIN_LAYOUT', 'classic'), //'classic' | 'split' | 'minimal' | 'immersive'
        'options'   => [
            'logo'              => env('MTVIEWS_LOGIN_LOGO', false),
            'register'          => env('MTVIEWS_LOGIN_REGISTER', false),
            'password_reset'    => env('MTVIEWS_LOGIN_PASSWORD_RESET', false),
            'home'              => env('MTVIEWS_LOGIN_HOME', true),
            'remember'          => env('MTVIEWS_LOGIN_REMEMBER', false),
        ],
    ],

    
    /*
    |--------------------------------------------------------------------------
    | Configuration de l'affichage des options des composants (ex: composant post_card)
    |--------------------------------------------------------------------------
    */

    //composant post.card
    // 'post-card' => [
    //     'options' => [
            
    //     ],
    // ],

    /*
    |--------------------------------------------------------------------------
    | Gestion des couleurs
    |--------------------------------------------------------------------------
    */
    'colors' => [
        'light' =>  [
            'primary' => env('PRIMARY_LIGHT_COLOR', '#6366f1'),
            'secondary' => env('SECONDARY_LIGHT_COLOR', '#71717a'),
            'bg' => env('BG_LIGHT_COLOR','#ffffff'),
            'text' => env('TEXT_LIGHT_COLOR','#18181b')
        ],
        'dark' =>  [
            'primary' => env('PRIMARY_DARK_COLOR','#818cf8'),
            'secondary' => env('SECONDARY_DARK_COLOR','#a1a1aa'),
            'bg' => env('BG_DARK_COLOR','#09090b'),
            'text' => env('TEXT_DARK_COLOR','#fafafa')
        ],        
    ],

    /*
    |--------------------------------------------------------------------------
    | Models Providers
    |--------------------------------------------------------------------------
    */
    'providers' => [
        'developpeurs' => [
            'driver' => 'eloquent',
            'model'  => env('DEVELOPPEUR_MODEL', '\App\Models\Developpeur'),
        ],
        'images' => [
            'driver' => 'eloquent',
            'model'  => env('IMAGE_MODEL', '\App\Models\Image'),
        ],
        'documents' => [
            'driver' => 'eloquent',
            'model'  => env('DOCUMENT_MODEL', '\App\Models\Document'),
        ],
        'videos' => [
            'driver' => 'eloquent',
            'model'  => env('VIDEO_MODEL', '\App\Models\Video'),
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | [IMAGE OPTIMIZER] Configuration de l'optimisation d'images
    |--------------------------------------------------------------------------
    |
    | Section ajoutée au package mt-views pour l'optimisation automatique.
    | Toutes les valeurs sont surchargeable via les variables d'environnement.
    |
    */
    'image_optimizer' => [

        // Disque de stockage (doit correspondre à un disque dans config/filesystems.php)
        'disk' => env('MT_IMAGE_DISK', 'public'),

        // Dossier de sortie des images optimisées (relatif au disque)
        'output_directory' => env('MT_IMAGE_OUTPUT_DIR', 'images/optimized'),

        // Taille max d'upload en KB (10240 = 10 MB)
        'max_upload_size' => env('MT_IMAGE_MAX_SIZE', 10240),

        // Qualité de compression par format
        'quality' => [
            'jpg'  => env('MT_IMAGE_QUALITY_JPG', 85),
            'png'  => env('MT_IMAGE_QUALITY_PNG', 85),
            'webp' => env('MT_IMAGE_QUALITY_WEBP', 85),
            'avif' => env('MT_IMAGE_QUALITY_AVIF', 80),
            'gif'  => env('MT_IMAGE_QUALITY_GIF', 85),
        ],

        // Conversion automatique en WebP (recommandé)
        'convert_to_webp' => env('MT_IMAGE_WEBP', true),

        // Conversion automatique en AVIF (nécessite Imagick + libavif)
        'convert_to_avif' => env('MT_IMAGE_AVIF', false),

        // Dimensions maximales (redimensionnement sans déformation)
        'max_width'  => env('MT_IMAGE_MAX_WIDTH', 2560),
        'max_height' => env('MT_IMAGE_MAX_HEIGHT', 2560),

        // Variantes responsive générées automatiquement
        // Clé = nom accessible via getVariantUrl('thumbnail'), valeur = largeur max en px
        'variants' => [
            'thumbnail' => 150,
            'small'     => 400,
            'medium'    => 800,
            'large'     => 1200,
            'xlarge'    => 1920,
        ],

        // Traitement en file d'attente
        'queue' => [
            'enabled'    => env('MT_IMAGE_QUEUE', true),
            'connection' => env('MT_IMAGE_QUEUE_CONNECTION', null), // null = connexion par défaut
            'queue_name' => env('MT_IMAGE_QUEUE_NAME', 'default'),
        ],

        // Watermark
        'watermark' => [
            'enabled'  => env('MT_IMAGE_WATERMARK', false),
            'path'     => env('MT_IMAGE_WATERMARK_PATH', null),  // chemin absolu
            'position' => 'bottom-right',  // top-left|top-right|bottom-left|bottom-right|center
            'opacity'  => 70,
            'padding'  => 10,
        ],

        // Logging
        'logging' => [
            'enabled' => env('MT_IMAGE_LOG', true),
            'channel' => env('MT_IMAGE_LOG_CHANNEL', 'stack'),
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Icônes Font Awesome
    |--------------------------------------------------------------------------
    */
    'icons' => [
        // BTP & CONSTRUCTION
        'blueprint'     => 'fa-solid fa-map',
        'cone'          => 'fa-solid fa-triangle-exclamation',
        'digging'       => 'fa-solid fa-person-digging',
        'hammer'        => 'fa-solid fa-hammer',
        'helmet'        => 'fa-solid fa-helmet-safety',
        'ruler'         => 'fa-solid fa-ruler-combined',
        'tools'         => 'fa-solid fa-screwdriver-wrench',
        'trowel'        => 'fa-solid fa-trowel-bricks',
        // SCOLAIRE & ÉDUCATION
        'book'          => 'fa-solid fa-book-open',
        'bus'           => 'fa-solid fa-bus',
        'certificate'   => 'fa-solid fa-award',
        'chalkboard'    => 'fa-solid fa-chalkboard-user',
        'microscope'    => 'fa-solid fa-microscope',
        'pen'           => 'fa-solid fa-pen-nib',
        'school'        => 'fa-solid fa-school',
        'student'       => 'fa-solid fa-graduation-cap',
        'user-grade'    => 'fa-solid fa-user-graduate',
        // BLOG & MÉDIAS
        'comments'      => 'fa-solid fa-comments',
        'eye'           => 'fa-solid fa-eye',
        'image'         => 'fa-solid fa-image',
        'newspaper'     => 'fa-solid fa-newspaper',
        'quote'         => 'fa-solid fa-quote-left',
        'rss'           => 'fa-solid fa-rss',
        'search'        => 'fa-solid fa-magnifying-glass',
        'share'         => 'fa-solid fa-share-nodes',
        'tags'          => 'fa-solid fa-tags',
        'write'         => 'fa-solid fa-pen-to-square',
        // INTERFACE GÉNÉRIQUE
        'add'           => 'fa-solid fa-plus',
        'cancel'        => 'fa-solid fa-xmark',
        'check'         => 'fa-solid fa-check',
        'delete'        => 'fa-solid fa-trash-can',
        'edit'          => 'fa-solid fa-pen',
        'error'         => 'fa-solid fa-circle-xmark',
        'info'          => 'fa-solid fa-circle-info',
        'save'          => 'fa-solid fa-floppy-disk',
        'success'       => 'fa-solid fa-circle-check',
        'warning'       => 'fa-solid fa-triangle-exclamation',
        // DIVERS
        'calendar'      => 'fa-solid fa-calendar-days',
        'camera'        => 'fa-solid fa-camera',
        'cog'           => 'fa-solid fa-cog',
        'download'      => 'fa-solid fa-download',
        'file'          => 'fa-solid fa-file',
        'home'          => 'fa-solid fa-house',
        'location'      => 'fa-solid fa-location-dot',
        'lock'          => 'fa-solid fa-lock',
        'phone'         => 'fa-solid fa-phone',
        'star'          => 'fa-solid fa-star',
        'upload'        => 'fa-solid fa-upload',
        'user'          => 'fa-solid fa-user',
        'users'         => 'fa-solid fa-users',
        'video'         => 'fa-solid fa-video',
    ],

    /*
    |--------------------------------------------------------------------------
    | Couleurs Tailwind CSS
    |--------------------------------------------------------------------------
    */
    'default_colors' => [
        'slate-50'   => '#f8fafc', 'slate-100'  => '#f1f5f9', 'slate-200'  => '#e2e8f0',
        'slate-300'  => '#cbd5e1', 'slate-400'  => '#94a3b8', 'slate-500'  => '#64748b',
        'slate-600'  => '#475569', 'slate-700'  => '#334155', 'slate-800'  => '#1e293b',
        'slate-900'  => '#0f172a',
        'zinc-50'    => '#fafafa', 'zinc-100'   => '#f4f4f5', 'zinc-200'   => '#e4e4e7',
        'zinc-300'   => '#d4d4d8', 'zinc-400'   => '#a1a1aa', 'zinc-500'   => '#71717a',
        'zinc-600'   => '#52525b', 'zinc-700'   => '#3f3f46', 'zinc-800'   => '#27272a',
        'zinc-900'   => '#18181b',
        'red-500'    => '#ef4444', 'red-600'    => '#dc2626', 'red-700'    => '#b91c1c',
        'orange-500' => '#f97316', 'orange-600' => '#ea580c',
        'amber-500'  => '#f59e0b', 'amber-600'  => '#d97706',
        'emerald-50' => '#ecfdf5', 'emerald-500'=> '#10b981', 'emerald-600'=> '#059669',
        'blue-50'    => '#eff6ff', 'blue-500'   => '#3b82f6', 'blue-600'   => '#2563eb',
        'blue-700'   => '#1d4ed8',
        'indigo-500' => '#6366f1', 'indigo-600' => '#4f46e5',
        'violet-500' => '#8b5cf6', 'purple-500' => '#a855f7',
        'white'      => '#ffffff', 'black'      => '#000000', 'transparent'=> 'transparent',
    ],
];
