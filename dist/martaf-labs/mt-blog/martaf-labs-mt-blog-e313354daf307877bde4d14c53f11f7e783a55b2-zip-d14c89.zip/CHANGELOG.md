
##############[23-04-2026]#####################
Supression des champs **featured_image, featured_image_legend, gallery_images,video_url,audio_url** de la table **articles**.
 les images featured proviendront directement de la table **images**, afin qu'on soit en mesure d'optimizer l'affichage.



git init
git add .
git commit -m "Initial commit - mt-blog"
git remote add origin https://github.com/martaf-labs/mt-blog.git
git branch -M main    
git pull origin main --rebase
git push -u origin main