<p class="mb-4 text-lg leading-relaxed">
    {!! $data['text'] !!}
</p>
