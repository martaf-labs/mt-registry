<figure class="my-6 text-center">
    <img src="{{ $data['url'] }}" class="rounded-xl mx-auto">
    
    @if(!empty($data['caption']))
        <figcaption class="text-sm text-gray-500 mt-2">
            {{ $data['caption'] }}
        </figcaption>
    @endif
</figure>
