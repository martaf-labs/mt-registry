@php $level = $data['level'] ?? 2; @endphp

<h{{ $level }} class="font-bold mt-8 mb-4 text-2xl">
    {{ $data['text'] }}
</h{{ $level }}>
