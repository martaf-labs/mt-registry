@props([
    'name',
    'value' => [],
    'id' => 'mt-editor-'.uniqid(),
])

<div 
    x-data="mtBlogEditor({
        fieldName: '{{ $name }}',
        initialData: @js($value ?? [])
    })"
    x-init="init()"
    class="mtblog-editor w-full"
>

    {{-- Toolbar --}}
    <div class="flex items-center justify-between mb-2">
        <h3 class="font-semibold text-lg text-gray-700 dark:text-gray-200">
            Contenu de l'article
        </h3>

        <button type="button"
                @click="toggleDarkMode"
                class="px-3 py-1 rounded-lg bg-gray-200 dark:bg-gray-700">
            <i class="fa-solid fa-moon"></i>
        </button>
    </div>

    {{-- EditorJS container --}}
    <div :id="editorId" class="editorjs-wrapper"></div>

    {{-- Hidden input --}}
    <input type="hidden" :name="fieldName" x-ref="input">
</div>
