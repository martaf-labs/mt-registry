{{--
╔══════════════════════════════════════════════════════════════════╗
║  HEADER VARIANT : magazine                                       ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Bande supérieure sombre (bg-primary) : logo | tagline       ║
║      + search + dark mode + auth                                 ║
║    → Bande nav (mt-bg ou blanche) : navigation pleine largeur    ║
║      avec accent coloré sur l'item actif                         ║
║    → Breaking ticker                                             ║
║  Usage : magazine, sport, culture, lifestyle                     ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.header._menu-data')

<header
    x-data="headerComponent()"
    x-init="init()"
    class="sticky top-0 z-40 transition-shadow duration-300"
    :class="scrolled ? 'shadow-lg' : ''">

    {{-- ── Bande 1 : fond sombre ─────────────────────────────────── --}}
    <div class="bg-[rgb(var(--mt-primary))] dark:bg-gray-950 text-white">
        <div class="px-4 lg:px-8 mx-auto max-w-full">
            <div class="flex items-center justify-between h-14 lg:h-16 gap-4">

                {{-- Logo + tagline --}}
                <div class="flex items-center gap-3 flex-shrink-0">
                    <a href="{{ mt_get_route('home') }}" wire:navigate class="group">
                        <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                             class="h-8 lg:h-10 w-auto object-contain brightness-0 invert
                                    transition-transform duration-300 group-hover:scale-105">
                    </a>
                    @if (config('mtblog.header.tagline'))
                    <span class="hidden lg:block text-[11px] text-white/40 font-medium
                                  border-l border-white/10 pl-3 leading-tight">
                        {{ config('mtblog.header.tagline') }}
                    </span>
                    @endif
                </div>

                {{-- Centre : date + localisation --}}
                <div class="hidden lg:flex items-center gap-4 text-[11px] text-white/50">
                    <span class="flex items-center gap-1.5">
                        <span class="relative w-1.5 h-1.5 flex-shrink-0">
                            <span class="absolute inset-0 rounded-full bg-[rgb(var(--mt-secondary))] animate-ping opacity-75"></span>
                            <span class="relative rounded-full w-1.5 h-1.5 bg-[rgb(var(--mt-secondary))]"></span>
                        </span>
                        EN DIRECT
                    </span>
                    <span class="w-px h-3 bg-white/10"></span>
                    <span><span id="header-topbar-date"></span></span>
                    @if (config('mtblog.header.city'))
                    <span class="w-px h-3 bg-white/10"></span>
                    <span><i class="fa-solid fa-location-dot text-[rgb(var(--mt-secondary))] mr-1 text-[9px]"></i>{{ config('mtblog.header.city') }}</span>
                    @endif
                </div>

                {{-- Droite --}}
                <div class="flex items-center gap-2 flex-shrink-0">
                    @include('mtblog::components.header._search-bar', ['theme' => 'dark'])
                    <x-mt::dark-mode-toggle />
                    @include('mtblog::components.header._auth-buttons', ['theme' => 'dark', 'compact' => true])
                    <button @click="mobileOpen = true"
                            class="lg:hidden w-9 h-9 flex items-center justify-center rounded-xl
                                   bg-white/10 text-white hover:bg-white/20 transition-colors">
                        <i class="fa-solid fa-bars text-sm"></i>
                    </button>
                </div>

            </div>
        </div>
    </div>

    {{-- ── Bande 2 : navigation ──────────────────────────────────── --}}
    <div class="mt-bg border-b border-gray-200/60 dark:border-white/5">
        <div class="px-4 lg:px-8 mx-auto max-w-full">
            <div class="hidden lg:flex items-center h-11">

                {{-- Lien accueil avec fond coloré --}}
                <a href="{{ mt_get_route('home') }}" wire:navigate
                   class="flex items-center gap-1.5 px-4 h-full text-sm font-bold text-white
                          bg-[rgb(var(--mt-secondary))] hover:bg-[rgb(var(--mt-secondary))]/90
                          mr-2 flex-shrink-0 transition-colors">
                    <i class="fa-solid fa-house text-xs"></i>
                    <span class="hidden xl:inline">Accueil</span>
                </a>

                {{-- Nav --}}
                @include('mtblog::components.header._nav-desktop', [
                    'menuItems' => $menuItems,
                    'showHome'  => false,
                    'size'      => 'sm',
                ])

            </div>
        </div>
    </div>

    {{-- Mobile --}}
    @include('mtblog::components.header._nav-mobile', [
        'menuItems' => $menuItems,
        'isHome'    => mtblog_is_home(),
    ])

</header>

@include('mtblog::components.header._breaking-ticker')
@include('mtblog::components.header._js')
