{{--
╔══════════════════════════════════════════════════════════════════╗
║  HEADER VARIANT : editorial                                      ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Topbar légère (fond clair)                                  ║
║    → Ligne 1 (haute) : logo centré | search gauche | auth droite ║
║    → Séparateur                                                  ║
║    → Ligne 2 (nav) : navigation pleine largeur centrée           ║
║    → Breaking ticker                                             ║
║  Usage : presse, revue, magazine de fond                         ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.header._menu-data')

@include('mtblog::components.header._topbar', [
    'theme' => 'light',
    'city'  => config('mtblog.header.city'),
    'temp'  => config('mtblog.header.temp'),
])

<header
    x-data="headerComponent()"
    x-init="init()"
    :class="scrolled ? 'shadow-sm' : ''"
    class="sticky top-0 z-40 mt-bg border-b border-gray-200/60 dark:border-white/5 transition-shadow duration-300">

    <div class="px-4 lg:px-8 mx-auto max-w-full">

        {{-- ── Ligne 1 : logo + search + auth ──────────────────── --}}
        <div class="flex items-center justify-between h-14 gap-4
                     border-b border-gray-100 dark:border-white/6">

            {{-- Search --}}
            <div class="flex-1 hidden lg:flex">
                @include('mtblog::components.header._search-bar', ['theme' => 'light'])
            </div>

            {{-- Logo centré --}}
            <a href="{{ mt_get_route('home') }}" wire:navigate
               class="flex-shrink-0 mx-auto lg:mx-0 group">
                <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                     class="h-9 lg:h-11 w-auto object-contain transition-transform duration-300
                            group-hover:scale-105 dark:brightness-0 dark:invert">
            </a>

            {{-- Auth + burger --}}
            <div class="flex-1 hidden lg:flex items-center justify-end gap-2">
                @include('mtblog::components.header._auth-buttons', ['theme' => 'light'])
            </div>

            {{-- Mobile : search + burger --}}
            <div class="flex items-center gap-2 lg:hidden">
                @include('mtblog::components.header._search-bar', ['theme' => 'light'])
                <button @click="mobileOpen = true"
                        class="w-9 h-9 flex items-center justify-center rounded-xl
                               bg-gray-100 dark:bg-white/6 text-gray-600 dark:text-white/50
                               hover:bg-gray-200 dark:hover:bg-white/10 transition-colors">
                    <i class="fa-solid fa-bars text-sm"></i>
                </button>
            </div>
        </div>

        {{-- ── Ligne 2 : navigation ─────────────────────────────── --}}
        <div class="hidden lg:flex items-center justify-center h-11">
            @include('mtblog::components.header._nav-desktop', [
                'menuItems' => $menuItems,
                'showHome'  => true,
                'size'      => 'sm',
            ])
        </div>

    </div>

    @include('mtblog::components.header._nav-mobile', [
        'menuItems' => $menuItems,
        'isHome'    => mtblog_is_home(),
    ])
</header>

@include('mtblog::components.header._breaking-ticker')
@include('mtblog::components.header._js')
