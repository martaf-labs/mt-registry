{{--
  Partial : _topbar.blade.php
  Barre supérieure (date, météo, langue, liens rapides, dark mode).
  Props :
    $theme  'dark' | 'light'  (défaut: 'dark')
    $city   string             (défaut: null → caché)
    $temp   string             (défaut: null → caché)
--}}

@if(mtblog_option_header('topbar'))

@props([
    'theme' => 'dark',
    'city'  => null,
    'temp'  => null,
])

@php
    $theme = mt_has_dark_mode()? $theme : 'light';
    $isDark    = $theme === 'dark';
    $barBg     = $isDark ? 'bg-black border-white/5' : 'bg-gray-50 dark:bg-white/4 border-gray-200 dark:border-white/6';
    $textColor = $isDark ? 'text-white/50' : 'text-gray-500 dark:text-white/40';
    $sepColor  = $isDark ? 'bg-white/10'   : 'bg-gray-300 dark:bg-white/10';
@endphp

<div class="text-xs border-b {{ $barBg }}"
     x-data="headerComponent()">
    <div class="flex items-center justify-between h-9 px-4 lg:px-8 py-1 mx-auto max-w-full">

        {{-- ── Gauche ─────────────────────────────────────────── --}}
        <div class="flex items-center gap-4">

            {{-- Live / En direct --}}
            <span class="inline-flex items-center gap-1.5 font-bold tracking-wider uppercase text-[10px]
                          text-[rgb(var(--mt-secondary))]">
                <span class="relative flex w-2 h-2 flex-shrink-0">
                    <span class="absolute inset-0 rounded-full opacity-75 animate-ping bg-[rgb(var(--mt-secondary))]"></span>
                    <span class="relative rounded-full w-2 h-2 bg-[rgb(var(--mt-secondary))]"></span>
                </span>
                <span class="hidden sm:inline">EN DIRECT</span>
            </span>

            <span class="w-px h-3 {{ $sepColor }} flex-shrink-0"></span>

            {{-- Date --}}
            <span class="{{ $textColor }} hidden sm:flex items-center gap-1.5 text-[11px] font-medium">
                <i class="fa-solid fa-calendar-alt text-[rgb(var(--mt-secondary))] text-[9px]"></i>
                <span id="header-topbar-date"></span>
            </span>

            {{-- Localisation --}}
            @if ($city)
            <span class="hidden w-px h-3 {{ $sepColor }} md:block flex-shrink-0"></span>
            <span class="{{ $textColor }} hidden md:flex items-center gap-1.5 text-[11px] font-medium">
                <i class="fa-solid fa-location-dot text-[rgb(var(--mt-secondary))] text-[9px]"></i>
                {{ $city }}
            </span>
            @endif

        </div>

        {{-- ── Droite ──────────────────────────────────────────── --}}
        <div class="flex items-center gap-3">

            {{-- Météo --}}
            @if ($temp)
            <span class="{{ $textColor }} hidden lg:flex items-center gap-1.5 text-[11px] font-medium">
                <i class="fa-solid fa-sun text-amber-400 text-[10px]"></i>
                {{ $temp }}
            </span>
            <span class="hidden w-px h-3 {{ $sepColor }} lg:block flex-shrink-0"></span>
            @endif

            {{-- Dark mode toggle --}}
            <x-mt::dark-mode-toggle />

            {{-- Langue --}}
            <livewire:mt.locale-switcher />

            {{-- Liens rapides --}}
            <span class="hidden w-px h-3 {{ $sepColor }} sm:block flex-shrink-0"></span>
            <a href="#" wire:navigate
              -mtlass="{{ $textColor }} hidden sm:flex items-center gap-1 text-[11px]
                      hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <i class="fa-solid fa-circle-play text-[10px]"></i>
                Vidéos
            </a>
            <a href="#" wire:navigate
               class="{{ $textColor }} hidden sm:flex items-center gap-1 text-[11px]
                      hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <i class="fa-solid fa-image text-[10px]"></i>
                Photos
            </a>

        </div>
    </div>
</div>
@endif