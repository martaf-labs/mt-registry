@php
    use Mt\Blog\Models\Category;
    use Mt\Blog\Models\Article;
    use Mt\Blog\Enums\StatusArticle;

    // ── Menu items (mis en cache 1h) ──────────────────────────────
    $menuItems = cache()->remember('blog.header.menu', 3600, function () {

        $menuItems = [];

        // Actualité / breaking news
        $actualitesItems = Category::whereHas('articles',
            fn($q) => $q->where('is_breaking_news', true)
        )->latest()->take(5)->get()->map(fn($cat) => [
            'label' => $cat->name,
            'icon'  => $cat->icon ?? 'fa-solid fa-newspaper',
            'url'   => mt_get_route('home_categories_show', ['slug' => $cat->slug]),
            'count' => $cat->articles()->where('is_breaking_news', true)->count(),
        ])->toArray();

        $menuItems['actualite'] = [
            'label'     => 'Actualité',
            'icon'      => 'fa-solid fa-bolt-lightning',
            'subItems'  => $actualitesItems,
            'is_active' => request()->routeIs('home.categories.show') && request('slug') === 'actualite',
        ];

        // Catégories principales (5 max)
        $mainCategories = Category::parents()
            ->whereHas('articles', fn($q) => $q->where('status', StatusArticle::PUBLISHED))
            ->withCount(['articles' => fn($q) => $q->where('status', StatusArticle::PUBLISHED)])
            ->ordered()
            ->take(5)
            ->get();

        foreach ($mainCategories as $cat) {
            $children = $cat->children()
                ->whereHas('articles', fn($q) => $q->where('status', StatusArticle::PUBLISHED))
                ->get()
                ->map(fn($child) => [
                    'label' => $child->name,
                    'icon'  => $child->icon ?? 'fa-solid fa-folder',
                    'url'   => mt_get_route('home_categories_show', ['slug' => $child->slug]),
                ])->toArray();

            $menuItems[$cat->slug] = [
                'label'     => $cat->name,
                'icon'      => $cat->icon ?? 'fa-solid fa-folder',
                'color'     => $cat->color ?? null,
                'url'       => empty($children)
                    ? mt_get_route('home_categories_show', ['slug' => $cat->slug])
                    : '#',
                'subItems'  => $children ?: null,
                'is_active' => request()->routeIs('home.categories.show') && request('slug') === $cat->slug,
                'count'     => $cat->articles_count ?? 0,
            ];
        }

        // Menu "Plus"
        $otherCategories = Category::parents()
            ->whereHas('articles', fn($q) => $q->where('status', StatusArticle::PUBLISHED))
            ->whereNotIn('id', $mainCategories->pluck('id'))
            ->ordered()
            ->get()
            ->map(fn($c) => [
                'label' => $c->name,
                'icon'  => $c->icon ?? 'fa-solid fa-folder',
                'url'   => mt_get_route('home_categories_show', ['slug' => $c->slug]),
            ])->toArray();

        if (!empty($otherCategories)) {
            $menuItems['plus'] = [
                'label'    => 'Plus',
                'icon'     => 'fa-solid fa-ellipsis',
                'subItems' => $otherCategories,
                'is_active' => false,
            ];
        }

        return $menuItems;
    });

    // ── Breaking news (mis en cache 5 min) ───────────────────────
    $breakingNews = cache()->remember('blog.breaking.news', 300, fn() =>
        Article::breakingNews()->with('category')->latest()->take(5)->get()
    );

    $currentSlug = request('slug');
    $isHome      = request()->routeIs('home');
@endphp


{{-- inclusion du layout actif --}}
@include('mtblog::components.header.'.mtblog_config('header.layout'))