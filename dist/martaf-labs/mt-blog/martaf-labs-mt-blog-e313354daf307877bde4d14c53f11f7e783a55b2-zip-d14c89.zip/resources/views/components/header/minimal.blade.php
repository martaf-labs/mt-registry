{{--
╔══════════════════════════════════════════════════════════════════╗
║  HEADER VARIANT : minimal                                        ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Pas de topbar                                               ║
║    → Barre unique fine : logo | nav compacte | search | darkmode ║
║    → Pas de breaking ticker (ou version sobre inline)            ║
║  Usage : corporate, blog tech, newsletter, juridique             ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.header._menu-data')

<header
    x-data="headerComponent()"
    x-init="init()"
    :class="scrolled ? 'shadow-sm' : ''"
    class="sticky top-0 z-40 mt-bg border-b border-gray-100 dark:border-white/6 transition-shadow duration-300">

    <div class="px-4 lg:px-8 mx-auto max-w-full">
        <div class="flex items-center justify-between h-14 gap-4">

            {{-- Logo compact --}}
            <a href="{{ mt_get_route('home') }}" wire:navigate class="flex-shrink-0 group">
                <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                     class="h-7 w-auto object-contain transition-transform duration-300
                            group-hover:scale-105 dark:brightness-0 dark:invert">
            </a>

            {{-- Nav compacte --}}
            @include('mtblog::components.header._nav-desktop', [
                'menuItems' => $menuItems,
                'showHome'  => true,
                'size'      => 'sm',
            ])

            {{-- Droite --}}
            <div class="flex items-center gap-1.5 flex-shrink-0">
                @include('mtblog::components.header._search-bar', ['theme' => 'light'])

                {{-- Dark mode seul (pas de gros boutons auth en minimal) --}}
                <x-mt::dark-mode-toggle />

                {{-- Auth compact --}}
                @include('mtblog::components.header._auth-buttons', [
                    'theme'   => 'light',
                    'compact' => true,
                ])

                <button @click="mobileOpen = true"
                        class="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg
                               text-gray-500 dark:text-white/40
                               hover:bg-gray-100 dark:hover:bg-white/6 transition-colors">
                    <i class="fa-solid fa-bars text-sm"></i>
                </button>
            </div>
        </div>
    </div>

    @include('mtblog::components.header._nav-mobile', [
        'menuItems' => $menuItems,
        'isHome'    => mtblog_is_home(),
    ])
</header>

{{-- Breaking news : version sobre inline (pas de marquee) --}}
@if ($breakingNews->isNotEmpty())
<div class="border-b border-gray-100 dark:border-white/6 bg-[rgb(var(--mt-secondary))]/5">
    <div class="px-4 lg:px-8 py-2 flex items-center gap-3 text-xs">
        <span class="flex-shrink-0 flex items-center gap-1.5 font-bold text-[rgb(var(--mt-secondary))] uppercase tracking-wider">
            <i class="fa-solid fa-bolt text-[9px]"></i>
            Flash
        </span>
        <span class="w-px h-3 bg-gray-200 dark:bg-white/10 flex-shrink-0"></span>
        <a href="{{ mt_get_route('home_articles_show', ['slug' => $breakingNews->first()->slug, 'id' => $breakingNews->first()->id]) }}"
           wire:navigate
           class="text-gray-600 dark:text-white/50 hover:text-[rgb(var(--mt-secondary))] transition-colors truncate font-medium">
            {!! $breakingNews->first()->title !!}
        </a>
        @if ($breakingNews->count() > 1)
        <a href="{{ mt_get_route('home') }}"
           wire:navigate
           class="flex-shrink-0 text-[rgb(var(--mt-secondary))] hover:underline font-semibold ml-auto">
            +{{ $breakingNews->count() - 1 }} autres
        </a>
        @endif
    </div>
</div>
@endif

@include('mtblog::components.header._js')
