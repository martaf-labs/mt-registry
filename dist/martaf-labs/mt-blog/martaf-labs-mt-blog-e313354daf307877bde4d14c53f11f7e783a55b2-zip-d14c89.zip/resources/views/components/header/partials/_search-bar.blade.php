{{--
  Partial : _search-bar.blade.php
  Barre de recherche inline expansible.
  Props :
    $placeholder  string  (défaut: 'Rechercher…')
    $theme        'light' | 'dark'  (défaut: 'light')
  Contrôlée par Alpine `searchOpen` dans le composant parent.
--}}
@if (mt_has_search())
@props([
    'placeholder' => 'Rechercher un article…',
    'theme'       => 'light',
])

@php
    $theme = mt_has_dark_mode()? $theme : 'light';
    $isDark      = $theme === 'dark';
    $inputBg     = $isDark
        ? 'bg-white/10 border-white/20 text-white placeholder-white/40 focus:bg-white/15 focus:border-white/40'
        : 'bg-gray-100 dark:bg-white/6 border-gray-200 dark:border-white/8 text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-white/30 focus:bg-white dark:focus:bg-white/8 focus:border-[rgb(var(--mt-secondary))]/40';
    $iconColor   = $isDark ? 'text-white/50' : 'text-gray-400 dark:text-white/30';
    $kbdClass    = $isDark ? 'bg-white/15 text-white/50 border-white/20' : 'bg-gray-200 dark:bg-white/8 text-gray-500 dark:text-white/30 border-gray-300 dark:border-white/10';
@endphp

<div class="relative" x-data="{ searchOpen: false }">

    {{-- Bouton icône --}}
    <button @click="searchOpen = true; $nextTick(() => $refs.searchInput.focus())"
            x-show="!searchOpen"
            class="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium
                   {{ $isDark
                       ? 'text-white/60 hover:bg-white/10 hover:text-white'
                       : 'text-gray-500 dark:text-white/40 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-gray-700 dark:hover:text-white' }}
                   transition-all duration-200"
            title="Rechercher (/)">
        <i class="fa-solid fa-magnifying-glass text-sm"></i>
        <span class="hidden xl:inline text-xs">Rechercher</span>
        <kbd class="hidden xl:inline text-[10px] px-1.5 py-0.5 rounded border
                     {{ $kbdClass }} font-mono">/</kbd>
    </button>

    {{-- Champ expansible --}}
    <div x-show="searchOpen"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 w-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         class="flex items-center gap-2"
         style="display:none">

        <div class="relative">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2
                       text-xs pointer-events-none {{ $iconColor }}"></i>
            <input
                x-ref="searchInput"
                type="text"
                placeholder="{{ $placeholder }}"
                @keydown.enter="window.location.href = '{{ mt_get_route('home') }}?q=' + $el.value"
                @keydown.escape="searchOpen = false"
                @blur="setTimeout(() => searchOpen = false, 200)"
                class="pl-8 pr-4 py-2 text-sm rounded-xl border w-48 lg:w-64
                       focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/20
                       transition-all duration-200 {{ $inputBg }}"
            />
        </div>

        <button @click="searchOpen = false"
                class="flex-shrink-0 p-2 rounded-xl
                       {{ $isDark
                           ? 'text-white/50 hover:bg-white/10'
                           : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6' }}
                       transition-colors">
            <i class="fa-solid fa-xmark text-xs"></i>
        </button>
    </div>
</div>

@endif