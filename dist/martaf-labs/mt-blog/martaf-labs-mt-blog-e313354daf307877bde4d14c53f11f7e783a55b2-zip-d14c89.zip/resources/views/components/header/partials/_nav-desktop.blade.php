{{--
  Partial : _nav-desktop.blade.php
  Navigation desktop avec dropdowns Alpine.js.
  Props :
    $menuItems   array  (requis)
    $showHome    bool   afficher le lien "Accueil" (défaut: true)
    $size        'sm' | 'md'  taille des items  (défaut: 'md')
    $textColor   string classes Tailwind couleur texte  (défaut: 'text-gray-700 dark:text-white/70')
    $hoverBg     string classes Tailwind hover bg       (défaut: 'hover:bg-gray-100 dark:hover:bg-white/5')
--}}

@props([
    'menuItems'  => [],
    'showHome'   => true,
    'size'       => 'md',
    'textColor'  => 'text-gray-700 dark:text-white/70',
    'hoverBg'    => 'hover:bg-gray-100 dark:hover:bg-white/5',
    'showIcons'    => false,
])

@php
    $showHome = mtblog_option_header('home');
    $showIcons = mtblog_option_header('menu_icons');
    $itemClass = $size === 'sm'
        ? 'px-2.5 py-1.5 text-xs'
        : 'px-3 py-2 text-sm';
@endphp

<nav class="hidden lg:flex items-center gap-0.5">

    {{-- Accueil --}}
    @if ($showHome)
    <a href="{{ mt_get_route('home') }}" wire:navigate
       class="relative flex items-center gap-1.5 {{ $itemClass }} font-medium rounded-lg
              {{ $textColor }} {{ $hoverBg }} transition-all duration-150
              {{ request()->routeIs('home') ? 'font-semibold text-[rgb(var(--mt-secondary))]' : '' }}">
        {{-- @if ($showIcons) --}}
        <i class="fa-solid fa-house text-xs opacity-70"></i>        
        {{-- @endif --}}
        <span class="hidden xl:inline">Accueil</span>
    </a>
    @endif

    @foreach ($menuItems as $key => $item)

    @if (!empty($item['subItems']))

    {{-- Item avec sous-menu --}}
    <div class="relative" x-data="{ open: false }"
         @mouseenter="open = true" @mouseleave="open = false">

        <button
            class="relative flex items-center gap-1.5 {{ $itemClass }} font-medium rounded-lg
                   {{ $textColor }} {{ $hoverBg }} transition-all duration-150
                   {{ $item['is_active'] ? 'font-semibold text-[rgb(var(--mt-secondary))]' : '' }}"
            :class="open ? 'font-semibold text-[rgb(var(--mt-secondary))] bg-gray-100 dark:bg-white/5' : ''">

            @if ($showIcons && $item['icon'])
            <i class="{{ $item['icon'] }} text-xs opacity-70"></i>
            @endif

            {{ $item['label'] }}

            <i class="fa-solid fa-chevron-down text-[9px] opacity-50 transition-transform duration-200"
               :class="open ? 'rotate-180' : ''"></i>

            {{-- Indicateur actif --}}
            @if ($item['is_active'])
            <span class="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-[2px]
                          bg-[rgb(var(--mt-secondary))] rounded-full"></span>
            @endif
        </button>

        {{-- Dropdown : le wrapper porte le décalage en PADDING (pt-2) → pont de survol
             transparent qui comble le vide bouton↔panneau (sinon @mouseleave referme le menu). --}}
        <div
            x-show="open"
            x-transition:enter="transition ease-out duration-150"
            x-transition:enter-start="opacity-0 translate-y-1 scale-95"
            x-transition:enter-end="opacity-100 translate-y-0 scale-100"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100 translate-y-0 scale-100"
            x-transition:leave-end="opacity-0 translate-y-1 scale-95"
            class="absolute top-full {{ $loop->last ? 'right-0' : 'left-0' }} pt-2 z-50"
            style="display:none"
        >
          <div class="w-max min-w-[15rem] max-w-[19rem]
                      bg-white dark:bg-gray-900
                      border border-gray-100 dark:border-white/8
                      rounded-2xl shadow-xl dark:shadow-black/40
                      overflow-hidden py-2">
            @foreach ($item['subItems'] as $child)
            <a href="{{ $child['url'] ?? '#' }}" wire:navigate
               class="flex items-center gap-2.5 px-4 py-2.5
                      text-sm text-gray-700 dark:text-white/70
                      hover:text-[rgb(var(--mt-secondary))] hover:bg-gray-50 dark:hover:bg-white/4
                      transition-all duration-150 group/child">
                @if ($showIcons && !empty($child['icon']))
                <span class="w-6 h-6 rounded-lg bg-gray-100 dark:bg-white/6 flex items-center justify-center flex-shrink-0
                              group-hover/child:bg-[rgb(var(--mt-secondary))]/10 transition-colors">
                    <i class="{{ $child['icon'] }} text-[10px] text-gray-500 dark:text-white/40
                               group-hover/child:text-[rgb(var(--mt-secondary))] transition-colors"></i>
                </span>
                @endif
                {{-- libellé : prend l'espace dispo, sur une seule ligne (tronque si trop long) --}}
                <span class="flex-1 min-w-0 truncate">{{ $child['label'] }}</span>
                @if (!empty($child['count']) && $child['count'] > 0)
                <span class="flex-shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded-full
                              bg-[rgb(var(--mt-secondary))]/10 text-[rgb(var(--mt-secondary))]">
                    {{ $child['count'] }}
                </span>
                @endif
            </a>
            @endforeach

            {{-- Lien "Voir tout" --}}
            @if (!empty($item['url']) && $item['url'] !== '#')
            <div class="border-t border-gray-100 dark:border-white/6 mt-1 pt-1 px-2">
                <a href="{{ $item['url'] }}" wire:navigate
                   class="flex items-center justify-between px-3 py-2 text-xs font-semibold
                          text-[rgb(var(--mt-secondary))] hover:bg-[rgb(var(--mt-secondary))]/8
                          rounded-xl transition-all">
                    Voir tout {{ $item['label'] }}
                    <i class="fa-solid fa-arrow-right text-[9px]"></i>
                </a>
            </div>
            @endif

          </div>
        </div>
    </div>

    @else

    {{-- Item simple --}}
    <a href="{{ $item['url'] ?? '#' }}" wire:navigate
       class="relative flex items-center gap-1.5 {{ $itemClass }} font-medium rounded-lg
              {{ $textColor }} {{ $hoverBg }} transition-all duration-150
              {{ $item['is_active'] ? 'font-semibold text-[rgb(var(--mt-secondary))]' : '' }}">
        @if ($showIcons && $item['icon'])
        <i class="{{ $item['icon'] }} text-xs opacity-70"></i>
        @endif
        {{ $item['label'] }}
        @if ($item['is_active'])
        <span class="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-[2px]
                      bg-[rgb(var(--mt-secondary))] rounded-full"></span>
        @endif
    </a>

    @endif

    @endforeach

</nav>
