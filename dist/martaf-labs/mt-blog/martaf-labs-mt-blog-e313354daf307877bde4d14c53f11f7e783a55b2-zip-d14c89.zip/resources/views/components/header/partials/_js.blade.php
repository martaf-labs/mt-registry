{{--
  Partial : _js.blade.php
  Composant Alpine.js partagé + styles communs.
  Inclure une seule fois, en bas de chaque variant de header.
--}}

<script>
function headerComponent() {
    return {
        scrolled:          false,
        mobileOpen:        false,
        searchMobileOpen:  false,
        searchQuery:       '',
        dark: localStorage.getItem('mt-theme') === 'dark' ||
              (!localStorage.getItem('mt-theme') && window.matchMedia('(prefers-color-scheme: dark)').matches),

        init() {
            // Scroll
            window.addEventListener('scroll', () => {
                this.scrolled = window.scrollY > 20;
            }, { passive: true });

            // Bloquer scroll body quand mobile menu ouvert
            this.$watch('mobileOpen', v => {
                document.body.style.overflow = v ? 'hidden' : '';
            });

            // Dark mode
            // this.$watch('dark', v => {
            //     document.documentElement.classList.toggle('dark', v);
            //     localStorage.setItem('mt-theme', v ? 'dark' : 'light');
            // });
            // document.documentElement.classList.toggle('dark', this.dark);

            // Raccourci "/" → focus recherche
            document.addEventListener('keydown', e => {
                if (
                    e.key === '/' &&
                    !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName) &&
                    !e.metaKey && !e.ctrlKey
                ) {
                    e.preventDefault();
                    // Dispatcher un événement custom pour ouvrir la recherche
                    document.dispatchEvent(new CustomEvent('open-search'));
                }
            });

            // Date topbar
            const dateEl = document.getElementById('header-topbar-date');
            if (dateEl) {
                dateEl.textContent = new Date().toLocaleDateString('fr-FR', {
                    weekday: 'long',
                    day:     'numeric',
                    month:   'long',
                });
            }
        }
    }
}
</script>
