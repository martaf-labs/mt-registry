{{--
╔══════════════════════════════════════════════════════════════════╗
║  HEADER VARIANT : immersive                                      ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Pas de topbar                                               ║
║    → Header TRANSPARENT au-dessus du hero (texte blanc)          ║
║    → Devient solide (mt-bg) + ombre dès le scroll                ║
║    → Logo + nav centre + search + auth compact                   ║
║    → Breaking ticker en bas                                      ║
║  Usage : lifestyle, voyage, magazine photo                       ║
╚══════════════════════════════════════════════════════════════════╝
--}}


<header
    x-data="headerComponent()"
    x-init="init()"
    :class="scrolled
        ? 'mt-bg border-gray-200/60 dark:border-white/5 shadow-sm'
        : 'bg-transparent border-transparent'"
    class="fixed top-0 left-0 right-0 z-40 transition-all duration-500">

    <div class="px-4 lg:px-8 mx-auto max-w-full">
        <div class="flex items-center justify-between h-16 lg:h-20 gap-4">

            {{-- Logo (version claire sur fond sombre, adaptée au scroll) --}}
            <a href="{{ mt_get_route('home') }}" wire:navigate class="flex flex-shrink-0 flex-nowrap items-center group">
                <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                     class="h-8 lg:h-10 w-auto object-contain transition-all duration-300 group-hover:scale-105"
                     {{-- :class="scrolled
                         ? 'dark:brightness-0 dark:invert'
                         : 'brightness-0 invert'" --}}
                    >

                    <span class="ml-2 font-bold mt-text-pimary uppercase">{{ config('app.name') }}</span>
            </a>
            {{-- Nav desktop --}}
            @include('mtblog::components.header.partials._nav-desktop', [
                'menuItems'  => $menuItems,
                'showHome'   => false,
                'textColor'  => 'mt-text',
                'hoverBg'    => 'hover:bg-white/10',
            ])
            {{-- Version scrollée (classes normales) --}}
            {{-- Astuce : on bascule via x-bind:class sur le nav wrapper --}}

            {{-- Droite --}}
            <div class="flex items-center gap-2 flex-shrink-0">
                @include('mtblog::components.header.partials._search-bar', ['theme' => mt_has_dark_mode() ? 'dark' : 'light'])
                @include('mtblog::components.header.partials._auth-buttons', [
                    'theme'   => mt_has_dark_mode() ? 'dark' : 'light',
                    'compact' => true,
                ])
                <button @click="mobileOpen = true"
                        class="lg:hidden w-9 h-9 flex items-center justify-center rounded-xl mt-bg-secondary-light mt-text  transition-colors">
                    <i class="fa-solid fa-bars text-sm"></i>
                </button>
            </div>
        </div>
    </div>

    @include('mtblog::components.header.partials._nav-mobile', [
        'menuItems' => $menuItems,
        'isHome'    => mtblog_is_home(),
    ])
</header>

{{-- Breaking ticker (sous le hero, position normale dans le flux) --}}
<div class="mt-16 lg:mt-20">
    @include('mtblog::components.header.partials._breaking-ticker')
</div>

@include('mtblog::components.header.partials._js')
