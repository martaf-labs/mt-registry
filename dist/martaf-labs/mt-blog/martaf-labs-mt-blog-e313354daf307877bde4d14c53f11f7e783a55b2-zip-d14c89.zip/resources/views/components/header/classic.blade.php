{{--
╔══════════════════════════════════════════════════════════════════╗
║  HEADER VARIANT : classic                                        ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Topbar noire (date, météo, liens)                           ║
║    → Ligne principale : logo | nav | search + auth               ║
║    → Breaking news ticker en bas                                 ║
║  Usage : blog généraliste, actualité, news                       ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.header.partials._topbar', [
    'theme' => 'dark',
    'city'  => config('mtblog.header.city'),
    'temp'  => config('mtblog.header.temp'),
])

<header
    x-data="headerComponent()"
    x-init="init()"
    :class="scrolled ? 'shadow-sm' : 'shadow-none'"
    class="sticky top-0 z-40 mt-bg border-b border-gray-200/60 dark:border-white/5 transition-shadow duration-300">

    <div class="px-4 lg:px-8 mx-auto max-w-full">
        <div class="flex items-center justify-between h-16 lg:h-[72px] gap-4">

            {{-- Logo --}}
            <a href="{{ mt_get_route('home') }}" wire:navigate class="flex-shrink-0 group">
                <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                     class="h-8 lg:h-10 w-auto object-contain transition-transform duration-300
                            group-hover:scale-105 dark:brightness-0 dark:invert">
            </a>

            {{-- Nav desktop --}}
            @include('mtblog::components.header.partials._nav-desktop', [
                'menuItems'  => $menuItems,
                'showHome'   => false,
            ])

            {{-- Droite --}}
            <div class="flex items-center gap-2 flex-shrink-0">
                @include('mtblog::components.header.partials._search-bar', ['theme' => 'light'])
                @include('mtblog::components.header.partials._auth-buttons', ['theme' => 'light'])
                <button @click="mobileOpen = true"
                        class="lg:hidden w-9 h-9 flex items-center justify-center rounded-xl
                               bg-gray-100 dark:bg-white/6 text-gray-600 dark:text-white/50
                               hover:bg-gray-200 dark:hover:bg-white/10 transition-colors">
                    <i class="fa-solid fa-bars text-sm"></i>
                </button>
            </div>
        </div>
    </div>

    @include('mtblog::components.header.partials._nav-mobile', [
        'menuItems' => $menuItems,
        'isHome'    => mtblog_is_home(),
    ])
</header>

@include('mtblog::components.header.partials._breaking-ticker')
@include('mtblog::components.header.partials._js')
