{{--
  Partial : _breaking-ticker.blade.php
  Bandeau breaking news défilant.
  Données : $breakingNews
--}}

@if (mtblog_option_header('breaking_news') && $breakingNews->isNotEmpty())
<div class="relative overflow-hidden py-2.5
             bg-gradient-to-r from-[rgb(var(--mt-secondary))] to-[rgb(var(--mt-secondary))]/85
             text-white">

    <div class="flex items-center gap-4 px-4 lg:px-8 mx-auto max-w-full">

        {{-- Badge --}}
        <span class="flex-shrink-0 inline-flex items-center gap-1.5
                      bg-white/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <i class="fa-solid fa-bolt text-yellow-300 text-[8px]"></i>
            Flash info
        </span>

        {{-- Défilement --}}
        <div class="flex-1 overflow-hidden">
            <div class="inline-flex items-center gap-10 whitespace-nowrap animate-marquee
                         hover:[animation-play-state:paused]">
                @foreach ([$breakingNews, $breakingNews] as $group)
                @foreach ($group as $news)
                <a href="{{ mt_get_route('home_articles_show', ['slug' => $news->slug, 'id' => $news->id]) }}"
                   wire:navigate
                   class="flex items-center gap-2 text-sm font-medium
                          text-white hover:text-yellow-200 transition-colors">
                    <i class="{{ $news->category?->icon ?? 'fa-solid fa-circle' }} text-[10px] opacity-60"></i>
                    {!! $news->title !!}
                </a>
                @endforeach
                @endforeach
            </div>
        </div>

    </div>
</div>

<style>
@keyframes marquee {
    0%   { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}
.animate-marquee {
    animation: marquee 35s linear infinite;
}
</style>

@endif
