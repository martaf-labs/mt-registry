{{--
╔══════════════════════════════════════════════════════════════════╗
║  FOOTER VARIANT : classic                                        ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Bloc newsletter pleine largeur                              ║
║    → 4 colonnes : logo+desc | catégories | récents | liens       ║
║    → Barre légale                                                ║
║  Usage : blog généraliste, news, actualité                       ║
╚══════════════════════════════════════════════════════════════════╝
--}}

{{-- @include('mtblog::components.footer.partials._footer-data') --}}

<footer class="mt-10 border-t border-gray-100 dark:border-white/6 mt-bg">

    {{-- ══ Newsletter (masquée si déjà abonné ; se masque aussi à l'inscription) ══ --}}
    @if (! mtblog_is_subscribed())
    <div x-data="{ gone: false }" x-show="!gone" @newsletter-subscribed.window="gone = true"
         class="border-b border-gray-100 dark:border-white/6">
        <div class="px-4 lg:px-8 py-6 mx-auto max-w-7xl">
            @include('mtblog::components.footer.partials._newsletter', ['theme' => 'light'])
        </div>
    </div>
    @endif

    {{-- ══ Colonnes ═════════════════════════════════════════════ --}}
    <div class="px-4 lg:px-8 py-10 mx-auto max-w-7xl">
        <div class="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">

            {{-- Col 1 : Logo + description + réseaux --}}
            <div class="sm:col-span-2 lg:col-span-1">
                <a href="{{ getRoute('home') }}" wire:navigate class="inline-block mb-4">
                    <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                         class="h-9 w-auto object-contain dark:brightness-0 dark:invert">
                </a>
                <p class="text-sm text-gray-500 dark:text-white/40 leading-relaxed mb-5">
                    {{ config('mtblog.meta.description', "Votre source d'information indépendante et fiable.") }}
                </p>
                @include('mtblog::components.footer.partials._social-links', [
                    'style' => 'pills',
                    'theme' => 'light',
                ])
            </div>

            {{-- Col 2 : Rubriques --}}
            <div>
                <h4 class="text-sm font-bold text-gray-900 dark:text-white mb-4 uppercase tracking-wider">
                    Rubriques
                </h4>
                <ul class="divide-y divide-gray-100 dark:divide-white/6">
                    @foreach ($footerCategoryLatest as $row)
                    @php $cat = $row['category']; @endphp
                    <li>
                        <a href="{{ getRoute('home_categories_show', ['slug' => $cat->slug]) }}" wire:navigate
                           class="flex items-center gap-2 py-2.5 text-[13px]
                                  text-gray-500 dark:text-white/40
                                  hover:text-[rgb(var(--mt-secondary))] transition-colors group">
                            @if ($cat->icon)
                            <i class="{{ $cat->icon }} text-xs opacity-60 group-hover:opacity-100 transition-opacity"></i>
                            @endif
                            {{ $cat->name }}
                        </a>
                    </li>
                    @endforeach
                </ul>
            </div>

            {{-- Col 3 : Articles récents --}}
            <div>
                <h4 class="text-sm font-bold text-gray-900 dark:text-white mb-4 uppercase tracking-wider">
                    Récents
                </h4>
                <ul class="divide-y divide-gray-100 dark:divide-white/6">
                    @foreach ($footerCategoryLatest as $row)
                    @php $article = $row['article']; @endphp
                    <li>
                        <a href="{{ getRoute('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]) }}"
                           wire:navigate
                           class="group block py-2.5 text-[13px] text-gray-600 dark:text-white/55 truncate
                                  hover:text-[rgb(var(--mt-secondary))] transition-colors">
                            {!! $article->title !!}
                        </a>
                    </li>
                    @endforeach
                </ul>
            </div>

            {{-- Col 4 : Liens + app --}}
            <div>
                <h4 class="text-sm font-bold text-gray-900 dark:text-white mb-4 uppercase tracking-wider">
                    Informations
                </h4>
                <ul class="space-y-2.5 mb-6">
                    @foreach ($legalLinks as $link)
                    <li>
                        <a href="{{ $link['url'] }}" wire:navigate
                           class="text-sm text-gray-500 dark:text-white/40
                                  hover:text-[rgb(var(--mt-secondary))] transition-colors">
                            {{ $link['label'] }}
                        </a>
                    </li>
                    @endforeach
                </ul>

                {{-- App stores (optionnel) --}}
                @if (config('mtblog.apps.android') || config('mtblog.apps.ios'))
                <h5 class="text-xs font-semibold text-gray-400 dark:text-white/30 uppercase tracking-wider mb-2">
                    Application
                </h5>
                <div class="flex flex-col gap-2">
                    @if (config('mtblog.apps.android'))
                    <a href="{{ config('mtblog.apps.android') }}" target="_blank" rel="noopener noreferrer"
                       class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium
                              border border-gray-200 dark:border-white/10 text-gray-600 dark:text-white/50
                              hover:border-[rgb(var(--mt-secondary))]/40 hover:text-[rgb(var(--mt-secondary))] transition-all">
                        <i class="fa-brands fa-google-play text-green-500"></i>
                        Google Play
                    </a>
                    @endif
                    @if (config('mtblog.apps.ios'))
                    <a href="{{ config('mtblog.apps.ios') }}" target="_blank" rel="noopener noreferrer"
                       class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium
                              border border-gray-200 dark:border-white/10 text-gray-600 dark:text-white/50
                              hover:border-[rgb(var(--mt-secondary))]/40 hover:text-[rgb(var(--mt-secondary))] transition-all">
                        <i class="fa-brands fa-apple text-gray-700 dark:text-white/60"></i>
                        App Store
                    </a>
                    @endif
                </div>
                @endif
            </div>

        </div>
    </div>

    {{-- ══ Tags populaires ══════════════════════════════════════ --}}
    @if ($footerTags->isNotEmpty())
    <div class="border-t border-gray-100 dark:border-white/6">
        <div class="px-4 lg:px-8 py-5 mx-auto max-w-7xl">
            <div class="flex flex-wrap gap-2 items-center">
                <span class="text-xs font-semibold uppercase tracking-wider text-gray-400 dark:text-white/30 mr-1">
                    Tags
                </span>
                @foreach ($footerTags as $tag)
                <a href="{{ $tag->url ?? '#' }}" wire:navigate
                   class="px-3 py-1 text-xs rounded-full transition-all duration-150
                          bg-gray-100 dark:bg-white/6 text-gray-600 dark:text-white/50
                          hover:bg-[rgb(var(--mt-secondary))] hover:text-white dark:hover:bg-[rgb(var(--mt-secondary))]">
                    #{{ $tag->name }}
                </a>
                @endforeach
            </div>
        </div>
    </div>
    @endif

    {{-- ══ Barre légale ══════════════════════════════════════════ --}}
    <div class="border-t border-gray-100 dark:border-white/6">
        <div class="px-4 lg:px-8 py-4 mx-auto max-w-7xl">
            @include('mtblog::components.footer.partials._legal-bar', ['theme' => 'light'])
        </div>
    </div>

</footer>

@include('mtblog::components.footer.partials._back-to-top')
