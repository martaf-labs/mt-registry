{{--
  Partial : _social-links.blade.php
  Icônes réseaux sociaux.
  Props :
    $style   'pills' | 'icons' | 'colored'  (défaut: 'pills')
    $theme   'dark'  | 'light'              (défaut: 'dark')
    $size    'sm'    | 'md'                 (défaut: 'md')
  Données : $socialLinks, $socialIcons
--}}

@props([
    'style' => 'pills',
    'theme' => 'dark',
    'size'  => 'md',
])

@if (!empty($socialLinks))

@php
    $isDark = $theme === 'dark';
    $isSm   = $size === 'sm';
    $iconSz = $isSm ? 'text-[11px]' : 'text-sm';
    $btnSz  = $isSm ? 'w-7 h-7'     : 'w-9 h-9';
@endphp

<div class="flex flex-wrap items-center gap-2">
    @foreach ($socialLinks as $network => $url)
    @php $info = $socialIcons[$network] ?? ['icon' => 'fa-solid fa-link', 'color' => '#666', 'bg' => '#eee']; @endphp

    <a href="{{ $url }}"
       target="_blank"
       rel="noopener noreferrer"
       title="{{ ucfirst($network) }}"
       class="flex-shrink-0 flex items-center justify-center rounded-xl
              transition-all duration-200 group/social
              {{ $btnSz }}
              @if ($style === 'colored')
                  hover:scale-110 hover:-translate-y-0.5
              @elseif ($style === 'icons')
                  {{ $isDark
                      ? 'text-white/40 hover:text-white'
                      : 'text-gray-400 dark:text-white/30 hover:text-gray-700 dark:hover:text-white' }}
              @else
                  {{ $isDark
                      ? 'bg-white/8 hover:bg-white/16 text-white/60 hover:text-white'
                      : 'bg-gray-100 dark:bg-white/6 hover:bg-gray-200 dark:hover:bg-white/10 text-gray-500 dark:text-white/40 hover:text-gray-800 dark:hover:text-white' }}
              @endif">

        @if ($style === 'colored')
        {{-- Fond coloré du réseau --}}
        <span class="flex items-center justify-center {{ $btnSz }} rounded-xl"
              style="background: {{ $info['bg'] }}">
            <i class="{{ $info['icon'] }} {{ $iconSz }}" style="color: {{ $info['color'] }}"></i>
        </span>
        @else
        <i class="{{ $info['icon'] }} {{ $iconSz }}"></i>
        @endif
    </a>
    @endforeach
</div>

@endif
