{{--
  Partial : _back-to-top.blade.php
  Bouton "Retour en haut" flottant.
  Apparaît après 400px de scroll.
--}}

<div
    x-data="{ show: false }"
    @scroll.window="show = window.scrollY > 400"
    x-show="show"
    x-transition:enter="transition ease-out duration-200"
    x-transition:enter-start="opacity-0 translate-y-4"
    x-transition:enter-end="opacity-100 translate-y-0"
    x-transition:leave="transition ease-in duration-150"
    x-transition:leave-start="opacity-100 translate-y-0"
    x-transition:leave-end="opacity-0 translate-y-4"
    class="fixed bottom-6 left-6 z-50"
    style="display:none">

    <button
        @click="window.scrollTo({ top: 0, behavior: 'smooth' })"
        class="flex items-center justify-center w-10 h-10 rounded-2xl
               bg-[rgb(var(--mt-secondary))] text-white shadow-lg
               shadow-[rgb(var(--mt-secondary))]/30
               hover:scale-110 hover:-translate-y-0.5
               transition-all duration-200"
        title="Retour en haut">
        <i class="fa-solid fa-arrow-up text-sm"></i>
    </button>

</div>
