{{--
╔══════════════════════════════════════════════════════════════════╗
║  FOOTER VARIANT : editorial                                      ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Bande supérieure sombre : logo | slogan | réseaux          ║
║    → Corps clair : 4 colonnes de liens                           ║
║    → Newsletter sobre                                            ║
║    → Barre légale                                                ║
║  Usage : presse sérieuse, revue, analyse, corporate              ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.footer._footer-data')

<footer class="mt-10">

    {{-- ══ Bande supérieure sombre ══════════════════════════════ --}}
    <div class="bg-[rgb(var(--mt-primary))] dark:bg-gray-950 text-white">
        <div class="px-4 lg:px-8 py-8 mx-auto max-w-7xl">
            <div class="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">

                {{-- Logo + slogan --}}
                <div>
                    <a href="{{ getRoute('home') }}" wire:navigate class="inline-block mb-3">
                        <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                             class="h-10 w-auto object-contain brightness-0 invert">
                    </a>
                    @if (config('mtblog.header.tagline'))
                    <p class="text-sm text-white/40 font-medium italic">
                        "{{ config('mtblog.header.tagline') }}"
                    </p>
                    @endif
                </div>

                {{-- Réseaux + abonnement --}}
                <div class="flex flex-col gap-4">
                    <div class="flex items-center gap-3">
                        <span class="text-xs text-white/30 uppercase tracking-widest flex-shrink-0">Suivre</span>
                        @include('mtblog::components.footer._social-links', [
                            'style' => 'pills',
                            'theme' => 'dark',
                            'size'  => 'sm',
                        ])
                    </div>
                    <a href="{{ route('register') ?? '#' }}"
                       class="self-start flex items-center gap-2 px-4 py-2.5 text-sm font-bold
                              bg-[rgb(var(--mt-secondary))] text-white rounded-xl
                              hover:opacity-90 transition-opacity">
                        <i class="fa-solid fa-bolt text-xs"></i>
                        S'abonner à la newsletter
                    </a>
                </div>

            </div>
        </div>
    </div>

    {{-- ══ Corps clair ════════════════════════════════════════════ --}}
    <div class="mt-bg border-t border-gray-100 dark:border-white/6">
        <div class="px-4 lg:px-8 py-10 mx-auto max-w-7xl">
            <div class="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">

                {{-- Rubriques --}}
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-widest
                                text-gray-400 dark:text-white/30 mb-4 flex items-center gap-2">
                        <span class="w-3 h-[2px] bg-[rgb(var(--mt-secondary))] rounded-full"></span>
                        Rubriques
                    </h4>
                    <ul class="space-y-2">
                        @foreach ($footerCategories->take(8) as $cat)
                        <li>
                            <a href="{{ getRoute('home_categories_show', ['slug' => $cat->slug]) }}" wire:navigate
                               class="text-sm text-gray-600 dark:text-white/50
                                      hover:text-[rgb(var(--mt-secondary))] hover:pl-1
                                      transition-all duration-150 block">
                                {{ $cat->name }}
                            </a>
                        </li>
                        @endforeach
                    </ul>
                </div>

                {{-- Derniers articles --}}
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-widest
                                text-gray-400 dark:text-white/30 mb-4 flex items-center gap-2">
                        <span class="w-3 h-[2px] bg-[rgb(var(--mt-secondary))] rounded-full"></span>
                        Derniers articles
                    </h4>
                    <ul class="space-y-3">
                        @foreach ($footerRecentArticles as $article)
                        <li>
                            <a href="{{ getRoute('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]) }}"
                               wire:navigate
                               class="group block">
                                <span class="text-[10px] text-[rgb(var(--mt-secondary))] font-semibold uppercase tracking-wide block mb-0.5">
                                    {{ $article->publishedDate }}
                                </span>
                                <span class="text-sm text-gray-600 dark:text-white/50 leading-snug line-clamp-2
                                              group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                    {!! $article->title !!}
                                </span>
                            </a>
                        </li>
                        @endforeach
                    </ul>
                </div>

                {{-- Informations légales --}}
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-widest
                                text-gray-400 dark:text-white/30 mb-4 flex items-center gap-2">
                        <span class="w-3 h-[2px] bg-[rgb(var(--mt-secondary))] rounded-full"></span>
                        Informations
                    </h4>
                    <ul class="space-y-2">
                        @foreach ($legalLinks as $link)
                        <li>
                            <a href="{{ $link['url'] }}" wire:navigate
                               class="text-sm text-gray-600 dark:text-white/50
                                      hover:text-[rgb(var(--mt-secondary))] hover:pl-1
                                      transition-all duration-150 block">
                                {{ $link['label'] }}
                            </a>
                        </li>
                        @endforeach
                    </ul>
                </div>

                {{-- Newsletter compacte --}}
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-widest
                                text-gray-400 dark:text-white/30 mb-4 flex items-center gap-2">
                        <span class="w-3 h-[2px] bg-[rgb(var(--mt-secondary))] rounded-full"></span>
                        Newsletter
                    </h4>
                    @include('mtblog::components.footer._newsletter', [
                        'theme'   => 'light',
                        'compact' => true,
                    ])
                </div>

            </div>
        </div>
    </div>

    {{-- ══ Tags ══════════════════════════════════════════════════ --}}
    @if ($footerTags->isNotEmpty())
    <div class="border-t border-gray-100 dark:border-white/6 mt-bg">
        <div class="px-4 lg:px-8 py-4 mx-auto max-w-7xl flex flex-wrap gap-2">
            <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-white/30 self-center mr-1">
                Tags
            </span>
            @foreach ($footerTags as $tag)
            <a href="{{ $tag->url ?? '#' }}" wire:navigate
               class="px-2.5 py-0.5 text-xs rounded-full transition-all
                      bg-gray-100 dark:bg-white/6 text-gray-500 dark:text-white/40
                      hover:bg-[rgb(var(--mt-secondary))] hover:text-white">
                #{{ $tag->name }}
            </a>
            @endforeach
        </div>
    </div>
    @endif

    {{-- ══ Barre légale ══════════════════════════════════════════ --}}
    <div class="border-t border-gray-100 dark:border-white/6 mt-bg">
        <div class="px-4 lg:px-8 py-4 mx-auto max-w-7xl">
            @include('mtblog::components.footer._legal-bar', ['theme' => 'light'])
        </div>
    </div>

</footer>

@include('mtblog::components.footer._back-to-top')
