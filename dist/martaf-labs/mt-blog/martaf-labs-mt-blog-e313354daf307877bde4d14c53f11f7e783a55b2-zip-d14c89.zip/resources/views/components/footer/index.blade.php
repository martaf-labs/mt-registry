@php
    use Mt\Blog\Models\Article;
    use Mt\Blog\Models\Category;
    use Mt\Blog\Models\Tag;

    // ── Catégories principales (mis en cache 1h) ──────────────────
    $footerCategories = cache()->remember('blog.footer.categories', 3600, fn() =>
        Category::parents()
            ->where('is_active', true)
            ->withCount(['articles as articles_count' => fn($q) => $q->published()])
            ->having('articles_count', '>', 0)
            ->ordered()
            ->take(8)
            ->get()
    );

    // ── Articles récents (mis en cache 10 min) ────────────────────
    $footerRecentArticles = cache()->remember('blog.footer.recent', 600, fn() =>
        Article::published()
            ->with(['category'])
            ->latest('published_at')
            ->take(4)
            ->get()
    );

    // ── Dernier article par rubrique (aligné ligne-à-ligne avec la colonne Rubriques) ──
    $footerCategoryLatest = cache()->remember('blog.footer.cat_latest', 600, fn() =>
        $footerCategories->take(6)->map(fn($cat) => [
            'category' => $cat,
            'article'  => Article::published()
                ->whereIn('category_id', $cat->getAllChildrenIds())
                ->latest('published_at')
                ->first(),
        ])->filter(fn($r) => $r['article'])->values()
    );

    // ── Tags populaires (mis en cache 1h) ─────────────────────────
    $footerTags = cache()->remember('blog.footer.tags', 3600, fn() =>
        Tag::popular(16)->get()
    );

    // ── Réseaux sociaux (depuis config) ──────────────────────────
    $socialLinks = array_filter([
        'facebook'  => config('mtblog.social.facebook'),
        'twitter'   => config('mtblog.social.twitter'),
        'instagram' => config('mtblog.social.instagram'),
        'youtube'   => config('mtblog.social.youtube'),
        'linkedin'  => config('mtblog.social.linkedin'),
        'telegram'  => config('mtblog.social.telegram'),
        'tiktok'    => config('mtblog.social.tiktok'),
        'whatsapp'  => config('mtblog.social.whatsapp'),
    ]);

    $socialIcons = [
        'facebook'  => ['icon' => 'fa-brands fa-facebook-f',   'color' => '#1877F2', 'bg' => '#E7F0FD'],
        'twitter'   => ['icon' => 'fa-brands fa-x-twitter',    'color' => '#0F1419', 'bg' => '#F0F0F0'],
        'instagram' => ['icon' => 'fa-brands fa-instagram',    'color' => '#E1306C', 'bg' => '#FCE4EC'],
        'youtube'   => ['icon' => 'fa-brands fa-youtube',      'color' => '#FF0000', 'bg' => '#FFEBEE'],
        'linkedin'  => ['icon' => 'fa-brands fa-linkedin-in',  'color' => '#0A66C2', 'bg' => '#E8F0F9'],
        'telegram'  => ['icon' => 'fa-brands fa-telegram',     'color' => '#2AABEE', 'bg' => '#E8F5FC'],
        'tiktok'    => ['icon' => 'fa-brands fa-tiktok',       'color' => '#010101', 'bg' => '#F0F0F0'],
        'whatsapp'  => ['icon' => 'fa-brands fa-whatsapp',     'color' => '#25D366', 'bg' => '#E8F9EE'],
    ];

    // ── Liens légaux ─────────────────────────────────────────────
    $legalLinks = [
        ['label' => 'Mentions légales',        'url' => '#'],
        ['label' => 'Politique de données',    'url' => '#'],
        ['label' => 'Cookies',                 'url' => '#'],
        ['label' => 'CGU',                     'url' => '#'],
        ['label' => 'Contact',                 'url' => '#'],
    ];

    $currentYear = date('Y');
@endphp

{{-- inclusion du layout actif --}}
@include('mtblog::components.footer.'.mtblog_config('footer.layout'))