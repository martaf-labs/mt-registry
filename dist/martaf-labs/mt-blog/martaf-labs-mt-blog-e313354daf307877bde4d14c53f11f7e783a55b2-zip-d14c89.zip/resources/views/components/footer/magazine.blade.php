{{--
╔══════════════════════════════════════════════════════════════════╗
║  FOOTER VARIANT : magazine                                       ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → CTA newsletter grand format avec image de fond              ║
║    → 5 colonnes : logo | rubriques | récents | tags | réseaux   ║
║    → Barre légale sombre                                         ║
║  Usage : magazine lifestyle, culture, sport, gastronomie         ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.footer._footer-data')

<footer class="mt-10">

    {{-- ══ CTA Newsletter grand format ════════════════════════════ --}}
    <div class="relative overflow-hidden bg-[rgb(var(--mt-primary))] dark:bg-gray-950">

        {{-- Déco géométrique --}}
        <div class="absolute inset-0 pointer-events-none overflow-hidden">
            <div class="absolute -top-24 -right-24 w-96 h-96 rounded-full
                         bg-[rgb(var(--mt-secondary))]/10 blur-3xl"></div>
            <div class="absolute -bottom-12 -left-12 w-64 h-64 rounded-full
                         bg-[rgb(var(--mt-secondary))]/8 blur-2xl"></div>
            {{-- Grille déco --}}
            <div class="absolute inset-0 opacity-[0.03]"
                 style="background-image: linear-gradient(rgba(255,255,255,.5) 1px, transparent 1px),
                                          linear-gradient(90deg, rgba(255,255,255,.5) 1px, transparent 1px);
                        background-size: 40px 40px;">
            </div>
        </div>

        <div class="relative px-4 lg:px-8 py-16 mx-auto max-w-7xl">
            <div class="max-w-2xl mx-auto text-center">

                {{-- Eyebrow --}}
                <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full
                              bg-[rgb(var(--mt-secondary))]/15 text-[rgb(var(--mt-secondary))]
                              text-[11px] font-bold uppercase tracking-widest mb-4">
                    <i class="fa-solid fa-envelope text-[9px]"></i>
                    Newsletter
                </span>

                <h3 class="text-2xl lg:text-4xl font-black text-white leading-tight mb-3">
                    Ne manquez rien de l'actualité
                </h3>
                <p class="text-white/50 text-sm lg:text-base mb-8 max-w-md mx-auto">
                    Rejoignez {{ number_format(config('mtblog.newsletter.subscribers', 0), 0, ',', ' ') > 0
                        ? number_format(config('mtblog.newsletter.subscribers', 0), 0, ',', ' ') . ' abonnés et recevez'
                        : 'notre communauté et recevez' }}
                    les meilleures infos chaque matin.
                </p>

                {{-- Formulaire newsletter centré --}}
                <div x-data="{
                    email: '',
                    loading: false,
                    success: false,
                    error: '',
                    async submit() {
                        if (!this.email || !this.email.includes('@')) { this.error = 'Email invalide.'; return; }
                        this.loading = true; this.error = '';
                        try { await $wire.subscribeNewsletter(this.email); this.success = true; this.email = ''; }
                        catch(e) { this.error = 'Erreur, réessayez.'; }
                        finally { this.loading = false; }
                    }
                }">
                    <template x-if="success">
                        <div class="inline-flex items-center gap-2 px-6 py-3 rounded-2xl
                                     bg-green-500/15 text-green-400 font-medium text-sm">
                            <i class="fa-solid fa-circle-check"></i>
                            Bienvenue ! Vous êtes bien inscrit.
                        </div>
                    </template>
                    <template x-if="!success">
                        <div class="flex flex-col sm:flex-row items-center gap-3 max-w-md mx-auto">
                            <input
                                x-model="email"
                                @keydown.enter="submit()"
                                type="email"
                                placeholder="votre@email.com"
                                class="w-full px-4 py-3.5 text-sm rounded-xl border border-white/10
                                       bg-white/8 text-white placeholder-white/35
                                       focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/40
                                       focus:border-[rgb(var(--mt-secondary))]/50 transition-all"
                            />
                            <button
                                @click="submit()"
                                :disabled="loading"
                                class="flex-shrink-0 flex items-center gap-2 px-6 py-3.5 text-sm font-bold text-white
                                       bg-[rgb(var(--mt-secondary))] rounded-xl
                                       hover:opacity-90 disabled:opacity-50 transition-all whitespace-nowrap">
                                <i class="fa-solid fa-paper-plane text-xs" x-show="!loading"></i>
                                <i class="fa-solid fa-spinner fa-spin text-xs" x-show="loading" style="display:none"></i>
                                S'abonner
                            </button>
                        </div>
                    </template>
                    <p x-text="error" x-show="error" class="mt-2 text-xs text-red-400" style="display:none"></p>
                </div>

                {{-- Réseaux --}}
                <div class="flex items-center justify-center gap-4 mt-8">
                    <span class="text-xs text-white/25 uppercase tracking-widest">Nous suivre</span>
                    <div class="w-px h-3 bg-white/10"></div>
                    @include('mtblog::components.footer._social-links', [
                        'style' => 'pills',
                        'theme' => 'dark',
                        'size'  => 'sm',
                    ])
                </div>

            </div>
        </div>
    </div>

    {{-- ══ Colonnes infos ═══════════════════════════════════════ --}}
    <div class="mt-bg border-t border-gray-100 dark:border-white/6">
        <div class="px-4 lg:px-8 py-10 mx-auto max-w-7xl">
            <div class="grid gap-8 sm:grid-cols-2 lg:grid-cols-5">

                {{-- Logo + desc (2 colonnes) --}}
                <div class="sm:col-span-2">
                    <a href="{{ getRoute('home') }}" wire:navigate class="inline-block mb-4">
                        <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                             class="h-9 w-auto object-contain dark:brightness-0 dark:invert">
                    </a>
                    <p class="text-sm text-gray-500 dark:text-white/40 leading-relaxed">
                        {{ config('mtblog.meta.description', "Votre source d'information.") }}
                    </p>
                </div>

                {{-- Rubriques --}}
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-widest
                                text-gray-400 dark:text-white/30 mb-4">
                        Rubriques
                    </h4>
                    <ul class="space-y-2">
                        @foreach ($footerCategories->take(6) as $cat)
                        <li>
                            <a href="{{ getRoute('home_categories_show', ['slug' => $cat->slug]) }}" wire:navigate
                               class="text-sm text-gray-500 dark:text-white/40
                                      hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                {{ $cat->name }}
                            </a>
                        </li>
                        @endforeach
                    </ul>
                </div>

                {{-- Articles récents --}}
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-widest
                                text-gray-400 dark:text-white/30 mb-4">
                        Récents
                    </h4>
                    <ul class="space-y-3">
                        @foreach ($footerRecentArticles->take(3) as $article)
                        <li>
                            <a href="{{ getRoute('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]) }}"
                               wire:navigate
                               class="text-sm text-gray-500 dark:text-white/40 leading-snug line-clamp-2
                                      hover:text-[rgb(var(--mt-secondary))] transition-colors block group">
                                {!! $article->title !!}
                            </a>
                        </li>
                        @endforeach
                    </ul>
                </div>

                {{-- Liens légaux --}}
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-widest
                                text-gray-400 dark:text-white/30 mb-4">
                        Informations
                    </h4>
                    <ul class="space-y-2">
                        @foreach ($legalLinks as $link)
                        <li>
                            <a href="{{ $link['url'] }}" wire:navigate
                               class="text-sm text-gray-500 dark:text-white/40
                                      hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                {{ $link['label'] }}
                            </a>
                        </li>
                        @endforeach
                    </ul>
                </div>

            </div>
        </div>
    </div>

    {{-- ══ Barre légale sombre ════════════════════════════════════ --}}
    <div class="bg-[rgb(var(--mt-primary))] dark:bg-gray-950 border-t border-white/5">
        <div class="px-4 lg:px-8 py-4 mx-auto max-w-7xl">
            @include('mtblog::components.footer._legal-bar', ['theme' => 'dark'])
        </div>
    </div>

</footer>

@include('mtblog::components.footer._back-to-top')
