{{--
╔══════════════════════════════════════════════════════════════════╗
║  FOOTER VARIANT : immersive                                      ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Fond sombre total (bg-primary)                              ║
║    → Bloc newsletter centré avec accent coloré                   ║
║    → Grille 3 colonnes : catégories | logo centré | réseaux      ║
║    → Tags cloud                                                  ║
║    → Barre légale                                                ║
║  Usage : lifestyle, voyage, magazine photo, sport                ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.footer._footer-data')

<footer class="mt-10 bg-[rgb(var(--mt-primary))] dark:bg-gray-950 text-white">

    {{-- ══ Newsletter avec fond accent ════════════════════════════ --}}
    <div class="relative overflow-hidden border-b border-white/5">

        {{-- Déco --}}
        <div class="absolute inset-0 pointer-events-none">
            <div class="absolute w-72 h-72 rounded-full -top-20 -right-10
                         bg-[rgb(var(--mt-secondary))]/10 blur-3xl"></div>
            <div class="absolute w-48 h-48 rounded-full bottom-0 left-10
                         bg-[rgb(var(--mt-secondary))]/5 blur-2xl"></div>
        </div>

        <div class="relative px-4 lg:px-8 py-10 mx-auto max-w-7xl">
            @include('mtblog::components.footer._newsletter', [
                'theme'   => 'dark',
                'compact' => false,
            ])
        </div>
    </div>

    {{-- ══ Contenu 3 colonnes ═══════════════════════════════════ --}}
    <div class="px-4 lg:px-8 py-12 mx-auto max-w-7xl">
        <div class="grid gap-10 sm:grid-cols-3">

            {{-- Catégories --}}
            <div>
                <h4 class="text-xs font-bold uppercase tracking-widest text-white/40 mb-5">
                    Rubriques
                </h4>
                <ul class="space-y-3">
                    @foreach ($footerCategories->take(8) as $cat)
                    <li>
                        <a href="{{ getRoute('home_categories_show', ['slug' => $cat->slug]) }}" wire:navigate
                           class="flex items-center gap-2.5 text-sm text-white/55
                                  hover:text-[rgb(var(--mt-secondary))] transition-colors group">
                            @if ($cat->icon)
                            <span class="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0
                                          bg-white/5 group-hover:bg-[rgb(var(--mt-secondary))]/15 transition-colors">
                                <i class="{{ $cat->icon }} text-[10px]"></i>
                            </span>
                            @endif
                            {{ $cat->name }}
                        </a>
                    </li>
                    @endforeach
                </ul>
            </div>

            {{-- Logo centré + description + réseaux --}}
            <div class="flex flex-col items-center text-center">
                <a href="{{ getRoute('home') }}" wire:navigate class="mb-5">
                    <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                         class="h-12 w-auto object-contain brightness-0 invert">
                </a>
                <p class="text-sm text-white/40 leading-relaxed mb-6 max-w-xs">
                    {{ config('mtblog.meta.description', "Votre source d'information indépendante.") }}
                </p>
                <div class="flex justify-center">
                    @include('mtblog::components.footer._social-links', [
                        'style' => 'pills',
                        'theme' => 'dark',
                    ])
                </div>
            </div>

            {{-- Articles récents --}}
            <div>
                <h4 class="text-xs font-bold uppercase tracking-widest text-white/40 mb-5">
                    Derniers articles
                </h4>
                <ul class="space-y-4">
                    @foreach ($footerRecentArticles as $article)
                    <li>
                        <a href="{{ getRoute('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]) }}"
                           wire:navigate class="group flex flex-col gap-1">
                            <span class="text-[11px] text-[rgb(var(--mt-secondary))] font-semibold uppercase tracking-wide">
                                {{ $article->publishedDate }}
                            </span>
                            <span class="text-sm text-white/55 leading-snug line-clamp-2
                                          group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                {!! $article->title !!}
                            </span>
                        </a>
                    </li>
                    @endforeach
                </ul>
            </div>

        </div>
    </div>

    {{-- ══ Tags ══════════════════════════════════════════════════ --}}
    @if ($footerTags->isNotEmpty())
    <div class="border-t border-white/5">
        <div class="px-4 lg:px-8 py-5 mx-auto max-w-7xl flex flex-wrap gap-2 items-center">
            <span class="text-[10px] font-semibold uppercase tracking-widest text-white/25 mr-1">Tags</span>
            @foreach ($footerTags as $tag)
            <a href="{{ $tag->url ?? '#' }}" wire:navigate
               class="px-2.5 py-1 text-[11px] rounded-full transition-all
                      bg-white/6 text-white/40 hover:bg-[rgb(var(--mt-secondary))] hover:text-white">
                #{{ $tag->name }}
            </a>
            @endforeach
        </div>
    </div>
    @endif

    {{-- ══ Barre légale ══════════════════════════════════════════ --}}
    <div class="border-t border-white/5">
        <div class="px-4 lg:px-8 py-4 mx-auto max-w-7xl">
            @include('mtblog::components.footer._legal-bar', ['theme' => 'dark'])
        </div>
    </div>

</footer>

@include('mtblog::components.footer._back-to-top')
