{{--
  Partial : _legal-bar.blade.php
  Barre de bas de page : copyright + liens légaux.
  Props :
    $theme   'dark' | 'light'  (défaut: 'dark')
  Données : $legalLinks, $currentYear
--}}

@props(['theme' => 'dark'])

@php $isDark = $theme === 'dark'; @endphp

<div class="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs
            {{ $isDark ? 'text-white/30' : 'text-gray-400 dark:text-white/30' }}">

    {{-- Copyright --}}
    <span>
        &copy; {{ $currentYear }} {{ config('app.name') }}.
        Tous droits réservés.
    </span>

    {{-- Liens légaux --}}
    <nav class="flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
        @foreach ($legalLinks as $link)
        <a href="{{ $link['url'] }}" wire:navigate
           class="hover:text-[rgb(var(--mt-secondary))] transition-colors duration-150">
            {{ $link['label'] }}
        </a>
        @endforeach
    </nav>

    {{-- Made with --}}
    <span class="flex items-center gap-1 flex-shrink-0">
        Fait avec
        <i class="fa-solid fa-heart text-[rgb(var(--mt-secondary))] text-[10px] animate-pulse"></i>
        par
        <a href="#" class="font-medium hover:text-[rgb(var(--mt-secondary))] transition-colors">
            {{ config('app.name') }}
        </a>
    </span>

</div>
