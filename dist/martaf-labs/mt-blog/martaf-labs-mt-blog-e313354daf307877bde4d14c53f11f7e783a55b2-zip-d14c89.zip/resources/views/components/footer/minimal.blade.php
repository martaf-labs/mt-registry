{{--
╔══════════════════════════════════════════════════════════════════╗
║  FOOTER VARIANT : minimal                                        ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Logo centré + description courte                            ║
║    → Réseaux sociaux centrés (colored)                           ║
║    → Liens catégories en ligne (horizontal)                      ║
║    → Barre légale sobre                                          ║
║  Usage : corporate, blog tech, newsletter, juridique             ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@include('mtblog::components.footer._footer-data')

<footer class="mt-10 border-t border-gray-100 dark:border-white/6 mt-bg">

    <div class="px-4 lg:px-8 py-12 mx-auto max-w-2xl text-center">

        {{-- Logo --}}
        <a href="{{ getRoute('home') }}" wire:navigate class="inline-block mb-4">
            <img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}"
                 class="h-8 w-auto object-contain mx-auto dark:brightness-0 dark:invert">
        </a>

        {{-- Description --}}
        <p class="text-sm text-gray-500 dark:text-white/40 leading-relaxed mb-6 max-w-md mx-auto">
            {{ config('mtblog.meta.description', "Votre source d'information indépendante et fiable.") }}
        </p>

        {{-- Réseaux --}}
        <div class="flex justify-center mb-8">
            @include('mtblog::components.footer._social-links', [
                'style' => 'colored',
                'theme' => 'light',
                'size'  => 'md',
            ])
        </div>

        {{-- Catégories en ligne --}}
        @if ($footerCategories->isNotEmpty())
        <nav class="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 mb-8">
            <a href="{{ getRoute('home') }}" wire:navigate
               class="text-sm text-gray-500 dark:text-white/40
                      hover:text-[rgb(var(--mt-secondary))] transition-colors font-medium">
                Accueil
            </a>
            @foreach ($footerCategories->take(6) as $cat)
            <a href="{{ getRoute('home_categories_show', ['slug' => $cat->slug]) }}" wire:navigate
               class="text-sm text-gray-500 dark:text-white/40
                      hover:text-[rgb(var(--mt-secondary))] transition-colors">
                {{ $cat->name }}
            </a>
            @endforeach
        </nav>
        @endif

        {{-- Newsletter minimale --}}
        <div class="max-w-sm mx-auto mb-8 p-5 rounded-2xl bg-gray-50 dark:bg-white/4 border border-gray-100 dark:border-white/6">
            @include('mtblog::components.footer._newsletter', [
                'theme'   => 'light',
                'compact' => true,
            ])
        </div>

    </div>

    {{-- Barre légale --}}
    <div class="border-t border-gray-100 dark:border-white/6">
        <div class="px-4 lg:px-8 py-4 mx-auto max-w-7xl">
            @include('mtblog::components.footer._legal-bar', ['theme' => 'light'])
        </div>
    </div>

</footer>

@include('mtblog::components.footer._back-to-top')
