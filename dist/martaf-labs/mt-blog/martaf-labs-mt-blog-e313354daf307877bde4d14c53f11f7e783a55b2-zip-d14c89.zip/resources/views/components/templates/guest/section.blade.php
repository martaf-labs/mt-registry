<section id="{{ $id }}" {{ $attributes->merge(['class' => 'my-12','style' => '']) }}>
    {{-- <h2 class="text-2xl font-bold text-[#0B1A33] mb-6 red-underline inline-block">{{ $title }}</h2> --}}
    <div class="flex items-center justify-between mb-5">
        @if ($title)
        <div class="flex items-center gap-3">
            <span class="w-1 h-6 rounded-full bg-mt-secondary"></span>
            <h2 class="text-lg font-bold tracking-wide text-gray-900 uppercase dark:text-white">{{ $title }}</h2>
            
            @if($badge)
            <span class="text-[11px] text-gray-400 dark:text-white/25 bg-gray-100 dark:bg-white/6 px-2 py-0.5 rounded-full font-medium">{{ $badge }}</span>
            @endif
        </div>            
        @endif
        
        @if ($actions)
        <a href="{{ mt_get_route('home') }}" class="flex items-center gap-1 text-xs font-medium text-gray-400 transition-colors dark:text-white/30 hover:text-mt-secondary dark:hover:text-mt-secondary">
            Voir plus <i class="fa-solid fa-arrow-right text-[10px]"></i>
        </a>            
        @endif
    </div>
    
    <div>
        {{ $slot }}
    </div>

</section>