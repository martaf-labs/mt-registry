{{--
╔══════════════════════════════════════════════════════════════════╗
║  COMPOSANT : card.blade.php                                      ║
║  Package   : mt (base blog)                                      ║
╠══════════════════════════════════════════════════════════════════╣
║  VARIANTS DISPONIBLES                                            ║
║  ─────────────────────────────────────────────────────────────  ║
║  • default    Card classique image + contenu. Grid / List.       ║
║  • magazine   Image pleine + overlay gradient. Immersif.         ║
║  • minimal    Typographie forte, petite vignette. Corporate.     ║
║  • spotlight  Grande image gauche, contenu détaillé à droite.   ║
║  • editorial  Numéro style presse + trait coloré. Analyse.      ║
║  • chip       Ultra-compact en ligne. Sidebar / widget.          ║
╠══════════════════════════════════════════════════════════════════╣
║  ÉLÉMENTS AFFICHABLES (props booléennes)                         ║
║  ─────────────────────────────────────────────────────────────  ║
║  • showImage      Affiche l'image / vignette              true   ║
║  • showCategory   Badge / label de catégorie              true   ║
║  • showDate       Date de publication                     true   ║
║  • showViews      Compteur de vues                        true   ║
║  • showExcerpt    Extrait du texte                        true   ║
║  • showReadMore   Lien "Lire la suite"                    false  ║
║  • showActions    Barre like / comments / share            true   ║
╠══════════════════════════════════════════════════════════════════╣
║  EXEMPLES D'UTILISATION                                          ║
║  ─────────────────────────────────────────────────────────────  ║
║  <x-card :article="$a" variant="magazine" />                     ║
║  <x-card :article="$a" variant="editorial"                       ║
║           :index="$loop->iteration" />                           ║
║  <x-card :article="$a" variant="chip" :show-actions="false" />   ║
║  <x-card :article="$a" variant="default" :show-excerpt="false"  ║
║           :show-read-more="true" />                              ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@props([
    'article'      => null,
    'url'          => null,
    'layout'       => 'grid',     // 'grid' | 'list'
    'variant'      => 'default',  // voir variants ci-dessus
    'index'        => null,       // pour le variant editorial (numérotation)
    'showImage'    => true,
    'showCategory' => false,
    'showDate'     => false,
    'showViews'    => false,
    'showExcerpt'  => mtblog_option_card('excerpt'),
    'showReadMore' => false,
    'showActions'  => false,   // barre like / comments / share
])

@if ($article)

@php
    $url    = mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]);
    $isList = $layout === 'list';

    //on force les variable de la configuration
    $showCategory   = mtblog_option_card('category');
    $showDate       = mtblog_option_card('date');
    $showViews      = mtblog_option_card('views');
    $showReadMore   = mtblog_option_card('read-more');
    $showActions    = mtblog_option_card('actions');

@endphp


{{-- ════════════════════════════════════════════════════════════
     VARIANT : default
     Card classique : image en haut (grid) ou à gauche (list),
     badge catégorie flottant, méta et contenu dessous.
     Usage : blog généraliste, news, multi-thématiques.
     ════════════════════════════════════════════════════════════ --}}
@if ($variant === 'default')

@php
    $containerClass = $isList ? 'flex flex-col sm:flex-row gap-0' : 'flex flex-col';
    $imageClass     = $isList ? 'sm:w-2/5 md:w-1/3 h-52 sm:h-auto flex-shrink-0' : 'w-full h-48';
@endphp

<article {{ $attributes->merge(['class' =>
    'group mt-bg rounded-2xl overflow-hidden' .
    'hover:-translate-y-0.5 transition-all duration-300 ' . $containerClass
]) }}>

    @if ($showImage)
    <a href="{{ $url }}" wire:navigate
       class="relative overflow-hidden bg-gray-100 dark:bg-white/4 block flex-shrink-0 {{ $imageClass }}">
        <x-mt::image-loader
            :src="$article->getVariantImage('medium')"
            :alt="$article->title"
            class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        @if ($showCategory)
        <span class="absolute top-3 left-3 mt-bg-secondary text-white text-[11px] font-semibold
                      uppercase tracking-wider px-2.5 py-1 rounded-full z-10 shadow-sm">
            {{ $article->categoryName }}
        </span>
        @endif
    </a>
    @endif

    <div class="flex flex-col flex-1 p-4">

        @if ($showCategory && ! $showImage)
        <span class="inline-block self-start mt-bg-secondary text-white text-[11px] font-semibold
                      uppercase tracking-wider px-2.5 py-1 rounded-full mb-3">
            {{ $article->categoryName }}
        </span>
        @endif

        @if ($showDate || $showViews)
        <div class="flex items-center gap-2 text-xs text-gray-400 dark:text-white/30 mb-2">
            @if ($showDate)  <span>{{ $article->publishedThere }}</span> @endif
            @if ($showDate && $showViews) <span>•</span> @endif
            @if ($showViews) <span>{{ $article->viewsCount(true) }}</span> @endif
        </div>
        @endif

        <h3 class="font-bold text-gray-900 dark:text-white text-[15px] leading-snug mb-2 line-clamp-2
                    group-hover:text-[rgb(var(--mt-secondary))] dark:group-hover:text-[rgb(var(--mt-secondary))]
                    transition-colors duration-200">
            <a href="{{ $url }}" wire:navigate>{!! $article->title !!}</a>
        </h3>

        @if ($showExcerpt)
        <p class="text-gray-500 dark:text-white/40 text-sm line-clamp-2 flex-1 mb-3">
            {{ $article->excerpt }}
        </p>
        @endif

        {{-- Footer : read more + actions --}}
        @if ($showReadMore || $showActions)
        <div class="mt-auto pt-3 border-t border-gray-100 dark:border-white/6
                     flex items-center justify-between gap-2">
            @if ($showReadMore)
            <a href="{{ $url }}" wire:navigate
               class="inline-flex items-center gap-1.5 text-[13px] font-semibold
                      text-[rgb(var(--mt-secondary))] hover:gap-3 transition-all duration-200">
                Lire la suite <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
            @else
            <div></div>
            @endif

            @if ($showActions)
            <x-mtblog::post.card.actions :article="$article" :url="$url" theme="light" size="md" />
            @endif
        </div>
        @endif

    </div>
</article>


{{-- ════════════════════════════════════════════════════════════
     VARIANT : magazine
     Image pleine hauteur, texte superposé via gradient sombre.
     Zoom subtil au hover. Actions en overlay bas à droite.
     Usage : lifestyle, voyage, photographie, actualité chaude.
     ════════════════════════════════════════════════════════════ --}}
@elseif ($variant === 'magazine')

@php
    $height = $isList ? 'h-56 sm:h-52' : 'h-64 md:h-72';
@endphp

<article {{ $attributes->merge(['class' =>
    'group relative overflow-hidden rounded-2xl cursor-pointer ' . $height
]) }}>

    @if ($showImage)
    <a href="{{ $url }}" wire:navigate class="absolute inset-0">
        <x-mt::image-loader
            :src="$article->getVariantImage('medium')"
            :alt="$article->title"
            class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
    </a>
    <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-black/5 pointer-events-none"></div>
    @else
    <div class="absolute inset-0 bg-gray-900 dark:bg-black/60"></div>
    @endif

    <div class="absolute bottom-0 left-0 right-0 p-4 sm:p-5 flex flex-col gap-2">

        @if ($showCategory)
        <span class="self-start mt-bg-secondary text-white text-[11px] font-semibold
                      uppercase tracking-wider px-2.5 py-0.5 rounded-full">
            {{ $article->categoryName }}
        </span>
        @endif

        <h3 class="font-bold text-white text-[15px] sm:text-base leading-snug line-clamp-2
                    group-hover:text-[rgb(var(--mt-secondary))] transition-colors duration-200"
            style="text-shadow: 0 1px 14px rgba(0,0,0,.6), 0 1px 3px rgba(0,0,0,.5);">
            <a href="{{ $url }}" wire:navigate>{!! $article->title !!}</a>
        </h3>

        @if ($showExcerpt)
        <div class="p-0 m-0 hidden sm:block">
            <p class="text-white/60 text-[13px] line-clamp-2">
                {{ $article->excerpt }}
            </p>
        </div>
        @endif

        {{-- Méta + actions sur la même ligne --}}
        <div class="flex items-center justify-between gap-2 flex-wrap mt-0.5">
            @if ($showDate || $showViews)
            <div class="flex items-center gap-2 text-[11px] text-white/45">
                @if ($showDate)  <span>{{ $article->publishedThere }}</span> @endif
                @if ($showDate && $showViews) <span>•</span> @endif
                @if ($showViews) <span>{{ $article->viewsCount(true) }}</span> @endif
            </div>
            @endif

            @if ($showActions)
            <x-mtblog::post.card.actions :article="$article" :url="$url" theme="dark" size="md" />
            @endif
        </div>

    </div>
</article>


{{-- ════════════════════════════════════════════════════════════
     VARIANT : minimal
     Accent typographique fort, ligne de séparation colorée.
     Actions en ligne avec les vues à droite du contenu.
     Usage : blog tech, juridique, corporate, newsletter.
     ════════════════════════════════════════════════════════════ --}}
@elseif ($variant === 'minimal')

<article {{ $attributes->merge(['class' =>
    'group mt-bg flex gap-4 py-4 border-b border-gray-100 dark:border-white/8 ' .
    'hover:border-[rgb(var(--mt-secondary))] transition-colors duration-200'
]) }}>

    <div class="flex-1 flex flex-col justify-between min-w-0 gap-1.5">

        @if ($showCategory || $showDate)
        <div class="flex items-center gap-2 text-[11px] font-medium">
            @if ($showCategory)
            <span class="text-[rgb(var(--mt-secondary))] uppercase tracking-widest font-semibold">
                {{ $article->categoryName }}
            </span>
            @endif
            @if ($showCategory && $showDate)
            <span class="text-gray-300 dark:text-white/20">—</span>
            @endif
            @if ($showDate)
            <span class="text-gray-400 dark:text-white/30">{{ $article->publishedThere }}</span>
            @endif
        </div>
        @endif

        <h3 class="font-semibold text-gray-900 dark:text-white text-[15px] leading-snug line-clamp-2
                    group-hover:text-[rgb(var(--mt-secondary))] transition-colors duration-200">
            <a href="{{ $url }}" wire:navigate>{!! $article->title !!}</a>
        </h3>

        @if ($showExcerpt)
        <p class="text-gray-500 dark:text-white/35 text-[13px] line-clamp-1">
            {{ $article->excerpt }}
        </p>
        @endif

        {{-- Footer : vues + read more + actions --}}
        <div class="flex items-center justify-between gap-2 mt-1 flex-wrap">
            <div class="flex items-center gap-3">
                @if ($showViews)
                <span class="text-xs text-gray-400 dark:text-white/25">{{ $article->viewsCount(true) }}</span>
                @endif
                @if ($showReadMore)
                <a href="{{ $url }}" wire:navigate
                   class="text-[12px] font-semibold text-[rgb(var(--mt-secondary))]
                          hover:underline underline-offset-2">
                    Lire &rarr;
                </a>
                @endif
            </div>

            @if ($showActions)
            <x-mtblog::post.card.actions :article="$article" :url="$url" theme="light" size="sm" />
            @endif
        </div>

    </div>

    @if ($showImage && ! $isList)
    <a href="{{ $url }}" wire:navigate
       class="flex-shrink-0 w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-gray-100 dark:bg-white/4">
        <x-mt::image-loader
            :src="$article->getVariantImage('small')"
            :alt="$article->title"
            class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
    </a>
    @endif

</article>


{{-- ════════════════════════════════════════════════════════════
     VARIANT : spotlight
     Grande image à gauche (40% desktop), contenu structuré
     à droite. Actions dans le footer du contenu.
     Usage : article mis en avant, hero, top story, featured.
     ════════════════════════════════════════════════════════════ --}}
@elseif ($variant === 'spotlight')

<article {{ $attributes->merge(['class' =>
    'group mt-bg rounded-2xl overflow-hidden border border-gray-100 dark:border-white/6 ' .
    'hover:shadow-lg transition-all duration-300 flex flex-col sm:flex-row'
]) }}>

    @if ($showImage)
    <a href="{{ $url }}" wire:navigate
       class="relative overflow-hidden bg-gray-100 dark:bg-white/4
              block w-full h-52 sm:h-auto sm:w-2/5 flex-shrink-0">
        <x-mt::image-loader
            :src="$article->getVariantImage('medium')"
            :alt="$article->title"
            class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        @if ($showCategory)
        <span class="absolute top-3 left-3 mt-bg-secondary text-white text-[11px] font-semibold
                      uppercase tracking-wider px-2.5 py-1 rounded-full z-10 shadow-sm">
            {{ $article->categoryName }}
        </span>
        @endif
    </a>
    @endif

    <div class="flex flex-col justify-between flex-1 p-5 sm:p-6">

        @if ($showCategory && ! $showImage)
        <span class="inline-block self-start mt-bg-secondary text-white text-[11px] font-semibold
                      uppercase tracking-wider px-2.5 py-1 rounded-full mb-3">
            {{ $article->categoryName }}
        </span>
        @endif

        <div class="flex-1">
            @if ($showDate || $showViews)
            <div class="flex items-center gap-2 text-xs text-gray-400 dark:text-white/30 mb-3">
                @if ($showDate)  <span>{{ $article->publishedThere }}</span> @endif
                @if ($showDate && $showViews) <span>•</span> @endif
                @if ($showViews) <span>{{ $article->viewsCount(true) }}</span> @endif
            </div>
            @endif

            <h3 class="font-bold text-gray-900 dark:text-white text-[17px] sm:text-lg leading-snug mb-3
                        group-hover:text-[rgb(var(--mt-secondary))] transition-colors duration-200 line-clamp-3">
                <a href="{{ $url }}" wire:navigate>{!! $article->title !!}</a>
            </h3>

            @if ($showExcerpt)
            <p class="text-gray-500 dark:text-white/40 text-sm line-clamp-3">
                {{ $article->excerpt }}
            </p>
            @endif
        </div>

        {{-- Footer --}}
        @if ($showReadMore || $showActions)
        <div class="mt-4 pt-4 border-t border-gray-100 dark:border-white/6
                     flex items-center justify-between gap-2">
            @if ($showReadMore)
            <a href="{{ $url }}" wire:navigate
               class="inline-flex items-center gap-2 text-[13px] font-semibold
                      text-[rgb(var(--mt-secondary))] hover:gap-3 transition-all duration-200">
                Lire l'article <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
            @else
            <div></div>
            @endif

            @if ($showActions)
            <x-mtblog::post.card.actions :article="$article" :url="$url" theme="light" size="md" />
            @endif
        </div>
        @endif

    </div>
</article>


{{-- ════════════════════════════════════════════════════════════
     VARIANT : editorial
     Numérotation style presse, barre colorée, vignette.
     Actions compactes à droite sous la vignette.
     Usage : blog de fond, revue, analyse, classement.
     ════════════════════════════════════════════════════════════ --}}
@elseif ($variant === 'editorial')

@php
    $indexLabel = $index ? str_pad($index, 2, '0', STR_PAD_LEFT) : null;
@endphp

<article {{ $attributes->merge(['class' =>
    'group mt-bg flex gap-3 sm:gap-4 py-4 sm:py-5 ' .
    'border-b border-gray-100 dark:border-white/8 ' .
    'hover:border-transparent transition-all duration-200'
]) }}>

    @if ($indexLabel)
    <div class="flex-shrink-0 w-9 sm:w-10 text-right pt-0.5">
        <span class="text-2xl sm:text-3xl font-black leading-none select-none tabular-nums
                      text-gray-100 dark:text-white/8
                      group-hover:text-[rgb(var(--mt-secondary))] transition-colors duration-300">
            {{ $indexLabel }}
        </span>
    </div>
    @endif

    <div class="flex-shrink-0 w-[3px] self-stretch rounded-full
                 bg-gray-100 dark:bg-white/8
                 group-hover:bg-[rgb(var(--mt-secondary))] transition-colors duration-300">
    </div>

    <div class="flex flex-1 gap-3 sm:gap-4 min-w-0">

        <div class="flex-1 flex flex-col gap-1.5 min-w-0">

            @if ($showCategory || $showDate)
            <div class="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px]">
                @if ($showCategory)
                <span class="text-[rgb(var(--mt-secondary))] font-bold uppercase tracking-widest">
                    {{ $article->categoryName }}
                </span>
                @endif
                @if ($showCategory && $showDate)
                <span class="text-gray-300 dark:text-white/15">/</span>
                @endif
                @if ($showDate)
                <span class="text-gray-400 dark:text-white/30">{{ $article->publishedThere }}</span>
                @endif
            </div>
            @endif

            <h3 class="font-bold text-gray-900 dark:text-white text-[15px] leading-snug line-clamp-2
                        group-hover:text-[rgb(var(--mt-secondary))] transition-colors duration-200">
                <a href="{{ $url }}" wire:navigate>{!! $article->title !!}</a>
            </h3>

            @if ($showExcerpt)
            <p class="text-gray-500 dark:text-white/35 text-[13px] line-clamp-1 sm:line-clamp-2">
                {{ $article->excerpt }}
            </p>
            @endif

            <div class="flex items-center justify-between gap-2 mt-0.5 flex-wrap">
                <div class="flex items-center gap-3">
                    @if ($showViews)
                    <span class="text-xs text-gray-400 dark:text-white/25">{{ $article->viewsCount(true) }}</span>
                    @endif
                    @if ($showReadMore)
                    <a href="{{ $url }}" wire:navigate
                       class="text-[12px] font-semibold text-[rgb(var(--mt-secondary))]
                              hover:underline underline-offset-2">
                        Lire &rarr;
                    </a>
                    @endif
                </div>

                @if ($showActions)
                <x-mtblog::post.card.actions :article="$article" :url="$url" theme="light" size="sm" />
                @endif
            </div>

        </div>

        @if ($showImage)
        <a href="{{ $url }}" wire:navigate
           class="flex-shrink-0 w-16 h-16 sm:w-20 sm:h-20 rounded-lg overflow-hidden bg-gray-100 dark:bg-white/4">
            <x-mt::image-loader
                :src="$article->getVariantImage('thumbnail')"
                :alt="$article->title"
                class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
        </a>
        @endif

    </div>
</article>


{{-- ════════════════════════════════════════════════════════════
     VARIANT : chip
     Card ultra-compacte. Pas d'actions pour garder la densité.
     showActions est ignoré sur ce variant (trop petit).
     Usage : "articles similaires", "les plus lus", aside.
     ════════════════════════════════════════════════════════════ --}}
@elseif ($variant === 'chip')

<article {{ $attributes->merge(['class' =>
    'group mt-bg flex items-center gap-3 p-2.5 rounded-xl ' .
    'border border-gray-100 dark:border-white/6 ' .
    'hover:border-[rgb(var(--mt-secondary))]/50 hover:shadow-sm ' .
    'transition-all duration-200'
]) }}>

    @if ($showImage)
    <a href="{{ $url }}" wire:navigate
       class="flex-shrink-0 w-12 h-12 sm:w-14 sm:h-14 rounded-full overflow-hidden bg-gray-100 dark:bg-white/4">
        <x-mt::image-loader
            :src="$article->getVariantImage('small')"
            :alt="$article->title"
            class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
    </a>
    @endif

    <div class="flex-1 min-w-0">

        @if ($showCategory)
        <span class="block text-[10px] font-bold text-[rgb(var(--mt-secondary))] uppercase tracking-widest leading-none mb-1">
            {{ $article->categoryName }}
        </span>
        @endif

        <h3 class="font-semibold text-gray-900 dark:text-white text-[13px] leading-snug line-clamp-2
                    group-hover:text-[rgb(var(--mt-secondary))] transition-colors duration-200">
            <a href="{{ $url }}" wire:navigate>{!! $article->title !!}</a>
        </h3>

        @if ($showDate || $showViews)
        <div class="flex items-center gap-1.5 text-[10px] text-gray-400 dark:text-white/30 mt-1">
            @if ($showDate)  <span>{{ $article->publishedThere }}</span> @endif
            @if ($showDate && $showViews) <span>·</span> @endif
            @if ($showViews) <span>{{ $article->viewsCount(true) }}</span> @endif
        </div>
        @endif

    </div>

    {{-- Sur chip : juste le bouton share, pas la barre complète --}}
    @if ($showActions)
    <div x-data="{ shareOpen: false, copied: false }" @click.stop class="relative flex-shrink-0">
        <button
            @click="shareOpen = !shareOpen"
            class="w-8 h-8 rounded-full flex items-center justify-center
                   bg-gray-100 dark:bg-white/6
                   hover:bg-[rgb(var(--mt-secondary))] group/share
                   transition-colors duration-200"
            title="Partager"
        >
            <i class="fa-regular fa-share-from-square text-[10px] text-gray-400 dark:text-white/40
                       group-hover/share:text-white transition-colors duration-200"></i>
        </button>

        <div
            x-show="shareOpen"
            @click.outside="shareOpen = false"
            x-transition:enter="transition ease-out duration-150"
            x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95"
            class="absolute bottom-full right-0 mb-2 z-50 w-48
                   bg-white dark:bg-gray-900
                   border border-gray-100 dark:border-white/8
                   rounded-2xl shadow-xl overflow-hidden"
            style="display:none"
        >
            @php
                $encodedUrl   = urlencode($url);
                $encodedTitle = urlencode(strip_tags($article->title));
                $chipNetworks = [
                    ['label'=>'Facebook',  'url'=>"https://www.facebook.com/sharer/sharer.php?u={$encodedUrl}", 'icon'=>'fa-brands fa-facebook-f', 'color'=>'#1877F2', 'bg'=>'#E7F0FD'],
                    ['label'=>'Twitter/X', 'url'=>"https://twitter.com/intent/tweet?url={$encodedUrl}&text={$encodedTitle}", 'icon'=>'fa-brands fa-x-twitter', 'color'=>'#0F1419', 'bg'=>'#F0F0F0'],
                    ['label'=>'WhatsApp',  'url'=>"https://wa.me/?text={$encodedTitle}%20{$encodedUrl}", 'icon'=>'fa-brands fa-whatsapp', 'color'=>'#25D366', 'bg'=>'#E8F9EE'],
                    ['label'=>'Telegram',  'url'=>"https://t.me/share/url?url={$encodedUrl}&text={$encodedTitle}", 'icon'=>'fa-brands fa-telegram', 'color'=>'#2AABEE', 'bg'=>'#E8F5FC'],
                ];
            @endphp
            <div class="px-2 py-2 flex flex-col gap-0.5">
                @foreach ($chipNetworks as $n)
                <a href="{{ $n['url'] }}" target="_blank" rel="noopener noreferrer"
                   @click="shareOpen = false"
                   class="flex items-center gap-2.5 px-2 py-1.5 rounded-xl hover:bg-gray-50 dark:hover:bg-white/4 transition-colors">
                    <span class="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0"
                          style="background:{{ $n['bg'] }}">
                        <i class="{{ $n['icon'] }} text-[11px]" style="color:{{ $n['color'] }}"></i>
                    </span>
                    <span class="text-[12px] font-medium text-gray-700 dark:text-white/70">{{ $n['label'] }}</span>
                </a>
                @endforeach
                <div class="h-px bg-gray-100 dark:bg-white/6 my-1"></div>
                <button @click="navigator.clipboard.writeText('{{ $url }}').then(()=>{ copied=true; setTimeout(()=>{ copied=false; shareOpen=false; },1500) })"
                   class="flex items-center gap-2.5 px-2 py-1.5 rounded-xl hover:bg-gray-50 dark:hover:bg-white/4 transition-colors w-full">
                    <span class="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 bg-gray-100 dark:bg-white/8">
                        <i :class="copied ? 'fa-solid fa-check text-green-500' : 'fa-solid fa-link text-gray-400'" class="text-[11px]"></i>
                    </span>
                    <span x-text="copied ? 'Copié !' : 'Copier le lien'"
                          :class="copied ? 'text-green-600 dark:text-green-400' : 'text-gray-700 dark:text-white/70'"
                          class="text-[12px] font-medium"></span>
                </button>
            </div>
        </div>
    </div>
    @else
    {{-- Bouton flèche par défaut quand actions désactivées --}}
    <div class="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center
                 bg-gray-100 dark:bg-white/6
                 group-hover:bg-[rgb(var(--mt-secondary))] transition-colors duration-200">
        <i class="fa-solid fa-arrow-right text-[9px] text-gray-400 dark:text-white/40
                   group-hover:text-white transition-colors duration-200"></i>
    </div>
    @endif

</article>

@endif

@endif
