{{--
╔══════════════════════════════════════════════════════════════════╗
║  COMPOSANT : hero.blade.php  — mt::hero                          ║
╠══════════════════════════════════════════════════════════════════╣
║  VARIANTS : classic | cinematic | split | stack                  ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@props([
    'featured'      => null,
    'lastArticles'  => collect(),
    'subArticles'   => collect(),
    'variant'       => 'classic',
    'showSidebar'   => true,
    'showBadge'     => true,
    'showBreaking'  => true,
    'showExcerpt'   => true,
    'showMeta'      => true,
    'showReadMore'  => false,
])


@if ($featured)
@php

    //on force les variable de la configuration
    $variant                = mtblog_option_home('hero.variant');
    $showSidebar            = mtblog_config('post-hero.options.sidebar');
    $showBadge              = mtblog_config('post-hero.options.badge');
    $showBreaking           = mtblog_config('post-hero.options.breaking');
    $showExcerpt            = mtblog_config('post-hero.options.excerpt');
    $showMeta               = mtblog_config('post-hero.options.meta');
    $showReadMore           = mtblog_config('post-hero.options.read_more');
    $showMetaReadingTime    = mtblog_config('post-hero.options.meta_reading_time');


    $url = mt_get_route('home_articles_show', ['slug' => $featured->slug, 'id' => $featured->id]);
    $parentCategory = $featured->category?->hasParent ? $featured->category->parent->name : $featured->categoryName;
    $subCategory    = $featured->category?->hasParent ? $featured->categoryName : null;
@endphp

@if ($variant === 'classic')
{{-- ── CLASSIC ─────────────────────────────────────────────────── --}}
<div class="grid gap-4 lg:grid-cols-3">

    <a href="{{ $url }}" wire:navigate
       class="relative flex flex-col justify-end overflow-hidden cursor-pointer
              lg:col-span-2 rounded-2xl group hover:shadow-lg transition-all duration-500 mt-bg">

        <div class="absolute inset-0">
            @if ($featured->hasFeatured)
            <img src="{{ $featured->getVariantImage('large') }}" alt="{!! $featured->title !!}"
                 class="absolute inset-0 object-cover w-full h-full transition-transform duration-700 group-hover:scale-105">
            @else
            <div class="w-full h-full flex items-center justify-center bg-gray-100 dark:bg-white/4">
                <i class="fa-regular fa-image text-2xl text-gray-300 dark:text-white/15"></i>
            </div>
            @endif
        </div>

        <div class="absolute inset-0 bg-gradient-to-t from-[rgb(var(--mt-bg))] via-[rgba(var(--mt-bg),.15)] to-transparent pointer-events-none"></div>

        <div class="relative h-[380px] lg:h-[520px] flex flex-col justify-end p-4 lg:p-8 gap-3">

            @if ($showBadge || ($showBreaking && $featured->is_breaking_news))
            <div class="flex items-center flex-wrap gap-2">
                @if ($showBadge)
                <span class="mt-bg-secondary text-white text-xs font-bold uppercase tracking-wide px-3 py-1 rounded-full">
                    {{ $parentCategory }}
                </span>
                @if ($subCategory)<span class="bg-white/15 text-white text-xs px-3 py-1 rounded-full">{{ $subCategory }}</span>@endif
                @endif
                @if ($showBreaking && $featured->is_breaking_news)
                <span class="bg-amber-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">
                    <i class="fa-solid fa-bolt mr-1"></i>Flash
                </span>
                @endif
            </div>
            @endif

            <h2 class="font-bold text-xl lg:text-4xl mt-text-secondary leading-tight group-hover:opacity-80 transition-opacity line-clamp-3">
                {!! $featured->title !!}
            </h2>

            @if ($showExcerpt)
            <p class="hidden lg:block text-sm lg:text-base mt-text line-clamp-2 max-w-2xl">{{ $featured->excerpt }}</p>
            @endif

            <div class="flex items-center justify-between gap-4 flex-wrap">
                @if ($showMeta)
                <div class="flex items-center gap-3 text-xs mt-text flex-wrap">
                    <span><i class="fa-regular fa-clock mr-1"></i>{{ $featured->publishedThere }}</span>
                    @if($showMetaReadingTime)<span>{{ $featured->readingTime(true) }}</span>@endif
                    @if ($featured->views_count > 0)<span><i class="fa-regular fa-eye mr-1"></i>{{ $featured->viewsCount(true) }}</span>@endif
                </div>
                @endif
                @if ($showReadMore)
                <span class="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-white mt-bg-secondary px-3 py-1.5 rounded-full flex-shrink-0 group-hover:opacity-90 transition-opacity">
                    Lire <i class="fa-solid fa-arrow-right text-[10px]"></i>
                </span>
                @endif
            </div>
        </div>
    </a>

    @if ($showSidebar && $lastArticles->isNotEmpty())
    <div class="flex flex-col mt-bg rounded-2xl overflow-hidden border border-gray-100 dark:border-white/6 shadow-sm">
        <div class="flex items-center gap-2 px-5 py-4 border-b border-gray-100 dark:border-white/6 flex-shrink-0">
            <span class="relative flex flex-shrink-0 w-2 h-2">
                <span class="animate-ping absolute inset-0 rounded-full mt-bg-secondary opacity-75"></span>
                <span class="relative rounded-full w-2 h-2 mt-bg-secondary"></span>
            </span>
            <h3 class="text-sm font-bold mt-text">Dernières infos</h3>
        </div>
        <div class="flex-1 divide-y divide-gray-100 dark:divide-white/5 overflow-y-auto">
            @forelse ($lastArticles as $article)
            @php $aUrl = mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]); @endphp
            <a href="{{ $aUrl }}" wire:navigate class="flex gap-3 p-4 hover:bg-gray-50 dark:hover:bg-white/4 transition-colors group">
                <div class="flex-shrink-0 w-16 h-14 rounded-xl overflow-hidden bg-gray-100 dark:bg-white/6">
                    @if ($article->hasFeatured)
                    <img src="{{ $article->getVariantImage('thumbnail') }}" alt="{!! $article->title !!}"
                         class="object-cover w-full h-full transition-transform duration-300 group-hover:scale-110">
                    @else
                    <div class="w-full h-full flex items-center justify-center">
                        <i class="fa-regular fa-image text-xs text-gray-300 dark:text-white/15"></i>
                    </div>
                    @endif
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-[11px] mt-text-secondary font-semibold mb-0.5 uppercase tracking-wide">{{ $article->publishedDate }}</p>
                    <p class="text-sm font-medium mt-text line-clamp-2 leading-snug group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                        {!! $article->title !!}
                    </p>
                </div>
            </a>
            @empty
            <p class="p-6 text-sm text-center text-gray-400 dark:text-white/30">Aucun article récent.</p>
            @endforelse
        </div>
    </div>
    @endif
</div>

@elseif ($variant === 'cinematic')
{{-- ── CINEMATIC ───────────────────────────────────────────────── --}}
<div class="relative overflow-hidden rounded-2xl group cursor-pointer h-[480px] lg:h-[600px]">
    <a href="{{ $url }}" wire:navigate class="absolute inset-0">
        @if ($featured->hasFeatured)
        <img src="{{ $featured->getVariantImage('large') }}" alt="{!! $featured->title !!}"
             class="absolute inset-0 object-cover w-full h-full transition-transform duration-700 group-hover:scale-105">
        @else
        <div class="absolute inset-0 bg-gray-900"></div>
        @endif
    </a>
    <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/10 pointer-events-none"></div>

    @if ($showBadge || ($showBreaking && $featured->is_breaking_news))
    <div class="absolute top-5 left-5 flex items-center gap-2 flex-wrap z-10">
        @if ($showBadge)
        <span class="mt-bg-secondary text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full shadow-sm">{{ $parentCategory }}</span>
        @if ($subCategory)<span class="bg-white/20 text-white text-xs px-3 py-1 rounded-full backdrop-blur-sm">{{ $subCategory }}</span>@endif
        @endif
        @if ($showBreaking && $featured->is_breaking_news)
        <span class="bg-amber-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse shadow-sm">
            <i class="fa-solid fa-bolt mr-1"></i>Flash
        </span>
        @endif
    </div>
    @endif

    <div class="absolute bottom-0 left-0 right-0 p-6 lg:p-10 flex flex-col gap-3 z-10">
        <h2 class="font-black text-2xl sm:text-3xl lg:text-5xl text-white leading-tight max-w-4xl group-hover:opacity-85 transition-opacity line-clamp-3">
            <a href="{{ $url }}" wire:navigate>{!! $featured->title !!}</a>
        </h2>
        @if ($showExcerpt)
        <p class="hidden sm:block text-white/65 text-sm lg:text-base max-w-3xl line-clamp-2">{{ $featured->excerpt }}</p>
        @endif
        <div class="flex items-center justify-between gap-4 flex-wrap">
            @if ($showMeta)
            <div class="flex items-center gap-3 text-xs text-white/50 flex-wrap">
                <span><i class="fa-regular fa-clock mr-1"></i>{{ $featured->publishedThere }}</span>
                @if($showMetaReadingTime)<span>{{ $featured->readingTime(true) }}</span>@endif
                @if ($featured->views_count > 0)<span><i class="fa-regular fa-eye mr-1"></i>{{ $featured->viewsCount(true) }}</span>@endif
            </div>
            @endif
            @if ($showReadMore)
            <a href="{{ $url }}" wire:navigate
               class="inline-flex items-center gap-2 text-sm font-semibold text-white bg-white/15 hover:bg-white/25 px-4 py-2 rounded-full transition-all backdrop-blur-sm flex-shrink-0">
                Lire l'article <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
            @endif
        </div>
    </div>
</div>

@elseif ($variant === 'split')
{{-- ── SPLIT ───────────────────────────────────────────────────── --}}
<div class="grid lg:grid-cols-2 gap-0 overflow-hidden rounded-2xl mt-bg border border-gray-100 dark:border-white/6 min-h-[380px] lg:min-h-[500px]">
    <div class="flex flex-col justify-between p-6 lg:p-10 order-2 lg:order-1">
        <div class="flex flex-col gap-4">
            @if ($showBadge || ($showBreaking && $featured->is_breaking_news))
            <div class="flex items-center gap-2 flex-wrap">
                @if ($showBadge)<span class="mt-bg-secondary text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full">{{ $parentCategory }}</span>@endif
                @if ($showBreaking && $featured->is_breaking_news)
                <span class="bg-amber-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">
                    <i class="fa-solid fa-bolt mr-1"></i>Flash
                </span>
                @endif
            </div>
            @endif
            <h2 class="font-black text-2xl lg:text-4xl mt-text leading-tight line-clamp-4 hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <a href="{{ $url }}" wire:navigate>{!! $featured->title !!}</a>
            </h2>
            @if ($showExcerpt)
            <p class="text-gray-500 dark:text-white/50 text-sm lg:text-base line-clamp-3 leading-relaxed">{{ $featured->excerpt }}</p>
            @endif
        </div>
        <div class="flex flex-col gap-3 mt-6 pt-6 border-t border-gray-100 dark:border-white/6">
            @if ($showMeta)
            <div class="flex items-center gap-3 text-xs text-gray-400 dark:text-white/30 flex-wrap">
                <span><i class="fa-regular fa-clock mr-1"></i>{{ $featured->publishedThere }}</span>
                @if($showMetaReadingTime)<span>{{ $featured->readingTime(true) }}</span>@endif
                @if ($featured->views_count > 0)<span><i class="fa-regular fa-eye mr-1"></i>{{ $featured->viewsCount(true) }}</span>@endif
            </div>
            @endif
            @if ($showReadMore)
            <a href="{{ $url }}" wire:navigate class="self-start inline-flex items-center gap-2 text-sm font-semibold text-[rgb(var(--mt-secondary))] hover:gap-3 transition-all">
                Lire l'article <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
            @endif
        </div>
    </div>
    <div class="relative overflow-hidden bg-gray-100 dark:bg-white/4 order-1 lg:order-2 h-64 lg:h-auto group">
        @if ($featured->hasFeatured)
        <a href="{{ $url }}" wire:navigate class="absolute inset-0">
            <img src="{{ $featured->getVariantImage('large') }}" alt="{!! $featured->title !!}"
                 class="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105">
        </a>
        @endif
    </div>
</div>

@elseif ($variant === 'stack')
{{-- ── STACK ───────────────────────────────────────────────────── --}}
<div class="flex flex-col gap-4">
    <div class="relative overflow-hidden rounded-2xl group cursor-pointer h-[340px] sm:h-[420px] lg:h-[500px]">
        <a href="{{ $url }}" wire:navigate class="absolute inset-0">
            @if ($featured->hasFeatured)
            <img src="{{ $featured->getVariantImage('large') }}" alt="{!! $featured->title !!}"
                 class="absolute inset-0 object-cover w-full h-full transition-transform duration-700 group-hover:scale-105">
            @else
            <div class="absolute inset-0 bg-gray-900"></div>
            @endif
        </a>
        <div class="absolute inset-0 bg-gradient-to-t from-black/88 via-black/20 to-transparent pointer-events-none"></div>
        <div class="absolute bottom-0 left-0 right-0 p-5 lg:p-8 flex flex-col gap-2.5">
            @if ($showBadge)
            <span class="self-start mt-bg-secondary text-white text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full">{{ $parentCategory }}</span>
            @endif
            <h2 class="font-black text-xl sm:text-2xl lg:text-4xl text-white leading-tight max-w-4xl group-hover:opacity-85 transition-opacity line-clamp-3">
                <a href="{{ $url }}" wire:navigate>{!! $featured->title !!}</a>
            </h2>
            @if ($showExcerpt)
            <p class="hidden sm:block text-white/60 text-sm max-w-3xl line-clamp-1">{{ $featured->excerpt }}</p>
            @endif
            @if ($showMeta)
            <div class="flex items-center gap-3 text-xs text-white/45 flex-wrap">
                <span><i class="fa-regular fa-clock mr-1"></i>{{ $featured->publishedThere }}</span>
                @if($showMetaReadingTime)<span>{{ $featured->readingTime(true) }}</span>@endif
                @if ($featured->views_count > 0)<span><i class="fa-regular fa-eye mr-1"></i>{{ $featured->viewsCount(true) }}</span>@endif
            </div>
            @endif
        </div>
    </div>

    @php $subs = $subArticles->isNotEmpty() ? $subArticles : $lastArticles; @endphp
    @if ($subs->isNotEmpty())
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        @foreach ($subs->take(3) as $sub)
        @php $sUrl = mt_get_route('home_articles_show', ['slug' => $sub->slug, 'id' => $sub->id]); @endphp
        <a href="{{ $sUrl }}" wire:navigate
           class="group flex gap-3 mt-bg rounded-2xl p-3 border border-gray-100 dark:border-white/6 hover:shadow-sm hover:-translate-y-0.5 transition-all duration-300">
            <div class="flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden bg-gray-100 dark:bg-white/6">
                @if ($sub->hasFeatured)
                <img src="{{ $sub->getVariantImage('thumbnail') }}" alt="{!! $sub->title !!}"
                     class="object-cover w-full h-full transition-transform duration-300 group-hover:scale-105">
                @else
                <div class="w-full h-full flex items-center justify-center">
                    <i class="fa-regular fa-image text-gray-300 dark:text-white/15 text-sm"></i>
                </div>
                @endif
            </div>
            <div class="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                @if ($showBadge)<span class="text-[10px] font-bold uppercase tracking-wider mt-text-secondary">{{ $sub->categoryName }}</span>@endif
                <p class="text-[13px] font-semibold mt-text leading-snug line-clamp-2 group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                    {!! $sub->title !!}
                </p>
                @if ($showMeta)<p class="text-[11px] text-gray-400 dark:text-white/30">{{ $sub->publishedThere }}</p>@endif
            </div>
        </a>
        @endforeach
    </div>
    @endif
</div>
@endif
@endif
