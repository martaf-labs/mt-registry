<div {{ $attributes->merge(['class' => 'bg-white dark:bg-[#111C2E] rounded-2xl overflow-hidden border border-gray-100 dark:border-white/6 shadow-sm animate-pulse']) }}>
    {{-- Image Placeholder --}}
    <div class="h-44 bg-gray-200 dark:bg-white/5 relative">
        <div class="absolute top-3 left-3 bg-gray-300 dark:bg-white/10 h-5 w-20 rounded-full"></div>
    </div>

    {{-- Content Placeholder --}}
    <div class="p-5">
        {{-- Date & Time --}}
        <div class="flex items-center gap-2 mb-3">
            <div class="h-3 w-16 bg-gray-200 dark:bg-white/10 rounded"></div>
            <div class="h-3 w-12 bg-gray-200 dark:bg-white/10 rounded"></div>
        </div>

        {{-- Title --}}
        <div class="space-y-2 mb-4">
            <div class="h-4 w-full bg-gray-300 dark:bg-white/20 rounded"></div>
            <div class="h-4 w-3/4 bg-gray-300 dark:bg-white/20 rounded"></div>
        </div>

        {{-- Excerpt --}}
        <div class="space-y-2 mb-5">
            <div class="h-3 w-full bg-gray-200 dark:bg-white/10 rounded"></div>
            <div class="h-3 w-5/6 bg-gray-200 dark:bg-white/10 rounded"></div>
        </div>

        {{-- Link --}}
        <div class="h-4 w-12 bg-gray-200 dark:bg-[#BE1622]/20 rounded"></div>
    </div>
</div>

