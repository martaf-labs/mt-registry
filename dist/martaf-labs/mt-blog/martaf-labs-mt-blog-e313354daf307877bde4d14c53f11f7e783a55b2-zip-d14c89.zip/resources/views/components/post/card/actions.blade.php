{{--
  SOUS-COMPOSANT : post/card/actions.blade.php
  Barre d'actions d'une card : like · réactions · commentaires · partage.
  Chaque action est activable par config : mtblog_option_card('like'|'reactions'|'comments'|'share').
  Props : article (requis), url (requis), theme 'light'|'dark', size 'md'|'sm'.
  Dépendances : Livewire (cardToggleLike / cardReact / cardRecordShare sur GuestBaseComponent),
                Alpine (état optimiste + popovers), FontAwesome.
--}}
@props([
    'article' => null,
    'url'     => null,
    'theme'   => 'light',
    'size'    => 'md',
])

@if ($article && $url)

@php
    $isDark = $theme === 'dark';
    $isSm   = $size === 'sm';

    // Flags config (granulaires)
    $showLike      = (bool) mtblog_option_card('like');
    $showReactions = (bool) mtblog_option_card('reactions');
    $showComments  = (bool) mtblog_option_card('comments');
    $showShare     = (bool) mtblog_option_card('share');

    $encodedUrl   = urlencode($url);
    $encodedTitle = urlencode(strip_tags($article->title));

    $shareNetworks = [
        'facebook' => ['label' => 'Facebook',    'icon' => 'fa-brands fa-facebook-f',  'color' => '#1877F2', 'bg' => '#E7F0FD', 'url' => "https://www.facebook.com/sharer/sharer.php?u={$encodedUrl}"],
        'twitter'  => ['label' => 'Twitter / X', 'icon' => 'fa-brands fa-x-twitter',   'color' => '#0F1419', 'bg' => '#F0F0F0', 'url' => "https://twitter.com/intent/tweet?url={$encodedUrl}&text={$encodedTitle}"],
        'whatsapp' => ['label' => 'WhatsApp',    'icon' => 'fa-brands fa-whatsapp',    'color' => '#25D366', 'bg' => '#E8F9EE', 'url' => "https://wa.me/?text={$encodedTitle}%20{$encodedUrl}"],
        'telegram' => ['label' => 'Telegram',    'icon' => 'fa-brands fa-telegram',    'color' => '#2AABEE', 'bg' => '#E8F5FC', 'url' => "https://t.me/share/url?url={$encodedUrl}&text={$encodedTitle}"],
        'linkedin' => ['label' => 'LinkedIn',    'icon' => 'fa-brands fa-linkedin-in', 'color' => '#0A66C2', 'bg' => '#E8F0F9', 'url' => "https://www.linkedin.com/sharing/share-offsite/?url={$encodedUrl}"],
    ];

    $btnBase = $isSm
        ? 'inline-flex items-center gap-1 text-[11px] font-medium px-2 py-1 rounded-lg transition-all duration-200'
        : 'inline-flex items-center gap-1.5 text-[12px] font-medium px-2.5 py-1.5 rounded-xl transition-all duration-200';

    if ($isDark) {
        $btnClass       = $btnBase . ' text-white/60 hover:text-white hover:bg-white/10';
        $btnLikedClass  = $btnBase . ' text-red-400 bg-red-500/15';
        $iconClass      = 'text-white/40';
        $separatorClass = 'bg-white/10';
    } else {
        $btnClass       = $btnBase . ' text-gray-400 dark:text-white/35 hover:text-gray-700 dark:hover:text-white/70 hover:bg-gray-100 dark:hover:bg-white/6';
        $btnLikedClass  = $btnBase . ' text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-500/10';
        $iconClass      = 'text-gray-300 dark:text-white/15';
        $separatorClass = 'bg-gray-100 dark:bg-white/8';
    }
@endphp

<div
    class="flex items-center gap-0.5"
    x-data="{
        liked: {{ $article->isLikedByUser() ? 'true' : 'false' }},
        likeCount: {{ (int) ($article->likes_count ?? 0) }},
        reactOpen: false,
        reactTotal: {{ (int) array_sum((array) ($article->meta_data['reactions'] ?? [])) }},
        shareOpen: false,
        shareTotal: {{ (int) ($article->shares_count ?? 0) }},
        copied: false,
        toggleLike() {
            @auth
                this.liked = !this.liked;
                this.likeCount += this.liked ? 1 : -1;
                $wire.cardToggleLike({{ $article->id }});
            @else
                Livewire.dispatch('open-auth-modal');
            @endauth
        },
        react(emoji) {
            this.reactTotal += 1;
            this.reactOpen = false;
            $wire.cardReact({{ $article->id }}, emoji);
        },
        share(network) {
            this.shareTotal += 1;
            this.shareOpen = false;
            $wire.cardRecordShare({{ $article->id }}, network);
        }
    }"
    @click.stop
>

    {{-- ── LIKE ─────────────────────────────────────────── --}}
    @if ($showLike)
    <button @click="toggleLike()" type="button"
            :class="liked ? '{{ $btnLikedClass }}' : '{{ $btnClass }}'"
            :aria-label="liked ? 'Retirer le like' : 'Liker'" title="J'aime">
        <i :class="liked ? 'fa-solid fa-heart text-red-500 dark:text-red-400' : 'fa-regular fa-heart {{ $iconClass }}'"></i>
        <span x-text="likeCount > 0 ? likeCount : ''"></span>
    </button>
    @endif

    {{-- ── RÉACTIONS (popover au clic + click-outside) ────── --}}
    @if ($showReactions)
    <div class="relative" @click.outside="reactOpen = false">
        <button type="button" @click="reactOpen = !reactOpen"
                :class="reactOpen ? '{{ $btnClass }} !text-[rgb(var(--mt-secondary))]' : '{{ $btnClass }}'"
                title="Réagir" aria-label="Réagir">
            <i class="fa-regular fa-face-smile {{ $iconClass }}"></i>
            <span x-show="reactTotal > 0" x-text="reactTotal" style="display:none"></span>
        </button>

        <div x-show="reactOpen"
             x-transition:enter="transition ease-out duration-150"
             x-transition:enter-start="opacity-0 scale-90 translate-y-1"
             x-transition:enter-end="opacity-100 scale-100 translate-y-0"
             class="absolute bottom-full left-0 mb-2 z-50 flex items-center gap-0.5 px-2 py-1.5
                    bg-white dark:bg-gray-900 border border-gray-100 dark:border-white/8
                    rounded-full shadow-xl dark:shadow-black/40"
             style="display:none">
            @foreach (['👍', '❤️', '😮', '😢', '😡'] as $em)
            <button type="button" @click="react('{{ $em }}')"
                    class="px-1 text-base leading-none transition-transform duration-150 hover:scale-[1.4]">{{ $em }}</button>
            @endforeach
        </div>
    </div>
    @endif

    {{-- ── COMMENTAIRES ──────────────────────────────────── --}}
    @if ($showComments)
    <a href="{{ $url }}#comments" wire:navigate class="{{ $btnClass }}" title="Commentaires" aria-label="Commentaires">
        <i class="fa-regular fa-comment {{ $iconClass }}"></i>
        @if (($article->comments_count ?? 0) > 0)<span>{{ $article->comments_count }}</span>@endif
    </a>
    @endif

    {{-- ── PARTAGE ───────────────────────────────────────── --}}
    @if ($showShare)
    @if ($showLike || $showReactions || $showComments)
    <span class="w-px h-4 mx-1 {{ $separatorClass }} flex-shrink-0"></span>
    @endif
    <div class="relative" @click.outside="shareOpen = false">
        <button type="button" @click="shareOpen = !shareOpen"
                :class="shareOpen ? '{{ $btnClass }} !text-[rgb(var(--mt-secondary))]' : '{{ $btnClass }}'"
                title="Partager" aria-label="Partager" :aria-expanded="shareOpen">
            <i class="fa-solid fa-share-nodes {{ $iconClass }}"></i>
            <span x-show="shareTotal > 0" x-text="shareTotal" style="display:none"></span>
            <span class="{{ $isSm ? 'hidden' : 'hidden sm:inline' }}">Partager</span>
        </button>

        <div x-show="shareOpen"
             x-transition:enter="transition ease-out duration-150"
             x-transition:enter-start="opacity-0 scale-95 translate-y-1"
             x-transition:enter-end="opacity-100 scale-100 translate-y-0"
             class="absolute bottom-full left-0 mb-2 z-50 w-52
                    bg-white dark:bg-gray-900 border border-gray-100 dark:border-white/8
                    rounded-2xl shadow-xl dark:shadow-black/40 overflow-hidden"
             style="display:none">
            <div class="px-3.5 pt-3 pb-2">
                <p class="text-[11px] font-semibold text-gray-400 dark:text-white/30 uppercase tracking-widest">Partager via</p>
            </div>
            <div class="flex flex-col gap-0.5 px-2 pb-2">
                @foreach ($shareNetworks as $key => $network)
                <a href="{{ $network['url'] }}" target="_blank" rel="noopener noreferrer"
                   @click="share('{{ $key }}')"
                   class="flex items-center gap-3 px-2.5 py-2 rounded-xl hover:bg-gray-50 dark:hover:bg-white/4 transition-colors duration-150 group/share">
                    <span class="flex items-center justify-center flex-shrink-0 rounded-lg w-7 h-7" style="background: {{ $network['bg'] }}">
                        <i class="{{ $network['icon'] }} text-[12px]" style="color: {{ $network['color'] }}"></i>
                    </span>
                    <span class="text-[13px] font-medium text-gray-700 dark:text-white/70 group-hover/share:text-gray-900 dark:group-hover/share:text-white transition-colors">{{ $network['label'] }}</span>
                </a>
                @endforeach
            </div>
            <div class="h-px mx-3 bg-gray-100 dark:bg-white/6"></div>
            <div class="px-2 py-2">
                <button type="button"
                        @click="navigator.clipboard.writeText('{{ $url }}').then(() => { copied = true; share('copy'); setTimeout(() => copied = false, 2000) })"
                        class="flex items-center w-full gap-3 px-2.5 py-2 rounded-xl hover:bg-gray-50 dark:hover:bg-white/4 transition-colors duration-150 group/copy">
                    <span class="flex items-center justify-center flex-shrink-0 rounded-lg w-7 h-7 bg-gray-100 dark:bg-white/8">
                        <i :class="copied ? 'fa-solid fa-check text-green-500' : 'fa-solid fa-link text-gray-500 dark:text-white/40'" class="text-[12px] transition-all duration-200"></i>
                    </span>
                    <span x-text="copied ? 'Lien copié !' : 'Copier le lien'"
                          :class="copied ? 'text-green-600 dark:text-green-400' : 'text-gray-700 dark:text-white/70'"
                          class="text-[13px] font-medium transition-colors"></span>
                </button>
            </div>
        </div>
    </div>
    @endif

</div>

@endif
