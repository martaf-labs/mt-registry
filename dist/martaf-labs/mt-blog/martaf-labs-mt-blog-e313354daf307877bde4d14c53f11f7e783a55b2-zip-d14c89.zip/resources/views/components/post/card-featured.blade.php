@props(['article'])

@php
    $url = mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]);
@endphp

<article class="relative group bg-white dark:bg-[#111C2E] rounded-3xl overflow-hidden border border-gray-100 dark:border-white/6 shadow-xl hover:shadow-2xl transition-all duration-500">
    <div class="flex flex-col md:flex-row">
        {{-- Image --}}
        <a href="{{ $url }}" wire:navigate class="md:w-3/5 h-64 md:h-[400px] overflow-hidden bg-gray-100 dark:bg-white/4">
            <img src="{{ $article->imageUrl }}" alt="{{ $article->title }}"
                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" loading="eager">
        </a>

        {{-- Contenu --}}
        <div class="md:w-2/5 p-8 md:p-12 flex flex-col justify-center">
            <div class="flex items-center gap-4 mb-6">
                <span class="bg-[#BE1622] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                    Mis en avant
                </span>
                <span class="text-gray-400 dark:text-white/40 text-sm">{{ $article->publishedThere }}</span>
            </div>

            <h2 class="text-2xl md:text-4xl font-extrabold text-gray-900 dark:text-white mb-4 leading-tight group-hover:text-[#BE1622] transition-colors">
                <a href="{{ $url }}" wire:navigate>{{ $article->title }}</a>
            </h2>

            <p class="text-gray-500 dark:text-white/60 text-lg mb-8 line-clamp-3">
                {{ $article->excerpt }}
            </p>

            <a href="{{ $url }}" wire:navigate
               class="inline-flex items-center gap-2 text-[#BE1622] font-bold text-lg group-hover:gap-3 transition-all duration-300">
                Découvrir l'article <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
    </div>
</article>
