@php $inputClass = 'w-full px-3 py-2.5 text-sm rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-white/6 text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-white/25 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/25 transition-all'; @endphp

<div x-data="{ open: @entangle('open') }" x-cloak
     @open-auth-modal.window="open = true">

    {{-- Backdrop + conteneur : @click.self → seul un clic sur le fond (pas la carte/les champs) ferme --}}
    <div x-show="open"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-150"
         @click.self="open = false"
         @keydown.escape.window="open = false"
         class="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
         style="display:none">

        <div class="w-full max-w-sm rounded-2xl overflow-hidden shadow-2xl"
             style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgba(var(--mt-ui-card-border),.7)">

            {{-- En-tête --}}
            <div class="flex items-center justify-between px-5 py-4" style="border-bottom: 1px solid rgba(var(--mt-ui-card-border),.6)">
                <h3 class="flex items-center gap-2 text-base font-bold mt-text">
                    <i class="fa-solid fa-bolt text-[rgb(var(--mt-secondary))]"></i> Connexion rapide
                </h3>
                <button type="button" @click="open = false"
                        class="flex items-center justify-center w-8 h-8 rounded-full text-gray-400 dark:text-white/40
                               hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            {{-- Formulaire --}}
            <form wire:submit="login" class="flex flex-col gap-3 p-5">
                <p class="text-sm mt-text-muted">Connectez-vous pour aimer et commenter.</p>

                <div>
                    <label class="block mb-1 text-xs font-semibold mt-text-muted">Email</label>
                    <input type="email" wire:model="email" autocomplete="email" placeholder="votre@email.com" class="{{ $inputClass }}">
                    @error('email') <p class="mt-1 text-xs text-red-500">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="block mb-1 text-xs font-semibold mt-text-muted">Mot de passe</label>
                    <input type="password" wire:model="password" autocomplete="current-password" placeholder="••••••••" class="{{ $inputClass }}">
                    @error('password') <p class="mt-1 text-xs text-red-500">{{ $message }}</p> @enderror
                </div>

                <label class="flex items-center gap-2 text-xs mt-text-muted cursor-pointer">
                    <input type="checkbox" wire:model="remember" class="rounded border-gray-300 dark:border-white/20 text-[rgb(var(--mt-secondary))]">
                    Se souvenir de moi
                </label>

                <button type="submit"
                        class="w-full py-2.5 text-sm font-semibold text-white bg-[rgb(var(--mt-secondary))] rounded-xl
                               hover:opacity-90 transition-opacity">
                    <span wire:loading.remove wire:target="login"><i class="fa-solid fa-right-to-bracket mr-1.5 text-xs"></i>Se connecter</span>
                    <span wire:loading wire:target="login"><i class="fa-solid fa-spinner fa-spin mr-1.5 text-xs"></i>Connexion…</span>
                </button>

                <div class="flex items-center justify-between pt-1 text-xs">
                    @if (\Illuminate\Support\Facades\Route::has('password.request'))
                    <a href="{{ route('password.request') }}" class="mt-text-muted hover:text-[rgb(var(--mt-secondary))] transition-colors">Mot de passe oublié ?</a>
                    @else
                    <span></span>
                    @endif
                    @if (\Illuminate\Support\Facades\Route::has('register'))
                    <a href="{{ route('register') }}" class="font-semibold text-[rgb(var(--mt-secondary))] hover:underline">Créer un compte</a>
                    @endif
                </div>
            </form>
        </div>
    </div>
</div>
