<div class="p-6 bg-white shadow rounded">
    @if ($message)
        <p class="text-green-600 font-medium">{{ $message }}</p>
    @else
        <form wire:submit="save" class="flex flex-col gap-3">
            <input type="email" wire:model="email" placeholder="Entrez votre email" class="border p-2 rounded">
            @error('email') <span class="text-red-500">{{ $message }}</span> @enderror
            <button type="submit" class="bg-blue-600 text-white p-2 rounded">S'abonner</button>
        </form>
    @endif
</div>