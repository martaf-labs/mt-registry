@php $inputClass = 'w-full px-3 py-2.5 text-sm rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-white/6 text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-white/25 focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/25 transition-all'; @endphp

<div x-data="{ open: @entangle('open') }" x-cloak
     @open-newsletter-modal.window="open = true">

    {{-- Backdrop : @click.self → seul un clic sur le fond ferme --}}
    <div x-show="open"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-150"
         @click.self="open = false"
         @keydown.escape.window="open = false"
         class="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
         style="display:none">

        <div class="w-full max-w-sm rounded-2xl overflow-hidden shadow-2xl"
             style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgba(var(--mt-ui-card-border),.7)">

            {{-- En-tête --}}
            <div class="flex items-center justify-between px-5 py-4" style="border-bottom: 1px solid rgba(var(--mt-ui-card-border),.6)">
                <h3 class="flex items-center gap-2 text-base font-bold mt-text">
                    <i class="fa-solid fa-envelope-open-text text-[rgb(var(--mt-secondary))]"></i> Newsletter
                </h3>
                <button type="button" @click="open = false"
                        class="flex items-center justify-center w-8 h-8 rounded-full text-gray-400 dark:text-white/40
                               hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div class="p-5">
                @if ($done)
                {{-- Succès --}}
                <div class="flex flex-col items-center gap-2 py-4 text-center">
                    <span class="flex items-center justify-center w-12 h-12 rounded-full bg-green-500/15 text-green-500">
                        <i class="fa-solid fa-check text-lg"></i>
                    </span>
                    <p class="text-sm font-semibold mt-text">Merci, vous êtes abonné !</p>
                    <p class="text-xs mt-text-muted">Vous recevrez nos prochaines actualités par email.</p>
                    <button type="button" @click="open = false"
                            class="mt-2 px-4 py-2 text-sm font-semibold text-white bg-[rgb(var(--mt-secondary))] rounded-xl hover:opacity-90 transition-opacity">
                        Fermer
                    </button>
                </div>
                @else
                {{-- Formulaire --}}
                <form wire:submit="subscribe" class="flex flex-col gap-3">
                    <p class="text-sm mt-text-muted">Recevez nos dernières actualités directement dans votre boîte mail.</p>

                    <div>
                        <input type="email" wire:model="email" autocomplete="email" placeholder="votre@email.com" class="{{ $inputClass }}">
                        @error('email') <p class="mt-1 text-xs text-red-500">{{ $message }}</p> @enderror
                    </div>

                    <button type="submit"
                            class="w-full py-2.5 text-sm font-semibold text-white bg-[rgb(var(--mt-secondary))] rounded-xl hover:opacity-90 transition-opacity">
                        <span wire:loading.remove wire:target="subscribe"><i class="fa-solid fa-paper-plane mr-1.5 text-xs"></i>S'abonner</span>
                        <span wire:loading wire:target="subscribe"><i class="fa-solid fa-spinner fa-spin mr-1.5 text-xs"></i>…</span>
                    </button>

                    <p class="text-[11px] text-center mt-text-muted">Pas de spam. Désabonnement en un clic.</p>
                </form>
                @endif
            </div>
        </div>
    </div>
</div>
