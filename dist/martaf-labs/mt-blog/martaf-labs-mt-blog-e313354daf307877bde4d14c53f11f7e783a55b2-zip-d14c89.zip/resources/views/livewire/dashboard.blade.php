<div>
    <livewire:mt.mt-dashboard></livewire:mt.mt-dashboard>
</div>