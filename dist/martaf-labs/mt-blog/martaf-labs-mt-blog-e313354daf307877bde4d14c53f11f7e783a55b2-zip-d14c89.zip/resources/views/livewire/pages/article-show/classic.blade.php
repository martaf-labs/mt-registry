{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : classic                                                ║
║  Vue    : article-show/classic.blade.php                         ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : grille 8/4 (article | sidebar sticky)               ║
║  Sidebar   : TOC + partage + infos article + articles similaires ║
║  Usage     : blog généraliste, news, multi-thématiques           ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $article->title)
    @section('og_url',         mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]))
    @section('og_title',       $article->title)
    @section('og_description', $article->excerpt)
    @section('og_image',       $article->getVariantImage('small'))

    {{-- Barre de progression lecture --}}
    <div class="fixed top-0 left-0 right-0 z-50 h-[2px] bg-gray-100 dark:bg-white/5 pointer-events-none">
        <div id="reading-progress"
             class="h-full bg-[rgb(var(--mt-secondary))] transition-all duration-100"
             style="width:0%">
        </div>
    </div>

    {{-- Rail de partage flottant (xl+) --}}
    @include('mtblog::livewire.pages.article-show.partials._share-rail')

    <div class="grid gap-8 lg:grid-cols-12">

        {{-- ══ COLONNE PRINCIPALE ══════════════════════════════════ --}}
        <div class="lg:col-span-8">
            <article>

                @if($hasBreadcrumb)
                {{-- ─ Fil d'ariane ─ --}}
                <div class="flex flex-wrap items-center gap-2 mb-5">
                    <a href="{{ mt_get_route('home') }}" wire:navigate
                       class="text-xs text-gray-400 dark:text-white/30
                              hover:text-[rgb(var(--mt-secondary))] transition-colors
                              flex items-center gap-1">
                        <i class="fa-solid fa-house text-[10px]"></i> Accueil
                    </a>

                    @if($article->category)
                    <i class="fa-solid fa-chevron-right text-[10px] text-gray-300 dark:text-white/15"></i>
                    <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category->hasParent ? $article->category->parent->slug : $article->category->slug]) }}"
                       wire:navigate
                       class="px-2.5 py-0.5 text-xs font-semibold text-white rounded-full mt-bg-secondary">
                        {{ $article->category->hasParent ? $article->category->parent->name : $article->categoryName }}
                    </a>

                    @if ($article->category->hasParent)
                    <i class="fa-solid fa-chevron-right text-[10px] text-gray-300 dark:text-white/15"></i>
                    <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category->slug]) }}"
                       wire:navigate
                       class="px-2.5 py-0.5 text-xs text-gray-600 dark:text-white/60
                              bg-gray-100 dark:bg-white/8 rounded-full
                              hover:bg-gray-200 dark:hover:bg-white/12 transition-colors">
                        {{ $article->categoryName }}
                    </a>
                    @endif
                    @endif

                    @if ($article->hasBeenUpdated)
                    <span class="ml-auto text-xs text-gray-400 dark:text-white/25 italic">
                        Mis à jour le {{ $article->updatedDate }}
                    </span>
                    @endif
                </div>
                @endif

                {{-- ─ Titre ─ --}}
                <h1 class="mb-5 text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white leading-tight">
                    {!! $article->title !!}
                </h1>

                {{-- ─ Extrait ─ --}}
                <p class="text-sm lg:text-base font-semibold text-gray-600 dark:text-white/55
                           leading-relaxed text-justify
                           border-l-[3px] border-[rgb(var(--mt-secondary))] pl-4 mb-6">
                    {{ $article->excerpt }}
                </p>

                {{-- ─ Méta + actions ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._meta')

                {{-- ─ Image principale ─ --}}
                @if ($article->hasFeatured)
                <figure class="mb-8">
                    <x-mt::image-loader
                        :src="$article->getVariantImage('large')"
                        :alt="$article->title"
                        class="w-full h-auto rounded-2xl"
                    />
                    <figcaption class="flex items-center gap-2 mt-2.5 pl-2 text-xs
                                        text-gray-400 dark:text-white/30
                                        border-l-2 border-[rgb(var(--mt-secondary))]">
                        {{ $article->image->title ?? "Photo d'illustration" }}
                    </figcaption>
                </figure>
                @endif

                {{-- ─ À retenir ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._takeaways')

                {{-- ─ Corps ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._content')

                {{-- ─ Réactions ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._reactions')

                {{-- ─ Tags + similaires ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._tags-and-similar')

                {{-- ─ Newsletter ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._newsletter-cta')

                {{-- ─ Encadré auteur ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._author-box')

                {{-- ─ Précédent / Suivant ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._post-nav')

                {{-- ─ Commentaires ─ --}}
                @include('mtblog::livewire.pages.article-show.partials._comments')

            </article>
        </div>

        {{-- ══ SIDEBAR (sticky) ════════════════════════════════════ --}}
        <aside class="lg:col-span-4">
            <div class="sticky top-28 flex flex-col gap-5 max-h-[calc(100vh-8rem)] overflow-y-auto pr-0.5">

                {{-- TOC --}}
                @if($hasToc)
                @include('mtblog::livewire.pages.article-show.partials._toc', [
                    'tocId'       => 'toc-desktop',
                    'collapsible' => true,
                ])
                @endif

                {{-- Infos article --}}
                @if($hasArticleInfo)
                @include('mtblog::livewire.pages.article-show.partials._article-info')
                @endif

                {{-- Plus lus de la rubrique --}}
                @include('mtblog::livewire.pages.article-show.partials._popular-category')

                {{-- Partage --}}
                @include('mtblog::livewire.pages.article-show.partials._share-panel')

            </div>
        </aside>
    </div>

    {{-- ══ À LIRE AUSSI ═══════════════════════════════════════════ --}}
    @if ($hasReadAlso && $this->others_articles?->count() > 0)
    <div class="pt-12 mt-14 border-t border-gray-100 dark:border-white/6" wire:ignore>
        <h2 class="text-lg font-bold text-gray-900 dark:text-white mb-6">À lire aussi</h2>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->others_articles as $a)
            <x-mtblog::post.card :article="$a" />
            @endforeach
        </div>
    </div>
    @endif

</div>

@include('mtblog::livewire.pages.article-show.partials._toc-script')
