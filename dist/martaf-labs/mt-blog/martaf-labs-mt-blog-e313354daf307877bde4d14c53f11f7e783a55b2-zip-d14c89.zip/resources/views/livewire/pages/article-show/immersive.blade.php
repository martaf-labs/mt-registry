{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : immersive                                              ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : hero plein écran → contenu centré colonne unique    ║
║  Usage     : lifestyle, voyage, photo, magazine premium          ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $article->title)
    @section('og_url',         mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]))
    @section('og_title',       $article->title)
    @section('og_description', $article->excerpt)
    @section('og_image',       $article->getVariantImage('small'))

    {{-- Barre de progression lecture --}}
    <div class="fixed top-0 left-0 right-0 z-50 h-[3px] pointer-events-none">
        <div id="reading-progress" class="h-full bg-[rgb(var(--mt-secondary))] transition-all duration-100" style="width:0%"></div>
    </div>

    {{-- ══ HERO PLEIN ÉCRAN ════════════════════════════════════════ --}}
    <div class="relative -mx-4 sm:-mx-6 lg:-mx-8 mb-12 h-[55vh] lg:h-[70vh] overflow-hidden">

        @if ($article->hasFeatured)
        <img src="{{ $article->getVariantImage('large') }}" alt="{!! $article->title !!}"
             class="absolute inset-0 w-full h-full object-cover">
        @else
        <div class="absolute inset-0 bg-gradient-to-br from-gray-900 to-gray-700"></div>
        @endif

        <div class="absolute inset-0 bg-gradient-to-t from-[rgba(var(--mt-primary))] via-[rgba(var(--mt-primary) .8)] to-[rgba(var(--mt-primary), .7)]"></div>

        <div class="absolute bottom-0 left-0 right-0 px-4 sm:px-8 lg:px-16 pb-10 max-w-5xl">

            @if($hasCategory)
            <div class="flex flex-wrap items-center gap-2 mb-4">
                <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category?->slug]) }}"
                   wire:navigate
                   class="mt-bg-secondary text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                    {{ $article->categoryName }}
                </a>
                @if ($article->is_breaking_news)
                <span class="bg-amber-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">
                    <i class="fa-solid fa-bolt mr-1"></i>Flash
                </span>
                @endif
            </div>
            @endif

            <h1 class="text-2xl sm:text-3xl lg:text-5xl font-black text-white leading-tight mb-4 max-w-4xl">
                {!! $article->title !!}
            </h1>

            <div class="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-white/55">
                @if($hasAuthor)
                    @if ($article->authorName)
                    <span class="flex items-center gap-1.5 text-white/80 font-medium">
                        <i class="fa-regular fa-user text-[rgb(var(--mt-secondary))]"></i>
                        {{ $article->authorName }}
                    </span>
                    @endif
                @endif

                @if($hasDate)
                <span><i class="fa-regular fa-calendar mr-1"></i>{{ $article->publishedDate }}</span>
                @endif
                
                @if($hasReadingTime)
                    <span><i class="fa-regular fa-clock mr-1"></i>{{ $article->readingTime }} de lecture</span>
                @endif

                @if($hasViewsCount)
                    @if ($article->views_count > 0)
                    <span><i class="fa-regular fa-eye mr-1"></i>{{ $article->viewsCount(true) }}</span>
                    @endif
                @endif
            </div>
        </div>
    </div>

    {{-- ══ CONTENU CENTRÉ ══════════════════════════════════════════ --}}
    <div class="max-w-4xl mx-auto">

        <p class="text-sm lg:text-md font-semibold mt-text text-justify mb-8
                   border-b border-gray-100 dark:border-white/6 pb-8">
            {{ $article->excerpt }}
        </p>

        @if($hasMeta)
        {{-- Barre d'actions centrée --}}
        <div class="flex items-center justify-center mb-10"
             x-data="{ liked: {{ $isLiked ? 'true' : 'false' }}, likeCount: {{ $article->likes_count ?? 0 }} }">
            <div class="inline-flex items-center gap-1 p-1.5 mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">

                <button @click="liked=!liked; likeCount+=liked?1:-1; $wire.toggleLike()"
                    :class="liked ? 'text-red-500 bg-red-50 dark:bg-red-500/10' : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6'"
                    class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all">
                    <i :class="liked ? 'fa-solid fa-heart' : 'fa-regular fa-heart'"></i>
                    <span x-text="likeCount > 0 ? likeCount : 'J\'aime'"></span>
                </button>

                <div class="w-px h-6 bg-gray-100 dark:bg-white/8"></div>

                <a href="#comments" class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 transition-all">
                    <i class="fa-regular fa-comment"></i>
                    <span>{{ $article->comments_count ?? 0 }}</span>
                </a>

                <div class="w-px h-6 bg-gray-100 dark:bg-white/8"></div>

                <button wire:click="toggleBookmark"
                    class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm transition-all
                           {{ $isBookmarked ? 'text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/10' : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6' }}">
                    <i class="{{ $isBookmarked ? 'fa-solid' : 'fa-regular' }} fa-bookmark"></i>
                </button>

            </div>
        </div>
        @endif

        {{-- image featured --}}
         @if ($article->hasFeatured)
        <figure class="mb-8">
            <x-mt::image-loader :src="$article->getVariantImage('large')" :alt="$article->title" class="w-full h-auto rounded-2xl"/>
            <figcaption class="flex items-center gap-2 mt-2.5 pl-2 text-xs text-gray-400 dark:text-white/30 border-l-2 border-[rgb(var(--mt-secondary))]">
                {{ \Illuminate\Support\Str::ucfirst($article->image->title) ?? "Photo d'illustration" }}
            </figcaption>
        </figure>
        @endif
        

        {{-- TOC (intégré au flux) --}}
        @if ($isContentBlocks)
        <div class="p-5 mb-8 border border-gray-200 dark:border-white/8 bg-gray-50 dark:bg-white/4 rounded-2xl">
            <h3 class="flex items-center gap-2 mb-3 text-sm font-bold text-gray-700 dark:text-white/70">
                <i class="fa-solid fa-list text-[rgb(var(--mt-secondary))] text-xs"></i>
                Dans cet article
            </h3>
            <ul class="space-y-1.5 text-sm" id="toc-desktop"></ul>
        </div>
        @endif

        {{-- Corps --}}
        @include('mtblog::livewire.pages.article-show.partials._content')

        {{-- Tags + similaires --}}
        @include('mtblog::livewire.pages.article-show.partials._tags-and-similar')

        {{-- Partage --}}
        <div class="mt-10">
            @include('mtblog::livewire.pages.article-show.partials._share-panel')
        </div>

        {{-- Commentaires --}}
        @include('mtblog::livewire.pages.article-show.partials._comments')
    </div>

    {{-- À lire aussi --}}
    @if ($this->others_articles?->count() > 0)
    <div class="pt-12 mt-14 border-t border-gray-100 dark:border-white/6 max-w-5xl mx-auto">
        <h2 class="text-lg font-bold text-gray-900 dark:text-white mb-6">À lire aussi</h2>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->others_articles as $a)
            <x-mtblog::post.card :article="$a" variant="magazine" />
            @endforeach
        </div>
    </div>
    @endif
</div>

@include('mtblog::livewire.pages.article-show.partials._toc-script')
