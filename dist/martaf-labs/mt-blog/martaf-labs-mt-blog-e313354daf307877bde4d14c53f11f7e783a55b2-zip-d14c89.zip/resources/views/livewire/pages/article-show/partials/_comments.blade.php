@if($hasComments)
    {{--
    Partial : _comments.blade.php
    Section commentaires complète.
    Données : $article, $this->article_comments (paginator | null), $commentText, $replyToId, $commentPosted
    --}}

    @if ($this->article_comments !== null)
    <section id="comments" class="mt-10 pt-8 border-t border-gray-100 dark:border-white/6">

        <h2 class="flex items-center gap-2 text-lg font-bold text-gray-900 dark:text-white mb-6">
            <i class="fa-regular fa-comments text-[rgb(var(--mt-secondary))] text-base"></i>
            Commentaires
            @if ($article->comments_count > 0)
            <span class="ml-1 text-sm font-normal text-gray-400 dark:text-white/30">
                ({{ $article->comments_count }})
            </span>
            @endif
        </h2>

        {{-- Formulaire --}}
        @auth
        <div class="p-4 mb-6 mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">

            {{-- Indication de réponse --}}
            @if ($replyToId)
            <div class="flex items-center justify-between gap-2 mb-3 px-3 py-2
                        bg-[rgb(var(--mt-secondary))]/8 rounded-xl text-sm">
                <span class="text-[rgb(var(--mt-secondary))] font-medium">
                    <i class="fa-solid fa-reply text-xs mr-1"></i>
                    En réponse à un commentaire
                </span>
                <button wire:click="cancelReply"
                        class="text-gray-400 hover:text-red-500 transition-colors">
                    <i class="fa-solid fa-xmark text-xs"></i>
                </button>
            </div>
            @endif

            <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-9 h-9 rounded-xl
                            bg-gradient-to-br from-[rgb(var(--mt-primary))] to-[rgb(var(--mt-secondary))]
                            flex items-center justify-center text-white text-xs font-bold">
                    {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
                </div>
                <div class="flex-1" x-data="{ txt: @entangle('commentText') }">
                    <textarea
                        x-model="txt"
                        id="comment-input"
                        rows="3"
                        placeholder="Partagez votre opinion…"
                        class="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-white/8
                            bg-gray-50 dark:bg-white/4
                            text-sm text-gray-800 dark:text-white
                            placeholder-gray-400 dark:placeholder-white/25
                            focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/20
                            focus:border-[rgb(var(--mt-secondary))]/50
                            transition-all resize-none">
                    </textarea>

                    @error('commentText')
                    <p class="mt-1 text-xs text-red-500">{{ $message }}</p>
                    @enderror

                    @if ($commentPosted)
                    <p class="mt-1 text-xs text-green-600 dark:text-green-400">
                        <i class="fa-solid fa-check mr-1"></i>
                        @if (mtblog_config('comments.auto_approve'))
                            Votre commentaire a été publié.
                        @else
                            Merci ! Votre commentaire sera visible après modération.
                        @endif
                    </p>
                    @endif

                    <div class="flex items-center justify-between mt-2">
                        <span class="text-xs text-gray-400 dark:text-white/25">
                            Restez courtois et constructif.
                        </span>
                        {{-- Bouton actif uniquement si du texte est saisi --}}
                        <button wire:click="postComment"
                                wire:loading.attr="disabled" wire:target="postComment"
                                :disabled="! txt || ! txt.trim()"
                                class="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold
                                    text-white mt-bg-secondary rounded-xl transition-all
                                    disabled:opacity-40 disabled:cursor-not-allowed enabled:hover:opacity-90">
                            <i class="fa-solid fa-paper-plane text-xs"></i> Publier
                        </button>
                    </div>
                </div>
            </div>
        </div>
        @else
        <div class="p-5 mb-6 text-sm text-center text-gray-500 dark:text-white/40
                    border border-gray-100 bg-gray-50 dark:bg-white/4 rounded-2xl dark:border-white/6">
            <i class="fa-solid fa-lock text-[rgb(var(--mt-secondary))] text-lg mb-2 block"></i>
            <button type="button" wire:click="$dispatch('open-auth-modal')"
                    class="text-[rgb(var(--mt-secondary))] font-semibold hover:underline">
                Connectez-vous
            </button>
            pour laisser un commentaire.
        </div>
        @endauth

        {{-- Liste commentaires --}}
        @if ($this->article_comments->isEmpty())
        <div class="text-center py-10 text-gray-400 dark:text-white/25 text-sm">
            <i class="fa-regular fa-comment text-2xl block mb-2 opacity-40"></i>
            Aucun commentaire pour le moment. Soyez le premier !
        </div>
        @else
        <div class="space-y-4">
            @foreach ($this->article_comments as $comment)
            <div class="p-4 mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">
                <div class="flex items-start gap-3">

                    {{-- Avatar --}}
                    <div class="flex-shrink-0 w-9 h-9 rounded-xl
                                bg-gradient-to-br from-[rgb(var(--mt-primary))] to-[rgb(var(--mt-bg))]
                                flex items-center justify-center text-white text-xs font-bold">
                        {{ strtoupper(substr($comment->user?->name ?? 'A', 0, 2)) }}
                    </div>

                    <div class="flex-1 min-w-0">
                        {{-- En-tête --}}
                        <div class="flex items-center justify-between gap-2 mb-2">
                            <div>
                                <span class="text-sm font-semibold text-gray-800 dark:text-white">
                                    {{ $comment->user?->name ?? 'Anonyme' }}
                                </span>
                                <span class="ml-2 text-xs text-gray-400 dark:text-white/25">
                                    {{ $comment->created_at->diffForHumans() }}
                                </span>
                            </div>
                        </div>

                        {{-- Texte --}}
                        <p class="text-sm leading-relaxed text-gray-600 dark:text-white/55">
                            {{ $comment->content }}
                        </p>

                        {{-- Actions commentaire --}}
                        <div class="flex items-center gap-4 mt-3">
                            <button class="flex items-center gap-1 text-xs text-gray-400 dark:text-white/25
                                            hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                <i class="fa-regular fa-thumbs-up"></i>
                                {{ $comment->likes_count ?? 0 }}
                            </button>
                            @auth
                            <button wire:click="replyTo({{ $comment->id }})"
                                    class="flex items-center gap-1 text-xs text-gray-400 dark:text-white/25
                                            hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                <i class="fa-solid fa-reply"></i>
                                Répondre
                            </button>
                            @endauth
                        </div>

                        {{-- Réponses --}}
                        @if ($comment->replies->isNotEmpty())
                        <div class="mt-3 pl-4 border-l-2 border-gray-100 dark:border-white/6 space-y-3">
                            @foreach ($comment->replies as $reply)
                            <div class="flex items-start gap-2.5">
                                <div class="flex-shrink-0 w-7 h-7 rounded-lg
                                            bg-gray-100 dark:bg-white/8
                                            flex items-center justify-center text-gray-600 dark:text-white/50 text-[10px] font-bold">
                                    {{ strtoupper(substr($reply->user?->name ?? 'A', 0, 2)) }}
                                </div>
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-xs font-semibold text-gray-700 dark:text-white/70">
                                            {{ $reply->user?->name ?? 'Anonyme' }}
                                        </span>
                                        <span class="text-[10px] text-gray-400 dark:text-white/25">
                                            {{ $reply->created_at->diffForHumans() }}
                                        </span>
                                    </div>
                                    <p class="text-xs leading-relaxed text-gray-600 dark:text-white/50">
                                        {{ $reply->content }}
                                    </p>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        @endif

                    </div>
                </div>
            </div>
            @endforeach
        </div>

        {{-- Pagination --}}
        @if ($this->article_comments->hasPages())
        <div class="mt-6">
            {{ $this->article_comments->links() }}
        </div>
        @endif

        @endif

    </section>
    @endif
@endif

