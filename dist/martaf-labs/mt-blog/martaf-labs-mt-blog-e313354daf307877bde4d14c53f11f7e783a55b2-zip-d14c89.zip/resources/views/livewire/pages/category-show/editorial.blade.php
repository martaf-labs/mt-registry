{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT CATÉGORIE : editorial                                    ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : header sobre (sans couleur de fond forte)           ║
║              grille 8/4 : articles | sidebar sticky              ║
║              sidebar : sous-catégories + top articles            ║
║  Usage     : presse sérieuse, revue, analyse, blog de fond       ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $category->name)
    @section('og_url',         mt_get_route('home_categories_show', ['slug' => $category->slug]))
    @section('og_title',       $category->name)
    @section('og_description', $category->description)
    @section('og_image',       $this->featuredArticle?->getVariantImage('small'))

    {{-- ══ EN-TÊTE SOBRE ══════════════════════════════════════════ --}}
    <header class="mb-8 pb-6 border-b border-gray-100 dark:border-white/6">

        {{-- Fil d'ariane --}}
        <nav class="flex items-center gap-1.5 text-xs text-gray-400 dark:text-white/30 mb-4">
            <a href="{{ mt_get_route('home') }}" wire:navigate class="hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <i class="fa-solid fa-house"></i>
            </a>
            @if ($category->hasParent)
            <i class="fa-solid fa-chevron-right text-[9px]"></i>
            <a href="{{ mt_get_route('home_categories_show', ['slug' => $category->parent->slug]) }}"
               wire:navigate class="hover:text-[rgb(var(--mt-secondary))] transition-colors">
                {{ $category->parent->name }}
            </a>
            @endif
            <i class="fa-solid fa-chevron-right text-[9px]"></i>
            <span class="text-gray-600 dark:text-white/50">{{ $category->name }}</span>
        </nav>

        <div class="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
            <div>
                {{-- Trait décoratif --}}
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-8 h-[3px] rounded-full bg-[rgb(var(--mt-secondary))]"></div>
                    @if ($category->icon)
                    <i class="{{ $category->icon }} text-[rgb(var(--mt-secondary))] text-sm"></i>
                    @endif
                </div>

                <h1 class="text-3xl lg:text-5xl font-black text-gray-900 dark:text-white leading-tight mb-2">
                    {{ $category->name }}
                </h1>
                @if ($category->description)
                <p class="text-gray-500 dark:text-white/40 text-sm max-w-2xl">{{ $category->description }}</p>
                @endif
            </div>

            <div class="flex items-center gap-6 flex-shrink-0 pb-1">
                <div class="text-right">
                    <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ add_zero($this->totalCount) }}</p>
                    <p class="text-xs text-gray-400 dark:text-white/30">article{{ $this->totalCount > 1 ? 's' : '' }}</p>
                </div>
                @if ($this->subCategories->count() > 0)
                <div class="w-px h-8 bg-gray-200 dark:bg-white/10"></div>
                <div class="text-right">
                    <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ add_zero($this->subCategories->count()) }}</p>
                    <p class="text-xs text-gray-400 dark:text-white/30">rubriques</p>
                </div>
                @endif
            </div>
        </div>
    </header>

    {{-- ══ ARTICLE À LA UNE ════════════════════════════════════════ --}}
    @include('mtblog::livewire.pages.category-show.partials._featured', ['variant' => 'spotlight'])

    {{-- ══ GRILLE + SIDEBAR ════════════════════════════════════════ --}}
    <div class="grid gap-8 lg:grid-cols-12">

        {{-- Contenu principal --}}
        <div class="lg:col-span-8">
            @include('mtblog::livewire.pages.category-show.partials._filters')
            @include('mtblog::livewire.pages.category-show.partials._articles-grid', ['cardVariant' => 'editorial'])
        </div>

        {{-- Sidebar sticky --}}
        <aside class="lg:col-span-4">
            <div class="sticky top-28 flex flex-col gap-5">

                {{-- Sous-catégories (thème light) --}}
                @if ($this->subCategories->count() > 0)
                <div class="mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm overflow-hidden">
                    <div class="flex items-center gap-2 px-5 py-4 border-b border-gray-100 dark:border-white/6">
                        <i class="fa-solid fa-folder text-[rgb(var(--mt-secondary))] text-xs"></i>
                        <h3 class="text-sm font-bold text-gray-900 dark:text-white">Rubriques</h3>
                    </div>
                    <div class="p-3 flex flex-col gap-0.5">
                        <button wire:click="$set('subCategoryId', null)"
                                class="flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium w-full transition-all
                                       {{ is_null($subCategoryId)
                                           ? 'bg-[rgb(var(--mt-secondary))]/10 text-[rgb(var(--mt-secondary))]'
                                           : 'text-gray-600 dark:text-white/50 hover:bg-gray-50 dark:hover:bg-white/4' }}">
                            <span class="flex items-center gap-2">
                                <i class="fa-solid fa-layer-group text-xs opacity-60"></i>
                                Toutes les rubriques
                            </span>
                            <span class="text-xs opacity-50">{{ add_zero($this->totalCount) }}</span>
                        </button>
                        @foreach ($this->subCategories as $sub)
                        <button wire:click="$set('subCategoryId', {{ $sub->id }})"
                                class="flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium w-full transition-all
                                       {{ $subCategoryId === $sub->id
                                           ? 'bg-[rgb(var(--mt-secondary))]/10 text-[rgb(var(--mt-secondary))]'
                                           : 'text-gray-600 dark:text-white/50 hover:bg-gray-50 dark:hover:bg-white/4' }}">
                            <span class="flex items-center gap-2">
                                @if ($sub->icon)
                                <i class="{{ $sub->icon }} text-xs opacity-60"></i>
                                @endif
                                {{ $sub->name }}
                            </span>
                            @if (isset($sub->articles_count))
                            <span class="text-xs opacity-50">{{ $sub->articles_count }}</span>
                            @endif
                        </button>
                        @endforeach
                    </div>
                </div>
                @endif

                {{-- Top articles --}}
                @include('mtblog::livewire.pages.category-show.partials._top-articles')

            </div>
        </aside>

    </div>

</div>
