@if ($hasFilter)
{{--
  Partial : _filters.blade.php
  Barre de filtres : compteur + recherche + tri + toggle vue
  Données : $articles (paginator), $sort, $search, $viewMode, $subCategoryId, $subCategories
--}}

<div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-6">

    {{-- Compteur résultats --}}
    <div class="text-sm mt-text">
        <span class="font-semibold">{{ add_zero($this->articles->total()) }}</span>
        article{{ $this->articles->total() > 1 ? 's' : '' }}
        @if ($search !== '')
            pour <span class="font-medium text-[rgb(var(--mt-secondary))]">"{{ $search }}"</span>
        @elseif ($subCategoryId)
            dans <span class="font-medium text-[rgb(var(--mt-secondary))]">
                {{ $this->subCategories->firstWhere('id', $subCategoryId)?->name }}
            </span>
        @endif
        @if ($search !== '' || $subCategoryId)
        <button wire:click="resetFilters"
                class="ml-2 text-xs text-gray-400 dark:text-white/30 hover:text-red-500 dark:hover:text-red-400 transition-colors">
            <i class="fa-solid fa-xmark mr-0.5"></i> Réinitialiser
        </button>
        @endif
    </div>

    <div class="flex items-center gap-2 flex-wrap">

        {{-- Recherche dans la catégorie --}}
        <div class="relative">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-white/25 text-xs pointer-events-none"></i>
            <input
                wire:model.live.debounce.400ms="search"
                type="text"
                placeholder="Rechercher…"
                class="pl-8 pr-3 py-1.5 text-sm rounded-xl border border-gray-200 dark:border-white/8
                       bg-white dark:bg-white/4 text-gray-800 dark:text-white
                       placeholder-gray-400 dark:placeholder-white/25
                       focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/20
                       focus:border-[rgb(var(--mt-secondary))]/40 transition-all w-40"
            />
        </div>

        {{-- Tri --}}
        <div class="flex items-center gap-1 p-1 bg-gray-100 dark:bg-white/6 rounded-xl">
            @foreach ([
                'recent'  => ['label' => 'Récents',    'icon' => 'fa-clock'],
                'popular' => ['label' => 'Populaires',  'icon' => 'fa-fire'],
                'oldest'  => ['label' => 'Anciens',    'icon' => 'fa-calendar'],
            ] as $value => $option)
            <button
                wire:click="$set('sort', '{{ $value }}')"
                class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150
                       {{ $sort === $value
                           ? 'mt-bg text-[rgb(var(--mt-secondary))] shadow-sm'
                           : 'text-gray-500 dark:text-white/40 hover:text-gray-700 dark:hover:text-white/60' }}">
                <i class="fa-solid {{ $option['icon'] }}"></i>
                <span class="hidden sm:inline">{{ $option['label'] }}</span>
            </button>
            @endforeach
        </div>

        {{-- Toggle vue (grid/list) --}}
        <div class="flex items-center gap-1 p-1 bg-gray-100 dark:bg-white/6 rounded-xl">
            <button
                wire:click="$set('viewMode', 'grid')"
                class="p-1.5 rounded-lg transition-all duration-150
                       {{ $viewMode === 'grid'
                           ? 'mt-bg text-[rgb(var(--mt-secondary))] shadow-sm'
                           : 'text-gray-400 dark:text-white/30 hover:text-gray-600 dark:hover:text-white/50' }}"
                title="Vue grille">
                <i class="fa-solid fa-grip text-xs"></i>
            </button>
            <button
                wire:click="$set('viewMode', 'list')"
                class="p-1.5 rounded-lg transition-all duration-150
                       {{ $viewMode === 'list'
                           ? 'mt-bg text-[rgb(var(--mt-secondary))] shadow-sm'
                           : 'text-gray-400 dark:text-white/30 hover:text-gray-600 dark:hover:text-white/50' }}"
                title="Vue liste">
                <i class="fa-solid fa-list text-xs"></i>
            </button>
        </div>

    </div>
</div>
@endif