{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT CATÉGORIE : magazine                                     ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : header 2 colonnes (info gauche | image droite)      ║
║              grille asymétrique : 1 grande + 2 petites           ║
║              puis pagination classique                           ║
║  Usage     : magazine lifestyle, culture, sport, gastronomie     ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $category->name)
    @section('og_url',         mt_get_route('home_categories_show', ['slug' => $category->slug]))
    @section('og_title',       $category->name)
    @section('og_description', $category->description)
    @section('og_image',       $this->featuredArticle?->getVariantImage('small'))

    {{-- ══ EN-TÊTE MAGAZINE ════════════════════════════════════════ --}}
    <header class="grid lg:grid-cols-2 gap-0 overflow-hidden rounded-2xl mb-8 min-h-[240px]">

        {{-- Gauche : infos sur fond coloré --}}
        <div class="bg-[rgb(var(--mt-primary))] dark:bg-[rgb(var(--mt-bg))] text-white
                     relative overflow-hidden px-6 py-8 lg:px-10 lg:py-10 flex flex-col justify-between">

            {{-- Déco --}}
            <div class="absolute inset-0 pointer-events-none overflow-hidden">
                <div class="absolute w-48 h-48 rounded-full -bottom-12 -left-12 bg-[rgb(var(--mt-secondary))]/10 blur-2xl"></div>
            </div>

            <div class="relative">
                {{-- Fil d'ariane --}}
                <nav class="flex items-center gap-1.5 text-xs text-white/40 mb-5">
                    <a href="{{ mt_get_route('home') }}" wire:navigate class="hover:text-white transition-colors">Accueil</a>
                    @if ($category->hasParent)
                    <i class="fa-solid fa-chevron-right text-[9px]"></i>
                    <a href="{{ mt_get_route('home_categories_show', ['slug' => $category->parent->slug]) }}"
                       wire:navigate class="hover:text-white transition-colors">{{ $category->parent->name }}</a>
                    @endif
                    <i class="fa-solid fa-chevron-right text-[9px]"></i>
                    <span class="text-white/70">{{ $category->name }}</span>
                </nav>

                {{-- Icône + Titre --}}
                <div class="flex items-start gap-3 mb-3">
                    @if ($category->icon)
                    <span class="w-11 h-11 rounded-xl bg-[rgb(var(--mt-secondary))] flex items-center justify-center flex-shrink-0 mt-0.5">
                        <i class="{{ $category->icon }} text-white"></i>
                    </span>
                    @endif
                    <h1 class="text-3xl lg:text-4xl font-black leading-tight">{{ $category->name }}</h1>
                </div>

                @if ($category->description)
                <p class="text-sm text-white/55 leading-relaxed max-w-sm">{{ $category->description }}</p>
                @endif
            </div>

            {{-- Stats + sous-catégories --}}
            <div class="relative mt-6">
                <div class="flex items-center gap-6 mb-4">
                    <div>
                        <p class="text-2xl font-bold">{{ add_zero($this->totalCount) }}</p>
                        <p class="text-xs text-white/40">article{{ $this->totalCount > 1 ? 's' : '' }}</p>
                    </div>
                    @if ($this->subCategories->count() > 0)
                    <div class="w-px h-8 bg-white/10"></div>
                    <div>
                        <p class="text-2xl font-bold">{{ add_zero($this->subCategories->count()) }}</p>
                        <p class="text-xs text-white/40">rubriques</p>
                    </div>
                    @endif
                </div>

                @include('mtblog::livewire.pages.category-show.partials._subcategories', ['theme' => 'dark'])
            </div>
        </div>

        {{-- Droite : image de la une --}}
        <div class="relative bg-gray-100 dark:bg-white/4 hidden lg:block">
            @if ($this->featuredArticle?->hasFeatured)
            <img src="{{ $this->featuredArticle->getVariantImage('large') }}"
                 alt="{{ $category->name }}"
                 class="absolute inset-0 w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-[rgb(var(--mt-primary))]/30 to-transparent"></div>
            @else
            <div class="absolute inset-0 flex items-center justify-center">
                @if ($category->icon)
                <i class="{{ $category->icon }} text-6xl text-gray-200 dark:text-white/8"></i>
                @endif
            </div>
            @endif
        </div>
    </header>

    {{-- ══ ARTICLE À LA UNE (si filtre sous-catégorie actif) ══════ --}}
    @if ($subCategoryId)
        @include('mtblog::livewire.pages.category-show.partials._featured', ['variant' => 'cinematic'])
    @endif

    {{-- ══ FILTRES ══════════════════════════════════════════════════ --}}
    @include('mtblog::livewire.pages.category-show.partials._filters')

    {{-- ══ GRILLE ASYMÉTRIQUE (premiers articles) ═════════════════ --}}
    @if ($this->articles->count() >= 3 && $this->articles->currentPage() === 1 && $search === '')

    @php $items = $this->articles->items(); @endphp

    <div class="grid lg:grid-cols-5 gap-5 mb-5">

        {{-- Grande carte à gauche --}}
        <div class="lg:col-span-3">
            <x-mtblog::post.card :article="$items[0]" variant="magazine" class="h-64 lg:h-80" :show-excerpt="true" :show-actions="true" />
        </div>

        {{-- 2 petites à droite --}}
        <div class="lg:col-span-2 flex flex-col gap-5">
            <x-mtblog::post.card :article="$items[1]" variant="default" :show-actions="true" />
            @if (isset($items[2]))
            <x-mtblog::post.card :article="$items[2]" variant="default" :show-actions="true" />
            @endif
        </div>

    </div>

    {{-- Reste de la grille (à partir du 4ème) --}}
    @php $rest = array_slice($items, 3); @endphp
    @if (count($rest) > 0)
    <div wire:loading.class="opacity-50 pointer-events-none" class="transition-opacity duration-200">
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 mb-8">
            @foreach ($rest as $article)
            <x-mtblog::post.card :article="$article" variant="default" :show-actions="true" />
            @endforeach
        </div>
    </div>
    @endif

    @else

    {{-- Pages suivantes ou filtre actif : grille standard --}}
    @include('mtblog::livewire.pages.category-show.partials._articles-grid', ['cardVariant' => 'default'])

    @endif

    {{-- Pagination --}}
    @if ($this->articles->hasPages())
    <div class="mt-4">{{ $this->articles->links() }}</div>
    @endif

    {{-- Indicateur chargement --}}
    <div wire:loading class="fixed bottom-6 right-6 z-50 mt-bg-primary text-white text-sm px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2.5">
        <i class="fa-solid fa-spinner fa-spin text-[rgb(var(--mt-secondary))]"></i> Chargement…
    </div>

</div>
