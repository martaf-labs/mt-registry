{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT CATÉGORIE : immersive                                    ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : hero plein écran avec image de l'article à la une   ║
║              sous-catégories en overlay bas                      ║
║              filtres flottants + grille magazine                 ║
║  Usage     : lifestyle, voyage, sport, photo                     ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $category->name)
    @section('og_url',         mt_get_route('home_categories_show', ['slug' => $category->slug]))
    @section('og_title',       $category->name)
    @section('og_description', $category->description)
    @section('og_image',       $this->featuredArticle?->getVariantImage('small'))

    {{-- ══ HERO ════════════════════════════════════════════════════ --}}
    <div class="relative -mx-4 sm:-mx-6 lg:-mx-8 mb-10 h-[45vh] lg:h-[60vh] overflow-hidden">

        {{-- Image de fond (article à la une) --}}
        @if ($this->featuredArticle?->hasFeatured)
        <img src="{{ $this->featuredArticle->getVariantImage('large') }}"
             alt="{{ $category->name }}"
             class="absolute inset-0 w-full h-full object-cover">
        @else
        <div class="absolute inset-0 bg-gradient-to-br from-[rgb(var(--mt-primary))] to-[rgb(var(--mt-bg))]"></div>
        @endif

        {{-- Overlays --}}
        <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/20"></div>
        <div class="absolute inset-0 bg-gradient-to-b from-black/30 to-transparent"></div>

        {{-- Contenu hero --}}
        <div class="absolute inset-0 flex flex-col justify-between px-4 sm:px-8 lg:px-12 py-6 lg:py-10">

            @if ($hasBreadcrumb)
            {{-- Haut : fil d'ariane --}}
            <nav class="flex items-center gap-1.5 text-xs text-white/50">
                <a href="{{ mt_get_route('home') }}" wire:navigate class="hover:text-white transition-colors">Accueil</a>
                <i class="fa-solid fa-chevron-right text-[9px]"></i>
                @if ($category->hasParent)
                <a href="{{ mt_get_route('home_categories_show', ['slug' => $category->parent->slug]) }}"
                   wire:navigate class="hover:text-white transition-colors">{{ $category->parent->name }}</a>
                <i class="fa-solid fa-chevron-right text-[9px]"></i>
                @endif
                <span class="text-white/80">{{ $category->name }}</span>
            </nav>            
            @endif

            {{-- Bas : titre + stats + sous-catégories --}}
            <div class="flex flex-col gap-4">

                <div class="flex items-end justify-between gap-4 flex-wrap">
                    <div>
                        @if ($hasIcon && $category->icon)
                        <div class="flex items-center gap-2.5 mb-2">
                            <span class="w-8 h-8 rounded-xl bg-[rgb(var(--mt-secondary))] flex items-center justify-center">
                                <i class="{{ $category->icon }} text-white text-sm"></i>
                            </span>
                        </div>
                        @endif
                        <h1 class="text-3xl lg:text-5xl font-black text-white leading-tight">
                            {{ $category->name }}
                        </h1>
                        @if ($category->description)
                        <p class="text-white/55 text-sm mt-1.5 max-w-lg hidden sm:block">{{ $category->description }}</p>
                        @endif
                    </div>

                    <div class="flex items-center gap-5 flex-shrink-0">
                        <div class="text-center">
                            <p class="text-2xl lg:text-3xl font-bold text-white">{{ add_zero($this->totalCount) }}</p>
                            <p class="text-[11px] text-white/40">article{{ $this->totalCount > 1 ? 's' : '' }}</p>
                        </div>
                        @if ($this->subCategories->count() > 0)
                        <div class="w-px h-8 bg-white/15"></div>
                        <div class="text-center">
                            <p class="text-2xl lg:text-3xl font-bold text-white">{{ add_zero($this->subCategories->count()) }}</p>
                            <p class="text-[11px] text-white/40">rubriques</p>
                        </div>
                        @endif
                    </div>
                </div>

                {{-- Sous-catégories --}}
                @include('mtblog::livewire.pages.category-show.partials._subcategories', ['theme' => 'dark'])

            </div>
        </div>
    </div>

    {{-- ══ ARTICLE À LA UNE (si filtrage actif) ════════════════════ --}}
    {{-- En immersive, l'image de la une sert de hero, donc on l'affiche uniquement sous forme cinematic si filtre --}}
    @if ($subCategoryId)
        @include('mtblog::livewire.pages.category-show.partials._featured', ['variant' => 'cinematic'])
    @endif

    {{-- ══ FILTRES ══════════════════════════════════════════════════ --}}
    @include('mtblog::livewire.pages.category-show.partials._filters')

    {{-- ══ ARTICLES ════════════════════════════════════════════════ --}}
    @include('mtblog::livewire.pages.category-show.partials._articles-grid', ['cardVariant' => 'magazine'])

</div>
