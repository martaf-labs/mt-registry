{{--
  Partial : _takeaways.blade.php — encadré « À retenir »
  Source : $article->meta_data['takeaways'] (array). Masqué si absent.
  Flag : $hasTakeaways
--}}
@if (($hasTakeaways ?? false))
@php $takeaways = (array) ($article->meta_data['takeaways'] ?? []); @endphp
@if (! empty($takeaways))
<div class="mb-8 p-5 rounded-2xl border-l-4 border-[rgb(var(--mt-secondary))]
            bg-[rgb(var(--mt-secondary))]/[0.05] dark:bg-white/[0.03]">
    <h2 class="flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-gray-900 dark:text-white mb-3">
        <i class="fa-solid fa-lightbulb text-[rgb(var(--mt-secondary))]"></i> À retenir
    </h2>
    <ul class="space-y-2">
        @foreach ($takeaways as $point)
        <li class="flex items-start gap-2.5 text-sm text-gray-600 dark:text-white/60">
            <i class="fa-solid fa-check text-[rgb(var(--mt-secondary))] text-xs mt-1 flex-shrink-0"></i>
            <span>{{ $point }}</span>
        </li>
        @endforeach
    </ul>
</div>
@endif
@endif
