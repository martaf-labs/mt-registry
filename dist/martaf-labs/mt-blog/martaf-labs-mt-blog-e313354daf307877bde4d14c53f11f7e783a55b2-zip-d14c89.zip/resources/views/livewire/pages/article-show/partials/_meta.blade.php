{{--
  Partial : _meta.blade.php
  Barre méta : infos (auteur/date/lecture/vues) + actions (like/bookmark/print).
  Chaque élément est activable indépendamment via config('mtblog.article-show.options.*').
  Données : $article, $isLiked, $isBookmarked + flags $hasAuthor/$hasDate/$hasReadingTime/
            $hasViewsCount/$hasLikes/$hasBookmark/$hasPrint
--}}

@php
    // Infos (gauche) — construites selon les flags pour éviter les séparateurs orphelins.
    $metaInfos = [];
    if (($hasAuthor ?? false) && $article->authorName)
        $metaInfos[] = ['icon' => 'fa-regular fa-user', 'text' => $article->authorName, 'strong' => true];
    if ($hasDate ?? false)
        $metaInfos[] = ['icon' => 'fa-regular fa-calendar-days', 'text' => $article->publishedDate];
    if ($hasReadingTime ?? false)
        $metaInfos[] = ['icon' => 'fa-regular fa-clock', 'text' => $article->readingTime . ' de lecture'];
    if (($hasViewsCount ?? false) && $article->views_count > 0)
        $metaInfos[] = ['icon' => 'fa-regular fa-eye', 'text' => $article->viewsCount(true)];

    $hasActions = ($hasLikes ?? false) || ($hasBookmark ?? false) || ($hasPrint ?? false);
@endphp

@if (! empty($metaInfos) || $hasActions)
<div class="pb-5 mb-6 border-b border-gray-100 dark:border-white/6">
    <div class="flex flex-wrap items-center justify-between gap-4">

        {{-- Infos --}}
        @if (! empty($metaInfos))
        <div class="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-sm text-gray-500 dark:text-white/40">
            @foreach ($metaInfos as $mi)
            <span class="flex items-center gap-1.5 {{ ($mi['strong'] ?? false) ? 'font-medium text-gray-700 dark:text-white/70' : '' }}">
                <i class="{{ $mi['icon'] }} text-xs {{ ($mi['strong'] ?? false) ? 'text-[rgb(var(--mt-secondary))]' : '' }}"></i>
                {{ $mi['text'] }}
            </span>
            @endforeach
        </div>
        @endif

        {{-- Actions rapides --}}
        @if ($hasActions)
        {{-- Like + bookmark OPTIMISTES (Alpine) : feedback instantané ; le serveur persiste.
             Init depuis l'état serveur → corrects au rechargement. Invité → modale connexion. --}}
        <div class="flex items-center gap-1"
             x-data="{
                liked: {{ $isLiked ? 'true' : 'false' }},
                likeCount: {{ (int) ($article->likes_count ?? 0) }},
                bookmarked: {{ $isBookmarked ? 'true' : 'false' }},
                toggleLike() {
                    @auth
                        this.liked = !this.liked;
                        this.likeCount += this.liked ? 1 : -1;
                        $wire.toggleLike();
                    @else
                        Livewire.dispatch('open-auth-modal');
                    @endauth
                },
                toggleBookmark() {
                    @auth
                        this.bookmarked = !this.bookmarked;
                        $wire.toggleBookmark();
                    @else
                        Livewire.dispatch('open-auth-modal');
                    @endauth
                }
             }">

            @if ($hasLikes ?? false)
            <button type="button" @click="toggleLike()"
                class="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm transition-all duration-200 active:scale-95"
                :class="liked
                    ? 'text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-500/10'
                    : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-gray-700 dark:hover:text-white/60'"
                title="J'aime">
                <i :class="liked ? 'fa-solid fa-heart' : 'fa-regular fa-heart'" class="text-xs transition-transform"></i>
                <span x-show="likeCount > 0" x-text="likeCount" class="text-xs font-medium" style="display:none"></span>
            </button>
            @endif

            @if ($hasBookmark ?? false)
            <button type="button" @click="toggleBookmark()"
                class="p-2 rounded-xl transition-all duration-200 active:scale-95"
                :class="bookmarked
                    ? 'text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/10'
                    : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-[rgb(var(--mt-secondary))]'"
                :title="bookmarked ? 'Retirer des favoris' : 'Sauvegarder'">
                <i :class="bookmarked ? 'fa-solid fa-bookmark' : 'fa-regular fa-bookmark'" class="text-xs"></i>
            </button>
            @endif

            @if ($hasPrint ?? false)
            <button type="button" onclick="window.print()"
                class="p-2 rounded-xl text-gray-400 dark:text-white/30
                    hover:bg-gray-100 dark:hover:bg-white/6 hover:text-gray-700 dark:hover:text-white/60
                    transition-all duration-200"
                title="Imprimer">
                <i class="fa-solid fa-print text-xs"></i>
            </button>
            @endif

        </div>
        @endif
    </div>
</div>
@endif
