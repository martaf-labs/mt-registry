<div>

    @section('title', "$article->title")
    {{-- options de partage --}}
    @section('og_url', mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]))
    @section('og_title', "$article->title")
    @section('og_description', "$article->description")
    @section('og_image', "$article->getVariantImage('small')")

    <div class="grid gap-8 lg:grid-cols-12">

        {{-- ══════════════════════════════════════════════
             COLONNE PRINCIPALE (article)
        ══════════════════════════════════════════════ --}}
        <div class="lg:col-span-8">
            <article>

                {{-- ─── En-tête article ─── --}}
                <div class="mb-7">

                    {{-- Fil d'ariane + catégories --}}
                    <div class="hidden lg:flex flex-wrap items-center gap-2 mb-4 w-full">
                        <a href="{{ mt_get_route('home') }}" wire:navigate
                           class="text-xs text-gray-400 dark:text-white/30 hover:text-[rgb(var(--mt-secondary))] transition-colors flex items-center gap-1">
                            <i class="fa-solid fa-house text-[10px]"></i> Accueil
                        </a>
                        
                        @if($article->category)
                        <i class="fa-solid fa-chevron-right text-[10px] text-gray-300 dark:text-white/15"></i>
                        @endif

                        <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category?->hasParent ? $article->category->parent->slug : $article->category?->slug]) }}"
                           wire:navigate
                           class="hidden lg:block px-3 py-1 text-xs font-semibold text-white transition-colors rounded-full mt-bg-secondary">
                            {{ $article->category?->hasParent ? $article->category->parent->name : $article->categoryName }}
                        </a>

                        @if ($article->category?->hasParent)
                            <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category->slug]) }}"
                               wire:navigate
                               class="px-3 py-1 text-xs text-gray-600 transition-colors bg-gray-100 rounded-full dark:bg-white/8 dark:text-white/60 hover:bg-gray-200 dark:hover:bg-white/12">
                                {{ $article->categoryName }}
                            </a>
                        @endif

                        @if ($article->hasBeenUpdated)
                        <span class="mr-auto mt-2 lg:mt-auto lg:ml-auto text-xs mt-text opacity-80">
                            Mis à jour le {{ $article->updatedDate }}
                        </span>
                        @endif
                    </div>

                    <div class="mb-2 lg:hidden">
                        <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category?->slug]) }}"
                           wire:navigate
                           class="px-3 py-1 text-xs font-semibold text-white transition-colors rounded-full bg-mt-secondary">
                            {{ $article->categoryName }}
                        </a>
                    </div>
                    {{-- Titre --}}
                    <h1 class="mb-8 text-2xl font-bold text-gray-900 lg:text-3xl dark:text-white">
                        {!! $article->title !!}
                    </h1>

                    {{-- Excerpt --}}
                    <p class="text-sm lg:text-md text-justify font-semibold text-gray-600 dark:text-white/55 leading-relaxed border-l-3 border-[#BE1622] pl-2 lg:pl-4">
                        {{ $article->excerpt }}
                    </p>

                    {{-- Meta : auteur + actions --}}
                    <div class="flex-wrap items-center justify-between hidden gap-4 pt-5 mt-5 border-t border-gray-100 lg:flex dark:border-white/6">

                        {{-- Infos --}}
                        <div class="flex items-center gap-4 text-sm text-gray-500 dark:text-white/40">
                            @if ($article->authorName)
                                <span class="flex items-center gap-1.5 font-medium text-gray-700 dark:text-white/70">
                                    <i class="fa-regular fa-user text-[rgb(var(--mt-secondary))] text-xs"></i>
                                    {{ $article->authorName }}
                                </span>
                                <span>•</span>
                            @endif
                            <span class="flex items-center gap-1">
                                <i class="text-xs fa-regular fa-clock"></i>
                                {{ $article->readingTime }} de lecture
                            </span>
                            @if ($article?->views_count > 0)
                                <span>•</span>
                                <span class="flex items-center gap-1">
                                    <i class="text-xs fa-regular fa-eye"></i>
                                    {{ $article->viewsCount(true) }}
                                </span>
                            @endif
                        </div>

                        {{-- Actions --}}
                        <div class="hidden items-center  gap-1">
                            {{-- Sauvegarder --}}
                            <button class="p-2.5 rounded-xl text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-[rgb(var(--mt-secondary))] dark:hover:text-[rgb(var(--mt-secondary))] transition-all"
                                    title="Sauvegarder">
                                <i class="fa-regular fa-bookmark"></i>
                            </button>
                            {{-- Partager --}}
                            <button class="p-2.5 rounded-xl text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-[rgb(var(--mt-secondary))] dark:hover:text-[rgb(var(--mt-secondary))] transition-all"
                                    title="Partager">
                                <i class="fa-solid fa-share-nodes"></i>
                            </button>
                            {{-- Imprimer --}}
                            <button onclick="window.print()"
                                    class="p-2.5 rounded-xl text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-[rgb(var(--mt-secondary))] dark:hover:text-[rgb(var(--mt-secondary))] transition-all"
                                    title="Imprimer">
                                <i class="fa-solid fa-print"></i>
                            </button>
                        </div>
                    </div>
                </div>

                {{-- ─── Image principale ─── --}}
                @if ($article->hasFeatured)
                <figure class="mb-8 group">
                    <x-mt::image-loader :src="$article->getVariantImage('large')"  :alt="$article->title" class="w-full h-auto"/>
                    <figcaption class="flex items-center gap-2 mt-2.5 pl-1.5 text-xs text-gray-400 dark:text-white/30 border-l-2 border-[rgb(var(--mt-secondary))]">
                        {{ $article->image->title ?? 'Photo d\'illustration' }}
                    </figcaption>
                </figure>
                @endif

                {{-- ─── Contenu simple (HTML) ─── --}}
                @if (!$isContentBlocks)
                <style>
                    #content p{
                        margin: 20px auto !important;
                    }
                    #content img{
                        margin-top: 10px !important;
                        margin-bottom: 0px !important;
                        width: 100% !important;
                        height: auto !important;
                    }
                </style>
                <div id="content" class="text-sm lg:tex-md
                            prose prose-lg dark:prose-invert max-w-none
                            prose-headings:text-gray-900 dark:prose-headings:text-white
                            prose-headings:font-bold
                            prose-a:text-[rgb(var(--mt-secondary))] prose-a:no-underline hover:prose-a:underline
                            prose-strong:text-gray-900 dark:prose-strong:text-white
                            prose-blockquote:border-[#BE1622] prose-blockquote:bg-gray-50 dark:prose-blockquote:bg-white/4
                            prose-blockquote:rounded-r-xl prose-blockquote:py-1
                            prose-img:rounded-xl
                            text-gray-700 dark:text-white/70 text-justify">
                    {!! $article->content !!}
                </div>
                @endif

                {{-- ─── Contenu blocs ─── --}}
                @if ($isContentBlocks)

                {{-- Table des matières mobile --}}
                <div class="p-5 mb-8 border border-gray-200 lg:hidden bg-gray-50 dark:bg-white/4 dark:border-white/8 rounded-2xl">
                    <h3 class="flex items-center gap-2 mb-3 text-sm font-bold text-gray-700 dark:text-white/70">
                        <i class="fa-solid fa-list text-[rgb(var(--mt-secondary))] text-xs"></i>
                        Dans cet article
                    </h3>
                    <ul class="space-y-1.5 text-sm" id="toc-mobile">
                        {{-- Généré dynamiquement par JS --}}
                    </ul>
                </div>

                {{-- Corps --}}
                <div class="prose prose-lg dark:prose-invert max-w-none
                            prose-headings:text-gray-900 dark:prose-headings:text-white
                            prose-headings:font-bold prose-headings:scroll-mt-28
                            prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4
                            prose-a:text-[rgb(var(--mt-secondary))] prose-a:no-underline hover:prose-a:underline
                            prose-strong:text-[rgb(var(--mt-secondary))]
                            prose-blockquote:border-[#BE1622] prose-blockquote:not-italic
                            prose-blockquote:bg-gradient-to-r prose-blockquote:from-[#0B1A33] prose-blockquote:to-[#1A2F4F]
                            prose-blockquote:text-white prose-blockquote:rounded-2xl prose-blockquote:px-6 prose-blockquote:py-4
                            prose-img:rounded-xl
                            text-gray-700 dark:text-white/70 text-justify" id="article-body">
                    {!! $article->content_blocks !!}
                </div>
                @endif

                {{-- ─── Tags ─── --}}
                @if ($article->tags->count() > 0)
                <div class="flex flex-wrap items-center gap-2 pt-6 mt-10 border-t border-gray-100 dark:border-white/6">
                    <span class="mr-1 text-xs font-semibold tracking-wide text-gray-400 uppercase dark:text-white/30">Tags</span>
                    @foreach ($article->tags as $tag)
                        <a href="{{ $tag->url ?? '#' }}"
                           class="px-3 py-1 text-xs font-medium text-gray-600 transition-all duration-150 bg-gray-100 rounded-full dark:bg-white/6 dark:text-white/50 hover:bg-mt-secondary hover:text-white dark:hover:bg-mt-secondary dark:hover:text-white">
                            #{{ $tag->name }}
                        </a>
                    @endforeach
                </div>
                @endif

                {{-- ─── Articles similaires ─── --}}
                @if ($this->similar_articles->count() > 0)
                <x-templates.guest.section title="Articles similaires" class="overflow-hidden border border-gray-100 shadow-sm mt-bg rounded-2xl dark:border-white/6">

                    <div class="divide-y divide-gray-100 dark:divide-white/5">
                        @foreach ($this->similar_articles as $similarArticle)
                        <a href="{{ mt_get_route('home_articles_show', ['slug' => $similarArticle->slug, 'id' => $similarArticle->id]) }}"
                           wire:navigate
                           class="flex items-center gap-4 px-5 py-3.5 hover:bg-gray-50 dark:hover:bg-white/4 transition-colors group">
                            <span class="text-2xl font-black text-[rgb(var(--mt-secondary))]/20 dark:text-[rgb(var(--mt-secondary))]/15 w-7 text-center flex-shrink-0 group-hover:text-[rgb(var(--mt-secondary))]/40 transition-colors select-none">
                                {{ str_pad($loop->index + 1, 2, '0', STR_PAD_LEFT) }}
                            </span>
                            <div class="flex-1 min-w-0">
                                <h4 class="font-medium text-sm text-gray-700 dark:text-white/70 line-clamp-2 leading-snug group-hover:text-[rgb(var(--mt-secondary))] dark:group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                    {!! $similarArticle->title !!}
                                </h4>
                                <span class="text-xs text-gray-400 dark:text-white/25 mt-0.5 block">{{ $similarArticle->publishedThere }}</span>
                            </div>
                            <i class="fa-solid fa-chevron-right text-[10px] text-gray-300 dark:text-white/15 flex-shrink-0 group-hover:text-[rgb(var(--mt-secondary))] transition-colors"></i>
                        </a>
                        @endforeach
                    </div>
                </x-templates.guest.section>
                @endif

                {{-- ─── Commentaires ─── --}}
                @if ($this->article_comments !== null)
                <x-templates.guest.section title="Commentaires" description="Rejoignez la discussion" class="pt-8 mt-10 border-t border-gray-100 dark:border-white/6" style="display: none">
                    {{-- Formulaire --}}
                    @auth
                    <div class="p-4 mb-6 border border-gray-100 shadow-sm mt-bg rounded-2xl dark:border-white/6">
                        <div class="flex items-start gap-3">
                            <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-[#0B1A33] to-[#BE1622] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                                {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
                            </div>
                            <div class="flex-1">
                                <textarea rows="3"
                                          placeholder="Partagez votre opinion…"
                                          class="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-white/8 bg-gray-50 dark:bg-white/4 text-sm text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-white/25 focus:outline-none focus:ring-2 focus:ring-[#BE1622]/20 focus:border-[#BE1622]/50 transition-all resize-none"></textarea>
                                <div class="flex justify-end mt-2">
                                    <button class="px-4 py-2 text-sm font-semibold text-white transition-colors bg-mt-secondary rounded-xl">
                                        <i class="fa-solid fa-paper-plane text-xs mr-1.5"></i> Publier
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @else
                    <div class="p-5 mb-6 text-sm text-center text-gray-500 border border-gray-100 bg-gray-50 dark:bg-white/4 rounded-2xl dark:border-white/6 dark:text-white/40">
                        <i class="fa-regular fa-lock text-[rgb(var(--mt-secondary))] text-lg mb-2 block"></i>
                        <a href="{{ route('login') ?? '#' }}" class="text-[rgb(var(--mt-secondary))] font-semibold hover:underline">Connectez-vous</a> pour laisser un commentaire.
                    </div>
                    @endauth

                    {{-- Liste commentaires --}}
                    <div class="space-y-4">
                        @foreach ($this->article_comments->approved()->latest()->take(10)->get() as $comment)
                        <div class="p-4 border border-gray-100 shadow-sm mt-bg rounded-2xl dark:border-white/6">
                            <div class="flex items-start gap-3">
                                <div class="w-9 h-9 rounded-xl bg-[rgb(var(--mt-primary))] dark:bg-[rgb(var(--mt-bg))] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                                    {{ strtoupper(substr($comment->user?->name ?? 'A', 0, 2)) }}
                                </div>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center justify-between gap-2 mb-1.5">
                                        <h4 class="text-sm font-semibold text-gray-800 dark:text-white">{{ $comment->user?->name ?? 'Anonyme' }}</h4>
                                        <span class="flex-shrink-0 text-xs text-gray-400 dark:text-white/25">{{ $comment->created_at->diffForHumans() }}</span>
                                    </div>
                                    <p class="text-sm leading-relaxed text-gray-600 dark:text-white/55">{{ $comment->content }}</p>
                                    <div class="flex items-center gap-4 mt-2.5">
                                        <button class="flex items-center gap-1 text-xs text-gray-400 dark:text-white/25 hover:text-[rgb(var(--mt-secondary))] dark:hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                            <i class="fa-regular fa-thumbs-up"></i>
                                            {{ $comment->likes_count ?? 0 }}
                                        </button>
                                        <button class="flex items-center gap-1 text-xs text-gray-400 dark:text-white/25 hover:text-[rgb(var(--mt-secondary))] dark:hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                            <i class="fa-regular fa-comment"></i>
                                            Répondre
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </x-templates.guest.section>
                @endif

            </article>
        </div>

        {{-- ══════════════════════════════════════════════
             SIDEBAR DROITE (sticky)
        ══════════════════════════════════════════════ --}}
        <aside class="lg:col-span-4">
            <div class="sticky top-28 space-y-5 max-h-[calc(100vh-8rem)] overflow-y-auto pr-0.5">

                {{-- Table des matières desktop --}}
                @if ($isContentBlocks)
                <div class="overflow-hidden border border-gray-100 shadow-sm mt-bg rounded-2xl dark:border-white/6">
                    <div class="flex items-center gap-2 px-5 py-4 border-b border-gray-100 dark:border-white/6">
                        <i class="fa-solid fa-list text-[rgb(var(--mt-secondary))] text-xs"></i>
                        <h3 class="text-sm font-bold text-gray-900 dark:text-white">Dans cet article</h3>
                    </div>
                    <ul class="p-3 space-y-0.5 text-sm" id="toc-desktop">
                        {{-- Généré dynamiquement par JS --}}
                    </ul>
                </div>
                @endif

                {{-- Partage réseaux --}}
                <div class="hidden p-5 border border-gray-100 shadow-sm mt-bg rounded-2xl dark:border-white/6">
                    <h3 class="flex items-center gap-2 mb-3 text-sm font-bold text-gray-900 dark:text-white">
                        <i class="fa-solid fa-share-nodes text-[rgb(var(--mt-secondary))] text-xs"></i>
                        Partager l'article
                    </h3>
                    <div class="grid grid-cols-2 gap-2">
                        <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(url()->current()) }}"
                           target="_blank"
                           class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#1877F2]/10 text-[#1877F2] text-xs font-semibold hover:bg-[#1877F2] hover:text-white transition-all duration-200">
                            <i class="fa-brands fa-facebook-f"></i> Facebook
                        </a>
                        <a href="https://twitter.com/intent/tweet?url={{ urlencode(url()->current()) }}&text={{ urlencode($article->title) }}"
                           target="_blank"
                           class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-black/6 dark:bg-white/6 text-gray-800 dark:text-white text-xs font-semibold hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all duration-200">
                            <i class="fa-brands fa-x-twitter"></i> Twitter / X
                        </a>
                        <a href="https://wa.me/?text={{ urlencode($article->title . ' ' . url()->current()) }}"
                           target="_blank"
                           class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#25D366]/10 text-[#25D366] text-xs font-semibold hover:bg-[#25D366] hover:text-white transition-all duration-200">
                            <i class="fa-brands fa-whatsapp"></i> WhatsApp
                        </a>
                        <button onclick="navigator.clipboard.writeText('{{ url()->current() }}').then(() => this.textContent='Copié !')"
                                class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-gray-100 dark:bg-white/6 text-gray-600 dark:text-white/50 text-xs font-semibold hover:bg-gray-200 dark:hover:bg-white/12 transition-all duration-200">
                            <i class="fa-solid fa-link"></i> Copier le lien
                        </button>
                    </div>
                </div>

                {{-- Infos article --}}
                <div class="p-5 space-y-3 text-sm border border-gray-100 shadow-sm mt-bg rounded-2xl dark:border-white/6">
                    <h3 class="mb-1 text-sm font-bold text-gray-900 dark:text-white">À propos de cet article</h3>
                    <div class="flex items-center justify-between text-gray-500 dark:text-white/40">
                        <span class="flex items-center gap-1.5"><i class="fa-regular fa-calendar text-[rgb(var(--mt-secondary))] text-xs w-4"></i> Publié le</span>
                        <span class="font-medium text-gray-700 dark:text-white/60">{{ $article->publishedDate }}</span>
                    </div>
                    <div class="flex items-center justify-between text-gray-500 dark:text-white/40">
                        <span class="flex items-center gap-1.5"><i class="fa-regular fa-clock text-[rgb(var(--mt-secondary))] text-xs w-4"></i> Lecture</span>
                        <span class="font-medium text-gray-700 dark:text-white/60">{{ $article->readingTime }}</span>
                    </div>
                    @if ($article->views_count > 0)
                    <div class="flex items-center justify-between text-gray-500 dark:text-white/40">
                        <span class="flex items-center gap-1.5"><i class="fa-regular fa-eye text-[rgb(var(--mt-secondary))] text-xs w-4"></i> Vues</span>
                        <span class="font-medium text-gray-700 dark:text-white/60">{{ $article->viewsCount() }}</span>
                    </div>
                    @endif
                    @if ($article->comments_count > 0)
                    <div class="flex items-center justify-between text-gray-500 dark:text-white/40">
                        <span class="flex items-center gap-1.5"><i class="fa-regular fa-comment text-[rgb(var(--mt-secondary))] text-xs w-4"></i> Commentaires</span>
                        <span class="font-medium text-gray-700 dark:text-white/60">{{ $article->comments_count }}</span>
                    </div>
                    @endif
                </div>

            </div>
        </aside>
    </div>

    {{-- ══════════════════════════════════════════════
         À LIRE AUSSI (pleine largeur)
    ══════════════════════════════════════════════ --}}
    @if ($this->others_articles?->count() > 0)
    <x-templates.guest.section title="À lire aussi" class="pt-10 border-t border-gray-100 mt-14 dark:border-white/6">

        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->others_articles as $article)
            <x-mtblog::post.card :article="$article"></x-mtblog::post.card>
            @endforeach
        </div>
    </x-templates.guest.section>
    @endif

</div>

{{-- ─── Script TOC auto (Table des matières) ─── --}}
@if ($isContentBlocks)
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const body   = document.getElementById('article-body');
        const tocD   = document.getElementById('toc-desktop');
        const tocM   = document.getElementById('toc-mobile');
        if (!body) return;

        const headings = body.querySelectorAll('h2, h3');
        headings.forEach((h, i) => {
            if (!h.id) h.id = 'section-' + (i + 1);

            const tag  = h.tagName.toLowerCase();
            const link = `<a href="#${h.id}"
                            class="flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all duration-150
                                   text-gray-500 dark:text-white/40 hover:text-[rgb(var(--mt-secondary))] dark:hover:text-[rgb(var(--mt-secondary))] hover:bg-gray-50 dark:hover:bg-white/4
                                   ${tag === 'h3' ? 'pl-6 text-[13px]' : 'font-medium'}">
                            <span class="w-1 h-1 rounded-full flex-shrink-0 ${tag === 'h2' ? 'bg-mt-secondary' : 'bg-gray-300 dark:bg-white/20'}"></span>
                            ${h.textContent.trim()}
                          </a>`;
            if (tocD) tocD.insertAdjacentHTML('beforeend', `<li>${link}</li>`);
            if (tocM) tocM.insertAdjacentHTML('beforeend', `<li>${link}</li>`);
        });

        // Surlignage actif au scroll
        if (tocD && headings.length) {
            const observer = new IntersectionObserver(entries => {
                entries.forEach(e => {
                    const id   = e.target.id;
                    const link = tocD.querySelector(`a[href="#${id}"]`);
                    if (link) link.classList.toggle('!text-[rgb(var(--mt-secondary))]', e.isIntersecting);
                });
            }, { rootMargin: '-20% 0px -70% 0px' });
            headings.forEach(h => observer.observe(h));
        }
    });
</script>
@endif
