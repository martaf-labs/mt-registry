{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : magazine                                               ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : grille 7/5 → image + titre énorme en en-tête        ║
║              sidebar droite enrichie : vues live, partage,       ║
║              articles chauds, TOC                                ║
║  Usage     : presse magazine, lifestyle, culture, sport          ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $article->title)
    @section('og_url',         mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]))
    @section('og_title',       $article->title)
    @section('og_description', $article->excerpt)
    @section('og_image',       $article->getVariantImage('small'))

    {{-- Barre de progression --}}
    <div class="fixed top-0 left-0 right-0 z-50 h-[3px] pointer-events-none">
        <div id="reading-progress" class="h-full bg-[rgb(var(--mt-secondary))] transition-all duration-100" style="width:0%"></div>
    </div>

    {{-- ══ EN-TÊTE MAGAZINE ════════════════════════════════════════ --}}
    <div class="grid lg:grid-cols-12 gap-6 mb-10">

        {{-- Image grande à gauche --}}
        <div class="lg:col-span-7 relative overflow-hidden rounded-2xl
                     bg-gray-100 dark:bg-white/4
                     min-h-[300px] lg:min-h-[480px]">
            @if ($article->hasFeatured)
            <img src="{{ $article->getVariantImage('large') }}" alt="{!! $article->title !!}"
                 class="absolute inset-0 w-full h-full object-cover">
            @endif

            {{-- Légende --}}
            @if ($article->image?->title)
            <div class="absolute bottom-3 left-3 text-[10px] text-white/50 italic bg-black/30 px-2 py-1 rounded-md backdrop-blur-sm">
                {{ $article->image->title }}
            </div>
            @endif
        </div>

        {{-- Titres + méta à droite --}}
        <div class="lg:col-span-5 flex flex-col justify-between">

            {{-- Catégorie + badge --}}
            <div class="flex flex-wrap items-center gap-2 mb-4">
                <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category?->slug]) }}" wire:navigate
                   class="mt-bg-secondary text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                    {{ $article->categoryName }}
                </a>
                @if ($article->is_breaking_news)
                <span class="bg-amber-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">
                    <i class="fa-solid fa-bolt mr-1"></i>Flash
                </span>
                @endif
                @if ($article->is_pinned)
                <span class="bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                    <i class="fa-solid fa-thumbtack mr-1"></i>Épinglé
                </span>
                @endif
            </div>

            {{-- Titre --}}
            <h1 class="text-2xl lg:text-4xl font-black text-gray-900 dark:text-white leading-tight mb-4">
                {!! $article->title !!}
            </h1>

            {{-- Extrait --}}
            <p class="text-sm lg:text-base text-gray-600 dark:text-white/50 leading-relaxed mb-6">
                {{ $article->excerpt }}
            </p>

            {{-- Méta --}}
            <div class="space-y-3 text-sm">
                @if ($article->authorName)
                <div class="flex items-center gap-2.5">
                    <span class="w-8 h-8 rounded-full bg-gradient-to-br from-[rgb(var(--mt-primary))] to-[rgb(var(--mt-secondary))]
                                  flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {{ strtoupper(substr($article->authorName, 0, 2)) }}
                    </span>
                    <div>
                        <p class="font-semibold text-gray-800 dark:text-white/80 text-sm">{{ $article->authorName }}</p>
                        <p class="text-xs text-gray-400 dark:text-white/30">{{ $article->publishedDate }}</p>
                    </div>
                </div>
                @endif

                <div class="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-gray-400 dark:text-white/30 pt-2 border-t border-gray-100 dark:border-white/6">
                    <span><i class="fa-regular fa-clock mr-1"></i>{{ $article->readingTime }} de lecture</span>
                    @if ($article->views_count > 0)
                    <span><i class="fa-regular fa-eye mr-1"></i>{{ $article->viewsCount(true) }}</span>
                    @endif
                    @if ($article->likes_count > 0)
                    <span><i class="fa-regular fa-heart mr-1"></i>{{ $article->likes_count }}</span>
                    @endif
                </div>
            </div>

            {{-- Actions --}}
            <div class="flex items-center gap-2 pt-4 mt-auto"
                 x-data="{ liked: {{ $isLiked ? 'true' : 'false' }}, likeCount: {{ $article->likes_count ?? 0 }} }">

                <button @click="liked=!liked; likeCount+=liked?1:-1; $wire.toggleLike()"
                    :class="liked ? 'text-red-500 bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20' : 'border-gray-200 dark:border-white/10 text-gray-500 dark:text-white/40 hover:border-[rgb(var(--mt-secondary))]/30'"
                    class="flex items-center gap-1.5 px-4 py-2 rounded-xl border text-sm font-medium transition-all">
                    <i :class="liked ? 'fa-solid fa-heart' : 'fa-regular fa-heart'"></i>
                    <span x-text="likeCount"></span>
                </button>

                <a href="#comments"
                   class="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-sm font-medium text-gray-500 dark:text-white/40 hover:border-[rgb(var(--mt-secondary))]/30 transition-all">
                    <i class="fa-regular fa-comment"></i>
                    {{ $article->comments_count ?? 0 }}
                </a>

                <button wire:click="toggleBookmark"
                    class="flex items-center gap-1.5 px-4 py-2 rounded-xl border text-sm font-medium transition-all
                           {{ $isBookmarked
                            ? 'border-[rgb(var(--mt-secondary))]/30 text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/8'
                            : 'border-gray-200 dark:border-white/10 text-gray-500 dark:text-white/40 hover:border-[rgb(var(--mt-secondary))]/30' }}">
                    <i class="{{ $isBookmarked ? 'fa-solid' : 'fa-regular' }} fa-bookmark"></i>
                </button>

                <button onclick="window.print()"
                    class="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-sm font-medium text-gray-500 dark:text-white/40 hover:border-gray-300 transition-all ml-auto">
                    <i class="fa-solid fa-print"></i>
                </button>

            </div>

        </div>
    </div>

    {{-- ══ CONTENU + SIDEBAR ════════════════════════════════════════ --}}
    <div class="grid gap-8 lg:grid-cols-12">

        {{-- Contenu --}}
        <div class="lg:col-span-8">
            <article>
                @include('mtblog::livewire.pages.article-show.partials._content')
                @include('mtblog::livewire.pages.article-show.partials._tags-and-similar')
                @include('mtblog::livewire.pages.article-show.partials._comments')
                
            </article>
        </div>

        {{-- Sidebar --}}
        <aside class="lg:col-span-4">
            <div class="sticky top-28 flex flex-col gap-5">
                @include('mtblog::livewire.pages.article-show.partials._toc', ['tocId' => 'toc-desktop', 'collapsible' => true])
                @include('mtblog::livewire.pages.article-show.partials._article-info')
                @include('mtblog::livewire.pages.article-show.partials._share-panel')
            </div>
        </aside>

    </div>

    {{-- À lire aussi --}}
    @if ($this->others_articles?->count() > 0)
    <div class="pt-12 mt-14 border-t border-gray-100 dark:border-white/6">
        <h2 class="text-lg font-bold text-gray-900 dark:text-white mb-6">À lire aussi</h2>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->others_articles as $a)
            <x-mtblog::post.card :article="$a" variant="spotlight" :show-read-more="true" />
            @endforeach
        </div>
    </div>
    @endif

</div>

@include('mtblog::livewire.pages.article-show.partials._toc-script')
