@if($hasShare)
    {{--
    Partial : _share-panel.blade.php
    Panneau de partage réseaux sociaux.
    Usage   : @include('mtblog::livewire.pages.article-show._share-panel')
    Données : $article (slug, id, title)
    --}}

    @php
        $shareUrl   = urlencode(mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]));
        $shareTitle = urlencode(strip_tags($article->title));
        $networks   = [
            ['label' => 'Facebook',  'icon' => 'fa-brands fa-facebook-f',   'color' => '#1877F2', 'bg' => '#E7F0FD', 'url' => "https://www.facebook.com/sharer/sharer.php?u={$shareUrl}"],
            ['label' => 'Twitter/X', 'icon' => 'fa-brands fa-x-twitter',    'color' => '#0F1419', 'bg' => '#F0F0F0', 'url' => "https://twitter.com/intent/tweet?url={$shareUrl}&text={$shareTitle}"],
            ['label' => 'WhatsApp',  'icon' => 'fa-brands fa-whatsapp',     'color' => '#25D366', 'bg' => '#E8F9EE', 'url' => "https://wa.me/?text={$shareTitle}%20{$shareUrl}"],
            ['label' => 'Telegram',  'icon' => 'fa-brands fa-telegram',     'color' => '#2AABEE', 'bg' => '#E8F5FC', 'url' => "https://t.me/share/url?url={$shareUrl}&text={$shareTitle}"],
            ['label' => 'LinkedIn',  'icon' => 'fa-brands fa-linkedin-in',  'color' => '#0A66C2', 'bg' => '#E8F0F9', 'url' => "https://www.linkedin.com/sharing/share-offsite/?url={$shareUrl}"],
        ];
    @endphp

    <div class="p-5 mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">

        <h3 class="flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-white mb-4">
            <i class="fa-solid fa-share-nodes text-[rgb(var(--mt-secondary))] text-xs"></i>
            Partager l'article
        </h3>

        <div class="flex flex-col gap-1.5">
            @foreach ($networks as $network)
            <a href="{{ $network['url'] }}"
            target="_blank"
            rel="noopener noreferrer"
            wire:click="recordShare('{{ strtolower($network['label']) }}')"
            class="flex items-center gap-3 px-3 py-2.5 rounded-xl
                    hover:bg-gray-50 dark:hover:bg-white/4
                    transition-colors duration-150 group">
                <span class="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center"
                    style="background: {{ $network['bg'] }}">
                    <i class="{{ $network['icon'] }} text-[12px]" style="color: {{ $network['color'] }}"></i>
                </span>
                <span class="text-sm font-medium text-gray-700 dark:text-white/60
                            group-hover:text-gray-900 dark:group-hover:text-white transition-colors">
                    {{ $network['label'] }}
                </span>
            </a>
            @endforeach

            {{-- Copier le lien --}}
            <div class="h-px bg-gray-100 dark:bg-white/6 my-1"></div>
            <button
                x-data="{ copied: false }"
                @click="navigator.clipboard.writeText('{{ urldecode($shareUrl) }}').then(() => { copied = true; setTimeout(() => copied = false, 2000) })"
                class="flex items-center gap-3 px-3 py-2.5 rounded-xl w-full
                    hover:bg-gray-50 dark:hover:bg-white/4
                    transition-colors duration-150 group">
                <span class="flex-shrink-0 w-8 h-8 rounded-lg bg-gray-100 dark:bg-white/8 flex items-center justify-center">
                    <i :class="copied ? 'fa-solid fa-check text-green-500' : 'fa-solid fa-link text-gray-400 dark:text-white/30'"
                    class="text-[12px] transition-all duration-200"></i>
                </span>
                <span x-text="copied ? 'Lien copié !' : 'Copier le lien'"
                    :class="copied ? 'text-green-600 dark:text-green-400' : 'text-gray-700 dark:text-white/60 group-hover:text-gray-900 dark:group-hover:text-white'"
                    class="text-sm font-medium transition-colors"></span>
            </button>
        </div>
    </div>
@endif