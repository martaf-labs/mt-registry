{{--
  Partial : _content.blade.php
  Corps de l'article (HTML simple ou blocs).
  Données : $article, $isContentBlocks
--}}

@if (! $isContentBlocks)

{{-- Contenu HTML classique --}}
<style>
    #content p      { margin: 20px auto !important; }
    #content img    { margin-top:10px !important; margin-bottom:0 !important; width:100% !important; height:auto !important; }
</style>
<div id="content"
     class="prose prose-lg dark:prose-invert max-w-none text-justify
            prose-headings:text-gray-900 dark:prose-headings:text-white
            prose-headings:font-bold prose-headings:scroll-mt-28
            prose-a:text-[rgb(var(--mt-secondary))] prose-a:no-underline hover:prose-a:underline
            prose-strong:text-gray-900 dark:prose-strong:text-white
            prose-blockquote:border-[rgb(var(--mt-secondary))] prose-blockquote:bg-gray-50 dark:prose-blockquote:bg-white/4
            prose-blockquote:rounded-r-xl prose-blockquote:py-1
            prose-img:rounded-xl
            text-gray-700 dark:text-white/70 text-sm lg:text-base">
    {!! $article->content !!}
</div>

@else

{{-- Table des matières mobile (avant les blocs) --}}
<div class="p-5 mb-8 border border-gray-200 dark:border-white/8
             bg-gray-50 dark:bg-white/4 rounded-2xl lg:hidden">
    <h3 class="flex items-center gap-2 mb-3 text-sm font-bold text-gray-700 dark:text-white/70">
        <i class="fa-solid fa-list text-[rgb(var(--mt-secondary))] text-xs"></i>
        Dans cet article
    </h3>
    <ul class="space-y-1.5 text-sm" id="toc-mobile"></ul>
</div>

{{-- Contenu blocs --}}
<div id="article-body"
     class="prose prose-lg dark:prose-invert max-w-none text-justify
            prose-headings:text-gray-900 dark:prose-headings:text-white
            prose-headings:font-bold prose-headings:scroll-mt-28
            prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4
            prose-a:text-[rgb(var(--mt-secondary))] prose-a:no-underline hover:prose-a:underline
            prose-strong:text-[rgb(var(--mt-secondary))]
            prose-blockquote:border-[rgb(var(--mt-secondary))] prose-blockquote:not-italic
            prose-blockquote:bg-gradient-to-r prose-blockquote:from-[rgb(var(--mt-primary))] prose-blockquote:to-[rgb(var(--mt-primary))]/80
            prose-blockquote:text-white prose-blockquote:rounded-2xl prose-blockquote:px-6 prose-blockquote:py-4
            prose-img:rounded-xl
            text-gray-700 dark:text-white/70 text-sm lg:text-base">
    {!! $article->content_blocks !!}
</div>

@endif
