{{--
  Partial : _article-info.blade.php
  Widget "À propos de cet article" pour sidebar.
  Données : $article
--}}

<div class="p-5 space-y-3 text-sm mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">

    <h3 class="text-sm font-bold text-gray-900 dark:text-white mb-3">
        À propos de cet article
    </h3>

    @php
        $infos = [
            ['icon' => 'fa-regular fa-calendar-days', 'label' => 'Publié le',      'value' => $article->publishedDate],
            ['icon' => 'fa-regular fa-clock',          'label' => 'Lecture',        'value' => $article->readingTime],
        ];
        if ($article->views_count > 0)
            $infos[] = ['icon' => 'fa-regular fa-eye',  'label' => 'Vues',          'value' => $article->viewsCount()];
        if ($article->likes_count > 0)
            $infos[] = ['icon' => 'fa-regular fa-heart', 'label' => "J'aime",       'value' => $article->likes_count];
        if ($article->comments_count > 0)
            $infos[] = ['icon' => 'fa-regular fa-comment', 'label' => 'Commentaires', 'value' => $article->comments_count];
        if ($article->shares_count > 0)
            $infos[] = ['icon' => 'fa-regular fa-share-from-square', 'label' => 'Partages', 'value' => $article->shares_count];
    @endphp

    @foreach ($infos as $info)
    <div class="flex items-center justify-between text-gray-500 dark:text-white/40">
        <span class="flex items-center gap-2">
            <i class="{{ $info['icon'] }} text-[rgb(var(--mt-secondary))] text-xs w-4 text-center"></i>
            {{ $info['label'] }}
        </span>
        <span class="font-medium text-gray-700 dark:text-white/60">{{ $info['value'] }}</span>
    </div>
    @endforeach

</div>
