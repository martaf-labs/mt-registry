{{--
  Partial : _featured.blade.php
  Article à la une de la catégorie.
  Props : $variant  'spotlight' | 'cinematic' (défaut: 'spotlight')
  Données : $featuredArticle, $subCategoryId
--}}

@props(['variant' => 'spotlight'])

@if ($this->featuredArticle && is_null($subCategoryId))

@php
    $f   = $this->featuredArticle;
    $url = mt_get_route('home_articles_show', ['slug' => $f->slug, 'id' => $f->id]);
@endphp

@if ($variant === 'cinematic')

    {{-- ── Cinematic : image plein, overlay gradient ─────────────── --}}
    <div class="relative overflow-hidden rounded-2xl group h-72 lg:h-96 mb-8">

        @if ($f->hasFeatured)
        <a href="{{ $url }}" wire:navigate class="absolute inset-0">
            <img src="{{ $f->getVariantImage('large') }}" alt="{!! $f->title !!}"
                 class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105">
        </a>
        @endif

        <div class="absolute inset-0 bg-gradient-to-t from-black/88 via-black/20 to-transparent pointer-events-none"></div>

        <div class="absolute bottom-0 left-0 right-0 p-5 lg:p-8 flex flex-col gap-2">
            <span class="self-start mt-bg-secondary text-white text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                {{ $f->categoryName }}
            </span>
            <h2 class="font-black text-xl lg:text-3xl text-white leading-tight line-clamp-2 max-w-3xl
                        group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <a href="{{ $url }}" wire:navigate>{!! $f->title !!}</a>
            </h2>
            <p class="hidden sm:block text-white/60 text-sm line-clamp-2 max-w-2xl">{{ $f->excerpt }}</p>
            <div class="flex items-center gap-3 text-xs text-white/45">
                <span><i class="fa-regular fa-clock mr-1"></i>{{ $f->publishedThere }}</span>
                <span>•</span>
                <span>{{ $f->readingTime }}</span>
                @if ($f->views_count > 0)
                <span>•</span>
                <span><i class="fa-regular fa-eye mr-1"></i>{{ $f->viewsCount(true) }}</span>
                @endif
            </div>
        </div>
    </div>

@else

    {{-- ── Spotlight : image gauche + contenu droite ──────────────── --}}
    <div class="mb-8">
        <a href="{{ $url }}" wire:navigate
           class="relative flex flex-col lg:flex-row overflow-hidden rounded-2xl group
                  bg-[rgb(var(--mt-primary))] dark:bg-[rgb(var(--mt-bg))]
                  hover:shadow-lg transition-all duration-300">

            {{-- Image --}}
            <div class="relative flex-shrink-0 h-64 lg:w-3/5 lg:h-auto overflow-hidden">
                <x-mt::image-loader :src="$f->getVariantImage('large')" :alt="$f->title"
                    class="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"/>

                {{-- Overlay latéral desktop --}}
                <div class="absolute inset-0 bg-gradient-to-r from-transparent to-[rgb(var(--mt-bg))]/80 hidden lg:block"></div>
                {{-- Overlay bas mobile --}}
                <div class="absolute inset-0 bg-gradient-to-t from-[rgb(var(--mt-primary))]/70 to-transparent lg:hidden"></div>

                {{-- Badge catégorie --}}
                <span class="absolute top-4 left-4 mt-bg-secondary text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                    {{ $f->categoryName }}
                </span>
            </div>

            {{-- Contenu --}}
            <div class="flex flex-col justify-center text-white p-5 lg:p-8">

                <div class="flex items-center gap-2 mb-3 text-xs text-white/50">
                    <span>{{ $f->publishedThere }}</span>
                    <span>•</span>
                    <span>{{ $f->readingTime }}</span>
                    @if ($f->views_count > 0)
                    <span>•</span>
                    <span><i class="fa-regular fa-eye mr-0.5"></i>{{ $f->viewsCount(true) }}</span>
                    @endif
                </div>

                <h2 class="mb-3 text-xl lg:text-2xl font-bold leading-snug
                            group-hover:text-[rgb(var(--mt-secondary))] transition-colors duration-200 line-clamp-3">
                    {!! $f->title !!}
                </h2>

                <p class="mb-5 text-sm leading-relaxed text-white/60 line-clamp-3">
                    {{ $f->excerpt }}
                </p>

                <span class="inline-flex items-center gap-2 text-sm font-semibold text-[rgb(var(--mt-secondary))]
                              group-hover:gap-3 transition-all duration-200">
                    Lire l'article <i class="fa-solid fa-arrow-right text-xs"></i>
                </span>
            </div>
        </a>
    </div>

@endif

@endif
