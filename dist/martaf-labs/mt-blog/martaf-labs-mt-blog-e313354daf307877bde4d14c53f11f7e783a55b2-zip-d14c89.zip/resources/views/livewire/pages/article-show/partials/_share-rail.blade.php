{{--
  Partial : _share-rail.blade.php — rail de partage flottant (vertical, gauche, xl+)
  Apparaît après défilement. Flag : $hasShareFloat. Réutilise recordShare().
--}}
@if (($hasShareFloat ?? false))
@php
    $shareUrl   = urlencode(mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]));
    $shareTitle = urlencode(strip_tags($article->title));
    $rail = [
        ['fa' => 'fa-brands fa-facebook-f',  'label' => 'facebook', 'url' => "https://www.facebook.com/sharer/sharer.php?u={$shareUrl}"],
        ['fa' => 'fa-brands fa-x-twitter',   'label' => 'twitter',  'url' => "https://twitter.com/intent/tweet?url={$shareUrl}&text={$shareTitle}"],
        ['fa' => 'fa-brands fa-whatsapp',    'label' => 'whatsapp', 'url' => "https://wa.me/?text={$shareTitle}%20{$shareUrl}"],
        ['fa' => 'fa-brands fa-linkedin-in', 'label' => 'linkedin', 'url' => "https://www.linkedin.com/sharing/share-offsite/?url={$shareUrl}"],
    ];
@endphp
<div x-data="{ show: false }"
     x-init="window.addEventListener('scroll', () => { show = window.scrollY > 400 })"
     :class="show ? 'opacity-100' : 'opacity-0 pointer-events-none'"
     class="hidden xl:flex fixed left-6 top-1/2 -translate-y-1/2 z-30 flex-col gap-2 transition-opacity duration-300">
    @foreach ($rail as $n)
    <a href="{{ $n['url'] }}" target="_blank" rel="noopener noreferrer"
       wire:click="recordShare('{{ $n['label'] }}')"
       class="w-10 h-10 rounded-full flex items-center justify-center mt-bg
              border border-gray-100 dark:border-white/8 shadow-sm
              text-gray-500 dark:text-white/50
              hover:text-white hover:bg-[rgb(var(--mt-secondary))] hover:border-transparent transition-all"
       title="Partager">
        <i class="{{ $n['fa'] }} text-sm"></i>
    </a>
    @endforeach
</div>
@endif
