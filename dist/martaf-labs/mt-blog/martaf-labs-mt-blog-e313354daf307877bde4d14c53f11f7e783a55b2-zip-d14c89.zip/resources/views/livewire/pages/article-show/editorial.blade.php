{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : editorial                                              ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : 3 colonnes — TOC sticky gauche | contenu centré |   ║
║              actions sticky droite                               ║
║  Usage     : presse sérieuse, analyse, revue, blog de fond       ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $article->title)
    @section('og_url',         mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]))
    @section('og_title',       $article->title)
    @section('og_description', $article->excerpt)
    @section('og_image',       $article->getVariantImage('small'))

    {{-- Barre de progression lecture --}}
    <div class="fixed top-0 left-0 right-0 z-50 h-[2px] pointer-events-none">
        <div id="reading-progress" class="h-full bg-[rgb(var(--mt-secondary))] transition-all duration-100" style="width:0%"></div>
    </div>

    {{-- ══ EN-TÊTE PLEINE LARGEUR ══════════════════════════════════ --}}
    <header class="pb-8 mb-8 border-b border-gray-100 dark:border-white/6">

        {{-- Fil d'ariane --}}
        <div class="flex flex-wrap items-center gap-2 mb-6 text-xs">
            <a href="{{ mt_get_route('home') }}" wire:navigate class="text-gray-400 dark:text-white/30 hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <i class="fa-solid fa-house"></i>
            </a>
            @if($article->category)
            <i class="fa-solid fa-chevron-right text-[9px] text-gray-300 dark:text-white/15"></i>
            <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category?->slug]) }}" wire:navigate
               class="text-[rgb(var(--mt-secondary))] font-semibold hover:underline">
                {{ $article->categoryName }}
            </a>
            @endif
        </div>

        {{-- Titre --}}
        <h1 class="text-3xl lg:text-5xl font-black text-gray-900 dark:text-white leading-tight mb-6 max-w-4xl">
            {!! $article->title !!}
        </h1>

        {{-- Extrait --}}
        <p class="text-base lg:text-xl text-gray-600 dark:text-white/50 leading-relaxed max-w-3xl mb-6">
            {{ $article->excerpt }}
        </p>

        {{-- Méta --}}
        <div class="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-gray-500 dark:text-white/40">
            @if ($article->authorName)
            <span class="flex items-center gap-2 font-medium text-gray-700 dark:text-white/70">
                <span class="w-7 h-7 rounded-full bg-gradient-to-br from-[rgb(var(--mt-primary))] to-[rgb(var(--mt-secondary))]
                              flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">
                    {{ strtoupper(substr($article->authorName, 0, 2)) }}
                </span>
                {{ $article->authorName }}
            </span>
            <span class="w-px h-4 bg-gray-200 dark:bg-white/10"></span>
            @endif
            <span>{{ $article->publishedDate }}</span>
            <span class="w-px h-4 bg-gray-200 dark:bg-white/10"></span>
            <span>{{ $article->readingTime }} de lecture</span>
            @if ($article->views_count > 0)
            <span class="w-px h-4 bg-gray-200 dark:bg-white/10"></span>
            <span>{{ $article->viewsCount(true) }}</span>
            @endif
        </div>
    </header>

    {{-- ══ GRILLE 3 COLONNES ════════════════════════════════════════ --}}
    <div class="grid lg:grid-cols-12 gap-8">

        {{-- ─ Colonne gauche : TOC sticky ─ --}}
        <div class="hidden lg:block lg:col-span-3">
            <div class="sticky top-28 space-y-5">
                @include('mtblog::livewire.pages.article-show.partials._toc', ['tocId' => 'toc-desktop', 'collapsible' => false])

                {{-- Infos article --}}
                @include('mtblog::livewire.pages.article-show.partials._article-info')
            </div>
        </div>

        {{-- ─ Colonne centrale : contenu ─ --}}
        <div class="lg:col-span-6">
            <article>

                {{-- Image principale --}}
                @if ($article->hasFeatured)
                <figure class="mb-8">
                    <x-mt::image-loader :src="$article->getVariantImage('large')" :alt="$article->title" class="w-full h-auto rounded-2xl"/>
                    <figcaption class="flex items-center gap-2 mt-2.5 pl-2 text-xs text-gray-400 dark:text-white/30 border-l-2 border-[rgb(var(--mt-secondary))]">
                        {{ $article->image->title ?? "Photo d'illustration" }}
                    </figcaption>
                </figure>
                @endif

                {{-- Corps --}}
                @include('mtblog::livewire.pages.article-show.partials._content')

                {{-- Tags --}}
                @include('mtblog::livewire.pages.article-show.partials._tags-and-similar')

                {{-- Commentaires --}}
                @include('mtblog::livewire.pages.article-show.partials._comments')

            </article>
        </div>

        {{-- ─ Colonne droite : actions sticky ─ --}}
        <div class="hidden lg:block lg:col-span-3">
            <div class="sticky top-28 space-y-5">

                {{-- Actions verticales --}}
                <div class="flex flex-col items-center gap-2 p-3 mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm"
                     x-data="{ liked: {{ $isLiked ? 'true' : 'false' }}, likeCount: {{ $article->likes_count ?? 0 }} }">

                    {{-- Like --}}
                    <button @click="liked=!liked; likeCount+=liked?1:-1; $wire.toggleLike()"
                        :class="liked ? 'text-red-500 bg-red-50 dark:bg-red-500/10' : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6'"
                        class="flex flex-col items-center gap-1 w-full px-2 py-3 rounded-xl text-xs font-medium transition-all">
                        <i :class="liked ? 'fa-solid fa-heart text-red-500' : 'fa-regular fa-heart'" class="text-lg"></i>
                        <span x-text="likeCount"></span>
                    </button>

                    <div class="w-full h-px bg-gray-100 dark:bg-white/6"></div>

                    {{-- Comment --}}
                    <a href="#comments"
                       class="flex flex-col items-center gap-1 w-full px-2 py-3 rounded-xl text-xs font-medium text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 transition-all">
                        <i class="fa-regular fa-comment text-lg"></i>
                        <span>{{ $article->comments_count ?? 0 }}</span>
                    </a>

                    <div class="w-full h-px bg-gray-100 dark:bg-white/6"></div>

                    {{-- Bookmark --}}
                    <button wire:click="toggleBookmark"
                        class="flex flex-col items-center gap-1 w-full px-2 py-3 rounded-xl text-xs font-medium transition-all
                               {{ $isBookmarked ? 'text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/10' : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6' }}">
                        <i class="{{ $isBookmarked ? 'fa-solid' : 'fa-regular' }} fa-bookmark text-lg"></i>
                        <span>Sauvegarder</span>
                    </button>

                    <div class="w-full h-px bg-gray-100 dark:bg-white/6"></div>

                    {{-- Print --}}
                    <button onclick="window.print()"
                        class="flex flex-col items-center gap-1 w-full px-2 py-3 rounded-xl text-xs font-medium text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 transition-all">
                        <i class="fa-solid fa-print text-lg"></i>
                        <span>Imprimer</span>
                    </button>

                </div>

                {{-- Partage --}}
                @include('mtblog::livewire.pages.article-show.partials._share-panel')

            </div>
        </div>

    </div>

    {{-- ══ À LIRE AUSSI ════════════════════════════════════════════ --}}
    @if ($this->others_articles?->count() > 0)
    <div class="pt-12 mt-14 border-t border-gray-100 dark:border-white/6">
        <h2 class="text-lg font-bold text-gray-900 dark:text-white mb-6">À lire aussi</h2>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->others_articles as $a)
            <x-mtblog::post.card :article="$a" variant="editorial" :index="$loop->iteration" />
            @endforeach
        </div>
    </div>
    @endif

</div>

@include('mtblog::livewire.pages.article-show.partials._toc-script')
