<div>
    @section('title', "$category->name")
    {{-- options de partage --}}
    @section('og_url', mt_get_route('home_categories_show', ['slug' => $category->slug]))
    @section('og_title', "$category->name")
    @section('og_description', "$category->description")
    @section('og_image', "$this->featuredArticle->imageUrl")

    {{-- ══════════════════════════════════════════════
         EN-TÊTE CATÉGORIE
    ══════════════════════════════════════════════ --}}
    <div class="bg-[rgb(var(--mt-primary))] dark:bg-[rgb(var(--mt-bg))] text-white rounded-2xl overflow-hidden mb-8 relative dark:border-1 dark:border-gray-900">

        {{-- Déco fond --}}
        <div class="absolute inset-0 overflow-hidden pointer-events-none">
            <div class="absolute w-64 h-64 rounded-full -top-16 -right-16 bg-mt-secondary/10 blur-3xl"></div>
            <div class="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-white/3 blur-2xl"></div>
        </div>

        <div class="relative px-6 py-8 lg:px-10 lg:py-10">
            <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">

                {{-- Infos catégorie --}}
                <div>
                    {{-- Fil d'ariane --}}
                    <nav class="hidden lg:flex items-center gap-1.5 text-xs text-white/40 mb-3">
                        <a href="{{ mt_get_route('home') }}" class="transition-colors hover:text-white">Accueil</a>
                        <i class="fa-solid fa-chevron-right text-[10px]"></i>
                        @if ($category->hasParent)
                            <a href="{{ mt_get_route('home_categories_show', ['slug' => $category->parent->slug]) }}"
                               class="transition-colors hover:text-white">
                                {{ $category->parent->name }}
                            </a>
                            <i class="fa-solid fa-chevron-right text-[10px]"></i>
                        @endif
                        <span class="text-white/70">{{ $category->name }}</span>
                    </nav>

                    <div class="flex items-center gap-3 mb-2">
                        @if ($category->icon)
                            <span class="items-center justify-center flex-shrink-0 hidden w-10 h-10 lg:flex rounded-xl bg-mt-secondary">
                                <i class="{{ $category->icon }} text-white"></i>
                            </span>
                        @endif
                        <h1 class="text-3xl font-bold leading-tight lg:text-4xl">
                            {{ $category->name }}
                        </h1>
                    </div>

                    @if ($category->description)
                        <p class="max-w-xl text-sm leading-relaxed text-white/60">
                            {{ $category->description }}
                        </p>
                    @endif
                </div>

                {{-- Stat articles --}}
                <div class="flex items-center flex-shrink-0 gap-6">
                    <div class="text-center">
                        <p class="text-3xl font-bold text-white">{{ add_zero($this->totalCount) }}</p>
                        <p class="text-xs text-white/40 mt-0.5">article{{ $this->totalCount > 1 ? 's' : '' }}</p>
                    </div>
                    @if ($this->subCategories->count() > 0)
                        <div class="w-px h-10 bg-white/10"></div>
                        <div class="text-center">
                            <p class="text-3xl font-bold text-white">{{ add_zero($this->subCategories->count()) }}</p>
                            <p class="text-xs text-white/40 mt-0.5">sous-rubrique{{ $this->subCategories->count() > 1 ? 's' : '' }}</p>
                        </div>
                    @endif
                </div>
            </div>

            {{-- Sous-catégories (pills) --}}
            @if ($this->subCategories->count() > 0)
                <div class="flex flex-wrap gap-2 pt-5 mt-6 border-t border-white/8">
                    <button
                        wire:click="$set('subCategoryId', null)"
                        class="px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-150
                               {{ is_null($subCategoryId) ? 'bg-mt-secondary text-white' : 'bg-white/8 text-white/60 hover:bg-white/15 hover:text-white' }}">
                        Tous
                    </button>
                    @foreach ($this->subCategories as $sub)
                        <button
                            wire:click="$set('subCategoryId', {{ $sub->id }})"
                            class="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-150
                                   {{ $subCategoryId === $sub->id ? 'bg-mt-secondary text-white' : 'bg-white/8 text-white/60 hover:bg-white/15 hover:text-white' }}">
                            @if ($sub->icon)
                                <i class="{{ $sub->icon }} text-xs"></i>
                            @endif
                            {{ $sub->name }}
                        </button>
                    @endforeach
                </div>
            @endif
        </div>
    </div>

    {{-- ══════════════════════════════════════════════
         ARTICLE À LA UNE
    ══════════════════════════════════════════════ --}}
    @if ($this->featuredArticle && is_null($subCategoryId))
        @php $featured = $this->featuredArticle; @endphp
        <div class="mb-8">
            <a href="{{ mt_get_route('home_articles_show', ['slug' => $featured->slug, 'id' => $featured->id]) }}"
               wire:navigate
               class="relative flex flex-col overflow-hidden transition-shadow duration-300 group lg:flex-row rounded-2xl bg-[rgb(var(--mt-primary))] dark:bg-[rgb(var(--mt-bg))] ">

                {{-- Image --}}
                <div class="relative flex-shrink-0 h-64 overflow-hidden lg:w-3/5 lg:h-auto">
                    <x-mt::image-loader :src="$featured->imageUrl" :alt="$featured->title" class="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105" />

                    <div class="absolute inset-0 bg-gradient-to-r from-transparent to-[rgb(var(--mt-bg))]/80 lg:block hidden"></div>
                    <div class="absolute inset-0 bg-gradient-to-t from-[rgb(var(--mt-primary))]/70 to-transparent lg:hidden"></div>

                    {{-- Badge à la une --}}
                    <span class="absolute top-4 left-4 inline-flex items-center gap-1.5 bg-mt-secondary text-white text-xs lg:font-bold px-3 py-1 rounded-full ">
                        {{ $featured->category?->name }}
                    </span>
                </div>

                {{-- Contenu --}}
                <div class="flex flex-col justify-center text-white p-2.5 lg:p-8">
                    <div class="flex items-center gap-2 mb-3 text-xs text-white/50">
                        <span>{{ $featured->publishedThere }}</span>
                        <span>•</span>
                        <span>{{ $featured->readingTime }}</span>
                    </div>
                    <h2 class="mb-3 text-xl font-bold leading-snug transition-colors duration-200 lg:text-2xl group-hover:text-mt-secondary">
                        {!! $featured->title !!}
                    </h2>
                    <p class="mb-5 text-sm leading-relaxed text-white/60 line-clamp-3">
                        {!! $featured->excerpt !!}
                    </p>
                    <span class="inline-flex items-center gap-2 text-sm font-semibold transition-all duration-200 text-mt-secondary group-hover:gap-3">
                        Lire l'article <i class="text-xs fa-solid fa-arrow-right"></i>
                    </span>
                </div>
            </a>
        </div>
    @endif

    {{-- ══════════════════════════════════════════════
         BARRE FILTRES + TRI
    ══════════════════════════════════════════════ --}}
    <div class="flex flex-col items-start justify-between gap-4 mb-6 sm:flex-row sm:items-center">
        <p class="text-sm mt-text">
            <span class="font-semibold mt-text">{{ add_zero($this->articles->total()) }}</span>
            article{{ $this->articles->total() > 1 ? 's' : '' }} trouvé{{ $this->articles->total() > 1 ? 's' : '' }}
            @if ($subCategoryId)
                dans <span class="font-medium text-mt-secondary">{{ $this->subCategories->firstWhere('id', $subCategoryId)?->name }}</span>
            @endif
        </p>

        {{-- Sélecteur de tri --}}
        <div class="flex items-center gap-2 p-1 bg-gray-100 dark:bg-white/6 rounded-xl">
            @foreach ([
                'recent'  => ['label' => 'Récents',   'icon' => 'fa-clock'],
                'popular' => ['label' => 'Populaires', 'icon' => 'fa-fire'],
                'oldest'  => ['label' => 'Anciens',   'icon' => 'fa-calendar'],
            ] as $value => $option)
                <button
                    wire:click="$set('sort', '{{ $value }}')"
                    class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-150
                           {{ $sort === $value
                               ? 'mt-bg text-mt-secondary shadow-sm'
                               : 'text-gray-500 dark:text-white/40 hover:mt-text' }}">
                    <i class="fa-solid {{ $option['icon'] }} text-xs"></i>
                    <span class="hidden sm:inline">{{ $option['label'] }}</span>
                </button>
            @endforeach
        </div>
    </div>

    {{-- ══════════════════════════════════════════════
         GRILLE D'ARTICLES
    ══════════════════════════════════════════════ --}}
    <div wire:loading.class="opacity-50 pointer-events-none" class="transition-opacity duration-200">

        @if ($this->articles->count() > 0)

            <div class="grid gap-6 mb-8 sm:grid-cols-2 lg:grid-cols-3">
                @foreach ($this->articles as $article)
                    <x-mtblog::post.card :article="$article"></x-mtblog::post.card>
                @endforeach
            </div>

            {{-- Pagination --}}
            <div class="mt-4">
                {{ $this->articles->links() }}
            </div>

        @else
            {{-- État vide --}}
            <div class="flex flex-col items-center justify-center py-24 text-center">
                <div class="flex items-center justify-center w-20 h-20 mb-5 bg-gray-100 rounded-2xl dark:bg-white/6">
                    @if ($category->icon)
                        <i class="{{ $category->icon }} text-3xl text-gray-300 dark:text-white/15"></i>
                    @else
                        <i class="text-3xl text-gray-300 fa-regular fa-newspaper dark:text-white/15"></i>
                    @endif
                </div>
                <h3 class="mb-2 text-lg font-semibold text-gray-700 dark:text-white/60">
                    Aucun article pour le moment
                </h3>
                <p class="max-w-xs mb-6 text-sm text-gray-400 dark:text-white/30">
                    Cette rubrique ne contient pas encore d'articles publiés.
                    Revenez bientôt !
                </p>
                <a href="{{ mt_get_route('home') }}"
                   wire:navigate
                   class="inline-flex items-center gap-2 px-5 py-2.5 bg-mt-primary dark:bg-white/8 text-white text-sm font-medium rounded-xl hover:bg-mt-secondary transition-colors duration-200">
                    <i class="text-xs fa-solid fa-house"></i>
                    Retour à l'accueil
                </a>
            </div>
        @endif

    </div>

    {{-- Indicateur de chargement --}}
    <div wire:loading class="fixed bottom-6 right-6 z-50 bg-mt-primary  text-white text-sm px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2.5">
        <i class="fa-solid fa-spinner fa-spin text-mt-secondary"></i>
        Chargement…
    </div>

</div>
