{{--
  Partial : _newsletter-cta.blade.php — CTA newsletter in-article
  Flag : $hasNewsletter. Soumet via $wire->subscribeNewsletter (GuestBaseComponent).
--}}
@if (($hasNewsletter ?? false))
<div class="mt-10 p-6 rounded-2xl text-center"
     style="background: linear-gradient(135deg, rgba(var(--mt-secondary),0.12), rgba(var(--mt-primary),0.08));
            border: 1px solid rgba(var(--mt-secondary),0.2)">
    <i class="fa-solid fa-envelope-open-text text-2xl text-[rgb(var(--mt-secondary))] mb-2"></i>
    <h3 class="text-lg font-bold text-gray-900 dark:text-white">Ne manquez aucune actualité</h3>
    <p class="mb-4 text-sm text-gray-500 dark:text-white/45">Recevez nos articles directement dans votre boîte mail.</p>

    <form wire:submit="subscribeNewsletter" class="flex flex-col gap-2 mx-auto max-w-md sm:flex-row">
        <input type="email" wire:model="newsletterEmail" placeholder="votre@email.com"
               class="flex-1 px-4 py-2.5 text-sm rounded-xl border border-gray-200 dark:border-white/10
                      bg-white dark:bg-white/6 text-gray-800 dark:text-white placeholder-gray-400
                      focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/25">
        <button type="submit"
                class="px-5 py-2.5 text-sm font-semibold text-white bg-[rgb(var(--mt-secondary))] rounded-xl
                       hover:opacity-90 transition-opacity flex-shrink-0">
            <span wire:loading.remove wire:target="subscribeNewsletter">S'abonner</span>
            <span wire:loading wire:target="subscribeNewsletter">…</span>
        </button>
    </form>
    @error('email') <p class="mt-2 text-xs text-red-500">{{ $message }}</p> @enderror
</div>
@endif
