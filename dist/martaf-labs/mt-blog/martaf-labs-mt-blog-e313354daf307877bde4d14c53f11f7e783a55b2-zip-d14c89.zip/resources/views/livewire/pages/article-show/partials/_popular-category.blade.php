{{--
  Partial : _popular-category.blade.php — widget sidebar « plus lus de la rubrique »
  Flag : $hasPopularCategory. Données : $this->popular_in_category
--}}
@if (($hasPopularCategory ?? false) && $this->popular_in_category->isNotEmpty())
<div class="p-5 mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">
    <h3 class="flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-white mb-4">
        <i class="fa-solid fa-fire text-[rgb(var(--mt-secondary))] text-xs"></i>
        Les plus lus - {{ $article->categoryName }}
    </h3>
    <div class="flex flex-col divide-y divide-gray-100 dark:divide-white/6">
        @foreach ($this->popular_in_category as $i => $a)
        <a href="{{ mt_get_route('home_articles_show', ['slug' => $a->slug, 'id' => $a->id]) }}" wire:navigate
           class="group flex items-start gap-3 py-2.5 first:pt-0 last:pb-0">
            <span class="w-5 flex-shrink-0 text-center text-base font-black leading-none tabular-nums"
                  style="color: rgba(var(--mt-secondary), {{ $i === 0 ? '1' : '0.35' }})">{{ $i + 1 }}</span>
            <span class="min-w-0">
                <span class="block text-[13px] font-medium text-gray-600 dark:text-white/55 leading-snug line-clamp-2
                             group-hover:text-[rgb(var(--mt-secondary))] transition-colors">{!! $a->title !!}</span>
                @if ($a->views_count > 0)
                <span class="block mt-0.5 text-[11px] text-gray-400 dark:text-white/30">
                    <i class="fa-solid fa-eye mr-0.5"></i>{{ $a->viewsCount(true) }}
                </span>
                @endif
            </span>
        </a>
        @endforeach
    </div>
</div>
@endif
