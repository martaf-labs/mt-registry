{{--
  Partial : _author-box.blade.php — encadré auteur + ses autres articles
  Flag : $hasAuthorBox. Données : $article->author, $this->author_articles
--}}
@if (($hasAuthorBox ?? false) && $article->author)
@php $author = $article->author; @endphp
<div class="mt-10 p-5 mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">
    <div class="flex items-start gap-4">
        <img src="{{ $author->profile_photo_url }}" alt="{{ $author->name }}"
             class="w-14 h-14 rounded-full object-cover flex-shrink-0 ring-2 ring-[rgb(var(--mt-secondary))]/20">
        <div class="flex-1 min-w-0">
            <span class="text-[11px] font-bold uppercase tracking-wider text-[rgb(var(--mt-secondary))]">Auteur</span>
            <h3 class="text-base font-bold text-gray-900 dark:text-white">{{ $author->name }}</h3>
            @if (! empty($author->bio))
            <p class="mt-1 text-sm text-gray-500 dark:text-white/45 line-clamp-2">{{ $author->bio }}</p>
            @endif
        </div>
    </div>

    @if ($this->author_articles->isNotEmpty())
    <div class="mt-4 pt-4 border-t border-gray-100 dark:border-white/6">
        <p class="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-400 dark:text-white/30">Du même auteur</p>
        <div class="flex flex-col gap-2">
            @foreach ($this->author_articles as $a)
            <a href="{{ mt_get_route('home_articles_show', ['slug' => $a->slug, 'id' => $a->id]) }}" wire:navigate
               class="text-sm text-gray-600 dark:text-white/55 hover:text-[rgb(var(--mt-secondary))] transition-colors truncate">
                {!! $a->title !!}
            </a>
            @endforeach
        </div>
    </div>
    @endif
</div>
@endif
