{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : minimal                                                ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : colonne unique centrée étroite, pas de sidebar      ║
║              accent typographique maximal, image petite          ║
║  Usage     : blog corporate, lettre, essai, newsletter           ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $article->title)
    @section('og_url',         mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]))
    @section('og_title',       $article->title)
    @section('og_description', $article->excerpt)
    @section('og_image',       $article->getVariantImage('small'))

    {{-- Barre de progression --}}
    <div class="fixed top-0 left-0 right-0 z-50 h-[2px] pointer-events-none">
        <div id="reading-progress" class="h-full bg-[rgb(var(--mt-secondary))] transition-all duration-100" style="width:0%"></div>
    </div>

    <div class="max-w-2xl mx-auto">

        {{-- ─ Catégorie + retour ─ --}}
        <div class="flex items-center justify-between mb-8">
            <a href="{{ mt_get_route('home') }}" wire:navigate
               class="flex items-center gap-1.5 text-xs text-gray-400 dark:text-white/30
                      hover:text-[rgb(var(--mt-secondary))] transition-colors">
                <i class="fa-solid fa-arrow-left text-[10px]"></i>
                Retour
            </a>
            @if($article->category)
            <a href="{{ mt_get_route('home_categories_show', ['slug' => $article->category->slug]) }}" wire:navigate
               class="text-xs font-bold uppercase tracking-widest text-[rgb(var(--mt-secondary))]
                      hover:underline underline-offset-2 transition-all">
                {{ $article->categoryName }}
            </a>
            @endif
        </div>

        {{-- ─ Trait décoratif ─ --}}
        <div class="w-12 h-[3px] bg-[rgb(var(--mt-secondary))] rounded-full mb-6"></div>

        {{-- ─ Titre ─ --}}
        <h1 class="text-3xl lg:text-4xl font-black text-gray-900 dark:text-white leading-tight mb-5">
            {!! $article->title !!}
        </h1>

        {{-- ─ Méta sobre ─ --}}
        <div class="flex items-center gap-3 text-xs text-gray-400 dark:text-white/30 mb-6 pb-6 border-b border-gray-100 dark:border-white/6">
            @if ($article->authorName)
            <span class="font-medium text-gray-600 dark:text-white/50">{{ $article->authorName }}</span>
            <span>·</span>
            @endif
            <span>{{ $article->publishedDate }}</span>
            <span>·</span>
            <span>{{ $article->readingTime }}</span>
            @if ($article->hasBeenUpdated)
            <span>·</span>
            <span class="italic">Mis à jour {{ $article->updatedDate }}</span>
            @endif
        </div>

        {{-- ─ Extrait --}}
        <p class="text-base font-medium text-gray-600 dark:text-white/50 leading-relaxed mb-8 italic">
            "{{ $article->excerpt }}"
        </p>

        {{-- ─ Image (format compact) ─ --}}
        @if ($article->hasFeatured)
        <figure class="mb-8">
            <x-mt::image-loader :src="$article->getVariantImage('large')" :alt="$article->title" class="w-full h-auto rounded-xl"/>
            @if($article->image?->title)
            <figcaption class="mt-2 text-xs text-center text-gray-400 dark:text-white/25 italic">
                {{ $article->image->title }}
            </figcaption>
            @endif
        </figure>
        @endif

        {{-- ─ Corps ─ --}}
        @include('mtblog::livewire.pages.article-show.partials._content')

        {{-- ─ Actions post-lecture ─ --}}
        <div class="mt-10 pt-8 border-t border-gray-100 dark:border-white/6">
            <p class="text-sm text-center text-gray-500 dark:text-white/35 mb-4">
                Cet article vous a été utile ?
            </p>
            <div class="flex items-center justify-center gap-3"
                 x-data="{ liked: {{ $isLiked ? 'true' : 'false' }}, likeCount: {{ $article->likes_count ?? 0 }} }">

                <button @click="liked=!liked; likeCount+=liked?1:-1; $wire.toggleLike()"
                    :class="liked ? 'border-red-300 text-red-500 bg-red-50 dark:bg-red-500/10' : 'border-gray-200 dark:border-white/10 text-gray-500 dark:text-white/40 hover:border-red-200 hover:text-red-400'"
                    class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border text-sm font-medium transition-all">
                    <i :class="liked ? 'fa-solid fa-heart' : 'fa-regular fa-heart'"></i>
                    <span x-text="liked ? 'Merci !' : 'J\'aime · ' + likeCount"></span>
                </button>

                <button wire:click="toggleBookmark"
                    class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border text-sm font-medium transition-all
                           {{ $isBookmarked
                            ? 'border-[rgb(var(--mt-secondary))]/30 text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/8'
                            : 'border-gray-200 dark:border-white/10 text-gray-500 dark:text-white/40 hover:border-[rgb(var(--mt-secondary))]/30 hover:text-[rgb(var(--mt-secondary))]' }}">
                    <i class="{{ $isBookmarked ? 'fa-solid' : 'fa-regular' }} fa-bookmark"></i>
                    {{ $isBookmarked ? 'Sauvegardé' : 'Sauvegarder' }}
                </button>

            </div>
        </div>

        {{-- ─ Tags ─ --}}
        @if ($article->tags->count() > 0)
        <div class="flex flex-wrap items-center gap-2 mt-8">
            <span class="text-xs font-semibold uppercase tracking-wider text-gray-400 dark:text-white/30 mr-1">Tags</span>
            @foreach ($article->tags as $tag)
            <a href="{{ $tag->url ?? '#' }}"
               class="px-3 py-1 text-xs text-gray-600 dark:text-white/50
                      bg-gray-100 dark:bg-white/6 rounded-full
                      hover:bg-mt-secondary hover:text-white dark:hover:bg-mt-secondary transition-all">
                #{{ $tag->name }}
            </a>
            @endforeach
        </div>
        @endif

        {{-- ─ Partage sobre ─ --}}
        <div class="mt-8">
            @include('mtblog::livewire.pages.article-show.partials._share-panel')
        </div>

        {{-- ─ Commentaires ─ --}}
        @include('mtblog::livewire.pages.article-show.partials._comments')

        {{-- ─ Similaires ─ --}}
        @if ($this->similar_articles->count() > 0)
        <div class="mt-12 pt-10 border-t border-gray-100 dark:border-white/6">
            <h3 class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-white/30 mb-5">
                Sur le même sujet
            </h3>
            <div class="flex flex-col gap-0">
                @foreach ($this->similar_articles->take(4) as $a)
                <x-mtblog::post.card :article="$a" variant="minimal" :show-excerpt="false" />
                @endforeach
            </div>
        </div>
        @endif

    </div>

</div>

@include('mtblog::livewire.pages.article-show.partials._toc-script')
