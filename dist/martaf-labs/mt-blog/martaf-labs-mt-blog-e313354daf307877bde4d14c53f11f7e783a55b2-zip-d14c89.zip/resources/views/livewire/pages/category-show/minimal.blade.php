{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT CATÉGORIE : minimal                                      ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : header minimaliste centré + barre de filtres sobre  ║
║              grille compacte de cards "minimal"                  ║
║              pas de sidebar, pas de featured                     ║
║  Usage     : blog corporate, lettre, newsletter, tech            ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $category->name)
    @section('og_url',         mt_get_route('home_categories_show', ['slug' => $category->slug]))
    @section('og_title',       $category->name)
    @section('og_description', $category->description)
    @section('og_image',       $this->featuredArticle?->getVariantImage('small'))

    {{-- ══ EN-TÊTE CENTRÉ ══════════════════════════════════════════ --}}
    <header class="text-center max-w-2xl mx-auto mb-10 pt-4">

        {{-- Fil d'ariane centré --}}
        <nav class="flex items-center justify-center gap-1.5 text-xs text-gray-400 dark:text-white/30 mb-5">
            <a href="{{ mt_get_route('home') }}" wire:navigate class="hover:text-[rgb(var(--mt-secondary))] transition-colors">Accueil</a>
            @if ($category->hasParent)
            <i class="fa-solid fa-chevron-right text-[9px]"></i>
            <a href="{{ mt_get_route('home_categories_show', ['slug' => $category->parent->slug]) }}"
               wire:navigate class="hover:text-[rgb(var(--mt-secondary))] transition-colors">
                {{ $category->parent->name }}
            </a>
            @endif
            <i class="fa-solid fa-chevron-right text-[9px]"></i>
            <span class="text-gray-600 dark:text-white/50">{{ $category->name }}</span>
        </nav>

        {{-- Trait + icône --}}
        <div class="flex items-center justify-center gap-3 mb-4">
            <div class="h-px flex-1 bg-gray-200 dark:bg-white/8"></div>
            @if ($category->icon)
            <div class="w-10 h-10 rounded-2xl bg-[rgb(var(--mt-secondary))]/10 flex items-center justify-center flex-shrink-0">
                <i class="{{ $category->icon }} text-[rgb(var(--mt-secondary))]"></i>
            </div>
            @endif
            <div class="h-px flex-1 bg-gray-200 dark:bg-white/8"></div>
        </div>

        <h1 class="text-3xl lg:text-4xl font-black text-gray-900 dark:text-white mb-3">
            {{ $category->name }}
        </h1>
        @if ($category->description)
        <p class="text-sm text-gray-500 dark:text-white/40 leading-relaxed mb-4">
            {{ $category->description }}
        </p>
        @endif

        {{-- Stats --}}
        <div class="flex items-center justify-center gap-5 text-sm text-gray-400 dark:text-white/30">
            <span><span class="font-bold text-gray-700 dark:text-white/70">{{ add_zero($this->totalCount) }}</span> article{{ $this->totalCount > 1 ? 's' : '' }}</span>
            @if ($this->subCategories->count() > 0)
            <span class="w-px h-4 bg-gray-200 dark:bg-white/10"></span>
            <span><span class="font-bold text-gray-700 dark:text-white/70">{{ add_zero($this->subCategories->count()) }}</span> rubrique{{ $this->subCategories->count() > 1 ? 's' : '' }}</span>
            @endif
        </div>
    </header>

    {{-- ══ SOUS-CATÉGORIES (pills light) ══════════════════════════ --}}
    @if ($this->subCategories->count() > 0)
    <div class="flex justify-center mb-8">
        @include('mtblog::livewire.pages.category-show.partials._subcategories', ['theme' => 'light'])
    </div>
    @endif

    {{-- ══ FILTRES ══════════════════════════════════════════════════ --}}
    @include('mtblog::livewire.pages.category-show.partials._filters')

    {{-- ══ ARTICLES (variant minimal) ════════════════════════════ --}}
    <div wire:loading.class="opacity-50 pointer-events-none" class="transition-opacity duration-200">

        @if ($this->articles->count() > 0)

        {{-- Toujours en colonne unique style minimal --}}
        <div class="flex flex-col gap-0 mb-8">
            @foreach ($this->articles as $article)
            <x-mtblog::post.card
                :article="$article"
                variant="minimal"
                :show-excerpt="$viewMode !== 'list' ? false : true"
                :show-actions="true"
            />
            @endforeach
        </div>

        <div class="mt-4">{{ $this->articles->links() }}</div>

        @else
        <div class="flex flex-col items-center justify-center py-24 text-center">
            <i class="fa-regular fa-newspaper text-4xl text-gray-200 dark:text-white/10 mb-4"></i>
            <h3 class="text-lg font-semibold text-gray-600 dark:text-white/50 mb-2">Aucun article pour le moment</h3>
            <p class="text-sm text-gray-400 dark:text-white/30 max-w-xs mb-6">Revenez bientôt !</p>
            <a href="{{ mt_get_route('home') }}" wire:navigate
               class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-xl
                      border border-gray-200 dark:border-white/10 text-gray-600 dark:text-white/50
                      hover:border-[rgb(var(--mt-secondary))]/40 hover:text-[rgb(var(--mt-secondary))] transition-all">
                <i class="fa-solid fa-arrow-left text-xs"></i>
                Retour à l'accueil
            </a>
        </div>
        @endif

    </div>

    <div wire:loading class="fixed bottom-6 right-6 z-50 mt-bg text-sm px-4 py-2.5 rounded-xl shadow-xl border border-gray-100 dark:border-white/6 flex items-center gap-2.5 mt-text">
        <i class="fa-solid fa-spinner fa-spin text-[rgb(var(--mt-secondary))]"></i> Chargement…
    </div>

</div>
