{{--
  Partial : _reactions.blade.php — barre de réactions emoji (fluide)
  Optimiste : le compteur monte instantanément côté Alpine, $wire.react persiste en arrière-plan.
  Flag : $hasReactions
--}}
@if (($hasReactions ?? false))
@php
    $emojis = ['👍' => "J'aime", '❤️' => 'Adore', '😮' => 'Surpris', '😢' => 'Triste', '😡' => 'En colère'];
    $counts = $this->reactions;
@endphp
<div class="mt-10 pt-6 border-t border-gray-100 dark:border-white/6"
     x-data="{
        counts: {{ \Illuminate\Support\Js::from($counts) }},
        react(emoji) {
            this.counts[emoji] = (this.counts[emoji] || 0) + 1;
            $wire.react(emoji);
        }
     }">
    <p class="text-sm font-semibold text-gray-700 dark:text-white/70 mb-3">Votre réaction&nbsp;?</p>
    <div class="flex flex-wrap gap-2">
        @foreach ($emojis as $emoji => $label)
        <button type="button" @click="react('{{ $emoji }}')"
                class="group flex items-center gap-2 px-3 py-2 rounded-full
                       border border-gray-200 dark:border-white/10
                       hover:border-[rgb(var(--mt-secondary))]/50 hover:bg-[rgb(var(--mt-secondary))]/5
                       active:scale-95 transition-all duration-150"
                title="{{ $label }}">
            <span class="text-lg leading-none transition-transform duration-150
                         group-hover:scale-125 group-active:scale-[1.6]">{{ $emoji }}</span>
            <span class="text-xs font-semibold text-gray-500 dark:text-white/40 tabular-nums"
                  x-text="counts['{{ $emoji }}'] || 0"></span>
        </button>
        @endforeach
    </div>
</div>
@endif
