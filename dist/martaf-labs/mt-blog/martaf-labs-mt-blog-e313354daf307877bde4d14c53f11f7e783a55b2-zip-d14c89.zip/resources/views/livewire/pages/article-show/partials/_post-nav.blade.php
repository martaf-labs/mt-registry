{{--
  Partial : _post-nav.blade.php — navigation article précédent / suivant (même rubrique)
  Flag : $hasPostNav. Données : $this->prev_article, $this->next_article
--}}
@if (($hasPostNav ?? false))
@php $prev = $this->prev_article; $next = $this->next_article; @endphp
@if ($prev || $next)
<div class="mt-10 grid gap-4 sm:grid-cols-2">

    @if ($prev)
    <a href="{{ mt_get_route('home_articles_show', ['slug' => $prev->slug, 'id' => $prev->id]) }}" wire:navigate
       class="group flex items-center gap-3 p-4 mt-bg rounded-2xl border border-gray-100 dark:border-white/6
              hover:border-[rgb(var(--mt-secondary))]/40 transition-colors">
        <i class="fa-solid fa-arrow-left text-[rgb(var(--mt-secondary))] flex-shrink-0 group-hover:-translate-x-1 transition-transform"></i>
        <span class="min-w-0">
            <span class="block text-[11px] uppercase tracking-wide text-gray-400 dark:text-white/30">Précédent</span>
            <span class="block text-sm font-semibold text-gray-700 dark:text-white/70 line-clamp-1">{!! $prev->title !!}</span>
        </span>
    </a>
    @else
    <div></div>
    @endif

    @if ($next)
    <a href="{{ mt_get_route('home_articles_show', ['slug' => $next->slug, 'id' => $next->id]) }}" wire:navigate
       class="group flex items-center justify-end gap-3 p-4 mt-bg rounded-2xl border border-gray-100 dark:border-white/6
              hover:border-[rgb(var(--mt-secondary))]/40 transition-colors text-right">
        <span class="min-w-0">
            <span class="block text-[11px] uppercase tracking-wide text-gray-400 dark:text-white/30">Suivant</span>
            <span class="block text-sm font-semibold text-gray-700 dark:text-white/70 line-clamp-1">{!! $next->title !!}</span>
        </span>
        <i class="fa-solid fa-arrow-right text-[rgb(var(--mt-secondary))] flex-shrink-0 group-hover:translate-x-1 transition-transform"></i>
    </a>
    @endif

</div>
@endif
@endif
