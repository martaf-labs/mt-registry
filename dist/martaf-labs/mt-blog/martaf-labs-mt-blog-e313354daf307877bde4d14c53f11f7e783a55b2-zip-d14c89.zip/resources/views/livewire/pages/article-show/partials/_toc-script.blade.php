{{--
  Partial : _toc-script.blade.php
  Script JS : Table des matières auto + barre de progression de lecture.
  Inclure en bas de chaque layout.
  Données : $isContentBlocks
--}}

@if ($isContentBlocks)
<script>
document.addEventListener('DOMContentLoaded', () => {
    // ── Table des matières ────────────────────────────────────
    const body = document.getElementById('article-body');
    const tocTargets = ['toc-desktop', 'toc-mobile', 'toc-alt'];

    if (body) {
        const headings = body.querySelectorAll('h2, h3');

        headings.forEach((h, i) => {
            if (!h.id) h.id = 'section-' + (i + 1);

            const isH3 = h.tagName.toLowerCase() === 'h3';
            const link = `
                <a href="#${h.id}"
                   class="flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all duration-150
                          text-gray-500 dark:text-white/40
                          hover:text-[rgb(var(--mt-secondary))] dark:hover:text-[rgb(var(--mt-secondary))]
                          hover:bg-gray-50 dark:hover:bg-white/4
                          ${isH3 ? 'pl-6 text-[13px]' : 'font-medium'}"
                   data-toc-link="${h.id}">
                    <span class="w-1.5 h-1.5 rounded-full flex-shrink-0
                                  ${isH3 ? 'bg-gray-300 dark:bg-white/20' : 'bg-[rgb(var(--mt-secondary))]'}">
                    </span>
                    ${h.textContent.trim()}
                </a>`;

            tocTargets.forEach(tocId => {
                const toc = document.getElementById(tocId);
                if (toc) toc.insertAdjacentHTML('beforeend', `<li>${link}</li>`);
            });
        });

        // ── Surlignage actif au scroll ────────────────────────
        const allTocLinks = document.querySelectorAll('[data-toc-link]');

        if (headings.length) {
            const observer = new IntersectionObserver(entries => {
                entries.forEach(e => {
                    const links = document.querySelectorAll(`[data-toc-link="${e.target.id}"]`);
                    links.forEach(link => {
                        link.classList.toggle('!text-[rgb(var(--mt-secondary))]', e.isIntersecting);
                        link.classList.toggle('!bg-[rgb(var(--mt-secondary))]/8', e.isIntersecting);
                    });
                });
            }, { rootMargin: '-20% 0px -70% 0px' });

            headings.forEach(h => observer.observe(h));
        }
    }

    // ── Barre de progression de lecture ───────────────────────
    const progressBar = document.getElementById('reading-progress');
    if (progressBar) {
        const article = document.getElementById('article-body') || document.getElementById('content');
        if (article) {
            window.addEventListener('scroll', () => {
                const rect    = article.getBoundingClientRect();
                const total   = article.offsetHeight;
                const scrolled = Math.max(0, -rect.top);
                const progress = Math.min(100, (scrolled / total) * 100);
                progressBar.style.width = progress + '%';
            }, { passive: true });
        }
    }
});
</script>
@endif
