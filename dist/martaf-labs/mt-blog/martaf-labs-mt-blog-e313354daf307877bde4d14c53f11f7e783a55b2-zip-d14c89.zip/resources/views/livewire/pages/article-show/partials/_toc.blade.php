{{--
  Partial : _toc.blade.php
  Table des matières (desktop + mobile).
  Props : $tocId (string, défaut 'toc-desktop')
          $label (string, défaut 'Dans cet article')
          $collapsible (bool, défaut false) → avec accordion Alpine
  Données : $isContentBlocks
--}}

@props([
    'tocId'       => 'toc-desktop',
    'label'       => 'Dans cet article',
    'collapsible' => false,
])

@if ($isContentBlocks)
<div class="mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm overflow-hidden"
     @if($collapsible) x-data="{ open: true }" @endif>

    <button
        class="w-full flex items-center justify-between gap-2 px-5 py-4 border-b border-gray-100 dark:border-white/6"
        @if($collapsible) @click="open = !open" @endif
    >
        <span class="flex items-center gap-2">
            <i class="fa-solid fa-list text-[rgb(var(--mt-secondary))] text-xs"></i>
            <span class="text-sm font-bold text-gray-900 dark:text-white">{{ $label }}</span>
        </span>
        @if($collapsible)
        <i class="fa-solid fa-chevron-down text-[10px] text-gray-400 dark:text-white/30 transition-transform duration-200"
           :class="open ? 'rotate-180' : ''"></i>
        @endif
    </button>

    <ul class="p-3 space-y-0.5 text-sm" id="{{ $tocId }}"
        @if($collapsible) x-show="open" x-transition @endif>
        {{-- Généré dynamiquement par JS (voir script TOC en bas de page) --}}
    </ul>

</div>
@endif
