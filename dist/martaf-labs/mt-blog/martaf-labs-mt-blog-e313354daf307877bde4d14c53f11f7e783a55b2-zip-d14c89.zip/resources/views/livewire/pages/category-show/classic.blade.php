{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT CATÉGORIE : classic                                      ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : header coloré pleine largeur (bg-primary)           ║
║              article à la une (spotlight)                        ║
║              filtres + grille 3 colonnes                         ║
║  Usage     : blog généraliste, news, multi-thématiques           ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div>
    @section('title', $category->name)
    @section('og_url',         mt_get_route('home_categories_show', ['slug' => $category->slug]))
    @section('og_title',       $category->name)
    @section('og_description', $category->description)
    @section('og_image',       $this->featuredArticle?->getVariantImage('small'))

    {{-- ══ EN-TÊTE COLORÉ ═════════════════════════════════════════ --}}
    <header class="bg-[rgb(var(--mt-primary))] dark:bg-[rgb(var(--mt-bg))] text-white
                   rounded-2xl overflow-hidden mb-8 relative
                   border border-transparent dark:border-white/6">

        {{-- Déco fond --}}
        <div class="absolute inset-0 overflow-hidden pointer-events-none">
            <div class="absolute w-72 h-72 rounded-full -top-20 -right-20 bg-[rgb(var(--mt-secondary))]/10 blur-3xl"></div>
            <div class="absolute bottom-0 left-0 w-56 h-56 rounded-full bg-white/3 blur-2xl"></div>
        </div>

        <div class="relative px-6 py-8 lg:px-10 lg:py-10">
            <div class="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">

                {{-- Infos catégorie --}}
                <div class="flex-1">

                    {{-- Fil d'ariane --}}
                    @if ($hasBreadcrumb)
                    <nav class="hidden lg:flex items-center gap-1.5 text-xs text-white/40 mb-4">
                        <a href="{{ mt_get_route('home') }}" wire:navigate class="hover:text-white transition-colors">Accueil</a>
                        <i class="fa-solid fa-chevron-right text-[10px]"></i>
                        @if ($category->hasParent)
                        <a href="{{ mt_get_route('home_categories_show', ['slug' => $category->parent->slug]) }}"
                           wire:navigate class="hover:text-white transition-colors">
                            {{ $category->parent->name }}
                        </a>
                        <i class="fa-solid fa-chevron-right text-[10px]"></i>
                        @endif
                        <span class="text-white/70">{{ $category->name }}</span>
                    </nav>
                    @endif

                    {{-- Icône + Titre --}}
                    <div class="flex items-center gap-3 mb-3">
                        @if ($hasIcon && $category->icon)
                        <span class="hidden lg:flex items-center justify-center w-12 h-12 rounded-2xl bg-[rgb(var(--mt-secondary))] flex-shrink-0">
                            <i class="{{ $category->icon }} text-white text-lg"></i>
                        </span>
                        @endif
                        <h1 class="text-3xl lg:text-4xl font-bold leading-tight">
                            {{ $category->name }}
                        </h1>
                    </div>

                    @if ($category->description)
                    <p class="max-w-xl text-sm leading-relaxed text-white/60 mb-0">
                        {{ $category->description }}
                    </p>
                    @endif
                </div>

                {{-- Stats --}}
                @if ($hasMeta)
                <div class="flex items-center gap-6 flex-shrink-0">
                    <div class="text-center">
                        <p class="text-3xl font-bold">{{ add_zero($this->totalCount) }}</p>
                        <p class="text-xs text-white/40 mt-0.5">article{{ $this->totalCount > 1 ? 's' : '' }}</p>
                    </div>
                    @if ($this->subCategories->count() > 0)
                    <div class="w-px h-10 bg-white/10"></div>
                    <div class="text-center">
                        <p class="text-3xl font-bold">{{ add_zero($this->subCategories->count()) }}</p>
                        <p class="text-xs text-white/40 mt-0.5">sous-rubrique{{ $this->subCategories->count() > 1 ? 's' : '' }}</p>
                    </div>
                    @endif
                </div>
                @endif
            </div>

            {{-- Sous-catégories --}}
            @if ($this->subCategories->count() > 0)
            <div class="pt-5 mt-6 border-t border-white/8">
                @include('mtblog::livewire.pages.category-show.partials._subcategories', ['theme' => 'dark'])
            </div>
            @endif
        </div>
    </header>

    {{-- ══ CORPS : colonne principale + sidebar optionnelle ════════ --}}
    <div class="grid grid-cols-1 gap-8 {{ $hasSidebar ? 'lg:grid-cols-12' : '' }}">

        <div class="min-w-0 {{ $hasSidebar ? 'lg:col-span-8' : '' }}">

            {{-- Article à la une --}}
            @if ($hasFeaturedArticle)
            @include('mtblog::livewire.pages.category-show.partials._featured', ['variant' => 'spotlight'])
            @endif

            {{-- Filtres --}}
            @include('mtblog::livewire.pages.category-show.partials._filters')

            {{-- Articles --}}
            @include('mtblog::livewire.pages.category-show.partials._articles-grid', [
                'cardVariant' => 'default',
                'gridCols'    => $hasSidebar ? 2 : 3,
            ])
        </div>

        {{-- Sidebar optionnelle --}}
        @if ($hasSidebar)
        <aside class="lg:col-span-4">
            <div class="lg:sticky lg:top-24 flex flex-col gap-5">
                @include('mtblog::livewire.pages.category-show.partials._top-articles')
            </div>
        </aside>
        @endif

    </div>

</div>
