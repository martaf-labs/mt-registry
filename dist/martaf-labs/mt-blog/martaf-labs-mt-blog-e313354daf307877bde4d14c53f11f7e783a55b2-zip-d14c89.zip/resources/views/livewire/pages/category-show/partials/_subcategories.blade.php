{{--
  Partial : _subcategories.blade.php
  Pills de filtrage par sous-catégorie.
  Props optionnelle : $theme  'dark' (sur fond sombre) | 'light' (sur fond clair)
  Données : $subCategories, $subCategoryId
--}}

@props(['theme' => 'dark'])

@if ($hasChildrens && $this->subCategories->count() > 0)

@php
    $isDark = $theme === 'dark';
    $allClass  = $isDark
        ? 'bg-white/12 text-white hover:bg-white/20'
        : 'bg-[rgb(var(--mt-secondary))] text-white';
    $allInactive = $isDark
        ? 'bg-white/8 text-white/60 hover:bg-white/15 hover:text-white'
        : 'bg-gray-100 dark:bg-white/6 text-gray-600 dark:text-white/50 hover:bg-gray-200 dark:hover:bg-white/10 hover:text-gray-900 dark:hover:text-white';
    $activeClass = $isDark
        ? 'bg-[rgb(var(--mt-secondary))] text-white'
        : 'bg-[rgb(var(--mt-secondary))] text-white';
    $inactiveClass = $isDark
        ? 'bg-white/8 text-white/60 hover:bg-white/15 hover:text-white'
        : 'bg-gray-100 dark:bg-white/6 text-gray-600 dark:text-white/50 hover:bg-gray-200 dark:hover:bg-white/10 hover:text-gray-900 dark:hover:text-white';
@endphp

<div class="flex flex-wrap gap-2">

    {{-- Bouton "Tous" --}}
    <button
        wire:click="$set('subCategoryId', null)"
        class="px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-150
               {{ is_null($subCategoryId) ? $activeClass : $inactiveClass }}">
        Tous
        <span class="ml-1 text-[10px] opacity-60">({{ add_zero($this->totalCount) }})</span>
    </button>

    {{-- Sous-catégories --}}
    @foreach ($this->subCategories as $sub)
    <button
        wire:click="$set('subCategoryId', {{ $sub->id }})"
        class="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-150
               {{ $subCategoryId === $sub->id ? $activeClass : $inactiveClass }}">
        @if ($sub->icon)
        <i class="{{ $sub->icon }} text-xs opacity-80"></i>
        @endif
        {{ $sub->name }}
        @if (isset($sub->articles_count) && $sub->articles_count > 0)
        <span class="text-[10px] opacity-60">({{ $sub->articles_count }})</span>
        @endif
    </button>
    @endforeach

</div>

@endif
