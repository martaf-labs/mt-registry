
{{--
Partial : _tags-and-similar.blade.php
Tags + Articles similaires.
Données : $article, $similar_articles
--}}
@if($hasTags)
    {{-- Tags --}}
    @if ($article->tags->count() > 0)
    <div class="flex flex-wrap items-center gap-2 pt-6 mt-8 border-t border-gray-100 dark:border-white/6">
        <span class="mr-1 text-xs font-semibold uppercase tracking-wide text-gray-400 dark:text-white/30">
            Tags
        </span>
        @foreach ($article->tags as $tag)
        <a href="{{ $tag->url ?? '#' }}"
        class="px-3 py-1 text-xs font-medium text-gray-600 dark:text-white/50
                bg-gray-100 dark:bg-white/6
                hover:bg-mt-secondary hover:text-white dark:hover:bg-mt-secondary dark:hover:text-white
                rounded-full transition-all duration-150">
            #{{ $tag->name }}
        </a>
        @endforeach
    </div>
    @endif
@endif


@if($hasSimilar)
    {{-- Articles similaires --}}
    @if ($this->similar_articles->count() > 0)
    <div class="mt-8 overflow-hidden mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm">

        <div class="flex items-center gap-2 px-5 py-4 border-b border-gray-100 dark:border-white/6">
            <i class="fa-solid fa-layer-group text-[rgb(var(--mt-secondary))] text-xs"></i>
            <h3 class="text-sm font-bold text-gray-900 dark:text-white">Articles similaires</h3>
        </div>

        <div class="divide-y divide-gray-100 dark:divide-white/5">
            @foreach ($this->similar_articles as $similarArticle)
            <a href="{{ mt_get_route('home_articles_show', ['slug' => $similarArticle->slug, 'id' => $similarArticle->id]) }}"
            wire:navigate
            class="flex items-center gap-4 px-5 py-3.5
                    hover:bg-gray-50 dark:hover:bg-white/4
                    transition-colors group">

                <span class="text-xl font-black tabular-nums select-none flex-shrink-0 w-7 text-center
                            text-gray-100 dark:text-white/8
                            group-hover:text-[rgb(var(--mt-secondary))]/40 transition-colors">
                    {{ str_pad($loop->iteration, 2, '0', STR_PAD_LEFT) }}
                </span>

                <div class="flex-1 min-w-0">
                    <h4 class="text-sm font-medium text-gray-700 dark:text-white/70
                                line-clamp-2 leading-snug
                                group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                        {!! $similarArticle->title !!}
                    </h4>
                    <span class="text-xs text-gray-400 dark:text-white/25 mt-0.5 block">
                        {{ $similarArticle->publishedThere }}
                    </span>
                </div>

                <i class="fa-solid fa-chevron-right text-[10px] text-gray-300 dark:text-white/15
                        group-hover:text-[rgb(var(--mt-secondary))] flex-shrink-0 transition-colors"></i>
            </a>
            @endforeach
        </div>
    </div>
    @endif
@endif
