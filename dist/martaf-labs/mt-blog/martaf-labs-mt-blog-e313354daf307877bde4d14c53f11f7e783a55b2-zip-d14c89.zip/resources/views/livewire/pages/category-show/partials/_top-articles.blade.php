{{--
  Partial : _top-articles.blade.php
  Widget "Les plus lus" pour sidebar.
  Données : $topArticles
--}}

@if ($this->topArticles->isNotEmpty())
<div class="mt-bg rounded-2xl border border-gray-100 dark:border-white/6 shadow-sm overflow-hidden">

    <div class="flex items-center gap-2 px-5 py-4 border-b border-gray-100 dark:border-white/6">
        <i class="fa-solid fa-fire text-[rgb(var(--mt-secondary))] text-xs"></i>
        <h3 class="text-sm font-bold text-gray-900 dark:text-white">Les plus lus</h3>
    </div>

    <div class="divide-y divide-gray-100 dark:divide-white/5">
        @foreach ($this->topArticles as $article)
        @php $url = mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]); @endphp
        <a href="{{ $url }}" wire:navigate
           class="flex items-center gap-3 px-4 py-3.5 hover:bg-gray-50 dark:hover:bg-white/4 transition-colors group">

            <span class="text-lg font-black tabular-nums select-none flex-shrink-0 w-6 text-center
                          text-gray-100 dark:text-white/8
                          group-hover:text-[rgb(var(--mt-secondary))]/40 transition-colors">
                {{ $loop->iteration }}
            </span>

            <div class="flex-1 min-w-0">
                <p class="text-sm font-medium text-gray-700 dark:text-white/70 line-clamp-2 leading-snug
                            group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                    {!! $article->title !!}
                </p>
                <p class="text-xs text-gray-400 dark:text-white/25 mt-0.5 flex items-center gap-1">
                    <i class="fa-regular fa-eye text-[9px]"></i>
                    {{ $article->viewsCount(true) }}
                </p>
            </div>
        </a>
        @endforeach
    </div>

</div>
@endif
