{{--
  Partial : _sponsored.blade.php
  Section articles sponsorisés.
  Props :
    $cardVariant  variant de card (défaut: 'default')
    $max          nombre max d'articles (défaut: 6)
  Données : $sponsored_articles
--}}

@props([
    'cardVariant' => 'default',
    'max'         => 6,
])

@if ($this->sponsored_articles?->isNotEmpty())
<section>
    {{-- <x-home::section-header
        title="Contenus sponsorisés"
        badge="Sponsorisé"
        icon="fa-solid fa-circle-dollar-to-slot"
    /> --}}

    <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        @foreach ($this->sponsored_articles->take($max) as $article)
        <x-mtblog::post.card :article="$article" :variant="$cardVariant" :show-actions="false" />
        @endforeach
    </div>
</section>
@endif
