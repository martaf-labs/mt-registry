{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT HOME : classic                                           ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Breaking news ticker                                        ║
║    → Hero (article à la une 2/3 + sidebar dernières infos 1/3)  ║
║    → Édition spéciale                                            ║
║    → Articles épinglés numérotés                                 ║
║    → Choix de la rédaction (grille 3 col)                        ║
║    → Blocs par catégories                                        ║
║    → Sponsorisés                                                 ║
║  Usage : blog généraliste, news, actu                            ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div class="space-y-14">
    @section('title', 'Accueil')

    {{-- ── Breaking news ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._breaking-news')

    {{-- ── Hero ────────────────────────────────────────────────────── --}}
    @if ($this->featured_article)
    @php $f = $this->featured_article; @endphp
    <section>
        <x-mtblog::post.hero
            :featured="$f"
            :last-articles="$this->last_articles"
            variant="classic"
        />
    </section>
    @endif

    {{-- ── Édition spéciale ─────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._special-edition')

    {{-- ── Épinglés ─────────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._pinned', [
        'title'   => 'À ne pas manquer',
        'variant' => 'numbered',
    ])

    {{-- ── Choix de la rédaction ───────────────────────────────── --}}
    @if ($this->random_articles->isNotEmpty())
    <section wire:ignore>
        @include('mtblog::livewire.home.partials._section-header', [
            'title'     => 'Choix de la rédaction',
            'icon'      => 'fa-solid fa-newspaper',
            'subtitle'  => 'Notre sélection du moment',
        ])
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->random_articles->take(6) as $article)
            <x-mtblog::post.card :article="$article" variant="default" :show-actions="true" />
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Par catégories ──────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._categories-blocks', [
        'cardVariant' => 'default',
        'columns'     => 4,
    ])

    {{-- ── Sponsorisés ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._sponsored')

</div>
