{{--
  Partial : _pinned.blade.php
  Section "À ne pas manquer" — articles épinglés.
  Props : $title  (défaut: 'À ne pas manquer')
          $variant  'numbered' | 'cards'  (défaut: 'numbered')
  Données : $pinned_articles
--}}

@props([
    'title'   => 'À ne pas manquer',
    'variant' => 'numbered',
])

@php
    $variant = mtblog_option_home('pinned.variant');
@endphp

@if ($this->pinned_articles->isNotEmpty())

<section>
    {{-- En-tête section --}}
    <div class="flex items-center gap-3 mb-5">
        <span class="w-1 h-6 bg-[rgb(var(--mt-secondary))] rounded-full flex-shrink-0"></span>
        <h2 class="text-base font-bold uppercase tracking-wide text-gray-900 dark:text-white">
            {{ $title }}
        </h2>
    </div>

    @if ($variant === 'cards')

    {{-- Variant cards : utilise le composant card --}}
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        @foreach ($this->pinned_articles as $article)
        <x-mtblog::post.card :article="$article" variant="default" :show-actions="false" />
        @endforeach
    </div>

    @else

    {{-- Variant numbered : style original amélioré --}}
    <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        @foreach ($this->pinned_articles as $article)
        @php $url = mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]); @endphp
        <a href="{{ $url }}" wire:navigate
           class="group flex items-start gap-4 p-4 mt-bg rounded-2xl
                  border border-gray-100 dark:border-white/6 shadow-sm
                  hover:shadow-md hover:border-[rgb(var(--mt-secondary))]/20 dark:hover:border-[rgb(var(--mt-secondary))]/20
                  transition-all duration-200">

            <span class="text-4xl font-black leading-none flex-shrink-0 select-none tabular-nums
                          text-[rgb(var(--mt-secondary))]/20 dark:text-[rgb(var(--mt-secondary))]/15
                          group-hover:text-[rgb(var(--mt-secondary))]/40 transition-colors">
                {{ str_pad($loop->iteration, 2, '0', STR_PAD_LEFT) }}
            </span>

            <div class="min-w-0">
                @if ($article->categoryName)
                <span class="text-[11px] font-semibold text-[rgb(var(--mt-secondary))] uppercase tracking-wide">
                    {{ $article->categoryName }}
                </span>
                @endif
                <h4 class="font-semibold text-sm text-gray-800 dark:text-white/80
                            leading-snug mt-0.5 line-clamp-3
                            group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                    {!! $article->title !!}
                </h4>
                <span class="block mt-1.5 text-xs text-gray-400 dark:text-white/30">
                    {{ $article->publishedThere }}
                </span>
            </div>
        </a>
        @endforeach
    </div>

    @endif
</section>

@endif
