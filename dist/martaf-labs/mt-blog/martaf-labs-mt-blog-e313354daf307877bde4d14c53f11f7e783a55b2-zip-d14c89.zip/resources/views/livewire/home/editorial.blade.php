{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT HOME : editorial                                         ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Breaking news ticker                                        ║
║    → Hero split (image droite + contenu gauche)                  ║
║    → 3 colonnes : articles principaux | sidebar sticky           ║
║      Principale : épinglés + grille "choix rédac"               ║
║      Sidebar : dernières infos + top populaires                  ║
║    → Blocs par catégorie (style éditorial)                       ║
║    → Édition spéciale + sponsorisés                              ║
║  Usage : presse sérieuse, revue, analyse, corporate              ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div class="space-y-14">
    @section('title', 'Accueil')

    {{-- ── Breaking news ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.pages.home._breaking-news', ['theme' => 'light'])

    {{-- ── Hero split ─────────────────────────────────────────────── --}}
    @if ($this->featured_article)
    <section>
        <x-mt::hero
            :featured="$this->featured_article"
            :last-articles="$this->last_articles"
            variant="split"
            :show-sidebar="false"
            :show-read-more="true"
        />
    </section>
    @endif

    {{-- ── Grille principale + Sidebar ────────────────────────────── --}}
    <div class="grid gap-8 lg:grid-cols-12">

        {{-- Colonne principale (8) --}}
        <div class="lg:col-span-8 space-y-12">

            {{-- Épinglés --}}
            @include('mtblog::livewire.pages.home._pinned', [
                'title'   => 'À ne pas manquer',
                'variant' => 'numbered',
            ])

            {{-- Choix rédaction --}}
            @if ($this->random_articles->isNotEmpty())
            <section>
                @include('mtblog::livewire.pages.home._section-header', [
                    'title'    => 'Choix de la rédaction',
                    'icon'     => 'fa-solid fa-pen-nib',
                    'subtitle' => 'Notre sélection éditoriale',
                ])
                <div class="grid gap-4 sm:grid-cols-2">
                    @foreach ($this->random_articles->take(6) as $article)
                    <x-mtblog::post.card :article="$article" variant="spotlight" :show-actions="true" />
                    @endforeach
                </div>
            </section>
            @endif

            {{-- Populaires --}}
            @if ($this->popular_articles->isNotEmpty())
            <section>
                @include('mtblog::livewire.pages.home._section-header', [
                    'title'    => 'Tendances',
                    'icon'     => 'fa-solid fa-chart-line',
                    'subtitle' => 'Les plus lus cette semaine',
                ])
                <div class="flex flex-col gap-0">
                    @foreach ($this->popular_articles->take(5) as $article)
                    <x-mtblog::post.card
                        :article="$article"
                        variant="editorial"
                        :index="$loop->iteration"
                        :show-excerpt="true"
                        :show-actions="false"
                    />
                    @endforeach
                </div>
            </section>
            @endif

        </div>

        {{-- Sidebar (4) --}}
        <aside class="lg:col-span-4">
            <div class="sticky top-28 flex flex-col gap-5">

                {{-- Dernières infos --}}
                <div class="mt-bg rounded-2xl overflow-hidden border border-gray-100 dark:border-white/6 shadow-sm">
                    <div class="flex items-center gap-2 px-5 py-4 border-b border-gray-100 dark:border-white/6">
                        <span class="relative flex flex-shrink-0 w-2 h-2">
                            <span class="animate-ping absolute inset-0 rounded-full mt-bg-secondary opacity-75"></span>
                            <span class="relative rounded-full w-2 h-2 mt-bg-secondary"></span>
                        </span>
                        <h3 class="text-sm font-bold mt-text">Dernières infos</h3>
                    </div>
                    <div class="divide-y divide-gray-100 dark:divide-white/5">
                        @forelse ($this->last_articles as $article)
                        @php $aUrl = mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]); @endphp
                        <a href="{{ $aUrl }}" wire:navigate
                           class="flex gap-3 p-4 hover:bg-gray-50 dark:hover:bg-white/4 transition-colors group">
                            <div class="flex-shrink-0 w-14 h-12 rounded-xl overflow-hidden bg-gray-100 dark:bg-white/6">
                                @if ($article->hasFeatured)
                                <img src="{{ $article->getVariantImage('thumbnail') }}" alt="{!! $article->title !!}"
                                     class="object-cover w-full h-full transition-transform duration-300 group-hover:scale-110">
                                @else
                                <div class="w-full h-full flex items-center justify-center">
                                    <i class="fa-regular fa-image text-xs text-gray-300 dark:text-white/15"></i>
                                </div>
                                @endif
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-[11px] text-[rgb(var(--mt-secondary))] font-semibold mb-0.5 uppercase tracking-wide">
                                    {{ $article->publishedDate }}
                                </p>
                                <p class="text-sm font-medium mt-text line-clamp-2 leading-snug
                                            group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                                    {!! $article->title !!}
                                </p>
                            </div>
                        </a>
                        @empty
                        <p class="p-6 text-sm text-center text-gray-400 dark:text-white/30">Aucun article récent.</p>
                        @endforelse
                    </div>
                </div>

                {{-- Édition spéciale (dans sidebar) --}}
                @include('mtblog::livewire.pages.home._special-edition')

            </div>
        </aside>

    </div>

    {{-- ── Blocs par catégorie ─────────────────────────────────── --}}
    @include('mtblog::livewire.pages.home._categories-blocks', [
        'cardVariant' => 'editorial',
        'columns'     => 3,
    ])

    {{-- ── Sponsorisés ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.pages.home._sponsored', ['cardVariant' => 'minimal'])

</div>
