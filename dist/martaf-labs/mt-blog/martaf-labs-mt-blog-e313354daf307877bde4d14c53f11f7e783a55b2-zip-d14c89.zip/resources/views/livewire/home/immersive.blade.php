{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT HOME : immersive                                         ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Hero cinématique plein écran                                ║
║    → Breaking news ticker (sous le hero)                         ║
║    → Grille 2+2 articles populaires                              ║
║    → Édition spéciale                                            ║
║    → Blocs catégories (cards magazine)                           ║
║    → Épinglés + Sponsorisés                                      ║
║  Usage : lifestyle, voyage, culture, sport, photo                ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div class="space-y-14">
    @section('title', 'Accueil')

    {{-- ── Hero cinematic ─────────────────────────────────────────── --}}
    @if ($this->featured_article)
    <section class="-mx-4 sm:-mx-6 lg:-mx-8">
        <x-mtblog::post.hero
            :featured="$this->featured_article"
            :last-articles="$this->last_articles"
            variant="cinematic"
            :show-sidebar="false"
        />
    </section>
    @endif

    {{-- ── Breaking news (sous le hero) ──────────────────────────── --}}
    @include('mtblog::livewire.home.partials._breaking-news', ['theme' => 'light'])

    {{-- ── Populaires : grille 2+2 avec grande carte ──────────────── --}}
    @if ($this->popular_articles->isNotEmpty())
    <section>
        @include('mtblog::livewire.home.partials._section-header', [
            'title'    => 'Tendances',
            'icon'     => 'fa-solid fa-fire',
            'subtitle' => 'Les plus lus cette semaine',
        ])

        {{-- Layout asymétrique : 1 grande + 3 petites sur desktop --}}
        @if ($this->popular_articles->count() >= 4)
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {{-- Grande carte --}}
            <div class="sm:col-span-2 lg:col-span-2">
                <x-mtblog::post.card
                    :article="$this->popular_articles->first()"
                    variant="magazine"
                    class="h-64 lg:h-80"
                    :show-excerpt="true"
                    :show-actions="true"
                />
            </div>
            {{-- Petites cartes --}}
            <div class="flex flex-col gap-4">
                @foreach ($this->popular_articles->skip(1)->take(3) as $article)
                <x-mtblog::post.card
                    :article="$article"
                    variant="chip"
                    :show-views="true"
                />
                @endforeach
            </div>
        </div>
        @else
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->popular_articles as $article)
            <x-mtblog::post.card :article="$article" variant="magazine" :show-actions="true" />
            @endforeach
        </div>
        @endif
    </section>
    @endif

    {{-- ── Édition spéciale ─────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._special-edition')

    {{-- ── Blocs par catégories (cards magazine) ───────────────── --}}
    @include('mtblog::livewire.home.partials._categories-blocks', [
        'cardVariant' => 'magazine',
        'columns'     => 4,
    ])

    {{-- ── Derniers articles en grille ────────────────────────── --}}
    @if ($this->random_articles->isNotEmpty())
    <section>
        @include('mtblog::livewire.home.partials._section-header', [
            'title'    => 'À découvrir',
            'icon'     => 'fa-solid fa-compass',
        ])
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            @foreach ($this->random_articles->take(8) as $article)
            <x-mtblog::post.card :article="$article" variant="default" :show-actions="true" />
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Épinglés ─────────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._pinned', ['variant' => 'cards'])

    {{-- ── Sponsorisés ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._sponsored', ['cardVariant' => 'magazine'])

</div>
