{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT HOME : minimal                                           ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Hero split (sobre, pas de sidebar)                          ║
║    → Breaking news sobre                                         ║
║    → Épinglés en style minimal                                   ║
║    → Derniers articles (cards minimal colonne)                   ║
║    → Sponsorisés (sobres)                                        ║
║  Usage : blog corporate, lettre, newsletter, tech, juridique     ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div class="space-y-14 max-w-4xl mx-auto">
    @section('title', 'Accueil')

    {{-- ── Hero sobre (pas d'image imposante) ─────────────────────── --}}
    @if ($this->featured_article)
    @php $f = $this->featured_article; @endphp
    <section>
        {{-- Simple card "spotlight" en pleine largeur --}}
        <x-mtblog::post.card
            :article="$f"
            variant="spotlight"
            :show-excerpt="true"
            :show-read-more="true"
            :show-actions="true"
            class="rounded-2xl"
        />
    </section>
    @endif

    {{-- ── Breaking news ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._breaking-news', ['theme' => 'light'])

    {{-- ── Édition spéciale ─────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._special-edition')

    {{-- ── Épinglés (style minimal numéroté) ─────────────────────── --}}
    @include('mtblog::livewire.home.partials._pinned', [
        'title'   => 'À ne pas manquer',
        'variant' => 'numbered',
    ])

    {{-- ── Derniers articles (variant minimal) ────────────────────── --}}
    @if ($this->last_articles->isNotEmpty())
    <section>
        @include('mtblog::livewire.home.partials._section-header', [
            'title'    => 'Derniers articles',
            'icon'     => 'fa-regular fa-clock',
            'subtitle' => 'Les publications les plus récentes',
        ])
        <div class="flex flex-col gap-0">
            @foreach ($this->last_articles as $article)
            <x-mtblog::post.card
                :article="$article"
                variant="minimal"
                :show-excerpt="true"
                :show-actions="true"
            />
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Populaires (style editorial) ──────────────────────────── --}}
    @if ($this->popular_articles->isNotEmpty())
    <section>
        @include('mtblog::livewire.home.partials._section-header', [
            'title'    => 'Tendances',
            'icon'     => 'fa-solid fa-chart-line',
        ])
        <div class="flex flex-col gap-0">
            @foreach ($this->popular_articles->take(5) as $article)
            <x-mtblog::post.card
                :article="$article"
                variant="editorial"
                :index="$loop->iteration"
                :show-excerpt="false"
                :show-actions="false"
            />
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Choix rédaction ─────────────────────────────────────── --}}
    @if ($this->random_articles->isNotEmpty())
    <section>
        @include('mtblog::livewire.home.partials._section-header', [
            'title' => 'Choix de la rédaction',
        ])
        <div class="flex flex-col gap-0">
            @foreach ($this->random_articles->take(8) as $article)
            <x-mtblog::post.card
                :article="$article"
                variant="minimal"
                :show-excerpt="false"
                :show-actions="false"
            />
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Sponsorisés ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._sponsored', [
        'cardVariant' => 'minimal',
        'max'         => 3,
    ])

</div>
