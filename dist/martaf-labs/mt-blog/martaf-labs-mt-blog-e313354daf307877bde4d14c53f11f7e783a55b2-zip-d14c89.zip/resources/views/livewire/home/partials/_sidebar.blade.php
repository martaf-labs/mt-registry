{{--
  Partial : _sidebar.blade.php
  Mini-sidebar des blocs « par catégories » (cf. _categories-blocks).
  Widgets configurables via config('mtblog.home.sidebar.widgets.*') :
    stats · popular (les plus lus) · archives · tags · social
  Données : requêtes CACHÉES ici (partial auto-suffisant, cf. _footer-data).
  Couleurs : tokens mt-ui (--mt-ui-*, --mt-text, --mt-secondary) → suit la charte.
--}}
@php
    use Mt\Blog\Models\Article;
    use Mt\Blog\Models\Category;
    use Mt\Blog\Models\Tag;

    $w      = (array) mtblog_config('home.sidebar.widgets');
    $sticky = (bool)  mtblog_config('home.sidebar.sticky');

    $fmt = function ($n) {
        $n = (int) $n;
        return $n >= 1000000 ? round($n / 1000000, 1) . 'M'
             : ($n >= 1000   ? round($n / 1000, 1) . 'k' : (string) $n);
    };

    $popular = ! empty($w['popular'])
        ? cache()->remember('blog.sidebar.popular', 600, fn () =>
            Article::published()->with('category')->orderByDesc('views_count')->take(5)->get())
        : collect();

    $stats = ! empty($w['stats'])
        ? cache()->remember('blog.sidebar.stats', 600, fn () => [
            'articles'   => Article::published()->count(),
            'categories' => Category::where('is_active', true)->count(),
            'views'      => (int) Article::published()->sum('views_count'),
        ])
        : null;

    $archives = ! empty($w['archives'])
        ? cache()->remember('blog.sidebar.archives', 3600, fn () =>
            Article::published()
                ->selectRaw("DATE_FORMAT(published_at, '%Y-%m') as ym, COUNT(*) as total")
                ->groupBy('ym')->orderByDesc('ym')->take(8)->get())
        : collect();

    $tags = ! empty($w['tags'])
        ? cache()->remember('blog.sidebar.tags', 3600, fn () => Tag::popular(18)->get())
        : collect();

    $socialLinks = ! empty($w['social']) ? array_filter([
        'facebook'  => config('mtblog.social.facebook'),
        'twitter'   => config('mtblog.social.twitter'),
        'instagram' => config('mtblog.social.instagram'),
        'youtube'   => config('mtblog.social.youtube'),
        'linkedin'  => config('mtblog.social.linkedin'),
        'telegram'  => config('mtblog.social.telegram'),
        'tiktok'    => config('mtblog.social.tiktok'),
        'whatsapp'  => config('mtblog.social.whatsapp'),
    ]) : [];

    $socialIcons = [
        'facebook'  => ['icon' => 'fa-brands fa-facebook-f', 'color' => '#1877F2'],
        'twitter'   => ['icon' => 'fa-brands fa-x-twitter',  'color' => '#0F1419'],
        'instagram' => ['icon' => 'fa-brands fa-instagram',  'color' => '#E1306C'],
        'youtube'   => ['icon' => 'fa-brands fa-youtube',    'color' => '#FF0000'],
        'linkedin'  => ['icon' => 'fa-brands fa-linkedin-in','color' => '#0A66C2'],
        'telegram'  => ['icon' => 'fa-brands fa-telegram',   'color' => '#2AABEE'],
        'tiktok'    => ['icon' => 'fa-brands fa-tiktok',     'color' => '#010101'],
        'whatsapp'  => ['icon' => 'fa-brands fa-whatsapp',   'color' => '#25D366'],
    ];

    // Style de carte commun (surface navy via tokens)
    $cardStyle = 'background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgba(var(--mt-ui-card-border), 0.7);';
    $sepStyle  = 'border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6);';
@endphp

<div class="{{ $sticky ? 'lg:sticky lg:top-24' : '' }} space-y-6">

    {{-- ── Chiffres clés ───────────────────────────────────────── --}}
    @if ($stats)
    <section class="rounded-2xl overflow-hidden" style="{{ $cardStyle }}">
        <div class="grid grid-cols-3 text-center divide-x" style="border-color: rgba(var(--mt-ui-card-border), 0.5)">
            <div class="px-2 py-4">
                <div class="text-xl font-black mt-text">{{ $fmt($stats['articles']) }}</div>
                <div class="text-[10px] uppercase tracking-wider mt-text-muted mt-0.5">Articles</div>
            </div>
            <div class="px-2 py-4">
                <div class="text-xl font-black mt-text">{{ $fmt($stats['categories']) }}</div>
                <div class="text-[10px] uppercase tracking-wider mt-text-muted mt-0.5">Rubriques</div>
            </div>
            <div class="px-2 py-4">
                <div class="text-xl font-black mt-text">{{ $fmt($stats['views']) }}</div>
                <div class="text-[10px] uppercase tracking-wider mt-text-muted mt-0.5">Vues</div>
            </div>
        </div>
    </section>
    @endif

    {{-- ── Les plus lus ────────────────────────────────────────── --}}
    @if ($popular->isNotEmpty())
    <section class="rounded-2xl overflow-hidden" style="{{ $cardStyle }}">
        <header class="flex items-center gap-2 px-4 py-3" style="{{ $sepStyle }}">
            <i class="fa-solid fa-fire text-[rgb(var(--mt-secondary))] text-sm"></i>
            <h3 class="text-sm font-bold uppercase tracking-wide mt-text">Les plus lus</h3>
        </header>
        <div class="divide-y" style="border-color: rgba(var(--mt-ui-card-border), 0.45)">
            @foreach ($popular as $i => $a)
            @php $aUrl = mt_get_route('home_articles_show', ['slug' => $a->slug, 'id' => $a->id]); @endphp
            <a href="{{ $aUrl }}" wire:navigate
               class="group flex items-center gap-3 px-4 py-3 transition-colors hover:bg-[rgba(var(--mt-secondary),0.06)]">
                <span class="flex-shrink-0 w-6 text-center text-lg font-black tabular-nums leading-none"
                      style="color: rgba(var(--mt-secondary), {{ $i === 0 ? '1' : '0.35' }})">
                    {{ $i + 1 }}
                </span>
                <div class="flex-shrink-0 w-12 h-12 rounded-lg overflow-hidden" style="background: rgba(var(--mt-text),0.05)">
                    @if ($a->hasFeatured)
                    <img src="{{ $a->getVariantImage('thumbnail') }}" alt="{!! $a->title !!}"
                         class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                    @endif
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-[13px] font-semibold mt-text leading-snug line-clamp-2
                              group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                        {!! $a->title !!}
                    </p>
                    <p class="text-[11px] mt-text-muted mt-0.5">
                        <i class="fa-regular fa-eye mr-1"></i>{{ $a->viewsCount(true) }}
                    </p>
                </div>
            </a>
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Archives ────────────────────────────────────────────── --}}
    @if ($archives->isNotEmpty())
    <section class="rounded-2xl overflow-hidden" style="{{ $cardStyle }}">
        <header class="flex items-center gap-2 px-4 py-3" style="{{ $sepStyle }}">
            <i class="fa-regular fa-calendar text-[rgb(var(--mt-secondary))] text-sm"></i>
            <h3 class="text-sm font-bold uppercase tracking-wide mt-text">Archives</h3>
        </header>
        <ul class="p-2">
            @foreach ($archives as $row)
            @php $label = \Carbon\Carbon::createFromFormat('Y-m', $row->ym)->translatedFormat('F Y'); @endphp
            <li class="flex items-center justify-between gap-2 px-3 py-2 rounded-xl
                       transition-colors hover:bg-[rgba(var(--mt-secondary),0.06)]">
                <span class="text-[13px] mt-text capitalize">{{ $label }}</span>
                <span class="text-[10px] font-bold px-2 py-0.5 rounded-full"
                      style="background: rgba(var(--mt-secondary),0.12); color: rgb(var(--mt-secondary))">
                    {{ $row->total }}
                </span>
            </li>
            @endforeach
        </ul>
    </section>
    @endif

    {{-- ── Tags populaires ─────────────────────────────────────── --}}
    @if ($tags->isNotEmpty())
    <section class="rounded-2xl overflow-hidden" style="{{ $cardStyle }}">
        <header class="flex items-center gap-2 px-4 py-3" style="{{ $sepStyle }}">
            <i class="fa-solid fa-hashtag text-[rgb(var(--mt-secondary))] text-sm"></i>
            <h3 class="text-sm font-bold uppercase tracking-wide mt-text">Tags populaires</h3>
        </header>
        <div class="flex flex-wrap gap-2 p-4">
            @foreach ($tags as $tag)
            <a href="{{ mt_get_route('home') }}?q={{ urlencode($tag->name) }}"
               class="text-[12px] px-2.5 py-1 rounded-full transition-colors mt-text
                      hover:text-[rgb(var(--mt-secondary))]"
               style="background: rgba(var(--mt-text),0.05)">
                #{{ $tag->name }}
            </a>
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Réseaux sociaux ─────────────────────────────────────── --}}
    @if (! empty($socialLinks))
    <section class="rounded-2xl overflow-hidden" style="{{ $cardStyle }}">
        <header class="flex items-center gap-2 px-4 py-3" style="{{ $sepStyle }}">
            <i class="fa-solid fa-share-nodes text-[rgb(var(--mt-secondary))] text-sm"></i>
            <h3 class="text-sm font-bold uppercase tracking-wide mt-text">Suivez-nous</h3>
        </header>
        <div class="flex flex-wrap gap-2 p-4">
            @foreach ($socialLinks as $network => $url)
            @php $info = $socialIcons[$network] ?? ['icon' => 'fa-solid fa-link', 'color' => '#666']; @endphp
            <a href="{{ $url }}" target="_blank" rel="noopener noreferrer" title="{{ ucfirst($network) }}"
               class="w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200
                      hover:-translate-y-0.5 hover:text-white"
               style="background: rgba(var(--mt-text),0.05); color: {{ $info['color'] }}"
               onmouseover="this.style.background='{{ $info['color'] }}'; this.style.color='#fff'"
               onmouseout="this.style.background='rgba(var(--mt-text),0.05)'; this.style.color='{{ $info['color'] }}'">
                <i class="{{ $info['icon'] }} text-sm"></i>
            </a>
            @endforeach
        </div>
    </section>
    @endif

</div>
