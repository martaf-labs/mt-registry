{{--
  Partial : _breaking-news.blade.php
  Bandeau breaking news / flash info.
  Props : $theme  'dark' | 'light'  (défaut: 'dark')
  Données : $breaking_news
--}}

@props(['theme' => 'dark'])

@if ($hasBreakingNews && $this->breaking_news->isNotEmpty())

@php $isDark = $theme === 'dark'; @endphp

<div class="flex items-stretch gap-0 rounded-xl overflow-hidden
            {{ $isDark
                ? 'bg-[rgb(var(--mt-secondary))]/[0.06] dark:bg-white/[0.03]'
                : 'mt-bg' }}">

    {{-- Badge "Flash" --}}
    <div class="flex items-center gap-1.5 px-3 py-2.5 bg-[rgb(var(--mt-secondary))] flex-shrink-0">
        <i class="fa-solid fa-bolt text-white text-xs animate-pulse"></i>
        <span class="text-white text-[11px] font-black uppercase tracking-wider hidden sm:inline">Flash</span>
    </div>

    {{-- Ticker --}}
    <div class="flex-1 overflow-hidden relative px-4 py-2.5 flex items-center"
         x-data="{
             items: {{ $this->breaking_news->pluck('title')->toJson() }},
             urls:  {{ $this->breaking_news->map(fn($a) => mt_get_route('home_articles_show', ['slug' => $a->slug, 'id' => $a->id]))->toJson() }},
             current: 0,
             interval: null,
             init() {
                 this.interval = setInterval(() => {
                     this.current = (this.current + 1) % this.items.length;
                 }, 5000);
             }
         }">
        <template x-for="(item, i) in items" :key="i">
            <a :href="urls[i]"
               wire:navigate
               x-show="current === i"
               x-transition:enter="transition ease-out duration-300"
               x-transition:enter-start="opacity-0 translate-y-2"
               x-transition:enter-end="opacity-100 translate-y-0"
               x-transition:leave="transition ease-in duration-200"
               x-transition:leave-start="opacity-100 translate-y-0"
               x-transition:leave-end="opacity-0 -translate-y-2"
               class="text-sm font-medium truncate
                      {{ $isDark
                          ? 'text-gray-700 dark:text-white/70 hover:text-[rgb(var(--mt-secondary))]'
                          : 'text-gray-700 dark:text-white/70 hover:text-[rgb(var(--mt-secondary))]' }}
                      transition-colors duration-150 absolute inset-x-4 top-1/2 -translate-y-1/2"
               x-text="item">
            </a>
        </template>
    </div>

    {{-- Dots navigation --}}
    @if ($this->breaking_news->count() > 1)
    <div class="flex items-center gap-1.5 px-3 flex-shrink-0"
         x-data
         x-ref="dots">
        @foreach ($this->breaking_news as $i => $news)
        <button @click="$dispatch('set-ticker', {{ $i }})"
                class="w-1.5 h-1.5 rounded-full transition-all duration-300
                       {{ $i === 0
                           ? 'bg-[rgb(var(--mt-secondary))]'
                           : 'bg-gray-300 dark:bg-white/20 hover:bg-[rgb(var(--mt-secondary))]/50' }}">
        </button>
        @endforeach
    </div>
    @endif

</div>

@endif
