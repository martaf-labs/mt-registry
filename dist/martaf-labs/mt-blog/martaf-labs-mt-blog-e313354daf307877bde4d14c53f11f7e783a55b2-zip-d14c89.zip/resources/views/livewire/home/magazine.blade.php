{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT HOME : magazine                                          ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → Breaking news ticker                                        ║
║    → Hero "stack" (grande une + 3 sous-articles)                 ║
║    → Édition spéciale                                            ║
║    → Grille asymétrique populaires (1 large + 2 + 2)            ║
║    → 2 colonnes : Rédaction | Épinglés                           ║
║    → Blocs catégorie (asymétrique magazine)                      ║
║    → Sponsorisés + Derniers articles sous forme chips            ║
║  Usage : magazine lifestyle, culture, sport, gastronomie         ║
╚══════════════════════════════════════════════════════════════════╝
--}}

<div class="space-y-14">
    @section('title', 'Accueil')

    {{-- ── Breaking news ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._breaking-news')

    {{-- ── Hero stack ──────────────────────────────────────────────── --}}
    @if ($this->featured_article)
    <section>
        <x-mt::hero
            :featured="$this->featured_article"
            :sub-articles="$this->last_articles->take(3)"
            variant="stack"
            :show-sidebar="false"
        />
    </section>
    @endif

    {{-- ── Édition spéciale ─────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._special-edition')

    {{-- ── Populaires : grille asymétrique 5 colonnes ─────────────── --}}
    @if ($this->popular_articles->count() >= 3)
    <section>
        @include('mtblog::livewire.home.partials._section-header', [
            'title'    => 'Tendances',
            'icon'     => 'fa-solid fa-fire',
            'subtitle' => 'Les plus lus cette semaine',
        ])

        <div class="grid lg:grid-cols-5 gap-5">
            {{-- Grande carte --}}
            <div class="lg:col-span-3">
                <x-mtblog::post.card
                    :article="$this->popular_articles->first()"
                    variant="magazine"
                    class="h-72 lg:h-96"
                    :show-excerpt="true"
                    :show-actions="true"
                />
            </div>
            {{-- 2 cartes empilées --}}
            <div class="lg:col-span-2 flex flex-col gap-5">
                @foreach ($this->popular_articles->skip(1)->take(2) as $article)
                <x-mtblog::post.card :article="$article" variant="default" :show-actions="true" />
                @endforeach
            </div>
        </div>

        {{-- Ligne supplémentaire (3 articles) --}}
        @if ($this->popular_articles->count() > 3)
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 mt-5">
            @foreach ($this->popular_articles->skip(3)->take(3) as $article)
            <x-mtblog::post.card :article="$article" variant="default" :show-actions="true" />
            @endforeach
        </div>
        @endif
    </section>
    @endif

    {{-- ── 2 colonnes : Choix rédaction | Épinglés ────────────────── --}}
    <div class="grid lg:grid-cols-2 gap-10">

        {{-- Choix de la rédaction --}}
        @if ($this->random_articles->isNotEmpty())
        <section>
            @include('mtblog::livewire.home.partials._section-header', [
                'title'    => 'Choix de la rédaction',
                'icon'     => 'fa-solid fa-pen-nib',
            ])
            <div class="flex flex-col gap-0">
                @foreach ($this->random_articles->take(5) as $article)
                <x-mtblog::post.card
                    :article="$article"
                    variant="minimal"
                    :show-excerpt="false"
                    :show-actions="false"
                />
                @endforeach
            </div>
        </section>
        @endif

        {{-- À ne pas manquer --}}
        @include('mtblog::livewire.home.partials._pinned', [
            'title'   => 'À ne pas manquer',
            'variant' => 'numbered',
        ])

    </div>

    {{-- ── Blocs par catégorie ─────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._categories-blocks', [
        'cardVariant' => 'default',
        'columns'     => 4,
    ])

    {{-- ── Derniers articles en chips ──────────────────────────── --}}
    @if ($this->last_articles->isNotEmpty())
    <section>
        @include('mtblog::livewire.home.partials._section-header', [
            'title'    => 'À découvrir aussi',
            'icon'     => 'fa-solid fa-compass',
        ])
        <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($this->random_articles->skip(6)->take(6) as $article)
            <x-mtblog::post.card :article="$article" variant="chip" :show-views="true" />
            @endforeach
        </div>
    </section>
    @endif

    {{-- ── Sponsorisés ─────────────────────────────────────────── --}}
    @include('mtblog::livewire.home.partials._sponsored', ['cardVariant' => 'spotlight'])

</div>
