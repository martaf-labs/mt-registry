{{--
  Partial : _categories-blocks.blade.php
  Blocs d'articles par rubrique (4 catégories max).
  Props :
    $cardVariant  variant de card à utiliser (défaut: 'default')
    $columns      nombre de colonnes articles par catégorie (défaut: 4)
  Données : $featured_categories (collection de ['category', 'articles'])
--}}

@props([
    'cardVariant' => 'default',
    'columns'     => 4,
])

@if ($this->featured_categories->isNotEmpty())
@php $hasSidebar = (bool) mtblog_config('home.sidebar.enabled'); @endphp
<div class="grid grid-cols-1 gap-8 {{ $hasSidebar ? 'lg:grid-cols-12' : '' }}">

  {{-- Colonne principale : les blocs par rubrique --}}
  <div class="space-y-12 min-w-0 {{ $hasSidebar ? 'lg:col-span-8 xl:col-span-9' : '' }}">
    @foreach ($this->featured_categories as $block)
    @php
        $cat = $block['category'];
        $articles = $block['articles'];
    @endphp

    <section>
        {{-- En-tête rubrique --}}
        <div class="flex items-center justify-between gap-3 mb-5">
            <div class="flex items-center gap-2.5">
                <span class="w-1 h-6 rounded-full flex-shrink-0" style="background: {{ $cat->color ?? 'rgb(var(--mt-secondary))' }}"></span>
                @if ($cat->icon)
                <span class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style="background: {{ $cat->color ?? 'rgb(var(--mt-secondary))' }}20">
                    <i class="{{ $cat->icon }} text-xs" style="color: {{ $cat->color ?? 'rgb(var(--mt-secondary))' }}"></i>
                </span>
                @endif
                <h2 class="text-base font-bold uppercase tracking-wide text-gray-900 dark:text-white">
                    {{ $cat->name }}
                </h2>
            </div>
            <a href="{{ mt_get_route('home_categories_show', ['slug' => $cat->slug]) }}" wire:navigate
               class="flex items-center gap-1.5 text-xs font-semibold
                      text-gray-400 dark:text-white/30 hover:text-[rgb(var(--mt-secondary))] hover:gap-2.5
                      transition-all duration-200">
                Tout voir <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>

        {{-- Articles de la rubrique --}}
        @if ($columns === 4 && $articles->count() >= 3)

        {{-- Layout « Une éditoriale » : grande une (image cadrée + contenu plein) + liste classée.
             On n'écrit JAMAIS le titre sur l'image (illisible selon la source) : il vit sur la surface. --}}
        @php
            $lead    = $articles->first();
            $rest    = $articles->skip(1)->take(3);
            $leadUrl = mt_get_route('home_articles_show', ['slug' => $lead->slug, 'id' => $lead->id]);
            $accent  = $cat->color ?? 'rgb(var(--mt-secondary))';
        @endphp
        <div class="grid lg:grid-cols-5 gap-6">

            {{-- LA UNE --}}
            <article class="lg:col-span-3 group flex flex-col rounded-2xl overflow-hidden"
                     style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgba(var(--mt-ui-card-border), 0.7)">
                <a href="{{ $leadUrl }}" wire:navigate
                   class="relative block h-44 sm:h-48 lg:h-52 overflow-hidden" style="background: rgba(var(--mt-text),0.06)">
                    @if ($lead->hasFeatured)
                    <img src="{{ $lead->getVariantImage('large') }}" alt="{!! $lead->title !!}"
                         class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105">
                    @endif
                    <span class="absolute top-3 left-3 text-white text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-full shadow"
                          style="background: {{ $accent }}">
                        {{ $lead->categoryName }}
                    </span>
                </a>
                <div class="flex flex-col flex-1 p-5 gap-2.5">
                    <h3 class="text-lg lg:text-xl font-bold leading-snug mt-text line-clamp-3
                               group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                        <a href="{{ $leadUrl }}" wire:navigate>{!! $lead->title !!}</a>
                    </h3>
                    @if ($lead->excerpt)
                    <p class="text-sm mt-text-muted line-clamp-2">{{ $lead->excerpt }}</p>
                    @endif
                    <div class="mt-auto pt-2 flex items-center gap-3 text-xs mt-text-muted">
                        <span>{{ $lead->publishedThere }}</span>
                        @if ($lead->views_count > 0)
                        <span class="inline-flex items-center gap-1"><i class="fa-regular fa-eye"></i>{{ $lead->viewsCount(true) }}</span>
                        @endif
                    </div>
                </div>
            </article>

            {{-- LISTE CLASSÉE --}}
            <div class="lg:col-span-2 flex flex-col divide-y" style="border-color: rgba(var(--mt-ui-card-border), 0.5)">
                @foreach ($rest as $article)
                @php $aUrl = mt_get_route('home_articles_show', ['slug' => $article->slug, 'id' => $article->id]); @endphp
                <a href="{{ $aUrl }}" wire:navigate class="group flex gap-4 py-4 first:pt-0 last:pb-0">
                    <div class="relative flex-shrink-0 w-24 h-20 rounded-xl overflow-hidden"
                         style="background: rgba(var(--mt-text),0.06)">
                        @if ($article->hasFeatured)
                        <img src="{{ $article->getVariantImage('thumbnail') }}" alt="{!! $article->title !!}"
                             class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110">
                        @endif
                    </div>
                    <div class="flex-1 min-w-0 flex flex-col justify-center gap-1">
                        <span class="text-[11px] font-bold uppercase tracking-wider" style="color: {{ $accent }}">
                            {{ $article->categoryName }}
                        </span>
                        <h4 class="text-sm font-semibold mt-text leading-snug line-clamp-2
                                   group-hover:text-[rgb(var(--mt-secondary))] transition-colors">
                            {!! $article->title !!}
                        </h4>
                        <div class="flex items-center gap-2 text-[11px] mt-text-muted">
                            <span>{{ $article->publishedThere }}</span>
                            @if ($article->views_count > 0)<span>· {{ $article->viewsCount(true) }}</span>@endif
                        </div>
                    </div>
                </a>
                @endforeach
            </div>
        </div>

        @else

        {{-- Grille standard --}}
        <div class="grid gap-4 sm:grid-cols-2 {{ $columns >= 3 ? 'lg:grid-cols-3' : 'lg:grid-cols-2' }}">
            @foreach ($articles->take($columns) as $article)
            <x-mtblog::post.card :article="$article" :variant="$cardVariant" :show-actions="false" />
            @endforeach
        </div>

        @endif
    </section>

    @endforeach
  </div>

  {{-- Mini-sidebar optionnelle (widgets configurables) --}}
  @if ($hasSidebar)
  <aside class="lg:col-span-4 xl:col-span-3">
      @include('mtblog::livewire.home.partials._sidebar')
  </aside>
  @endif

</div>
@endif
