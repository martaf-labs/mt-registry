{{--
  Partial : _section-header.blade.php
  En-tête de section réutilisable.
  Props :
    $title     string  Titre de la section (requis)
    $subtitle  string  Sous-titre optionnel
    $icon      string  Classe FontAwesome optionnelle
    $href      string  URL "Voir tout" optionnelle
    $hrefLabel string  Label du lien (défaut: 'Voir tout')
    $badge     string  Badge label optionnel (ex: 'Sponsorisé')
--}}

@props([
    'title'     => '',
    'subtitle'  => null,
    'icon'      => null,
    'href'      => null,
    'hrefLabel' => 'Voir tout',
    'badge'     => null,
])

<div class="flex items-center justify-between gap-3 mb-5">
    <div class="flex items-center gap-3 min-w-0">
        <span class="w-1 h-6 bg-[rgb(var(--mt-secondary))] rounded-full flex-shrink-0"></span>
        @if ($icon)
        <i class="{{ $icon }} text-[rgb(var(--mt-secondary))] text-sm flex-shrink-0"></i>
        @endif
        <div class="min-w-0">
            <div class="flex items-center gap-2 flex-wrap">
                <h2 class="text-base font-bold uppercase tracking-wide text-gray-900 dark:text-white">
                    {{ $title }}
                </h2>
                @if ($badge)
                <span class="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full
                              bg-gray-100 dark:bg-white/8 text-gray-500 dark:text-white/40">
                    {{ $badge }}
                </span>
                @endif
            </div>
            @if ($subtitle)
            <p class="text-xs text-gray-400 dark:text-white/30 mt-0.5">{{ $subtitle }}</p>
            @endif
        </div>
    </div>

    @if ($href)
    <a href="{{ $href }}" wire:navigate
       class="flex-shrink-0 flex items-center gap-1.5 text-xs font-semibold
              text-[rgb(var(--mt-secondary))] hover:gap-2.5 transition-all duration-200">
        {{ $hrefLabel }} <i class="fa-solid fa-arrow-right text-[10px]"></i>
    </a>
    @endif
</div>
