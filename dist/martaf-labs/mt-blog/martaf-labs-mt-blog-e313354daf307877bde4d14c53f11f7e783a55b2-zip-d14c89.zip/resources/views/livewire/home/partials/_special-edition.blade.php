{{--
  Partial : _special-edition.blade.php
  Bandeau "Édition Spéciale" configurable.
  Données : $special_edition (array|null)
  Structure array : ['label', 'description', 'url', 'cta']
--}}

@if (!is_null($this->special_edition))
@php $se = $this->special_edition; @endphp

<div class="relative overflow-hidden rounded-2xl
             bg-gradient-to-r from-[rgb(var(--mt-secondary))] to-[rgb(var(--mt-secondary))]/80
             text-white p-5 sm:p-6
             flex flex-col sm:flex-row items-center justify-between gap-4
             shadow-lg shadow-[rgb(var(--mt-secondary))]/20">

    {{-- Texture déco --}}
    <div class="absolute inset-0 pointer-events-none opacity-8"
         style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;">
    </div>

    <div class="relative flex flex-col sm:flex-row items-center gap-4">
        <div class="flex-shrink-0 w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
            <i class="fa-solid fa-star text-white"></i>
        </div>
        <div>
            <span class="block text-lg sm:text-2xl font-black tracking-tight uppercase">
                {{ $se['label'] ?? 'Édition Spéciale' }}
            </span>
            @if (!empty($se['description']))
            <p class="text-sm text-white/75 mt-0.5 hidden sm:block max-w-md">{{ $se['description'] }}</p>
            @endif
        </div>
    </div>

    @if (!empty($se['url']))
    <a href="{{ $se['url'] }}" wire:navigate
       class="relative flex-shrink-0 bg-white text-[rgb(var(--mt-secondary))]
              px-5 py-2.5 rounded-xl font-bold text-sm
              hover:bg-gray-50 hover:scale-105 transition-all shadow-md whitespace-nowrap">
        {{ $se['cta'] ?? 'Lire le dossier' }}
        <i class="fa-solid fa-arrow-right ml-2 text-xs"></i>
    </a>
    @endif

</div>
@endif
