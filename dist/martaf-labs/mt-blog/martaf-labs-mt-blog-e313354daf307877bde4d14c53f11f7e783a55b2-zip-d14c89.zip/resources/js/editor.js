document.addEventListener("alpine:init", () => {

    Alpine.data("mtBlogEditor", (config) => ({
        editor: null,
        editorId: "editor-" + Math.random().toString(36).slice(2),
        fieldName: config.fieldName,
        initialData: config.initialData,

        async init() {
            await this.loadEditor();
            this.initEditor();
        },

        async loadEditor() {
            if (window.EditorJS) return;

            await Promise.all([
                this.loadScript("https://cdn.jsdelivr.net/npm/@editorjs/editorjs@latest"),
                this.loadScript("https://cdn.jsdelivr.net/npm/@editorjs/header@latest"),
                this.loadScript("https://cdn.jsdelivr.net/npm/@editorjs/paragraph@latest"),
                this.loadScript("https://cdn.jsdelivr.net/npm/@editorjs/list@latest"),
                this.loadScript("https://cdn.jsdelivr.net/npm/@editorjs/quote@latest"),
                this.loadScript("https://cdn.jsdelivr.net/npm/@editorjs/image@latest"),
                this.loadScript("https://cdn.jsdelivr.net/npm/@editorjs/embed@latest"),
            ]);
        },

        initEditor() {
            this.editor = new EditorJS({
                holder: this.editorId,
                autofocus: true,
                data: { blocks: this.initialData ?? [] },

                onChange: async () => {
                    const data = await this.editor.save();
                    this.$refs.input.value = JSON.stringify(data.blocks);
                },

                tools: {
                    header: Header,
                    paragraph: Paragraph,
                    list: List,
                    quote: Quote,
                    embed: Embed,
                    image: {
                        class: ImageTool,
                        config: {
                            endpoints: {
                                byFile: "/mtblog/upload-image",
                                byUrl: "/mtblog/fetch-image"
                            },
                            additionalRequestHeaders: {
                                'X-CSRF-TOKEN': document
                                    .querySelector('meta[name="csrf-token"]')
                                    .getAttribute('content')
                            }
                        }
                    },


                }
            });
        },

        toggleDarkMode() {
            document.documentElement.classList.toggle('dark');
        },

        loadScript(src) {
            return new Promise(resolve => {
                const s = document.createElement("script");
                s.src = src;
                s.onload = resolve;
                document.head.appendChild(s);
            });
        }
    }))
})
