<?php

use Illuminate\Support\Facades\Route;
use Mt\Blog\Http\Controllers\MediaController;
use Mt\Blog\Http\Controllers\NewsletterController;

// Routes utilitaires du package : session + CSRF (`web`) suffisent.
// - upload/fetch-image : appelées par l'éditeur (page admin déjà protégée, POST sous CSRF).
// - newsletter.unsubscribe : lien PUBLIC depuis un email → surtout pas derrière `auth`.
Route::prefix('mtblog')
    ->middleware(['web'])
    ->group(function () {
        Route::post('/upload-image', [MediaController::class, 'upload']);
        Route::post('/fetch-image', [MediaController::class, 'fetch']);

        Route::get('/newsletter/unsubscribe/{token}', [NewsletterController::class, 'unsubscribe'])->name('newsletter.unsubscribe');
    });

