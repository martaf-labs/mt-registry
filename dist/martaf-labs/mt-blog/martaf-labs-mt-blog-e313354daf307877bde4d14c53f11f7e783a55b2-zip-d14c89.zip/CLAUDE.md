# mt-blog — North Star (à lire AVANT toute modification)

> Package **domaine « blog / journal en ligne »** de l'écosystème martaf-labs.
> C'est le **socle réutilisable** de toute app de type blog/presse (ex. hôte de
> référence : `bandeinfo`). Il consomme `mt-ui` (UI/UX générique) + `mt-media`
> (médias) + `mt-foundation` (modèles/i18n) + `mt-auth` (users/rôles).
> La logique métier blog vit ICI ; l'hôte ne porte que le câblage (routes, config,
> sidebar, charte). Cf. North Star mt-ui pour les règles UI transverses.

## 0. Principe directeur — apps MODERNES

Fluidité et **adaptativité à tous les supports** (mobile → desktop) sont
**prioritaires**, pas une finition. Chaque écran/variant doit être pensé
mobile-first, responsive (breakpoints `sm/md/lg`), avec transitions sobres.
Toute nouvelle vue qui n'est pas fluide sur petit écran est considérée incomplète.

> **Règle design actée — ne JAMAIS écrire un titre/texte par-dessus une image** :
> les images sont imprévisibles (scans de documents, captures, portraits) → texte
> illisible une fois sur deux. Pattern : image **cadrée en hauteur fixe** + texte sur la
> **surface** (carte). L'overlay n'est toléré que si l'image s'y prête vraiment.

## 1. Le cœur : moteur de templates piloté par config

Chaque **surface** du front a N **variants** (skins) interchangeables + des
**options** (toggles de features). Tout est piloté par `config/mtblog.php` (que
l'hôte peut surcharger), jamais en dur.

| Surface | Variants | Sélection |
|---|---|---|
| `home` | classic · editorial · immersive · magazine · minimal | `config('mtblog.home.layout')` |
| `header` | (idem 5) | `config('mtblog.header.layout')` |
| `footer` | (idem 5) | `config('mtblog.footer.layout')` |
| `article-show` | (idem 5) | `config('mtblog.article-show.layout')` |
| `category-show` | (idem 5) | `config('mtblog.category-show.layout')` |

**Pattern de dispatch (à respecter pour toute nouvelle surface) :**
- Vue composant : `…/index.blade.php` → `@include('mtblog::…'.mtblog_config('<surface>.layout'))`.
- Composant Livewire : `view('mtblog::livewire.<surface>.'.$this->layout)` (le `$layout`
  est lu dans `mount()` via `mtblog_config('<surface>.layout')`).
- Les variants vivent dans des fichiers frères (`home/classic.blade.php`, `home/editorial.blade.php`…),
  les morceaux communs dans `…/partials/_*.blade.php`.

**Options (feature flags) :** chaque surface + les composants `post-card`/`post-hero`
ont un bloc `options` lu via les helpers `mtblog_option_*()`. Un variant NE code pas
ses features en dur : il teste l'option (ex. `@if(mtblog_option_article_show('share'))`).

## 2. Helpers (src/Helpers/helpers.php)

- `mtblog_config('home.layout')` → lit `config('mtblog.<key>')`.
- `mtblog_option_home|header|footer|article_show|category_show|card|hero('x')` → toggles.
- `render_blocks($blocks)` → rendu du contenu structuré (BlockRenderer).
- ⚠️ **`mt_get_route()` n'est PAS ici** : il est fourni par **mt-ui**. Ne pas le redéfinir.

## 3. Routes — l'hôte est maître (couplage par clés logiques)

Le front réfère des **clés logiques** stables, pas des noms de route :
`mt_get_route('home_articles_show', ['slug'=>…, 'id'=>…])`. Le helper mt-ui
résout via le **`config/routes.php` de l'hôte** (`config('routes.<clé>')` → nom de
route réel), puis `route()`. Clé/route absente → **`''`** (lien inerte, pas de fatal).

> Conséquence : tout nouvel écran qui pointe vers une route DOIT avoir sa clé dans
> le `config/routes.php` de l'hôte, sinon le lien est silencieusement vide.
> Clés blog actuelles : `home`, `home_articles_show`, `home_categories_show`
> (+ `home_articles`, `home_categories`).
> Les routes elles-mêmes sont définies par l'hôte (`routes/web.php`) — le package
> ne déclare que ses routes utilitaires (upload image éditeur, newsletter unsubscribe),
> sous middleware `['web']` (unsubscribe = lien public, surtout pas `auth`).

## 4. Icônes — split assumé admin / front

- **Back-office (formulaires, tables, modals)** : `mt-icons` **inline** (`<x-mt::icon name="…">`),
  noms anglais courts. Cf. North Star mt-ui.
- **Front public** : **FontAwesome** (chargé par mt-ui `partials/head.blade.php`,
  local + CDN fallback). Justifié : marques (`fa-brands fa-facebook/whatsapp/x-twitter…`)
  et richesse iconographique absentes de mt-icons. C'est un choix, pas un bug.

## 5. Couleurs / thème (état + dette)

- Le front utilise `--mt-secondary` comme **accent de marque** (titres au hover, badges,
  barres) + des dégradés `--mt-flag-*` (drapeau, personnalisable par projet).
- ⚠️ **Dette connue** : les cards/partials emploient encore des couleurs **brutes**
  (`text-gray-900 dark:text-white`, `border-gray-100 dark:border-white/8`) au lieu des
  **tokens sémantiques** mt-ui (`mt-text`, `mt-bg`, `mt-card`, `--mt-ui-*`). Donc la
  charte per-tenant n'irrigue que l'accent, pas les surfaces/textes. Réconciliation à
  faire écran par écran (objectif : la charte de l'hôte pilote *tout* le front).

## 6. Données (composants Livewire)

`Home`, `Pages\ArticleShow`, `Pages\CategoryShow` exposent des `#[Computed]` propres
(featured, pinned, breaking, sponsored, populaires, par-catégorie avec dédoublonnage).
Étendre la donnée = ajouter un computed + un `@if(option)` dans les variants, jamais
de requête dans la vue (sauf cache court justifié, ex. menu header).

## 7. Conventions

- **Nouveau variant** = un fichier blade frère +, au besoin, un partial commun. Pas de
  `if ($layout === …)` géant dans une seule vue.
- **Composants Livewire admin** : à enregistrer dans `MtBlogServiceProvider` (sinon 419).
- **Mobile-first / responsive** : obligatoire (cf. §0).
- **i18n** : champs traduisibles via mt-foundation ; ne pas aplatir dans un hook.
- **Pas de fichiers résidus** (`*.blade copy.php`, `old_*`) committés.
- En cas de doute UI transverse (tokens, dropdown, modal, layout) → North Star mt-ui.

## 8. Interactions d'engagement (like / réactions / partage / newsletter)

Méthodes **partagées sur `GuestBaseComponent`** (dont héritent Home, ArticleShow,
CategoryShow → dispo partout où une card s'affiche, sans duplication) :
- `cardToggleLike($id)` — like d'un article depuis une card ; invité → `dispatch('open-auth-modal')`.
- `cardReact($id, $emoji)` — réaction emoji agrégée dans `meta_data.reactions` (pas d'auth).
- `cardRecordShare($id, $network)` — incrément **atomique** `shares_count` (`DB::raw`).
- `subscribeNewsletter(?$email)` — crée un `NewsletterSubscriber`.
> ArticleShow a EN PLUS `toggleLike()`/`react()` (article courant, sans `$id`) — **noms
> distincts** des `card*` exprès, pour éviter la collision d'héritage.
- UI : **optimiste côté Alpine** (compteur instantané), persistance serveur en arrière-plan.
- Like requiert l'auth ; réactions/partage non (compteurs d'engagement).
- Actions de card activables par config : `mtblog_option_card('like'|'reactions'|'comments'|'share')`.

## 9. Modales front + politique commentaires

- **Modales globales** (incluses dans le layout guest, enregistrées dans le SP) :
  `mtblog.quick-auth` (connexion rapide, ouvre sur `open-auth-modal`) et
  `mtblog.newsletter-modal` (ouvre sur `open-newsletter-modal`). Déclenchées par
  `Livewire.dispatch('…')` depuis n'importe quel bouton (header/footer/cards, hors composant).
  Ouverture **instantanée** via le listener Alpine `@…-modal.window="open=true"` (optimiste).
- **« Abonné » newsletter** : helper `mtblog_is_subscribed()` (connecté = email dans
  `newsletter_subscribers` actifs ; invité = cookie `mt_newsletter_subscribed`). Masque les
  CTA « S'abonner ».
- **Commentaires** : politique `config('mtblog.comments.auto_approve')` (`MTBLOG_COMMENTS_AUTO_APPROVE`)
  → `ArticleShow::postComment` crée en `approved` (post-modération) ou `pending` (pré-modération).
  `Comment::user()` = `belongsTo(User,'created_by')` (l'auteur est dans `created_by`, pas `user_id`).

## 10. Admin (back-office)

- **Pattern** : `XIndex extends GenericIndex` (définition : columns/rowActions/configuration) +
  `XIndexComponent extends BaseIndex` (composant, `indexClass()` + méthodes d'action). Idem
  formulaires : `XForm extends GenericForm` + `XFormComponent extends BaseForm`. **Tout composant
  admin DOIT être enregistré dans `MtBlogServiceProvider`** (sinon 419 sur les actions).
- **Formulaire schema-driven** (`GenericForm::schema()`) : types text/textarea/select/editor/
  toggle/datetime/image… Pour des champs **hors-colonne** (ex. tags = relation, « à retenir » =
  `meta_data`) : les ajouter au schéma comme champ simple, overrider `fillModel()` (hydratation
  édition), et dans `save()` les **exclure du cleanData** + traiter à part (`syncTags`, meta_data).
  Rappel : `$form->validate()` ne renvoie QUE les clés présentes dans `rules()`.
- **Index** : `rowActions($id)` doit être **null-safe** (le GenericIndex l'appelle avec `null`
  pour bâtir le gabarit) ; filtres `configuration['filters']` = STATIQUES `[col,op,val]`
  (pas de tabs dynamiques côté BaseIndex).
- Écrans en place : Articles, Catégories, Utilisateurs, **Commentaires (modération)**.
