<?php

/**____________________________________________________________________________________________
|                                                                                       |
|  Configuration du package MtBlog                                                      |
|  Ce fichier contient les paramètres de configuration pour le package de blogging.       |
|  Vous pouvez personnaliser les types de blocs, les middlewares, et d'autres options.   |
|_______________________________________________________________________________________|
*/

return [

    /*
    |--------------------------------------------------------------------------
    | Configuration de l'affichage des vues pour les articles (ex: vue article-show)
    |--------------------------------------------------------------------------
    */

    //vue home
    'home' => [
        'layout' => env('MTBLOG_HOME_LAYOUT', 'classic'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'hero' =>[
                'variant' => env('MTBLOG_HOME_HERO_VARIANT', 'split'), //classic | cinematic | split | stack  
            ],
            'pinned' =>[
                'variant' => env('MTBLOG_HOME_PINNED_VARIANT', 'cards'), //'numbered' | 'cards'  
            ],
            'breaking_news'   => env('MTBLOG_HOME_BREAKING_NEWS', false),
        ],

        // mini-sidebar des blocs « par catégories » (widgets configurables)
        'sidebar' => [
            'enabled' => env('MTBLOG_HOME_SIDEBAR', true),
            'sticky'  => env('MTBLOG_HOME_SIDEBAR_STICKY', true),
            'widgets' => [
                'stats'    => env('MTBLOG_SIDEBAR_STATS', true),     // chiffres clés du site
                'popular'  => env('MTBLOG_SIDEBAR_POPULAR', true),   // les plus lus
                'archives' => env('MTBLOG_SIDEBAR_ARCHIVES', true),  // archives par mois
                'tags'     => env('MTBLOG_SIDEBAR_TAGS', true),      // nuage de tags
                'social'   => env('MTBLOG_SIDEBAR_SOCIAL', true),    // réseaux sociaux
            ],
        ],
    ],

    //vue header
    'header' => [
        'layout' => env('MTBLOG_HEADER_LAYOUT', 'classic'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'topbar'   => env('MTBLOG_HEADER_TOPBAR', true),
            'breaking_news'   => env('MTBLOG_HEADER_BREAKING_NEWS', false),
            'home'   => env('MTBLOG_HEADER_HOME', true),
            'auth'   => env('MTBLOG_HEADER_AUTH', true),
            'suscribe'   => env('MTBLOG_HEADER_SUSCRIBE', false),
            'bookmarks'   => env('MTBLOG_HEADER_BOOKMARKS', false),
            'menu_icons'   => env('MTBLOG_HEADER_MENU_ICONS', false),
            'compact'   => env('MTBLOG_HEADER_COMPACT', false),
        ],
    ],

    //vue footer
    'footer' => [
        'layout' => env('MTBLOG_FOOTER_LAYOUT', 'classic'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'social'   => env('MTBLOG_FOOTER_SOCIAL', false),
            'newsletter'   => env('MTBLOG_FOOTER_NEWSLETTER', false),
            'apps'   => env('MTBLOG_FOOTER_APPS', false),
            'tagline'   => env('MTBLOG_FOOTER_TAGLINE', false),
        ],
    ],

    //vue category-show
    'category-show' => [
        'layout' => env('MTBLOG_CATEGORY_LAYOUT', 'immersive'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'childrens'    => env('MTBLOG_CATEGORY_SHOW_CHILDRENS', true),   // pills sous-rubriques
            'breadcrumb'   => env('MTBLOG_CATEGORY_SHOW_BREADCRUMB', true),
            'icon'         => env('MTBLOG_CATEGORY_SHOW_ICON', true),
            'meta'         => env('MTBLOG_CATEGORY_SHOW_META', true),         // stats (nb articles / sous-rubriques)
            'filter'       => env('MTBLOG_CATEGORY_SHOW_FILTER', true),       // barre recherche/tri/vue
            'featured'     => env('MTBLOG_CATEGORY_SHOW_FEATURED', true),     // article à la une
            'sidebar'      => env('MTBLOG_CATEGORY_SHOW_SIDEBAR', true),      // sidebar (plus lus…)
        ],
    ],

    //vue article-show — chaque module activable indépendamment
    'article-show' => [
        'layout' => env('MTBLOG_ARTICLE_LAYOUT', 'immersive'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'breadcrumb'    => env('MTBLOG_ARTICLE_SHOW_BREADCRUMB', true),
            'category'      => env('MTBLOG_ARTICLE_SHOW_CATEGORY', true),
            // barre méta (chaque item a son propre flag)
            'author'        => env('MTBLOG_ARTICLE_SHOW_AUTHOR', false),
            'date'          => env('MTBLOG_ARTICLE_SHOW_DATE', true),
            'reading_time'  => env('MTBLOG_ARTICLE_SHOW_READING_TIME', true),
            'views_count'   => env('MTBLOG_ARTICLE_SHOW_VIEWS_COUNT', true),
            // actions
            'likes'         => env('MTBLOG_ARTICLE_SHOW_LIKES', true),
            'bookmark'      => env('MTBLOG_ARTICLE_SHOW_BOOKMARK', true),
            'print'         => env('MTBLOG_ARTICLE_SHOW_PRINT', true),
            'share'         => env('MTBLOG_ARTICLE_SHOW_SHARE', true),
            // contenu annexe
            'toc'           => env('MTBLOG_ARTICLE_SHOW_TOC', true),
            'article_info'  => env('MTBLOG_ARTICLE_SHOW_INFO', true),
            'tags'          => env('MTBLOG_ARTICLE_SHOW_TAGS', true),
            'similar'       => env('MTBLOG_ARTICLE_SHOW_SIMILAR', true),
            'comments'      => env('MTBLOG_ARTICLE_SHOW_COMMENTS', true),
            'read_also'     => env('MTBLOG_ARTICLE_SHOW_READ_ALSO', true),
            // modules additionnels
            'takeaways'        => env('MTBLOG_ARTICLE_SHOW_TAKEAWAYS', true),       // encadré « à retenir »
            'reactions'        => env('MTBLOG_ARTICLE_SHOW_REACTIONS', true),       // barre d'emojis
            'author_box'       => env('MTBLOG_ARTICLE_SHOW_AUTHOR_BOX', true),      // encadré auteur
            'post_nav'         => env('MTBLOG_ARTICLE_SHOW_POST_NAV', true),        // précédent / suivant
            'newsletter'       => env('MTBLOG_ARTICLE_SHOW_NEWSLETTER', true),      // CTA newsletter in-article
            'share_float'      => env('MTBLOG_ARTICLE_SHOW_SHARE_FLOAT', true),     // rail de partage flottant
            'popular_category' => env('MTBLOG_ARTICLE_SHOW_POPULAR_CAT', true),     // « plus lus » de la rubrique (sidebar)
        ],
    ],
    
    /*
    |--------------------------------------------------------------------------
    | Configuration de l'affichage des options des composants (ex: composant post_card)
    |--------------------------------------------------------------------------
    */

    //composant post.hero
    'post-hero' => [
        'options' => [
            'sidebar'               => env('MTBLOG_HERO_SIDEBAR', true),
            'badge'                 => env('MTBLOG_HERO_BADGE', true),
            'breaking'              => env('MTBLOG_HERO_BREAKING', true),
            'excerpt'               => env('MTBLOG_HERO_EXCERPT', true),
            'meta'                  => env('MTBLOG_HERO_META', true),
            'meta_reading_time'     => env('MTBLOG_HERO_META_READING_TIME', true),
            'read_more'             => env('MTBLOG_HERO_READ_MORE', true),
        ],
    ],

    //composant post.card
    'post-card' => [
        'options' => [
            'image'     => env('MTBLOG_CARD_IMAGE', true),
            'category'  => env('MTBLOG_CARD_CATEGORY', false),
            'author'    => env('MTBLOG_CARD_AUTHOR', false),
            'date'      => env('MTBLOG_CARD_DATE', false),
            'views'     => env('MTBLOG_CARD_VIEWS', false),
            'excerpt'   => env('MTBLOG_CARD_EXCERPT', true),
            'read_more' => env('MTBLOG_CARD_READ_MORE', false),
            'actions'   => env('MTBLOG_CARD_ACTIONS', false),  // barre d'actions (maître)
            // actions granulaires (affichées si 'actions' est ON)
            'like'      => env('MTBLOG_CARD_LIKE', true),
            'reactions' => env('MTBLOG_CARD_REACTIONS', true),
            'comments'  => env('MTBLOG_CARD_COMMENTS', true),
            'share'     => env('MTBLOG_CARD_SHARE', true),
        ],
    ],

    // Réseaux sociaux (liens publics — pilotés par .env, consommés par footer + sidebar)
    'social' => [
        'facebook'  => env('MTBLOG_SOCIAL_FACEBOOK'),
        'twitter'   => env('MTBLOG_SOCIAL_TWITTER'),
        'instagram' => env('MTBLOG_SOCIAL_INSTAGRAM'),
        'youtube'   => env('MTBLOG_SOCIAL_YOUTUBE'),
        'linkedin'  => env('MTBLOG_SOCIAL_LINKEDIN'),
        'telegram'  => env('MTBLOG_SOCIAL_TELEGRAM'),
        'tiktok'    => env('MTBLOG_SOCIAL_TIKTOK'),
        'whatsapp'  => env('MTBLOG_SOCIAL_WHATSAPP'),
    ],


    /*
    |--------------------------------------------------------------------------
    | Types de blocs disponibles pour l'éditeur de contenu   
    |--------------------------------------------------------------------------
    */  
    'blocks' => [
        'paragraph' => 'mtblog::blocks.paragraph',
        'heading'   => 'mtblog::blocks.heading',
        'image'     => 'mtblog::blocks.image'
    ],

    // Commentaires
    'comments' => [
        // true  → les commentaires sont publiés immédiatement (post-modération via l'admin)
        // false → ils passent en « en attente » et n'apparaissent qu'après approbation (pré-modération)
        'auto_approve' => env('MTBLOG_COMMENTS_AUTO_APPROVE', true),
    ],

    // Middleware à appliquer aux routes du package (ex: auth, admin, etc.)
    'middleware' => ['web','auth'],

];
