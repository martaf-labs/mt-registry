Voici un texte de documentation prêt à mettre dans le README de ton package.

---

# Editor visuel (Block Editor) – Guide d’installation

Le package **mt/blog** fournit un éditeur moderne basé sur des blocs (type Medium / Notion / Gutenberg) utilisant **EditorJS + Alpine + TailwindCSS + FontAwesome** avec support du dark mode, de l’upload d’images et du rendu côté serveur.

Ce guide explique **toutes les étapes nécessaires** pour l’intégrer correctement dans un projet Laravel.

---

# 1. Publier les assets du package

Après installation du package :

```bash
php artisan vendor:publish --tag=mtblog-assets
```

Cela publie :

```
public/vendor/mtblog/editor.js
public/vendor/mtblog/editor.css
```

---

# 2. Créer le lien storage (obligatoire)

L’éditeur permet l’upload d’images.
Les fichiers doivent être accessibles publiquement.

Exécuter :

```bash
php artisan storage:link
```

Les images seront stockées dans :

```
storage/app/public/mtblog/YYYY/MM/
```

Et accessibles via :

```
/storage/mtblog/...
```

---

# 3. Charger les assets dans le layout admin

Dans ton layout Blade principal (ex: `layouts/admin.blade.php`) :

```blade
<head>
    @mtblogEditorAssets
</head>
```

Cette directive charge automatiquement :

* AlpineJS
* FontAwesome 7 Free
* EditorJS + plugins
* Styles Tailwind du package

Aucune compilation front n’est nécessaire.

---

# 4. Ajouter le token CSRF dans le layout

Dans la balise `<head>` du layout :

```blade
<meta name="csrf-token" content="{{ csrf_token() }}">
```

Indispensable pour l’upload d’images depuis l’éditeur.

---

# 5. Ajouter l’éditeur dans un formulaire

Dans ta vue Blade :

```blade
<x-mtblog::editor 
    name="content_blocks"
    :value="$article->content_blocks ?? []"
/>
```

Paramètres :

| Prop  | Description                    |
| ----- | ------------------------------ |
| name  | nom du champ envoyé au serveur |
| value | JSON des blocs existants       |

---

# 6. Sauvegarder le contenu dans le contrôleur

Dans ton controller :

```php
$article->content_blocks = json_decode($request->content_blocks, true);
$article->save();
```

Le champ `content_blocks` doit être de type JSON dans la base.

---

# 7. Cast recommandé dans le modèle

```php
protected $casts = [
    'content_blocks' => \Mt\Blog\Casts\ContentBlocksCast::class,
];
```

Cela permet de manipuler les blocs comme une Collection Laravel.

---

# 8. Sécurité des routes d’upload

Par défaut, les routes d’upload utilisent les middlewares :

```php
['web', 'auth']
```

Tu peux les modifier dans la config publiée :

```bash
php artisan vendor:publish --tag=mtblog-config
```

Puis modifier :

```php
'middleware' => ['web','auth'],
```

---

# 9. Fonctionnement de l’upload d’images

L’éditeur permet :

* Drag & drop d’image
* Upload depuis l’ordinateur
* Import via URL

Les images sont automatiquement :

* validées (type image)
* limitées à 5MB
* renommées avec UUID
* classées par date (année/mois)

Exemple de chemin :

```
storage/app/public/mtblog/2026/02/uuid.jpg
```

Le stockage utilise le disque Laravel `public`.
Le projet peut donc utiliser :

* stockage local
* Amazon S3
* Cloudflare R2
* DigitalOcean Spaces
* MinIO

Sans modification du package.

---

# 10. Dark mode automatique

L’éditeur est compatible Tailwind dark mode.

Le bouton lune dans la toolbar bascule :

```html
<html class="dark">
```

Si ton admin possède déjà un dark mode global, l’éditeur s’adapte automatiquement.

---

# 11. Responsive design

L’éditeur est entièrement responsive :

* desktop : largeur complète
* tablette : layout adaptatif
* mobile : toolbar compacte

Aucune configuration supplémentaire requise.

---

# 12. Rendu des blocs côté frontend

Dans les vues publiques :

```blade
{!! render_blocks($article->content_blocks) !!}
```

Le rendu est effectué via le moteur de blocs fourni par le package.

---

# 13. Ajouter des blocs personnalisés

Dans `AppServiceProvider` :

```php
use Mt\Blog\Support\BlockRegistry;

public function boot()
{
    app(BlockRegistry::class)->register(
        'cta',
        'blocks.cta'
    );
}
```

Le package est entièrement extensible.

---

# Résumé

Après installation :

1. Publier assets
2. Créer storage link
3. Charger `@mtblogEditorAssets`
4. Ajouter le composant `<x-mtblog::editor />`
5. Sauvegarder le JSON côté controller
6. Utiliser `render_blocks()` côté frontend

Ton projet dispose maintenant d’un éditeur de contenu moderne basé sur des blocs.
