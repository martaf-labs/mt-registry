<?php

namespace Mt\MtBlog\Traits;

use App\Models\Like;
use Illuminate\Database\Eloquent\Relations\MorphMany;

trait Likeable
{
    public function likes(): MorphMany
    {
        return $this->morphMany(Like::class, 'likeable');
    }

    public function likeBy(User $user): Like
    {
        return $this->likes()->firstOrCreate(['user_id' => $user->id]);
    }

    public function unlikeBy(User $user): bool
    {
        return $this->likes()->where('user_id', $user->id)->delete() > 0;
    }

    public function isLikedBy(User $user): bool
    {
        return $this->likes()->where('user_id', $user->id)->exists();
    }

    public function toggleLikeBy(User $user): ?Like
    {
        if ($this->isLikedBy($user)) {
            $this->unlikeBy($user);
            return null;
        }
        
        return $this->likeBy($user);
    }

    public function getLikesCountAttribute(): int
    {
        return $this->likes()->count();
    }

    protected static function bootLikeable()
    {
        static::deleting(function ($model) {
            $model->likes()->delete();
        });
    }
}