<?php

namespace Mt\Blog\Traits;

use App\Models\Comment;
use Illuminate\Database\Eloquent\Relations\MorphMany;

trait Commentable
{
    public function comments(): MorphMany
    {
        return $this->morphMany(Comment::class, 'commentable');
    }

    public function addComment(array $data, User $user): Comment
    {
        return $this->comments()->create(array_merge($data, [
            'user_id' => $user->id,
        ]));
    }

    public function getCommentsCountAttribute(): int
    {
        return $this->comments()->approved()->count();
    }

    protected static function bootCommentable()
    {
        static::deleting(function ($model) {
            $model->comments()->delete();
        });
    }
}