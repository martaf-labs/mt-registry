<?php

use Mt\Blog\Enums\StatusArticle;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\Category;
use Mt\Blog\Services\BlockRenderer;


/**
 * Recuperer un element de configuration de "mt-ui"
 */
if (!function_exists('mtblog_config')) {
    function mtblog_config(string $key) {
        if (is_null($key)) {
            return '';
        }
        return config("mtblog.$key");
    }
}

/**
 * Verifier l'autorisation d'affichage des options d'une vue ou d'un composant
 */
if (!function_exists('mtblog_option')) {
    function mtblog_option(string $viewName, string $optionName) {
        if(!$viewName || !$optionName){
            return false;
        }
        return mtblog_config($viewName.''.'.options.'.''.$optionName);
    }
}

/**
 * Verifier l'autorisation d'affichage des options de la vue home
 */
if (!function_exists('mtblog_option_home')) {
    function mtblog_option_home(string $optionName) {
        return mtblog_config('home.options.'.''.$optionName);

    }
}

/**
 * Verifier l'autorisation d'affichage des options de la vue header
 */
if (!function_exists('mtblog_option_header')) {
    function mtblog_option_header(string $optionName) {
        return mtblog_config('header.options.'.''.$optionName);

    }
}

/**
 * Verifier l'autorisation d'affichage des options de la vue footer
 */
if (!function_exists('mtblog_option_footer')) {
    function mtblog_option_footer(string $optionName) {
        return mtblog_config('footer.options.'.''.$optionName);

    }
}

/**
 * Verifier l'autorisation d'affichage des options de la vue show-category
 */
if (!function_exists('mtblog_option_category_show')) {
    function mtblog_option_category_show(string $optionName) {


        return mtblog_config('category-show.options.'.''.$optionName);

    }
}

/**
 * Verifier l'autorisation d'affichage des options de la vue show-article
 */
if (!function_exists('mtblog_option_article_show')) {
    function mtblog_option_article_show(string $optionName) {


        return mtblog_config('article-show.options.'.''.$optionName);

    }
}

/**
 * Verifier l'autorisation d'affichage des options du composant post.card
 */
if (!function_exists('mtblog_option_card')) {
    function mtblog_option_card(string $optionName) {

        return mtblog_option('post-card',$optionName);

    }
}

/**
 * Verifier l'autorisation d'affichage des options du composant post.hero
 */
if (!function_exists('mtblog_option_hero')) {
    function mtblog_option_hero(string $optionName) {

        return mtblog_option('post-hero',$optionName);

    }
}


if (! function_exists('render_blocks')) {
    /**
     * Fonction d'aide pour rendre les blocs de contenu d'un article
     * @param array|null $blocks
     * @return string
     */
    function render_blocks($blocks)
    {
        return app(BlockRenderer::class)->render($blocks ?? []);
    }
}

// helpers routes
if (! function_exists('mtblog_is_home')) {
    function mtblog_is_home()
    {
        return request()->routeIs('home');
    }
}

// NB : mt_get_route() est fourni par mt-ui (src/Helpers/helpers.php). Il résout
// une clé LOGIQUE (ex. 'home_articles_show') via le mapping config/routes.php de
// l'hôte → nom de route réel. Ne pas le redéfinir ici (le thin host possède ses routes).

/**
 * L'utilisateur courant est-il déjà abonné à la newsletter ?
 * - connecté : son email figure dans les abonnés actifs ;
 * - invité   : un cookie a été posé lors de son inscription.
 * Sert à masquer le bouton « S'abonner » (header) et le CTA newsletter (footer).
 */
if (! function_exists('mtblog_is_subscribed')) {
    function mtblog_is_subscribed(): bool
    {
        if (request()->cookie('mt_newsletter_subscribed')) {
            return true;
        }

        if (auth()->check()) {
            $email = auth()->user()->email ?? null;

            return $email && \Mt\Blog\Models\NewsletterSubscriber::query()
                ->where('email', $email)
                ->where('is_active', true)
                ->exists();
        }

        return false;
    }
}
