<?php

namespace Mt\Blog\Casts;

use Illuminate\Contracts\Database\Eloquent\CastsAttributes;

class ContentBlocksCast implements CastsAttributes
{
    public function get($model, $key, $value, $attributes)
    {
        return collect(json_decode($value, true) ?? []);
    }

    public function set($model, $key, $value, $attributes)
    {
        return json_encode($value);
    }
}
