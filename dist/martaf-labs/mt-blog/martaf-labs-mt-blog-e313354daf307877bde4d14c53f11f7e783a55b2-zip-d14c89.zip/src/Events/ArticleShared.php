<?php

namespace Mt\Blog\Events;

use Mt\Blog\Models\Article;

class ArticleShared
{
    public function __construct(
        public readonly Article $article,
        public readonly string $network  // 'facebook' | 'twitter' | 'whatsapp' …
    ) {}
}
