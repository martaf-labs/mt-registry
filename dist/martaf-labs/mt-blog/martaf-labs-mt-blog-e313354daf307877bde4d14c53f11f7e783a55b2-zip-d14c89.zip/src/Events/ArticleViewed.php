<?php

namespace Mt\Blog\Events;

use Mt\Blog\Models\Article;

class ArticleViewed
{
    public function __construct(
        public readonly Article $article,
        public readonly bool $isUnique,
        public readonly array $context = []  // ip, user_agent, referrer, device
    ) {}
}
