<?php

namespace Mt\Blog\Events;

use Mt\Blog\Models\Article;

class ArticleLiked
{
    public function __construct(
        public readonly Article $article,
        public readonly string $action  // 'add' | 'remove'
    ) {}
}
