<?php

namespace Mt\Blog\Enums;

enum TypeSponsorship: string
{
    case SPONSORED  = 'sponsored';
    case FEATURED   = 'featured';
    case HOMEPAGE   = 'homepage';
    case STICKY     = 'sticky';

    public function label(): string
    {
        return match ($this) {
            self::SPONSORED   => 'Sponsorisé',
            self::FEATURED    => 'En vedette',
            self::HOMEPAGE    => 'Page d\'Accueil',
            self::STICKY      => 'Collant',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
