<?php

namespace Mt\Blog\Enums;

enum VisibilityArticle: string
{
    case PUBLIC            = 'public';
    case PRIVATE          = 'private';
    case PEMIUM        = 'premium';

    public function label(): string
    {
        return match ($this) {
            self::PUBLIC           => 'Brouillon',
            self::PRIVATE         => 'Suspendu',
            self::PEMIUM       => 'Publié'
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
