<?php

namespace Mt\Blog\Enums;

enum StatusArticle: string
{
    case DRAFT            = 'draft';
    case PENDING          = 'pending';
    case PUBLISHED        = 'published';
    case SCHEDULED        = 'scheduled';
    case ARCHIVED         = 'archived';

    public function label(): string
    {
        return match ($this) {
            self::DRAFT           => 'Brouillon',
            self::PENDING         => 'Suspendu',
            self::PUBLISHED       => 'Publié',
            self::SCHEDULED       => 'Programmé',
            self::ARCHIVED        => 'Archivé',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }

    public function badge(): array
    {
        return match ($this) {
            self::DRAFT        => ['type' => 'dark', 'label' => $this->label()],
            self::PENDING      => ['type' => 'danger', 'label' => $this->label()],
            self::PUBLISHED    => ['type' => 'success', 'label' => $this->label()],
            self::SCHEDULED    => ['type' => 'info', 'label' => $this->label()],
            self::ARCHIVED     => ['type' => 'secondary', 'label' => $this->label()],
        };
    }
}
