<?php
// app/Models/Tag.php

namespace Mt\Blog\Models;

use Mt\MtFoundation\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Tag extends MtBaseModel
{
    protected $fillable = [
        'name',
        'slug',
        'usage_count',
    ];

    // Relations
    public function articles(): BelongsToMany
    {
        return $this->belongsToMany(Article::class)
                    ->withTimestamps();
    }

    // Scopes
    public function scopePopular($query, $limit = 10)
    {
        return $query->orderBy('usage_count', 'desc')->limit($limit);
    }

    // Méthodes
    public function incrementUsage(): void
    {
        $this->increment('usage_count');
    }

    public function decrementUsage(): void
    {
        $this->decrement('usage_count');
    }

    public function syncUsage(): void
    {
        $this->usage_count = $this->articles()->count();
        $this->saveQuietly();
    }

    // Accesseurs
    public function getUrlAttribute(): string
    {
        // L'hôte peut ne pas définir de page tag dédiée → dégradation propre
        // vers la recherche (sinon RouteNotFoundException dès qu'un tag est rendu).
        return \Illuminate\Support\Facades\Route::has('tags.show')
            ? route('tags.show', $this->slug)
            : url('/?q=' . urlencode($this->name));
    }
}