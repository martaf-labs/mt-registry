<?php

namespace Mt\Blog\Models;

use Mt\MtFoundation\Models\BaseVideo;

class Video extends BaseVideo
{

}