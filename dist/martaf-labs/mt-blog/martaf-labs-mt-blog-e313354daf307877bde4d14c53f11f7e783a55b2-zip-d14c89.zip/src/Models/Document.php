<?php

namespace Mt\Blog\Models;

use Mt\MtFoundation\Models\BaseDocument;

class Document extends BaseDocument
{

}