<?php

namespace Mt\Blog\Models;

use Mt\MtFoundation\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Like extends MtBaseModel
{

    protected $fillable = [
        'likeable_id',
        'likeable_type',
    ];

    // Relations
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function likeable(): MorphTo
    {
        return $this->morphTo();
    }

    // Scopes
    public function scopeForArticle($query, Article $article)
    {
        return $query->where('likeable_type', Article::class)
                     ->where('likeable_id', $article->id);
    }

    public function scopeForComment($query, Comment $comment)
    {
        return $query->where('likeable_type', Comment::class)
                     ->where('likeable_id', $comment->id);
    }

    public function scopeByUser($query, User $user)
    {
        return $query->where('user_id', $user->id);
    }
}