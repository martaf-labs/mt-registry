<?php

namespace Mt\Blog\Models;

use Carbon\Carbon;
use Illuminate\Support\Collection;
use Mt\MtFoundation\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ArticleStat extends MtBaseModel
{
    protected $table = 'article_stats';

    protected $fillable = [
        'article_id', 'date',
        'views', 'unique_views',
        'likes', 'comments', 'shares',
        'avg_time_on_page', 'bounce_rate',
        'referrers', 'devices', 'locations',
    ];

    protected $casts = [
        'date'             => 'date',
        'referrers'        => 'array',
        'devices'          => 'array',
        'locations'        => 'array',
        'avg_time_on_page' => 'float',
        'bounce_rate'      => 'float',
    ];

    // ── Relations ──────────────────────────────────────────

    public function article(): BelongsTo
    {
        return $this->belongsTo(Article::class);
    }

    // ── Scopes ─────────────────────────────────────────────

    public function scopeForPeriod($query, $startDate, $endDate)
    {
        return $query->whereBetween('date', [$startDate, $endDate]);
    }

    public function scopeLastDays($query, int $days)
    {
        return $query->where('date', '>=', now()->subDays($days)->toDateString());
    }

    public function scopeToday($query)
    {
        return $query->where('date', now()->toDateString());
    }

    public function scopeThisWeek($query)
    {
        return $query->forPeriod(
            now()->startOfWeek()->toDateString(),
            now()->toDateString()
        );
    }

    public function scopeThisMonth($query)
    {
        return $query->forPeriod(
            now()->startOfMonth()->toDateString(),
            now()->toDateString()
        );
    }

    // ── Accesseurs ─────────────────────────────────────────

    public function getTotalViewsAttribute(): int
    {
        return $this->views + $this->unique_views;
    }

    public function getEngagementRateAttribute(): float
    {
        if ($this->views === 0) return 0.0;

        $interactions = $this->likes + $this->comments + $this->shares;
        return round(($interactions / $this->views) * 100, 2);
    }

    public function getTopReferrerAttribute(): ?string
    {
        if (empty($this->referrers)) return null;

        return collect($this->referrers)
            ->sortDesc()
            ->keys()
            ->first();
    }

    public function getTopDeviceAttribute(): ?string
    {
        if (empty($this->devices)) return null;

        return collect($this->devices)
            ->sortDesc()
            ->keys()
            ->first();
    }

    // ── Méthodes statiques (agrégation multi-jours) ────────

    /**
     * Agrège les stats d'un article sur une période.
     * Retourne un tableau prêt pour un graphique.
     *
     * ArticleStat::summaryFor($article, 30)
     */
    public static function summaryFor(Article $article, int $days = 30): array
    {
        $rows = static::where('article_id', $article->id)
            ->lastDays($days)
            ->orderBy('date')
            ->get();

        return [
            'total_views'      => $rows->sum('views'),
            'total_unique'     => $rows->sum('unique_views'),
            'total_likes'      => $rows->sum('likes'),
            'total_comments'   => $rows->sum('comments'),
            'total_shares'     => $rows->sum('shares'),
            'avg_time'         => round($rows->avg('avg_time_on_page'), 1),
            'avg_bounce'       => round($rows->avg('bounce_rate'), 1),
            'engagement_rate'  => self::calcEngagement($rows),
            'daily'            => $rows->map(fn($r) => [
                'date'    => $r->date->format('d/m'),
                'views'   => $r->views,
                'likes'   => $r->likes,
                'shares'  => $r->shares,
            ])->values()->all(),
            'top_referrers'    => self::mergeJsonCounts($rows, 'referrers'),
            'top_devices'      => self::mergeJsonCounts($rows, 'devices'),
        ];
    }

    private static function calcEngagement(Collection $rows): float
    {
        $views = $rows->sum('views');
        if ($views === 0) return 0.0;

        $interactions = $rows->sum('likes')
            + $rows->sum('comments')
            + $rows->sum('shares');

        return round(($interactions / $views) * 100, 2);
    }

    /**
     * Fusionne et somme les colonnes JSON (referrers, devices…)
     * sur plusieurs lignes. Retourne le top 5 trié.
     */
    private static function mergeJsonCounts(Collection $rows, string $column): array
    {
        return $rows
            ->pluck($column)
            ->filter()
            ->flatMap(fn($arr) => $arr)
            ->groupBy(fn($val, $key) => $key)  // clé = source/device
            ->map(fn($group) => $group->sum())
            ->sortDesc()
            ->take(5)
            ->all();
    }
}