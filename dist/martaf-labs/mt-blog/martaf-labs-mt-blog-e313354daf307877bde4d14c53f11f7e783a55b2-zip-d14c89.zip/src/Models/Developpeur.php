<?php

namespace Mt\Blog\Models;

use Mt\MtAuth\Models\BaseDeveloppeur;

class Developpeur extends BaseDeveloppeur
{

}