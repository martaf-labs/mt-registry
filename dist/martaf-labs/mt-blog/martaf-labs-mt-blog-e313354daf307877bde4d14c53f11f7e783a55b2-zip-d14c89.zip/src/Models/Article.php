<?php

namespace Mt\Blog\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\Blog\Casts\ContentBlocksCast;
use Mt\Blog\Enums\StatusArticle;
use Mt\Blog\Enums\VisibilityArticle;
use Mt\Blog\Models\ArticleRevision;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtUi\Contracts\Searchable;
use Mt\MtMedia\Traits\HasMedia;

class Article extends MtBaseModel implements Searchable
{
    use HasMedia;

    protected $table = 'articles';

    protected $fillable = [
        'title',
        'slug',
        'excerpt',
        'content',
        'content_original',
        'content_blocks',
        // 'featured_image',
        // 'featured_image_legend',
        // 'gallery_images',
        // 'video_url',
        // 'audio_url',
        'category_id',
        'article_type_id',
        'views_count',
        'unique_views_count',
        'reading_time',
        'word_count',
        'likes_count',
        'comments_count',
        'shares_count',
        'bookmarks_count',
        'status',
        'visibility',
        'published_at',
        'scheduled_for',
        'featured_until',
        'meta_data',
        'canonical_url',
        'allow_comments',
        'is_featured',
        'is_breaking_news',
        'is_pinned',
        'version',
    ];

    protected $casts = [
        'content_blocks' => ContentBlocksCast::class,
        'gallery_images' => 'array',
        'views_count' => 'integer',
        'unique_views_count' => 'integer',
        'reading_time' => 'integer',
        'word_count' => 'integer',
        'likes_count' => 'integer',
        'comments_count' => 'integer',
        'shares_count' => 'integer',
        'bookmarks_count' => 'integer',
        'status' => StatusArticle::class,
        'meta_data' => 'array',
        'allow_comments' => 'boolean',
        'is_featured' => 'boolean',
        'is_breaking_news' => 'boolean',
        'is_pinned' => 'boolean',
        'published_at' => 'datetime',
        'visibility' => VisibilityArticle::class,
        'scheduled_for' => 'datetime',
        'featured_until' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    

    // Events
    protected static function booted()
    {
        static::creating(function ($model) {
            $model->slug = $model->slug ?? Str::slug($model->title);
            $model->content_original = $model->content;
            $model->word_count = str_word_count(strip_tags($model->content));
            $model->reading_time = ceil($model->word_count / 200);
        });

        static::updating(function ($model) {
            if ($model->isDirty('content')) {
                $model->word_count = str_word_count(strip_tags($model->content));
                $model->reading_time = ceil($model->word_count / 200);
            }
        });

        static::saving(function ($model) {
            if ($model->isDirty('status')) {
                switch ($model->status) {
                    case StatusArticle::DRAFT->value:
                        $model->published_at = null;
                        break;
                    
                    default:
                        break;
                }
            } 

            $model->excerpt = trim($model->excerpt);
            $model->status = $model->status ?? StatusArticle::DRAFT->value;           
            $model->visibility = $model->visibility ?? VisibilityArticle::PUBLIC->value;           
            $model->article_type_id = $model->article_type_id ?? 1;
            $model->allow_comments = $model->allow_comments ?? true;
            $model->is_featured = $model->is_featured ?? true;
            $model->is_breaking_news = $model->is_breaking_news ?? true;
            $model->is_pinned = $model->is_pinned ?? true;
        });
        
        static::created(function ($model) {
            if ($model->is_featured) {
                static::where('id', '!=', $model->id)
                ->where('is_featured', true)
                ->update(['is_featured' => false,'featured_until' => null,]);
            }
        });
    }

    // Relations
    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(ArticleType::class, 'article_type_id');
    }

    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class)->withTimestamps();
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class);
    }

    public function approvedComments(): HasMany
    {
        return $this->hasMany(Comment::class)->approved();
    }

    public function likes(): MorphMany
    {
        return $this->morphMany(Like::class, 'likeable');
    }

    public function bookmarks(): HasMany
    {
        return $this->hasMany(Bookmark::class);
    }

    public function stats(): HasMany
    {
        return $this->hasMany(ArticleStat::class);
    }

    public function revisions(): HasMany
    {
        return $this->hasMany(ArticleRevision::class);
    }

    public function contributors(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'contributors')
                    ->withPivot('role', 'order')
                    ->withTimestamps();
    }

    public function sponsorships(): HasMany
    {
        return $this->hasMany(Sponsorship::class);
    }

    public function partners()
    {
        return $this->belongsToMany(
            Partner::class, 'sponsorships'
        )->withPivot([
            'type',
            'start_date',
            'end_date',
            'price'
        ])->withTimestamps();
    }

    // Scopes
    public function scopePublished($query)
    {
        return $query->where('status', StatusArticle::PUBLISHED->value)
                     ->where('published_at', '<=', now());
    }

    public function scopeDraft($query)
    {
        return $query->where('status', 'draft');
    }

    public function scopeScheduled($query)
    {
        return $query->where('status', 'scheduled')
                     ->where('scheduled_for', '>', now());
    }

    public function scopeFeatured($query)
    {
        return $query->published()->where('is_featured', true)
                     ->where(function($q) {
                         $q->whereNull('featured_until')
                           ->orWhere('featured_until', '>', now());
                     });
    }

    public function scopeBreakingNews($query)
    {
        return $query->published()->where('is_breaking_news', true);
    }

    public function scopePinned($query)
    {
        return $query->published()->where('is_pinned', true);
    }

    public function scopePublic($query)
    {
        return $query->published()->where('visibility', 'public');
    }

    public function scopePremium($query)
    {
        return $query->published()->where('visibility', 'premium');
    }

    public function scopeFromCategory($query, $categoryId)
    {
        return $query->published()->where('category_id', $categoryId);
    }

    public function scopeFromAuthor($query, $authorId)
    {
        return $query->published()->where('created_by', $authorId);
    }

    public function scopePopular($query, $days = 7)
    {
        return $query->published()->where('published_at', '>=', now()->subDays($days))
                     ->orderBy('views_count', 'desc');
    }

    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        return $query->published()->whereFullText(['title', 'content'], $term);
    }

    // Accesseurs
    public function getAuthorNameAttribute()
    {
        return $this->author?->name;
    }
    public function getAuthorRoleAttribute()
    {
        return $this->author?->role;
    }
    public function getCategoryNameAttribute()
    {
        return $this->category?->name;
    }
    public function getExcerptAttribute($value)
    {
        // Source : l'extrait saisi, sinon dérivé du contenu. Dans les deux cas on
        // décode les entités HTML (&eacute;, &nbsp;, &rarr;…) et on retire les
        // balises résiduelles — sinon elles s'affichent en clair dans les cards.
        $text = $value ?? Str::limit(strip_tags((string) $this->content), 200);

        return trim(html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5));
    }

    public function getReadingTimeAttribute($value)
    {
        $time = add_zero(ceil(str_word_count(strip_tags($this->content)) / 200));
        return "$time min";
    }

    /**
     * Temps de lecture estimé, en méthode (certaines vues l'appellent ainsi).
     * $withSuffix : avec ou sans le suffixe « min ». Cohérent avec l'accesseur reading_time.
     */
    public function readingTime(bool $withSuffix = true): string
    {
        $minutes = max(1, (int) ceil(str_word_count(strip_tags((string) $this->content)) / 200));
        $label   = add_zero($minutes);

        return $withSuffix ? "$label min" : (string) $label;
    }

    public function getUrlAttribute(): string
    {
        return route('articles.show', [$this->id, $this->slug]);
    }

    // public function getHasFeaturedImageAttribute(): string
    // {
    //     return $this->featured_image != null  && Storage::disk(mt_get_storage_disk())->exists($this->featured_image);
    // }

    // public function getImageUrlAttribute(): ?string
    // {
        
    //     return $this->featured_image  
    //         ? Storage::disk(mt_get_storage_disk())->url($this->featured_image)
    //         : null;
    // }

    public function getIsContentBlocksAttribute(): bool
    {
        return $this->content === null && $this->content_blocks !== null;
    }

    public function getIsPremiumAttribute(): bool
    {
        return $this->visibility === VisibilityArticle::PEMIUM;
    }

    public function getIsPublicAttribute(): bool
    {
        return $this->visibility === VisibilityArticle::PUBLIC;
    }

    public function getIsPublishedAttribute(): bool
    {
        return $this->status === StatusArticle::PUBLISHED 
            && $this->published_at 
            && $this->published_at <= now();
    }

    public function getPublishedThereAttribute()
    {
        if(is_null($this->published_at)){
            return;
        }

        $dateFormater = null;
        // si la date de publication est dans les 24h, on affiche "il y a X heures/minutes", sinon on affiche la date de publication au format "d M Y"
        if (Carbon::parse($this->published_at)->greaterThanOrEqualTo(now()->subDay())) {
            $dateFormater = tempsEcoule($this->published_at, null, true, true);
        } else {
            $dateFormater = Carbon::parse($this->published_at)->translatedFormat('d M Y');
        }
        
        return $dateFormater;
    }

    public function getPublishedDateAttribute()
    {
        $date=!is_null($this->published_at)? Carbon::parse($this->published_at)->translatedFormat('d M Y') : null;
        return $date;
    }

    public function getHasBeenUpdatedAttribute()
    {
        return !is_null($this->updated_at);
    }

    public function getUpdatedThereAttribute()
    {
        
        if(is_null($this->updated_at)){
            return;
        }

        $dateFormater = null;
        // si la date de publication est dans les 24h, on affiche "il y a X heures/minutes", sinon on affiche la date de publication au format "d M Y"
        if (Carbon::parse($this->updated_at)->greaterThanOrEqualTo(now()->subDay())) {
            $dateFormater = tempsEcoule($this->updated_at, null, true, true);
        } else {
            $dateFormater = Carbon::parse($this->updated_at)->translatedFormat('d M Y');
        }
        
        return $dateFormater;
    }

    public function getUpdatedDateAttribute()
    {
        $date=!is_null($this->updated_at)? Carbon::parse($this->updated_at)->translatedFormat('d M Y') : null;
        return $date;
    }

    public function viewsCount($withLabel = false)
    {
        $label = $withLabel? ($this->views_count > 1 ? ' vues' : ' vue') : '';
        $value = add_zero($this->views_count);
        return $value.''.$label;
    }

    // Méthodes
    public function publish(): void
    {
        $this->status = StatusArticle::PUBLISHED->value;
        $this->published_at = now();
        $this->scheduled_for = null;
        $this->save();
    }

    public function unpublish(): void
    {
        $this->status = StatusArticle::DRAFT->value;
        $this->published_at = null;
        $this->save();
    }

    public function toggleFeatured(): void
    {
        $isFeatured = $this->is_featured ? false : true;
        $this->is_featured = $isFeatured;

        if(!$isFeatured){
            $this->featured_until = now()->addMonth();

            // on gere les autre article
            static::featured()
            ->update(['is_featured' => false,'featured_until' => null,]);
        }

        $this->save();

    }

    public function togglePinned(): void
    {
        $isPinned = $this->is_pinned ? false : true;
        $this->is_pinned = $isPinned;
        $this->save();
    }

    public function toggleBreakingNews(): void
    {
        $isBreaking = $this->is_breaking_news ? false : true;
        $this->is_breaking_news = $isBreaking;
        $this->save();
    }

    public function incrementViews($isUnique = false): void
    {
        $this->increment('views_count');
        
        if ($isUnique) {
            $this->increment('unique_views_count');
        }
        
        // Enregistrer dans les stats quotidiennes
        $this->stats()->updateOrCreate(
            ['date' => now()->toDateString()],
            ['views' => \DB::raw('views + 1')]
        );
    }

    public function syncTags(array $tagNames): void
    {
        $tagIds = [];
        
        foreach ($tagNames as $tagName) {
            $tag = Tag::firstOrCreate(
                ['slug' => Str::slug($tagName)],
                ['name' => $tagName]
            );
            $tagIds[] = $tag->id;
        }
        
        $this->tags()->sync($tagIds);
    }

    public function createRevision(User $user, string $summary = null): ArticleRevision
    {
        return $this->revisions()->create([
            'created_by' => $user->id,
            'title' => $this->title,
            'excerpt' => $this->excerpt,
            'content' => $this->content,
            'version' => $this->version + 1,
            'summary' => $summary,
        ]);
    }

    // Relation singulier pour updateOrCreate dans syncRelations
    public function sponsorship()
    {
        return $this->hasOne(Sponsorship::class)->latestOfMany();
    }

    //helper
    public function activeSponsorship(){
        return $this->sponsorships()
            ->where('is_active', true)
            ->where(function ($query){
                $query->whereNull('start_date')
                    ->OrWhere('start_date', '<=', now());
            })
            ->where(function ($query){
                $query->whereNull('end_date')
                    ->OrWhere('end_date', '>=', now());
            });
    }
    public function isSponsored() : bool
    {
        return $this->type()?->is_sponsored ?? false;
        
    }

    // like
    public function toggleLike(): void
    {
        $like = $this->likes()->where('created_by', auth()->id())->first();

        if ($like) {
            $like->delete();
            $this->decrement('likes_count');
        } else {
            $this->likes()->create(['created_by' => auth()->id()]);
            $this->increment('likes_count');
        }
    }

    // Dans le modèle Article
    public function isLikedByUser(): bool
    {
        return $this->likes()->where('created_by', auth()->id())->exists();
    }


    //search
    public static function searchCategory(): string
    {
        return 'Articles';
    }

    public static function searchIcon(): string
    {
        return getIcone('article');
    }

    public static function searchColor(): string
    {
        return 'blue'; // blue | green | purple | orange | red | teal | pink | gray
    }

    public static function searchableColumns(): array
    {
        return ['title', 'excerpt', 'content', 'content_blocks'];
    }

    public function toSearchResult(): array
    {
        return [
            'id'          => $this->id,
            'title'       => $this->title,
            'subtitle'    => $this->excerpt,
            'meta'        => $this->publishedThere,
            'url'         => mt_get_route('home_articles_show', ['id' => $this->id, 'slug' => $this->slug]),
            'avatar'      => $this->imageUrl ?? null,
            'avatar_text' => strtoupper(substr($this->title, 0, 2)),
        ];
    }
}