<?php

namespace Mt\Blog\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Contributor extends Pivot
{
    protected $table = 'contributors';

    protected $fillable = [
        'article_id',
        'role',
        'order',
    ];

    protected $casts = [
        'order' => 'integer',
    ];

    // Relations
    public function article(): BelongsTo
    {
        return $this->belongsTo(Article::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // Scopes
    public function scopeAuthors($query)
    {
        return $query->where('role', 'author');
    }

    public function scopeEditors($query)
    {
        return $query->where('role', 'editor');
    }

    public function scopePhotographers($query)
    {
        return $query->where('role', 'photographer');
    }

    // Accesseurs
    public function getRoleLabelAttribute(): string
    {
        return [
            'author' => 'Auteur',
            'coauthor' => 'Co-auteur',
            'editor' => 'Éditeur',
            'photographer' => 'Photographe',
            'illustrator' => 'Illustrateur',
        ][$this->role] ?? $this->role;
    }
}