<?php

namespace Mt\Blog\Models;

use Mt\MtFoundation\Models\MtBaseModel;

class Advertisement extends MtBaseModel
{

    protected $fillable = [
        'name',
        'type',
        'position',
        'code',
        'image_url',
        'link_url',
        'targeting_rules',
        'impressions_limit',
        'clicks_limit',
        'impressions_count',
        'clicks_count',
        'start_date',
        'end_date',
        'is_active',
        'priority',
    ];

    protected $casts = [
        'targeting_rules' => 'array',
        'start_date' => 'datetime',
        'end_date' => 'datetime',
        'is_active' => 'boolean',
        'priority' => 'integer',
    ];

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true)
                     ->where('start_date', '<=', now())
                     ->where(function($q) {
                         $q->whereNull('end_date')
                           ->orWhere('end_date', '>', now());
                     });
    }

    public function scopeForPosition($query, $position)
    {
        return $query->where('position', $position);
    }

    public function scopeNotExpired($query)
    {
        return $query->where(function($q) {
            $q->whereNull('impressions_limit')
              ->orWhereRaw('impressions_count < impressions_limit');
        })->where(function($q) {
            $q->whereNull('clicks_limit')
              ->orWhereRaw('clicks_count < clicks_limit');
        });
    }

    // Méthodes
    public function recordImpression(): void
    {
        $this->increment('impressions_count');
    }

    public function recordClick(): void
    {
        $this->increment('clicks_count');
    }

    public function hasReachedLimits(): bool
    {
        if ($this->impressions_limit && $this->impressions_count >= $this->impressions_limit) {
            return true;
        }
        
        if ($this->clicks_limit && $this->clicks_count >= $this->clicks_limit) {
            return true;
        }
        
        return false;
    }

    public function getClickThroughRateAttribute(): float
    {
        if ($this->impressions_count === 0) {
            return 0;
        }
        
        return round(($this->clicks_count / $this->impressions_count) * 100, 2);
    }
}