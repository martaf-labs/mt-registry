<?php

namespace Mt\Blog\Models;

use Illuminate\Support\Str;
use Mt\MtFoundation\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Partner extends MtBaseModel
{

    protected $fillable = [
        'name',
        'slug',
        'logo',
        'icon',
        'color',
        'website',
        'email',
        'description',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    /**
     * action du booted
     */
    protected static function booted()
    {
        static::creating(function($model){
            $model->slug = Str::slug($model->name);
        });
    }

    // Relations
    public function sponsorships(): HasMany
    {
        return $this->hasMany(Sponsorship::class);
    }

    public function articles()
    {
        return $this->belongsToMany(
            Article::class, 'sponsorships'
        )->withPivot([
            'type',
            'start_date',
            'end_date',
            'price'
        ])->whitTimestamp();
    }
}
