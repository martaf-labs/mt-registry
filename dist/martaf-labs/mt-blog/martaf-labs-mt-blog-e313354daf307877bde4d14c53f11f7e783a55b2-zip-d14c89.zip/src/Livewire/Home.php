<?php

namespace Mt\Blog\Livewire;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Mt\Blog\Livewire\GuestBaseComponent;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\Category;

#[Title('Accueil')]
class Home extends GuestBaseComponent
{
    /**
     * Layout de mise en page.
     * Valeurs : 'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
     * Configuré via config('mtblog.home_layout', 'classic')
     * ou forcé via ?layout=editorial pour les previews dev.
     */
    // #[Url(as: 'layout', except: 'classic')]
    public string $layout = 'classic';

    // ── Mount ───────────────────────────────────────────────────
    public function mount(): void
    {
        $this->layout = mtblog_config('home.layout');
    }

    // ── Computed ────────────────────────────────────────────────

    /**
     * Article à la une : d'abord featured, sinon le plus récent.
     */
    #[Computed]
    public function featured_article(): ?Article
    {
        return Article::published()
            ->with(['category.parent', 'author'])
            ->featured()
            ->latest('published_at')
            ->first()
            ?? Article::published()
                ->with(['category.parent', 'author'])
                ->latest('published_at')
                ->first();
    }

    /**
     * Derniers articles publiés (hors article à la une).
     */
    #[Computed]
    public function last_articles()
    {
        $excludeIds = array_filter([$this->featured_article?->id]);

        return Article::published()
            ->with(['category'])
            ->whereNotIn('id', $excludeIds)
            ->latest('published_at')
            ->take(6)
            ->get();
    }

    /**
     * Breaking news (flash).
     */
    #[Computed]
    public function breaking_news()
    {
        return Article::breakingNews()
            ->with(['category'])
            ->latest('published_at')
            ->take(5)
            ->get();
    }

    /**
     * Articles épinglés (ou fallback sur articles récents non encore affichés).
     */
    #[Computed]
    public function pinned_articles()
    {
        $pinned = Article::pinned()
            ->with(['category'])
            ->latest('published_at')
            ->take(3)
            ->get();

        if ($pinned->isEmpty()) {
            $usedIds = array_filter([
                $this->featured_article?->id,
                ...$this->last_articles->pluck('id')->all(),
            ]);

            $pinned = Article::published()
                ->with(['category'])
                ->whereNotIn('id', $usedIds)
                ->inRandomOrder()
                ->take(3)
                ->get();
        }

        return $pinned;
    }

    /**
     * Articles "Choix de la rédaction" — pool varié, sans doublons.
     */
    #[Computed]
    public function random_articles()
    {
        $usedIds = array_filter([
            $this->featured_article?->id,
            ...$this->last_articles->pluck('id')->all(),
            ...$this->pinned_articles->pluck('id')->all(),
        ]);

        return Article::published()
            ->with(['category'])
            ->whereNotIn('id', $usedIds)
            ->inRandomOrder()
            ->take(24)
            ->get();
    }

    /**
     * Articles populaires (les plus vus, 7 derniers jours).
     * Utilisé dans certains layouts pour une section "Tendances".
     */
    #[Computed]
    public function popular_articles()
    {
        $usedIds = array_filter([
            $this->featured_article?->id,
            ...$this->last_articles->pluck('id')->all(),
        ]);

        return Article::published()
            ->with(['category'])
            ->whereNotIn('id', $usedIds)
            ->popular(7)
            ->take(6)
            ->get();
    }

    /**
     * Articles par catégorie mise en avant.
     * Retourne un tableau ['category' => Category, 'articles' => Collection]
     * pour les layouts qui affichent des blocs par rubrique.
     */
    #[Computed]
    public function featured_categories()
    {
        $usedIds = array_filter([
            $this->featured_article?->id,
            ...$this->last_articles->pluck('id')->all(),
            ...$this->pinned_articles->pluck('id')->all(),
        ]);

        return Category::where('is_active', true)
            ->whereNull('parent_id')
            ->ordered()
            ->take(4)
            ->get()
            ->map(fn(Category $cat) => [
                'category' => $cat,
                'articles' => Article::published()
                    ->with(['category'])
                    ->whereIn('category_id', $cat->getAllChildrenIds())
                    ->whereNotIn('id', $usedIds)
                    ->latest('published_at')
                    ->take(4)
                    ->get(),
            ])
            ->filter(fn($block) => $block['articles']->isNotEmpty());
    }

    /**
     * Articles sponsorisés actifs.
     */
    #[Computed]
    public function sponsored_articles()
    {
        return Article::published()
            ->with(['category'])
            ->whereHas('sponsorships', function ($q) {
                $q->where('is_active', true)
                    ->where(function ($q2) {
                        $q2->whereNull('start_date')
                            ->orWhere('start_date', '<=', now());
                    })
                    ->where(function ($q2) {
                        $q2->whereNull('end_date')
                            ->orWhere('end_date', '>=', now());
                    });
            })
            ->inRandomOrder()
            ->take(6)
            ->get();
    }

    /**
     * Édition spéciale (null = désactivée).
     * Surcharger dans le projet client si nécessaire.
     */
    #[Computed]
    public function special_edition(): ?array
    {
        return null;
        // Exemple d'activation :
        // return [
        //     'label'       => 'Édition Spéciale',
        //     'description' => 'Notre dossier complet sur les élections.',
        //     'url'         => '/dossier/elections',
        //     'cta'         => 'Lire le dossier',
        // ];
    }

    // ── Render ──────────────────────────────────────────────────

    public function render()
    {
        return view('mtblog::livewire.home.' . $this->layout, [
            'hasBreakingNews' => mtblog_option_home('breaking_news'),
        ]);
    }
}
