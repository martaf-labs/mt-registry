<?php

namespace Mt\Blog\Livewire;

use Illuminate\Auth\Events\Login as LoginEvent;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\On;
use Livewire\Component;

/**
 * Modale de connexion rapide (front blog).
 * S'ouvre sur l'évènement 'open-auth-modal' (émis par toggleLike / postComment /
 * le bouton « se connecter » des commentaires) → l'utilisateur s'authentifie sans
 * quitter l'article. Réutilise la technique du composant mt-ui Login :
 * écriture directe en session SANS migrate() (évite le souci de cookie en AJAX),
 * puis rechargement de la page pour re-rendre tout en état connecté.
 */
class QuickAuth extends Component
{
    public bool   $open     = false;
    public string $email    = '';
    public string $password = '';
    public bool   $remember = false;

    #[On('open-auth-modal')]
    public function openModal(): void
    {
        if (Auth::check()) {
            return;
        }
        $this->open = true;
    }

    public function close(): void
    {
        $this->open = false;
        $this->reset(['email', 'password', 'remember']);
        $this->resetErrorBag();
    }

    public function login(): void
    {
        $this->validate([
            'email'    => 'required|string|email',
            'password' => 'required|string',
        ], [
            'email.required'    => "L'adresse e-mail est obligatoire.",
            'email.email'       => 'Adresse e-mail invalide.',
            'password.required' => 'Le mot de passe est obligatoire.',
        ]);

        $this->ensureIsNotRateLimited();

        $provider = Auth::getProvider();
        $user     = $provider->retrieveByCredentials(['email' => $this->email]);

        if (! $user || ! $provider->validateCredentials($user, ['password' => $this->password])) {
            RateLimiter::hit($this->throttleKey());
            $this->reset('password');
            throw ValidationException::withMessages(['email' => __('auth.failed')]);
        }

        $this->writeAuthToSession($user);
        RateLimiter::clear($this->throttleKey());

        // Rechargement complet → ArticleShow & co. se re-rendent authentifiés.
        $this->js('window.location.reload()');
    }

    protected function writeAuthToSession(Authenticatable $user): void
    {
        $guard = Auth::guard();
        session()->put($guard->getName(), $user->getAuthIdentifier());

        if ($this->remember) {
            $user->setRememberToken(Str::random(60));
            $user->save();
        }

        $guard->setUser($user);
        event(new LoginEvent(Auth::getDefaultDriver(), $user, $this->remember));
    }

    protected function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        $seconds = RateLimiter::availableIn($this->throttleKey());
        throw ValidationException::withMessages([
            'email' => __('auth.throttle', ['seconds' => $seconds, 'minutes' => (int) ceil($seconds / 60)]),
        ]);
    }

    protected function throttleKey(): string
    {
        return Str::transliterate(Str::lower($this->email) . '|' . request()->ip());
    }

    public function render()
    {
        return view('mtblog::livewire.quick-auth');
    }
}
