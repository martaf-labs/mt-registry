<?php

namespace Mt\Blog\Livewire\Admin\Comments;

use Livewire\Attributes\Title;
use Mt\Blog\Livewire\Indexes\CommentIndex;
use Mt\Blog\Models\Comment;
use Mt\MtUi\Livewire\Base\BaseIndex;

#[Title('Commentaires')]
class CommentIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return CommentIndex::class;
    }

    public function approveComment($id = null): void
    {
        if ($id) {
            Comment::whereKey($id)->update(['status' => 'approved']);
        }
        $this->dispatch(BaseIndex::class, 'refresh');
    }

    public function unapproveComment($id = null): void
    {
        if ($id) {
            Comment::whereKey($id)->update(['status' => 'pending']);
        }
        $this->dispatch(BaseIndex::class, 'refresh');
    }

    public function markSpam($id = null): void
    {
        if ($id) {
            Comment::whereKey($id)->update(['status' => 'spam']);
        }
        $this->dispatch(BaseIndex::class, 'refresh');
    }
}
