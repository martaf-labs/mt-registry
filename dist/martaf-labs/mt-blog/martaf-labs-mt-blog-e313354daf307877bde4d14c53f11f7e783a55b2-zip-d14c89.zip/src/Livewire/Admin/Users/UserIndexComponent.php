<?php

namespace Mt\Blog\Livewire\Admin\Users;

use Livewire\Attributes\Title;
use Mt\MtUi\Livewire\Base\BaseIndex;
use Mt\Blog\Livewire\Indexes\UserIndex;

#[Title('Utilisateurs')]
class UserIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return UserIndex::class;
    }
}
