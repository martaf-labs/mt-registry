<?php

namespace Mt\Blog\Livewire\Admin\Users;

use Mt\Blog\Models\User;
use Mt\Blog\Models\Categorie;
use Livewire\Attributes\Title;
use Mt\MtUi\Livewire\Base\BaseForm;
use Dom\Comment;
use Livewire\Attributes\Locked;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

#[Title('Utilisateurs')]
class UsersForm extends Component
{
    // Déclarer les propriétés avec des valeurs par défaut
    public $modelClass = User::class;
    public $model = "user";
    public $model_plural = "users";
    public $mainLabel = "Users";
    public $title = "";
    public $navItems = null; // CORRECTION : Initialiser à null
    public $mode = null;
    #[Locked]
    public $id = null;
    public $data = null;
    public $form = null;

    // Propriétés du formulaire - initialiser avec des valeurs par défaut
    public $userable_type = '';
    public $userable_id = null;
    public $email = '';
    public $password = '';
    public $role = null;
    public $last_seen = '';

    // CORRECTION : Utiliser la même signature que BaseForm
    public function mount($modelClass = null, $model = '', $model_plural = '', $title = '', $navItems = null, $id = null, $data = null, $mode = null, $form)
    {
        // Initialiser les propriétés de base avec les valeurs par défaut de cette classe
        $this->modelClass = $modelClass ?? $this->modelClass;
        $this->model = $model ?: $this->model;
        $this->model_plural = $model_plural ?: $this->model_plural;
        $this->title = $title ?: $this->title;
        $this->id = $id ?? $this->id;

        // CORRECTION : Initialiser formDatas avant de l'utiliser
        $this->initializeFormDatas();

        // Appel du parent avec tous les paramètres
        parent::mount(
            modelClass: $this->modelClass,
            model: $this->model,
            model_plural: $this->model_plural,
            title: $this->title,
            navItems: $this->navItems->get(),
            id: $this->id,
            data: $this->data,
            mode: $this->mode,
            form: $this->form
        );
    }

    /**
     * Initialiser formDatas séparément
     */
    private function initializeFormDatas()
    {
        // Préparer la navigation
        $this->navItems = navItems($this->model, $this->mainLabel)->add('Nouveau','#');

        // Charger les données si ID est fourni
        if ($this->id && is_numeric($this->id) && !$this->data) {
            $this->title = "Modifier l'utilisateur";
            $this->data = User::find($this->id);
            $this->mode='edit';
            $this->navItems = navItems($this->model, $this->mainLabel)
                ->add($this->data->nom, mt_get_route($this->model_plural.'_show', ['id' => $this->id]))
                ->add('Modifier','#');
        } else{
            $this->title = "Ajouter un utilisateur";
            $this->mode='create';
            $this->navItems = navItems($this->model, $this->mainLabel)
                ->add('Nouveau','#');
        }

        $annees = range(date('Y'), 1990);
        $userId = $this->data?->user_id ?? Auth::id();
        $editNullable = $this->mode === 'edit'? 'nullable' : 'required';

        $this->formDatas = [
        ];
    }
}
