<?php

namespace Mt\Blog\Livewire\Admin\Users;

use Livewire\Attributes\Title;
use Mt\MtUi\Livewire\Base\BaseProfile;
use Mt\Blog\Livewire\Profiles\UserProfile;

#[Title('Profil Utilisateur')]
class UserProfileComponent extends BaseProfile
{
    public function profileClass(): string
    {
        return UserProfile::class;
    }
}
