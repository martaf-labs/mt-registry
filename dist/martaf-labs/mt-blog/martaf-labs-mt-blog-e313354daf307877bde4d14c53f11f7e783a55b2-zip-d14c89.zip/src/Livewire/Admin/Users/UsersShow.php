<?php

namespace Mt\Blog\Livewire\Admin\Users;

use Mt\Blog\Models\User;
use Livewire\Component;
use Mt\Blog\Models\Categorie;
use Livewire\Attributes\Title;
use Livewire\Attributes\Locked;

#[Title('Utilisateurs')]
class UsersShow extends Component
{
    // Déclarer les propriétés avec des valeurs par défaut
    public $modelClass = User::class;
    public $model = "user";
    public $model_plural = "users";
    public $mainLabel = "Users";
    public $title = "";
    public $navItems = null;
    #[Locked]
    public $id = null;
    public $data = null;
    public $showDatas = null;

    public function mount($modelClass = null, $model = '', $model_plural = '', $title = '', $navItems = null, $id = null, $showDatas = null)
    {
        // Initialiser les propriétés de base avec les valeurs par défaut de cette classe

        // Initialiser showDatas avant de l'utiliser
        $this->initializeShowDatas();

        // Appel du parent avec tous les paramètres
        parent::mount(
            modelClass: $this->modelClass,
            model: $this->model,
            model_plural: $this->model_plural,
            title: $this->title,
            navItems: $this->navItems->get(),
            id: $this->id,
            showDatas: $this->showDatas
        );
    }

    /**
     * Initialiser showDatas séparément
     */
    private function initializeShowDatas()
    {
        // Charger les données si ID est fourni
        if ($this->id && is_numeric($this->id) && !$this->data) {
            $this->data = $this->modelClass::find($this->id);
            $this->title = $this->data->nom;

            // Navigation items
            $this->navItems = navItems($this->model, $this->mainLabel)
                ->add($this->data->nom, mt_get_route($this->model_plural.'_show', ['id' => $this->id]))
                ->add('Description','#');
        } else {
            $this->title = "Description de l'user";
            if ($this->navItems) {
                $this->navItems->add('Description', '#');
            }
        }

        $this->showDatas = [
            'fields' => [
                [
                    'name' => 'nom',
                    'type' => 'text',
                    'label' => 'Nom de l\'user',
                    'value' => $this->data->nom ?? 'N/A',
                    'col' => 12,
                ],
                [
                    'name' => 'categorie',
                    'type' => 'text',
                    'label' => 'Catégorie d\'user',
                    'relation' => 'categorie',
                    'relation_type' => 'belongsTo',
                    'value' => $this->data->categorie->nom ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'marque',
                    'type' => 'select',
                    'label' => 'Marque',
                    'value' => User::marques()[$this->data->marque] ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'modele',
                    'type' => 'text',
                    'label' => 'Modèle',
                    'value' => $this->data->modele ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'annee',
                    'type' => 'text',
                    'label' => 'Mise en service',
                    'value' => $this->data->annee ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'numero_serie',
                    'type' => 'text',
                    'label' => 'Numéro de série',
                    'value' => $this->data->numero_serie ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'immatriculation',
                    'type' => 'text',
                    'label' => 'Immatriculation',
                    'value' => $this->data->immatriculation ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'type_compteur',
                    'type' => 'select',
                    'label' => 'Type de compteur',
                    'value' => User::typeCompteurs()[$this->data->type_compteur] ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'couleur',
                    'type' => 'select',
                    'label' => 'Couleur',
                    'value' => User::couleurs()[$this->data->couleur] ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'localisation',
                    'type' => 'text',
                    'label' => 'Localisation',
                    'value' => $this->data->localisation ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'etat',
                    'type' => 'select',
                    'label' => 'État',
                    'value' => User::etats()[$this->data->etat] ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'statut',
                    'type' => 'select',
                    'label' => 'Statut',
                    'value' => User::statuts()[$this->data->statut] ?? 'N/A',
                    'col' => 4,
                ],
                [
                    'name' => 'user',
                    'type' => 'text',
                    'label' => 'Créé par',
                    'relation' => 'user',
                    'relation_type' => 'belongsTo',
                    'display_field' => 'name',
                    'value' => $this->data->user->name ?? 'N/A',
                    'col' => 4,
                ],
                // Champs supplémentaires pour les métadonnées
                [
                    'name' => 'compteur',
                    'type' => 'text',
                    'label' => $this->data->type_compteur == User::KILOMETRAGE? 'Kilométrage' : 'Heures moteur',
                    'value' => $this->data->formatCompteur(true),
                    'col' => 6,
                ],
                [
                    'name' => 'description',
                    'type' => 'editor',
                    'label' => 'Description',
                    'value' => $this->data->description,
                    'col' => 12,
                ]
            ],

            'medias' => [
                'image' => [
                    'url' => $this->data->imageUrl()
                ],
                'images' => $this->data->images->map(function($item){
                        return [
                            'title' => $item->nom,
                            'src' => $item->imageUrl(),
                            'description' => $item->description
                        ];
                    })->toArray(),
            ],

            'actions' => [
                'edit' => [
                    'label' => 'Modifier',
                    'route' => 'admin.users.edit',
                    'params' => ['id' => $this->id],
                    'icon' => 'pencil',
                    'variant' => 'primary'
                ],
                'back' => [
                    'label' => 'Retour à la liste',
                    'route' => 'admin.users.index',
                    'icon' => 'arrow-left',
                    'variant' => 'secondary'
                ],
                'delete' => [
                    'label' => 'Supprimer',
                    'route' => 'admin.users.destroy',
                    'params' => ['id' => $this->id],
                    'icon' => 'trash',
                    'variant' => 'danger',
                    'method' => 'delete'
                ]
            ]
        ];
    }

    /**
     * Surcharger la méthode formatValue pour les champs spécifiques
     */
    public function formatValue($field, $value)
    {
        $fieldName = $field['name'] ?? '';

        // Formatage spécifique pour les valeurs numériques
        if ($fieldName === 'kilometrage' && $value) {
            return number_format($value, 0, ',', ' ') . ' km';
        }

        if ($fieldName === 'heures_moteur' && $value) {
            return number_format($value, 0, ',', ' ') . ' h';
        }

        // Formatage spécifique pour les dates
        if (in_array($fieldName, ['created_at', 'updated_at']) && $value) {
            return \Carbon\Carbon::parse($value)->format('d/m/Y H:i');
        }

        // Formatage pour les champs select avec listItems
        if (isset($field['listItems']) && $value) {
            $listItems = $field['listItems'];
            if (is_array($listItems) && isset($listItems[$value])) {
                return $listItems[$value];
            }
        }

        // Appeler la méthode parente pour le formatage standard
        return parent::formatValue($field, $value);
    }

    /**
     * Obtenir des informations supplémentaires pour l'affichage
     * Cette méthode peut être utilisée dans la vue pour afficher des infos supplémentaires
     */
    public function getAdditionalInfo()
    {
        $info = [];

        if ($this->data) {
            $info[] = [
                'label' => 'Date de création',
                'value' => $this->data->created_at?->format('d/m/Y H:i'),
                'icon' => 'calendar-plus'
            ];

            $info[] = [
                'label' => 'Dernière modification',
                'value' => $this->data->updated_at?->format('d/m/Y H:i'),
                'icon' => 'calendar-check'
            ];

            if ($this->data->kilometrage) {
                $info[] = [
                    'label' => 'Kilométrage',
                    'value' => number_format($this->data->kilometrage, 0, ',', ' ') . ' km',
                    'icon' => 'speedometer2'
                ];
            }

            if ($this->data->heures_moteur) {
                $info[] = [
                    'label' => 'Heures moteur',
                    'value' => number_format($this->data->heures_moteur, 0, ',', ' ') . ' h',
                    'icon' => 'clock'
                ];
            }
        }

        return $info;
    }
}
