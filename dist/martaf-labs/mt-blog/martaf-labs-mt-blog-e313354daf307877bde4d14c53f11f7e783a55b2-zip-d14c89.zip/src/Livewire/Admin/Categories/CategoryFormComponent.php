<?php

namespace Mt\Blog\Livewire\Admin\Categories;

use Mt\Blog\Livewire\Forms\CategoryForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class CategoryFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return CategoryForm::class;
    }

    public function getModelName(): string
    {
        return 'une catégorie';
    }

    public function getPluralModelName(): string
    {
        return 'les catégories';
    }

    public function getRedirectRouteName(): string
    {
        return 'admin.categories.index';
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('categorie', 'Catégories')
                ->add('Nouvelle', '#')
                ->get()
            : navItems('categorie', 'Catégories')
                ->add($data->name, '#')
                ->add('Modifier', '#')
                ->get();
    }

    /**
     * Formulaire mono-étape (pas de wizard).
     */
    public function steps(): array
    {
        return [];
    }
}
