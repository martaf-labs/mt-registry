<?php

namespace Mt\Blog\Livewire\Admin\Categories;

use Livewire\Attributes\Title;
use Mt\Blog\Livewire\Indexes\CategoryIndex;
use Mt\Blog\Models\Category;
use Mt\MtUi\Livewire\Base\BaseIndex;

#[Title('Catégories')]
class CategoryIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return CategoryIndex::class;
    }

    public function toggleActive($id = null)
    {
        if (is_null($id)) {
            return;
        }

        $category = Category::find($id);

        if ($category) {
            $category->update(['is_active' => ! $category->is_active]);
        }

        $this->dispatch(BaseIndex::class, 'refresh');
    }
}
