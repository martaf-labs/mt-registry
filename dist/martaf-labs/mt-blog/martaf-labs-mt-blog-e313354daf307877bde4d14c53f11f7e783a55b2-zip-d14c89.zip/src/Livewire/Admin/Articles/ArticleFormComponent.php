<?php

namespace Mt\Blog\Livewire\Admin\Articles;

use Illuminate\Support\Str;
use Mt\Blog\Livewire\Forms\ArticleForm;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\ArticleType;
use Mt\Blog\Models\Category;
use Mt\Blog\Models\Partner;
use Mt\MtUi\Livewire\Base\BaseForm;

class ArticleFormComponent extends BaseForm
{
    // Définitions abstraites implémentées

    public function formClass(): string
    {
        return ArticleForm::class;
    }

    public function getModelName(): string
    {
        return 'un article';
    }

    public function getPluralModelName(): string
    {
        return 'les articles';
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data) ?
        navItems("article", "Articles")
        ->add("Nouveau", '#')
        ->get()
        :
        navItems("article", "Articles")
        ->add($data->title, mt_get_route("articles_show", ["id"=> $data->id]))
        ->add("Modifier", '#')
        ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'admin.articles.index';
    }

    /**
     * Définition des étapes (formulaire multi-étapes)
     */
    public function steps(): array
    {
        $articleCommonsFields = ['title', 'excerpt', 'content', 'image.path', 'image.title'];

        $articleAllFields = $articleCommonsFields;
        return [];

        // if ($this->mode !== 'edit'){
        //    array_push($articleCommonsFields, 'image.path');
        // }

        // return $this->mode === 'edit' ? []
        // : [
        //     1 => [
        //         'title' => 'Type de contenu',
        //         'description' => 'Choisir un type de contenu',
        //         'fields' => ['type.is_sponsored']
        //     ],
        //     2 => [
        //         'title' => 'Type d\'article',
        //         'description' => 'Choisir le type d\'article',
        //         'fields' => ['article_type_id']
        //     ],
        //     3 => [
        //         'title' => 'Sponsor de l\'article',
        //         'description' => 'Choisir un partenaire',
        //         'fields' => ['sponsorship.partner_id']
        //     ],
        //     4 => [
        //         'title' => 'Sponsor de l\'article',
        //         'description' => 'Ajouter un nouveau partenaire',
        //         'fields' => ['partner.name','partner.email','partner.website','partner.icon','partner.color','partner.description']
        //     ],
        //     5 => [
        //         'title' => 'Catégorie de l\'article',
        //         'description' => 'Choisir une catégorie',
        //         'fields' => ['category.parent_id']
        //     ],
        //     6 => [
        //         'title' => 'Catégorie de l\'article',
        //         'description' => 'Ajouter une nouvelle catégorie',
        //         'fields' => ['category_parent.name','category_parent.icon','category_parent.color','category_parent.description']
        //     ],
        //     7 => [
        //         'title' => 'Sous-catégorie de l\'article',
        //         'description' => 'Choisir une sous-catégorie',
        //         'fields' => ['category_id']
        //     ],
        //     8 => [
        //         'title' => 'Sous-catégorie de l\'article',
        //         'description' => 'Ajouter une sous-catégorie',
        //         'fields' => ['category.name','category.icon','category.color','category.description']
        //     ],
        //     9 => [
        //         'title' => 'Détails de l\'article',
        //         'description' => 'Ajouter les détails de l\'article',
        //         'fields' => $articleAllFields
        //     ]
        // ];
    }


    /**
     * Conditions pour afficher chaque étape
     *
     * Flux création :
     *  1  → Toujours : choisir type de contenu (sponsorisé ou non)
     *  2  → Si des ArticleType existent en BDD
     *  3  → Si sponsorisé ET des Partners existent en BDD → choisir un partenaire
     *  4  → Si sponsorisé ET aucun partenaire sélectionné après étape 3
     *           (soit pas de Partners en BDD, soit l'utilisateur n'en a pas choisi)
     *  5  → Si des catégories parentes existent en BDD → choisir une catégorie
     *  6  → Si aucune catégorie parente en BDD → forcer la création
     *  7  → Si une catégorie parente a été choisie/créée ET qu'elle a des sous-catégories
     *  8  → Si une catégorie parente a été choisie/créée ET qu'elle n'a pas de sous-catégories
     *  9  → Toujours : détails de l'article
     */
    // public function stepCondition(int $step): bool
    // {
    //     $countCategoryParent = Category::parents()->count();

    //     // Compter les enfants uniquement si une catégorie parente est sélectionnée
    //     $parentId = $this->form->category['parent_id'];
    //     $countCategoryChild = !is_null($parentId)
    //         ? (Category::find($parentId)?->children()->count() ?? 0)
    //         : 0;

    //     // is_sponsored provient d'un <select> donc c'est une string "true"/"false"
    //     $isSponsored = filter_var($this->form->type['is_sponsored'], FILTER_VALIDATE_BOOLEAN);

    //     $partnerCount = Partner::count();
    //     $partnerSelected = !is_null($this->form->sponsorship['partner_id']);

    //     switch ($step) {
    //         case 1:
    //             // Toujours affichée
    //             return true;

    //         case 2:
    //             // Afficher seulement s'il existe des types d'articles en BDD
    //             // (peu importe si un type est déjà sélectionné, pour permettre le retour arrière)
    //             return ArticleType::count() > 0;

    //         case 3:
    //             // Choisir un partenaire existant : seulement si sponsorisé ET des partenaires existent
    //             return $isSponsored && $partnerCount > 0;

    //         case 4:
    //             // Créer un nouveau partenaire :
    //             // - Si sponsorisé ET aucun partenaire en BDD (on force la création)
    //             // - Si sponsorisé ET des partenaires existent MAIS aucun n'a été sélectionné à l'étape 3
    //             return $isSponsored && !$partnerSelected;

    //         case 5:
    //             // Choisir une catégorie parente existante
    //             return $countCategoryParent > 0;

    //         case 6:
    //             // Créer une catégorie parente : seulement si aucune en BDD
    //             return $countCategoryParent === 0;

    //         case 7:
    //             // Choisir une sous-catégorie : une catégorie parente doit être sélectionnée
    //             // ET elle doit avoir des enfants
    //             return !is_null($parentId) && $countCategoryChild > 0;

    //         case 8:
    //             // Créer une sous-catégorie : une catégorie parente sélectionnée
    //             // ET elle n'a pas encore de sous-catégories
    //             return !is_null($parentId) && $countCategoryChild === 0;

    //         default:
    //             return true;
    //     }
    // }
}
