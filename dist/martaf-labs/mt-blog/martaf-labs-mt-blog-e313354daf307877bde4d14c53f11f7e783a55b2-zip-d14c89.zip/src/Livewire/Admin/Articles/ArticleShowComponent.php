<?php

namespace Mt\Blog\Livewire\Admin\Articles;

use Livewire\Attributes\Title;
use Mt\Blog\Livewire\Shows\ArticleShow;
use Mt\MtUi\Livewire\Base\BaseShow;

#[Title('Articles')]
class ArticleShowComponent extends BaseShow
{
    public function showClass(): string
    {
        return ArticleShow::class;
    }

    /**
     * gerer les caracteristique de l'équipement :ajouter,modifier, supprimer
     */
    public function manageCaracteristiques()
    {
        $this->dispatch('open-equipement-caracteristiques-modal',
            id: $this->id,
        );
    }
}
