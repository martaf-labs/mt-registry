<?php

namespace Mt\Blog\Livewire;

use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Str;
use Livewire\Attributes\On;
use Livewire\Component;
use Mt\Blog\Models\NewsletterSubscriber;

/**
 * Inscription newsletter — point unique pour le header (modale) ET le footer
 * (formulaire inline qui émet l'évènement 'newsletter-subscribe').
 * À l'inscription : crée le NewsletterSubscriber, pose un cookie 1 an, et émet
 * 'newsletter-subscribed' (capté côté Alpine → masque header + footer instantanément).
 */
class NewsletterModal extends Component
{
    public bool   $open  = false;
    public string $email = '';
    public bool   $done  = false;

    #[On('open-newsletter-modal')]
    public function openModal(): void
    {
        $this->reset(['email', 'done']);
        $this->resetErrorBag();
        $this->open = true;
    }

    public function close(): void
    {
        $this->open = false;
    }

    /** Soumission depuis la modale (champ $email du composant). */
    public function subscribe(): void
    {
        $this->doSubscribe($this->email);
        $this->done = true;
    }

    /** Soumission depuis le formulaire inline du footer (email passé en paramètre). */
    #[On('newsletter-subscribe')]
    public function subscribeWith(string $email): void
    {
        try {
            $this->doSubscribe($email);
        } catch (\Throwable $e) {
            // Le footer gère son propre retour visuel ; on ne propage pas l'erreur de validation.
        }
    }

    protected function doSubscribe(string $email): void
    {
        $data = validator(
            ['email' => $email],
            ['email' => 'required|email:rfc'],
            ['email.required' => 'Adresse email requise.', 'email.email' => 'Adresse email invalide.']
        )->validate();

        NewsletterSubscriber::firstOrCreate(
            ['email' => $data['email']],
            ['token' => Str::random(40), 'is_active' => true]
        );

        Cookie::queue('mt_newsletter_subscribed', '1', 60 * 24 * 365); // 1 an
        $this->dispatch('newsletter-subscribed');                       // → Alpine masque header + footer
        $this->dispatch('notify', message: 'Merci ! Votre inscription est confirmée.', type: 'success');
    }

    public function render()
    {
        return view('mtblog::livewire.newsletter-modal');
    }
}
