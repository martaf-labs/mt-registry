<?php

namespace Mt\Blog\Livewire;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Mt\Blog\Models\Advertisement;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\ArticleStat;
use Mt\Blog\Models\Category;
use Mt\Blog\Models\Comment;
use Mt\Blog\Models\NewsletterSubscriber;
use Mt\Blog\Models\Partner;
use Mt\Blog\Models\Sponsorship;
use Mt\Blog\Models\Tag;
use Mt\MtUi\Livewire\MtDashboard;
use Illuminate\Support\Str;

/**
 * Dashboard Blog — mt-blog
 *
 * Enregistrement dans AppServiceProvider :
 *   Livewire::component('mt.dashboard', \App\Livewire\Dashboard::class);
 */
class Dashboard extends MtDashboard
{
    // ──────────────────────────────────────────────────────────────────────
    // Période d'analyse sélectionnée
    // ──────────────────────────────────────────────────────────────────────
    public string $periode = '30'; // 7 | 30 | 90 | 365

    public function getTitle(): string
    {
        return 'Tableau de bord';
    }

    public function getSubtitle(): string
    {
        $totalVues = Article::sum('views_count');
        return number_format($totalVues, 0, ',', ' ') . ' vues au total · ' .
               ucfirst(now()->locale('fr')->translatedFormat('l j F Y'));
    }

    public function getQuickActions(): array
    {
        return [
            [
                'label'   => 'Nouvel article',
                'icon'    => 'fa-solid fa-pen-to-square',
                'route'   => mt_get_route('articles_create'),
                'variant' => 'primary',
            ],
            [
                'label'   => 'Nouvelle catégorie',
                'icon'    => 'fa-solid fa-folder-plus',
                'route'   => 'admin.categories.create',
                'variant' => 'secondary',
            ],
            [
                'label'   => 'Commentaires',
                'icon'    => 'fa-solid fa-comments',
                'route'   => mt_get_route('articles'),
                'variant' => 'ghost',
            ],
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // STATS CARDS
    // ──────────────────────────────────────────────────────────────────────
    public function getStats(): array
    {
        $days = (int) $this->periode;
        $depuis = now()->subDays($days);

        // ── Articles ──────────────────────────────────────────────────
        $totalArticles     = Article::count();
        $publies           = Article::published()->count();
        $brouillons        = Article::draft()->count();
        $programmes        = Article::scheduled()->count();
        $nouvelsCeMois     = Article::where('created_at', '>=', $depuis)->count();
        $articlesMoisPrec  = Article::where('created_at', '<', $depuis)
                                    ->where('created_at', '>=', now()->subDays($days * 2))
                                    ->count();
        $variationArticles = $articlesMoisPrec > 0
            ? round((($nouvelsCeMois - $articlesMoisPrec) / $articlesMoisPrec) * 100)
            : ($nouvelsCeMois > 0 ? 100 : 0);

        // ── Vues ──────────────────────────────────────────────────────
        $vuesPeriode = ArticleStat::where('date', '>=', $depuis)->sum('views');
        $vuesPrecPeriode = ArticleStat::where('date', '<', $depuis)
                                      ->where('date', '>=', now()->subDays($days * 2))
                                      ->sum('views');
        $variationVues = $vuesPrecPeriode > 0
            ? round((($vuesPeriode - $vuesPrecPeriode) / $vuesPrecPeriode) * 100)
            : ($vuesPeriode > 0 ? 100 : 0);

        // ── Commentaires ──────────────────────────────────────────────
        $totalCommentaires  = Comment::count();
        $enAttente          = Comment::pending()->count();
        $approuves          = Comment::approved()->count();

        // ── Engagement ────────────────────────────────────────────────
        $totalLikes         = Article::sum('likes_count');
        $totalShares        = Article::sum('shares_count');
        $totalBookmarks     = Article::sum('bookmarks_count');
        $likesPeriode       = ArticleStat::where('date', '>=', $depuis)->sum('likes');

        // ── Newsletter ────────────────────────────────────────────────
        $totalAbonnes       = NewsletterSubscriber::where('is_active', true)->count();
        $nouveauxAbonnes    = NewsletterSubscriber::where('is_active', true)
                                                  ->where('created_at', '>=', $depuis)
                                                  ->count();

        // ── Partenaires & Sponsorings ─────────────────────────────────
        $sponsoringActifs   = Sponsorship::where('is_active', true)
                                         ->where(fn($q) => $q->whereNull('end_date')->orWhere('end_date', '>=', now()))
                                         ->count();
        $totalPartenaires   = Partner::where('is_active', true)->count();

        return [
            // Articles publiés
            [
                'label'      => 'Articles publiés',
                'value'      => $publies,
                'icon'       => 'fa-solid fa-newspaper',
                'color'      => 'primary',
                'route'      => mt_get_route('articles'),
                'change'     => ($variationArticles >= 0 ? '+' : '') . $variationArticles . '%',
                'changeType' => $variationArticles >= 0 ? 'positive' : 'negative',
                'details'    => [
                    ['label' => 'Total',      'value' => $totalArticles],
                    ['label' => 'Brouillons', 'value' => $brouillons],
                    ['label' => 'Programmés', 'value' => $programmes],
                ],
            ],

            // Vues (période)
            [
                'label'      => 'Vues (' . $days . 'j)',
                'value'      => number_format($vuesPeriode, 0, ',', ' '),
                'icon'       => 'fa-solid fa-eye',
                'color'      => 'info',
                'change'     => ($variationVues >= 0 ? '+' : '') . $variationVues . '%',
                'changeType' => $variationVues >= 0 ? 'positive' : 'negative',
                'details'    => [
                    ['label' => 'vs période préc.', 'value' => number_format($vuesPrecPeriode, 0, ',', ' ')],
                ],
            ],

            // Engagement
            [
                'label'      => 'Engagement',
                'value'      => number_format($totalLikes + $totalShares + $totalBookmarks, 0, ',', ' '),
                'icon'       => 'fa-solid fa-heart',
                'color'      => 'danger',
                'details'    => [
                    ['label' => 'Likes',    'value' => number_format($totalLikes, 0, ',', ' ')],
                    ['label' => 'Partages', 'value' => number_format($totalShares, 0, ',', ' ')],
                    ['label' => 'Favoris',  'value' => number_format($totalBookmarks, 0, ',', ' ')],
                ],
            ],

            // Commentaires
            [
                'label'      => 'Commentaires',
                'value'      => $totalCommentaires,
                'icon'       => 'fa-solid fa-comments',
                'color'      => $enAttente > 0 ? 'warning' : 'success',
                'route'      => mt_get_route('articles'),
                'change'     => $enAttente > 0 ? $enAttente . ' en attente' : 'Tous approuvés',
                'changeType' => $enAttente > 0 ? 'negative' : 'positive',
                'details'    => [
                    ['label' => 'Approuvés', 'value' => $approuves],
                    ['label' => 'En attente', 'value' => $enAttente],
                ],
            ],

            // Newsletter
            [
                'label'      => 'Abonnés newsletter',
                'value'      => number_format($totalAbonnes, 0, ',', ' '),
                'icon'       => 'fa-solid fa-envelope',
                'color'      => 'success',
                'details'    => [
                    ['label' => 'Nouveaux (' . $days . 'j)', 'value' => '+' . $nouveauxAbonnes],
                ],
            ],

            // Partenaires / sponsorings
            [
                'label'      => 'Sponsorings actifs',
                'value'      => $sponsoringActifs,
                'icon'       => 'fa-solid fa-handshake',
                'color'      => 'warning',
                'details'    => [
                    ['label' => 'Partenaires', 'value' => $totalPartenaires],
                ],
            ]
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // WIDGETS
    // ──────────────────────────────────────────────────────────────────────
    public function getWidgets(): array
    {
        return [
            $this->widgetArticlesRecents(),
            $this->widgetPerformances(),
            $this->widgetGraphiqueVues(),
            $this->widgetCommentairesEnAttente(),
            $this->widgetTopArticles(),
            $this->widgetCategories(),
        ];
    }

    public function getStatsColumns(): int
    {
        return 4; // 2 lignes de 3 colonnes
    }

    // ──────────────────────────────────────────────────────────────────────
    // WIDGET 1 — Articles récents (avec statut)
    // ──────────────────────────────────────────────────────────────────────
    private function widgetArticlesRecents(): array
    {
        $articles = Article::with(['category', 'author'])
            ->latest()
            ->take(7)
            ->get()
            ->map(function ($a) {
                $statut = $a->status?->value ?? 'draft';

                $badgeVariant = match($statut) {
                    'published' => 'success',
                    'scheduled' => 'info',
                    'pending'   => 'warning',
                    'archived'  => 'gray',
                    default     => 'gray', // draft
                };

                $badgeLabel = match($statut) {
                    'published' => 'Publié',
                    'scheduled' => 'Programmé',
                    'pending'   => 'En attente',
                    'archived'  => 'Archivé',
                    default     => 'Brouillon',
                };

                return [
                    'title'        => $a->title,
                    'meta'         => ($a->category?->name ?? '—') . ' · ' . ($a->author?->name ?? '—') . ' · ' . $a->reading_time,
                    'icon'         => $a->category?->icon ?? 'fa-solid fa-newspaper',
                    'badge'        => ['label' => $badgeLabel, 'variant' => $badgeVariant],
                    'route'        => mt_get_route('articles_edit', ['id' => $a->id]),
                ];
            })->toArray();

        return [
            'type'     => 'list',
            'title'    => 'Articles récents',
            'subtitle' => 'Derniers créés ou modifiés',
            'span'     => 2,
            'data'     => $articles,
            'actions'  => [
                ['label' => 'Tous les articles', 'route' => mt_get_route('articles')],
                ['label' => '+ Nouvel article',  'route' => 'admin.articles.create'],
            ],
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // WIDGET 2 — Performances clés (stat_group)
    // ──────────────────────────────────────────────────────────────────────
    private function widgetPerformances(): array
    {
        $days = (int) $this->periode;
        $depuis = now()->subDays($days);

        $stats = ArticleStat::where('date', '>=', $depuis)->get();

        $vues       = $stats->sum('views');
        $vuesUniques = $stats->sum('unique_views');
        $tempsMoyen = round($stats->avg('avg_time_on_page') ?? 0);
        $tauxRebond = round($stats->avg('bounce_rate') ?? 0, 1);
        $likes      = $stats->sum('likes');
        $partages   = $stats->sum('shares');

        // Article le plus vu de la période
        $topArticle = Article::with('category')
            ->whereHas('stats', fn($q) => $q->where('date', '>=', $depuis))
            ->orderByDesc('views_count')
            ->first();

        $tauxEngagement = $vues > 0
            ? round((($likes + $partages) / $vues) * 100, 2)
            : 0;

        return [
            'type'    => 'stat_group',
            'title'   => 'Performances (' . $days . ' jours)',
            'subtitle' => 'Métriques de la période',
            'span'    => 1,
            'data'    => [
                [
                    'label' => 'Vues totales',
                    'value' => number_format($vues, 0, ',', ' '),
                    'icon'  => 'fa-solid fa-eye',
                ],
                [
                    'label' => 'Vues uniques',
                    'value' => number_format($vuesUniques, 0, ',', ' '),
                    'icon'  => 'fa-solid fa-user',
                ],
                [
                    'label' => 'Temps moyen / page',
                    'value' => $tempsMoyen . 's',
                    'icon'  => 'fa-solid fa-clock',
                ],
                [
                    'label' => 'Taux de rebond',
                    'value' => $tauxRebond . '%',
                    'icon'  => 'fa-solid fa-right-from-bracket',
                    'badge' => [
                        'label'   => $tauxRebond > 60 ? 'Élevé' : 'Bon',
                        'variant' => $tauxRebond > 60 ? 'warning' : 'success',
                    ],
                ],
                [
                    'label' => 'Likes & Partages',
                    'value' => number_format($likes + $partages, 0, ',', ' '),
                    'icon'  => 'fa-solid fa-heart',
                ],
                [
                    'label' => 'Taux d\'engagement',
                    'value' => $tauxEngagement . '%',
                    'icon'  => 'fa-solid fa-chart-pie',
                    'badge' => [
                        'label'   => $tauxEngagement > 3 ? 'Bon' : 'Faible',
                        'variant' => $tauxEngagement > 3 ? 'success' : 'warning',
                    ],
                ],
                [
                    'label' => 'Top article',
                    'value' => $topArticle ? Str::limit($topArticle->title, 22) : '—',
                    'icon'  => 'fa-solid fa-trophy',
                    'badge' => [
                        'label'   => $topArticle ? number_format($topArticle->views_count, 0, ',', ' ') . ' vues' : '—',
                        'variant' => 'info',
                    ],
                ],
            ],
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // WIDGET 3 — Graphique vues & likes sur 30 jours
    // ──────────────────────────────────────────────────────────────────────
    private function widgetGraphiqueVues(): array
    {
        $days = min((int) $this->periode, 30); // max 30 points sur le graphique

        $jours = collect(range($days - 1, 0))->map(fn($i) => now()->subDays($i)->toDateString());

        $statsParJour = ArticleStat::selectRaw('date, SUM(views) as total_views, SUM(unique_views) as total_unique, SUM(likes) as total_likes')
            ->where('date', '>=', now()->subDays($days))
            ->groupBy('date')
            ->get()
            ->keyBy(fn($s) => $s->date->toDateString());

        $labels  = $jours->map(fn($d) => Carbon::parse($d)->locale('fr')->translatedFormat('j M'))->toArray();
        $vues    = $jours->map(fn($d) => $statsParJour->get($d)?->total_views ?? 0)->toArray();
        $uniques = $jours->map(fn($d) => $statsParJour->get($d)?->total_unique ?? 0)->toArray();
        $likes   = $jours->map(fn($d) => $statsParJour->get($d)?->total_likes ?? 0)->toArray();

        return [
            'type'       => 'chart',
            'title'      => 'Vues & engagement',
            'subtitle'   => 'Évolution sur ' . $days . ' jours',
            'span'       => 2,
            'chart_type' => 'line',
            'height'     => '260px',
            'legend'     => true,
            'data'       => [
                'labels'   => $labels,
                'datasets' => [
                    [
                        'label'           => 'Vues',
                        'data'            => $vues,
                        'borderColor'     => 'rgb(var(--mt-primary))',
                        'backgroundColor' => 'rgba(var(--mt-primary), 0.08)',
                        'fill'            => true,
                        'tension'         => 0.4,
                        'borderWidth'     => 2,
                        'pointRadius'     => 3,
                    ],
                    [
                        'label'           => 'Vues uniques',
                        'data'            => $uniques,
                        'borderColor'     => 'rgb(var(--mt-info))',
                        'backgroundColor' => 'transparent',
                        'fill'            => false,
                        'tension'         => 0.4,
                        'borderWidth'     => 1.5,
                        'borderDash'      => [4, 4],
                        'pointRadius'     => 2,
                    ],
                    [
                        'label'           => 'Likes',
                        'data'            => $likes,
                        'borderColor'     => 'rgb(var(--mt-danger))',
                        'backgroundColor' => 'transparent',
                        'fill'            => false,
                        'tension'         => 0.4,
                        'borderWidth'     => 1.5,
                        'pointRadius'     => 2,
                    ],
                ],
            ],
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // WIDGET 4 — Commentaires en attente de modération
    // ──────────────────────────────────────────────────────────────────────
    private function widgetCommentairesEnAttente(): array
    {
        $commentaires = Comment::with(['article', 'user'])
            ->pending()
            ->latest()
            ->take(6)
            ->get()
            ->map(fn($c) => [
                'title'        => Str::limit($c->content, 55),
                'meta'         => ($c->user?->name ?? 'Anonyme') . ' · ' . $c->created_at->locale('fr')->diffForHumans() . ' · ' . Str::limit($c->article?->title ?? '—', 25),
                'icon'         => 'fa-solid fa-comment-dots',
                'badge'        => ['label' => 'En attente', 'variant' => 'warning'],
                'route'        => mt_get_route('articles'),
            ])->toArray();

        $total = Comment::pending()->count();

        return [
            'type'     => 'list',
            'title'    => 'Modération',
            'subtitle' => $total > 0 ? $total . ' commentaire(s) en attente' : 'Aucun commentaire en attente',
            'span'     => 1,
            'data'     => $commentaires,
            'footer'   => $total > 6 ? ($total - 6) . ' autres commentaires en attente' : null,
            'actions'  => [
                ['label' => 'Tout modérer', 'route' => mt_get_route('articles')],
            ],
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // WIDGET 5 — Top 5 articles (par vues)
    // ──────────────────────────────────────────────────────────────────────
    private function widgetTopArticles(): array
    {
        $maxVues = Article::max('views_count') ?: 1;

        $articles = Article::published()
            ->with('category')
            ->orderByDesc('views_count')
            ->take(5)
            ->get()
            ->map(fn($a) => [
                'label'   => Str::limit($a->title, 35),
                'value'   => number_format($a->views_count, 0, ',', ' ') . ' vues',
                'percent' => round(($a->views_count / $maxVues) * 100),
                'color'   => 'primary',
                'meta'    => ($a->category?->name ?? '—') . ' · ' . $a->reading_time . ' de lecture',
                'icon'    => $a->category?->icon ?? 'fa-solid fa-file-lines',
            ])->toArray();

        return [
            'type'     => 'progress',
            'title'    => 'Top articles',
            'subtitle' => 'Par nombre de vues (tous temps)',
            'span'     => 1,
            'data'     => $articles,
            'actions'  => [
                ['label' => 'Voir les statistiques', 'route' => mt_get_route('articles')],
            ],
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // WIDGET 6 — Répartition par catégorie
    // ──────────────────────────────────────────────────────────────────────
    private function widgetCategories(): array
    {
        $totalArticles = max(1, Article::published()->count());

        $categories = Category::withCount(['articles' => fn($q) => $q->published()])
            ->where('is_active', true)
            ->orderByDesc('articles_count')
            ->take(6)
            ->get()
            ->map(fn($cat) => [
                'label'   => $cat->name,
                'value'   => $cat->articles_count . ' articles',
                'percent' => round(($cat->articles_count / $totalArticles) * 100),
                'color'   => $this->colorFromHex($cat->color),
                'meta'    => round(($cat->articles_count / $totalArticles) * 100) . '% du contenu',
                'icon'    => $cat->icon ?? 'fa-solid fa-folder',
            ])->toArray();

        return [
            'type'     => 'progress',
            'title'    => 'Répartition par catégorie',
            'subtitle' => 'Articles publiés',
            'span'     => 1,
            'data'     => $categories,
            'actions'  => [
                ['label' => 'Gérer les catégories', 'route' => 'admin.categories.index'],
            ],
        ];
    }

    // ──────────────────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────────────────

    /**
     * Mappe une couleur hex vers un nom de couleur mt-*.
     * Approximation basique par teinte dominante.
     */
    private function colorFromHex(string $hex): string
    {
        $hex = ltrim($hex, '#');
        if (strlen($hex) !== 6) return 'primary';

        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));

        if ($r > $g && $r > $b) return 'danger';
        if ($g > $r && $g > $b) return 'success';
        if ($b > $r && $b > $g) return 'info';
        if ($r > 200 && $g > 150 && $b < 100) return 'warning';

        return 'primary';
    }

    // ──────────────────────────────────────────────────────────────────────
    // Action Livewire — changement de période
    // ──────────────────────────────────────────────────────────────────────
    public function setPeriode(string $periode): void
    {
        $this->periode = in_array($periode, ['7', '30', '90', '365']) ? $periode : '30';
    }
}