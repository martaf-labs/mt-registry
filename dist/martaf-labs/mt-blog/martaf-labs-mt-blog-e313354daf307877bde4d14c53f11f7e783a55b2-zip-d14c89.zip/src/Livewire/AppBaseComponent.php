<?php

namespace Mt\Blog\Livewire;

use Livewire\Component;
use Livewire\Attributes\Layout;

#[Layout('components.layouts.app')]
class AppBaseComponent extends Component
{
    // Ici on peux ajouter des méthodes ou propriétés communes
}
