<?php

namespace Mt\Blog\Livewire;

use Livewire\Component;
use Livewire\Attributes\Layout;
use Illuminate\Support\Str;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\NewsletterSubscriber;

#[Layout('mtblog::components.layouts.guest')]
// #[Layout('mt::components.layouts.guest')]
class GuestBaseComponent extends Component
{
    /** Email saisi dans les CTA newsletter (in-article, footer…). */
    public string $newsletterEmail = '';

    /**
     * Inscription newsletter — partagée par toutes les pages guest.
     * Appelable via wire:submit (utilise $newsletterEmail) ou en passant l'email
     * (footer Alpine : $wire.subscribeNewsletter(email)).
     */
    public function subscribeNewsletter(?string $email = null): void
    {
        $email = $email ?? $this->newsletterEmail;

        $data = validator(
            ['email' => $email],
            ['email' => 'required|email:rfc'],
            ['email.required' => 'Adresse email requise.', 'email.email' => 'Adresse email invalide.']
        )->validate();

        NewsletterSubscriber::firstOrCreate(
            ['email' => $data['email']],
            ['token' => Str::random(40), 'is_active' => true]
        );

        $this->newsletterEmail = '';
        $this->dispatch('notify', message: 'Merci ! Votre inscription est confirmée.', type: 'success');
    }

    // ── Interactions sur les post-cards (grilles home/catégorie/similaires…) ──
    // Noms distincts de ArticleShow::toggleLike()/react() (qui ciblent l'article courant)
    // pour éviter toute collision : ici on passe l'ID de l'article de la card.

    /** Like/unlike d'un article depuis une card. Invité → ouvre la modale de connexion. */
    public function cardToggleLike(int $articleId): void
    {
        if (! auth()->check()) {
            $this->dispatch('open-auth-modal');
            return;
        }

        $article = Article::find($articleId);
        if (! $article) {
            return;
        }

        $like = $article->likes()->where('created_by', auth()->id());

        if ($like->exists()) {
            $like->delete();
            $article->decrement('likes_count');
        } else {
            $article->likes()->create(['created_by' => auth()->id()]);
            $article->increment('likes_count');
        }
    }

    /** Réaction emoji rapide depuis une card (compteur agrégé dans meta_data, sans auth requise). */
    public function cardReact(int $articleId, string $emoji): void
    {
        $allowed = ['👍', '❤️', '😮', '😢', '😡'];
        if (! in_array($emoji, $allowed, true)) {
            return;
        }

        $article = Article::find($articleId);
        if (! $article) {
            return;
        }

        $meta = (array) ($article->meta_data ?? []);
        $meta['reactions'] = $meta['reactions'] ?? [];
        $meta['reactions'][$emoji] = ($meta['reactions'][$emoji] ?? 0) + 1;

        $article->meta_data = $meta;
        $article->save();
    }

    /** Comptabilise un partage d'article depuis une card (incrémente shares_count). */
    public function cardRecordShare(int $articleId, string $network = ''): void
    {
        Article::whereKey($articleId)->update([
            'shares_count' => \Illuminate\Support\Facades\DB::raw('shares_count + 1'),
        ]);
    }
}
