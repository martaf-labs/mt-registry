<?php
namespace Mt\Blog\Livewire\Forms;

use Illuminate\Support\Facades\Mail;
use Livewire\Attributes\Validate;
use Livewire\Component;
use Mt\Blog\Models\NewsletterSubscriber;

class NewsletterForm extends Component
{
    #[Validate('required|email|unique:newsletter_subscribers,email')]
    public $email = '';
    public $message = '';

    public function save()
    {
        $this->validate();

        $subscriber = NewsletterSubscriber::create(['email' => $this->email]);

        // Ici, envoyez votre mail de confirmation (facultatif mais recommandé)
        $this->message = "Merci ! Veuillez vérifier votre email pour confirmer votre inscription.";
        $this->reset('email');
    }

    public function render() { return view('mtblog::livewire.forms.newsletter-form'); }
}