<?php

namespace Mt\Blog\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Mt\Blog\Models\Category;
use Mt\MtUi\Livewire\Forms\GenericForm;

/**
 * Form Object du module Catégorie (schema-driven, cf. ArticleForm).
 */
class CategoryForm extends GenericForm
{
    public $name        = null;
    public $description = null;
    public $icon        = 'fa-solid fa-folder';
    public $color       = '#3b82f6';
    public $parent_id   = null;
    public $order       = 0;
    public $is_active   = true;

    public static function modelClass(): string
    {
        return Category::class;
    }

    public function schema(): array
    {
        $modelId = $this->getModelId();

        // Catégories parentes possibles : toutes sauf la catégorie en cours d'édition
        // (on évite qu'une catégorie devienne son propre parent).
        $parents = Category::query()
            ->when(is_numeric($modelId), fn ($q) => $q->whereKeyNot($modelId))
            ->orderBy('name')
            ->pluck('name', 'id');

        return [
            'name' => [
                'type'  => 'text',
                'label' => 'Nom de la catégorie',
                'col'   => 12,
            ],
            'parent_id' => [
                'type'    => 'select',
                'label'   => 'Catégorie parente (optionnel)',
                'options' => $parents,
                'col'     => 6,
            ],
            'order' => [
                'type'  => 'number',
                'label' => "Ordre d'affichage",
                'col'   => 6,
            ],
            'icon' => [
                'type'  => 'text',
                'label' => 'Icône (classe FontAwesome)',
                'col'   => 6,
            ],
            'color' => [
                'type'  => 'text',
                'label' => 'Couleur (hex)',
                'col'   => 6,
            ],
            'description' => [
                'type'  => 'textarea',
                'label' => 'Description',
                'col'   => 12,
            ],
            'is_active' => [
                'type'  => 'toggle',
                'label' => 'Catégorie active',
                'col'   => 12,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $ignore  = is_numeric($modelId) ? ',' . $modelId : '';

        return [
            'name'        => 'required|string|max:255|unique:categories,name' . $ignore,
            'parent_id'   => 'nullable|exists:categories,id',
            'order'       => 'nullable|integer|min:0',
            'icon'        => 'nullable|string|max:255',
            'color'       => 'nullable|string|max:255',
            'description' => 'nullable|string',
            'is_active'   => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Le nom de la catégorie est obligatoire.',
            'name.unique'   => 'Une catégorie portant ce nom existe déjà.',
        ];
    }

    public function save(?Model $model = null): Model
    {
        // "" (placeholder du select) → null pour respecter la règle nullable|exists
        $this->parent_id = $this->parent_id ?: null;
        $this->order     = $this->order ?: 0;

        $data = $this->validate();

        if ($model) {
            $model->update($data);

            return $model;
        }

        return Category::create($data);
    }
}
