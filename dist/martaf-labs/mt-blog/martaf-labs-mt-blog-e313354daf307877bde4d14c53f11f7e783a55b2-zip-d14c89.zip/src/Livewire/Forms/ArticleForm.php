<?php

namespace Mt\Blog\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use League\Flysystem\Visibility;
use Mt\Blog\Enums\StatusArticle;
use Mt\Blog\Enums\TypeSponsorship;
use Mt\Blog\Enums\VisibilityArticle;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\ArticleType;
use Mt\Blog\Models\Category;
use Mt\Blog\Models\Partner;
use Mt\MtUi\Livewire\Forms\GenericForm;

class ArticleForm extends GenericForm
{
    public $title = null;
    public $slug = null;
    public $excerpt = null;
    public $content =null;
    public $content_original = null;
    public $content_blocks = null;
    public $category_id = null;
    public $article_type_id = 1;
    public $views_count = 0;
    public $unique_views_count = 0;
    public $reading_time = 0;
    public $word_count = 0;
    public $likes_count = 0;
    public $comments_count = 0;
    public $shares_count = 0;
    public $bookmarks_count = 0;
    public $status = StatusArticle::DRAFT->value;
    public $visibility = VisibilityArticle::PUBLIC->value;
    public $published_at = null;
    public $scheduled_for = null;
    public $featured_until = null;
    public $meta_data = null;
    public $canonical_url = null;
    public $allow_comments = true;
    public $is_featured = false;
    public $is_breaking_news = false;
    public $is_pinned = false;
    public $version = 1.0;

    // Champs « custom » (pas des colonnes Article) :
    public $tags = '';        // mots-clés séparés par des virgules (relation tags)
    public $takeaways = '';   // « à retenir » : une idée par ligne (→ meta_data.takeaways)

    public $image = [
        'model_type'   => 'Article',
        'model_id'     => null,
        'title'        => null,
        'path'         => null
    ];

    // Définition du schéma selon Form Object
    public function schema(): array
    {
        $isEdit = is_numeric($this->getModelId());

        $articleSchema = [
            'title' => [
                'type'  => 'text',
                'label' => 'Titre de l\'article',
                'col'   => 12,
            ],
            'excerpt' => [
                'type'  => 'textarea',
                'label' => 'Chapeau (résumé court)',
                'col'   => 12,
            ],
            'category_id' => [
                'type'    => 'select',
                'label'   => 'Rubrique',
                'options' => Category::where('is_active', true)->orderBy('name')->pluck('name', 'id'),
                'col'     => 4,
            ],
            'status' => [
                'type'    => 'select',
                'label'   => 'Statut',
                'options' => [
                    'draft'     => 'Brouillon',
                    'pending'   => 'En attente',
                    'published' => 'Publié',
                    'scheduled' => 'Programmé',
                    'archived'  => 'Archivé',
                ],
                'col'     => 4,
            ],
            'visibility' => [
                'type'    => 'select',
                'label'   => 'Visibilité',
                'options' => [
                    'public'  => 'Public',
                    'private' => 'Privé',
                    'premium' => 'Premium',
                ],
                'col'     => 4,
            ],
            'content' => [
                'type'  => 'editor',
                'label' => 'Contenu',
                'col'   => 12,
            ],
            'takeaways' => [
                'type'        => 'textarea',
                'label'       => 'À retenir (une idée par ligne)',
                'placeholder' => "Première idée clé\nDeuxième idée clé\n…",
                'col'         => 12,
            ],
            'tags' => [
                'type'        => 'text',
                'label'       => 'Mots-clés / tags (séparés par des virgules)',
                'placeholder' => 'élections, économie, santé',
                'col'         => 12,
            ],
            'published_at' => [
                'type'  => 'datetime',
                'label' => 'Date de publication (ou programmation)',
                'col'   => 6,
            ],
            'image.path' => [
                'type'     => 'image',
                'label'    => 'Image principale',
                'oldvalue' => $isEdit ? Article::find($this->getModelId())?->image?->path : null,
                'col'      => 6,
            ],
            'image.title' => [
                'type'  => 'image-legend',
                'label' => 'Légende de l\'image',
                'col'   => 12,
            ],
            'is_featured' => [
                'type'  => 'toggle',
                'label' => 'À la une',
                'col'   => 3,
            ],
            'is_breaking_news' => [
                'type'  => 'toggle',
                'label' => 'Flash / Breaking',
                'col'   => 3,
            ],
            'is_pinned' => [
                'type'  => 'toggle',
                'label' => 'Épinglé',
                'col'   => 3,
            ],
            'allow_comments' => [
                'type'  => 'toggle',
                'label' => 'Commentaires autorisés',
                'col'   => 3,
            ],
        ];

        return array_merge(
            // $typeContenuSchema,
            // $articleTypeExistantSchema,
            // $partnerExistantSchema,
            // $partnerSchema,
            // $categorieExistanteSchema,
            // $categorieSchema,
            // $subCategorieExistanteSchema,
            // $subCategorieSchema,
            $articleSchema,
        );
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);
        $rules   = [];

        // if (!$isEdit) {
        //     $rules[1] = [
        //         'type.is_sponsored' => 'required|boolean',
        //     ];
        //     $rules[2] = [
        //         'article_type_id' => 'nullable|exists:article_types,id',
        //     ];
        //     $rules[3] = [
        //         'sponsorship.partner_id' => 'nullable|exists:partners,id',
        //     ];
        //     $rules[4] = [
        //         'partner.name'        => 'nullable|string|max:255|unique:partners,name',
        //         'partner.email'       => 'nullable|email',
        //         'partner.website'     => 'nullable|string',
        //         'partner.icon'        => 'nullable|string|max:255',
        //         'partner.color'       => 'nullable|string|max:255',
        //         'partner.description' => 'nullable',
        //     ];
        //     $rules[5] = [
        //         'category.parent_id' => 'nullable|exists:categories,id',
        //     ];
        //     $rules[6] = [
        //         'category_parent.name'        => 'required_without:category.parent_id|string|max:255|unique:categories,name',
        //         'category_parent.icon'        => 'nullable|string|max:255',
        //         'category_parent.color'       => 'nullable|string|max:255',
        //         'category_parent.description' => 'nullable',
        //     ];
        //     $rules[7] = [
        //         'category_id' => 'nullable|exists:categories,id',
        //     ];
        //     $rules[8] = [
        //         'category.name'        => 'required_without:category_id|string|max:255|unique:categories,name',
        //         'category.icon'        => 'nullable|string|max:255',
        //         'category.color'       => 'nullable|string|max:255',
        //         'category.description' => 'nullable',
        //     ];
        // }

        $articleRules = [
            // required en création, nullable en édition
            'title'            => ($isEdit ? 'nullable' : 'required') . '|string|max:255|unique:articles,title,' . $modelId,
            'excerpt'          => 'nullable|string|max:500',
            'content'          => ($isEdit ? 'nullable' : 'required'),
            'category_id'      => 'required|exists:categories,id',
            'status'           => 'required|string|in:draft,pending,published,scheduled,archived',
            'visibility'       => 'required|string|in:public,private,premium',
            'published_at'     => 'nullable|date',
            'tags'             => 'nullable|string|max:500',
            'takeaways'        => 'nullable|string|max:2000',
            'is_featured'      => 'boolean',
            'is_breaking_news' => 'boolean',
            'is_pinned'        => 'boolean',
            'allow_comments'   => 'boolean',
            'image.path'       => $this->image['path'] instanceof \Illuminate\Http\UploadedFile
                                        ? 'required|image|mimes:jpeg,png,jpg,gif,webp|max:3000'
                                        : 'nullable',
            'image.title'      => 'nullable|string|max:255',
        ];

        // if (!$isEdit) {
        //     $rules[9] = $articleRules;
        // } else {
        //     $rules = $articleRules;
        // }

        return $articleRules;
    }

    public function messages(): array
    {
        return [
            'title.required'           => "Le titre de l'article est obligatoire",
            'title.unique'             => "Un article du même titre existe déjà",
            'content.required'         => "Le contenu de l'article est obligatoire",
            'featured_image.required'  => "L'image de l'article est obligatoire",
            'featured_image.image'     => "Le fichier doit être une image",
            'featured_image.max'       => "L'image ne doit pas dépasser 3 Mo",
            // 'partner.name.required_without' => "Le nom du partenaire est obligatoire si aucun partenaire n'est sélectionné",
        ];
    }

    public static function modelClass(): string
    {
        return Article::class;
    }

    /**
     * Hydratation à l'édition : en plus des colonnes (gérées par le parent),
     * on charge les champs « custom » → tags (relation) et à retenir (meta_data).
     */
    public function fillModel(Model $model): void
    {
        parent::fillModel($model);

        $this->tags = $model->tags()->pluck('name')->implode(', ');
        $this->takeaways = collect($model->meta_data['takeaways'] ?? [])->implode("\n");
    }

    // getModelId() est désormais fourni par GenericForm (protected, partagé par tous les Form Objects).

    /**
     * Résout l'ID de la catégorie finale selon le parcours des étapes
     */
    // protected function resolveCategory(): ?int
    // {
    //     // Cas 1 : sous-catégorie existante sélectionnée (step 7)
    //     if (!is_null($this->category_id)) {
    //         return (int) $this->category_id;
    //     }

    //     // Cas 2 : catégorie parente choisie + nouvelle sous-catégorie à créer (step 8)
    //     if (!is_null($this->category['parent_id']) && !is_null($this->category['name'])) {
    //         $child = Category::create([
    //             'name'        => $this->category['name'],
    //             'slug'        => Str::slug($this->category['name']),
    //             'icon'        => $this->category['icon'],
    //             'color'       => $this->category['color'],
    //             'description' => $this->category['description'],
    //             'parent_id'   => (int) $this->category['parent_id'],
    //             'is_active'   => true,
    //         ]);
    //         return $child->id;
    //     }

    //     // Cas 3 : nouvelle catégorie parente à créer (step 6)
    //     if (!is_null($this->category_parent['name'])) {
    //         $parent = Category::create([
    //             'name'        => $this->category_parent['name'],
    //             'slug'        => Str::slug($this->category_parent['name']),
    //             'icon'        => $this->category_parent['icon'],
    //             'color'       => $this->category_parent['color'],
    //             'description' => $this->category_parent['description'],
    //             'is_active'   => true,
    //         ]);
    //         return $parent->id;
    //     }

    //     // Cas 4 : catégorie parente existante, pas de sous-catégorie
    //     return !is_null($this->category['parent_id']) ? (int) $this->category['parent_id'] : null;
    // }

    /**
     * Synchronise les relations après création/update de l'article
     */
    // protected function syncRelations(Article $article): void
    // {
    //     $isSponsored = filter_var($this->type['is_sponsored'], FILTER_VALIDATE_BOOLEAN);

    //     if (!$isSponsored) {
    //         return;
    //     }

    //     $partnerId = !empty($this->sponsorship['partner_id']) ? (int) $this->sponsorship['partner_id'] : null;

    //     // Créer le partenaire si nouveau
    //     if (is_null($partnerId) && !is_null($this->partner['name'])) {
    //         $partner = Partner::create([
    //             'name'        => $this->partner['name'],
    //             'slug'        => Str::slug($this->partner['name']),
    //             'email'       => $this->partner['email'],
    //             'website'     => $this->partner['website'],
    //             'icon'        => $this->partner['icon'],
    //             'color'       => $this->partner['color'],
    //             'description' => $this->partner['description'],
    //             'is_active'   => true,
    //         ]);
    //         $partnerId = $partner->id;
    //     }

    //     if (!is_null($partnerId)) {
    //         // Utilise sponsorships() (HasMany) avec updateOrCreate
    //         $article->sponsorships()->updateOrCreate(
    //             ['article_id' => $article->id],
    //             [
    //                 'partner_id'         => $partnerId,
    //                 'type'               => $this->sponsorship['type'],
    //                 'start_date'         => $this->sponsorship['start_date'],
    //                 'end_date'           => $this->sponsorship['end_date'],
    //                 'price'              => $this->sponsorship['price'],
    //                 'contract_reference' => $this->sponsorship['contract_reference'],
    //                 'description'        => $this->sponsorship['description'],
    //                 'is_active'          => $this->sponsorship['is_active'] ?? true,
    //             ]
    //         );
    //     }
    // }

    /**
     * Actions déclenchées quand un champ change
     */
    // public function fieldActions(): array
    // {
    //     return [
    //         'type.is_sponsored' => [
    //             ['type' => 'clear', 'target' => 'article_type_id'],
    //             ['type' => 'clear', 'target' => 'sponsorship.partner_id'],
    //             ['type' => 'clear', 'target' => 'partner.name'],
    //         ],
    //         'sponsorship.partner_id' => [
    //             ['type' => 'clear', 'target' => 'partner.name'],
    //             ['type' => 'clear', 'target' => 'partner.email'],
    //             ['type' => 'clear', 'target' => 'partner.website'],
    //         ],
    //         'category.parent_id' => [
    //             ['type' => 'clear', 'target' => 'category_id'],
    //         ],
    //     ];
    // }

    /**
     * Champs critiques pour le recalcul des étapes disponibles
     */
    public function getCriticalFields(): array
    {
        return [
            'type.is_sponsored',
            'article_type_id',
            'sponsorship.partner_id',
            'category.parent_id',
            'category_id',
        ];
    }

    public function save(Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            // 1. Validation & Données
            $data = $this->component->hasMultipleSteps() ? $this->all() : $this->validate();

            // Nettoyage : 'image' (médias), 'tags' et 'takeaways' ne sont pas des colonnes Article.
            $cleanData = collect($data)->except(['image', 'tags', 'takeaways'])->toArray();


            // 2. Persistance du modèle principal
            if ($model) {
                $model->update($cleanData);
                $article = $model;
            } else {
                $article = Article::create($cleanData);
            }

            // 2b. Tags (création + réutilisation via firstOrCreate dans syncTags)
            $tagNames = collect(explode(',', (string) $this->tags))
                ->map(fn ($t) => trim($t))->filter()->unique()->values()->all();
            $article->syncTags($tagNames);

            // 2c. « À retenir » → meta_data.takeaways (on préserve le reste de meta_data, ex. réactions)
            $takeaways = collect(explode("\n", (string) $this->takeaways))
                ->map(fn ($t) => trim($t))->filter()->values()->all();
            $meta = (array) ($article->meta_data ?? []);
            $meta['takeaways'] = $takeaways;
            $article->meta_data = $meta;
            $article->save();

            $data['image']['model_type'] = "Article";
            $data['image']['model_id'] = $article->id;
            $data['image']['title'] = $article->image?->title ?? $article->title;

            // 3. Appel de la méthode factorisée dans le GenericForm
            DB::afterCommit(function () use ($article, $data ) {
                $this->handleImagePersistence([$data['image']], 'articleUploads');
            });

            session()->flash('success', 'Opération réussie.');
            return $article;
        });
    }
}
