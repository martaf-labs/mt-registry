<?php

namespace Mt\Blog\Livewire\Pages;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\WithPagination;
use Mt\Blog\Livewire\GuestBaseComponent;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\Category;

#[Title('Catégorie')]
class CategoryShow extends GuestBaseComponent
{
    use WithPagination;

    // ── État ────────────────────────────────────────────────────
    public Category $category;

    #[Url(as: 'tri')]
    public string $sort = 'recent';          // recent | popular | oldest

    #[Url(as: 'sous')]
    public ?int $subCategoryId = null;

    #[Url(as: 'q')]
    public string $search = '';              // recherche libre dans la catégorie

    #[Url(as: 'vue')]
    public string $viewMode = 'grid';        // grid | list  (toggle côté vue)

    /**
     * Layout de mise en page.
     * Valeurs : 'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
     * Configuré via config('mtblog.category_layout', 'classic')
     * ou forcé via ?layout=editorial pour les previews.
     */
    // #[Url(as: 'layout', except: 'classic')]
    public string $layout = 'classic';

    // ── Mount ───────────────────────────────────────────────────
    public function mount(string $slug): void
    {
        $this->category = Category::with(['parent', 'children'])
            ->where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();

        // Layout depuis config si non forcé
        // if ($this->layout === 'classic') {
            $this->layout = mtblog_config('category-show.layout');
        // }
    }

    // ── Watchers ────────────────────────────────────────────────

    public function updatedSort(): void          { $this->resetPage(); }
    public function updatedSubCategoryId(): void { $this->resetPage(); }
    public function updatedSearch(): void        { $this->resetPage(); }

    // ── Computed ────────────────────────────────────────────────

    #[Computed]
    public function articles()
    {
        $categoryIds = $this->subCategoryId
            ? [$this->subCategoryId]
            : $this->category->getAllChildrenIds();

        $query = Article::published()
            ->with(['category', 'author'])
            ->whereIn('category_id', $categoryIds);

        // Recherche textuelle
        if ($this->search !== '') {
            $query->where(function ($q) {
                $q->where('title', 'like', '%' . $this->search . '%')
                  ->orWhere('excerpt', 'like', '%' . $this->search . '%');
            });
        }

        $query = match ($this->sort) {
            'popular' => $query->orderBy('views_count', 'desc'),
            'oldest'  => $query->orderBy('published_at', 'asc'),
            default   => $query->orderBy('published_at', 'desc'),
        };

        return $query->paginate(12);
    }

    #[Computed]
    public function subCategories()
    {
        return $this->category->children()
            ->where('is_active', true)
            ->withCount(['articles as articles_count' => fn($q) => $q->published()])
            ->ordered()
            ->get();
    }

    #[Computed]
    public function featuredArticle(): ?Article
    {
        $categoryIds = $this->category->getAllChildrenIds();

        return Article::published()
            ->whereIn('category_id', $categoryIds)
            ->featured()
            ->latest('published_at')
            ->first()
            ?? Article::published()
                ->whereIn('category_id', $categoryIds)
                ->latest('published_at')
                ->first();
    }

    #[Computed]
    public function totalCount(): int
    {
        return Article::published()
            ->whereIn('category_id', $this->category->getAllChildrenIds())
            ->count();
    }

    /**
     * Top articles (les plus vus) pour la sidebar des layouts enrichis.
     */
    #[Computed]
    public function topArticles()
    {
        return Article::published()
            ->whereIn('category_id', $this->category->getAllChildrenIds())
            ->orderBy('views_count', 'desc')
            ->take(5)
            ->get();
    }

    /**
     * Réinitialise tous les filtres.
     */
    public function resetFilters(): void
    {
        $this->sort          = 'recent';
        $this->subCategoryId = null;
        $this->search        = '';
        $this->resetPage();
    }

    // ── Render ──────────────────────────────────────────────────

    public function render()
    {
        return view('mtblog::livewire.pages.category-show.' . $this->layout, [
            'hasChildrens'  => mtblog_option_category_show('childrens'),
            'hasBreadcrumb' => mtblog_option_category_show('breadcrumb'),
            'hasIcon'       => mtblog_option_category_show('icon'),
            'hasMeta'       => mtblog_option_category_show('meta'),
            'hasFilter'     => mtblog_option_category_show('filter'),
            'hasFeaturedArticle' => mtblog_option_category_show('featured'),
            'hasSidebar'    => mtblog_option_category_show('sidebar'),
        ])
        ->title($this->category->name);
    }
}
