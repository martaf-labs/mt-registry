<?php

namespace Mt\Blog\Livewire\Pages;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Mt\Blog\Events\ArticleViewed;
use Mt\Blog\Livewire\GuestBaseComponent;
use Mt\Blog\Models\Article;

#[Title('Article')]
class ArticleShow extends GuestBaseComponent
{

    public $article;
    public $isContentBlocks;

    public function mount($slug, $id = null)
    {
        $this->article = Article::published()
            // ->where('slug', $slug)
            ->where('id', $id)
            ->first();

        $this->isContentBlocks = $this->article?->isContentBlocks;

        // on incremente la vue de l'article: uniquement la première fois que la page est chargée, pas à chaque rechargement
        //egalement, on peut ajouter une session pour éviter d'incrémenter la vue si l'utilisateur a déjà vu l'article
        $hasViewed = session()->get('has_viewed_article_' . $this->article->id, false);

        if ($this->article && !$hasViewed) {
            $this->article->incrementViews();
            session()->put('has_viewed_article_' . $this->article->id, true);
        }

        // Détecter si c'est une vue unique (cookie ou session)
        $sessionKey = 'viewed_article_' . $id;
        $isUnique   = ! session()->has($sessionKey);

        if ($isUnique) {
            session()->put($sessionKey, true);
        }

        event(new ArticleViewed(
            article:  $this->article,
            isUnique: $isUnique,
            context:  [
                'referrer' => request()->headers->get('referer'),
                // 'device'   => $this->detectDevice(),   // 'mobile' | 'tablet' | 'desktop'
            ]
        ));
    }

    #[Computed]
    public function similar_articles()
    {
        $similar_articles = Article::published()
            ->where('category_id', $this->article->category_id)
            ->inRandomOrder()
            ->take(6)
            ->get();

        return $similar_articles;
    }

    #[Computed]
    public function article_comments()
    {
        return !$this->article->allow_comments ? null :
        $this->article->comments();
    }

    #[Computed]
    public function others_articles()
    {
        $others_articles = Article::published()
            ->where('category_id', '!=', $this->article->category_id)
            ->inRandomOrder()
            ->take(12)
            ->get();

        return $others_articles;
    }

    public function render()
    {

        $title = $this->article->title;

        return view('mtblog::livewire.pages.article-show')->title($title);
    }
}
