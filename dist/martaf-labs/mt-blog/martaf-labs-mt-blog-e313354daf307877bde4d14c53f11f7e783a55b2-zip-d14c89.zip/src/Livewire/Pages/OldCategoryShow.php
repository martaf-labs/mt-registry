<?php

namespace Mt\Blog\Livewire\Pages;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\WithPagination;
use Mt\Blog\Livewire\GuestBaseComponent;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\Category;

#[Title('Catégorie')]
class CategoryShow extends GuestBaseComponent
{
    use WithPagination;

    public Category $category;

    #[Url(as: 'tri')]
    public string $sort = 'recent'; // recent | popular | oldest

    #[Url(as: 'sous')]
    public ?int $subCategoryId = null;

    public function mount(string $slug): void
    {
        $this->category = Category::where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();
    }

    /**
     * Réinitialise la pagination quand un filtre change
     */
    public function updatedSort(): void
    {
        $this->resetPage();
    }

    public function updatedSubCategoryId(): void
    {
        $this->resetPage();
    }

    #[Computed]
    public function articles()
    {
        // On récupère les articles de la catégorie ET de ses sous-catégories
        $categoryIds = $this->subCategoryId
            ? [$this->subCategoryId]
            : $this->category->getAllChildrenIds();

        $query = Article::published()
            ->whereIn('category_id', $categoryIds);

        $query = match ($this->sort) {
            'popular' => $query->orderBy('views_count', 'desc'),
            'oldest'  => $query->orderBy('published_at', 'asc'),
            default   => $query->orderBy('published_at', 'desc'),
        };
        
        return $query->paginate(12);
    }

    #[Computed]
    public function subCategories()
    {
        return $this->category->children()->where('is_active', true)->get();
    }

    #[Computed]
    public function featuredArticle()
    {
        $categoryIds = $this->category->getAllChildrenIds();

        return Article::published()
            ->whereIn('category_id', $categoryIds)
            ->featured()
            ->latest('published_at')
            ->first()
            ?? Article::published()
                ->whereIn('category_id', $categoryIds)
                ->latest('published_at')
                ->first();
    }

    #[Computed]
    public function totalCount(): int
    {
        return Article::published()
            ->whereIn('category_id', $this->category->getAllChildrenIds())
            ->count();
    }

    public function render()
    {
        return view('mtblog::livewire.pages.category-show')
            ->title($this->category->name . ' — Bande Info');
    }
}
