<?php

namespace Mt\Blog\Livewire\Indexes;

use Mt\Blog\Models\Category;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class CategoryIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Category::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        $data = Category::find($rowId);

        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [
                'toggle_active' => [
                    'type'   => 'livewire',
                    'icon'   => $data?->is_active ? 'fa-solid fa-xmark' : 'fa-solid fa-check',
                    'label'  => $data?->is_active ? 'Désactiver' : 'Activer',
                    'method' => 'toggleActive',
                    'params' => $rowId,
                ],
            ],
        ];
    }

    public function columns($rowId): array
    {
        $data = Category::find($rowId);

        return [
            'firstColumn' => array_filter([
                'field'       => 'name',
                'label'       => 'Nom',
                'value'       => $data?->name,
                'showLetters' => true,
                'letters'     => $data?->name,
                'metaDatas'   => array_filter([
                    $data?->parentName ? 'Parent : ' . $data->parentName : null,
                    $data?->articlesCount . ' article(s)',
                ]),
            ]),

            'othersColumns' => [
                'order' => [
                    'label' => 'Ordre',
                    'value' => $data?->order,
                ],
                'is_active' => [
                    'label' => 'Active',
                    'value' => $data?->is_active ? 'Oui' : 'Non',
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'categorie',
            'model_plural' => 'categories',
            'mainLabel'    => 'Catégories',
            'title'        => 'Liste des catégories',

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'order',
                'defaultSortDirection' => 'asc',
            ],

            'filters'        => [],
            'sortableFields' => ['name', 'order'],
            'searchableFields' => [
                'direct'    => ['name'],
                'relations' => [],
            ],
        ];
    }
}
