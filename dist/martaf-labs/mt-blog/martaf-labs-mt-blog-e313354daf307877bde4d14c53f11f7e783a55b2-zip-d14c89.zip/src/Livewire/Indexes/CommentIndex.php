<?php

namespace Mt\Blog\Livewire\Indexes;

use Illuminate\Support\Str;
use Mt\Blog\Models\Comment;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class CommentIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Comment::class;
    }

    public function mainActions(): array
    {
        return ['create' => false, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        $data = Comment::find($rowId);

        if (! $data) {
            return ['edit' => false, 'delete' => true, 'custom' => []];
        }

        $custom = [];

        if ($data->status !== 'approved') {
            $custom['approve'] = [
                'type'   => 'livewire',
                'icon'   => 'fa-solid fa-check',
                'label'  => 'Approuver',
                'method' => 'approveComment',
                'params' => $rowId,
            ];
        }

        if ($data->status === 'approved') {
            $custom['unapprove'] = [
                'type'   => 'livewire',
                'icon'   => 'fa-solid fa-eye-slash',
                'label'  => 'Dépublier',
                'method' => 'unapproveComment',
                'params' => $rowId,
            ];
        }

        if ($data->status !== 'spam') {
            $custom['spam'] = [
                'type'   => 'livewire',
                'icon'   => 'fa-solid fa-ban',
                'label'  => 'Marquer comme spam',
                'method' => 'markSpam',
                'params' => $rowId,
            ];
        }

        return [
            'edit'   => false,
            'delete' => true,
            'custom' => $custom,
        ];
    }

    public function columns($rowId): array
    {
        $data = Comment::find($rowId);

        $badgeMap = [
            'approved' => ['type' => 'success', 'label' => 'Approuvé'],
            'pending'  => ['type' => 'info',    'label' => 'En attente'],
            'spam'     => ['type' => 'danger',  'label' => 'Spam'],
        ];
        $status = $data?->status ?? 'pending';

        return [
            'firstColumn' => array_filter([
                'field'       => 'content',
                'label'       => 'Commentaire',
                'value'       => Str::limit(strip_tags($data?->content ?? ''), 90),
                'showLetters' => true,
                'letters'     => $data?->user?->name ?? 'A',
                'metaDatas'   => array_filter([
                    $data?->user?->name ?? 'Anonyme',
                    $data?->article?->title ? Str::limit($data->article->title, 40) : null,
                    $data?->created_at?->diffForHumans(),
                ]),
            ]),
            'othersColumns' => [
                'status' => [
                    'label'      => 'Statut',
                    'value'      => $status,
                    'badgeDatas' => $badgeMap[$status] ?? ['type' => 'secondary', 'label' => $status],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'comment',
            'model_plural' => 'comments',
            'mainLabel'    => 'Commentaires',
            'title'        => 'Modération des commentaires',

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'created_at',
                'defaultSortDirection' => 'desc',
            ],

            'filters'         => [],
            'sortableFields'  => ['created_at'],
            'searchableFields' => [
                'direct'    => ['content'],
                'relations' => [],
            ],
        ];
    }
}
