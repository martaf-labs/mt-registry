<?php

namespace Mt\Blog\Services;

use Mt\Blog\Support\BlockRegistry;

class BlockRenderer
{
    public function __construct(
        protected BlockRegistry $registry
    ) {}

    public function render(array $blocks): string
    {
        return collect($blocks)
            ->map(fn($block) => $this->renderBlock($block))
            ->implode("\n");
    }

    protected function renderBlock(array $block): string
    {
        $view = $this->registry->getView($block['type']);

        if (!$view || !view()->exists($view)) {
            return "<!-- Unknown block {$block['type']} -->";
        }

        return view($view, [
            'data' => $block['data'] ?? [],
            'meta' => $block['meta'] ?? [],
        ])->render();
    }
}
