<?php

namespace Mt\Blog\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Mt\Blog\Events\{ArticleViewed, ArticleLiked, ArticleCommented, ArticleShared};
use Mt\Blog\Models\ArticleStat;

class RecordArticleStat implements ShouldQueue
{
    public string $queue = 'stats';  // queue dédiée, basse priorité

    public function handle(mixed $event): void
    {
        match (true) {
            $event instanceof ArticleViewed    => $this->handleView($event),
            $event instanceof ArticleLiked     => $this->handleLike($event),
            $event instanceof ArticleCommented => $this->handleComment($event),
            $event instanceof ArticleShared    => $this->handleShare($event),
            default => null,
        };
    }

    private function handleView(ArticleViewed $event): void
    {
        $stat = $this->getOrCreate($event->article->id);

        $stat->increment('views');

        if ($event->isUnique) {
            $stat->increment('unique_views');
        }

        // Agrégation des referrers
        if ($referrer = $event->context['referrer'] ?? null) {
            $referrers = $stat->referrers ?? [];
            $key = parse_url($referrer, PHP_URL_HOST) ?? 'direct';
            $referrers[$key] = ($referrers[$key] ?? 0) + 1;
            $stat->update(['referrers' => $referrers]);
        }

        // Agrégation des devices
        if ($device = $event->context['device'] ?? null) {
            $devices = $stat->devices ?? [];
            $devices[$device] = ($devices[$device] ?? 0) + 1;
            $stat->update(['devices' => $devices]);
        }
    }

    private function handleLike(ArticleLiked $event): void
    {
        $stat = $this->getOrCreate($event->article->id);

        $event->action === 'add'
            ? $stat->increment('likes')
            : $stat->decrement('likes');
    }

    private function handleComment(ArticleCommented $event): void
    {
        $stat = $this->getOrCreate($event->article->id);

        $event->action === 'add'
            ? $stat->increment('comments')
            : $stat->decrement('comments');
    }

    private function handleShare(ArticleShared $event): void
    {
        $stat = $this->getOrCreate($event->article->id);
        $stat->increment('shares');
    }

    private function getOrCreate(int $articleId): ArticleStat
    {
        return ArticleStat::firstOrCreate(
            [
                'article_id' => $articleId,
                'date'       => now()->toDateString(),
            ],
            [
                'views'          => 0,
                'unique_views'   => 0,
                'likes'          => 0,
                'comments'       => 0,
                'shares'         => 0,
                'avg_time_on_page' => 0,
                'bounce_rate'    => 0,
                'referrers'      => [],
                'devices'        => [],
                'locations'      => [],
            ]
        );
    }
}