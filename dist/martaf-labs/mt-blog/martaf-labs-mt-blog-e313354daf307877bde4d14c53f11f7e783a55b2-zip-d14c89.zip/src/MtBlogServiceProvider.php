<?php

namespace Mt\Blog;


use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;
use Mt\Blog\Events\ArticleCommented;
use Mt\Blog\Events\ArticleLiked;
use Mt\Blog\Events\ArticleShared;
use Mt\Blog\Events\ArticleViewed;
use Mt\Blog\Listeners\RecordArticleStat;
use Mt\Blog\Support\BlockRegistry;
use Illuminate\Support\Facades\Event;

class MtBlogServiceProvider extends ServiceProvider
{
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        $this->basePath = dirname(__DIR__);
    }

    public function register(): void
    {
        $configPath = $this->basePath . '/config/mtblog.php';

        // Config merge (register uniquement)
        if (file_exists($configPath)) {
            $this->mergeConfigFrom($configPath, 'mtblog');
        }

        //les routs du package
        $this->loadRoutesFrom($this->basePath.'/routes/web.php');
        
        // Enregistrement des blocs par défaut du package (optionnel)
        $this->registerDefaultBlocks();
        $configPath = $this->basePath . '/config/mtblog.php';
        
        if (file_exists($configPath)) {
            $this->mergeConfigFrom($configPath, 'mtblog');
        }

        $this->app->singleton(BlockRegistry::class, function () {
        return new BlockRegistry();
        });
    }

    // --------------------------------------------------------
    // Méthode d’enregistrement des blocs par défaut du package (optionnel)
    // --------------------------------------------------------
    protected function registerDefaultBlocks()
    {
        $registry = app(BlockRegistry::class);
        foreach (config('mtblog.blocks') as $type => $view) {
            $registry->register($type, $view);
        }
    }


    public function boot(): void
    {
        $basePath    = $this->basePath;
        $configPath  = $basePath . '/config/mtblog.php';
        $viewsPath   = $basePath . '/resources/views';
        $publicPath  = $basePath . '/public';

        // Charger les helpers
        $this->loadHelpers();        

        // Publier les vues
        $this->publishes([
            $viewsPath => resource_path('views/vendor/mt/blog'),
        ], 'mtblog');

        // Publier les assets
        $this->publishes([
            $publicPath . '/assets' => public_path('vendor/mt/blog/'),
        ], 'mtblog-assets');

        // Publier la config (le merge est dans register)
        if (file_exists($configPath)) {
            $this->publishes([
                $configPath => config_path('mtblog.php'),
            ], 'mtblog-config');
        }

        // 1. Enregistre le namespace pour @include('mt::...') et les composants de classe
        $this->loadViewsFrom($viewsPath, 'mtblog');

        // 2. Enregistre le namespace pour les composants anonymes <x-mt::... />
        if (is_dir($viewsPath . '/components')) {        
            // On utilise 'mt' au lieu de 'mt-components' pour la cohérence
            Blade::anonymousComponentPath($viewsPath . '/components', 'mtblog');
        }

        // Composants Livewire
        $this->registerLivewireComponents();

        // MorphMap (merge sans enforcer pour ne pas écraser l'app hôte)
        $modelsPath = $basePath . '/src/Models';
        if (is_dir($modelsPath)) {
            $map = [];
            foreach (File::allFiles($modelsPath) as $file) {
                $class = 'Mt\\Blog\\Models\\' . $file->getFilenameWithoutExtension();
                $map[class_basename($class)] = $class;
            }
            Relation::enforceMorphMap($map);
        }

        // Migrations
        if (is_dir($basePath . '/database/migrations')) {
            $this->loadMigrationsFrom($basePath . '/database/migrations');
        }
        
        // --------------------------------------------------------
        // 7️⃣ Enregistrer des directives Blade personnalisées pour les assets de l’éditeur (optionnel)
        // --------------------------------------------------------
        Blade::directive('mtblogEditorAssets', function () {
            return <<<HTML
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@7/css/all.min.css">
        <script defer src="https://unpkg.com/alpinejs" ></script>
        <link rel="stylesheet" href="/vendor/mtblog/editor.css">
        <script defer src="/vendor/mtblog/editor.js"></script>
        HTML;
        });

        
        // --------------------------------------------------------
        // Events pour les modèles
        // --------------------------------------------------------

        Event::listen(ArticleViewed::class,    RecordArticleStat::class);
        Event::listen(ArticleLiked::class,     RecordArticleStat::class);
        Event::listen(ArticleCommented::class, RecordArticleStat::class);
        Event::listen(ArticleShared::class,    RecordArticleStat::class);

        

    }

    protected function registerLivewireComponents(): void
    {
        // Pages
        \Livewire::component('mtblog.pages.article-show', \Mt\Blog\Livewire\Pages\ArticleShow::class);
        \Livewire::component('mtblog.pages.category-show', \Mt\Blog\Livewire\Pages\CategoryShow::class);
        
        // newsletter form
        \Livewire::component('mtblog.forms.newsletter-form', \Mt\Blog\Livewire\Forms\NewsletterForm::class);
        \Livewire::component('mtblog.dashboard', \Mt\Blog\Livewire\Dashboard::class);

        // Modale de connexion rapide (front)
        \Livewire::component('mtblog.quick-auth', \Mt\Blog\Livewire\QuickAuth::class);
        // Modale / inscription newsletter (front)
        \Livewire::component('mtblog.newsletter-modal', \Mt\Blog\Livewire\NewsletterModal::class);

        // Home (page d'accueil pleine page)
        \Livewire::component('mtblog.home', \Mt\Blog\Livewire\Home::class);

        // Admin — Articles
        \Livewire::component('mtblog.admin.articles.index', \Mt\Blog\Livewire\Admin\Articles\ArticleIndexComponent::class);
        \Livewire::component('mtblog.admin.articles.form', \Mt\Blog\Livewire\Admin\Articles\ArticleFormComponent::class);
        \Livewire::component('mtblog.admin.articles.show', \Mt\Blog\Livewire\Admin\Articles\ArticleShowComponent::class);

        // Admin — Users
        \Livewire::component('mtblog.admin.users.index', \Mt\Blog\Livewire\Admin\Users\UserIndexComponent::class);
        \Livewire::component('mtblog.admin.users.form', \Mt\Blog\Livewire\Admin\Users\UsersForm::class);
        \Livewire::component('mtblog.admin.users.profile', \Mt\Blog\Livewire\Admin\Users\UserProfileComponent::class);
        \Livewire::component('mtblog.admin.users.show', \Mt\Blog\Livewire\Admin\Users\UsersShow::class);

        // Admin — Categories
        \Livewire::component('mtblog.admin.categories.index', \Mt\Blog\Livewire\Admin\Categories\CategoryIndexComponent::class);
        \Livewire::component('mtblog.admin.categories.form', \Mt\Blog\Livewire\Admin\Categories\CategoryFormComponent::class);

        // Admin — Comments (modération)
        \Livewire::component('mtblog.admin.comments.index', \Mt\Blog\Livewire\Admin\Comments\CommentIndexComponent::class);
    }

    protected function loadHelpers()
    {
        $helperFile =$this->basePath . '/src/Helpers/helpers.php';
        
        if (file_exists($helperFile)) {
            require_once $helperFile;
        }
    }
}
