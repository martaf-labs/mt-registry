<?php

namespace Mt\Blog\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Mt\Blog\Models\NewsletterSubscriber;

class NewsletterController extends Controller
{
    public function unsubscribe($token)
    {
        $subscriber = NewsletterSubscriber::where('token', $token)->first();

        if ($subscriber) {
            $subscriber->delete(); // Ou $subscriber->update(['is_active' => false]);
            return "Vous avez été désinscrit avec succès.";
        }

        return "Lien invalide ou déjà désinscrit.";
    }
}