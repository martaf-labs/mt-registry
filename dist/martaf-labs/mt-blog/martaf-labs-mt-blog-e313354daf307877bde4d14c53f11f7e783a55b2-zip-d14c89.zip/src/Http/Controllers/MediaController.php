<?php

namespace Mt\Blog\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class MediaController extends Controller
{
    public function upload(Request $request)
    {
        $request->validate([
            'image' => ['required','image','max:5120'] // 5MB
        ]);

        $file = $request->file('image');
        $path = $file->storeAs(
            'mtblog/'.date('Y/m'),
            Str::uuid().'.'.$file->getClientOriginalExtension(),
            'public'
        );



        return response()->json([
            "success" => 1,
            "file" => [
                "url" => Storage::disk('public')->url($path)
            ]
        ]);
    }

    public function fetch(Request $request)
    {
        $request->validate([
            'url' => ['required','url']
        ]);

        $contents = file_get_contents($request->url);
        $name = Str::uuid().'.jpg';

        Storage::disk('public')->put("mtblog/$name", $contents);

        return response()->json([
            "success" => 1,
            "file" => [
                "url" => Storage::disk('public')->url("mtblog/$name")
            ]
        ]);
    }
}
