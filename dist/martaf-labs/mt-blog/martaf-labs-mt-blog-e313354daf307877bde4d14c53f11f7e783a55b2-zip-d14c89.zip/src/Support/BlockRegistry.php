<?php

namespace Mt\Blog\Support;

class BlockRegistry
{
    protected array $blocks = [];

    public function register(string $type, string $view): void
    {
        $this->blocks[$type] = $view;
    }

    public function getView(string $type): ?string
    {
        return $this->blocks[$type] ?? null;
    }

    public function all(): array
    {
        return $this->blocks;
    }
}
