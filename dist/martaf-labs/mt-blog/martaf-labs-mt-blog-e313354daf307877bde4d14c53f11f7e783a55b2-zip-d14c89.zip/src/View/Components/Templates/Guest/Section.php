<?php

namespace Mt\Blog\View\Components\Templates\Guest;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Str;
use Illuminate\View\Component;

class Section extends Component
{
    public string $id;
    public string $title;
    public string $description;
    public ?array $actions;
    public ?string $badge;
    /**
     * Create a new component instance.
     */
    public function __construct($id = '', $title = '', $description = '', $actions = null, $badge = null)
    {
        $this->id = $id;
        $this->title = Str::upper($title);
        $this->description = $description;
        $this->actions = $actions;
        $this->badge = $badge;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('mtblog::components.templates.guest.section');
    }
}
