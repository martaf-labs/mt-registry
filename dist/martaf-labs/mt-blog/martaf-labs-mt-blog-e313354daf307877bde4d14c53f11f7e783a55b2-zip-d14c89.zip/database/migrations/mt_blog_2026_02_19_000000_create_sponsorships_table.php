<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations. 
     */
    public function up(): void
    {
        
        if(!Schema::hasTable('sponsorships')){
            Schema::create('sponsorships', function (Blueprint $table) {
                $table->id();
                $table->string('type')->nullable(); // sponsored, featured, homepage, sticky
                $table->dateTime('start_date')->nullable();
                $table->dateTime('end_date')->nullable();
                $table->decimal('price', 12, 2)->nullable();
                $table->string('contract_reference')->nullable();
                $table->text('description')->nullable();
                $table->boolean('is_active')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->foreignId('article_id')
                    ->constrained()
                    ->cascadeOndelete();

                $table->foreignId('partner_id')
                    ->constrained()
                    ->cascadeOndelete();

                $table->index(['article_id', 'partner_id']);

            });
        }

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sponsorships');
    }
};
