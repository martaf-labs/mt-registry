<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations. 
     */
    public function up(): void
    {
        if(!Schema::hasTable('categories')){
            Schema::create('categories', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('slug')->unique();
                $table->string('icon')->default('fa-solid fa-folder');
                $table->string('color')->default('#3b82f6'); // Couleur de la catégorie
                $table->integer('order')->default(0);
                $table->json('meta_data')->nullable(); // SEO meta
                $table->text('description')->nullable();
                $table->boolean('is_active')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
            Schema::table('categories', function (Blueprint $table) {
                $table->foreignId('parent_id')->nullable()
                    ->constrained('categories')
                    ->cascadeOnDelete();
            });
        }

        if(!Schema::hasTable('article_types')){
            Schema::create('article_types', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('slug')->unique();
                $table->string('label')->nullable();
                $table->string('icon')->default('fa-solid fa-tags');
                $table->string('color')->default('#3b82f6');
                $table->integer('order')->default(0);
                $table->boolean('is_editorial')->default(true);
                $table->boolean('is_sponsored')->default(false);
                $table->integer('usage_count')->default(0);
                $table->text('description')->nullable();
                $table->boolean('is_active')->default(true);

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if(!Schema::hasTable('articles')){
            Schema::create('articles', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->string('slug');
                $table->text('excerpt')->nullable(); // Résumé
                $table->longText('content')->nullable();
                $table->longText('content_original')->nullable(); // Version originale (pour révisions)
                $table->json('content_blocks')->nullable(); // Structure de contenu modulaire
                
                // Médias
                // $table->string('featured_image')->nullable();
                // $table->text('featured_image_legend')->nullable();
                // $table->json('gallery_images')->nullable(); // Galerie d'images
                // $table->string('video_url')->nullable(); // URL vidéo YouTube/Vimeo
                // $table->string('audio_url')->nullable(); // Version audio de l'article
                
                // Relations
                $table->foreignId('category_id')->nullable()->constrained('categories')->onDelete('set null');
                
                $table->foreignId('article_type_id')->nullable()->constrained('article_types')->onDelete('set null');
                
                // Statistiques et métriques
                $table->integer('views_count')->default(0);
                $table->integer('unique_views_count')->default(0); // Vues uniques
                $table->integer('reading_time')->default(0); // Temps de lecture en minutes
                $table->integer('word_count')->default(0);
                
                // Engagement
                $table->integer('likes_count')->default(0);
                $table->integer('comments_count')->default(0);
                $table->integer('shares_count')->default(0);
                $table->integer('bookmarks_count')->default(0);
                
                // Publication
                $table->string('status')->nullable(); //['draft', 'pending', 'published', 'scheduled', 'archived']
                $table->string('visibility')->nullable(); // , ['public', 'private', 'premium']
                $table->timestamp('published_at')->nullable();
                $table->timestamp('scheduled_for')->nullable(); // Publication programmée
                $table->timestamp('featured_until')->nullable(); // Jusqu'à quand l'article est à la une
                
                // SEO
                $table->json('meta_data')->nullable();
                $table->string('canonical_url')->nullable();
                
                // Configuration
                $table->boolean('allow_comments')->default(true);
                $table->boolean('is_featured')->default(false); // Article à la une
                $table->boolean('is_breaking_news')->default(false); // Information en direct
                $table->boolean('is_pinned')->default(false); // Épinglé en haut
                
                // Versioning
                $table->unsignedInteger('version')->default(1);
                
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

            });
        }

        if(!Schema::hasTable('tags')){
            Schema::create('tags', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('slug')->unique();
                $table->integer('usage_count')->default(0);

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if(!Schema::hasTable('article_tag')){
            Schema::create('article_tag', function (Blueprint $table) {
                $table->id();
                $table->foreignId('article_id')->constrained()->onDelete('cascade');
                $table->foreignId('tag_id')->constrained()->onDelete('cascade');
                
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['article_id', 'tag_id']);
            });
        }

        if(!Schema::hasTable('comments')){
            Schema::create('comments', function (Blueprint $table) {
                $table->id();
                $table->text('content');
                
                $table->foreignId('article_id')->constrained()->onDelete('cascade');
                $table->integer('likes_count')->default(0);
                $table->string('status')-> nullable();// ['pending', 'approved', 'spam', 'trash']
                $table->json('meta_data')->nullable(); // IP, user agent, etc.
                
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            
            });
            Schema::table('comments', function (Blueprint $table) {
                $table->foreignId('parent_id')
                    ->nullable()                 // commentaire racine = pas de parent
                    ->constrained('comments')
                    ->cascadeOnDelete();
            });
        }

        if(!Schema::hasTable('likes')){
            Schema::create('likes', function (Blueprint $table) {
                $table->id();                
                $table->morphs('likeable'); // Peut liker articles, commentaires, etc.
                
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                
                $table->unique(['created_by', 'likeable_id', 'likeable_type']);
            });
        }

        if(!Schema::hasTable('newsletters')){
            Schema::create('newsletters', function (Blueprint $table) {
                $table->id(); 
                $table->string('email')->unique();
                $table->string('name')->nullable();
                $table->json('preferences')->nullable(); // Types d'articles souhaités
                $table->string('frequency')->nullable();// ['daily', 'weekly', 'monthly']
                $table->timestamp('subscribed_at')->useCurrent();
                $table->timestamp('unsubscribed_at')->nullable();
                $table->string('token')->unique(); // Token pour désabonnement
                
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                
            });
        }

        if(!Schema::hasTable('article_stats')){
            Schema::create('article_stats', function (Blueprint $table) {
                $table->id(); 
                $table->foreignId('article_id')->constrained()->onDelete('cascade');
                $table->date('date');
                $table->integer('views')->default(0);
                $table->integer('unique_views')->default(0);
                $table->integer('likes')->default(0);
                $table->integer('comments')->default(0);
                $table->integer('shares')->default(0);
                $table->float('avg_time_on_page')->default(0); // Temps moyen de lecture
                $table->float('bounce_rate')->default(0); // Taux de rebond
                $table->json('referrers')->nullable(); // Sources de trafic
                $table->json('devices')->nullable(); // Appareils utilisés
                $table->json('locations')->nullable(); // Localisations géographiques
                
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();              
            });
        }

        if(!Schema::hasTable('notifications')){
            Schema::create('notifications', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->string('type');
                $table->morphs('notifiable');
                $table->text('data');
                $table->timestamp('read_at')->nullable();
                    
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();           
            });
        }

        if(!Schema::hasTable('bookmarks')){
            Schema::create('bookmarks', function (Blueprint $table) {
                $table->id();
                
                $table->foreignId('article_id')->constrained()->onDelete('cascade');
                $table->text('note')->nullable(); // Note personnelle
                $table->json('collection')->nullable(); // Collection de bookmarks
                $table->timestamp('read_later')->nullable(); // À lire plus tard
                $table->boolean('downloaded')->default(false); // Disponible hors ligne
                    
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps(); 
            
                $table->unique(['created_by', 'article_id']);
                           
            });
        }

        if(!Schema::hasTable('contributors')){
            Schema::create('contributors', function (Blueprint $table) {
                $table->id();
                $table->foreignId('article_id')->constrained()->onDelete('cascade');
                
                $table->string('role')->nullable();//['author', 'coauthor', 'editor', 'photographer', 'illustrator']
                $table->integer('order')->default(0); // Ordre d'affichage
                    
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps(); 
                
                $table->unique(['article_id', 'created_by', 'role']);
                           
            });
        }

        if(!Schema::hasTable('article_revisions')){
            Schema::create('article_revisions', function (Blueprint $table) {
                $table->id();
                $table->foreignId('article_id')->constrained()->onDelete('cascade');
                
                $table->string('title');
                $table->text('excerpt')->nullable();
                $table->longText('content');
                $table->json('changes')->nullable(); // Diff des changements
                $table->string('summary')->nullable(); // Résumé des modifications
                $table->unsignedInteger('version');
                    
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps(); 
                                           
            });
        }

        if(!Schema::hasTable('advertisements')){
            Schema::create('advertisements', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('type'); // banner, video, native, etc.
                $table->string('position'); // header, sidebar, in-content, etc.
                $table->text('code')->nullable(); // Code HTML/JS
                $table->string('image_url')->nullable();
                $table->string('link_url')->nullable();
                $table->json('targeting_rules')->nullable(); // Règles de ciblage
                $table->integer('impressions_limit')->nullable(); // Limite d'impressions
                $table->integer('clicks_limit')->nullable();
                $table->integer('impressions_count')->default(0);
                $table->integer('clicks_count')->default(0);
                $table->dateTime('start_date');
                $table->dateTime('end_date')->nullable();
                $table->boolean('is_active')->default(true);
                $table->integer('priority')->default(0); // Priorité d'affichage
                    
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps(); 
                           
            });   
        }

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('advertisements');
        Schema::dropIfExists('article_revisions');
        Schema::dropIfExists('contributors');
        Schema::dropIfExists('bookmarks');
        Schema::dropIfExists('notifications');
        Schema::dropIfExists('article_stats');
        Schema::dropIfExists('newsletters');
        Schema::dropIfExists('likes');
        Schema::dropIfExists('comments');
        Schema::dropIfExists('article_tag');
        Schema::dropIfExists('tags');
        Schema::dropIfExists('article_types');
        Schema::dropIfExists('articles');
        Schema::dropIfExists('categories');
    }
};
