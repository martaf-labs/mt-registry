<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations. 
     */
    public function up(): void
    {
        
        if(!Schema::hasTable('partners')){
            Schema::create('partners', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('slug')->unique();
                $table->string('logo')->nullanle(); // Logo du partenaire
                $table->string('icon')->default('fa-solid fa-tags'); 
                $table->string('color')->default('#3b82f6'); 
                $table->string('website')->nullable();
                $table->string('email')->nullable();
                $table->text('description')->nullable();
                $table->boolean('is_active')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('partners');
    }
};
