<?php
// database/factories/ArticleFactory.php

namespace Mt\MtBlog\Database\Factories;

use App\Models\Article;
use App\Models\User;
use App\Models\Category;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class ArticleFactory extends Factory
{
    protected $model = Article::class;

    public function definition(): array
    {
        $title = $this->faker->sentence();
        $content = $this->generateRichContent();
        
        return [
            'title' => $title,
            'slug' => Str::slug($title),
            'excerpt' => $this->faker->paragraph(3),
            'content' => $content,
            'user_id' => User::factory(),
            'category_id' => Category::factory(),
            'views_count' => $this->faker->numberBetween(0, 10000),
            'likes_count' => $this->faker->numberBetween(0, 500),
            'comments_count' => $this->faker->numberBetween(0, 100),
            'status' => $this->faker->randomElement(['draft', 'published', 'archived']),
            'visibility' => $this->faker->randomElement(['public', 'private', 'premium']),
            'published_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
            'is_featured' => $this->faker->boolean(20),
            'is_breaking_news' => $this->faker->boolean(5),
            'reading_time' => $this->faker->numberBetween(3, 15),
            'word_count' => $this->faker->numberBetween(300, 3000),
        ];
    }

    public function published(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'published',
                'published_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
            ];
        });
    }

    public function draft(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'draft',
                'published_at' => null,
            ];
        });
    }

    public function featured(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'is_featured' => true,
                'featured_until' => $this->faker->dateTimeBetween('now', '+1 month'),
            ];
        });
    }

    private function generateRichContent(): string
    {
        $paragraphs = [];
        
        for ($i = 0; $i < rand(5, 10); $i++) {
            $paragraphs[] = '<p>' . $this->faker->paragraph(rand(5, 15)) . '</p>';
            
            // Ajouter parfois une image
            if (rand(0, 3) === 0) {
                $paragraphs[] = '<figure><img src="https://picsum.photos/800/400?random=' . rand(1, 1000) . '" alt="Image"><figcaption>' . $this->faker->sentence() . '</figcaption></figure>';
            }
            
            // Ajouter parfois un titre
            if (rand(0, 4) === 0) {
                $paragraphs[] = '<h2>' . $this->faker->sentence() . '</h2>';
            }
            
            // Ajouter parfois une citation
            if (rand(0, 5) === 0) {
                $paragraphs[] = '<blockquote>' . $this->faker->paragraph(2) . '</blockquote>';
            }
        }
        
        return implode("\n\n", $paragraphs);
    }
}