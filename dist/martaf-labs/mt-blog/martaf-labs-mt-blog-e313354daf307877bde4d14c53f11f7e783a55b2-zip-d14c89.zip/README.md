# mt/blog

**Bibliothèque partagée contenant les modèles, traits et composants métiers communs aux sites et applications de type "blog" développés avec Laravel.**

---

## Informations générales

- **Nom du package** : `mt/blog`
- **Auteur** : Djoukeng Brice Marcello
- **Début du développement** : 19/02/2026
- **Version actuelle** : `dev-main`
- **Licence** : MIT (ou interne selon vos besoins)

---

## Description

Ce package centralise tous les éléments communs utilisés par plusieurs projets de type, afin de :

- Éviter la duplication de code
- Garantir la cohérence des modèles et traits métiers
- Faciliter la maintenance et les mises à jour

Il contient principalement :

- Models Laravel partagés
- Traits réutilisables
- Helpers et fonctions utilitaires
- Enums et constantes
- Services métier réutilisables
- Migrations partagés


---

## Structure du package

src/
├── Models/ # Tous les modèles partagés
├── database/ # Tous les modèles partagés
└── MtBlogServiceProvider.php # Service Provider pour Laravel


---

## Installation

### 1️⃣ Ajouter le repository Git

Dans le `composer.json` de votre projet Laravel :

```
"repositories": [
  {
    "type": "vcs",
    "url": "git@github.com:mt/blog.git"
  }
]
```
Pour utiliser la version de développement dev-main :
composer require mt/blog:dev-main


Développement


Créez vos Models, Traits ou Services dans src/

Testez les changements dans vos projets Laravel

Commit et push

Pour une future version stable, utilisez les tags Git pour versionner proprement :

git tag 1.0.0
git push origin main --tags



