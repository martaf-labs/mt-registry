@props([
    'article'=> null,
    'url'=> null,
    ])


@if ($article)

@php
    $url = $url ?? mt_get_route('home_articles_show', ['slug' => $article?->slug, 'id' => $article?->id]);
@endphp

<article {{ $attributes->merge(['class' => 'flex flex-col items-start group bg-white dark:bg-[#111C2E] rounded-2xl overflow-hidden border border-gray-100 dark:border-white/6 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300']) }}>
    {{-- Image Section --}}
    <a href="{{ $url }}" wire:navigate class="relative block overflow-hidden bg-gray-100 w-100 h-44 dark:bg-white/4">
        @if ($article->hasFeaturedImage)
            <img src="{{ $article->imageUrl }}" alt="{{ $article->title }}"
                 class="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105" loading="lazy">
        @else
            <div class="flex items-center justify-center w-full h-full">
                <i class="text-3xl text-gray-300 fa-regular fa-image dark:text-white/10"></i>
            </div>
        @endif

        <span class="absolute top-3 left-3 bg-[#BE1622] text-white text-xs font-medium px-2.5 py-1 rounded-full">
            {{ $article->categoryName }}
        </span>
    </a>

    {{-- Content Section --}}
    <div class="flex flex-col flex-1 p-5 items-between">
        <div class="flex-1">
            <div class="flex items-center gap-2 mb-2 text-xs text-gray-400 dark:text-white/30">
                <span>{{ $article->publishedThere }}</span>
                <span>•</span>
                <span>{{ $article->reading_time }} min</span>
            </div>

            <h3 class="font-bold text-gray-900 dark:text-white text-[15px] leading-snug mb-2 line-clamp-2 group-hover:text-[#BE1622] dark:group-hover:text-[#BE1622] transition-colors">
                <a href="{{ $url }}" wire:navigate>
                    {{ $article->title }}
                </a>
            </h3>
            <p class="mb-4 text-sm text-gray-500 dark:text-white/40 line-clamp-2">
                {{ $article->excerpt }}
            </p>
        </div>


        <div class="">
            <a href="{{ $url }}" wire:navigate
           class="inline-flex items-center gap-1.5 text-sm font-semibold text-[#BE1622] group-hover:gap-2.5 transition-all duration-200">
                Lire l'article <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>
    </div>
</article>
@endif
