{{--
  Partial : _auth-buttons.blade.php
  Boutons auth (connexion / abonnement) ou avatar user connecté.
  Props :
    $theme    'light' | 'dark'  (défaut: 'light')
    $compact  bool              (défaut: false → labels visibles)
--}}
@if (mtblog_option_header(('auth')))
@props([
    'theme'   => 'light',
    'compact' => false,
])

@php
    $theme = mt_has_dark_mode()? $theme : 'light';
    $compact = mtblog_option_header('compact');
    $isDark   = mt_has_dark_mode() ? $theme === 'dark' : false;
    $loginCls = $isDark
        ? 'border-white/20 text-white/70 hover:bg-white/10 hover:text-white hover:border-white/40'
        : 'border-gray-200 dark:border-white/10 text-gray-600 dark:text-white/50 hover:bg-gray-100 dark:hover:bg-white/6';
@endphp

@auth

{{-- Avatar utilisateur connecté --}}
<div class="relative" x-data="{ open: false }" @click.outside="open = false">
    <button @click="open = !open"
            class="flex items-center gap-2 p-1 rounded-xl transition-all
                   {{ $isDark ? 'hover:bg-white/10' : 'hover:bg-gray-100 dark:hover:bg-white/6' }}">
        <div class="w-8 h-8 rounded-lg
                     bg-gradient-to-br from-[rgb(var(--mt-secondary))] to-[rgb(var(--mt-primary))]
                     flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
            {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
        </div>
        @if (!$compact)
        <span class="hidden xl:block text-sm font-medium truncate max-w-[100px]
                      {{ $isDark ? 'text-white/70' : 'text-gray-700 dark:text-white/70' }}">
            {{ auth()->user()->name }}
        </span>
        <i class="hidden xl:block fa-solid fa-chevron-down text-[9px] opacity-40 transition-transform"
           :class="open ? 'rotate-180' : ''"></i>
        @endif
    </button>

    {{-- Dropdown user --}}
    <div x-show="open"
         x-transition:enter="transition ease-out duration-150"
         x-transition:enter-start="opacity-0 scale-95 translate-y-1"
         x-transition:enter-end="opacity-100 scale-100 translate-y-0"
         x-transition:leave="transition ease-in duration-100"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="absolute right-0 top-full mt-2 z-50 w-52
                bg-white dark:bg-gray-900
                border border-gray-100 dark:border-white/8
                rounded-2xl shadow-xl overflow-hidden py-1"
         style="display:none">

        <div class="px-4 py-3 border-b border-gray-100 dark:border-white/6">
            <p class="text-sm font-semibold text-gray-900 dark:text-white truncate">{{ auth()->user()->name }}</p>
            <p class="text-xs text-gray-400 dark:text-white/30 truncate">{{ auth()->user()->email }}</p>
        </div>

        {{-- @if (auth()->user()->isAdmin() || auth()->user()->isEditor()) --}}
        <a href="{{ route('dashboard') ?? '#' }}" wire:navigate
           class="flex items-center gap-2.5 px-4 py-2.5 text-sm text-gray-700 dark:text-white/60
                  hover:bg-gray-50 dark:hover:bg-white/4 hover:text-[rgb(var(--mt-secondary))] transition-colors">
            <i class="fa-solid fa-gauge text-xs w-4 text-center"></i>
            Tableau de bord
        </a>
        {{-- @endif --}}

         @if (mtblog_option_header(('bookmarks')))
        <a href="#" wire:navigate
           class="flex items-center gap-2.5 px-4 py-2.5 text-sm text-gray-700 dark:text-white/60
                  hover:bg-gray-50 dark:hover:bg-white/4 hover:text-[rgb(var(--mt-secondary))] transition-colors">
            <i class="fa-regular fa-bookmark text-xs w-4 text-center"></i>
            Mes favoris
        </a>
        @endif

        <div class="border-t border-gray-100 dark:border-white/6 mt-1 pt-1">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit"
                        class="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-500
                               hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors">
                    <i class="fa-solid fa-arrow-right-from-bracket text-xs w-4 text-center"></i>
                    Déconnexion
                </button>
            </form>
        </div>
    </div>
</div>

@else
{{-- Boutons connexion / abonnement --}}
<div class="flex items-center gap-2">
    <a href="{{ route('login') }}" wire:navigate
       class="flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-xl
              border transition-all duration-200 {{ $loginCls }}">
        @if (!$compact) <x-mt::icon name="user" /> @endif
        <span class="{{ $compact ? 'hidden' : '' }}">Connexion</span>
        @if ($compact) <x-mt::icon name="user" /> @endif
    </a>

    @if (mtblog_option_header(('suscribe')))
    <a href="{{ route('register') ?? '#' }}" wire:navigate
       class="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold rounded-xl
              bg-[rgb(var(--mt-secondary))] text-white
              hover:opacity-90 hover:scale-105 transition-all duration-200 shadow-sm">
        @if (!$compact)
        <x-mt::icon name="bolt" />
        S'abonner
        @else
        <x-mt::icon name="bolt" />
        @endif
    </a>
    @endif
</div>

@endauth


@endif