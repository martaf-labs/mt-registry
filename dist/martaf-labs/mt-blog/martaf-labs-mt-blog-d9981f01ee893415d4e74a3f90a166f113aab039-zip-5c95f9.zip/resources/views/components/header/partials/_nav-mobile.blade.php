{{--
  Partial : _nav-mobile.blade.php
  Drawer mobile complet (logo, menu, auth, liens).
  Contrôlé par Alpine `mobileOpen` dans le composant parent.
  Données : $menuItems, mtblog_is_home()
--}}
@php
    $showIcons = mtblog_option_header('menu_icons');
@endphp

{{-- Overlay --}}
<div x-show="mobileOpen"
     @click="mobileOpen = false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     class="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
     style="display:none">
</div>

{{-- Drawer --}}
<div x-show="mobileOpen"
     x-transition:enter="transition ease-out duration-300"
     x-transition:enter-start="opacity-0 -translate-x-full"
     x-transition:enter-end="opacity-100 translate-x-0"
     x-transition:leave="transition ease-in duration-200"
     x-transition:leave-start="opacity-100 translate-x-0"
     x-transition:leave-end="opacity-0 -translate-x-full"
     class="fixed top-0 left-0 bottom-0 z-50 w-80 max-w-[90vw]
            bg-white dark:bg-gray-950
            flex flex-col shadow-2xl lg:hidden overflow-hidden"
     style="display:none">

    {{-- En-tête drawer --}}
    <div class="flex items-center justify-between px-5 py-4
                 border-b border-gray-100 dark:border-white/6 flex-shrink-0">
        <a href="{{ mt_get_route('home') }}" wire:navigate @click="mobileOpen = false"
           class="flex items-center">
            <img src="{{ asset('logo.png') }}" alt="Logo"
                 class="h-7 w-auto object-contain dark:brightness-0 dark:invert">
        </a>
        <button @click="mobileOpen = false"
                class="w-8 h-8 flex items-center justify-center rounded-xl
                       bg-gray-100 dark:bg-white/6 text-gray-500 dark:text-white/50
                       hover:bg-gray-200 dark:hover:bg-white/10 transition-colors">
            <i class="fa-solid fa-xmark text-sm"></i>
        </button>
    </div>

    {{-- Corps drawer (scrollable) --}}
    <div class="flex-1 overflow-y-auto">

        @if (mt_has_search())
        {{-- Recherche mobile --}}
        <div class="px-4 py-3 border-b border-gray-100 dark:border-white/6">
            <div class="relative">
                <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2
                           text-gray-400 dark:text-white/25 text-xs pointer-events-none"></i>
                <input
                    type="text"
                    placeholder="Rechercher un article…"
                    @keydown.enter="window.location.href = '{{ mt_get_route('home') }}?q=' + $el.value"
                    class="w-full pl-8 pr-4 py-2.5 text-sm rounded-xl
                           border border-gray-200 dark:border-white/8
                           bg-gray-50 dark:bg-white/4
                           text-gray-800 dark:text-white
                           placeholder-gray-400 dark:placeholder-white/25
                           focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/20"
                />
            </div>
        </div>
        
        @endif

        {{-- Menu --}}
        <div class="px-3 py-3">
            <a href="{{ mt_get_route('home') }}" wire:navigate @click="mobileOpen = false"
               class="flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors
                      {{ mtblog_is_home()
                          ? 'text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/8'
                          : 'text-gray-700 dark:text-white/70 hover:bg-gray-50 dark:hover:bg-white/4' }}">
                @if($showIcons)<i class="fa-solid fa-house text-sm w-5 text-center"></i>@endif
                Accueil
            </a>

            @foreach ($menuItems as $key => $item)

            @if (!empty($item['subItems']))

            {{-- Accordéon --}}
            <div x-data="{ open: {{ $item['is_active'] ? 'true' : 'false' }} }">
                <button @click="open = !open"
                        class="w-full flex items-center justify-between gap-3 px-4 py-3
                               text-sm font-medium rounded-xl transition-colors
                               {{ $item['is_active']
                                   ? 'text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/8'
                                   : 'text-gray-700 dark:text-white/70 hover:bg-gray-50 dark:hover:bg-white/4' }}">
                    <span class="flex items-center gap-3">
                        @if ($showIcons && $item['icon'])
                        <i class="{{ $item['icon'] }} text-sm w-5 text-center opacity-70"></i>
                        @endif
                        {{ $item['label'] }}
                    </span>
                    <i class="fa-solid fa-chevron-down text-[10px] opacity-40 transition-transform duration-200"
                       :class="open ? 'rotate-180' : ''"></i>
                </button>

                <div x-show="open" x-transition class="pl-5 pb-1" style="display:none">
                    <div class="border-l-2 border-gray-100 dark:border-white/6 pl-3 space-y-0.5">
                        @foreach ($item['subItems'] as $child)
                        <a href="{{ $child['url'] ?? '#' }}" wire:navigate @click="mobileOpen = false"
                           class="flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-sm
                                  text-gray-600 dark:text-white/50
                                  hover:text-[rgb(var(--mt-secondary))] hover:bg-gray-50 dark:hover:bg-white/4
                                  transition-colors group/mc">
                            <span class="flex items-center gap-2.5">
                                @if ($showIcons && !empty($child['icon']))
                                <i class="{{ $child['icon'] }} text-xs opacity-60 group-hover/mc:opacity-100 transition-opacity"></i>
                                @endif
                                {{ $child['label'] }}
                            </span>
                            @if (!empty($child['count']) && $child['count'] > 0)
                            <span class="text-[10px] font-bold px-1.5 py-0.5 rounded-full
                                          bg-[rgb(var(--mt-secondary))]/10 text-[rgb(var(--mt-secondary))]">
                                {{ $child['count'] }}
                            </span>
                            @endif
                        </a>
                        @endforeach
                    </div>
                </div>
            </div>

            @else

            {{-- Item simple --}}
            <a href="{{ $item['url'] ?? '#' }}" wire:navigate @click="mobileOpen = false"
               class="flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors
                      {{ $item['is_active']
                          ? 'text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/8'
                          : 'text-gray-700 dark:text-white/70 hover:bg-gray-50 dark:hover:bg-white/4' }}">
                @if ($showIcons && $item['icon'])
                <i class="{{ $item['icon'] }} text-sm w-5 text-center opacity-70"></i>
                @endif
                {{ $item['label'] }}
            </a>

            @endif
            @endforeach
        </div>

        {{-- Séparateur --}}
        <div class="h-px bg-gray-100 dark:bg-white/5 mx-4"></div>

        {{-- Liens rapides --}}
        {{-- <div class="px-3 py-3 space-y-0.5">
            <a href="#" wire:navigate @click="mobileOpen = false"
               class="flex items-center gap-3 px-4 py-3 text-sm text-gray-600 dark:text-white/50
                      hover:text-[rgb(var(--mt-secondary))] hover:bg-gray-50 dark:hover:bg-white/4 rounded-xl transition-colors">
                <i class="fa-solid fa-circle-play w-5 text-center"></i> Vidéos
            </a>
            <a href="#" wire:navigate @click="mobileOpen = false"
               class="flex items-center gap-3 px-4 py-3 text-sm text-gray-600 dark:text-white/50
                      hover:text-[rgb(var(--mt-secondary))] hover:bg-gray-50 dark:hover:bg-white/4 rounded-xl transition-colors">
                <i class="fa-solid fa-image w-5 text-center"></i> Photos
            </a>
        </div> --}}

    </div>

    @if(mtblog_option_header('auth'))
    {{-- Pied drawer : auth ─────────────────────────────────────── --}}
    <div class="flex-shrink-0 border-t border-gray-100 dark:border-white/6 p-4">
        @auth
        <div class="flex items-center gap-3 mb-3 p-3 bg-gray-50 dark:bg-white/4 rounded-2xl">
            <div class="w-10 h-10 rounded-xl
                         bg-gradient-to-br from-[rgb(var(--mt-secondary))] to-[rgb(var(--mt-primary))]
                         flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
            </div>
            <div class="min-w-0">
                <p class="text-sm font-semibold text-gray-900 dark:text-white truncate">{{ auth()->user()->name }}</p>
                <p class="text-xs text-gray-500 dark:text-white/40 truncate">{{ auth()->user()->email }}</p>
            </div>
        </div>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit"
                    class="w-full flex items-center justify-center gap-2 py-2.5 text-sm text-red-500
                           hover:bg-red-50 dark:hover:bg-red-500/10 rounded-xl transition-all">
                <i class="fa-solid fa-arrow-right-from-bracket text-xs"></i>
                Déconnexion
            </button>
        </form>
        @else
            
        <div class="grid grid-cols-2 gap-2">
            <a href="{{ route('login') }}"
               class="flex items-center justify-center gap-2 py-2.5 text-sm font-medium
                      border border-gray-200 dark:border-white/10 rounded-xl
                      text-gray-700 dark:text-white/70
                      hover:bg-gray-50 dark:hover:bg-white/4 transition-all">
                <i class="fa-regular fa-user text-xs"></i>
                Connexion
            </a>
            @if(mtblog_option_header('suscribe'))
            <a href="{{ route('register') ?? '#' }}"
               class="flex items-center justify-center gap-2 py-2.5 text-sm font-semibold
                      bg-[rgb(var(--mt-secondary))] text-white rounded-xl
                      hover:opacity-90 transition-opacity">
                S'abonner
            </a>
            @endif
        </div>
        @endauth
    </div>
    @endif

</div>
