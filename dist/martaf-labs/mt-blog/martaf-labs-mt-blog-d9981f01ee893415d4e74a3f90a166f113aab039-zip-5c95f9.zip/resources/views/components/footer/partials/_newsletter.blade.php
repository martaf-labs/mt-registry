{{--
  Partial : _newsletter.blade.php
  Bloc d'abonnement à la newsletter.
  Props :
    $theme    'dark' | 'light'  (défaut: 'dark')
    $compact  bool              (défaut: false)
--}}

@props([
    'theme'   => 'dark',
    'compact' => false,
])

@php
    $isDark = $theme === 'dark';
@endphp

<div x-data="{
    email: '',
    loading: false,
    success: false,
    error: '',
    async submit() {
        if (!this.email || !this.email.includes('@')) {
            this.error = 'Adresse email invalide.';
            return;
        }
        this.loading = true;
        this.error   = '';
        try {
            await $wire.subscribeNewsletter(this.email);
            this.success = true;
            this.email   = '';
        } catch(e) {
            this.error = 'Une erreur est survenue. Réessayez.';
        } finally {
            this.loading = false;
        }
    }
}">

    @if (!$compact)
    {{-- Version complète --}}
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div class="max-w-sm">
            <div class="flex items-center gap-2 mb-2">
                <i class="fa-solid fa-envelope-open-text text-[rgb(var(--mt-secondary))] text-sm"></i>
                <h4 class="font-bold text-sm uppercase tracking-wider
                            {{ $isDark ? 'text-white' : 'text-gray-900 dark:text-white' }}">
                    Newsletter
                </h4>
            </div>
            <p class="text-sm {{ $isDark ? 'text-white/50' : 'text-gray-500 dark:text-white/40' }}">
                Recevez les dernières actualités directement dans votre boîte mail.
            </p>
        </div>

        <div class="w-full sm:w-auto">
            <template x-if="success">
                <div class="flex items-center gap-2 px-4 py-3 rounded-xl
                             bg-green-500/15 text-green-400 text-sm font-medium">
                    <i class="fa-solid fa-circle-check"></i>
                    Merci ! Votre inscription est confirmée.
                </div>
            </template>

            <template x-if="!success">
                <div class="flex gap-2">
                    <div class="relative flex-1 sm:w-64">
                        <i class="fa-solid fa-envelope absolute left-3 top-1/2 -translate-y-1/2
                                   text-xs pointer-events-none
                                   {{ $isDark ? 'text-white/30' : 'text-gray-400 dark:text-white/30' }}">
                        </i>
                        <input
                            x-model="email"
                            @keydown.enter="submit()"
                            type="email"
                            placeholder="votre@email.com"
                            class="w-full pl-8 pr-3 py-2.5 text-sm rounded-xl border
                                   focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/25
                                   transition-all
                                   {{ $isDark
                                       ? 'bg-white/8 border-white/10 text-white placeholder-white/30 focus:border-[rgb(var(--mt-secondary))]/40'
                                       : 'bg-white dark:bg-white/6 border-gray-200 dark:border-white/10 text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-white/30 focus:border-[rgb(var(--mt-secondary))]/50' }}"
                        />
                    </div>
                    <button
                        @click="submit()"
                        :disabled="loading"
                        class="flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold text-white
                               bg-[rgb(var(--mt-secondary))] rounded-xl
                               hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed
                               transition-all flex-shrink-0">
                        <i class="fa-solid fa-paper-plane text-xs" x-show="!loading"></i>
                        <i class="fa-solid fa-spinner fa-spin text-xs" x-show="loading" style="display:none"></i>
                        <span class="hidden sm:inline">S'abonner</span>
                    </button>
                </div>
            </template>

            <p x-text="error" x-show="error" class="mt-1.5 text-xs text-red-400" style="display:none"></p>
        </div>
    </div>

    @else
    {{-- Version compacte (colonne) --}}
    <h4 class="font-bold text-sm mb-3
                {{ $isDark ? 'text-white' : 'text-gray-900 dark:text-white' }}">
        <i class="fa-solid fa-envelope-open-text text-[rgb(var(--mt-secondary))] mr-2"></i>
        Newsletter
    </h4>
    <p class="text-xs mb-4 {{ $isDark ? 'text-white/45' : 'text-gray-500 dark:text-white/40' }}">
        L'actualité dans votre boîte mail, sans spam.
    </p>

    <template x-if="success">
        <div class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-green-500/15 text-green-400 text-xs font-medium">
            <i class="fa-solid fa-circle-check"></i> Inscription confirmée !
        </div>
    </template>

    <template x-if="!success">
        <div class="flex flex-col gap-2">
            <input
                x-model="email"
                @keydown.enter="submit()"
                type="email"
                placeholder="votre@email.com"
                class="w-full px-3 py-2.5 text-sm rounded-xl border
                       focus:outline-none focus:ring-2 focus:ring-[rgb(var(--mt-secondary))]/25
                       transition-all
                       {{ $isDark
                           ? 'bg-white/8 border-white/10 text-white placeholder-white/30'
                           : 'bg-white dark:bg-white/6 border-gray-200 dark:border-white/10 text-gray-800 dark:text-white placeholder-gray-400' }}"
            />
            <button
                @click="submit()"
                :disabled="loading"
                class="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-semibold text-white
                       bg-[rgb(var(--mt-secondary))] rounded-xl
                       hover:opacity-90 disabled:opacity-50 transition-all">
                <i class="fa-solid fa-paper-plane text-xs" x-show="!loading"></i>
                <i class="fa-solid fa-spinner fa-spin text-xs" x-show="loading" style="display:none"></i>
                S'abonner gratuitement
            </button>
            <p x-text="error" x-show="error" class="text-xs text-red-400" style="display:none"></p>
        </div>
    </template>

    @endif

</div>
