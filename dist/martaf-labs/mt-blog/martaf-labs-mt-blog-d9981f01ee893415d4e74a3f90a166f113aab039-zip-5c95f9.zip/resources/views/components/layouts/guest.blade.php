{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : guest.blade.php                                        ║
║  Package : mt (base blog)                                        ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure :                                                     ║
║    → <head> : meta SEO, OG, styles, dark mode init               ║
║    → Header (variant configurable depuis config/env)             ║
║    → <main> : slot contenu                                       ║
║    → Footer                                                      ║
║    → Scripts globaux (Alpine, Livewire, toasts, lazy img)        ║
╚══════════════════════════════════════════════════════════════════╝
--}}

   <x-mt::layouts.guest>

    {{-- ══ Styles globaux package ══════════════════════════════════ --}}
    <style>

        /* ── Scrollbar fine ──────────────────────────────────── */
        ::-webkit-scrollbar       { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb {
            background: rgb(var(--mt-secondary, 99 102 241) / .35);
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: rgb(var(--mt-secondary, 99 102 241) / .65);
        }

        /* ── Sélection ────────────────────────────────────────── */
        ::selection {
            background: rgb(var(--mt-secondary, 99 102 241) / .18);
        }

        /* ── Focus visible accessible ─────────────────────────── */
        :focus-visible {
            outline: 2px solid rgb(var(--mt-secondary, 99 102 241));
            outline-offset: 2px;
            border-radius: 4px;
        }

        /* ── Barre de progression lecture ────────────────────── */
        #reading-progress {
            transition: width 80ms linear;
            will-change: width;
        }

        /* ── Prose (article body) ────────────────────────────── */
        .prose p            { margin-top: 1.25rem !important; margin-bottom: 1.25rem !important; }
        .prose img          { width: 100% !important; height: auto !important; }
        .prose h2, .prose h3 { scroll-margin-top: 7rem; }

        /* ── TOC sticky ──────────────────────────────────────── */
        .mt-toc-sticky {
            position: sticky;
            top: 104px;
            max-height: calc(100vh - 120px);
            overflow-y: auto;
        }

        /* ── Skeleton ────────────────────────────────────────── */
        @keyframes mt-skeleton {
            0%   { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
        .mt-skeleton {
            background: linear-gradient(
                90deg,
                rgb(var(--mt-bg) / 1) 25%,
                rgba(0,0,0,.06)       50%,
                rgb(var(--mt-bg) / 1) 75%
            );
            background-size: 200% 100%;
            animation: mt-skeleton 1.4s ease-in-out infinite;
        }

        /* ── Animations ──────────────────────────────────────── */
        @keyframes mt-fade-in {
            from { opacity: 0; transform: translateY(12px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes mt-slide-down {
            from { opacity: 0; transform: translateY(-6px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes mt-marquee {
            0%   { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }

        .animate-mt-fade-in    { animation: mt-fade-in 0.55s ease-out forwards; }
        .animate-mt-slide-down { animation: mt-slide-down 0.2s ease-out forwards; }
        .animate-mt-marquee    { animation: mt-marquee 32s linear infinite; }

        /* ── Hover lift ──────────────────────────────────────── */
        .mt-hover-lift {
            transition: transform 0.28s cubic-bezier(.34,1.56,.64,1),
                        box-shadow 0.28s ease;
        }
        .mt-hover-lift:hover {
            transform: translateY(-5px);
            box-shadow: 0 14px 36px -10px rgb(var(--mt-secondary, 99 102 241) / .22);
        }

        /* ── Glass ───────────────────────────────────────────── */
        .mt-glass {
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            background: rgba(255, 255, 255, .08);
            border: 1px solid rgba(255, 255, 255, .14);
        }
        .mt-glass-dark {
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            background: rgba(8, 16, 36, .75);
            border: 1px solid rgba(255, 255, 255, .07);
        }

        /* ── Dégradé drapeau (personnalisable par projet) ──────── */
        .mt-gradient-flag {
            background: linear-gradient(
                90deg,
                rgb(var(--mt-flag-1, 30 28 70))   33%,
                rgb(var(--mt-flag-2, 190 22  34))  33% 66%,
                rgb(var(--mt-flag-3, 255 215  0))  66%
            );
        }

        /* ── Print ───────────────────────────────────────────── */
        @media print {
            header, footer, aside, nav,
            .no-print { display: none !important; }
            main       { max-width: 100% !important; padding: 0 !important; }
            body       { font-size: 12pt; color: #000 !important; background: #fff !important; }
            a          { color: inherit !important; text-decoration: none !important; }
            .prose img { max-width: 100%; height: auto; }
        }
    </style>
</head>

{{-- ── body ──────────────────────────────────────────────────── --}}
<body class="mt-bg mt-text antialiased min-h-screen flex flex-col">

    {{-- Skip to content (accessibilité) --}}
    <a href="#main-content"
       class="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[9999]
              focus:px-4 focus:py-2 focus:rounded-xl focus:text-sm focus:font-semibold
              focus:bg-[rgb(var(--mt-secondary))] focus:text-white focus:shadow-lg
              transition-all duration-200">
        Aller au contenu principal
    </a>


    <x-mtblog::header />

    {{-- ══ Contenu principal ══════════════════════════════════════ --}}
    <main id="main-content"
          class="flex-1 w-full max-w-7xl mx-auto px-4 lg:px-8 py-8
                 animate-mt-fade-in">
        {{ $slot }}
    </main>

    {{-- ══ Footer ══════════════════════════════════════════════════ --}}
    <x-mtblog::footer />

    {{-- ══ Toast container (notifications Livewire) ═══════════════ --}}
    <div id="toast-container"
         class="fixed bottom-6 right-6 z-[9999] flex flex-col gap-3 pointer-events-none">
    </div>

    {{-- ══ Scripts globaux ════════════════════════════════════════ --}}
    <script>
    document.addEventListener('DOMContentLoaded', () => {

        // ── Smooth scroll ancres internes ────────────────────────
        document.querySelectorAll('a[href^="#"]').forEach(a => {
            a.addEventListener('click', e => {
                const target = document.querySelector(a.getAttribute('href'));
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });

        // ── Lazy loading images (data-src) ───────────────────────
        if ('IntersectionObserver' in window) {
            const imgObserver = new IntersectionObserver((entries, obs) => {
                entries.forEach(entry => {
                    if (!entry.isIntersecting) return;
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    obs.unobserve(img);
                });
            }, { rootMargin: '100px 0px' });

            document.querySelectorAll('img[data-src]').forEach(img => imgObserver.observe(img));
        }

        // ── Raccourci "/" → focus recherche header ───────────────
        document.addEventListener('keydown', e => {
            if (
                e.key === '/' &&
                !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName) &&
                !e.metaKey && !e.ctrlKey
            ) {
                e.preventDefault();
                document.dispatchEvent(new CustomEvent('open-search'));
            }
        });

    });

    // ── Helper toast (réutilisable partout) ─────────────────────
    window.mtToast = function(message, type = 'success', duration = 3500) {
        const palette = {
            success : 'bg-green-500 shadow-green-500/20',
            error   : 'bg-red-500   shadow-red-500/20',
            warning : 'bg-amber-500 shadow-amber-400/20',
            info    : 'bg-blue-500  shadow-blue-500/20',
        };
        const icons = {
            success : 'fa-circle-check',
            error   : 'fa-circle-xmark',
            warning : 'fa-triangle-exclamation',
            info    : 'fa-circle-info',
        };

        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = [
            'pointer-events-auto flex items-center gap-3',
            'px-4 py-3 rounded-2xl shadow-xl text-white text-sm font-medium',
            'transition-all duration-300 translate-y-4 opacity-0',
            palette[type] ?? palette.info,
        ].join(' ');

        toast.innerHTML = `<i class="fa-solid ${icons[type] ?? icons.info} flex-shrink-0"></i>${message}`;
        container.appendChild(toast);

        requestAnimationFrame(() => {
            toast.classList.remove('translate-y-4', 'opacity-0');
        });

        setTimeout(() => {
            toast.classList.add('translate-y-4', 'opacity-0');
            setTimeout(() => toast.remove(), 320);
        }, duration);
    };

    // ── Notifications Livewire → toast ───────────────────────────
    document.addEventListener('livewire:initialized', () => {
        Livewire.on('notify', ({ message, type = 'success', duration = 3500 }) => {
            window.mtToast(message, type, duration);
        });

        // Auth modal (si utilisé)
        Livewire.on('open-auth-modal', () => {
            document.dispatchEvent(new CustomEvent('open-auth-modal'));
        });
    });
    </script>

</x-mt::layouts.guest>
