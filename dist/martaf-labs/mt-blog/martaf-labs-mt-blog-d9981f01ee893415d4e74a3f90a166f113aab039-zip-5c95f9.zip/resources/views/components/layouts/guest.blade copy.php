
    <x-mt::layouts.guest>

        @push('styles')
            <style>
                .gradient-bg {
                    background: linear-gradient(135deg, #1F1C46 0%, #1F1C46 50%, #2D2D82 100%);
                }

                .gradient-text {
                    background: linear-gradient(135deg, #1F1C46, #2D2D82);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
            </style>

            <style>

                /* 2. KEYFRAMES (Animations) */
                @keyframes float {
                    0%, 100% { transform: translateY(0px); }
                    50% { transform: translateY(-10px); }
                }

                @keyframes pulse-glow {
                    0%, 100% { opacity: 0.6; }
                    50% { opacity: 1; }
                }

                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                @keyframes slideDown {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                @keyframes marquee {
                    0% { transform: translateX(100%); }
                    100% { transform: translateX(-100%); }
                }

                @keyframes loading {
                    0% { background-position: 200% 0; }
                    100% { background-position: -200% 0; }
                }

                @keyframes pulse {
                    0%, 100% { opacity: 1; transform: scale(1); }
                    50% { opacity: 0.5; transform: scale(1.1); }
                }

                /* 3. CLASSES D'ANIMATION */
                .animate-float { animation: float 3s ease-in-out infinite; }
                .animate-pulse-glow { animation: pulse-glow 2s ease-in-out infinite; }
                .animate-fadeIn { animation: fadeIn 0.8s ease-out forwards; }
                .animate-slideDown { animation: slideDown 0.3s ease-out forwards; }
                .animate-marquee, .breaking-news-animation { animation: marquee 25s linear infinite; }
                .live-pulse { animation: pulse 1.5s ease-in-out infinite; }

                /* 4. COMPOSANTS UI & GLASSMORPHISM */
                .glass {
                    backdrop-filter: blur(10px);
                    background: rgba(255, 255, 255, 0.1);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }

                .glass-dark {
                    backdrop-filter: blur(10px);
                    background: rgba(11, 26, 51, 0.8);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                }

                /* Dropdown */
                .dropdown {
                    position: relative;
                    display: inline-block;
                }

                .dropdown-content {
                    position: absolute;
                    top: 100%;
                    left: 0;
                    min-width: 240px;
                    opacity: 0;
                    visibility: hidden;
                    transform: translateY(-10px);
                    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                    z-index: 100;
                }

                .dropdown:hover .dropdown-content {
                    opacity: 1;
                    visibility: visible;
                    transform: translateY(0);
                }

                /* Tooltip */
                .tooltip { position: relative; }

                .tooltip-content {
                    position: absolute;
                    bottom: 100%;
                    left: 50%;
                    transform: translateX(-50%) translateY(10px);
                    padding: 8px 12px;
                    background: #1F1C46;
                    color: white;
                    border-radius: 8px;
                    font-size: 12px;
                    white-space: nowrap;
                    opacity: 0;
                    visibility: hidden;
                    transition: all 0.3s ease;
                    pointer-events: none;
                }

                .tooltip:hover .tooltip-content {
                    opacity: 1;
                    visibility: visible;
                    transform: translateX(-50%) translateY(0);
                }

                /* Skeleton & Progress */
                .skeleton {
                    background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
                    background-size: 200% 100%;
                    animation: loading 1.5s infinite;
                }

                /* 5. HOVER EFFECTS */
                .hover-lift {
                    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
                }

                .hover-lift:hover {
                    transform: translateY(-8px) scale(1.02);
                    box-shadow: 0 20px 40px -15px rgba(198, 40, 40, 0.3);
                }

                .hover-glow:hover, .red-glow:hover {
                    transition: all 0.3s ease;
                    box-shadow: 0 0 25px rgba(198, 40, 40, 0.4);
                }

                .zoomable-image {
                    cursor: zoom-in;
                    transition: transform 0.3s ease;
                }

                .zoomable-image.zoomed {
                    transform: scale(1.5);
                    cursor: zoom-out;
                    z-index: 100;
                    position: relative;
                }

                /* 6. COULEURS & DÉGRADÉS */
                .gradient-navy { background: linear-gradient(135deg, #1F1C46 0%, #1A2F4F 100%); }
                .gradient-red { background: linear-gradient(135deg, #BE1622 0%, #E63C50 100%); }

                /* Dégradé drapeau (ex: Bleu/Rouge/Jaune) */
                .gradient-flag {
                    background: linear-gradient(90deg, #1F1C46 33%, #BE1622 33%, #BE1622 66%, #FFD700 66%);
                }

                .border-flag {
                    border-image: linear-gradient(90deg, #1F1C46 33%, #BE1622 33%, #BE1622 66%, #FFD700 66%) 1;
                    border-width: 3px;
                    border-style: solid;
                }

                /* 7. UTILITAIRES SPÉCIFIQUES */
                .red-underline { position: relative; }
                .red-underline::after {
                    content: '';
                    position: absolute;
                    bottom: -4px;
                    left: 0;
                    width: 60px;
                    height: 3px;
                    background: #BE1622;
                    transition: width 0.3s ease;
                }
                .red-underline:hover::after { width: 100px; }

                .highlight {
                    background: linear-gradient(120deg, rgba(198, 40, 40, 0.2) 0%, rgba(198, 40, 40, 0.2) 100%);
                    background-repeat: no-repeat;
                    background-size: 100% 0.3em;
                    background-position: 0 88%;
                    transition: background-size 0.25s ease-in;
                }
                .highlight:hover { background-size: 100% 100%; }

                .reading-time {
                    background: linear-gradient(90deg, #BE1622 0%, #BE1622 var(--reading-progress), #e0e0e0 var(--reading-progress), #e0e0e0 100%);
                }

                .toc-sticky {
                    position: sticky;
                    top: 100px;
                    max-height: calc(100vh - 120px);
                    overflow-y: auto;
                }
            </style>

        @endpush

        @section('meta_description', "Site d'information général et d'analyses de l'actualité nationale et internationale, avec un accent particulier sur les nouvelles locales et régionales.")


        {{-- header --}}
        @include('mtblog::components.header.'.mtblog_config('header.layout'))

        <main class="px-4 py-8 mx-auto max-w-7xl lg:px-8">
            {{ $slot }}
        </main>

        <!-- Footer moderne -->
        {{-- @include('livewire.partials.footer') --}}

        @push('scripts')
        <!-- Scripts pour interactivité -->
        <script>

            // Mobile menu toggle
            function toggleMobileMenu() {
                const menu = document.getElementById('mobileMenu');
                menu.classList.toggle('hidden');
            }

            // Mobile accordions
            function toggleAccordion(id) {
                const element = document.getElementById(id);
                const arrow = document.getElementById('arrow' + id.replace('mobile', ''));
                if (element.classList.contains('hidden')) {
                    element.classList.remove('hidden');
                    arrow.style.transform = 'rotate(180deg)';
                } else {
                    element.classList.add('hidden');
                    arrow.style.transform = 'rotate(0deg)';
                }
            }

            // Smooth scroll for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    document.querySelector(this.getAttribute('href')).scrollIntoView({
                        behavior: 'smooth'
                    });
                });
            });

            // Lazy loading images
            if ('IntersectionObserver' in window) {
                const images = document.querySelectorAll('img[data-src]');
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            img.src = img.dataset.src;
                            img.classList.add('opacity-100');
                            imageObserver.unobserve(img);
                        }
                    });
                });
                images.forEach(img => imageObserver.observe(img));
            }


        </script>

        @if (mt_has_dark_mode())
        <script>
            // Dark mode preference
            if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
                document.body.classList.add('dark-mode-aware');
            }
        </script>
        @endif
        @endpush

    </x-mt::layouts.guest>
