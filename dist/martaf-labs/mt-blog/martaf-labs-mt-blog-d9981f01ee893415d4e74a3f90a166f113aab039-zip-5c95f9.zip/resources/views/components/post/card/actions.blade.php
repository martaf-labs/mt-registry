{{--
╔══════════════════════════════════════════════════════════════════╗
║  SOUS-COMPOSANT : card-actions.blade.php                         ║
║  Usage : inclus dans card.blade.php via @include ou <x-mt::...> ║
╠══════════════════════════════════════════════════════════════════╣
║  PROPS                                                           ║
║  • article      Objet Article (requis)                           ║
║  • url          URL de l'article (requis)                        ║
║  • theme        'light' | 'dark'   (default: light)             ║
║                 light  → sur fond clair (default, minimal…)      ║
║                 dark   → sur fond sombre (magazine overlay…)     ║
║  • size         'sm' | 'md'        (default: md)                 ║
║                 sm → variant chip / editorial                    ║
╠══════════════════════════════════════════════════════════════════╣
║  RÉSEAUX DE PARTAGE DISPONIBLES                                  ║
║  Facebook · Twitter/X · WhatsApp · Telegram · LinkedIn           ║
║  + Copier le lien                                                ║
╠══════════════════════════════════════════════════════════════════╣
║  DÉPENDANCES                                                     ║
║  • Livewire  : wire:click pour like (action toggleLike)          ║
║  • Alpine.js : x-data pour le dropdown share                     ║
║  • FontAwesome : icônes                                          ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@props([
    'article' => null,
    'url'     => null,
    'theme'   => 'light',  // 'light' | 'dark'
    'size'    => 'md',     // 'md' | 'sm'
])

@if ($article && $url)

@php
    $isDark = $theme === 'dark';
    $isSm   = $size === 'sm';

    $encodedUrl   = urlencode($url);
    $encodedTitle = urlencode(strip_tags($article->title));

    $shareNetworks = [
        'facebook'  => [
            'label' => 'Facebook',
            'url'   => "https://www.facebook.com/sharer/sharer.php?u={$encodedUrl}",
            'icon'  => 'fa-brands fa-facebook-f',
            'color' => '#1877F2',
            'bg'    => '#E7F0FD',
        ],
        'twitter'   => [
            'label' => 'Twitter / X',
            'url'   => "https://twitter.com/intent/tweet?url={$encodedUrl}&text={$encodedTitle}",
            'icon'  => 'fa-brands fa-x-twitter',
            'color' => '#0F1419',
            'bg'    => '#F0F0F0',
        ],
        'whatsapp'  => [
            'label' => 'WhatsApp',
            'url'   => "https://wa.me/?text={$encodedTitle}%20{$encodedUrl}",
            'icon'  => 'fa-brands fa-whatsapp',
            'color' => '#25D366',
            'bg'    => '#E8F9EE',
        ],
        'telegram'  => [
            'label' => 'Telegram',
            'url'   => "https://t.me/share/url?url={$encodedUrl}&text={$encodedTitle}",
            'icon'  => 'fa-brands fa-telegram',
            'color' => '#2AABEE',
            'bg'    => '#E8F5FC',
        ],
        'linkedin'  => [
            'label' => 'LinkedIn',
            'url'   => "https://www.linkedin.com/sharing/share-offsite/?url={$encodedUrl}",
            'icon'  => 'fa-brands fa-linkedin-in',
            'color' => '#0A66C2',
            'bg'    => '#E8F0F9',
        ],
    ];

    // Classes selon le thème
    $btnBase = $isSm
        ? 'inline-flex items-center gap-1 text-[11px] font-medium px-2 py-1 rounded-lg transition-all duration-200'
        : 'inline-flex items-center gap-1.5 text-[12px] font-medium px-2.5 py-1.5 rounded-xl transition-all duration-200';

    if ($isDark) {
        $btnClass        = $btnBase . ' text-white/60 hover:text-white hover:bg-white/10';
        $btnLikedClass   = $btnBase . ' text-red-400 bg-red-500/15';
        $iconClass       = 'text-white/40';
        $separatorClass  = 'bg-white/10';
    } else {
        $btnClass        = $btnBase . ' text-gray-400 dark:text-white/35 hover:text-gray-700 dark:hover:text-white/70 hover:bg-gray-100 dark:hover:bg-white/6';
        $btnLikedClass   = $btnBase . ' text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-500/10';
        $iconClass       = 'text-gray-300 dark:text-white/15';
        $separatorClass  = 'bg-gray-100 dark:bg-white/8';
    }
@endphp

<div
    class="flex items-center gap-0.5"
    x-data="{
        liked: {{ $article->isLikedByUser() ? 'true' : 'false' }},
        likeCount: {{ $article->likes_count ?? 0 }},
        shareOpen: false,
        copied: false,
        toggleLike() {
            this.liked = !this.liked;
            this.likeCount += this.liked ? 1 : -1;
            $wire.toggleLike({{ $article->id }});
        },
        copyLink() {
            navigator.clipboard.writeText('{{ $url }}').then(() => {
                this.copied = true;
                setTimeout(() => { this.copied = false; }, 2000);
            });
        }
    }"
    @click.stop
>

    {{-- ── LIKE ─────────────────────────────────────────── --}}
    <button
        @click="toggleLike()"
        :class="liked ? '{{ $btnLikedClass }}' : '{{ $btnClass }}'"
        :aria-label="liked ? 'Retirer le like' : 'Liker cet article'"
        title="J'aime"
    >
        <i :class="liked ? 'fa-solid fa-heart text-red-500 dark:text-red-400' : 'fa-regular fa-heart {{ $iconClass }}'"></i>
        <span x-text="likeCount > 0 ? likeCount : ''"></span>
    </button>

    {{-- ── COMMENTS ──────────────────────────────────────── --}}
    <a
        href="{{ $url }}#comments"
        wire:navigate
        class="{{ $btnClass }}"
        title="Commentaires"
        aria-label="Voir les commentaires"
    >
        <i class="fa-regular fa-comment {{ $iconClass }}"></i>
        @if (($article->comments_count ?? 0) > 0)
        <span>{{ $article->comments_count }}</span>
        @endif
    </a>

    {{-- ── SÉPARATEUR ─────────────────────────────────────── --}}
    <span class="w-px h-4 mx-1 {{ $separatorClass }} flex-shrink-0"></span>

    {{-- ── SHARE ─────────────────────────────────────────── --}}
    <div class="relative" x-data @click.outside="shareOpen = false">

        <button
            @click="shareOpen = !shareOpen"
            :class="shareOpen ? '{{ $btnLikedClass }} !text-[rgb(var(--mt-secondary))] !bg-[rgb(var(--mt-secondary))]/10' : '{{ $btnClass }}'"
            title="Partager"
            aria-label="Partager cet article"
            :aria-expanded="shareOpen"
        >
            <i class="fa-regular fa-share-from-square {{ $iconClass }}"></i>
            <span class="{{ $isSm ? 'hidden' : 'hidden sm:inline' }}">Partager</span>
        </button>

        {{-- Dropdown share --}}
        <div
            x-show="shareOpen"
            x-transition:enter="transition ease-out duration-150"
            x-transition:enter-start="opacity-0 scale-95 translate-y-1"
            x-transition:enter-end="opacity-100 scale-100 translate-y-0"
            x-transition:leave="transition ease-in duration-100"
            x-transition:leave-start="opacity-100 scale-100 translate-y-0"
            x-transition:leave-end="opacity-0 scale-95 translate-y-1"
            class="absolute bottom-full left-0 mb-2 z-50 w-52
                   bg-white dark:bg-gray-900
                   border border-gray-100 dark:border-white/8
                   rounded-2xl shadow-xl dark:shadow-black/40
                   overflow-hidden"
            style="display:none"
        >
            {{-- En-tête --}}
            <div class="px-3.5 pt-3 pb-2">
                <p class="text-[11px] font-semibold text-gray-400 dark:text-white/30 uppercase tracking-widest">
                    Partager via
                </p>
            </div>

            {{-- Réseaux --}}
            <div class="px-2 pb-2 flex flex-col gap-0.5">
                @foreach ($shareNetworks as $key => $network)
                <a
                    href="{{ $network['url'] }}"
                    target="_blank"
                    rel="noopener noreferrer"
                    @click="shareOpen = false"
                    class="flex items-center gap-3 px-2.5 py-2 rounded-xl
                           hover:bg-gray-50 dark:hover:bg-white/4
                           transition-colors duration-150 group/share"
                >
                    <span class="flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center"
                          style="background: {{ $network['bg'] }}">
                        <i class="{{ $network['icon'] }} text-[12px]" style="color: {{ $network['color'] }}"></i>
                    </span>
                    <span class="text-[13px] text-gray-700 dark:text-white/70
                                  group-hover/share:text-gray-900 dark:group-hover/share:text-white
                                  transition-colors duration-150 font-medium">
                        {{ $network['label'] }}
                    </span>
                </a>
                @endforeach
            </div>

            {{-- Séparateur --}}
            <div class="h-px bg-gray-100 dark:bg-white/6 mx-3"></div>

            {{-- Copier le lien --}}
            <div class="px-2 py-2">
                <button
                    @click="copyLink()"
                    class="w-full flex items-center gap-3 px-2.5 py-2 rounded-xl
                           hover:bg-gray-50 dark:hover:bg-white/4
                           transition-colors duration-150 group/copy"
                >
                    <span class="flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center bg-gray-100 dark:bg-white/8">
                        <i :class="copied ? 'fa-solid fa-check text-green-500' : 'fa-regular fa-link text-gray-500 dark:text-white/40'"
                           class="text-[12px] transition-all duration-200"></i>
                    </span>
                    <span x-text="copied ? 'Lien copié !' : 'Copier le lien'"
                          :class="copied ? 'text-green-600 dark:text-green-400' : 'text-gray-700 dark:text-white/70 group-hover/copy:text-gray-900 dark:group-hover/copy:text-white'"
                          class="text-[13px] font-medium transition-colors duration-150">
                    </span>
                </button>
            </div>

        </div>
    </div>

</div>

@endif
