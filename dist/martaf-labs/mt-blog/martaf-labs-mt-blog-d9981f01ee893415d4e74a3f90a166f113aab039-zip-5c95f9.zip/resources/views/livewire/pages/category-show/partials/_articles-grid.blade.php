{{--
  Partial : _articles-grid.blade.php
  Grille / liste d'articles + état vide + pagination.
  Props : $cardVariant (string, défaut 'default') → variant de <x-mtblog::post.card>
  Données : $articles (paginator), $viewMode, $category
--}}

@props(['cardVariant' => 'default'])

<div wire:loading.class="opacity-50 pointer-events-none" class="transition-opacity duration-200">

    @if ($this->articles->count() > 0)

        {{-- Grille ou liste --}}
        @if ($viewMode === 'list')
        <div class="flex flex-col gap-0 mb-8">
            @foreach ($this->articles as $article)
            <x-mtblog::post.card
                :article="$article"
                :variant="$cardVariant"
                layout="list"
            />
            @endforeach
        </div>
        @else
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 mb-8">
            @foreach ($this->articles as $article)
            <x-mtblog::post.card
                :article="$article"
                :variant="$cardVariant"
                layout="grid"
            />
            @endforeach
        </div>
        @endif

        {{-- Pagination --}}
        <div class="mt-4">
            {{ $this->articles->links() }}
        </div>

    @else

        {{-- État vide --}}
        <div class="flex flex-col items-center justify-center py-24 text-center">
            <div class="flex items-center justify-center w-20 h-20 mb-5 bg-gray-100 dark:bg-white/6 rounded-2xl">
                @if ($category->icon)
                <i class="{{ $category->icon }} text-3xl text-gray-300 dark:text-white/15"></i>
                @else
                <i class="fa-regular fa-newspaper text-3xl text-gray-300 dark:text-white/15"></i>
                @endif
            </div>
            <h3 class="mb-2 text-lg font-semibold text-gray-700 dark:text-white/60">
                @if ($search !== '')
                Aucun résultat pour "{{ $search }}"
                @else
                Aucun article pour le moment
                @endif
            </h3>
            <p class="max-w-xs mb-6 text-sm text-gray-400 dark:text-white/30">
                @if ($search !== '')
                Essayez un autre mot-clé ou réinitialisez les filtres.
                @else
                Cette rubrique ne contient pas encore d'articles publiés. Revenez bientôt !
                @endif
            </p>
            <div class="flex items-center gap-3">
                @if ($search !== '' || $subCategoryId || $sort !== 'recent')
                <button wire:click="resetFilters"
                        class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-xl
                               border border-gray-200 dark:border-white/10 text-gray-600 dark:text-white/50
                               hover:border-[rgb(var(--mt-secondary))]/30 hover:text-[rgb(var(--mt-secondary))] transition-all">
                    <i class="fa-solid fa-rotate-left text-xs"></i>
                    Réinitialiser les filtres
                </button>
                @endif
                <a href="{{ mt_get_route('home') }}" wire:navigate
                   class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-xl
                          bg-[rgb(var(--mt-primary))] dark:bg-white/8 text-white
                          hover:bg-[rgb(var(--mt-secondary))] transition-colors">
                    <i class="fa-solid fa-house text-xs"></i>
                    Retour à l'accueil
                </a>
            </div>
        </div>

    @endif

</div>

{{-- Indicateur de chargement global --}}
<div wire:loading
     class="fixed bottom-6 right-6 z-50 mt-bg-primary text-white text-sm px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2.5">
    <i class="fa-solid fa-spinner fa-spin text-[rgb(var(--mt-secondary))]"></i>
    Chargement…
</div>
