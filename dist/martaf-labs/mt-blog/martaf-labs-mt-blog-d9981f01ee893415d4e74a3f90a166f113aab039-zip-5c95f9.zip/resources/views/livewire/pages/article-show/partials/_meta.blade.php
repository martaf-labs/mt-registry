{{--
  Partial : _meta.blade.php
  Usage   : @include('mtblog::livewire.pages.article-show._meta')
  Données : $article, $isLiked, $isBookmarked
  Affiche : auteur, date, temps de lecture, vues + boutons bookmark/share/like
--}}

@if($hasMeta)
<div class="pb-5 mb-6 border-b border-gray-100 dark:border-white/6">
    <div class="flex flex-wrap items-center justify-between gap-4">

        {{-- Infos --}}
        <div class="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-sm text-gray-500 dark:text-white/40">

            @if ($article->authorName)
            <span class="flex items-center gap-1.5 font-medium text-gray-700 dark:text-white/70">
                <i class="fa-regular fa-user text-[rgb(var(--mt-secondary))] text-xs"></i>
                {{ $article->authorName }}
            </span>
            <span class="text-gray-200 dark:text-white/10">•</span>
            @endif

            <span class="flex items-center gap-1.5">
                <i class="fa-regular fa-calendar-days text-xs text-[rgb(var(--mt-secondary))]"></i>
                {{ $article->publishedDate }}
            </span>

            <span class="text-gray-200 dark:text-white/10">•</span>

            <span class="flex items-center gap-1.5">
                <i class="fa-regular fa-clock text-xs"></i>
                {{ $article->readingTime }} de lecture
            </span>

            @if ($article->views_count > 0)
            <span class="text-gray-200 dark:text-white/10">•</span>
            <span class="flex items-center gap-1.5">
                <i class="fa-regular fa-eye text-xs"></i>
                {{ $article->viewsCount(true) }}
            </span>
            @endif

        </div>

        {{-- Actions rapides --}}
        <div class="flex items-center gap-1" x-data="{ liked: {{ $isLiked ? 'true' : 'false' }}, likeCount: {{ $article->likes_count ?? 0 }} }">

            {{-- Like --}}
            <button
                @click="liked=!liked; likeCount+=liked?1:-1; $wire.toggleLike()"
                class="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm transition-all duration-200"
                :class="liked
                    ? 'text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-500/10'
                    : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-gray-700 dark:hover:text-white/60'"
                title="J'aime">
                <i :class="liked ? 'fa-solid fa-heart' : 'fa-regular fa-heart'" class="text-xs"></i>
                <span x-text="likeCount > 0 ? likeCount : ''" class="text-xs font-medium"></span>
            </button>

            {{-- Bookmark --}}
            <button
                wire:click="toggleBookmark"
                class="p-2 rounded-xl transition-all duration-200 {{ $isBookmarked
                    ? 'text-[rgb(var(--mt-secondary))] bg-[rgb(var(--mt-secondary))]/10'
                    : 'text-gray-400 dark:text-white/30 hover:bg-gray-100 dark:hover:bg-white/6 hover:text-[rgb(var(--mt-secondary))]' }}"
                title="{{ $isBookmarked ? 'Retirer des favoris' : 'Sauvegarder' }}">
                <i class="{{ $isBookmarked ? 'fa-solid' : 'fa-regular' }} fa-bookmark text-xs"></i>
            </button>

            {{-- Print --}}
            <button
                onclick="window.print()"
                class="p-2 rounded-xl text-gray-400 dark:text-white/30
                    hover:bg-gray-100 dark:hover:bg-white/6 hover:text-gray-700 dark:hover:text-white/60
                    transition-all duration-200"
                title="Imprimer">
                <i class="fa-solid fa-print text-xs"></i>
            </button>

        </div>
    </div>
</div>
@endif