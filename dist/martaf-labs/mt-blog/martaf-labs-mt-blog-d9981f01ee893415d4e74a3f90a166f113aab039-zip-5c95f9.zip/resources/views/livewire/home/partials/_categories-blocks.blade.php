{{--
  Partial : _categories-blocks.blade.php
  Blocs d'articles par rubrique (4 catégories max).
  Props :
    $cardVariant  variant de card à utiliser (défaut: 'default')
    $columns      nombre de colonnes articles par catégorie (défaut: 4)
  Données : $featured_categories (collection de ['category', 'articles'])
--}}

@props([
    'cardVariant' => 'default',
    'columns'     => 4,
])

@if ($this->featured_categories->isNotEmpty())
<div class="space-y-12">
    @foreach ($this->featured_categories as $block)
    @php
        $cat = $block['category'];
        $articles = $block['articles'];
    @endphp

    <section>
        {{-- En-tête rubrique --}}
        <div class="flex items-center justify-between gap-3 mb-5">
            <div class="flex items-center gap-2.5">
                <span class="w-1 h-6 rounded-full flex-shrink-0" style="background: {{ $cat->color ?? 'rgb(var(--mt-secondary))' }}"></span>
                @if ($cat->icon)
                <span class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style="background: {{ $cat->color ?? 'rgb(var(--mt-secondary))' }}20">
                    <i class="{{ $cat->icon }} text-xs" style="color: {{ $cat->color ?? 'rgb(var(--mt-secondary))' }}"></i>
                </span>
                @endif
                <h2 class="text-base font-bold uppercase tracking-wide text-gray-900 dark:text-white">
                    {{ $cat->name }}
                </h2>
            </div>
            <a href="{{ mt_get_route('home_categories_show', ['slug' => $cat->slug]) }}" wire:navigate
               class="flex items-center gap-1.5 text-xs font-semibold
                      text-gray-400 dark:text-white/30 hover:text-[rgb(var(--mt-secondary))] hover:gap-2.5
                      transition-all duration-200">
                Tout voir <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>

        {{-- Articles de la rubrique --}}
        @if ($columns === 4 && $articles->count() >= 3)

        {{-- Layout spécial : 1 grande + colonne de 3 petites --}}
        <div class="grid lg:grid-cols-5 gap-5">
            <div class="lg:col-span-3">
                <x-mtblog::post.card
                    :article="$articles->first()"
                    variant="magazine"
                    class="h-60 lg:h-90"
                    :show-actions="false"
                />
            </div>
            <div class="lg:col-span-2 flex flex-col gap-0">
                @foreach ($articles->skip(1)->take(3) as $article)
                <x-mtblog::post.card
                    :article="$article"
                    variant="minimal"
                    :show-excerpt="true"
                />
                @endforeach
            </div>
        </div>

        @else

        {{-- Grille standard --}}
        <div class="grid gap-4 sm:grid-cols-2 {{ $columns >= 3 ? 'lg:grid-cols-3' : 'lg:grid-cols-2' }}">
            @foreach ($articles->take($columns) as $article)
            <x-mtblog::post.card :article="$article" :variant="$cardVariant" :show-actions="false" />
            @endforeach
        </div>

        @endif
    </section>

    @endforeach
</div>
@endif
