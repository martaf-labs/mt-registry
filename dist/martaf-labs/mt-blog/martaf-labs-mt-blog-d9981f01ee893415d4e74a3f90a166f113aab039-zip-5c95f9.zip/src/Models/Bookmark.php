<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Bookmark extends MtBaseModel
{

    protected $fillable = [
        'article_id',
        'note',
        'collection',
        'read_later',
        'downloaded',
    ];

    protected $casts = [
        'collection' => 'array',
        'read_later' => 'datetime',
        'downloaded' => 'boolean',
    ];

    // Relations
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function article(): BelongsTo
    {
        return $this->belongsTo(Article::class);
    }

    // Scopes
    public function scopeReadLater($query)
    {
        return $query->whereNotNull('read_later')
                     ->where('read_later', '>=', now());
    }

    public function scopeDownloaded($query)
    {
        return $query->where('downloaded', true);
    }

    public function scopeInCollection($query, $collection)
    {
        return $query->whereJsonContains('collection', $collection);
    }

    // Méthodes
    public function markAsRead(): void
    {
        $this->read_later = null;
        $this->save();
    }

    public function markForLater(\DateTime $when = null): void
    {
        $this->read_later = $when ?? now()->addDay();
        $this->save();
    }

    public function toggleDownload(): void
    {
        $this->downloaded = !$this->downloaded;
        $this->save();
    }
}