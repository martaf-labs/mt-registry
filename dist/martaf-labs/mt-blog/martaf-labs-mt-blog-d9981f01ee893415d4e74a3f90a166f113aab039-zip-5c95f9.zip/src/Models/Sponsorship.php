<?php

namespace Mt\Blog\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;
use Mt\Blog\Enums\TypeSponsorship;
use Mt\MtViews\Models\MtBaseModel;

class Sponsorship extends MtBaseModel
{

    protected $fillable = [
        'type',
        'start_date',
        'end_date',
        'price',
        'contract_reference',
        'description',
        'is_active',
        'article_id',
        'partner_id',
    ];

    protected $casts = [
        'type' => TypeSponsorship::class,
        'start_date' => 'datetime',
        'end_date' => 'datetime',
        'price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    // Relations
    public function article(): BelongsTo
    {
        return $this->belongsTo(Article::class);
    }
    public function partner(): BelongsTo
    {
        return $this->belongsTo(Partner::class);
    }

    // business logic
    public function isCurrentlyActive(): bool
    {
        if ($this->is_active) {
            return false;
        }

        if ($this->start_date && now()->lt($this->start_date)) {
            return false;
        }

        if ($this->end_date && now()->gt($this->end_date)) {
            return false;
        }

        return true;
    }
}
