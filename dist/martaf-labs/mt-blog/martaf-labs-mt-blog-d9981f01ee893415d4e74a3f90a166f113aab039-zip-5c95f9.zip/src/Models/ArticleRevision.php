<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ArticleRevision extends MtBaseModel
{
    protected $fillable = [
        'article_id',
        'title',
        'excerpt',
        'content',
        'changes',
        'summary',
        'version',
    ];

    protected $casts = [
        'changes' => 'array',
    ];

    // Relations
    public function article(): BelongsTo
    {
        return $this->belongsTo(Article::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // Méthodes
    public function restore(): Article
    {
        $article = $this->article;
        $article->title = $this->title;
        $article->excerpt = $this->excerpt;
        $article->content = $this->content;
        $article->save();
        
        return $article;
    }

    public function diff(ArticleRevision $other = null): array
    {
        $other = $other ?? $this->article->revisions()
                        ->where('version', $this->version - 1)
                        ->first();
        
        if (!$other) {
            return [];
        }
        
        // Calculer les différences entre les deux versions
        // Implémentation simplifiée
        return [
            'title' => $this->title !== $other->title,
            'excerpt' => $this->excerpt !== $other->excerpt,
            'content' => $this->content !== $other->content,
        ];
    }
}