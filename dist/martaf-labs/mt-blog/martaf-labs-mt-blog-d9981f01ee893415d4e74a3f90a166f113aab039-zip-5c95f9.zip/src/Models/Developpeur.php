<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\BaseDeveloppeur;

class Developpeur extends BaseDeveloppeur
{

}