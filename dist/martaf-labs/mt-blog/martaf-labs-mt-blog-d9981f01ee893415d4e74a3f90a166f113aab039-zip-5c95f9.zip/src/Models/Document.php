<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\BaseDocument;

class Document extends BaseDocument
{

}