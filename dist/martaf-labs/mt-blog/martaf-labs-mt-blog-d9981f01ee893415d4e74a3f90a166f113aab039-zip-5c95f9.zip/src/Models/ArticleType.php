<?php

namespace Mt\Blog\Models;

use Illuminate\Support\Str;
use Mt\MtViews\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ArticleType extends MtBaseModel
{

    protected $fillable = [
        'name',
        'slug',
        'label',
        'icon',
        'color',
        'order',
        'is_editorial',
        'is_sponsored',
        'usage_count',
        'description',
        'is_active',
    ];

    protected $casts = [
        'is_editorial'  => 'boolean',
        'is_sponsored'  => 'boolean',
        'is_active'     => 'boolean',
    ];

    /**
     * action du booted
     */
    protected static function booted()
    {
        static::creating(function($model){
            $model->slug = Str::slug($model->name);
        });
    }

    // Relations
    public function articles(): HasMany
    {
        return $this->hasMany(Article::class);
    }

    // scopes
    public function scopeSponsored($query)
    {
        return $query->where('is_sponsored', true);
    }

    public function scopeNotSponsored($query)
    {
        return $query->where('is_sponsored', false);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('order')->orderBy('name');
    }
}
