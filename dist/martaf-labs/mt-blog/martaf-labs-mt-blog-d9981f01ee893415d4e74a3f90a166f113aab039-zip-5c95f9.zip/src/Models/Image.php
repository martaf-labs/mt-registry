<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\BaseImage;

class Image extends BaseImage
{

}