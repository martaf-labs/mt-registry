<?php
// app/Models/Tag.php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Tag extends MtBaseModel
{
    protected $fillable = [
        'name',
        'slug',
        'usage_count',
    ];

    // Relations
    public function articles(): BelongsToMany
    {
        return $this->belongsToMany(Article::class)
                    ->withTimestamps();
    }

    // Scopes
    public function scopePopular($query, $limit = 10)
    {
        return $query->orderBy('usage_count', 'desc')->limit($limit);
    }

    // Méthodes
    public function incrementUsage(): void
    {
        $this->increment('usage_count');
    }

    public function decrementUsage(): void
    {
        $this->decrement('usage_count');
    }

    public function syncUsage(): void
    {
        $this->usage_count = $this->articles()->count();
        $this->saveQuietly();
    }

    // Accesseurs
    public function getUrlAttribute(): string
    {
        return route('tags.show', $this->slug);
    }
}