<?php

namespace Mt\Blog\Models;

use Illuminate\Support\Str;
use Mt\MtViews\Models\MtBaseModel;

class Newsletter extends MtBaseModel
{

    protected $fillable = [
        'email',
        'name',
        'preferences',
        'frequency',
        'subscribed_at',
        'unsubscribed_at',
        'token',
    ];

    protected $casts = [
        'preferences' => 'array',
        'subscribed_at' => 'datetime',
        'unsubscribed_at' => 'datetime',
    ];

    protected static function booted()
    {
        static::creating(function ($newsletter) {
            $newsletter->token = $newsletter->token ?? Str::random(32);
        });
    }

    // Scopes
    public function scopeSubscribed($query)
    {
        return $query->whereNull('unsubscribed_at');
    }

    public function scopeUnsubscribed($query)
    {
        return $query->whereNotNull('unsubscribed_at');
    }

    public function scopeWithFrequency($query, $frequency)
    {
        return $query->where('frequency', $frequency);
    }

    // Méthodes
    public function subscribe(): void
    {
        $this->unsubscribed_at = null;
        $this->subscribed_at = now();
        $this->save();
    }

    public function unsubscribe(): void
    {
        $this->unsubscribed_at = now();
        $this->save();
    }

    public function isSubscribed(): bool
    {
        return is_null($this->unsubscribed_at);
    }

    public function getUnsubscribeUrlAttribute(): string
    {
        return route('newsletter.unsubscribe', $this->token);
    }
}