<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\BaseVideo;

class Video extends BaseVideo
{

}