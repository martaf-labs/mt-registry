<?php
namespace Mt\Blog\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Mt\MtViews\Models\MtBaseModel;

class NewsletterSubscriber extends MtBaseModel
{
    protected $fillable = ['email', 'token', 'is_active'];

    protected $casts = [
        'is_active' => 'boolean',
    ];


    protected static function booted()
    {
        static::creating(function ($subscriber) {
            $subscriber->token = Str::random(32);
        });
    }
}