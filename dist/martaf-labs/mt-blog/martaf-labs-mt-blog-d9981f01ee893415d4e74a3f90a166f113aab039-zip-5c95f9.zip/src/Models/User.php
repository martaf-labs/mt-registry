<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\BaseUser;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class User extends BaseUser
{

// Relations
    public function articles(): HasMany
    {
        return $this->hasMany(Article::class);
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class);
    }

    public function likes(): HasMany
    {
        return $this->hasMany(Like::class);
    }

    public function bookmarks(): HasMany
    {
        return $this->hasMany(Bookmark::class);
    }

    public function contributedArticles(): BelongsToMany
    {
        return $this->belongsToMany(Article::class, 'contributors')
                    ->withPivot('role', 'order')
                    ->withTimestamps();
    }

    public function revisions(): HasMany
    {
        return $this->hasMany(ArticleRevision::class);
    }

    // Scopes
    public function scopeJournalists($query)
    {
        return $query->where('role', 'journalist');
    }

    public function scopeEditors($query)
    {
        return $query->where('role', 'editor');
    }

    public function scopeAdmins($query)
    {
        return $query->where('role', 'admin');
    }

    // Méthodes d'autorisation
    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function isEditor(): bool
    {
        return $this->role === 'editor' || $this->isAdmin();
    }

    public function isJournalist(): bool
    {
        return $this->role === 'journalist' || $this->isEditor();
    }

    public function canEditArticle(Article $article): bool
    {
        return $this->isEditor() || $this->id === $article->user_id;
    }

    // Accesseurs
    public function getProfilePhotoUrlAttribute(): string
    {
        return $this->profile_photo 
            ? asset('storage/' . $this->profile_photo)
            : 'https://ui-avatars.com/api/?name=' . urlencode($this->name);
    }

    public function getIsActiveAttribute(): bool
    {
        return $this->status === 'active';
    }

    public function getTotalArticlesPublishedAttribute(): int
    {
        return $this->articles()->published()->count();
    }

}