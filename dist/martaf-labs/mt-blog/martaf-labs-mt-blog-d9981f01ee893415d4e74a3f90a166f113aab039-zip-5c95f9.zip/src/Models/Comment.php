<?php

namespace Mt\Blog\Models;

use Mt\MtViews\Models\MtBaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Comment extends MtBaseModel
{

    protected $fillable = [
        'content',
        'article_id',
        'parent_id',
        'likes_count',
        'status',
        'meta_data',
    ];

    protected $casts = [
        'meta_data' => 'array',
    ];

    // Relations
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function article(): BelongsTo
    {
        return $this->belongsTo(Article::class);
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Comment::class, 'parent_id');
    }

    public function replies(): HasMany
    {
        return $this->hasMany(Comment::class, 'parent_id');
    }

    public function likes(): MorphMany
    {
        return $this->morphMany(Like::class, 'likeable');
    }

    // Scopes
    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeSpam($query)
    {
        return $query->where('status', 'spam');
    }

    public function scopeRoot($query)
    {
        return $query->whereNull('parent_id');
    }

    // Accesseurs
    public function getIsApprovedAttribute(): bool
    {
        return $this->status === 'approved';
    }

    public function getIsPendingAttribute(): bool
    {
        return $this->status === 'pending';
    }

    public function getIsSpamAttribute(): bool
    {
        return $this->status === 'spam';
    }

    public function getRepliesCountAttribute(): int
    {
        return $this->replies()->approved()->count();
    }

    // Méthodes
    public function approve(): void
    {
        $this->status = 'approved';
        $this->save();
    }

    public function markAsSpam(): void
    {
        $this->status = 'spam';
        $this->save();
    }

    public function isAuthor(User $user): bool
    {
        return $this->user_id === $user->id;
    }
}