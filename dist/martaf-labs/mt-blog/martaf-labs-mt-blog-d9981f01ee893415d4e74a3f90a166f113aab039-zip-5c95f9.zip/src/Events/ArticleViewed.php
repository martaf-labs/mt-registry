<?php

namespace Mt\Blog\Events;

use Mt\Blog\Models\Article;

class ArticleViewed
{
    public function __construct(
        public readonly Article $article,
        public readonly bool $isUnique,
        public readonly array $context = []  // ip, user_agent, referrer, device
    ) {}
}

// src/Events/ArticleLiked.php
class ArticleLiked
{
    public function __construct(
        public readonly Article $article,
        public readonly string $action  // 'add' | 'remove'
    ) {}
}

// src/Events/ArticleCommented.php
class ArticleCommented
{
    public function __construct(
        public readonly Article $article,
        public readonly string $action  // 'add' | 'remove'
    ) {}
}

// src/Events/ArticleShared.php
class ArticleShared
{
    public function __construct(
        public readonly Article $article,
        public readonly string $network  // 'facebook' | 'twitter' | 'whatsapp' …
    ) {}
}