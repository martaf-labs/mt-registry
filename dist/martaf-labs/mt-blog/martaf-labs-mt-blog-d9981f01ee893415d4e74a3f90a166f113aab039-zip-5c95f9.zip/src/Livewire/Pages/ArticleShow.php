<?php

namespace Mt\Blog\Livewire\Pages;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Mt\Blog\Events\ArticleViewed;
use Mt\Blog\Events\ArticleLiked;
use Mt\Blog\Events\ArticleShared;
use Mt\Blog\Livewire\GuestBaseComponent;
use Mt\Blog\Models\Article;
use Mt\Blog\Models\Comment;

#[Title('Article')]
class ArticleShow extends GuestBaseComponent
{
    // ── État ────────────────────────────────────────────────────
    public Article $article;
    public bool    $isContentBlocks = false;
    public bool    $isLiked         = false;
    public bool    $isBookmarked    = false;
    public string  $commentText     = '';
    public ?int    $replyToId       = null;   // ID du commentaire parent (réponse)
    public bool    $commentPosted   = false;

    // ── Variant de mise en page ─────────────────────────────────
    /**
     * Contrôle le layout de la vue.
     * Valeurs : 'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
     *
     * Peut être forcé depuis le ServiceProvider / config :
     *   config('mtblog.article_layout', 'classic')
     *
     * Ou passé en query string pour les previews :
     *   ?layout=editorial
     */
    // #[Url(as: 'layout', except: 'classic')]
    public string $layout ='classic';

    // ── Mount ───────────────────────────────────────────────────
    public function mount(string $slug, int $id): void
    {
        // Récupération de l'article publié
        $this->article = Article::published()
            ->with(['category.parent', 'tags', 'author'])
            ->where('id', $id)
            ->firstOrFail();

        $this->isContentBlocks = $this->article->isContentBlocks;

        // Layout par défaut depuis la config si non forcé en URL
        // if ($this->layout === 'classic') {
        $this->layout = mtblog_config('article-show.layout');
        // }

        // ── Gestion des vues ────────────────────────────────────
        $viewKey    = 'has_viewed_article_' . $this->article->id;
        $uniqueKey  = 'viewed_article_' . $id;
        $hasViewed  = session()->has($viewKey);
        $isUnique   = ! session()->has($uniqueKey);

        if (! $hasViewed) {
            $this->article->incrementViews($isUnique);
            session()->put($viewKey, true);
        }

        if ($isUnique) {
            session()->put($uniqueKey, true);
        }

        // ── Event stats ─────────────────────────────────────────
        event(new ArticleViewed(
            article:  $this->article,
            isUnique: $isUnique,
            context:  [
                'referrer' => request()->headers->get('referer'),
                'device'   => $this->detectDevice(),
            ]
        ));

        // ── État utilisateur ────────────────────────────────────
        if (auth()->check()) {
            $userId = auth()->id();
            $this->isLiked      = $this->article->likes()
                ->where('created_by', $userId)->exists();
            $this->isBookmarked = $this->article->bookmarks()
                ->where('created_by', $userId)->exists();
        }
    }

    // ── Computed ────────────────────────────────────────────────

    #[Computed]
    public function similar_articles()
    {
        return Article::published()
            ->where('category_id', $this->article->category_id)
            ->where('id', '!=', $this->article->id)
            ->inRandomOrder()
            ->take(6)
            ->get();
    }

    #[Computed]
    public function others_articles()
    {
        return Article::published()
            ->where('category_id', '!=', $this->article->category_id)
            ->inRandomOrder()
            ->take(12)
            ->get();
    }

    #[Computed]
    public function article_comments()
    {
        if (! $this->article->allow_comments) {
            return null;
        }

        return $this->article
            ->comments()
            ->approved()
            ->whereNull('parent_id')
            ->with(['user', 'replies.user'])
            ->latest()
            ->paginate(10);
    }

    // ── Actions ─────────────────────────────────────────────────

    /**
     * Toggle like sur l'article.
     * Optimistic UI géré côté Alpine, persistance ici.
     */
    public function toggleLike(): void
    {
        if (! auth()->check()) {
            $this->dispatch('open-auth-modal');
            return;
        }

        $userId = auth()->id();
        $like   = $this->article->likes()->where('created_by', $userId);

        if ($like->exists()) {
            $like->delete();
            $this->article->decrement('likes_count');
            $this->isLiked = false;
            event(new ArticleLiked($this->article, 'remove'));
        } else {
            $this->article->likes()->create(['created_by' => $userId]);
            $this->article->increment('likes_count');
            $this->isLiked = true;
            event(new ArticleLiked($this->article, 'add'));
        }
    }

    /**
     * Toggle bookmark.
     */
    public function toggleBookmark(): void
    {
        if (! auth()->check()) {
            $this->dispatch('open-auth-modal');
            return;
        }

        $userId   = auth()->id();
        $bookmark = $this->article->bookmarks()->where('created_by', $userId);

        if ($bookmark->exists()) {
            $bookmark->delete();
            $this->article->decrement('bookmarks_count');
            $this->isBookmarked = false;
        } else {
            $this->article->bookmarks()->create(['created_by' => $userId]);
            $this->article->increment('bookmarks_count');
            $this->isBookmarked = true;
        }
    }

    /**
     * Publier un commentaire (ou une réponse).
     */
    public function postComment(): void
    {
        if (! auth()->check()) {
            $this->dispatch('open-auth-modal');
            return;
        }

        $this->validate([
            'commentText' => 'required|string|min:3|max:1000',
        ]);

        $this->article->comments()->create([
            'content'    => $this->commentText,
            'parent_id'  => $this->replyToId,
            'created_by' => auth()->id(),
            'status'     => 'pending',
        ]);

        $this->article->increment('comments_count');

        $this->commentText   = '';
        $this->replyToId     = null;
        $this->commentPosted = true;

        $this->dispatch('comment-posted');
        unset($this->article_comments);  // reset computed
    }

    /**
     * Définit le commentaire auquel on répond.
     */
    public function replyTo(int $commentId): void
    {
        $this->replyToId = $commentId;
        $this->dispatch('focus-comment-input');
    }

    /**
     * Annule la réponse en cours.
     */
    public function cancelReply(): void
    {
        $this->replyToId = null;
    }

    /**
     * Enregistre un partage (appelé depuis JS/Alpine).
     */
    public function recordShare(string $network): void
    {
        $this->article->increment('shares_count');
        event(new ArticleShared($this->article, $network));
    }

    // ── Helpers ─────────────────────────────────────────────────

    private function detectDevice(): string
    {
        $agent = strtolower(request()->userAgent() ?? '');

        if (str_contains($agent, 'mobile')) return 'mobile';
        if (str_contains($agent, 'tablet') || str_contains($agent, 'ipad')) return 'tablet';

        return 'desktop';
    }

    // ── Render ──────────────────────────────────────────────────

    public function render()
    {
        return view('mtblog::livewire.pages.article-show.' . $this->layout, [
            'hasBreadcrumb' => mtblog_option_article_show('breadcrumb'),
            'hasCategory' => mtblog_option_article_show('category'),
            'hasMeta' => mtblog_option_article_show('meta'),
            'hasAuthor' => mtblog_option_article_show('author'),
            'hasDate' => mtblog_option_article_show('date'),
            'hasReadingTime' => mtblog_option_article_show('reading_time'),
            'hasViewsCount' => mtblog_option_article_show('views_count'),
            'hasShare' => mtblog_option_article_show('share'),
            'hasTags' => mtblog_option_article_show('tags'),
            'hasSimilar' => mtblog_option_article_show('similar'),
            'hasComments' => mtblog_option_article_show('comments'),
        ])
        ->title($this->article->title);
    }
}
