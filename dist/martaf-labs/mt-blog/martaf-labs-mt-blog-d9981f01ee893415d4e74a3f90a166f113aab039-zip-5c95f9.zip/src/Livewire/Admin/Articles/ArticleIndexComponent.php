<?php

namespace Mt\Blog\Livewire\Admin\Articles;

use Livewire\Attributes\Title;
use Mt\Blog\Models\Article;
use Mt\MtViews\Livewire\Base\BaseIndex;
use Mt\Blog\Livewire\Indexes\ArticleIndex;

#[Title('Articles')]
class ArticleIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return ArticleIndex::class;
    }

    public function togglePublished($id=null)
    {
        if (is_null($id)){
            return;
        }

        $data = Article::find($id);

        if(!$data->isPublished){
            $data->publish();
        }
        else{
            $data->unpublish();
        }

        $this->dispatch(BaseIndex::class,'refresh');

    }

    public function toggleFeatured($id=null)
    {
        $data = Article::find($id)?->toggleFeatured();
        $this->dispatch(BaseIndex::class,'refresh');

    }

    public function togglePinned($id=null)
    {
        $data = Article::find($id)?->togglePinned();
        $this->dispatch(BaseIndex::class,'refresh');

    }

    public function toggleBreakingNews($id=null)
    {
        $data = Article::find($id)?->toggleBreakingNews();
        $this->dispatch(BaseIndex::class,'refresh');

    }

}
