<?php

namespace Mt\Blog\Livewire;

use Livewire\Component;
use Livewire\Attributes\Layout;

#[Layout('mtblog::components.layouts.guest')]
// #[Layout('mt::components.layouts.guest')]
class GuestBaseComponent extends Component
{
    // Ici on peux ajouter des méthodes ou propriétés communes
}
