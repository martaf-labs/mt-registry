<?php

namespace Mt\Blog\Livewire\Indexes;

use Mt\Blog\Models\Article;
use Mt\MtViews\Livewire\Indexes\GenericIndex;

class ArticleIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Article::class;
    }

    public function mainActions() : array
    {
        return [
            'create' => true,
            'custom' => [
                // "categorie" => [
                //     'icon' => getIcone('categorie'),
                //     'label' => "Catégorie",
                //     'route' => mt_get_route("categories")
                // ]
            ],
        ];
    }

    public function rowActions($rowId) : array
    {
        $data = Article::find($rowId);

        return [
            'edit' => true,
            'image-manager' => false,
            'delete' => true,
            'custom' => [
                "publier" => [
                    'type' => "livewire",
                    'icon' => $data->isPublished? "fa-solid fa-xmark" : "fa-solid fa-check",
                    'label' => $data->isPublished ? "Dépublier" : "Publier",
                    'method' => 'togglePublished',
                    'params' => $rowId
                ],
                "toggle_featured" => [
                    'type' => "livewire",
                    'icon' => $data->is_featured? "fa-solid fa-xmark" : "fa-solid fa-check",
                    'label' => $data->is_featured ? "Retirer de la Une" : "Mettre à la Une",
                    'method' => 'toggleFeatured',
                    'params' => $rowId
                ],
                "toggle_pinned" => [
                    'type' => "livewire",
                    'icon' => $data->is_pinned? "fa-solid fa-xmark" : "fa-solid fa-check",
                    'label' => $data->is_pinned ? "désépingler" : "épingler",
                    'method' => 'togglePinned',
                    'params' => $rowId
                ],
                "toggle_breaking" => [
                    'type' => "livewire",
                    'icon' => $data->is_breaking_news? "fa-solid fa-xmark" : "fa-solid fa-check",
                    'label' => $data->is_breaking_news ? "Rétirer de l' Actualité" : "Marqué Comme Actualité",
                    'method' => 'toggleBreakingNews',
                    'params' => $rowId
                ],
            ],
        ];
    }

    public function columns($rowId) : array
    {
        $data=Article::find($rowId);
        // if($data){
        //     dd($data?->has_featured);
        // }
        return [
            'firstColumn' => array_filter([
                'field' => 'title',
                'label' => 'Titre',
                'value' => $data?->title,
                'showLetters' => !$data?->has_featured,
                'letters' => $data?->title,
                'showImage' => $data?->has_featured,
                'image' => $data?->has_featured?$data?->getVariantImage('thumbnail') : null,
                'metaDatas' => array_filter([
                    $data?->category?->name,
                    $data?->publishedDate,
                    $data?->status,
                ]),
            ]),

            'othersColumns' => [

                'status' => [
                    'label' => 'Statut',
                    'value' => $data?->status,
                    'badgeDatas' => $data?->status?->badge(),
                ],
                // 'debut_prevue' => [
                //     'label' => 'Début Prévu',
                //     'value' => $data?->getDebutPrevue(),
                // ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model' => 'article',
            'model_plural' => 'articles',
            'mainLabel' => 'Articles',
            'title' => 'Liste d\'articles',

            'features' => [
                'canAddImages' => false,
                'searchable' => true,
                'perPage' => 20,
                'defaultSort' => 'created_at',
                'defaultSortDirection' => 'desc',
            ],

            'filters' => [],
            'sortableFields' => ['title'],
            // 'exportDatas' => $this->getArticleExportData(),
            'searchableFields' => [
                'direct' => ['title'],
                'relations' => [
                    'typeArticle' => ['title']
                ],
            ],
        ];
    }

    // public function getArticleExportData(): array
    // {
    //     $exportColumns = [
    //         'Nom' => 'nom',
    //         'Immatriculation' => 'immatriculation',
    //         'Numéro de série' => 'numero_serie',
    //         'Modèle' => 'modele',
    //         'Marque' => 'marque',
    //         'Catégorie' => 'type.nom',
    //         'Mise en service' => 'annee',
    //         'Type de compteur' => 'type_compteur',
    //         'Couleur' => 'couleur',
    //         'Localisation' => 'localisation',
    //         'Créé le' => 'created_at',
    //         'Mis à jour le' => 'updated_at',
    //     ];

    //     $exportData = Article::with('type')->get()->map(function ($article) {
    //         return [
    //             'nom' => $article->nom,
    //             'immatriculation' => $article->immatriculation,
    //             'numero_serie' => $article->numero_serie,
    //             'modele' => $article->modele,
    //             'marque' => $article->marque,
    //             'typeArticle.nom' => $article->typeArticle->nom ?? '',
    //             'annee' => $article->annee,
    //             'type_compteur' => $article->type_compteur,
    //             'couleur' => $article->couleur,
    //             'localisation' => $article->localisation,
    //             'created_at' => $article->created_at->format('d/m/Y H:i'),
    //             'updated_at' => $article->updated_at->format('d/m/Y H:i'),
    //         ];
    //     })->toArray();

    //     return [
    //         'columns' => $exportColumns,
    //         'data' => $exportData,
    //     ];
    // }

    // public function getStatistics(): array
    // {
    //     $modelClass = $this->modelClass();

    //     $total = $modelClass::count();
    //     $disponibles = $modelClass::where('statut', Article::DISPONIBLE)->count();
    //     $enPanne = $modelClass::where('statut', Article::EN_PANNE)->count();
    //     $horsService = $modelClass::where('statut', Article::INDISPONIBLE)->count();

    //     return [
    //         [
    //             'label' => 'Total Articles',
    //             'value' => $total,
    //             'icon' => 'truck',
    //             'color' => 'primary'
    //         ],
    //         [
    //             'label' => 'Disponibles',
    //             'value' => $disponibles,
    //             'icon' => 'check-circle',
    //             'color' => 'success'
    //         ],
    //         [
    //             'label' => 'En panne',
    //             'value' => $enPanne,
    //             'icon' => 'exclamation-triangle',
    //             'color' => 'danger'
    //         ],
    //         [
    //             'label' => 'Hors service',
    //             'value' => $horsService,
    //             'icon' => 'x-circle',
    //             'color' => 'secondary'
    //         ]
    //     ];
    // }

    // public function getFilterOptions(): array
    // {
    //     return [
    //         'typeArticles' => TypeArticle::pluck('nom', 'id'),
    //         'etats' => Article::etats(),
    //         'statuts' => Article::statuts(),
    //         'marques' => Article::marques(),
    //     ];
    // }


}
