<?php

use Illuminate\Support\Facades\Route;
use Mt\Blog\Http\Controllers\MediaController;
use Mt\Blog\Http\Controllers\NewsletterController;

Route::prefix('mtblog')
    ->middleware(config('blog.middleware'))
    ->group(function () {
        Route::post('/upload-image', [MediaController::class, 'upload']);
        Route::post('/fetch-image', [MediaController::class, 'fetch']);
        
        Route::get('/newsletter/unsubscribe/{token}', [NewsletterController::class, 'unsubscribe'])->name('newsletter.unsubscribe');
    });
