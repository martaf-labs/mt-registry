<?php

/**____________________________________________________________________________________________
|                                                                                       |
|  Configuration du package MtBlog                                                      |
|  Ce fichier contient les paramètres de configuration pour le package de blogging.       |
|  Vous pouvez personnaliser les types de blocs, les middlewares, et d'autres options.   |
|_______________________________________________________________________________________|
*/

return [

    /*
    |--------------------------------------------------------------------------
    | Configuration de l'affichage des vues pour les articles (ex: vue article-show)
    |--------------------------------------------------------------------------
    */

    //vue home
    'home' => [
        'layout' => env('MTBLOG_HOME_LAYOUT', 'classic'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'hero' =>[
                'variant' => env('MTBLOG_HOME_HERO_VARIANT', 'split'), //classic | cinematic | split | stack  
            ],
            'pinned' =>[
                'variant' => env('MTBLOG_HOME_PINNED_VARIANT', 'cards'), //'numbered' | 'cards'  
            ],
            'breaking_news'   => env('MTBLOG_HOME_BREAKING_NEWS', false),
        ],
    ],

    //vue header
    'header' => [
        'layout' => env('MTBLOG_HEADER_LAYOUT', 'classic'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'topbar'   => env('MTBLOG_HEADER_TOPBAR', true),
            'breaking_news'   => env('MTBLOG_HEADER_BREAKING_NEWS', false),
            'home'   => env('MTBLOG_HEADER_HOME', true),
            'auth'   => env('MTBLOG_HEADER_AUTH', true),
            'suscribe'   => env('MTBLOG_HEADER_SUSCRIBE', false),
            'bookmarks'   => env('MTBLOG_HEADER_BOOKMARKS', false),
            'menu_icons'   => env('MTBLOG_HEADER_MENU_ICONS', false),
            'compact'   => env('MTBLOG_HEADER_COMPACT', false),
        ],
    ],

    //vue footer
    'footer' => [
        'layout' => env('MTBLOG_FOOTER_LAYOUT', 'classic'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'social'   => env('MTBLOG_FOOTER_SOCIAL', false),
            'newsletter'   => env('MTBLOG_FOOTER_NEWSLETTER', false),
            'apps'   => env('MTBLOG_FOOTER_APPS', false),
            'tagline'   => env('MTBLOG_FOOTER_TAGLINE', false),
        ],
    ],

    //vue category-show
    'category-show' => [
        'layout' => env('MTBLOG_CATEGORY_LAYOUT', 'immersive'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'childrens'    => env('MTBLOG_CATEGORY_SHOW_CHILDRENS', false),
            'breadcrumb'   => env('MTBLOG_CATEGORY_SHOW_BREADCRUMB', false),
            'icon'         => env('MTBLOG_CATEGORY_SHOW_ICON', false),
            'meta'         => env('MTBLOG_CATEGORY_SHOW_META', false),
            'filter'       => env('MTBLOG_CATEGORY_SHOW_FILTER', false)
        ],
    ],

    //vue article-show
    'article-show' => [
        'layout' => env('MTBLOG_ARTICLE_LAYOUT', 'immersive'), //'classic' | 'immersive' | 'editorial' | 'minimal' | 'magazine'
        'options' => [
            'breadcrumb'    => env('MTBLOG_ARTICLE_SHOW_BREADCRUMB', false),
            'meta'          => env('MTBLOG_ARTICLE_SHOW_META', false),
            'category'      => env('MTBLOG_ARTICLE_SHOW_CATEGORY', false),
            'share'         => env('MTBLOG_ARTICLE_SHOW_SHARE', false),
            'date'          => env('MTBLOG_ARTICLE_SHOW_DATE', true),
            'reading_time'  => env('MTBLOG_ARTICLE_SHOW_READING_TIME', false),
            'views_count'   => env('MTBLOG_ARTICLE_SHOW_VIEWS_COUNT', true),
            'comments'      => env('MTBLOG_ARTICLE_SHOW_COMMENTS', false),
            'tags'          => env('MTBLOG_ARTICLE_SHOW_TAGS', false),
            'similar'          => env('MTBLOG_ARTICLE_SHOW_SIMILAR', false),
        ],
    ],
    
    /*
    |--------------------------------------------------------------------------
    | Configuration de l'affichage des options des composants (ex: composant post_card)
    |--------------------------------------------------------------------------
    */

    //composant post.hero
    'post-hero' => [
        'options' => [
            'sidebar'               => env('MTBLOG_HERO_SIDEBAR', true),
            'badge'                 => env('MTBLOG_HERO_BADGE', true),
            'breaking'              => env('MTBLOG_HERO_BREAKING', true),
            'excerpt'               => env('MTBLOG_HERO_EXCERPT', true),
            'meta'                  => env('MTBLOG_HERO_META', true),
            'meta_reading_time'     => env('MTBLOG_HERO_META_READING_TIME', true),
            'read_more'             => env('MTBLOG_HERO_READ_MORE', true),
        ],
    ],

    //composant post.card
    'post-card' => [
        'options' => [
            'image'     => env('MTBLOG_CARD_IMAGE', true),
            'category'  => env('MTBLOG_CARD_CATEGORY', false),
            'author'    => env('MTBLOG_CARD_AUTHOR', false),
            'date'      => env('MTBLOG_CARD_DATE', false),
            'views'     => env('MTBLOG_CARD_VIEWS', false),
            'excerpt'   => env('MTBLOG_CARD_EXCERPT', true),
            'read_more' => env('MTBLOG_CARD_READ_MORE', false),
            'actions'   => env('MTBLOG_CARD_ACTIONS', false),
        ],
    ],


    /*
    |--------------------------------------------------------------------------
    | Types de blocs disponibles pour l'éditeur de contenu   
    |--------------------------------------------------------------------------
    */  
    'blocks' => [
        'paragraph' => 'mtblog::blocks.paragraph',
        'heading'   => 'mtblog::blocks.heading',
        'image'     => 'mtblog::blocks.image'
    ],

    // Middleware à appliquer aux routes du package (ex: auth, admin, etc.)
    'middleware' => ['web','auth'],

];
