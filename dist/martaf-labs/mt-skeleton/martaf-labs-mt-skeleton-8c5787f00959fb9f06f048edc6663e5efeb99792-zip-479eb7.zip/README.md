# mt-skeleton

Skeleton officiel de l'écosystème **martaf-labs**. Crée une application Laravel 13 prête à l'emploi, avec les modules `mt-*` de votre choix installés et configurés automatiquement.

## Prérequis

| Outil | Version minimale |
| ----- | ---------------- |
| PHP | 8.2 |
| Composer | 2.x |
| Node.js | 18+ |

## Démarrage rapide

```bash
composer create-project martaf-labs/mt-skeleton mon-projet
cd mon-projet
```

L'installateur `mt:install` se lance automatiquement et vous guide pour sélectionner les modules à activer.

## Modules disponibles

Les modules s'installent via la commande interactive `php artisan mt:install`. Les dépendances entre modules sont résolues automatiquement.

| Module | Description | Dépend de |
| ------ | ----------- | --------- |
| `mt-foundation` | Socle obligatoire — config, migrations, traductions | — |
| `mt-ui` | Composants Blade et layouts réutilisables | `mt-foundation` |
| `mt-school` | Gestion scolaire (élèves, classes, notes, bulletins) | `mt-foundation`, `mt-ui` |
| `mt-blog` | Blog complet (articles, catégories, tags) | `mt-foundation`, `mt-ui` |
| `mt-docs` | Documentation en ligne au format Markdown | `mt-foundation`, `mt-ui` |

Arbre de dépendances :

```text
mt-foundation
├── mt-ui
│   ├── mt-school
│   ├── mt-blog
│   └── mt-docs
└── mt-icons
```

Pour la documentation détaillée de chaque module, voir [docs/modules.md](docs/modules.md).

## Stack technique

- **Laravel** 13 — framework PHP
- **Livewire** 3 — composants réactifs full-stack
- **Laravel Fortify** — authentification headless
- **Tailwind CSS** 4 + **Vite** — frontend

## Développement

Lancer le serveur, la queue et Vite en parallèle :

```bash
composer run dev
```

Compiler les assets pour la production :

```bash
npm run build
```

## Tests

```bash
composer run test
```

## Linting

```bash
# Corriger automatiquement
composer run lint

# Vérifier sans modifier
composer run lint:check
```

## Variables d'environnement

Copier `.env.example` en `.env` et ajuster selon votre environnement. Par défaut, le projet utilise **SQLite** — aucune configuration de base de données n'est nécessaire pour démarrer.

```bash
cp .env.example .env
php artisan key:generate
```

## Registre Composer

Les packages `martaf-labs/*` sont distribués via un registre Satis privé, déclaré automatiquement dans `composer.json` :

```text
https://martaf-labs.github.io/mt-registry
```

## Licence

MIT — voir le fichier [LICENSE](LICENSE).
