# Documentation des modules

## mt-foundation

Socle **obligatoire** de tout projet martaf-labs.

### Ce qu'il publie

| Ressource | Destination |
|-----------|-------------|
| Configuration | `config/mt.php` |
| Migrations | `database/migrations/` |
| Traductions | `lang/vendor/mt-foundation/` |

### Tag de publication

```bash
php artisan vendor:publish --tag=mt-foundation-config
php artisan vendor:publish --tag=mt-foundation-migrations
php artisan vendor:publish --tag=mt-foundation-lang
```

---

## mt-views

Composants Blade réutilisables et layouts de base.

### Ce qu'il publie

| Ressource | Destination |
|-----------|-------------|
| Composants | `resources/views/vendor/mt-views/` |
| Layouts | `resources/views/layouts/` |
| Configuration | `config/mt-views.php` |

### Dépend de

- `mt-foundation`

---

## mt-school

Module de gestion scolaire complet.

### Ce qu'il publie

| Ressource | Destination |
|-----------|-------------|
| Configuration | `config/mt-school.php` |
| Migrations | `database/migrations/` |
| Vues | `resources/views/vendor/mt-school/` |
| Routes | `routes/mt-school.php` |
| Traductions | `lang/vendor/mt-school/` |

### Activer les routes

Dans `routes/web.php` :

```php
require __DIR__.'/mt-school.php';
```

### Dépend de

- `mt-foundation`
- `mt-views`

### Tables créées

- `students` — Élèves
- `classrooms` — Classes
- `teachers` — Enseignants
- `subjects` — Matières
- `grades` — Notes
- `report_cards` — Bulletins

---

## mt-blog

Module blog complet.

### Dépend de

- `mt-foundation`
- `mt-views`

### Tables créées

- `posts` — Articles
- `categories` — Catégories
- `tags` — Tags
- `post_tag` — Pivot articles/tags

---

## mt-docs

Documentation en ligne au format Markdown.

### Dépend de

- `mt-foundation`
- `mt-views`

---

## Résolution des dépendances

L'installateur résout automatiquement les dépendances.
Si vous sélectionnez `school`, `foundation` et `views` seront installés avant lui, même si vous ne les avez pas explicitement sélectionnés.

```
foundation
    └── views
    │       └── school
    │       └── blog
    │       └── docs
    └── icons
```
