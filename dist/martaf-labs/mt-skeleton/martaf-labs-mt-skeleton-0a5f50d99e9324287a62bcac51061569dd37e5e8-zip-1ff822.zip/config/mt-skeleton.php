<?php

/**
 * Configuration centrale du skeleton martaf-labs.
 *
 * Ce fichier définit les modules disponibles dans l'écosystème,
 * leurs dépendances, et les options globales du projet.
 *
 * Publiable via : php artisan vendor:publish --tag=mt-skeleton-config
 */

return [

    /*
    |--------------------------------------------------------------------------
    | Nom de l'écosystème
    |--------------------------------------------------------------------------
    | Utilisé dans les messages CLI et les en-têtes de fichiers générés.
    */
    'name' => 'martaf-labs',

    /*
    |--------------------------------------------------------------------------
    | Modules disponibles
    |--------------------------------------------------------------------------
    | Chaque module correspond à un package Composer `martaf-labs/mt-*`.
    |
    | Structure de chaque module :
    |   - label       : Nom affiché dans le menu interactif
    |   - package     : Nom du package Composer
    |   - version     : Contrainte de version Composer
    |   - required    : true = toujours installé, non désélectionnable
    |   - depends_on  : Liste des modules requis avant celui-ci
    |   - installer   : Classe PHP chargée de configurer ce module
    |   - description : Explication courte affichée dans le CLI
    */
    'modules' => [

        'foundation' => [
            'label'       => 'mt-foundation (socle commun)',
            'package'     => 'martaf-labs/mt-foundation',
            'version'     => 'dev-main',
            'required'    => true,
            'depends_on'  => [],
            'installer'   => \MtSkeleton\Installers\FoundationInstaller::class,
            'description' => 'Socle obligatoire : helpers, traits, config globale.',
        ],

        'auth' => [
            'label'       => 'mt-auth (authentification)',
            'package'     => 'martaf-labs/mt-auth',
            'version'     => 'dev-main',
            'required'    => true,
            'depends_on'  => ['foundation'],
            'installer'   => \MtSkeleton\Installers\AuthInstaller::class,
            'description' => 'Authentification, utilisateurs, rôles et permissions.',
        ],

        'views' => [
            'label'       => 'mt-views (composants UI)',
            'package'     => 'martaf-labs/mt-views',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation', 'auth'],
            'installer'   => \MtSkeleton\Installers\ViewsInstaller::class,
            'description' => 'Composants Blade réutilisables, layouts, Livewire.',
        ],

        'icons' => [
            'label'       => 'mt-icons (icônes SVG)',
            'package'     => 'martaf-labs/mt-icons',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation'],
            'installer'   => \MtSkeleton\Installers\IconsInstaller::class,
            'description' => 'Système d\'icônes SVG + FontAwesome intégré.',
        ],

        'images' => [
            'label'       => 'mt-images (gestion des images)',
            'package'     => 'martaf-labs/mt-images',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation'],
            'installer'   => \MtSkeleton\Installers\ImagesInstaller::class,
            'description' => 'Upload, optimisation et gestion des images.',
        ],

        'search' => [
            'label'       => 'mt-search (recherche globale)',
            'package'     => 'martaf-labs/mt-search',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation', 'views'],
            'installer'   => \MtSkeleton\Installers\SearchInstaller::class,
            'description' => 'Moteur de recherche global pour tous les modules.',
        ],

        'editor' => [
            'label'       => 'mt-editor (éditeur de texte)',
            'package'     => 'martaf-labs/mt-editor',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation', 'views'],
            'installer'   => \MtSkeleton\Installers\EditorInstaller::class,
            'description' => 'Intégration TinyMCE et éditeurs de texte enrichi.',
        ],

        'school' => [
            'label'       => 'mt-school-core (module scolaire)',
            'package'     => 'martaf-labs/mt-school-core',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation', 'auth', 'views'],
            'installer'   => \MtSkeleton\Installers\SchoolInstaller::class,
            'description' => 'Base de toute application scolaire : élèves, classes, notes.',
        ],

        'blog' => [
            'label'       => 'mt-blog (module blog)',
            'package'     => 'martaf-labs/mt-blog',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation', 'auth', 'views'],
            'installer'   => \MtSkeleton\Installers\BlogInstaller::class,
            'description' => 'Base de tout projet blog/journal : articles, catégories, tags.',
        ],

        'docs' => [
            'label'       => 'mt-docs (documentation)',
            'package'     => 'martaf-labs/mt-docs',
            'version'     => 'dev-main',
            'required'    => false,
            'depends_on'  => ['foundation', 'auth', 'views'],
            'installer'   => \MtSkeleton\Installers\DocsInstaller::class,
            'description' => 'Module de documentation en ligne au format Markdown.',
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Présets (combinaisons prédéfinies de modules)
    |--------------------------------------------------------------------------
    | Permettent de sélectionner rapidement un ensemble cohérent de modules
    | selon le type de projet souhaité.
    |
    | Note : foundation et auth sont toujours inclus automatiquement
    | via la résolution des dépendances, même s'ils ne sont pas
    | listés explicitement dans chaque préset.
    */
    'presets' => [

        'minimal' => [
            'label'   => 'Minimal (foundation + auth)',
            'modules' => ['foundation', 'auth'],
        ],

        'blog' => [
            'label'   => 'Site Blog',
            'modules' => ['foundation', 'auth', 'views', 'icons', 'blog'],
        ],

        'school' => [
            'label'   => 'Application Scolaire',
            'modules' => ['foundation', 'auth', 'views', 'icons', 'school'],
        ],

        'full' => [
            'label'   => 'Écosystème complet',
            'modules' => ['foundation', 'auth', 'views', 'icons', 'images', 'search', 'editor', 'blog', 'school', 'docs'],
        ],

        'custom' => [
            'label'   => 'Personnalisé (choisir manuellement)',
            'modules' => [],
        ],

    ],

];