<?php

namespace MtSkeleton\Console\Commands;

use Illuminate\Console\Command;
use MtSkeleton\Installers\BaseInstaller;

/**
 * InstallCommand
 *
 * Commande Artisan principale du skeleton martaf-labs.
 * Lance un assistant interactif en ligne de commande pour :
 *   1. Choisir un préset (blog, school, full...) ou une sélection manuelle
 *   2. Résoudre automatiquement les dépendances entre modules
 *   3. Installer chaque module via son Installer dédié
 *
 * Usage :
 *   php artisan mt:install
 *   php artisan mt:install --preset=school
 *   php artisan mt:install --preset=custom --modules=foundation,views,blog
 */
class InstallCommand extends Command
{
    /**
     * Signature de la commande avec ses options facultatives.
     */
    protected $signature = 'mt:install
                            {--preset= : Préset à utiliser (minimal, blog, school, full, custom)}
                            {--modules= : Liste de modules séparés par des virgules (ex: foundation,views,blog)}
                            {--force : Réinstaller même si déjà installé}';

    /**
     * Description affichée dans `php artisan list`.
     */
    protected $description = 'Installe l\'écosystème martaf-labs de manière interactive';

    /**
     * Modules disponibles issus de la config.
     */
    protected array $availableModules = [];

    /**
     * Modules sélectionnés pour l'installation.
     */
    protected array $selectedModules = [];

    /**
     * Point d'entrée de la commande.
     */
    public function handle(): int
    {
        $this->availableModules = config('mt-skeleton.modules', []);

        $this->displayBanner();

        // Étape 1 : Sélection des modules (via option ou interactif)
        $this->selectedModules = $this->resolveModuleSelection();

        if (empty($this->selectedModules)) {
            $this->error('Aucun module sélectionné. Installation annulée.');
            return self::FAILURE;
        }

        // Étape 2 : Résolution des dépendances
        $this->selectedModules = $this->resolveDependencies($this->selectedModules);

        // Étape 3 : Confirmation avant installation
        if (! $this->confirmInstallation()) {
            $this->warn('Installation annulée.');
            return self::SUCCESS;
        }

        // Étape 4 : Installation de chaque module
        $this->installModules();

        $this->displaySuccess();

        return self::SUCCESS;
    }

    /**
     * Affiche la bannière de bienvenue du skeleton.
     */
    protected function displayBanner(): void
    {
        $this->newLine();
        $this->line('  <fg=cyan;options=bold>
  ███╗   ███╗████████╗
  ████╗ ████║╚══██╔══╝
  ██╔████╔██║   ██║
  ██║╚██╔╝██║   ██║
  ██║ ╚═╝ ██║   ██║
  ╚═╝     ╚═╝   ╚═╝  martaf-labs skeleton</>');
        $this->newLine();
        $this->line('  <options=bold>Bienvenue dans l\'installateur de l\'écosystème martaf-labs.</>');
        // CORRECTION : Laravel 13+ (était "Laravel 12+")
        $this->line('  Laravel 13+ · PHP 8.2+');
        $this->newLine();
    }

    /**
     * Détermine les modules à installer selon les options passées
     * ou via le menu interactif.
     *
     * @return array Clés des modules sélectionnés (ex: ['foundation', 'views', 'blog'])
     */
    protected function resolveModuleSelection(): array
    {
        // Option --modules= passée directement
        if ($modules = $this->option('modules')) {
            return array_filter(explode(',', $modules));
        }

        // Option --preset= passée directement
        if ($preset = $this->option('preset')) {
            return $this->getPresetModules($preset);
        }

        // Mode interactif : choix du préset
        return $this->askForPreset();
    }

    /**
     * Affiche le menu interactif de sélection du préset.
     *
     * @return array Modules correspondant au préset choisi
     */
    protected function askForPreset(): array
    {
        $presets = config('mt-skeleton.presets', []);

        $this->line('  <options=bold>Quel type de projet souhaitez-vous créer ?</>');
        $this->newLine();

        // Construction du menu de choix
        $choices = [];
        foreach ($presets as $key => $preset) {
            $choices[$key] = $preset['label'];
        }

        $selected = $this->choice(
            '  Choisissez un préset',
            array_values($choices),
            0 // Valeur par défaut : premier préset
        );

        // Retrouver la clé du préset à partir du label sélectionné
        $presetKey = array_search($selected, $choices);

        // Si personnalisé, lancer la sélection manuelle
        if ($presetKey === 'custom') {
            return $this->askForCustomModules();
        }

        return $this->getPresetModules($presetKey);
    }

    /**
     * Permet à l'utilisateur de cocher manuellement les modules voulus.
     * CORRECTION : utilise components->multiselect() disponible depuis Laravel 11+,
     * plus fiable que choice() avec multisélection.
     *
     * @return array Modules sélectionnés manuellement
     */
    protected function askForCustomModules(): array
    {
        $this->newLine();
        $this->line('  <options=bold>Sélectionnez les modules à installer :</>');
        $this->line('  <fg=gray>(mt-foundation est toujours inclus)</>');
        $this->newLine();

        // Construire la liste des modules optionnels
        $optionalModules = array_filter(
            $this->availableModules,
            fn($module) => ! $module['required']
        );

        $choices = [];
        foreach ($optionalModules as $key => $module) {
            $choices[$key] = "{$module['label']} — {$module['description']}";
        }

        // CORRECTION : multiselect() est plus fiable que choice() avec multisélection
        $selected = $this->components->multiselect(
            '  Modules à installer',
            $choices
        );

        // Retrouver les clés des modules sélectionnés
        $selectedKeys = [];
        foreach ($selected as $label) {
            $key = array_search($label, $choices);
            if ($key !== false) {
                $selectedKeys[] = $key;
            }
        }

        // Ajouter foundation obligatoirement
        return array_unique(array_merge(['foundation'], $selectedKeys));
    }

    /**
     * Retourne la liste des modules pour un préset donné.
     *
     * @param string $presetKey Clé du préset (ex: 'school')
     * @return array
     */
    protected function getPresetModules(string $presetKey): array
    {
        $presets = config('mt-skeleton.presets', []);

        if (! isset($presets[$presetKey])) {
            $this->error("Préset inconnu : {$presetKey}");
            return [];
        }

        return $presets[$presetKey]['modules'];
    }

    /**
     * Résout les dépendances entre modules.
     * Si l'utilisateur choisit 'blog', on ajoute automatiquement
     * 'foundation' et 'views' s'ils ne sont pas déjà sélectionnés.
     *
     * @param array $modules Modules initialement sélectionnés
     * @return array Modules avec dépendances résolues (triés par ordre d'installation)
     */
    protected function resolveDependencies(array $modules): array
    {
        $resolved = [];

        $resolve = function (string $moduleKey) use (&$resolve, &$resolved) {
            // Éviter les doublons et les boucles infinies
            if (in_array($moduleKey, $resolved)) {
                return;
            }

            $module = $this->availableModules[$moduleKey] ?? null;

            if (! $module) {
                $this->warn("Module inconnu ignoré : {$moduleKey}");
                return;
            }

            // Résoudre d'abord les dépendances de ce module
            foreach ($module['depends_on'] as $dependency) {
                $resolve($dependency);
            }

            $resolved[] = $moduleKey;
        };

        // Toujours commencer par foundation
        $resolve('foundation');

        foreach ($modules as $moduleKey) {
            $resolve($moduleKey);
        }

        return $resolved;
    }

    /**
     * Affiche le récapitulatif et demande confirmation avant installation.
     *
     * @return bool true si l'utilisateur confirme
     */
    protected function confirmInstallation(): bool
    {
        $this->newLine();
        $this->line('  <options=bold>Modules qui seront installés :</>');
        $this->newLine();

        foreach ($this->selectedModules as $moduleKey) {
            $module = $this->availableModules[$moduleKey];
            $required = $module['required'] ? ' <fg=yellow>(obligatoire)</>' : '';
            $this->line("  <fg=green>✓</> {$module['label']}{$required}");
            $this->line("    <fg=gray>{$module['description']}</>");
        }

        $this->newLine();

        return $this->confirm('  Confirmer l\'installation ?', true);
    }

    /**
     * Lance l'installation de chaque module sélectionné,
     * dans l'ordre résolu (dépendances en premier).
     */
    protected function installModules(): void
    {
        $this->newLine();
        $this->line('  <options=bold>Installation en cours...</>');
        $this->newLine();

        foreach ($this->selectedModules as $moduleKey) {
            $module = $this->availableModules[$moduleKey];

            $this->line("  <fg=cyan>→</> Installation de <options=bold>{$module['label']}</>...");

            try {
                // Instancier et exécuter l'installer du module
                $installer = new $module['installer']($this);
                $installer->install(force: $this->option('force') ?? false);

                $this->line("  <fg=green>✓</> {$module['label']} installé avec succès.");

            } catch (\Throwable $e) {
                $this->error("  ✗ Erreur lors de l'installation de {$module['label']} : {$e->getMessage()}");
                $this->line("  <fg=gray>  Trace : {$e->getFile()}:{$e->getLine()}</>");
            }

            $this->newLine();
        }
    }

    /**
     * Affiche le message de succès final avec les prochaines étapes.
     */
    protected function displaySuccess(): void
    {
        $this->line('  <fg=green;options=bold>✓ Installation terminée !</>');
        $this->newLine();
        $this->line('  <options=bold>Prochaines étapes :</>');
        $this->line('  1. Configurez votre fichier <fg=yellow>.env</>');
        $this->line('  2. Lancez <fg=yellow>php artisan migrate</>');
        $this->line('  3. Lancez <fg=yellow>npm install && npm run dev</>');
        $this->line('  4. Démarrez avec <fg=yellow>php artisan serve</>');
        $this->newLine();
        $this->line('  Documentation : <fg=cyan>https://docs.martaf-labs.dev</>');
        $this->newLine();
    }
}
