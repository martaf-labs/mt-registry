<?php

namespace MtSkeleton\Installers;

/**
 * FoundationInstaller
 *
 * Installer du module mt-foundation.
 * Ce module est obligatoire et constitue le socle de tout projet martaf-labs.
 *
 * Il s'occupe de :
 *   - Installer le package via Composer si absent
 *   - Publier la configuration principale
 *   - Publier les migrations
 *   - Publier les fichiers de traduction (fr, en, ar)
 *   - Copier le stub de configuration globale
 */
class FoundationInstaller extends BaseInstaller
{
    /**
     * Installation de mt-foundation.
     *
     * @param bool $force Écraser les fichiers existants si true
     */
    public function install(bool $force = false): void
    {
        // 1. Installer le package via Composer si pas encore présent
        //    → Nécessaire quand mt:module est appelé après l'installation initiale
        if (! $this->isPackageInstalled('martaf-labs/mt-foundation')) {
            $this->requireComposerPackage('martaf-labs/mt-foundation');
        }

        // 2. Publier la configuration principale du package
        //    → Génère config/mt-foundation.php dans le projet
        $this->publish('mt-foundation-config', $force);

        // 3. Publier les migrations du package
        //    → Copie les migrations dans database/migrations/
        //    → Permet au développeur de les modifier avant de les exécuter
        $this->publish('mt-foundation-migrations', $force);

        // 4. Publier les fichiers de traduction
        //    → lang/vendor/mt/mt-foundation/{fr,en,ar}/
        $this->publish('mt-foundation-lang', $force);

        // 5. Copier le stub de configuration globale de l'app
        //    → config/app-mt.php : préférences globales de l'écosystème
        $this->copyStub(
            stubPath: 'config/app-mt.php',
            destPath: 'config/app-mt.php',
            force: $force
        );

        $this->success('mt-foundation configuré avec succès.');
    }
}