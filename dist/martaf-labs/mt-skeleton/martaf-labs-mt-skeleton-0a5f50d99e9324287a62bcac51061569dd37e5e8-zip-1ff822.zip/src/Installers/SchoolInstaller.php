<?php

namespace MtSkeleton\Installers;

/**
 * SchoolInstaller
 *
 * Installer du module mt-school-core.
 * Ce module fournit la base de toute application de gestion scolaire.
 *
 * Il s'occupe de :
 *   - Installer le package via Composer si absent
 *   - Publier la configuration mt-school-core.php
 *   - Publier les migrations (élèves, classes, notes, bulletins...)
 *   - Publier les vues Blade du module
 *   - Publier les assets CSS/JS
 *   - Publier les fichiers de traduction (fr, en, ar)
 *   - Copier les routes du module dans routes/
 *   - Copier les stubs de contrôleurs de démarrage
 *
 * Prérequis : FoundationInstaller, AuthInstaller et ViewsInstaller
 *             doivent être exécutés avant.
 */
class SchoolInstaller extends BaseInstaller
{
    /**
     * Installation de mt-school-core.
     *
     * @param bool $force Écraser les fichiers existants si true
     */
    public function install(bool $force = false): void
    {
        // 1. Installer le package via Composer si pas encore présent
        if (! $this->isPackageInstalled('martaf-labs/mt-school-core')) {
            $this->requireComposerPackage('martaf-labs/mt-school-core');
        }

        // 2. Configuration du module
        //    → Génère config/mt-school-core.php dans le projet
        $this->publish('mt-school-core-config', $force);

        // 3. Migrations de la base de données
        //    → Tables : students, classrooms, teachers,
        //               subjects, grades, report_cards...
        $this->publish('mt-school-core-migrations', $force);

        // 4. Vues Blade du module
        //    → resources/views/vendor/mt/mt-school-core/
        $this->publish('mt-school-core-views', $force);

        // 5. Assets CSS/JS spécifiques au module
        //    → public/vendor/mt/mt-school-core/
        $this->publish('mt-school-core-assets', $force);

        // 6. Fichiers de traduction
        //    → lang/vendor/mt/mt-school-core/{fr,en,ar}/
        $this->publish('mt-school-core-lang', $force);

        // 7. Copier le fichier de routes du module dans le projet
        //    → routes/mt-school.php
        //    → À inclure dans routes/web.php via :
        //      require __DIR__.'/mt-school.php';
        $this->copyStub(
            stubPath: 'routes/mt-school.php',
            destPath: 'routes/mt-school.php',
            force: $force
        );

        // 8. Copier le contrôleur de tableau de bord de démarrage
        //    → app/Http/Controllers/School/DashboardController.php
        $this->copyStub(
            stubPath: 'controllers/School/DashboardController.php',
            destPath: 'app/Http/Controllers/School/DashboardController.php',
            force: $force,
            replacements: [
                '{{NAMESPACE}}' => 'App\\Http\\Controllers\\School',
            ]
        );

        // 9. Rappels importants pour le développeur
        $this->info("Ajoutez dans routes/web.php :");
        $this->info("require __DIR__.'/mt-school.php';");
        $this->info("Lancez ensuite : php artisan migrate");

        $this->success('mt-school-core configuré avec succès.');
    }
}