<?php

namespace MtSkeleton\Installers;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

/**
 * BaseInstaller
 *
 * Classe abstraite dont héritent tous les installers de modules mt-*.
 * Fournit les méthodes utilitaires communes :
 *   - Publication de fichiers de config via vendor:publish
 *   - Exécution de commandes Artisan
 *   - Copie de stubs depuis le package vers le projet
 *   - Installation de packages Composer
 *   - Vérification de packages installés
 *   - Messages formatés dans le terminal
 *
 * Chaque module (foundation, auth, blog, school...) possède son propre
 * Installer qui étend cette classe et implémente `install()`.
 */
abstract class BaseInstaller
{
    /**
     * Instance de la commande Artisan parente (pour l'affichage CLI).
     */
    protected Command $command;

    /**
     * @param Command $command Commande Artisan qui a déclenché l'installation
     */
    public function __construct(Command $command)
    {
        $this->command = $command;
    }

    /**
     * Point d'entrée de l'installation du module.
     * Doit être implémenté par chaque Installer enfant.
     *
     * @param bool $force Forcer la réinstallation si déjà présent
     */
    abstract public function install(bool $force = false): void;

    // =========================================================================
    // Méthodes utilitaires disponibles dans tous les installers
    // =========================================================================

    /**
     * Publie les ressources d'un package via `vendor:publish`.
     *
     * Utilise --no-interaction pour éviter les confirmations en CLI.
     * Le tag doit correspondre à un tag déclaré dans le ServiceProvider
     * du package concerné (ex: 'mt-foundation-config').
     *
     * @param string $tag   Tag de publication (ex: 'mt-foundation-config')
     * @param bool   $force Écraser les fichiers existants
     */
    protected function publish(string $tag, bool $force = false): void
    {
        $params = [
            '--tag'              => $tag,
            '--no-interaction'   => true,
        ];

        if ($force) {
            $params['--force'] = true;
        }

        $this->command->callSilent('vendor:publish', $params);

        $this->info("Ressources publiées : {$tag}");
    }

    /**
     * Exécute une commande Artisan silencieusement.
     *
     * Utilise callSilent pour ne pas polluer la sortie principale.
     * Les erreurs sont absorbées — à utiliser pour des commandes
     * non critiques (migrate, optimize, etc.).
     *
     * @param string $command   Nom de la commande (ex: 'migrate')
     * @param array  $arguments Arguments à passer à la commande
     */
    protected function artisan(string $command, array $arguments = []): void
    {
        $this->command->callSilent($command, $arguments);
        $this->info("Commande exécutée : php artisan {$command}");
    }

    /**
     * Copie un stub depuis le package vers le projet cible.
     *
     * Les stubs sont stockés dans le dossier stubs/ du package mt-skeleton,
     * publié via vendor:publish --tag=mt-skeleton-stubs.
     *
     * Priorité de recherche du stub :
     *   1. stubs/mt/{stubPath} dans le projet (stub personnalisé par le dev)
     *   2. Le dossier stubs/ du package mt-skeleton lui-même
     *
     * @param string $stubPath     Chemin du stub (ex: 'routes/mt-school.php')
     * @param string $destPath     Destination dans le projet (ex: 'routes/mt-school.php')
     * @param bool   $force        Écraser si déjà existant
     * @param array  $replacements Remplacements de variables dans le stub
     *                             (ex: ['{{NAMESPACE}}' => 'App\\Http\\Controllers'])
     */
    protected function copyStub(
        string $stubPath,
        string $destPath,
        bool $force = false,
        array $replacements = []
    ): void {
        // Priorité 1 : stub personnalisé dans le projet
        $projectStub = base_path("stubs/mt/{$stubPath}");

        // Priorité 2 : stub du package mt-skeleton
        $packageStub = dirname(__DIR__, 2) . "/stubs/{$stubPath}";

        // Choisir la source disponible
        $source = File::exists($projectStub) ? $projectStub : $packageStub;

        if (! File::exists($source)) {
            $this->warn("Stub introuvable : {$stubPath}");
            return;
        }

        $destination = base_path($destPath);

        // Ne pas écraser si déjà présent (sauf si force)
        if (File::exists($destination) && ! $force) {
            $this->warn("Fichier déjà existant (ignoré) : {$destPath}");
            return;
        }

        // Créer le dossier destination si nécessaire
        File::ensureDirectoryExists(dirname($destination));

        // Lire et appliquer les remplacements de variables
        $content = File::get($source);

        if (! empty($replacements)) {
            $content = str_replace(
                array_keys($replacements),
                array_values($replacements),
                $content
            );
        }

        File::put($destination, $content);

        $this->info("Fichier créé : {$destPath}");
    }

    /**
     * Installe un package Composer via `composer require`.
     *
     * Utilisé pour ajouter dynamiquement un package mt-* au projet
     * quand l'utilisateur sélectionne un module dans le menu interactif.
     *
     * @param string $package Nom du package (ex: 'martaf-labs/mt-blog')
     * @param string $version Contrainte de version (ex: 'dev-main')
     * @param bool   $dev     Installer en require-dev
     */
    protected function requireComposerPackage(
        string $package,
        string $version = 'dev-main',
        bool $dev = false
    ): void {
        $this->info("Installation Composer : {$package}:{$version}...");

        $command = array_filter([
            'composer',
            'require',
            "{$package}:{$version}",
            $dev ? '--dev' : null,
            '--no-interaction',
            '--no-progress',
            '--quiet',
        ]);

        $process = new \Symfony\Component\Process\Process(
            array_values($command),
            base_path(),
            null,
            null,
            null // Pas de timeout
        );

        $process->run();

        if (! $process->isSuccessful()) {
            $this->error("Échec de l'installation de {$package} : {$process->getErrorOutput()}");
            return;
        }

        $this->info("Package installé : {$package}");
    }

    /**
     * Vérifie si un package Composer est déjà installé dans le projet.
     *
     * Lit le composer.lock pour vérifier la présence du package,
     * ce qui garantit qu'il est réellement installé (pas seulement requis).
     *
     * @param string $package Nom du package (ex: 'martaf-labs/mt-blog')
     * @return bool
     */
    protected function isPackageInstalled(string $package): bool
    {
        $composerLock = base_path('composer.lock');

        if (! File::exists($composerLock)) {
            return false;
        }

        $lock = json_decode(File::get($composerLock), true);

        $packages = array_merge(
            $lock['packages'] ?? [],
            $lock['packages-dev'] ?? []
        );

        foreach ($packages as $installed) {
            if (($installed['name'] ?? '') === $package) {
                return true;
            }
        }

        return false;
    }

    // =========================================================================
    // Méthodes d'affichage dans le terminal
    // =========================================================================

    /**
     * Affiche un message de succès (texte vert indenté).
     */
    protected function success(string $message): void
    {
        $this->command->line("    <fg=green>✓ {$message}</>");
    }

    /**
     * Affiche un message d'information (texte gris indenté).
     */
    protected function info(string $message): void
    {
        $this->command->line("    <fg=gray>→ {$message}</>");
    }

    /**
     * Affiche un avertissement (texte jaune indenté).
     */
    protected function warn(string $message): void
    {
        $this->command->line("    <fg=yellow>⚠ {$message}</>");
    }

    /**
     * Affiche une erreur (texte rouge indenté).
     */
    protected function error(string $message): void
    {
        $this->command->line("    <fg=red>✗ {$message}</>");
    }
}