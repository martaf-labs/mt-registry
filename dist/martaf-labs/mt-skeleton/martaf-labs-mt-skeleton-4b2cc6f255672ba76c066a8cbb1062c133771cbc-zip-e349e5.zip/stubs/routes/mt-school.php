<?php

/**
 * Routes du module mt-school
 *
 * Ce fichier est publié par l'installateur de mt-school.
 * Il définit toutes les routes de l'application scolaire.
 *
 * Pour l'activer, ajoutez dans routes/web.php :
 *   require __DIR__.'/mt-school.php';
 *
 * Ou via le RouteServiceProvider :
 *   Route::middleware('web')->group(base_path('routes/mt-school.php'));
 */

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\School\DashboardController;

/*
|--------------------------------------------------------------------------
| Routes du tableau de bord
|--------------------------------------------------------------------------
*/
Route::middleware(['web', 'auth'])->prefix('school')->name('school.')->group(function () {

    // Tableau de bord principal
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    /*
    |--------------------------------------------------------------------------
    | Gestion des élèves
    |--------------------------------------------------------------------------
    | Décommentez et adaptez selon vos contrôleurs
    */
    // Route::resource('students', StudentController::class);

    /*
    |--------------------------------------------------------------------------
    | Gestion des classes
    |--------------------------------------------------------------------------
    */
    // Route::resource('classrooms', ClassroomController::class);

    /*
    |--------------------------------------------------------------------------
    | Gestion des notes
    |--------------------------------------------------------------------------
    */
    // Route::resource('grades', GradeController::class);

    /*
    |--------------------------------------------------------------------------
    | Bulletins scolaires
    |--------------------------------------------------------------------------
    */
    // Route::get('report-cards', [ReportCardController::class, 'index'])->name('report-cards.index');
    // Route::get('report-cards/{student}', [ReportCardController::class, 'show'])->name('report-cards.show');

});
