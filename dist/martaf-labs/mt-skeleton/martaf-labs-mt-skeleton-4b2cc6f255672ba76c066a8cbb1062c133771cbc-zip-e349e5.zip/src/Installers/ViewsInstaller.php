<?php

namespace MtSkeleton\Installers;

/**
 * ViewsInstaller
 *
 * Installer du module mt-views.
 * Publie les composants Blade réutilisables et les layouts de base.
 */
class ViewsInstaller extends BaseInstaller
{
    public function install(bool $force = false): void
    {
        // Configuration (pagination, thème, etc.)
        $this->publish('mt-views-config', $force);

        // Composants Blade → resources/views/vendor/mt-views/
        $this->publish('mt-views-components', $force);

        // Layouts de base (app.blade.php, guest.blade.php...)
        $this->publish('mt-views-layouts', $force);
    }
}
