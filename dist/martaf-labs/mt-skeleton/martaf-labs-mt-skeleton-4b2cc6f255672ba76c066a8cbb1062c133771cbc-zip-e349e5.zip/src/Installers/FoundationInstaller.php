<?php

namespace MtSkeleton\Installers;

/**
 * FoundationInstaller
 *
 * Installer du module mt-foundation.
 * Ce module est obligatoire et constitue le socle de tout projet martaf-labs.
 *
 * Il s'occupe de :
 *   - Publier la configuration globale mt.php
 *   - Publier les helpers et traits de base
 *   - Créer le fichier de langue fr par défaut
 */
class FoundationInstaller extends BaseInstaller
{
    /**
     * Installation de mt-foundation.
     *
     * @param bool $force Écraser les fichiers existants si true
     */
    public function install(bool $force = false): void
    {
        // 1. Publier la configuration principale du package
        //    → Génère config/mt.php dans le projet
        $this->publish('mt-foundation-config', $force);

        // 2. Publier les migrations du package
        //    → Permet de les modifier avant de les exécuter
        $this->publish('mt-foundation-migrations', $force);

        // 3. Publier les fichiers de traduction
        //    → lang/vendor/mt-foundation/fr/*.php
        $this->publish('mt-foundation-lang', $force);

        // 4. Copier le stub de configuration globale de l'app si absent
        //    → Fichier de référence pour les préférences du développeur
        $this->copyStub(
            stubPath: 'config/app-mt.php',
            destPath: 'config/app-mt.php',
            force: $force
        );
    }
}
