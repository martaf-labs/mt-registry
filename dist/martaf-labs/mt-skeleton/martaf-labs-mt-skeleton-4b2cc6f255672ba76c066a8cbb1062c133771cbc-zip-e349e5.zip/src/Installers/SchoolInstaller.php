<?php

namespace MtSkeleton\Installers;

/**
 * SchoolInstaller
 *
 * Installer du module mt-school.
 * Ce module transforme le projet Laravel en application de gestion scolaire.
 *
 * Il s'occupe de :
 *   - Publier la configuration mt-school.php
 *   - Publier les migrations (élèves, classes, notes, bulletins...)
 *   - Publier les vues Blade du module
 *   - Copier les routes du module dans routes/
 *   - Copier les stubs de contrôleurs de démarrage
 *
 * Prérequis : FoundationInstaller et ViewsInstaller doivent être exécutés avant.
 */
class SchoolInstaller extends BaseInstaller
{
    /**
     * Installation de mt-school.
     *
     * @param bool $force Écraser les fichiers existants si true
     */
    public function install(bool $force = false): void
    {
        // 1. Configuration du module
        //    → Génère config/mt-school.php (rôles, paramètres scolaires, etc.)
        $this->publish('mt-school-config', $force);

        // 2. Migrations de la base de données
        //    → Tables : students, classrooms, teachers, grades, report_cards...
        $this->publish('mt-school-migrations', $force);

        // 3. Vues Blade du module
        //    → resources/views/vendor/mt-school/
        $this->publish('mt-school-views', $force);

        // 4. Assets (CSS/JS spécifiques au module si présents)
        $this->publish('mt-school-assets', $force);

        // 5. Fichiers de langue
        //    → lang/vendor/mt-school/fr/*.php
        $this->publish('mt-school-lang', $force);

        // 6. Copier le fichier de routes du module dans le projet
        //    → routes/mt-school.php (à inclure manuellement dans routes/web.php)
        $this->copyStub(
            stubPath: 'routes/mt-school.php',
            destPath: 'routes/mt-school.php',
            force: $force
        );

        // 7. Copier des contrôleurs de démarrage (optionnel mais utile)
        //    → app/Http/Controllers/School/DashboardController.php
        $this->copyStub(
            stubPath: 'controllers/School/DashboardController.php',
            destPath: 'app/Http/Controllers/School/DashboardController.php',
            force: $force,
            replacements: [
                '{{NAMESPACE}}' => 'App\\Http\\Controllers\\School',
            ]
        );

        // 8. Informer le développeur d'inclure les routes manuellement
        $this->info("N'oubliez pas d'inclure les routes dans routes/web.php :");
        $this->info("require __DIR__.'/mt-school.php';");
    }
}
