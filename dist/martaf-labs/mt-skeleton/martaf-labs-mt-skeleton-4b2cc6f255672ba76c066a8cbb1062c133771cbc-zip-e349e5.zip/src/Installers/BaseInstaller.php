<?php

namespace MtSkeleton\Installers;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

/**
 * BaseInstaller
 *
 * Classe abstraite dont héritent tous les installers de modules mt-*.
 * Fournit les méthodes utilitaires communes :
 *   - Publication de fichiers de config
 *   - Exécution de commandes Artisan
 *   - Copie de stubs
 *   - Messages formatés dans le terminal
 *
 * Chaque module (foundation, blog, school...) possède son propre
 * Installer qui étend cette classe et implémente `install()`.
 */
abstract class BaseInstaller
{
    /**
     * Instance de la commande Artisan parente (pour l'affichage CLI).
     */
    protected Command $command;

    /**
     * @param Command $command Commande Artisan qui a déclenché l'installation
     */
    public function __construct(Command $command)
    {
        $this->command = $command;
    }

    /**
     * Point d'entrée de l'installation du module.
     * Doit être implémenté par chaque Installer enfant.
     *
     * @param bool $force Forcer la réinstallation si déjà présent
     */
    abstract public function install(bool $force = false): void;

    // =========================================================================
    // Méthodes utilitaires disponibles dans tous les installers
    // =========================================================================

    /**
     * Publie les ressources d'un package via `vendor:publish`.
     *
     * @param string $tag  Tag de publication (ex: 'mt-foundation-config')
     * @param bool   $force Écraser les fichiers existants
     */
    protected function publish(string $tag, bool $force = false): void
    {
        $params = ['--tag' => $tag, '--quiet' => true];

        if ($force) {
            $params['--force'] = true;
        }

        $this->command->callSilent('vendor:publish', $params);

        $this->info("Ressources publiées : {$tag}");
    }

    /**
     * Exécute une commande Artisan silencieusement.
     * Utilise `callSilent` pour ne pas polluer la sortie principale.
     *
     * @param string $command  Nom de la commande (ex: 'migrate')
     * @param array  $arguments Arguments à passer
     */
    protected function artisan(string $command, array $arguments = []): void
    {
        $this->command->callSilent($command, $arguments);
        $this->info("Commande exécutée : php artisan {$command}");
    }

    /**
     * Copie un stub dans le projet cible si le fichier destination n'existe pas.
     * Utile pour générer des fichiers de démarrage (contrôleurs, modèles, vues...).
     *
     * @param string $stubPath  Chemin du stub source (relatif à /stubs)
     * @param string $destPath  Chemin de destination dans le projet (relatif à base_path)
     * @param bool   $force     Écraser si existant
     * @param array  $replacements Tableau de remplacement dans le stub (ex: ['{{NAME}}' => 'Blog'])
     */
    protected function copyStub(
        string $stubPath,
        string $destPath,
        bool $force = false,
        array $replacements = []
    ): void {
        $source      = base_path("stubs/mt/{$stubPath}");
        $destination = base_path($destPath);

        // Vérifier que le stub source existe
        if (! File::exists($source)) {
            $this->warn("Stub introuvable : {$stubPath}");
            return;
        }

        // Ne pas écraser si déjà présent (sauf force)
        if (File::exists($destination) && ! $force) {
            $this->warn("Fichier déjà existant (ignoré) : {$destPath}");
            return;
        }

        // Créer le dossier destination si nécessaire
        File::ensureDirectoryExists(dirname($destination));

        // Lire le contenu du stub
        $content = File::get($source);

        // Appliquer les remplacements de variables dans le stub
        if (! empty($replacements)) {
            $content = str_replace(
                array_keys($replacements),
                array_values($replacements),
                $content
            );
        }

        // Écrire le fichier destination
        File::put($destination, $content);

        $this->info("Fichier créé : {$destPath}");
    }

    /**
     * Vérifie si un package Composer est installé.
     *
     * @param string $package Nom du package (ex: 'martaf-labs/mt-blog')
     * @return bool
     */
    protected function isPackageInstalled(string $package): bool
    {
        $composerLock = base_path('composer.lock');

        if (! File::exists($composerLock)) {
            return false;
        }

        $lock = json_decode(File::get($composerLock), true);

        $packages = array_merge(
            $lock['packages'] ?? [],
            $lock['packages-dev'] ?? []
        );

        foreach ($packages as $installed) {
            if (($installed['name'] ?? '') === $package) {
                return true;
            }
        }

        return false;
    }

    // =========================================================================
    // Méthodes d'affichage dans le terminal
    // =========================================================================

    /**
     * Affiche un message d'information (texte gris indenté).
     */
    protected function info(string $message): void
    {
        $this->command->line("    <fg=gray>→ {$message}</>");
    }

    /**
     * Affiche un avertissement (texte jaune indenté).
     */
    protected function warn(string $message): void
    {
        $this->command->line("    <fg=yellow>⚠ {$message}</>");
    }

    /**
     * Affiche une erreur (texte rouge indenté).
     */
    protected function error(string $message): void
    {
        $this->command->line("    <fg=red>✗ {$message}</>");
    }
}
