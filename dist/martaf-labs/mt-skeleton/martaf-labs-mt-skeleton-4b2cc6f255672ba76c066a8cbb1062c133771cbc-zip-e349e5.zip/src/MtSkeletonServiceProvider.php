<?php

namespace MtSkeleton;

use Illuminate\Support\ServiceProvider;
use MtSkeleton\Console\Commands\InstallCommand;
use MtSkeleton\Console\Commands\MakeModuleCommand;

/**
 * MtSkeletonServiceProvider
 *
 * Point d'entrée principal du skeleton martaf-labs.
 * Enregistre les commandes Artisan et publie les ressources
 * nécessaires à l'installation de l'écosystème.
 */
class MtSkeletonServiceProvider extends ServiceProvider
{
    /**
     * Enregistre les services du skeleton dans le conteneur IoC.
     * Appelé avant boot(), idéal pour les bindings simples.
     */
    public function register(): void
    {
        // Fusion de la configuration du skeleton avec celle de l'app
        $this->mergeConfigFrom(
            __DIR__ . '/../config/mt-skeleton.php',
            'mt-skeleton'
        );
    }

    /**
     * Démarre les services du skeleton.
     * Appelé après register(), une fois tous les providers chargés.
     */
    public function boot(): void
    {
        // Enregistrement des commandes Artisan uniquement en CLI
        if ($this->app->runningInConsole()) {
            $this->registerCommands();
            $this->registerPublishables();
        }
    }

    /**
     * Enregistre les commandes Artisan disponibles dans le skeleton.
     */
    protected function registerCommands(): void
    {
        $this->commands([
            // Commande principale d'installation interactive
            InstallCommand::class,

            // Commande pour ajouter un module mt-* après installation
            MakeModuleCommand::class,
        ]);
    }

    /**
     * Déclare les ressources publiables via `php artisan vendor:publish`.
     * Chaque groupe peut être publié indépendamment grâce au tag.
     */
    protected function registerPublishables(): void
    {
        // Configuration globale du skeleton
        $this->publishes([
            __DIR__ . '/../config/mt-skeleton.php' => config_path('mt-skeleton.php'),
        ], 'mt-skeleton-config');

        // Stubs personnalisables par le développeur
        $this->publishes([
            __DIR__ . '/../stubs' => base_path('stubs/mt'),
        ], 'mt-skeleton-stubs');
    }
}
