<?php

/**
 * Configuration centrale du skeleton martaf-labs.
 *
 * Ce fichier définit les modules disponibles dans l'écosystème,
 * leurs dépendances, et les options globales du projet.
 *
 * Publiable via : php artisan vendor:publish --tag=mt-skeleton-config
 */

return [

    /*
    |--------------------------------------------------------------------------
    | Nom de l'écosystème
    |--------------------------------------------------------------------------
    | Utilisé dans les messages CLI et les en-têtes de fichiers générés.
    */
    'name' => 'martaf-labs',

    /*
    |--------------------------------------------------------------------------
    | Modules disponibles
    |--------------------------------------------------------------------------
    | Chaque module correspond à un package Composer `martaf-labs/mt-*`.
    |
    | Structure de chaque module :
    |   - label       : Nom affiché dans le menu interactif
    |   - package     : Nom du package Composer
    |   - version     : Contrainte de version Composer
    |   - required    : true = toujours installé, non désélectionnable
    |   - depends_on  : Liste des modules requis avant celui-ci
    |   - installer   : Classe PHP chargée de configurer ce module
    |   - description : Explication courte affichée dans le CLI
    */
    'modules' => [

        'foundation' => [
            'label'       => 'mt-foundation (socle commun)',
            'package'     => 'martaf-labs/mt-foundation',
            'version'     => '^1.0',
            'required'    => true,
            'depends_on'  => [],
            'installer'   => \MtSkeleton\Installers\FoundationInstaller::class,
            'description' => 'Socle obligatoire : helpers, traits, config globale.',
        ],

        'views' => [
            'label'       => 'mt-views (composants UI)',
            'package'     => 'martaf-labs/mt-views',
            'version'     => '^1.0',
            'required'    => false,
            'depends_on'  => ['foundation'],
            'installer'   => \MtSkeleton\Installers\ViewsInstaller::class,
            'description' => 'Composants Blade réutilisables, layouts de base.',
        ],

        'icons' => [
            'label'       => 'mt-icons (icônes SVG)',
            'package'     => 'martaf-labs/mt-icons',
            'version'     => '^1.0',
            'required'    => false,
            'depends_on'  => ['foundation'],
            'installer'   => \MtSkeleton\Installers\IconsInstaller::class,
            'description' => 'Système d\'icônes SVG intégré.',
        ],

        'blog' => [
            'label'       => 'mt-blog (module blog)',
            'package'     => 'martaf-labs/mt-blog',
            'version'     => '^1.0',
            'required'    => false,
            'depends_on'  => ['foundation', 'views'],
            'installer'   => \MtSkeleton\Installers\BlogInstaller::class,
            'description' => 'Blog complet : articles, catégories, tags, auteurs.',
        ],

        'school' => [
            'label'       => 'mt-school (application scolaire)',
            'package'     => 'martaf-labs/mt-school',
            'version'     => '^1.0',
            'required'    => false,
            'depends_on'  => ['foundation', 'views'],
            'installer'   => \MtSkeleton\Installers\SchoolInstaller::class,
            'description' => 'Gestion scolaire : élèves, classes, notes, bulletins.',
        ],

        'docs' => [
            'label'       => 'mt-docs (documentation)',
            'package'     => 'martaf-labs/mt-docs',
            'version'     => '^1.0',
            'required'    => false,
            'depends_on'  => ['foundation', 'views'],
            'installer'   => \MtSkeleton\Installers\DocsInstaller::class,
            'description' => 'Module de documentation en ligne (Markdown).',
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Présets (combinaisons prédéfinies de modules)
    |--------------------------------------------------------------------------
    | Permettent de sélectionner rapidement un ensemble cohérent de modules
    | selon le type de projet souhaité.
    */
    'presets' => [

        'minimal' => [
            'label'   => 'Minimal (foundation uniquement)',
            'modules' => ['foundation'],
        ],

        'blog' => [
            'label'   => 'Site Blog',
            'modules' => ['foundation', 'views', 'icons', 'blog'],
        ],

        'school' => [
            'label'   => 'Application Scolaire',
            'modules' => ['foundation', 'views', 'icons', 'school'],
        ],

        'full' => [
            'label'   => 'Écosystème complet',
            'modules' => ['foundation', 'views', 'icons', 'blog', 'school', 'docs'],
        ],

        'custom' => [
            'label'   => 'Personnalisé (choisir manuellement)',
            'modules' => [],
        ],

    ],

];
