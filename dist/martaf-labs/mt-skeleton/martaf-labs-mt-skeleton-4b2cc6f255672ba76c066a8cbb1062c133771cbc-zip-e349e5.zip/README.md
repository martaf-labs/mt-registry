# mt-skeleton

> Skeleton officiel de l'écosystème **martaf-labs** pour Laravel 12+.

Permet de créer rapidement une application Laravel en sélectionnant les modules `mt-*` souhaités via un installateur interactif en ligne de commande.

---

## Prérequis

- PHP **8.2+**
- Composer **2.x**
- Laravel **12+**
- Node.js **18+** (pour les assets)

---

## Création d'un nouveau projet

```bash
composer create-project martaf-labs/mt-skeleton nom-du-projet
cd nom-du-projet
```

L'installateur interactif se lance automatiquement après la création du projet.

---

## Installation interactive

Si vous souhaitez relancer l'installateur :

```bash
php artisan mt:install
```

### Avec un préset

```bash
# Application scolaire
php artisan mt:install --preset=school

# Site blog
php artisan mt:install --preset=blog

# Écosystème complet
php artisan mt:install --preset=full

# Sélection manuelle
php artisan mt:install --preset=custom
```

### Avec une liste de modules

```bash
php artisan mt:install --modules=foundation,views,school
```

---

## Ajouter un module après installation

```bash
php artisan mt:module blog
php artisan mt:module docs --force
```

---

## Modules disponibles

| Module | Package | Description |
|--------|---------|-------------|
| `foundation` | `martaf-labs/mt-foundation` | Socle obligatoire (helpers, traits, config) |
| `views` | `martaf-labs/mt-views` | Composants Blade, layouts |
| `icons` | `martaf-labs/mt-icons` | Système d'icônes SVG |
| `blog` | `martaf-labs/mt-blog` | Blog complet (articles, catégories, tags) |
| `school` | `martaf-labs/mt-school` | Gestion scolaire (élèves, classes, notes) |
| `docs` | `martaf-labs/mt-docs` | Documentation en ligne (Markdown) |

---

## Présets disponibles

| Préset | Modules inclus |
|--------|----------------|
| `minimal` | foundation |
| `blog` | foundation, views, icons, blog |
| `school` | foundation, views, icons, school |
| `full` | foundation, views, icons, blog, school, docs |
| `custom` | Sélection manuelle |

---

## Après l'installation

```bash
# 1. Configurer l'environnement
cp .env.example .env
php artisan key:generate

# 2. Configurer la base de données dans .env
# DB_CONNECTION=mysql
# DB_DATABASE=mon_projet

# 3. Lancer les migrations
php artisan migrate

# 4. Installer les dépendances front
npm install && npm run dev

# 5. Démarrer le serveur
php artisan serve
```

---

## Structure du skeleton

```
mt-skeleton/
├── src/
│   ├── Console/Commands/
│   │   ├── InstallCommand.php      # Installateur interactif principal
│   │   └── MakeModuleCommand.php   # Ajout d'un module après coup
│   ├── Installers/
│   │   ├── BaseInstaller.php       # Classe abstraite parente
│   │   ├── FoundationInstaller.php
│   │   ├── ViewsInstaller.php
│   │   ├── BlogInstaller.php
│   │   ├── SchoolInstaller.php
│   │   └── DocsInstaller.php
│   └── MtSkeletonServiceProvider.php
├── config/
│   └── mt-skeleton.php             # Configuration centrale (modules, présets)
├── stubs/
│   ├── config/                     # Stubs de config publiables
│   ├── routes/                     # Stubs de routes par module
│   ├── controllers/                # Stubs de contrôleurs de démarrage
│   └── views/                     # Stubs de vues de démarrage
└── docs/
    ├── installation.md
    └── modules.md
```

---

## Personnalisation des stubs

Publiez les stubs pour les modifier selon vos besoins :

```bash
php artisan vendor:publish --tag=mt-skeleton-stubs
```

Les stubs seront copiés dans `stubs/mt/` à la racine de votre projet.

---

## Contribuer

Les contributions sont les bienvenues ! Consultez [CONTRIBUTING.md](CONTRIBUTING.md).

---

## Licence

MIT — [martaf-labs](https://github.com/martaf-labs)
