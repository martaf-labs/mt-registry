<?php

namespace Mt\MtSchoolCore\Support;

use Illuminate\Support\Facades\Route;
use Mt\MtSchoolCore\Models\SchoolNotification;

/**
 * Résolveur de la cloche de notifications (point d'extension mt-ui
 * `config('mt-ui.notifications_resolver')`). Renvoie le compteur non-lu + les
 * derniers items de l'utilisateur connecté. Double cloisonnement : SchoolScope + user_id.
 */
class NotificationBadgeResolver
{
    public function count(): int
    {
        if (! auth()->check()) {
            return 0;
        }

        return SchoolNotification::where('user_id', auth()->id())
            ->where('is_read', false)
            ->count();
    }

    public function url(): ?string
    {
        return Route::has('notifications') ? route('notifications') : null;
    }

    public function recent(): array
    {
        if (! auth()->check()) {
            return [];
        }

        $center = $this->url();

        return SchoolNotification::where('user_id', auth()->id())
            ->orderByDesc('created_at')
            ->limit(6)
            ->get()
            ->map(fn ($n) => [
                'title' => (string) $n->title,
                'read'  => (bool) $n->is_read,
                'time'  => $n->created_at?->diffForHumans(),
                'url'   => $n->url ?: $center,
            ])
            ->all();
    }
}
