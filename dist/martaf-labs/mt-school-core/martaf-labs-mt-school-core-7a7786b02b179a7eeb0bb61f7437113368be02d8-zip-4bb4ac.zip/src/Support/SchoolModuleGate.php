<?php

namespace Mt\MtSchoolCore\Support;

/**
 * Gate de gating du menu mt-ui par module d'abonnement.
 * Branché via config('mt-ui.module_gate') dans le service provider.
 */
class SchoolModuleGate
{
    public function enabled(string $code): bool
    {
        return moduleEnabled($code);
    }
}
