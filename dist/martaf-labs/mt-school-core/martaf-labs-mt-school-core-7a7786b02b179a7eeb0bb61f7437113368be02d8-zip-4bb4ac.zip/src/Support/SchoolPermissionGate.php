<?php

namespace Mt\MtSchoolCore\Support;

/**
 * Gate de gating du menu mt-ui par PERMISSION (RBAC).
 * Branché via config('mt-ui.permission_gate') dans le service provider.
 *
 * Délègue à la couche d'autorisation Laravel (`$user->can(...)`), elle-même
 * résolue par le `Gate::before` du package → rôle scolaire → RoleSchool::permissions().
 * Un item de menu portant une clé `permission` est masqué si l'utilisateur ne l'a pas.
 */
class SchoolPermissionGate
{
    public function allows(string $ability): bool
    {
        return (bool) auth()->user()?->can($ability);
    }
}
