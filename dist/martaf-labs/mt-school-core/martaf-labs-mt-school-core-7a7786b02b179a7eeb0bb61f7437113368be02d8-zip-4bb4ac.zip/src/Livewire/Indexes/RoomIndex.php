<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Room;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class RoomIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Room::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = Room::find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'code',
                'label'       => __('mtschool::structure.col_room'),
                'value'       => $data?->code,
                'showLetters' => true,
                'letters'     => $data?->code,
                'metaDatas'   => array_filter([
                    $data?->type,
                    $data?->capacity ? __('mtschool::structure.capacity_meta', ['n' => $data->capacity]) : null,
                ]),
            ],

            'othersColumns' => [
                'capacity' => [
                    'label' => __('mtschool::structure.capacity'),
                    'value' => $data?->capacity,
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_f') : __('mtschool::common.inactive_f'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'room',
            'model_plural' => 'rooms',
            'mainLabel'    => __('mtschool::structure.rooms'),
            'title'        => __('mtschool::structure.rooms'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'code',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code', 'capacity'],
            'searchableFields' => [
                'direct'    => ['code', 'type'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => Room::count(),
                'icon'  => 'building-office',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active'),
                'value' => Room::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
