<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\ReportCard;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Index générique des RÉSULTATS (classement d'une classe pour une période) :
 * moyennes/rangs calculés (ReportCardComputer) + statut du bulletin par élève.
 * Filtres classe + période OBLIGATOIRES ; actions d'en-tête = Calculer /
 * Générer / Publier (+ PDF classe construit sur le contexte courant).
 */
class ResultIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return PeriodAverage::class;
    }

    public function mainActions(): array
    {
        $classId  = $this->contextFilter('class_id');
        $periodId = $this->contextFilter('period_id');

        $custom = [
            [
                'label'   => __('mtschool::academics.compute_averages'),
                'icon'    => 'calculator',
                'method'  => 'compute',
                'variant' => 'secondary',
            ],
            [
                'label'   => __('mtschool::academics.generate_report_cards'),
                'icon'    => 'document-check',
                'method'  => 'generate',
                'variant' => 'secondary',
                'confirm' => __('mtschool::academics.confirm_generate_report_cards'),
            ],
            [
                'label'   => __('mtschool::academics.publish'),
                'icon'    => 'megaphone',
                'method'  => 'publish',
                'variant' => 'primary',
                'confirm' => __('mtschool::academics.confirm_publish_report_cards'),
            ],
        ];

        if ($classId && $periodId) {
            $custom[] = [
                'label'  => __('mtschool::academics.pdf_class'),
                'icon'   => 'document-text',
                'route'  => mt_get_route('academics_report_cards_pdf_class', ['class' => $classId, 'period' => $periodId]),
                'target' => '_blank',
            ];
        }

        return ['create' => false, 'custom' => $custom];
    }

    public function rowActions($rowId): array
    {
        $pa = PeriodAverage::find($rowId);
        $periodId = $this->contextFilter('period_id');

        $custom = [];
        if ($pa && $periodId) {
            $custom[] = [
                'type'  => 'route',
                'route' => mt_get_route('academics_report_cards_bulletin', ['enrollment' => $pa->enrollment_id, 'period' => $periodId]),
                'label' => __('mtschool::academics.report_card'),
                'icon'  => 'document-text',
            ];
        }

        return ['edit' => false, 'delete' => false, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $pa = PeriodAverage::with('enrollment.student')->find($rowId);

        // Statut du bulletin de la ligne (classe/période courantes).
        $rc = $pa ? ReportCard::where('enrollment_id', $pa->enrollment_id)
            ->where('period_id', $pa->period_id)->first() : null;
        $rcStatus = $rc?->status?->value ?? ($rc ? (string) $rc->status : null);
        $rcMap = [
            'published' => [__('mtschool::academics.rc_status_published'), 'success'],
            'validated' => [__('mtschool::academics.rc_status_validated'), 'info'],
            'generated' => [__('mtschool::academics.rc_status_generated'), 'warning'],
        ];
        [$rcLabel, $rcVariant] = $rc ? ($rcMap[$rcStatus] ?? [__('mtschool::academics.rc_status_draft'), 'secondary']) : ['—', 'secondary'];

        return [
            'firstColumn' => [
                'field'       => 'rank',
                'label'       => __('mtschool::academics.col_student2'),
                'value'       => $pa?->enrollment?->student?->full_name_reverse ?? $pa?->enrollment?->student?->full_name ?? '—',
                'showLetters' => true,
                'letters'     => $pa?->enrollment?->student?->initials,
                'metaDatas'   => array_filter([$pa?->enrollment?->reference]),
            ],

            'othersColumns' => [
                'rank' => [
                    'label' => __('mtschool::academics.rank'),
                    'value' => $pa?->rank ?? '—',
                    'align' => 'center',
                ],
                'overall_average' => [
                    'label' => __('mtschool::academics.grade_average'),
                    'value' => $pa ? number_format((float) $pa->overall_average, 2, ',', ' ') : '—',
                    'align' => 'right',
                ],
                'mention' => [
                    'label'      => __('mtschool::academics.mention_col'),
                    'value'      => $pa?->mention?->label() ?? '—',
                    'badgeDatas' => $pa?->mention ? [
                        'label' => $pa->mention->label(),
                        'type'  => $pa->mention->badge(),
                    ] : [],
                ],
                'report_card' => [
                    'label'      => __('mtschool::academics.report_card_col'),
                    'value'      => $rcLabel,
                    'badgeDatas' => $rc ? ['label' => $rcLabel, 'type' => $rcVariant] : [],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'result',
            'model_plural' => 'results',
            'mainLabel'    => __('mtschool::academics.results_title'),
            'title'        => __('mtschool::academics.results_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => false,
                'perPage'              => 100, // classement complet d'une classe
                'defaultSort'          => 'rank',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['rank', 'overall_average'],
            'searchableFields' => [],
        ];
    }

    public function getFiltersConfig(): array
    {
        return [
            'class_id' => [
                'label'    => __('mtschool::structure.col_classroom'),
                'type'     => 'select',
                'required' => true,
                'options'  => Classroom::where('active', true)->orderBy('code')->get()
                    ->mapWithKeys(fn ($c) => [$c->id => $c->label])->toArray(),
            ],
            'period_id' => [
                'label'    => __('mtschool::councils.period'),
                'type'     => 'select',
                'required' => true,
                'options'  => Period::orderBy('id')->get()
                    ->mapWithKeys(fn ($p) => [$p->id => $p->label])->toArray(),
            ],
        ];
    }

    /** class_id filtre via l'inscription (pas une colonne de period_averages). */
    public function applyFilters($query, array $activeFilters): void
    {
        if (! empty($activeFilters['period_id'])) {
            $query->where('period_id', $activeFilters['period_id']);
        }

        if (! empty($activeFilters['class_id'])) {
            $query->whereHas('enrollment', fn ($q) => $q
                ->where('class_id', $activeFilters['class_id'])
                ->where('status', 'validated'));
        }
    }

    /** Effectif / moyennes / bulletins générés / publiés — contextuels classe+période. */
    public function getStatistics(): array
    {
        $classId  = $this->contextFilter('class_id');
        $periodId = $this->contextFilter('period_id');

        $enrollIds = $classId
            ? Enrollment::where('class_id', $classId)->validated()->pluck('id')
            : collect();

        $rcQuery = fn () => ReportCard::whereIn('enrollment_id', $enrollIds)->where('period_id', $periodId);

        return [
            [
                'label' => __('mtschool::academics.stat_roster'),
                'value' => $enrollIds->count(),
                'icon'  => 'users',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::academics.stat_averages'),
                'value' => ($classId && $periodId)
                    ? PeriodAverage::where('period_id', $periodId)->whereIn('enrollment_id', $enrollIds)->count()
                    : 0,
                'icon'  => 'calculator',
                'color' => 'info',
            ],
            [
                'label' => __('mtschool::academics.stat_rc_generated'),
                'value' => ($classId && $periodId) ? $rcQuery()->count() : 0,
                'icon'  => 'document-check',
                'color' => 'warning',
            ],
            [
                'label' => __('mtschool::academics.stat_rc_published'),
                'value' => ($classId && $periodId) ? $rcQuery()->where('status', 'published')->count() : 0,
                'icon'  => 'megaphone',
                'color' => 'success',
            ],
        ];
    }
}
