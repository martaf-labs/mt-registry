<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Tuteurs (parents / responsables légaux). CRUD + action « Créer un accès portail ».
 */
class GuardianIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Guardian::class;
    }

    public function mainActions(): array
    {
        return ['create' => true, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        // « Voir la fiche » en 1re position (fiche tuteur = base-profile).
        $custom = [[
            'type'  => 'route',
            'route' => mt_get_route('guardians_profile', ['id' => $rowId]),
            'label' => __('mtschool::students.view_profile'),
            'icon'  => 'eye',
        ]];

        $guardian = Guardian::find($rowId);
        if ($guardian && $guardian->email && ! app(PortalAccountService::class)->accountFor($guardian)) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'provisionPortal',
                'params' => $rowId,
                'label'  => __('mtschool::portal.create_account'),
                'icon'   => 'identification',
            ];
        }

        return ['edit' => true, 'delete' => true, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $data = $rowId ? Guardian::with('students')->find($rowId) : null;

        return [
            'firstColumn' => [
                'field'       => 'last_name',
                'label'       => __('mtschool::students.col_guardian'),
                'value'       => $data?->full_name,
                // Photo (média vedette) si présente, sinon repli initiales.
                'showImage'   => true,
                'image'       => $data?->getVariantImage('thumbnail') ?: null,
                'showLetters' => true,
                'letters'     => $data ? mb_substr((string) $data->first_name, 0, 1) . mb_substr((string) $data->last_name, 0, 1) : '',
                'metaDatas'   => array_filter([$data?->reference, $data?->title]),
            ],

            'othersColumns' => [
                'email'    => ['label' => __('mtschool::students.email'), 'value' => $data?->email ?: '—'],
                'phone'    => ['label' => __('mtschool::students.phone'), 'value' => $data?->phone ?: '—'],
                'children' => ['label' => __('mtschool::students.children'), 'value' => $data ? $data->students->count() : 0],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'guardian',
            'model_plural' => 'guardians',
            'mainLabel'    => __('mtschool::students.guardians'),
            'title'        => __('mtschool::students.guardians'),

            'features' => [
                'canAddImages'         => false, // photo unique → éditée dans le formulaire
                'searchable'           => true,
                'perPage'              => 25,
                'defaultSort'          => 'last_name',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['last_name', 'first_name'],
            'searchableFields' => [
                'direct'    => ['last_name', 'first_name', 'email', 'phone', 'reference'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::students.stat_total_guardians'),
                'value' => Guardian::count(),
                'icon'  => 'user-circle',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::students.stat_guardian_accounts'),
                'value' => Guardian::where('has_user_account', true)->count(),
                'icon'  => 'identification',
                'color' => 'success',
            ],
        ];
    }
}
