<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class StudentIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Student::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        // « Voir la fiche » en tête (base-show).
        $custom = [[
            'type'  => 'route',
            'route' => mt_get_route('students_profile', ['id' => $rowId]),
            'label' => __('mtschool::students.view_profile'),
            'icon'  => 'eye',
        ]];

        // « Créer un accès parent » si le tuteur principal a un e-mail et pas encore de compte.
        $student  = Student::find($rowId);
        $portal   = app(PortalAccountService::class);
        $guardian = $student?->primaryContact()->first() ?? $student?->guardians()->first();
        if ($guardian && $guardian->email && ! $portal->accountFor($guardian)) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'provisionParentPortal',
                'params' => $rowId,
                'label'  => __('mtschool::portal.create_parent_account'),
                'icon'   => 'identification',
            ];
        }

        // « Créer un accès élève » si l'élève n'a pas encore de compte (login = e-mail
        // ou, à défaut, matricule → identifiant généré, montré à l'admin).
        if ($student && ! $portal->accountFor($student)) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'provisionStudentPortal',
                'params' => $rowId,
                'label'  => __('mtschool::portal.create_student_account'),
                'icon'   => 'user',
            ];
        }

        return [
            'edit'   => true,
            'delete' => false,
            'custom' => $custom,
        ];
    }

    public function columns($rowId = null): array
    {
        $data       = Student::with(['currentEnrollment.classroom'])->find($rowId);
        $enrollment = $data?->currentEnrollment;

        return [
            'firstColumn' => [
                'field'       => 'last_name',
                'label'       => __('mtschool::students.col_student'),
                'value'       => $data?->full_name,
                // Photo (média vedette) si présente, sinon repli initiales.
                'showImage'   => true,
                'image'       => $data?->getVariantImage('thumbnail') ?: null,
                'showLetters' => true,
                'letters'     => $data?->initials,
                'metaDatas'   => array_filter([
                    $data?->reference,
                    $data?->gender === 'M' ? __('mtschool::students.boy') : ($data?->gender === 'F' ? __('mtschool::students.girl') : null),
                    $data?->birth_date?->format('d/m/Y'),
                ]),
            ],

            'othersColumns' => [
                'classroom' => [
                    'label' => __('mtschool::students.col_classroom'),
                    'value' => $enrollment?->classroom?->code ?? '—',
                ],
                'birth_place' => [
                    'label' => __('mtschool::students.birth_place'),
                    'value' => $data?->birth_place ?? '—',
                ],
                'status' => [
                    'label'      => __('mtschool::students.enrollment_col'),
                    'value'      => $enrollment?->status?->label() ?? __('mtschool::students.not_enrolled'),
                    'badgeDatas' => $enrollment ? [
                        'label' => $enrollment->status->label(),
                        'color' => $enrollment->status->badge(),
                    ] : ['label' => __('mtschool::students.not_enrolled'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'student',
            'model_plural' => 'students',
            'mainLabel'    => __('mtschool::students.students'),
            'title'        => __('mtschool::students.students'),

            'features' => [
                'canAddImages'         => false, // photo unique → éditée dans le formulaire
                'searchable'           => true,
                'perPage'              => 25,
                'defaultSort'          => 'last_name',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['last_name', 'first_name', 'reference'],
            'searchableFields' => [
                'direct'    => ['last_name', 'first_name', 'reference', 'email', 'phone'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        // Enrollment est filtré sur l'année active (global scope) ; Student est inter-années.
        return [
            [
                'label' => __('mtschool::students.stat_total_students'),
                'value' => Student::count(),
                'icon'  => 'users',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::students.stat_enrolled_year', ['year' => activeSchoolYear()?->code]),
                'value' => Enrollment::validated()->count(),
                'icon'  => 'clipboard-document-check',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::students.stat_pending'),
                'value' => Enrollment::pending()->count(),
                'icon'  => 'clock',
                'color' => 'warning',
            ],
        ];
    }
}
