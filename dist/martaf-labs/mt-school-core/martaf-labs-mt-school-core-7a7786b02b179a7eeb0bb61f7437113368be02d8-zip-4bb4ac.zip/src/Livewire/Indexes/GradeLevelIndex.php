<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class GradeLevelIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return GradeLevel::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = GradeLevel::with('cycle')->find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'code',
                'label'       => __('mtschool::structure.col_grade_level'),
                'value'       => $data?->code,
                'showLetters' => true,
                'letters'     => $data?->abbreviation ?? $data?->code,
                'metaDatas'   => array_filter([
                    $data?->cycle?->code,
                    __('mtschool::structure.class_count', ['n' => $data?->classes()->count()]),
                ]),
            ],

            'othersColumns' => [
                'cycle' => [
                    'label' => __('mtschool::structure.col_cycle'),
                    'value' => $data?->cycle?->code,
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_m') : __('mtschool::common.inactive_m'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_m'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_m'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'grade-level',
            'model_plural' => 'grade-levels',
            'mainLabel'    => __('mtschool::structure.grade_levels'),
            'title'        => __('mtschool::structure.grade_levels'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'order',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code', 'order'],
            'searchableFields' => [
                'direct'    => ['code', 'abbreviation'],
                'relations' => ['cycle' => ['code']],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => GradeLevel::count(),
                'icon'  => 'academic-cap',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active_m'),
                'value' => GradeLevel::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
