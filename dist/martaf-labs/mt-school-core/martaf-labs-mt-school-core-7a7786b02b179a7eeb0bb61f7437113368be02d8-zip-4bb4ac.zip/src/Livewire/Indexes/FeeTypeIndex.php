<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\FeeType;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/** Catalogue des types de frais (TENANT). Montants dans la grille (FeeSchedule). */
class FeeTypeIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return FeeType::class;
    }

    public function mainActions(): array
    {
        return ['create' => true, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        return ['edit' => true, 'delete' => true, 'custom' => []];
    }

    public function columns($rowId = null): array
    {
        $data = FeeType::find($rowId);
        $mandatory = $data?->characteristic === 'mandatory';

        return [
            'firstColumn' => [
                'field'       => 'label',
                'label'       => __('mtschool::academics.col_fee_type'),
                'value'       => $data?->label,
                'showLetters' => true,
                'letters'     => $data?->code,
                'metaDatas'   => array_filter([$data?->code]),
            ],
            'othersColumns' => [
                'characteristic' => [
                    'label'      => __('mtschool::academics.characteristic'),
                    'value'      => $mandatory ? __('mtschool::academics.mandatory') : __('mtschool::academics.optional'),
                    'badgeDatas' => $mandatory
                        ? ['label' => __('mtschool::academics.mandatory'), 'color' => 'primary']
                        : ['label' => __('mtschool::academics.optional'), 'color' => 'secondary'],
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_m') : __('mtschool::common.inactive_m'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_m'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_m'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'fee_type',
            'model_plural' => 'fee_types',
            'mainLabel'    => __('mtschool::academics.fee_types'),
            'title'        => __('mtschool::academics.fee_types'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'order',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['order', 'code'],
            'searchableFields' => ['direct' => ['code'], 'relations' => []],
        ];
    }

    public function getStatistics(): array
    {
        return [
            ['label' => __('mtschool::academics.fee_types'), 'value' => FeeType::count(), 'icon' => 'banknotes', 'color' => 'primary'],
            ['label' => __('mtschool::structure.stat_active_m'), 'value' => FeeType::where('active', true)->count(), 'icon' => 'check-circle', 'color' => 'success'],
        ];
    }
}
