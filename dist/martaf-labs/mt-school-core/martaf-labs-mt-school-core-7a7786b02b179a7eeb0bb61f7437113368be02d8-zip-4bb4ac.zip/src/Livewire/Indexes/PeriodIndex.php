<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class PeriodIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Period::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = Period::with('schoolYear', 'parent')->find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'code',
                'label'       => __('mtschool::structure.col_period'),
                'value'       => $data?->code,
                'showLetters' => true,
                'letters'     => $data?->code,
                'metaDatas'   => array_filter([
                    $data?->schoolYear?->code,
                    $data?->parent?->code ? __('mtschool::structure.sub_period_of', ['code' => $data->parent->code]) : null,
                    $data?->start_date?->format('d/m/Y') . ' – ' . $data?->end_date?->format('d/m/Y'),
                ]),
            ],

            'othersColumns' => [
                'type' => [
                    'label' => __('mtschool::common.type'),
                    'value' => $data?->type?->label(),
                ],
                'weight' => [
                    'label' => __('mtschool::structure.weight'),
                    'value' => $data?->weight,
                ],
                'is_active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->is_active ? __('mtschool::common.active_f') : __('mtschool::common.inactive_f'),
                    'badgeDatas' => $data?->is_active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'period',
            'model_plural' => 'periods',
            'mainLabel'    => __('mtschool::structure.periods'),
            'title'        => __('mtschool::structure.periods'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'order',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code', 'order', 'start_date'],
            'searchableFields' => [
                'direct'    => ['code'],
                'relations' => ['schoolYear' => ['code']],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => Period::count(),
                'icon'  => 'calendar',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active'),
                'value' => Period::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
