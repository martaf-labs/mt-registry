<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Enums\EnrollmentStatus;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Index générique des INSCRIPTIONS de l'année active (écran de validation).
 * Pilote de la doctrine « vues généralistes d'abord » : l'écran instancie
 * base-index (stats + filtres + recherche + actions) au lieu d'une vue bespoke.
 */
class EnrollmentIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Enrollment::class;
    }

    public function mainActions(): array
    {
        // Les inscriptions se créent via l'assistant d'inscription (élèves), pas ici.
        return ['create' => false, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        $custom = [];
        $enrollment = Enrollment::find($rowId);

        // Valider / refuser : uniquement pour les inscriptions EN ATTENTE.
        if ($enrollment?->isPending()) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'validateEnrollment',
                'params' => $rowId,
                'label'  => __('mtschool::students.enrollment_validate'),
                'icon'   => 'check-circle',
            ];
            $custom[] = [
                'type'    => 'livewire',
                'method'  => 'openReject',
                'params'  => $rowId,
                'label'   => __('mtschool::students.enrollment_reject'),
                'icon'    => 'x-circle',
                'variant' => 'danger',
            ];
        }

        return ['edit' => false, 'delete' => false, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $e = Enrollment::with(['student', 'classroom'])->find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'reference',
                'label'       => __('mtschool::students.col_student'),
                'value'       => $e?->student?->full_name_reverse ?? $e?->student?->full_name ?? '—',
                'showLetters' => true,
                'letters'     => $e?->student?->initials,
                'metaDatas'   => array_filter([
                    $e?->reference,
                    $e?->enrollment_date?->format('d/m/Y'),
                ]),
            ],

            'othersColumns' => [
                'classroom' => [
                    'label' => __('mtschool::students.col_classroom'),
                    'value' => $e?->classroom?->code ?? '—',
                ],
                'status' => [
                    'label'      => __('mtschool::students.enrollment_col'),
                    'value'      => $e?->status?->label() ?? '—',
                    'badgeDatas' => $e?->status ? [
                        'label' => $e->status->label(),
                        'type'  => $e->status->badge(),
                    ] : [],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'enrollment',
            'model_plural' => 'enrollments',
            'mainLabel'    => __('mtschool::students.enrollments_title'),
            'title'        => __('mtschool::students.enrollments_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 25,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['id', 'enrollment_date', 'reference'],
            'searchableFields' => [
                'direct'    => ['reference'],
                'relations' => ['student' => ['last_name', 'first_name', 'reference']],
            ],
        ];
    }

    /** Panneau Filtres du base-index : état + classe. */
    public function getFiltersConfig(): array
    {
        return [
            'status' => [
                'label'   => __('mtschool::pedagogy.sup_state'),
                'type'    => 'select',
                'options' => EnrollmentStatus::options(),
            ],
            'class_id' => [
                'label'   => __('mtschool::students.col_classroom'),
                'type'    => 'select',
                'options' => Classroom::orderBy('code')->pluck('code', 'id')->toArray(),
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::students.enrollment_pending'),
                'value' => Enrollment::pending()->count(),
                'icon'  => 'clock',
                'color' => 'warning',
            ],
            [
                'label' => __('mtschool::students.enrollment_validated'),
                'value' => Enrollment::validated()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::students.enrollment_status_rejected'),
                'value' => Enrollment::where('status', EnrollmentStatus::REJECTED->value)->count(),
                'icon'  => 'x-circle',
                'color' => 'danger',
            ],
        ];
    }
}
