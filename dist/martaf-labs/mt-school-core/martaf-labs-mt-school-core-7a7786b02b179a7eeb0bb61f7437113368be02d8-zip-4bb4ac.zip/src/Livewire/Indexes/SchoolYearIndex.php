<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class SchoolYearIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return SchoolYear::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = SchoolYear::find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'code',
                'label'       => __('mtschool::structure.col_school_year'),
                'value'       => $data?->code,
                'showLetters' => true,
                'letters'     => $data?->code,
                'metaDatas'   => array_filter([
                    $data?->start_date?->format('d/m/Y') . ' – ' . $data?->end_date?->format('d/m/Y'),
                ]),
            ],

            'othersColumns' => [
                'is_active' => [
                    'label'      => __('mtschool::common.active'),
                    'value'      => $data?->is_active ? __('mtschool::common.yes') : __('mtschool::common.no'),
                    'badgeDatas' => $data?->is_active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
                'is_closed' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->is_closed ? __('mtschool::structure.closed') : __('mtschool::structure.opened'),
                    'badgeDatas' => $data?->is_closed
                        ? ['label' => __('mtschool::structure.closed'), 'color' => 'danger']
                        : ['label' => __('mtschool::structure.opened'), 'color' => 'primary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'school-year',
            'model_plural' => 'school-years',
            'mainLabel'    => __('mtschool::structure.school_years'),
            'title'        => __('mtschool::structure.school_years'),

            'features' => [
                'canAddImages'        => false,
                'searchable'          => true,
                'perPage'             => 20,
                'defaultSort'         => 'created_at',
                'defaultSortDirection' => 'desc',
            ],

            'filters'         => [],
            'sortableFields'  => ['code', 'start_date', 'end_date'],
            'searchableFields' => [
                'direct'    => ['code'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => SchoolYear::count(),
                'icon'  => 'calendar',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::common.active'),
                'value' => SchoolYear::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::structure.stat_closed'),
                'value' => SchoolYear::closed()->count(),
                'icon'  => 'x-circle',
                'color' => 'secondary',
            ],
        ];
    }
}
