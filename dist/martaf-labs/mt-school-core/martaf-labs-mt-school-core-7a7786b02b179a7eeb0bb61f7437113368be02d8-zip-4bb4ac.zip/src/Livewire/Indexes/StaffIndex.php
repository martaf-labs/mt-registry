<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\StaffMember;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Tout le PERSONNEL de l'école (enseignants, administratifs, techniques, direction).
 * Vue transversale — la gestion pédagogique des enseignants reste dans TeacherIndex.
 */
class StaffIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return StaffMember::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => false, // création via Enseignants (profil pédagogique) ou Import personnel
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => false,
            'delete' => true,
            'custom' => [[
                'type'  => 'route',
                'route' => mt_get_route('staff_profile', ['id' => $rowId]),
                'label' => __('mtschool::students.view_profile'),
                'icon'  => 'eye',
            ]],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = $rowId ? StaffMember::find($rowId) : null;

        return [
            'firstColumn' => [
                'field'       => 'full_name',
                'label'       => __('mtschool::students.col_staff_member'),
                'value'       => $data?->full_name,
                'showImage'   => true,
                'image'       => $data?->getVariantImage('thumbnail') ?: null,
                'showLetters' => true,
                'letters'     => $data ? mb_substr($data->first_name ?? '', 0, 1) . mb_substr($data->last_name ?? '', 0, 1) : null,
                'metaDatas'   => array_filter([
                    $data?->email,
                    $data?->phone,
                ]),
            ],

            'othersColumns' => [
                'type' => [
                    'label' => __('mtschool::students.staff_type'),
                    'value' => $data?->type?->label() ?? '—',
                ],
                'fonction' => [
                    'label' => __('mtschool::students.staff_role'),
                    'value' => $data?->metadata['fonction'] ?? '—',
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'staff-member',
            'model_plural' => 'staff-members',
            'mainLabel'    => __('mtschool::students.stat_staff'),
            'title'        => __('mtschool::students.stat_staff'),

            'features' => [
                'canAddImages'         => false, // photo unique → éditée dans le formulaire
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['id'],
            'searchableFields' => [
                'direct' => ['last_name', 'first_name', 'email', 'phone'],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::students.stat_staff'),
                'value' => StaffMember::count(),
                'icon'  => 'users',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::students.staff_type_teacher'),
                'value' => StaffMember::where('type', \Mt\MtSchoolCore\Enums\StaffType::TEACHER->value)->count(),
                'icon'  => 'chalkboard',
                'color' => 'info',
            ],
        ];
    }
}
