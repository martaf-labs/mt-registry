<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Homework;
use Mt\MtSchoolCore\Models\HomeworkSubmission;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtSchoolCore\Models\Teacher;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Supervision ADMIN des devoirs (instance base-index) : tous les devoirs de l'année,
 * filtres classe/matière/enseignant/état, taux de rendu, détail lecture seule.
 */
class HomeworkSupervisionIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Homework::class;
    }

    public function mainActions(): array
    {
        return ['create' => false, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        $custom = [[
            'type'   => 'livewire',
            'method' => 'showDetail',
            'params' => $rowId,
            'label'  => __('mtschool::pedagogy.sup_detail'),
            'icon'   => 'eye',
        ]];

        if (auth()->user()?->can('school.homeworks.manage')) {
            $custom[] = [
                'type'    => 'livewire',
                'method'  => 'deleteHomework',
                'params'  => $rowId,
                'label'   => __('mtschool::common.delete'),
                'icon'    => 'trash',
                'variant' => 'danger',
            ];
        }

        return ['edit' => false, 'delete' => false, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $hw = $rowId
            ? Homework::with(['classroom', 'subject', 'teacher.staff'])->withCount('submissions')->find($rowId)
            : null;

        $roster = $hw ? Enrollment::validated()->where('class_id', $hw->class_id)->count() : 0;
        $state  = ! $hw ? 'open' : ($hw->status !== 'published' ? 'draft' : ($hw->isExpired() ? 'expired' : 'open'));
        $stateVariant = ['draft' => 'secondary', 'expired' => 'warning', 'open' => 'info'][$state];

        return [
            'firstColumn' => [
                'field'     => 'title',
                'label'     => __('mtschool::pedagogy.title_field'),
                'value'     => $hw?->title,
                'metaDatas' => array_filter([
                    $hw && $hw->is_graded ? __('mtschool::pedagogy.scored_out_of', ['max' => rtrim(rtrim((string) $hw->max_score, '0'), '.')]) : null,
                ]),
            ],
            'othersColumns' => [
                'classroom' => ['label' => __('mtschool::pedagogy.sup_class'), 'value' => $hw?->classroom?->code ?? '—'],
                'subject'   => ['label' => __('mtschool::pedagogy.sup_subject'), 'value' => $hw?->subject?->label ?? '—'],
                'teacher'   => ['label' => __('mtschool::pedagogy.sup_teacher'), 'value' => $hw?->teacher?->full_name ?? '—'],
                'deadline'  => ['label' => __('mtschool::pedagogy.sup_deadline'), 'value' => $hw?->submission_deadline?->format('d/m/Y H:i') ?? '—'],
                'submissions' => [
                    'label' => __('mtschool::pedagogy.sup_submissions'),
                    'value' => $hw ? $hw->submissions_count . ($roster ? ' / ' . $roster : '') : '0',
                    'align' => 'center',
                ],
                'state' => [
                    'label'      => __('mtschool::pedagogy.sup_state'),
                    'value'      => __('mtschool::pedagogy.sup_state_' . $state),
                    'badgeDatas' => ['label' => __('mtschool::pedagogy.sup_state_' . $state), 'type' => $stateVariant],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'homework',
            'model_plural' => 'homeworks',
            'mainLabel'    => __('mtschool::pedagogy.sup_homeworks_title'),
            'title'        => __('mtschool::pedagogy.sup_homeworks_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'submission_deadline',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['submission_deadline', 'title'],
            'searchableFields' => ['direct' => ['title'], 'relations' => []],
        ];
    }

    public function getFiltersConfig(): array
    {
        return [
            'class_id' => [
                'label'   => __('mtschool::pedagogy.sup_class'),
                'type'    => 'select',
                'options' => Classroom::orderBy('code')->pluck('code', 'id')->toArray(),
            ],
            'subject_id' => [
                'label'   => __('mtschool::pedagogy.sup_subject'),
                'type'    => 'select',
                'options' => Subject::orderBy('code')->get()->mapWithKeys(fn ($s) => [$s->id => $s->label])->toArray(),
            ],
            'teacher_id' => [
                'label'   => __('mtschool::pedagogy.sup_teacher'),
                'type'    => 'select',
                'options' => Teacher::with('staff')->get()->sortBy('full_name')->mapWithKeys(fn ($t) => [$t->id => $t->full_name])->toArray(),
            ],
            'state' => [
                'label'   => __('mtschool::pedagogy.sup_state'),
                'type'    => 'select',
                'options' => [
                    'open'    => __('mtschool::pedagogy.sup_open'),
                    'expired' => __('mtschool::pedagogy.sup_expired'),
                    'draft'   => __('mtschool::pedagogy.sup_draft'),
                ],
            ],
        ];
    }

    /** class_id/subject_id/teacher_id = colonnes directes ; 'state' = scopes métier. */
    public function applyFilters($query, array $activeFilters): void
    {
        foreach (['class_id', 'subject_id', 'teacher_id'] as $col) {
            if (! empty($activeFilters[$col])) {
                $query->where($col, $activeFilters[$col]);
            }
        }

        match ($activeFilters['state'] ?? null) {
            'open'    => $query->open(),
            'expired' => $query->expired(),
            'draft'   => $query->where('status', 'draft'),
            default   => null,
        };
    }

    public function getStatistics(): array
    {
        return [
            ['label' => __('mtschool::pedagogy.sup_total'), 'value' => Homework::count(), 'icon' => 'clipboard-document-list', 'color' => 'primary'],
            ['label' => __('mtschool::pedagogy.sup_open'), 'value' => Homework::open()->count(), 'icon' => 'clock', 'color' => 'info'],
            ['label' => __('mtschool::pedagogy.sup_expired'), 'value' => Homework::expired()->count(), 'icon' => 'x-circle', 'color' => 'warning'],
            ['label' => __('mtschool::pedagogy.sup_submissions'), 'value' => HomeworkSubmission::count(), 'icon' => 'check-circle', 'color' => 'success'],
        ];
    }
}
