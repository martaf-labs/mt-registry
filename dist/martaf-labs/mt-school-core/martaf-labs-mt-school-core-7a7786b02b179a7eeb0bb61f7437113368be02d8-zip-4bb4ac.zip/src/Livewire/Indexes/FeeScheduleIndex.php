<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\FeeSchedule;
use Mt\MtSchoolCore\Models\FeeType;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Index STANDARD de la grille tarifaire : chaque ligne = un tarif
 * (type de frais × niveau × filière → montant) de l'année active.
 * Création / édition via base-form (comme les autres modules).
 */
class FeeScheduleIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return FeeSchedule::class;
    }

    public function mainActions(): array
    {
        return ['create' => true, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        return ['edit' => true, 'delete' => true, 'custom' => []];
    }

    public function columns($rowId = null): array
    {
        $s = FeeSchedule::with(['feeType', 'gradeLevel', 'specialization'])->find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'fee_type_id',
                'label'       => __('mtschool::finances.col_fee_type2'),
                'value'       => $s?->feeType?->label ?? '—',
                'showLetters' => true,
                'letters'     => $s?->feeType?->code,
                'metaDatas'   => array_filter([$s?->feeType?->code]),
            ],

            'othersColumns' => [
                'grade_level' => [
                    'label' => __('mtschool::finances.level'),
                    'value' => $s?->gradeLevel?->label ?? '—',
                ],
                'specialization' => [
                    'label'      => __('mtschool::finances.specialization_opt2'),
                    'value'      => $s?->specialization?->code ?? __('mtschool::finances.all_or_none'),
                    'badgeDatas' => $s?->specialization
                        ? ['label' => $s->specialization->code, 'type' => 'info']
                        : ['label' => __('mtschool::finances.all_or_none'), 'type' => 'secondary'],
                ],
                'amount' => [
                    'label' => __('mtschool::finances.col_amount'),
                    'value' => number_format((float) ($s?->amount ?? 0), 0, ',', ' '),
                    'align' => 'right',
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'fee_schedule',
            'model_plural' => 'fee_schedules',
            'mainLabel'    => __('mtschool::finances.schedule_title'),
            'title'        => __('mtschool::finances.schedule_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => false,
                'perPage'              => 25,
                'defaultSort'          => 'grade_level_id',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['grade_level_id', 'amount'],
            'searchableFields' => [],
        ];
    }

    /** Filtres standard : ils FILTRENT les lignes de la grille. */
    public function getFiltersConfig(): array
    {
        return [
            'grade_level_id' => [
                'label'   => __('mtschool::finances.level'),
                'type'    => 'select',
                'options' => GradeLevel::orderBy('order')->get()
                    ->mapWithKeys(fn ($g) => [$g->id => $g->label])->toArray(),
            ],
            'fee_type_id' => [
                'label'   => __('mtschool::finances.col_fee_type2'),
                'type'    => 'select',
                'options' => FeeType::where('active', true)->orderBy('order')->get()
                    ->mapWithKeys(fn ($ft) => [$ft->id => $ft->label])->toArray(),
            ],
        ];
    }

    /** Lignes configurées + Total/élève, contextuels aux filtres. */
    public function getStatistics(): array
    {
        $gradeId = $this->contextFilter('grade_level_id');
        $typeId  = $this->contextFilter('fee_type_id');

        $query = FeeSchedule::query()
            ->when($gradeId, fn ($q) => $q->where('grade_level_id', $gradeId))
            ->when($typeId, fn ($q) => $q->where('fee_type_id', $typeId));

        $count = (clone $query)->count();

        // Total/élève : significatif pour UN niveau donné (grille générale, hors filière).
        $totalPerStudent = $gradeId
            ? number_format((float) (clone $query)->whereNull('specialization_id')->sum('amount'), 0, ',', ' ')
            : '—';

        return [
            [
                'label' => __('mtschool::finances.schedule_title'),
                'value' => $count,
                'icon'  => 'receipt-percent',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::finances.total_per_student'),
                'value' => $totalPerStudent,
                'icon'  => 'banknotes',
                'color' => 'success',
            ],
        ];
    }
}
