<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Scholarship;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Index générique des BOURSES actives (année/école courantes).
 * L'attribution passe par la modale « Attribuer » (FeeService::grantScholarship,
 * qui applique la remise aux SchoolFee).
 */
class ScholarshipIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Scholarship::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => false,
            'custom' => [
                [
                    'label'   => __('mtschool::finances.scholarship_grant'),
                    'icon'    => 'gift',
                    'method'  => 'openGrant',
                    'variant' => 'primary',
                ],
            ],
        ];
    }

    public function rowActions($rowId): array
    {
        return ['edit' => false, 'delete' => false, 'custom' => []];
    }

    public function columns($rowId = null): array
    {
        $s = Scholarship::with('enrollment.student')->find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'reference',
                'label'       => __('mtschool::finances.scholarship_student'),
                'value'       => $s?->enrollment?->student?->full_name_reverse ?? $s?->enrollment?->student?->full_name ?? '—',
                'showLetters' => true,
                'letters'     => $s?->enrollment?->student?->initials,
                'metaDatas'   => array_filter([$s?->reference, $s?->label]),
            ],

            'othersColumns' => [
                'type' => [
                    'label'      => __('mtschool::finances.scholarship_category'),
                    'value'      => $s?->type ? __('mtschool::finances.scholarship_cat_' . $s->type) : '—',
                    'badgeDatas' => $s?->type ? [
                        'label' => __('mtschool::finances.scholarship_cat_' . $s->type),
                        'type'  => ['merit' => 'info', 'social' => 'primary', 'government' => 'warning'][$s->type] ?? 'secondary',
                    ] : [],
                ],
                'amount' => [
                    'label' => __('mtschool::finances.scholarship_amount'),
                    'value' => $s
                        ? ((float) $s->coverage_rate > 0
                            ? rtrim(rtrim(number_format((float) $s->coverage_rate, 2), '0'), '.') . ' %'
                            : number_format((float) $s->amount, 0, ',', ' '))
                        : '—',
                    'align' => 'right',
                ],
                'coverage' => [
                    'label' => __('mtschool::finances.scholarship_coverage'),
                    'value' => $s?->coverage ? __('mtschool::finances.coverage_' . $s->coverage) : '—',
                ],
                'award_date' => [
                    'label' => __('mtschool::documents.cert_issued_on'),
                    'value' => $s?->award_date?->format('d/m/Y') ?? '—',
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'scholarship',
            'model_plural' => 'scholarships',
            'mainLabel'    => __('mtschool::finances.scholarships_title'),
            'title'        => __('mtschool::finances.scholarships_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => false,
                'perPage'              => 25,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'desc',
            ],

            // Seules les bourses ACTIVES sont gérées ici.
            'filters'          => [['status', 'active']],
            'sortableFields'   => ['id', 'award_date'],
            'searchableFields' => [],
        ];
    }

    public function getFiltersConfig(): array
    {
        return [
            'type' => [
                'label'   => __('mtschool::finances.scholarship_category'),
                'type'    => 'select',
                'options' => collect(['merit', 'social', 'government', 'other'])
                    ->mapWithKeys(fn ($c) => [$c => __('mtschool::finances.scholarship_cat_' . $c)])->toArray(),
            ],
        ];
    }

    public function getStatistics(): array
    {
        $type = $this->contextFilter('type');
        $base = Scholarship::active()->when($type, fn ($q) => $q->where('type', $type));

        return [
            [
                'label' => __('mtschool::finances.scholarships_list'),
                'value' => (clone $base)->count(),
                'icon'  => 'gift',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::finances.scholarship_cat_social'),
                'value' => Scholarship::active()->where('type', 'social')->count(),
                'icon'  => 'user-group',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::finances.scholarship_cat_merit'),
                'value' => Scholarship::active()->where('type', 'merit')->count(),
                'icon'  => 'academic-cap',
                'color' => 'info',
            ],
        ];
    }
}
