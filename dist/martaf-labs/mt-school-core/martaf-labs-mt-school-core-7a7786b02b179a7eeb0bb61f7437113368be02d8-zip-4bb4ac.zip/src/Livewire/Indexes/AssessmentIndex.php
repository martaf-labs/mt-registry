<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Assessment;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Évaluations de l'année active. Action « Saisir les notes » → GradeEntryManager.
 */
class AssessmentIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Assessment::class;
    }

    public function mainActions(): array
    {
        return ['create' => true, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [
                [
                    'type'  => 'route',
                    'route' => mt_get_route('academics_assessments_grades', ['id' => $rowId]),
                    'label' => __('mtschool::academics.enter_grades'),
                    'icon'  => 'pencil-square',
                ],
            ],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = $rowId ? Assessment::with(['classroom', 'subject', 'period'])->find($rowId) : null;

        $total = $data ? Enrollment::where('class_id', $data->class_id)->validated()->count() : 0;
        $entered = $data ? $data->grades()->whereNotNull('final_score')->count() : 0;
        $absent  = $data ? $data->grades()->where('is_absent', true)->count() : 0;
        $done    = $entered + $absent;

        return [
            'firstColumn' => [
                'field'       => 'label',
                'label'       => __('mtschool::academics.col_assessment'),
                'value'       => $data?->label,
                'showLetters' => true,
                'letters'     => $data?->subject?->abbreviation ?? $data?->subject?->code,
                'metaDatas'   => array_filter([
                    $data?->classroom?->label,
                    $data?->subject?->code,
                    $data?->period?->label,
                ]),
            ],

            'othersColumns' => [
                'type' => [
                    'label' => __('mtschool::common.type'),
                    'value' => $data?->type?->label() ?? '—',
                ],
                'max_score' => [
                    'label' => __('mtschool::academics.grading_scale'),
                    'value' => $data ? ('/' . rtrim(rtrim((string) $data->max_score, '0'), '.')) : '—',
                ],
                'entry' => [
                    'label'      => __('mtschool::academics.entry'),
                    'value'      => $done . '/' . $total,
                    'badgeDatas' => $total > 0 && $done >= $total
                        ? ['label' => __('mtschool::academics.entry_complete'), 'color' => 'success']
                        : ($done > 0 ? ['label' => $done . '/' . $total, 'color' => 'warning'] : ['label' => __('mtschool::academics.entry_todo'), 'color' => 'secondary']),
                ],
                'published' => [
                    'label'      => __('mtschool::academics.publication'),
                    'value'      => $data?->published ? __('mtschool::common.published_f') : __('mtschool::common.draft'),
                    'badgeDatas' => $data?->published
                        ? ['label' => __('mtschool::common.published_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.draft'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'assessment',
            'model_plural' => 'assessments',
            'mainLabel'    => __('mtschool::academics.assessments'),
            'title'        => __('mtschool::academics.assessments'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['id'],
            'searchableFields' => [
                'direct'    => ['code'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::academics.assessments'),
                'value' => Assessment::count(),
                'icon'  => 'pencil-square',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::academics.stat_published'),
                'value' => Assessment::where('published', true)->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
