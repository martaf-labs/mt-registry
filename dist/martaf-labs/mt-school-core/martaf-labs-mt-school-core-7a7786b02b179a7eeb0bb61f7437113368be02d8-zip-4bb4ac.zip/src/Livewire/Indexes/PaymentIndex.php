<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Index générique de l'ENCAISSEMENT par classe (vue caissier) : dû / payé /
 * reste par élève inscrit (validé) de la classe filtrée. Les statistiques
 * sont CONTEXTUELLES au filtre classe (contextFilter — option moteur).
 */
class PaymentIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Enrollment::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => false,
            'custom' => [
                [
                    'label'   => __('mtschool::finances.generate_fees'),
                    'icon'    => 'banknotes',
                    'method'  => 'generate',
                    'variant' => 'secondary',
                ],
            ],
        ];
    }

    public function rowActions($rowId): array
    {
        $e = Enrollment::with('schoolFees')->find($rowId);
        $hasFees   = $e && $e->schoolFees->isNotEmpty();
        $remaining = $e ? (float) $e->schoolFees->sum('remaining_amount') : 0.0;

        $custom = [];

        if ($hasFees && $remaining > 0) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'openPayment',
                'params' => $rowId,
                'label'  => __('mtschool::finances.collect'),
                'icon'   => 'credit-card',
            ];
        }

        if ($hasFees) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'openScholarship',
                'params' => $rowId,
                'label'  => __('mtschool::finances.scholarship'),
                'icon'   => 'gift',
            ];
            $custom[] = [
                'type'  => 'route',
                'route' => mt_get_route('finances_payments_student', ['enrollment' => $rowId]),
                'label' => __('mtschool::finances.details_schedule'),
                'icon'  => 'adjustments-horizontal',
            ];
            $custom[] = [
                'type'   => 'route',
                'route'  => mt_get_route('finances_payments_receipt', ['enrollment' => $rowId]),
                'target' => '_blank', // PDF : nouvel onglet, pas de wire:navigate
                'label'  => __('mtschool::finances.receipt_statement'),
                'icon'   => 'document-text',
            ];
        }

        return ['edit' => false, 'delete' => false, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $e = Enrollment::with(['student', 'schoolFees'])->find($rowId);

        $due  = $e ? (float) $e->schoolFees->sum('net_amount') : 0.0;
        $paid = $e ? (float) $e->schoolFees->sum('amount_paid') : 0.0;
        $rem  = $e ? (float) $e->schoolFees->sum('remaining_amount') : 0.0;

        $status = $due <= 0 ? 'none' : ($rem <= 0 ? 'paid' : ($paid > 0 ? 'partial' : 'pending'));
        $statusMap = [
            'paid'    => [__('mtschool::finances.status_settled'), 'success'],
            'partial' => [__('mtschool::finances.status_partial'), 'warning'],
            'pending' => [__('mtschool::finances.status_unpaid'), 'danger'],
            'none'    => ['—', 'secondary'],
        ];
        [$statusLabel, $statusVariant] = $statusMap[$status];

        return [
            'firstColumn' => [
                'field'       => 'id',
                'label'       => __('mtschool::finances.col_student3'),
                'value'       => $e?->student?->full_name_reverse ?? $e?->student?->full_name ?? '—',
                'showLetters' => true,
                'letters'     => $e?->student?->initials,
                'metaDatas'   => array_filter([$e?->reference]),
            ],

            'othersColumns' => [
                'due' => [
                    'label' => __('mtschool::finances.col_due'),
                    'value' => number_format($due, 0, ',', ' '),
                    'align' => 'right',
                ],
                'paid' => [
                    'label' => __('mtschool::finances.col_paid'),
                    'value' => number_format($paid, 0, ',', ' '),
                    'align' => 'right',
                ],
                'remaining' => [
                    'label' => __('mtschool::finances.col_remaining'),
                    'value' => number_format($rem, 0, ',', ' '),
                    'align' => 'right',
                ],
                'status' => [
                    'label'      => __('mtschool::finances.col_status2'),
                    'value'      => $statusLabel,
                    'badgeDatas' => ['label' => $statusLabel, 'type' => $statusVariant],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'payment',
            'model_plural' => 'payments',
            'mainLabel'    => __('mtschool::finances.payments_title'),
            'title'        => __('mtschool::finances.payments_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 25,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'asc',
            ],

            // Vue caissier : uniquement les inscriptions VALIDÉES.
            'filters'          => [['status', 'validated']],
            'sortableFields'   => ['id'],
            'searchableFields' => [
                'direct'    => ['reference'],
                'relations' => ['student' => ['last_name', 'first_name', 'reference']],
            ],
        ];
    }

    /** Filtre classe OBLIGATOIRE (le caissier travaille par classe). */
    public function getFiltersConfig(): array
    {
        return [
            'class_id' => [
                'label'    => __('mtschool::structure.col_classroom'),
                'type'     => 'select',
                'required' => true,
                'options'  => Classroom::where('active', true)->orderBy('code')->get()
                    ->mapWithKeys(fn ($c) => [$c->id => $c->label])->toArray(),
            ],
        ];
    }

    /** Totaux CONTEXTUELS à la classe filtrée : dû / encaissé / reste. */
    public function getStatistics(): array
    {
        $classId = $this->contextFilter('class_id');

        $enrollments = Enrollment::validated()
            ->when($classId, fn ($q) => $q->where('class_id', $classId))
            ->with('schoolFees')->get();

        $due  = (float) $enrollments->sum(fn ($e) => (float) $e->schoolFees->sum('net_amount'));
        $paid = (float) $enrollments->sum(fn ($e) => (float) $e->schoolFees->sum('amount_paid'));
        $rem  = (float) $enrollments->sum(fn ($e) => (float) $e->schoolFees->sum('remaining_amount'));

        return [
            [
                'label' => __('mtschool::finances.total_due'),
                'value' => number_format($due, 0, ',', ' '),
                'icon'  => 'banknotes',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::finances.total_paid'),
                'value' => number_format($paid, 0, ',', ' '),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::finances.total_remaining'),
                'value' => number_format($rem, 0, ',', ' '),
                'icon'  => 'clock',
                'color' => 'danger',
            ],
        ];
    }
}
