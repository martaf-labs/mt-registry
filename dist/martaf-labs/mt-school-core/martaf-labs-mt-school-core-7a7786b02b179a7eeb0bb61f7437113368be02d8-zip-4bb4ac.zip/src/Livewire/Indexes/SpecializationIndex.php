<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Specialization;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class SpecializationIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Specialization::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = Specialization::find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'code',
                'label'       => __('mtschool::structure.col_specialization'),
                'value'       => $data?->code,
                'showLetters' => true,
                'letters'     => $data?->abbreviation ?? $data?->code,
                'metaDatas'   => array_filter([
                    __('mtschool::structure.level_count_assoc', ['n' => $data?->gradeLevels()->count()]),
                ]),
            ],

            'othersColumns' => [
                'abbreviation' => [
                    'label' => __('mtschool::structure.abbreviation'),
                    'value' => $data?->abbreviation,
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_f') : __('mtschool::common.inactive_f'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'specialization',
            'model_plural' => 'specializations',
            'mainLabel'    => __('mtschool::structure.specializations'),
            'title'        => __('mtschool::structure.specializations'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'code',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code', 'abbreviation'],
            'searchableFields' => [
                'direct'    => ['code', 'abbreviation'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => Specialization::count(),
                'icon'  => 'academic-cap',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active'),
                'value' => Specialization::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
