<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Teacher;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Enseignants (Teacher = StaffMember type=TEACHER + extension pédagogique).
 * Les colonnes nom/contact sont déléguées à la relation `staff`.
 */
class TeacherIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Teacher::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        $custom = [];

        // « Créer un accès portail » seulement si l'enseignant n'a pas encore de compte.
        $teacher = Teacher::find($rowId);
        if ($teacher && ! app(PortalAccountService::class)->accountFor($teacher)) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'provisionPortal',
                'params' => $rowId,
                'label'  => __('mtschool::portal.create_account'),
                'icon'   => 'identification',
            ];
        }

        return [
            'edit'   => true,
            'delete' => true,
            'custom' => $custom,
        ];
    }

    public function columns($rowId = null): array
    {
        $data    = $rowId ? Teacher::with(['staff', 'primarySubject', 'subjects'])->find($rowId) : null;
        $staff   = $data?->staff;

        return [
            'firstColumn' => [
                'field'       => 'full_name',
                'label'       => __('mtschool::students.col_teacher'),
                'value'       => $staff?->full_name,
                // Photo (média vedette du StaffMember) si présente, sinon repli initiales.
                'showImage'   => true,
                'image'       => $staff?->getVariantImage('thumbnail') ?: null,
                'showLetters' => true,
                'letters'     => $staff ? mb_substr($staff->first_name ?? '', 0, 1) . mb_substr($staff->last_name ?? '', 0, 1) : null,
                'metaDatas'   => array_filter([
                    $data?->primarySubject?->code,
                    $staff?->email,
                    $staff?->phone,
                ]),
            ],

            'othersColumns' => [
                'primary_subject' => [
                    'label' => __('mtschool::students.primary_subject'),
                    'value' => $data?->primarySubject?->label ?? '—',
                ],
                'qualified' => [
                    'label' => __('mtschool::students.qualified_subjects'),
                    'value' => __('mtschool::students.subject_count', ['n' => $data?->subjects?->count() ?? 0]),
                ],
                'contract_hours' => [
                    'label' => __('mtschool::students.contract_hours'),
                    'value' => $data?->contract_hours
                        ? __('mtschool::students.hours_suffix', ['n' => rtrim(rtrim((string) $data->contract_hours, '0'), '.')])
                        : '—',
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $staff?->active ? __('mtschool::common.active_m') : __('mtschool::common.inactive_m'),
                    'badgeDatas' => $staff?->active
                        ? ['label' => __('mtschool::common.active_m'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_m'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'teacher',
            'model_plural' => 'teachers',
            'mainLabel'    => __('mtschool::students.teachers'),
            'title'        => __('mtschool::students.teachers'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['id'],
            'searchableFields' => [
                'direct'    => ['degree'],
                'relations' => [
                    'staff' => ['last_name', 'first_name', 'email', 'phone'],
                ],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::students.stat_teachers'),
                'value' => Teacher::count(),
                'icon'  => 'chalkboard',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active_m'),
                'value' => Teacher::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
