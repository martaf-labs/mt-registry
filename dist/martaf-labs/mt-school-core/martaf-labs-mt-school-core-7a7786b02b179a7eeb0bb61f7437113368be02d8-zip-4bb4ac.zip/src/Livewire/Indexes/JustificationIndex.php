<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Illuminate\Support\Facades\Storage;
use Mt\MtSchoolCore\Models\AbsenceJustification;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Index générique des JUSTIFICATIFS D'ABSENCE déposés par les parents :
 * approuver (→ absences de la période marquées justifiées) ou refuser (motif).
 */
class JustificationIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return AbsenceJustification::class;
    }

    public function mainActions(): array
    {
        return ['create' => false, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        $j = AbsenceJustification::find($rowId);
        $custom = [];

        if ($j?->status === 'pending') {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'approve',
                'params' => $rowId,
                'label'  => __('mtschool::portal.approve'),
                'icon'   => 'check-circle',
            ];
            $custom[] = [
                'type'    => 'livewire',
                'method'  => 'openReject',
                'params'  => $rowId,
                'label'   => __('mtschool::portal.reject'),
                'icon'    => 'x-circle',
                'variant' => 'danger',
            ];
        }

        if ($j?->document) {
            $custom[] = [
                'type'   => 'route',
                'route'  => Storage::disk('public')->url($j->document),
                'target' => '_blank',
                'label'  => __('mtschool::portal.view_document'),
                'icon'   => 'document-text',
            ];
        }

        return ['edit' => false, 'delete' => false, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $j = AbsenceJustification::with(['enrollment.student', 'enrollment.classroom'])->find($rowId);

        $statusVariant = ['pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger'][$j?->status] ?? 'secondary';

        return [
            'firstColumn' => [
                'field'       => 'id',
                'label'       => __('mtschool::students.col_student'),
                'value'       => $j?->enrollment?->student?->full_name_reverse ?? $j?->enrollment?->student?->full_name ?? '—',
                'showLetters' => true,
                'letters'     => $j?->enrollment?->student?->initials,
                'metaDatas'   => array_filter([$j?->enrollment?->classroom?->code]),
            ],

            'othersColumns' => [
                'period' => [
                    'label' => __('mtschool::portal.period'),
                    'value' => $j
                        ? $j->start_date?->format('d/m/Y') . ' → ' . $j->end_date?->format('d/m/Y')
                        : '—',
                ],
                'reason' => [
                    'label' => __('mtschool::portal.reason'),
                    'value' => $j?->reason ? __('mtschool::portal.reason_' . $j->reason) : '—',
                ],
                'status' => [
                    'label'      => __('mtschool::pedagogy.sup_state'),
                    'value'      => $j?->status ? __('mtschool::portal.justif_' . $j->status) : '—',
                    'badgeDatas' => $j?->status ? [
                        'label' => __('mtschool::portal.justif_' . $j->status),
                        'type'  => $statusVariant,
                    ] : [],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'justification',
            'model_plural' => 'justifications',
            'mainLabel'    => __('mtschool::portal.justify_admin_title'),
            'title'        => __('mtschool::portal.justify_admin_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => false,
                'perPage'              => 25,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['id'],
            'searchableFields' => [],
        ];
    }

    public function getFiltersConfig(): array
    {
        return [
            'status' => [
                'label'   => __('mtschool::pedagogy.sup_state'),
                'type'    => 'select',
                'options' => collect(['pending', 'approved', 'rejected'])
                    ->mapWithKeys(fn ($s) => [$s => __('mtschool::portal.justif_' . $s)])->toArray(),
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::portal.justif_pending'),
                'value' => AbsenceJustification::where('status', 'pending')->count(),
                'icon'  => 'clock',
                'color' => 'warning',
            ],
            [
                'label' => __('mtschool::portal.justif_approved'),
                'value' => AbsenceJustification::where('status', 'approved')->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::portal.justif_rejected'),
                'value' => AbsenceJustification::where('status', 'rejected')->count(),
                'icon'  => 'x-circle',
                'color' => 'danger',
            ],
        ];
    }
}
