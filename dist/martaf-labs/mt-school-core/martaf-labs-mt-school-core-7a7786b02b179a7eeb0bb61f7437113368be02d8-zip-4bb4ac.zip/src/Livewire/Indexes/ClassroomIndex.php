<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

class ClassroomIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Classroom::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = Classroom::with('gradeLevel', 'schoolYear', 'specialization', 'room')->find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'code',
                'label'       => __('mtschool::structure.col_classroom'),
                'value'       => $data?->code,
                'showLetters' => true,
                'letters'     => $data?->abbreviation ?? $data?->code,
                'metaDatas'   => array_filter([
                    $data?->gradeLevel?->code,
                    $data?->schoolYear?->code,
                    $data?->specialization?->abbreviation,
                ]),
            ],

            'othersColumns' => [
                'enrollment' => [
                    'label' => __('mtschool::structure.enrollment'),
                    'value' => ($data?->current_enrollment ?? 0) . ' / ' . ($data?->max_capacity ?? '—'),
                ],
                'room' => [
                    'label' => __('mtschool::structure.col_room'),
                    'value' => $data?->room?->code ?? '—',
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_f') : __('mtschool::common.inactive_f'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'classroom',
            'model_plural' => 'classrooms',
            'mainLabel'    => __('mtschool::structure.classrooms'),
            'title'        => __('mtschool::structure.classrooms'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'code',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code'],
            'searchableFields' => [
                'direct'    => ['code', 'abbreviation'],
                'relations' => [
                    'gradeLevel' => ['code'],
                    'schoolYear' => ['code'],
                ],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => Classroom::count(),
                'icon'  => 'building-office',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active'),
                'value' => Classroom::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::structure.stat_enrolled'),
                'value' => Classroom::sum('current_enrollment'),
                'icon'  => 'users',
                'color' => 'info',
            ],
        ];
    }
}
