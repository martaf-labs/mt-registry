<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Illuminate\Support\Facades\Storage;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtSchoolCore\Models\Teacher;
use Mt\MtSchoolCore\Models\TeachingResource;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Supervision ADMIN des ressources pédagogiques (instance base-index) : documents +
 * liens partagés par les enseignants, filtres, modération (dépublier / supprimer).
 */
class ResourceSupervisionIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return TeachingResource::class;
    }

    public function mainActions(): array
    {
        return ['create' => false, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        $r = TeachingResource::find($rowId);
        $canManage = auth()->user()?->can('school.resources.manage');

        $custom = [];

        // Ouvrir la ressource (lien externe ou fichier) — nouvel onglet.
        $url = $r?->type === 'link' ? $r?->external_url : ($r?->file ? Storage::disk('public')->url($r->file) : null);
        if ($url) {
            $custom[] = [
                'type'   => 'route',
                'route'  => $url,
                'target' => '_blank',
                'label'  => __('mtschool::pedagogy.sup_open_resource'),
                'icon'   => 'arrow-up-tray',
            ];
        }

        if ($canManage) {
            $custom[] = [
                'type'   => 'livewire',
                'method' => 'togglePublish',
                'params' => $rowId,
                'label'  => $r?->published ? __('mtschool::pedagogy.sup_unpublish') : __('mtschool::pedagogy.sup_publish'),
                'icon'   => $r?->published ? 'x-circle' : 'check-circle',
            ];
            $custom[] = [
                'type'    => 'livewire',
                'method'  => 'deleteResource',
                'params'  => $rowId,
                'label'   => __('mtschool::common.delete'),
                'icon'    => 'trash',
                'variant' => 'danger',
            ];
        }

        return ['edit' => false, 'delete' => false, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $r = $rowId ? TeachingResource::with(['classroom', 'gradeLevel', 'subject', 'teacher.staff'])->find($rowId) : null;

        $isLink = $r?->type === 'link';

        return [
            'firstColumn' => [
                'field'     => 'title',
                'label'     => __('mtschool::pedagogy.title_field'),
                'value'     => $r?->title,
                'metaDatas' => array_filter([
                    $r && $r->file_size ? number_format($r->file_size / 1024, 0, ',', ' ') . ' Ko' : null,
                ]),
            ],
            'othersColumns' => [
                'type' => [
                    'label'      => __('mtschool::pedagogy.sup_type'),
                    'value'      => $r ? __('mtschool::pedagogy.sup_type_' . $r->type) : '—',
                    'badgeDatas' => $r ? ['label' => __('mtschool::pedagogy.sup_type_' . $r->type), 'type' => $isLink ? 'info' : 'secondary'] : [],
                ],
                'subject'   => ['label' => __('mtschool::pedagogy.sup_subject'), 'value' => $r?->subject?->label ?? '—'],
                'classroom' => ['label' => __('mtschool::pedagogy.sup_class'), 'value' => $r?->classroom?->code ?? $r?->gradeLevel?->label ?? '—'],
                'teacher'   => ['label' => __('mtschool::pedagogy.sup_teacher'), 'value' => $r?->teacher?->full_name ?? '—'],
                'metrics'   => [
                    'label' => __('mtschool::pedagogy.sup_downloads') . ' / ' . __('mtschool::pedagogy.sup_views'),
                    'value' => $r ? $r->downloads . ' / ' . $r->views : '0 / 0',
                    'align' => 'center',
                ],
                'state' => [
                    'label'      => __('mtschool::pedagogy.sup_state'),
                    'value'      => $r?->published ? __('mtschool::pedagogy.sup_published') : __('mtschool::pedagogy.sup_unpublished'),
                    'badgeDatas' => $r ? ['label' => $r->published ? __('mtschool::pedagogy.sup_published') : __('mtschool::pedagogy.sup_unpublished'), 'type' => $r->published ? 'success' : 'secondary'] : [],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'resource',
            'model_plural' => 'resources',
            'mainLabel'    => __('mtschool::pedagogy.sup_resources_title'),
            'title'        => __('mtschool::pedagogy.sup_resources_title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'created_at',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['created_at', 'title'],
            'searchableFields' => ['direct' => ['title'], 'relations' => []],
        ];
    }

    public function getFiltersConfig(): array
    {
        return [
            'class_id' => [
                'label'   => __('mtschool::pedagogy.sup_class'),
                'type'    => 'select',
                'options' => Classroom::orderBy('code')->pluck('code', 'id')->toArray(),
            ],
            'subject_id' => [
                'label'   => __('mtschool::pedagogy.sup_subject'),
                'type'    => 'select',
                'options' => Subject::orderBy('code')->get()->mapWithKeys(fn ($s) => [$s->id => $s->label])->toArray(),
            ],
            'teacher_id' => [
                'label'   => __('mtschool::pedagogy.sup_teacher'),
                'type'    => 'select',
                'options' => Teacher::with('staff')->get()->sortBy('full_name')->mapWithKeys(fn ($t) => [$t->id => $t->full_name])->toArray(),
            ],
            'type' => [
                'label'   => __('mtschool::pedagogy.sup_type'),
                'type'    => 'select',
                'options' => [
                    'document' => __('mtschool::pedagogy.sup_type_document'),
                    'link'     => __('mtschool::pedagogy.sup_type_link'),
                ],
            ],
            'visibility' => [
                'label'   => __('mtschool::pedagogy.sup_state'),
                'type'    => 'select',
                'options' => [
                    'published'   => __('mtschool::pedagogy.sup_published'),
                    'unpublished' => __('mtschool::pedagogy.sup_unpublished'),
                ],
            ],
        ];
    }

    public function applyFilters($query, array $activeFilters): void
    {
        foreach (['class_id', 'subject_id', 'teacher_id'] as $col) {
            if (! empty($activeFilters[$col])) {
                $query->where($col, $activeFilters[$col]);
            }
        }
        if (! empty($activeFilters['type'])) {
            $query->ofType($activeFilters['type']);
        }
        match ($activeFilters['visibility'] ?? null) {
            'published'   => $query->where('published', true),
            'unpublished' => $query->where('published', false),
            default       => null,
        };
    }

    public function getStatistics(): array
    {
        return [
            ['label' => __('mtschool::pedagogy.sup_total'), 'value' => TeachingResource::count(), 'icon' => 'folder', 'color' => 'primary'],
            ['label' => __('mtschool::pedagogy.sup_published'), 'value' => TeachingResource::published()->count(), 'icon' => 'check-circle', 'color' => 'success'],
            ['label' => __('mtschool::pedagogy.sup_downloads'), 'value' => (int) TeachingResource::sum('downloads'), 'icon' => 'arrow-up-tray', 'color' => 'info'],
            ['label' => __('mtschool::pedagogy.sup_views'), 'value' => (int) TeachingResource::sum('views'), 'icon' => 'chart-bar', 'color' => 'warning'],
        ];
    }
}
