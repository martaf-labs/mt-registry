<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Enums\SubjectGroup;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtUi\Livewire\Indexes\GenericIndex;

/**
 * Catalogue des matières de l'établissement (TENANT).
 * Les coefficients par niveau vivent dans la maquette (Curriculum), pas ici.
 */
class SubjectIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Subject::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data  = Subject::find($rowId);
        $group = $data?->group;

        return [
            'firstColumn' => [
                'field'       => 'label',
                'label'       => __('mtschool::structure.col_subject'),
                'value'       => $data?->label,
                'showLetters' => true,
                'letters'     => $data?->abbreviation ?? $data?->code,
                'metaDatas'   => array_filter([
                    $data?->code,
                    $group?->label(),
                ]),
            ],

            'othersColumns' => [
                'group' => [
                    'label'      => __('mtschool::structure.group'),
                    'value'      => $group?->label() ?? '—',
                    'badgeDatas' => $group
                        ? ['label' => $group->label(), 'color' => 'info']
                        : null,
                ],
                'is_core' => [
                    'label'      => __('mtschool::structure.core_curriculum'),
                    'value'      => $data?->is_core ? __('mtschool::common.yes') : __('mtschool::common.no'),
                    'badgeDatas' => $data?->is_core
                        ? ['label' => __('mtschool::structure.core_curriculum'), 'color' => 'primary']
                        : null,
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_f') : __('mtschool::common.inactive_f'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'subject',
            'model_plural' => 'subjects',
            'mainLabel'    => __('mtschool::structure.subjects'),
            'title'        => __('mtschool::structure.subjects'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'code',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code', 'abbreviation'],
            'searchableFields' => [
                'direct'    => ['code', 'abbreviation'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => Subject::count(),
                'icon'  => 'book',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active'),
                'value' => Subject::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
            [
                'label' => __('mtschool::structure.stat_core'),
                'value' => Subject::core()->count(),
                'icon'  => 'star',
                'color' => 'warning',
            ],
        ];
    }
}
