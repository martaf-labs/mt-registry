<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Fees;

use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\FeeScheduleIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

/**
 * Écran Grille tarifaire = base-index STANDARD (liste des lignes de grille de
 * l'année active) ; création/édition d'une ligne via base-form, comme les
 * autres modules. Remplace l'ancien FeeScheduleManager (vue bespoke).
 */
#[Layout('mt::components.layouts.app')]
class FeeScheduleIndexComponent extends BaseIndex
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public function indexClass(): string
    {
        return FeeScheduleIndex::class;
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('fee_schedule', __('mtschool::finances.schedule_title'))) {
            return $gate;
        }

        return parent::render();
    }
}
