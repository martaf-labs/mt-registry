<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Fees;

use Mt\MtSchoolCore\Livewire\Forms\FeeScheduleForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class FeeSchedulesFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return FeeScheduleForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::finances.schedule_line');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::finances.schedule_title');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('fee_schedule', __('mtschool::finances.schedule_title'))->add(__('mtschool::common.new_m'), '#')->get()
            : navItems('fee_schedule', __('mtschool::finances.schedule_title'))
                ->add($data->feeType?->code ?? __('mtschool::finances.schedule_line'), mt_get_route('fee_schedules'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'finances.fees.schedule';
    }

    public function steps(): array
    {
        return [];
    }
}
