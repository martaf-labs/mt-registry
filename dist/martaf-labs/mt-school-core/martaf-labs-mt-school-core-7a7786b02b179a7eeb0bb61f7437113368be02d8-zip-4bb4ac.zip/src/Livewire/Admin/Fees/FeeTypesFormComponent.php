<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Fees;

use Mt\MtSchoolCore\Livewire\Forms\FeeTypeForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class FeeTypesFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return FeeTypeForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::academics.fee_type_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::academics.fee_type_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('fee_type', __('mtschool::academics.fee_types'))->add(__('mtschool::common.new_m'), '#')->get()
            : navItems('fee_type', __('mtschool::academics.fee_types'))
                ->add($data->code ?? __('mtschool::academics.fee_type_singular'), mt_get_route('finances_fees'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'finances.fees';
    }

    public function steps(): array
    {
        return [];
    }
}
