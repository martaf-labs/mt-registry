<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Announcements;

use Mt\MtSchoolCore\Livewire\Forms\AnnouncementForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class AnnouncementsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return AnnouncementForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::academics.announcement_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::academics.announcement_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('announcement', __('mtschool::academics.announcements'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('announcement', __('mtschool::academics.announcements'))
                ->add($data->title ?? __('mtschool::academics.announcement_singular'), mt_get_route('communication_announcements'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'communication.announcements';
    }

    public function steps(): array
    {
        return [];
    }
}
