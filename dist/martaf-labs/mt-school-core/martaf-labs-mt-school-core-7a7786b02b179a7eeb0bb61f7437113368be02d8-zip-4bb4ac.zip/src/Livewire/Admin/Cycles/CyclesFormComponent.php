<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Cycles;

use Mt\MtSchoolCore\Livewire\Forms\CycleForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class CyclesFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return CycleForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.cycle_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.cycle_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('cycle', __('mtschool::structure.cycles'))->add(__('mtschool::common.new_m'), '#')->get()
            : navItems('cycle', __('mtschool::structure.cycles'))
                ->add($data->code, mt_get_route('cycles'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.cycles';
    }

    public function steps(): array
    {
        return [];
    }
}
