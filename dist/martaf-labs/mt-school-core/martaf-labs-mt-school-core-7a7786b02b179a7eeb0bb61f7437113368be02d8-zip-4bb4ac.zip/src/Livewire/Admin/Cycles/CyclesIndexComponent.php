<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Cycles;

use Mt\MtSchoolCore\Livewire\Indexes\CycleIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class CyclesIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return CycleIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.cycles'));
    }
}
