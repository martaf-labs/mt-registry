<?php

namespace Mt\MtSchoolCore\Livewire\Admin\SchoolYears;

use Mt\MtSchoolCore\Livewire\Indexes\SchoolYearIndex;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtUi\Livewire\Base\BaseIndex;

class SchoolYearsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return SchoolYearIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.school_years'));
    }

    public function toggleActive(int $id): void
    {
        $schoolYear = SchoolYear::find($id);
        if (!$schoolYear) {
            return;
        }

        if ($schoolYear->is_active) {
            $schoolYear->update(['is_active' => false]);
        } else {
            $schoolYear->activate();
        }

        $this->dispatch('refresh');
    }

    public function toggleClosed(int $id): void
    {
        $schoolYear = SchoolYear::find($id);
        if (!$schoolYear) {
            return;
        }

        if ($schoolYear->is_closed) {
            $schoolYear->update(['is_closed' => false]);
        } else {
            $schoolYear->close();
        }

        $this->dispatch('refresh');
    }
}
