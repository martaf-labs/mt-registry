<?php

namespace Mt\MtSchoolCore\Livewire\Admin\SchoolYears;

use Mt\MtSchoolCore\Livewire\Forms\SchoolYearForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class SchoolYearsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return SchoolYearForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.year_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.year_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('school_year', __('mtschool::structure.school_years'))
                ->add(__('mtschool::common.new_f'), '#')
                ->get()
            : navItems('school_year', __('mtschool::structure.school_years'))
                ->add($data->code, mt_get_route('school_years'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.school-years';
    }

    public function steps(): array
    {
        return [];
    }
}
