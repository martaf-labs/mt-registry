<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Students;

use Mt\MtSchoolCore\Livewire\Shows\StudentProfile;
use Mt\MtUi\Livewire\Base\BaseShow;

/**
 * Fiche élève = INSTANCE de base-profile (fiche de PERSONNE — avatar rond,
 * onglets, sections). Toute la présentation vient du moteur base-show ;
 * la configuration vit dans StudentProfile (Shows\GenericProfile).
 */
class StudentsProfileComponent extends BaseShow
{
    public function showClass(): string
    {
        return StudentProfile::class;
    }
}
