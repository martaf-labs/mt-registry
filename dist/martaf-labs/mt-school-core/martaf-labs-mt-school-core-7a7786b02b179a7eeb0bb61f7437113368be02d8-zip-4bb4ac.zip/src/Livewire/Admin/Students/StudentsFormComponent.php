<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Students;

use Mt\MtSchoolCore\Livewire\Forms\StudentEnrollmentForm;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtUi\Livewire\Base\BaseForm;

class StudentsFormComponent extends BaseForm
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public function mount(?int $id = null): void
    {
        parent::mount($id);

        if ($this->mode !== 'create') {
            return;
        }

        // Garde-fou : aucune inscription possible sans classe ouverte (année active)
        $hasClasses = activeSchoolYearId() !== null
            && Classroom::where('active', true)->exists();

        if (! $hasClasses) {
            session()->flash('error', __('mtschool::enrollment.no_open_class_error'));
            $this->redirectRoute('structure.classrooms', navigate: true);
            return;
        }

        if (empty($this->form->date)) {
            $this->form->date = now()->format('Y-m-d');
        }
    }

    public function formClass(): string
    {
        return StudentEnrollmentForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::enrollment.model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::enrollment.model_name_plural');
    }

    public function getRedirectRouteName(): string
    {
        return 'students.index';
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('student', __('mtschool::enrollment.nav_students'))->add(__('mtschool::enrollment.nav_enroll'), '#')->get()
            : navItems('student', __('mtschool::enrollment.nav_students'))
                ->add($data->student?->full_name ?? __('mtschool::enrollment.step_finalize_title'), mt_get_route('students_index'))
                ->add(__('mtschool::enrollment.nav_edit'), '#')
                ->get();
    }

    /**
     * Étapes — masquées en édition (mono-étape).
     */
    public function steps(): array
    {
        if ($this->mode === 'edit') {
            return [];
        }

        return [
            1 => ['title' => __('mtschool::enrollment.step_cycle_title'),       'icon' => 'rectangle-stack',           'description' => __('mtschool::enrollment.step_cycle_desc'),          'fields' => ['cycle_id']],
            2 => ['title' => __('mtschool::enrollment.step_level_title'),      'icon' => 'academic-cap',              'description' => __('mtschool::enrollment.step_level_desc'),                'fields' => ['grade_level_id']],
            3 => ['title' => __('mtschool::enrollment.step_class_title'),      'icon' => 'user-group',                'description' => __('mtschool::enrollment.step_class_desc'),               'fields' => ['class_id']],
            4 => ['title' => __('mtschool::enrollment.step_student_title'),       'icon' => 'user',                      'description' => __('mtschool::enrollment.step_student_desc'),       'fields' => ['student_existing_id']],
            5 => ['title' => __('mtschool::enrollment.step_new_student_title'),'icon' => 'user-plus',                 'description' => __('mtschool::enrollment.step_new_student_desc'),            'fields' => [
                'student.last_name', 'student.first_name', 'student.gender', 'student.birth_date', 'student.birth_place',
                'student.nationality', 'student.birth_certificate_number', 'student.is_repeating', 'student.is_transferred',
                'student.previous_school', 'student.previous_class', 'student.previous_year', 'student.notes',
            ]],
            6 => ['title' => __('mtschool::enrollment.step_guardian_title'),      'icon' => 'user-circle',               'description' => __('mtschool::enrollment.step_guardian_desc'),              'fields' => ['guardian_existing_id', 'guardian_relationship']],
            7 => ['title' => __('mtschool::enrollment.step_new_guardian_title'),'icon' => 'user-circle',             'description' => __('mtschool::enrollment.step_new_guardian_desc'),              'fields' => [
                'guardian.title', 'guardian.gender', 'guardian.last_name', 'guardian.first_name', 'guardian.phone',
                'guardian.email', 'guardian.occupation', 'guardian.address', 'guardian_relationship',
                'guardian_is_primary', 'guardian_can_pickup', 'guardian_portal_access',
            ]],
            8 => ['title' => __('mtschool::enrollment.step_documents_title'),   'icon' => 'paper-clip',                'description' => __('mtschool::enrollment.step_documents_desc'),       'fields' => ['photo', 'birth_certificate', 'report_card', 'other_document']],
            9 => ['title' => __('mtschool::enrollment.step_finalize_title'), 'icon' => 'clipboard-document-check',  'description' => __('mtschool::enrollment.step_finalize_desc'),        'fields' => ['date', 'enrollment_notes']],
        ];
    }

    /**
     * Conditions d'affichage — alternance « existant / nouveau ».
     */
    public function stepCondition(int $step): bool
    {
        $noStudentChosen  = empty($this->form->student_existing_id);
        $noGuardianChosen = empty($this->form->guardian_existing_id);

        return match ($step) {
            // Choisir un élève existant : seulement s'il en existe
            4 => Student::count() > 0,
            // Nouvel élève : seulement si aucun élève existant choisi
            5 => $noStudentChosen,
            // Tuteur existant : seulement en flux nouvel élève, et s'il en existe
            6 => $noStudentChosen && Guardian::count() > 0,
            // Nouveau tuteur : flux nouvel élève + aucun tuteur existant choisi
            7 => $noStudentChosen && $noGuardianChosen,
            default => true,
        };
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('enrollments', __('mtschool::students.enrollments_title'))) {
            return $gate;
        }

        return parent::render();
    }
}
