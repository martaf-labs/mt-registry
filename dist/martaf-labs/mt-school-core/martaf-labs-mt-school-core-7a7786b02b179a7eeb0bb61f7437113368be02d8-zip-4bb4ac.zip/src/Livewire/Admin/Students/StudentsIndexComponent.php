<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Students;

use Illuminate\Support\Str;
use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\StudentIndex;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtUi\Livewire\Base\BaseIndex;

#[Layout('mt::components.layouts.app')]
class StudentsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return StudentIndex::class;
    }

    /** Crée un accès portail PARENT (compte du tuteur principal de l'élève) + identifiants. */
    public function provisionParentPortal(int $studentId): void
    {
        $student  = Student::find($studentId);
        $guardian = $student?->primaryContact()->first() ?? $student?->guardians()->first();

        if (! $guardian) {
            showAlert('error', __('mtschool::portal.no_guardian'));
            return;
        }

        try {
            $result = app(PortalAccountService::class)->provision($guardian);

            if ($result['created']) {
                showAlert('success', __('mtschool::portal.account_created', [
                    'email'    => $result['user']->email,
                    'password' => $result['password'],
                ]));
            } else {
                showAlert('info', __('mtschool::portal.account_exists', ['email' => $result['user']->email]));
            }
        } catch (\Throwable $e) {
            showAlert('error', $e->getMessage());
        }
    }

    /** Crée un accès portail ÉLÈVE (compte de l'élève) + identifiants. */
    public function provisionStudentPortal(int $studentId): void
    {
        $student = Student::find($studentId);
        if (! $student) {
            showAlert('error', __('mtschool::portal.no_guardian'));
            return;
        }

        // Login : e-mail de l'élève si présent, sinon identifiant généré depuis le
        // matricule (unique par école → suffixé par l'école pour l'unicité globale).
        $login = $student->email ?: (
            Str::slug($student->reference ?: ('eleve-' . $student->id))
            . '@el' . ($student->school_id ?? currentSchoolId()) . '.local'
        );

        try {
            $result = app(PortalAccountService::class)->provision($student, $login);

            if ($result['created']) {
                showAlert('success', __('mtschool::portal.account_created', [
                    'email'    => $result['user']->email,
                    'password' => $result['password'],
                ]));
            } else {
                showAlert('info', __('mtschool::portal.account_exists', ['email' => $result['user']->email]));
            }
        } catch (\Throwable $e) {
            showAlert('error', $e->getMessage());
        }
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::students.students'));
    }
}
