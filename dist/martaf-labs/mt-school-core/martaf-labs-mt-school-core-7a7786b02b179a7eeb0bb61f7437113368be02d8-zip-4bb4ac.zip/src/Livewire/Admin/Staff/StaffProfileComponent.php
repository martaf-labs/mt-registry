<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Staff;

use Mt\MtSchoolCore\Livewire\Shows\StaffProfile;
use Mt\MtUi\Livewire\Base\BaseShow;

/**
 * Fiche personnel = INSTANCE de base-profile (fiche de PERSONNE — avatar rond,
 * onglets, sections). La présentation vient du moteur base-show ; la config
 * vit dans StaffProfile (Shows\GenericProfile).
 */
class StaffProfileComponent extends BaseShow
{
    public function showClass(): string
    {
        return StaffProfile::class;
    }
}
