<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Staff;

use Mt\MtSchoolCore\Livewire\Indexes\StaffIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class StaffIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return StaffIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::students.stat_staff'));
    }
}
