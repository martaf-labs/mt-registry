<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Teachers;

use Mt\MtSchoolCore\Livewire\Forms\TeacherForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class TeachersFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return TeacherForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::students.teacher_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::students.teacher_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('teacher', __('mtschool::students.teachers'))->add(__('mtschool::common.new_m'), '#')->get()
            : navItems('teacher', __('mtschool::students.teachers'))
                ->add($data->full_name ?? __('mtschool::students.teacher_singular'), mt_get_route('staff_teachers'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'staff.teachers';
    }

    public function steps(): array
    {
        return [];
    }
}
