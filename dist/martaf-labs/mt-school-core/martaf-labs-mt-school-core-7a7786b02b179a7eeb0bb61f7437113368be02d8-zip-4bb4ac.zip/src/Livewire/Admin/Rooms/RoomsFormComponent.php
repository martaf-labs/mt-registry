<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Rooms;

use Mt\MtSchoolCore\Livewire\Forms\RoomForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class RoomsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return RoomForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.room_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.room_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('room', __('mtschool::structure.rooms'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('room', __('mtschool::structure.rooms'))
                ->add($data->code, mt_get_route('rooms'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.rooms';
    }

    public function steps(): array
    {
        return [];
    }
}
