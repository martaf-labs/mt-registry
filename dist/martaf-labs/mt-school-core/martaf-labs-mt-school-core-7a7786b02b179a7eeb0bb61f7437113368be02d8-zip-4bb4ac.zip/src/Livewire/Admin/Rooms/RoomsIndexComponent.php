<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Rooms;

use Mt\MtSchoolCore\Livewire\Indexes\RoomIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class RoomsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return RoomIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.rooms'));
    }
}
