<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Subjects;

use Mt\MtSchoolCore\Livewire\Indexes\SubjectIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class SubjectsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return SubjectIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.subjects'));
    }
}
