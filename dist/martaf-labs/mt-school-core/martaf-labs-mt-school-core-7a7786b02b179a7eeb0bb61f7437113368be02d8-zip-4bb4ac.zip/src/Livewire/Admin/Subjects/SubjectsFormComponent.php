<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Subjects;

use Mt\MtSchoolCore\Livewire\Forms\SubjectForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class SubjectsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return SubjectForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.subject_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.subject_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('subject', __('mtschool::structure.subjects'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('subject', __('mtschool::structure.subjects'))
                ->add($data->code ?? __('mtschool::structure.subject_singular'), mt_get_route('subjects'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.subjects';
    }

    public function steps(): array
    {
        return [];
    }
}
