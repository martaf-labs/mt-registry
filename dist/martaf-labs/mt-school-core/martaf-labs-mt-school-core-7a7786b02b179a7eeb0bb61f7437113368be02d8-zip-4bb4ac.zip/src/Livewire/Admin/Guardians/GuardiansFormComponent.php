<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Guardians;

use Mt\MtSchoolCore\Livewire\Forms\GuardianForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class GuardiansFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return GuardianForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::students.guardian_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::students.guardian_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('user-circle', __('mtschool::students.guardians'))
                ->add(__('mtschool::common.new_m'), '#')
                ->get()
            : navItems('user-circle', __('mtschool::students.guardians'))
                ->add($data->full_name, mt_get_route('guardians_profile', ['id' => $data->id]))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'students.guardians';
    }

    public function steps(): array
    {
        return [];
    }
}
