<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Guardians;

use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\GuardianIndex;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtUi\Livewire\Base\BaseIndex;

#[Layout('mt::components.layouts.app')]
class GuardiansIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return GuardianIndex::class;
    }

    /** Crée un accès portail (compte parent) pour le tuteur + affiche ses identifiants. */
    public function provisionPortal(int $guardianId): void
    {
        $guardian = Guardian::find($guardianId);
        if (! $guardian) {
            return;
        }

        try {
            $result = app(PortalAccountService::class)->provision($guardian);

            if ($result['created']) {
                showAlert('success', __('mtschool::portal.account_created', [
                    'email'    => $result['user']->email,
                    'password' => $result['password'],
                ]));
            } else {
                showAlert('info', __('mtschool::portal.account_exists', ['email' => $result['user']->email]));
            }
        } catch (\Throwable $e) {
            showAlert('error', $e->getMessage());
        }
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::students.guardians'));
    }
}
