<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Pedagogy;

use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\ResourceSupervisionIndex;
use Mt\MtSchoolCore\Models\TeachingResource;
use Mt\MtUi\Livewire\Base\BaseIndex;

/**
 * Supervision ADMIN des ressources pédagogiques = INSTANCE de base-index. Liste/stats/
 * filtres viennent du moteur ; ici la modération : (dé)publier + supprimer (permission
 * school.resources.manage). Le versant enseignant (création) vit sur le portail.
 */
#[Layout('mt::components.layouts.app')]
class ResourceSupervision extends BaseIndex
{
    public function indexClass(): string
    {
        return ResourceSupervisionIndex::class;
    }

    public function togglePublish(int $id): void
    {
        abort_unless(auth()->user()?->can('school.resources.manage'), 403);

        $r = TeachingResource::findOrFail($id);
        $r->update(['published' => ! $r->published]);
    }

    // ⚠️ NE PAS nommer delete() — méthode dédiée (supprime aussi le fichier physique).
    public function deleteResource(int $id): void
    {
        abort_unless(auth()->user()?->can('school.resources.manage'), 403);

        $r = TeachingResource::findOrFail($id);
        if ($r->file && Storage::disk('public')->exists($r->file)) {
            Storage::disk('public')->delete($r->file);
        }
        $r->delete();
        showAlert('success', __('mtschool::pedagogy.sup_res_deleted'));
    }
}
