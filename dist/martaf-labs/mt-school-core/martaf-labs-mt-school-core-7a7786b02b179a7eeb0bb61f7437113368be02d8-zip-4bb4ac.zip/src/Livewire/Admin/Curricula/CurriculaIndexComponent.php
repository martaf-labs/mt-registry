<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Curricula;

use Mt\MtSchoolCore\Livewire\Indexes\CurriculumIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class CurriculaIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return CurriculumIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.curricula'));
    }
}
