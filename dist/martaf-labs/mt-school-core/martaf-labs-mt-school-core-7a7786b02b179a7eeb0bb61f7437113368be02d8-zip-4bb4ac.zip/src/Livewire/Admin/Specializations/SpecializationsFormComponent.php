<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Specializations;

use Mt\MtSchoolCore\Livewire\Forms\SpecializationForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class SpecializationsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return SpecializationForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.spec_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.spec_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('specialization', __('mtschool::structure.specializations'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('specialization', __('mtschool::structure.specializations'))
                ->add($data->code, mt_get_route('specializations'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.specializations';
    }

    public function steps(): array
    {
        return [];
    }
}
