<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Specializations;

use Mt\MtSchoolCore\Livewire\Indexes\SpecializationIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class SpecializationsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return SpecializationIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.specializations'));
    }
}
