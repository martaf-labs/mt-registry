<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Results;

use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\ResultIndex;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\ReportCard;
use Mt\MtSchoolCore\Services\ReportCardComputer;
use Mt\MtSchoolCore\Services\ReportCardService;
use Mt\MtUi\Livewire\Base\BaseIndex;

/**
 * Écran Moyennes & Bulletins = INSTANCE de base-index. Le classement, les
 * stats et les filtres viennent du moteur ; ici la logique de pilotage :
 * calculer les moyennes/rangs, générer les bulletins, publier (+ notifier).
 * Remplace l'ancien ResultsManager (vue bespoke).
 */
#[Layout('mt::components.layouts.app')]
class ResultsIndexComponent extends BaseIndex
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public function indexClass(): string
    {
        return ResultIndex::class;
    }

    /** Classe + période OBLIGATOIRES : 1res valeurs par défaut (re-posées au reset). */
    protected function defaultFilters(): array
    {
        $classId  = Classroom::where('active', true)->orderBy('code')->value('id');
        $periodId = Period::orderBy('id')->value('id');

        return array_filter([
            'class_id'  => $classId ? (string) $classId : null,
            'period_id' => $periodId ? (string) $periodId : null,
        ]);
    }

    private function context(): array
    {
        return [
            (int) ($this->activeFilters['class_id'] ?? 0),
            (int) ($this->activeFilters['period_id'] ?? 0),
        ];
    }

    public function compute(): void
    {
        [$classId, $periodId] = $this->context();
        if (! $classId || ! $periodId) {
            return;
        }

        $summary = app(ReportCardComputer::class)->compute($classId, $periodId);

        showAlert('success', __('mtschool::academics.averages_computed_msg', [
            'count' => $summary['computed'],
            'avg'   => $summary['class_average'] !== null ? number_format($summary['class_average'], 2, ',', ' ') : '—',
        ]));
    }

    /** Fige les bulletins de la classe/période (recalcule + persiste les ReportCard). */
    public function generate(): void
    {
        [$classId, $periodId] = $this->context();
        if (! $classId || ! $periodId) {
            return;
        }

        $count = app(ReportCardService::class)->generateForClassroom($classId, $periodId);

        showAlert('success', __('mtschool::academics.report_cards_generated_msg', ['count' => $count]));
    }

    /** Publie (rend visibles sur le portail) tous les bulletins générés. */
    public function publish(): void
    {
        [$classId, $periodId] = $this->context();
        if (! $classId || ! $periodId) {
            return;
        }

        $enrollIds = Enrollment::where('class_id', $classId)->validated()->pluck('id');
        $count = 0;
        // Publier SANS notifier laisserait parents/élèves dans le noir : on notifie
        // chaque bulletin qui n'était pas déjà publié (pas de re-notification au re-clic).
        $notifier = app(\Mt\MtSchoolCore\Services\NotificationService::class);
        ReportCard::whereIn('enrollment_id', $enrollIds)
            ->where('period_id', $periodId)
            ->get()
            ->each(function (ReportCard $rc) use (&$count, $notifier) {
                $wasPublished = $rc->isPublished();
                $rc->publish();
                if (! $wasPublished) {
                    $notifier->notifyReportCardPublished($rc);
                }
                $count++;
            });

        showAlert('success', __('mtschool::academics.report_cards_published_msg', ['count' => $count]));
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('results', __('mtschool::academics.results_title'))) {
            return $gate;
        }

        return parent::render();
    }
}
