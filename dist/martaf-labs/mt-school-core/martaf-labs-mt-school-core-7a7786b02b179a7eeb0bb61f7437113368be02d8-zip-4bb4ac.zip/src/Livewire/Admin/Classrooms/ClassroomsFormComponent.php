<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Classrooms;

use Mt\MtSchoolCore\Livewire\Forms\ClassroomForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class ClassroomsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return ClassroomForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.class_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.class_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('classroom', __('mtschool::structure.classrooms'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('classroom', __('mtschool::structure.classrooms'))
                ->add($data->code, mt_get_route('classrooms'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.classrooms';
    }

    /**
     * Cascade Cycle → Niveau → Classe (création). Plat en édition.
     */
    public function steps(): array
    {
        if ($this->mode === 'edit') {
            return [];
        }

        return [
            1 => ['title' => __('mtschool::structure.cycle_select'),  'icon' => 'rectangle-stack', 'description' => __('mtschool::structure.step_cycle_class_desc'),          'fields' => ['cycle_id']],
            2 => ['title' => __('mtschool::structure.grade_level_select'), 'icon' => 'academic-cap',    'description' => __('mtschool::structure.step_level_class_desc'),         'fields' => ['grade_level_id']],
            3 => ['title' => __('mtschool::structure.classrooms'), 'icon' => 'user-group',      'description' => __('mtschool::structure.step_class_info_desc'),   'fields' => [
                'code', 'abbreviation', 'label',
                'specialization_id', 'room_id', 'teaching_language', 'max_capacity', 'active', 'notes',
            ]],
        ];
    }
}
