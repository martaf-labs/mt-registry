<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Assignments;

use Mt\MtSchoolCore\Livewire\Indexes\ClassAssignmentIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class AssignmentsIndexComponent extends BaseIndex
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public function indexClass(): string
    {
        return ClassAssignmentIndex::class;
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('assignments', __('mtschool::academics.assignments'))) {
            return $gate;
        }

        return parent::render()->title(__('mtschool::academics.assignments'));
    }
}
