<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Assessments;

use Mt\MtSchoolCore\Livewire\Forms\AssessmentForm;
use Mt\MtUi\Livewire\Base\BaseForm;

class AssessmentsFormComponent extends BaseForm
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public function formClass(): string
    {
        return AssessmentForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::academics.assessment_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::academics.assessment_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('assessment', __('mtschool::academics.assessments'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('assessment', __('mtschool::academics.assessments'))
                ->add($data->label ?? __('mtschool::academics.assessment_singular'), mt_get_route('academics_assessments'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'academics.assessments';
    }

    public function steps(): array
    {
        return [];
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('assessments', __('mtschool::academics.assessments'))) {
            return $gate;
        }

        return parent::render();
    }
}
