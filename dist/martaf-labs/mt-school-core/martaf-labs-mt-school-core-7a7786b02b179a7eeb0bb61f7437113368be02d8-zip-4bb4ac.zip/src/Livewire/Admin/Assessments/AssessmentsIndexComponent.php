<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Assessments;

use Mt\MtSchoolCore\Livewire\Indexes\AssessmentIndex;
use Mt\MtUi\Livewire\Base\BaseIndex;

class AssessmentsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return AssessmentIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::academics.assessments'));
    }
}
