<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Payments;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\PaymentIndex;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Services\FeeService;
use Mt\MtUi\Livewire\Base\BaseIndex;

/**
 * Écran Encaissement = INSTANCE de base-index (doctrine « vues généralistes
 * d'abord »). Liste/stats/filtre classe viennent du moteur ; ici la logique
 * métier : générer les frais dus, encaisser, accorder une bourse.
 * Remplace l'ancien PaymentsManager (vue bespoke).
 */
#[Layout('mt::components.layouts.app')]
class PaymentsIndexComponent extends BaseIndex
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    // Modale d'encaissement
    public bool $showPay = false;
    public ?int $payEnrollmentId = null;
    public string $payStudent = '';
    public $payAmount   = null;
    public string $payMethod = 'cash';
    public ?string $payDate = null;

    // Modale de bourse
    public bool $showScholarship = false;
    public ?int $schEnrollmentId = null;
    public string $schStudent = '';
    public string $schLabel = '';
    public string $schMode = 'percent';
    public $schValue = null;
    public $schFeeTypeId = null;

    public function indexClass(): string
    {
        return PaymentIndex::class;
    }

    /** Filtre classe OBLIGATOIRE : 1re classe active par défaut (re-posé au reset). */
    protected function defaultFilters(): array
    {
        $classId = Classroom::where('active', true)->orderBy('code')->value('id');

        return $classId ? ['class_id' => (string) $classId] : [];
    }

    /** Modales encaissement + bourse, rendues en fin de base-index. */
    public function extraPartials(): array
    {
        return ['mtschool::livewire.admin.payments.partials.modals'];
    }

    #[Computed]
    public function feeTypes(): array
    {
        return \Mt\MtSchoolCore\Models\FeeType::where('active', true)->orderBy('order')->get()
            ->mapWithKeys(fn ($ft) => [$ft->id => $ft->label])->toArray();
    }

    public function paymentMethods(): array
    {
        return [
            'cash'          => __('mtschool::finances.method_cash'),
            'mobile_money'  => __('mtschool::finances.method_mobile_money'),
            'bank_transfer' => __('mtschool::finances.method_bank_transfer'),
            'check'         => __('mtschool::finances.method_check'),
            'card'          => __('mtschool::finances.method_card'),
            'other'         => __('mtschool::finances.method_other'),
        ];
    }

    /** Génère les frais dus (grille tarifaire) pour la classe filtrée. */
    public function generate(): void
    {
        $classId = (int) ($this->activeFilters['class_id'] ?? 0);
        if (! $classId) {
            return;
        }

        $n = app(FeeService::class)->generateForClassroom($classId);
        showAlert('success', __('mtschool::finances.fees_generated_msg', ['n' => $n]));
    }

    public function openPayment(int $enrollmentId): void
    {
        $e = Enrollment::with(['student', 'schoolFees'])->find($enrollmentId);
        if (! $e) {
            return;
        }

        $remaining = (float) $e->schoolFees->sum('remaining_amount');

        $this->payEnrollmentId = $enrollmentId;
        $this->payStudent = $e->student?->full_name_reverse ?? $e->student?->full_name ?? '—';
        $this->payAmount  = $remaining > 0 ? $remaining : null;
        $this->payMethod  = 'cash';
        $this->payDate    = now()->format('Y-m-d');
        $this->showPay    = true;
        $this->dispatch('open-pay-modal');
    }

    public function savePayment(): void
    {
        $this->validate([
            'payAmount' => 'required|numeric|min:1',
            'payMethod' => 'required|string',
            'payDate'   => 'required|date',
        ], [], ['payAmount' => __('mtschool::finances.amount_field_required')]);

        $enrollment = Enrollment::findOrFail($this->payEnrollmentId);
        $allocated  = app(FeeService::class)->recordPayment(
            $enrollment, (float) $this->payAmount, $this->payMethod, $this->payDate
        );

        $this->showPay = false;
        showAlert('success', __('mtschool::finances.payment_saved_msg', ['amount' => number_format($allocated, 0, ',', ' ')]));
        $this->dispatch('close-modal', name: 'pay');
    }

    public function openScholarship(int $enrollmentId): void
    {
        $e = Enrollment::with('student')->find($enrollmentId);
        if (! $e) {
            return;
        }

        $this->schEnrollmentId = $enrollmentId;
        $this->schStudent  = $e->student?->full_name_reverse ?? $e->student?->full_name ?? '—';
        $this->schLabel    = '';
        $this->schMode     = 'percent';
        $this->schValue    = null;
        $this->schFeeTypeId = null;
        $this->showScholarship = true;
        $this->dispatch('open-sch-modal');
    }

    public function saveScholarship(): void
    {
        $this->validate([
            'schValue'     => 'required|numeric|min:0.01',
            'schMode'      => 'required|in:percent,amount',
            'schFeeTypeId' => 'nullable|integer',
        ], [], ['schValue' => __('mtschool::finances.value_field_required')]);

        $enrollment = Enrollment::findOrFail($this->schEnrollmentId);
        app(FeeService::class)->grantScholarship($enrollment, [
            'label'       => $this->schLabel ?: __('mtschool::finances.default_scholarship_label'),
            'mode'        => $this->schMode,
            'value'       => (float) $this->schValue,
            'fee_type_id' => $this->schFeeTypeId ?: null,
        ]);

        $this->showScholarship = false;
        showAlert('success', __('mtschool::finances.scholarship_granted_msg'));
        $this->dispatch('close-modal', name: 'scholarship');
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('payments', __('mtschool::finances.payments_title'))) {
            return $gate;
        }

        return parent::render();
    }
}
