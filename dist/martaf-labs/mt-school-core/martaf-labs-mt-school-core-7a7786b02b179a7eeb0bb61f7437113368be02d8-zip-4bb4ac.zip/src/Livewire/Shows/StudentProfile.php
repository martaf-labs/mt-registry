<?php

namespace Mt\MtSchoolCore\Livewire\Shows;

use Mt\MtSchoolCore\Enums\Relationship;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtUi\Livewire\Shows\GenericProfile;

/**
 * FICHE ÉLÈVE (base-profile) — fiche de PERSONNE : avatar rond, onglets, sections.
 * Onglets : Profil (identité + champs perso EAV) · Scolarité (inscriptions) ·
 * Tuteurs · Finances (frais + bourses). Lecture seule : les modifications
 * passent par le form d'édition / l'assistant / les écrans dédiés.
 */
class StudentProfile extends GenericProfile
{
    public static function modelClass(): string
    {
        return Student::class;
    }

    public function configuration(): array
    {
        return [
            'model'        => 'student',
            'model_plural' => 'students',
            'mainLabel'    => __('mtschool::students.students'),
            'title'        => __('mtschool::students.student_model_name'),
            'features'     => ['canAddImages' => false], // photo unique → éditée dans le formulaire
        ];
    }

    public function header($s): array
    {
        $enrollment = $s->currentEnrollment;

        $badges = [];
        if ($enrollment?->status) {
            $badges[] = ['label' => $enrollment->status->label(), 'type' => $enrollment->status->badge()];
        }
        $badges[] = $s->active
            ? ['label' => __('mtschool::common.active_m'), 'type' => 'success']
            : ['label' => __('mtschool::common.inactive_m'), 'type' => 'secondary'];

        return [
            'image'    => $s->getVariantImage('medium') ?: null,
            'letters'  => $s->initials,
            'title'    => $s->full_name,
            'subtitle' => implode(' · ', array_filter([
                $s->reference,
                $enrollment?->classroom?->code,
                $s->gender === 'M' ? __('mtschool::students.gender_m') : ($s->gender === 'F' ? __('mtschool::students.gender_f') : null),
                $s->birth_date?->format('d/m/Y'),
            ])),
            'badges'   => $badges,
        ];
    }

    public function actions($s): array
    {
        $actions = [
            [
                'label'   => __('mtschool::common.edit'),
                'icon'    => 'pencil',
                'route'   => mt_get_route('students_edit', ['id' => $s->id]),
                'variant' => 'primary',
            ],
        ];

        // Relevé financier PDF (si inscrit cette année)
        if ($s->currentEnrollment) {
            $actions[] = [
                'label'  => __('mtschool::finances.receipt_statement'),
                'icon'   => 'document-text',
                'route'  => mt_get_route('finances_payments_receipt', ['enrollment' => $s->currentEnrollment->id]),
                'target' => '_blank',
            ];
        }

        return $actions;
    }

    public function tabs(): array
    {
        return [
            'profile'   => __('mtschool::students.tab_profile'),
            'schooling' => __('mtschool::students.tab_schooling'),
            'guardians' => __('mtschool::students.guardians'),
            'finances'  => __('mtschool::students.tab_finances'),
        ];
    }

    public function sections($s): array
    {
        $sections = [];

        /* ---------- Onglet Profil ---------- */
        $sections[] = [
            'tab'   => 'profile',
            'type'  => 'attributes',
            'title' => __('mtschool::students.identity'),
            'items' => [
                __('mtschool::students.last_name')   => $s->last_name,
                __('mtschool::students.first_name')  => $s->first_name,
                __('mtschool::students.gender')      => $s->gender === 'M' ? __('mtschool::students.gender_m') : ($s->gender === 'F' ? __('mtschool::students.gender_f') : null),
                __('mtschool::students.birth_date')  => $s->birth_date?->format('d/m/Y'),
                __('mtschool::students.birth_place') => $s->birth_place,
                __('mtschool::students.nationality') => $s->nationality,
            ],
        ];

        $sections[] = [
            'tab'   => 'profile',
            'type'  => 'attributes',
            'title' => __('mtschool::students.contact_info'),
            'items' => [
                __('mtschool::students.email')   => $s->email,
                __('mtschool::students.phone')   => $s->phone,
                __('mtschool::students.address') => $s->address,
            ],
        ];

        // Champs personnalisés de l'école (EAV) — seulement si des champs sont définis.
        $customItems = [];
        foreach ($s->customFieldDefinitions() as $definition) {
            $customItems[$definition->label] = $s->customField($definition->key);
        }
        if (! empty($customItems)) {
            $sections[] = [
                'tab'   => 'profile',
                'type'  => 'attributes',
                'title' => __('mtschool::custom_fields.title'),
                'items' => $customItems,
            ];
        }

        /* ---------- Onglet Scolarité ---------- */
        $current = $s->currentEnrollment;
        $sections[] = [
            'tab'   => 'schooling',
            'type'  => 'attributes',
            'title' => __('mtschool::students.current_enrollment'),
            'items' => [
                __('mtschool::students.col_classroom')     => $current?->classroom?->code,
                __('mtschool::students.enrollment_col')    => $current?->status?->label(),
                __('mtschool::students.enrollment_date')   => $current?->enrollment_date?->format('d/m/Y'),
                __('mtschool::structure.school_year')      => $current?->schoolYear?->code,
            ],
        ];

        $history = $s->enrollments()->with(['classroom', 'schoolYear'])->orderByDesc('id')->get();
        $sections[] = [
            'tab'       => 'schooling',
            'type'      => 'table',
            'title'     => __('mtschool::students.enrollment_history'),
            'columns'   => [__('mtschool::structure.school_year'), __('mtschool::students.col_classroom'), __('mtschool::students.enrollment_col'), __('mtschool::students.enrollment_date')],
            'rows'      => $history->map(fn ($e) => [
                $e->schoolYear?->code,
                $e->classroom?->code,
                $e->status ? ['badge' => $e->status->label(), 'type' => $e->status->badge()] : null,
                $e->enrollment_date?->format('d/m/Y'),
            ])->all(),
            'empty'     => __('mtschool::students.no_enrollments'),
            'emptyIcon' => 'clipboard-document-list',
        ];

        /* ---------- Onglet Tuteurs ---------- */
        $sections[] = [
            'tab'       => 'guardians',
            'type'      => 'table',
            'title'     => __('mtschool::students.guardians'),
            'columns'   => [__('mtschool::students.col_guardian'), __('mtschool::students.relationship'), __('mtschool::students.phone'), __('mtschool::students.email'), __('mtschool::students.primary_contact')],
            'rows'      => $s->guardians->map(fn ($g) => [
                $g->full_name,
                $g->pivot->relationship ? Relationship::tryFrom($g->pivot->relationship)?->label() : null,
                $g->phone,
                $g->email,
                $g->pivot->is_primary_contact
                    ? ['badge' => __('mtschool::common.yes'), 'type' => 'success']
                    : ['badge' => __('mtschool::common.no'), 'type' => 'secondary'],
            ])->all(),
            'empty'     => __('mtschool::students.no_guardians'),
            'emptyIcon' => 'user-group',
        ];

        /* ---------- Onglet Finances ---------- */
        $fees = $current ? $current->schoolFees : collect();
        $sections[] = [
            'tab'   => 'finances',
            'type'  => 'attributes',
            'title' => __('mtschool::finances.payments_title'),
            'items' => [
                __('mtschool::finances.total_due')       => number_format((float) $fees->sum('net_amount'), 0, ',', ' '),
                __('mtschool::finances.total_paid')      => number_format((float) $fees->sum('amount_paid'), 0, ',', ' '),
                __('mtschool::finances.total_remaining') => number_format((float) $fees->sum('remaining_amount'), 0, ',', ' '),
            ],
        ];

        $sections[] = [
            'tab'       => 'finances',
            'type'      => 'table',
            'title'     => __('mtschool::finances.fees_detail'),
            'columns'   => [__('mtschool::finances.col_fee_type2'), __('mtschool::finances.col_due'), __('mtschool::finances.col_paid'), __('mtschool::finances.col_remaining')],
            'rows'      => $fees->map(fn ($f) => [
                $f->feeType?->label,
                number_format((float) $f->net_amount, 0, ',', ' '),
                number_format((float) $f->amount_paid, 0, ',', ' '),
                number_format((float) $f->remaining_amount, 0, ',', ' '),
            ])->all(),
            'empty'     => __('mtschool::finances.no_fees'),
            'emptyIcon' => 'banknotes',
        ];

        $scholarships = $current ? $current->scholarships()->with([])->get() : collect();
        if ($scholarships->isNotEmpty()) {
            $sections[] = [
                'tab'     => 'finances',
                'type'    => 'table',
                'title'   => __('mtschool::finances.scholarships_title'),
                'columns' => [__('mtschool::finances.scholarship_label'), __('mtschool::finances.scholarship_category'), __('mtschool::finances.scholarship_amount')],
                'rows'    => $scholarships->map(fn ($b) => [
                    $b->label,
                    $b->type ? __('mtschool::finances.scholarship_cat_' . $b->type) : null,
                    (float) $b->coverage_rate > 0
                        ? rtrim(rtrim(number_format((float) $b->coverage_rate, 2), '0'), '.') . ' %'
                        : number_format((float) $b->amount, 0, ',', ' '),
                ])->all(),
            ];
        }

        return $sections;
    }
}
