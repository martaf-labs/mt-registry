<?php

namespace Mt\MtSchoolCore\Livewire\Shows;

use Mt\MtFoundation\Enums\CivilitePersonnel;
use Mt\MtFoundation\Enums\SexePersonnel;
use Mt\MtSchoolCore\Enums\ContractStatus;
use Mt\MtSchoolCore\Models\StaffMember;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtUi\Livewire\Shows\GenericProfile;

/**
 * FICHE PERSONNEL (base-profile) — fiche de PERSONNE : avatar rond, onglets, sections.
 * Onglets : Profil (identité + coordonnées) · Contrat (poste/grade/statut). Lecture
 * seule : l'édition passe par le form personnel/enseignant.
 */
class StaffProfile extends GenericProfile
{
    public static function modelClass(): string
    {
        return StaffMember::class;
    }

    public function configuration(): array
    {
        return [
            'model'        => 'staff-member',
            'model_plural' => 'staff-members',
            'mainLabel'    => __('mtschool::students.stat_staff'),
            'title'        => __('mtschool::students.col_staff_member'),
            'features'     => ['canAddImages' => false], // photo unique → éditée dans le formulaire
        ];
    }

    private function initials($s): string
    {
        return mb_strtoupper(mb_substr((string) $s->first_name, 0, 1) . mb_substr((string) $s->last_name, 0, 1));
    }

    public function header($s): array
    {
        $hasAccount = (bool) app(PortalAccountService::class)->accountFor($s);
        $civility   = $s->title ? CivilitePersonnel::tryFrom($s->title)?->label() : null;

        $badges = [];
        if ($s->type) {
            $badges[] = ['label' => $s->type->label(), 'type' => $s->type->badge()];
        }
        $badges[] = $hasAccount
            ? ['label' => __('mtschool::students.account_active'), 'type' => 'success']
            : ['label' => __('mtschool::students.account_none'), 'type' => 'secondary'];
        $badges[] = $s->active
            ? ['label' => __('mtschool::common.active_m'), 'type' => 'success']
            : ['label' => __('mtschool::common.inactive_m'), 'type' => 'secondary'];

        return [
            'image'    => $s->getVariantImage('medium') ?: null,
            'letters'  => $this->initials($s),
            'title'    => $s->full_name,
            'subtitle' => implode(' · ', array_filter([$s->reference, $civility, $s->position ?: ($s->metadata['fonction'] ?? null)])),
            'badges'   => $badges,
        ];
    }

    public function actions($s): array
    {
        return [
            [
                'label'   => __('mtschool::common.edit'),
                'icon'    => 'pencil',
                'route'   => $s->isTeacher() ? mt_get_route('teachers_edit', ['id' => $s->id]) : mt_get_route('staff_index'),
                'variant' => 'primary',
            ],
        ];
    }

    public function tabs(): array
    {
        return [
            'profile'  => __('mtschool::students.tab_profile'),
            'contract' => __('mtschool::students.tab_contract'),
        ];
    }

    public function sections($s): array
    {
        $civility = $s->title ? CivilitePersonnel::tryFrom($s->title)?->label() : null;
        $gender   = $s->gender ? SexePersonnel::tryFrom($s->gender)?->label() : null;

        return [
            /* ---------- Profil ---------- */
            [
                'tab'   => 'profile',
                'type'  => 'attributes',
                'title' => __('mtschool::students.identity'),
                'items' => [
                    __('mtschool::students.last_name')      => $s->last_name,
                    __('mtschool::students.first_name')     => $s->first_name,
                    __('mtschool::students.civility')       => $civility,
                    __('mtschool::students.gender')         => $gender,
                    __('mtschool::students.birth_date')     => $s->birth_date?->format('d/m/Y'),
                    __('mtschool::students.birth_place')    => $s->birth_place,
                    __('mtschool::students.nationality')    => $s->nationality,
                    __('mtschool::students.id_card_number') => $s->id_card_number,
                ],
            ],
            [
                'tab'   => 'profile',
                'type'  => 'attributes',
                'title' => __('mtschool::students.contact_info'),
                'items' => [
                    __('mtschool::students.email')           => $s->email,
                    __('mtschool::students.phone')           => $s->phone,
                    __('mtschool::students.emergency_phone') => $s->emergency_phone,
                    __('mtschool::students.address')         => $s->address,
                ],
            ],

            /* ---------- Contrat ---------- */
            [
                'tab'   => 'contract',
                'type'  => 'attributes',
                'title' => __('mtschool::students.tab_contract'),
                'items' => [
                    __('mtschool::students.staff_type')        => $s->type?->label(),
                    __('mtschool::students.position')          => $s->position ?: ($s->metadata['fonction'] ?? null),
                    __('mtschool::students.grade')             => $s->grade,
                    __('mtschool::students.contract_status')   => $s->contract_status instanceof ContractStatus ? $s->contract_status->label() : $s->contract_status,
                    __('mtschool::students.hire_date')         => $s->hire_date?->format('d/m/Y'),
                    __('mtschool::students.contract_end_date') => $s->contract_end_date?->format('d/m/Y'),
                ],
            ],
        ];
    }
}
