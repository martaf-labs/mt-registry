<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\FeeSchedule;
use Mt\MtSchoolCore\Models\FeeType;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Specialization;
use Mt\MtUi\Livewire\Forms\GenericForm;

/**
 * Ligne de grille tarifaire : type de frais × niveau × filière → montant
 * (année active). Unicité de la combinaison par école + année.
 */
class FeeScheduleForm extends GenericForm
{
    public $fee_type_id       = null;
    public $grade_level_id    = null;
    public $specialization_id = null;
    public $amount            = null;
    public $active            = true;

    public function schema(): array
    {
        return [
            'fee_type_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::finances.col_fee_type2'),
                'options' => FeeType::where('active', true)->orderBy('order')->get()
                    ->mapWithKeys(fn ($ft) => [$ft->id => $ft->label])->toArray(),
                'col'     => 6,
            ],
            'grade_level_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::finances.level'),
                'options' => GradeLevel::orderBy('order')->get()
                    ->mapWithKeys(fn ($g) => [$g->id => $g->label])->toArray(),
                'col'     => 6,
            ],
            'specialization_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::finances.specialization_opt2'),
                'options' => ['' => __('mtschool::finances.all_or_none')]
                    + Specialization::active()->orderBy('code')->pluck('code', 'id')->toArray(),
                'col'     => 6,
            ],
            'amount' => [
                'type'  => 'number',
                'label' => __('mtschool::finances.col_amount'),
                'col'   => 6,
            ],
            'active' => ['type' => 'toggle', 'label' => __('mtschool::common.active_m'), 'col' => 12],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();

        return [
            'fee_type_id' => [
                'required', 'integer',
                Rule::exists('fee_types', 'id')->where('school_id', currentSchoolId()),
                // Une seule ligne par combinaison type × niveau × filière (école + année).
                // ⚠️ whereNull('deleted_at') : MtBaseModel soft-delete TOUS les modèles —
                // sans lui, une ligne supprimée bloque à jamais la re-création.
                Rule::unique('fee_schedules', 'fee_type_id')
                    ->where('school_id', currentSchoolId())
                    ->where('school_year_id', activeSchoolYearId())
                    ->where('grade_level_id', $this->grade_level_id)
                    ->where('specialization_id', $this->specialization_id ?: null)
                    ->whereNull('deleted_at')
                    ->ignore($modelId),
            ],
            'grade_level_id' => [
                'required', 'integer',
                Rule::exists('grade_levels', 'id')->where('school_id', currentSchoolId()),
            ],
            'specialization_id' => 'nullable|integer',
            'amount'            => 'required|numeric|min:1',
            'active'            => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'fee_type_id.required' => __('mtschool::finances.schedule_fee_type_required'),
            'fee_type_id.unique'   => __('mtschool::finances.schedule_line_unique'),
            'grade_level_id.required' => __('mtschool::finances.schedule_level_required'),
            'amount.required'      => __('mtschool::finances.amount_field_required'),
            'amount.min'           => __('mtschool::finances.amount_field_required'),
        ];
    }

    public static function modelClass(): string
    {
        return FeeSchedule::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            $data['specialization_id'] = $data['specialization_id'] ?: null;
            $data['amount'] = (float) $data['amount'];

            if ($model) {
                $model->update($data);
            } else {
                $data['school_year_id'] = activeSchoolYearId();
                $model = FeeSchedule::create($data);
            }

            return $model;
        });
    }
}
