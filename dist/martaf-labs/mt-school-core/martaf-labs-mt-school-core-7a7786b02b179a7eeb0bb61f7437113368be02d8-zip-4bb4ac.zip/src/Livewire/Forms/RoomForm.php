<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\Room;
use Mt\MtUi\Livewire\Forms\GenericForm;

class RoomForm extends GenericForm
{
    public $code        = null;
    public $label       = null;
    public $type        = null;
    public $capacity    = null;
    public $active      = true;
    public $description = null;

    public function schema(): array
    {
        return [
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.room_code_ph'),
                'placeholder' => 'A101',
                'col'         => 6,
            ],
            'type' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.room_type'),
                'options' => [
                    'classroom'  => __('mtschool::structure.room_type_classroom'),
                    'lab'        => __('mtschool::structure.room_type_lab'),
                    'library'    => __('mtschool::structure.room_type_library'),
                    'sports'     => __('mtschool::structure.room_type_sports'),
                    'conference' => __('mtschool::structure.room_type_conference'),
                    'other'      => __('mtschool::structure.room_type_other'),
                ],
                'col'     => 6,
            ],
            'label' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.label_field'),
                'col'   => 6,
            ],
            'capacity' => [
                'type'  => 'number',
                'label' => __('mtschool::structure.capacity_seats'),
                'col'   => 6,
            ],
            'description' => [
                'type'  => 'textarea',
                'label' => __('mtschool::structure.equipment_desc'),
                'col'   => 12,
            ],
            'active' => [
                'type'  => 'checkbox',
                'label' => __('mtschool::structure.room_active'),
                'col'   => 12,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);

        return [
            'code'        => [$isEdit ? 'nullable' : 'required', 'string', 'max:30', Rule::unique('rooms', 'code')->where('school_id', currentSchoolId())->ignore($modelId)], // unicité PAR école
            'label'       => 'nullable',
            'type'        => 'nullable|string|max:50',
            'capacity'    => 'nullable|integer|min:1',
            'active'      => 'boolean',
            'description' => 'nullable|array', // traduisible → coerce en tableau par le base-form ; |string casse (cf. SchoolYearForm)
        ];
    }

    public function messages(): array
    {
        return [
            'code.required' => __('mtschool::structure.room_code_required'),
            'code.unique'   => __('mtschool::structure.room_code_unique'),
        ];
    }

    public static function modelClass(): string
    {
        return Room::class;
    }

    protected function getModelId(): ?int
    {
        if (!isset($this->component)) {
            return null;
        }
        try {
            return $this->component->modelData()?->id ?? null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();
            // Colonnes NOT NULL à défaut DB (ex. type, capacity) : ne pas forcer null.
            $data = array_filter($data, fn ($v) => !is_null($v));

            if ($model) {
                $model->update($data);
                return $model;
            }

            return Room::create($data);
        });
    }
}
