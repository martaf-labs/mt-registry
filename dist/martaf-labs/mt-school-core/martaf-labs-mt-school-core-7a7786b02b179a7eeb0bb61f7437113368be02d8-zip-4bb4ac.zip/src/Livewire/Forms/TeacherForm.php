<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtMedia\Services\MediaService;
use Mt\MtSchoolCore\Enums\StaffType;
use Mt\MtSchoolCore\Models\StaffMember;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtSchoolCore\Models\Teacher;
use Mt\MtUi\Livewire\Forms\GenericForm;

/**
 * Formulaire unifié Enseignant = StaffMember (personne, type=TEACHER) + Teacher
 * (extension pédagogique) + matières qualifiées (teacher_subject).
 *
 * Les noms/spécialité sont traduisibles côté modèles : on les saisit en texte simple
 * et on les stocke en {locale => valeur} (la locale par défaut).
 */
class TeacherForm extends GenericForm
{
    // ── Personne (StaffMember) ──
    public $last_name  = null;
    public $first_name = null;
    public $gender     = null;
    public $title      = null;
    public $email      = null;
    public $phone      = null;
    public $hire_date  = null;

    // ── Pédagogique (Teacher) ──
    public $primary_subject_id = null;
    public $degree         = null;
    public $specialty      = null;
    public $contract_hours = null;
    public $subject_ids    = [];

    public $active = true;
    public $photo  = null; // upload → média vedette du StaffMember (comme élève/tuteur)

    public function schema(): array
    {
        $subjects = Subject::active()->orderBy('code')->get();

        // Aperçu de la photo existante en édition : média vedette du StaffMember.
        $media     = $this->teacherModel()?->staff?->image;
        $photoPath = $media?->path ? \Mt\MtMedia\Models\BaseMedia::encodeUrlPath($media->path) : null;

        return [
            'photo'      => ['type' => 'image', 'label' => __('mtschool::students.staff_photo'), 'col' => 12, 'oldvalue' => $photoPath],
            // Noms traduisibles (portés par StaffMember) → multilingue EXPLICITE (le form pilote Teacher).
            'last_name'  => ['type' => 'text', 'label' => __('mtschool::students.last_name'), 'col' => 6, 'multilingual' => true],
            'first_name' => ['type' => 'text', 'label' => __('mtschool::students.first_name'), 'col' => 6, 'multilingual' => true],

            'title'     => ['type' => 'select', 'label' => __('mtschool::students.title_civility'),
                            'options' => ['M.' => 'M.', 'Mme' => 'Mme', 'Mlle' => 'Mlle', 'Dr' => 'Dr', 'Pr' => 'Pr'], 'col' => 4],
            // Genre = enum mt-foundation (M / F / non précisé) — cf. North Star base-form.
            'gender'    => ['type' => 'select', 'label' => __('mtschool::students.gender'),
                            'options' => \Mt\MtFoundation\Enums\SexePersonnel::options(), 'col' => 4],
            'hire_date' => ['type' => 'date', 'label' => __('mtschool::students.hire_date'), 'col' => 4],

            'email' => ['type' => 'email', 'label' => __('mtschool::students.email'), 'col' => 6],
            'phone' => ['type' => 'text', 'label' => __('mtschool::students.phone'), 'col' => 6],

            'primary_subject_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::students.primary_subject'),
                'options' => $subjects->mapWithKeys(fn ($s) => [$s->id => $s->code . ' · ' . $s->label])->toArray(),
                'col'     => 6,
            ],
            'contract_hours' => ['type' => 'number', 'label' => __('mtschool::students.weekly_hours'), 'col' => 6],

            'degree'    => ['type' => 'text', 'label' => __('mtschool::students.degree'), 'col' => 6],
            'specialty' => ['type' => 'text', 'label' => __('mtschool::students.specialty'), 'col' => 6],

            'subject_ids' => [
                'type'     => 'card-select',
                'label'    => __('mtschool::students.qualified_subjects'),
                'multiple' => true,
                'options'  => $subjects->mapWithKeys(fn ($s) => [$s->id => [
                    'title' => $s->label,
                    'badge' => $s->code,
                    'meta'  => $s->group?->label(),
                ]])->toArray(),
                'col'      => 12,
            ],

            'active' => ['type' => 'toggle', 'label' => __('mtschool::students.teacher_active'), 'col' => 12],
        ];
    }

    public function rules(): array
    {
        $teacher = $this->teacherModel();
        $staffId = $teacher?->staff_id;

        return [
            // Traduisibles → règle 'array' ; prénom FACULTATIF (usage tchadien du nom unique).
            'last_name'  => 'required|array',
            'first_name' => 'nullable|array',
            'gender'     => ['nullable', Rule::in(array_keys(\Mt\MtFoundation\Enums\SexePersonnel::options()))],
            'title'      => 'nullable|string|max:10',
            'hire_date'  => 'nullable|date',
            'email'      => [
                'nullable', 'email', 'max:150',
                Rule::unique('staff', 'email')->where('school_id', currentSchoolId())->ignore($staffId),
            ],
            'phone'              => 'nullable|string|max:40',
            'primary_subject_id' => 'nullable|integer|exists:subjects,id',
            'degree'             => 'nullable|string|max:120',
            'specialty'          => 'nullable|string|max:150',
            'contract_hours'     => 'nullable|numeric|min:0|max:60',
            'subject_ids'        => 'nullable|array',
            'subject_ids.*'      => 'integer|exists:subjects,id',
            'active'             => 'boolean',
            'photo'              => 'nullable|image|max:5120',
        ];
    }

    public function messages(): array
    {
        return [
            'last_name.required' => __('mtschool::students.last_name_required'),
            'email.unique'       => __('mtschool::students.email_unique'),
        ];
    }

    public static function modelClass(): string
    {
        return Teacher::class;
    }

    protected function teacherModel(): ?Teacher
    {
        if (! isset($this->component)) {
            return null;
        }
        try {
            return $this->component->modelData();
        } catch (\Throwable) {
            return null;
        }
    }

    /** Lit un champ traduisible en TABLEAU {locale => valeur} (JSON brut, pas aplati). */
    private function readTranslatable(?Model $m, string $field): array
    {
        if (! $m) {
            return [];
        }
        $raw = $m->getRawOriginal($field);
        $decoded = is_array($raw) ? $raw : (is_string($raw) ? json_decode($raw, true) : null);

        return is_array($decoded) ? $decoded : [];
    }

    public function fillModel(Model $model): void
    {
        /** @var Teacher $model */
        $staff = $model->staff;

        // Noms traduisibles : tableau {fr,en,ar} pour alimenter les onglets de langue.
        $this->last_name  = $this->readTranslatable($staff, 'last_name');
        $this->first_name = $this->readTranslatable($staff, 'first_name');
        $this->gender     = $staff?->gender;
        $this->title      = $staff?->title;
        $this->email      = $staff?->email;
        $this->phone      = $staff?->phone;
        $this->hire_date  = $staff?->hire_date?->format('Y-m-d');

        $this->primary_subject_id = $model->primary_subject_id;
        $this->degree         = $model->degree;
        $this->specialty      = $model->specialty;
        $this->contract_hours = $model->contract_hours;
        $this->subject_ids    = $model->subjects()->pluck('subjects.id')->toArray();

        $this->active = $staff?->active ?? true;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data   = $this->validate();
            $locale = config('mt-school-core.multilingual.default', 'fr');

            $staffData = [
                // Déjà des tableaux {locale => valeur} (champs multilingues) ; prénom facultatif.
                'last_name'  => $data['last_name'],
                'first_name' => $data['first_name'] ?? null,
                'gender'     => $data['gender'] ?? null,
                'title'      => $data['title'] ?? null,
                'email'      => $data['email'] ?? null,
                'phone'      => $data['phone'] ?? null,
                'hire_date'  => $data['hire_date'] ?? null,
                'active'     => $data['active'] ?? true,
                'type'       => StaffType::TEACHER->value,
            ];

            $teacherData = [
                'primary_subject_id' => $data['primary_subject_id'] ?: null,
                'degree'             => $data['degree'] ?? null,
                'specialty'          => filled($data['specialty'] ?? null) ? [$locale => $data['specialty']] : null,
                'contract_hours'     => $data['contract_hours'] !== '' ? $data['contract_hours'] : null,
            ];

            /** @var Teacher $teacher */
            if ($model) {
                $model->staff->update($staffData);
                $model->update($teacherData);
                $teacher = $model;
                $staff   = $model->staff;
            } else {
                $staff   = StaffMember::create($staffData);
                $teacher = Teacher::create(['staff_id' => $staff->id] + $teacherData);
            }

            $teacher->subjects()->sync($data['subject_ids'] ?? []);

            // Photo : média vedette du StaffMember (remplace l'ancienne, gardée en galerie).
            if ($this->photo instanceof \Illuminate\Http\UploadedFile) {
                $staff->images()->where('is_featured', true)->update(['is_featured' => false]);
                app(MediaService::class)->attach($staff, $this->photo, ['type' => 'photo', 'is_featured' => true]);
            }

            return $teacher;
        });
    }
}
