<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Enums\SubjectGroup;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtUi\Livewire\Forms\GenericForm;

class SubjectForm extends GenericForm
{
    public $code         = null;
    public $abbreviation = null;
    public $label        = null;
    public $group        = 'other';
    public $color        = null;
    public $icon         = null;
    public $is_core      = false;
    public $active       = true;
    public $description  = null;

    public function schema(): array
    {
        return [
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.subject_code_ph'),
                'placeholder' => 'MATH',
                'col'         => 6,
            ],
            'abbreviation' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.subject_abbr'),
                'placeholder' => 'Math',
                'col'         => 6,
            ],
            'label' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.full_label_field'),
                'col'   => 12,
            ],
            'group' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.subject_group'),
                'options' => SubjectGroup::options(),
                'col'     => 6,
            ],
            'color' => [
                'type'  => 'color-picker',
                'label' => __('mtschool::common.color'),
                'col'   => 6,
            ],
            'icon' => [
                'type'  => 'icon-picker',
                'label' => __('mtschool::common.icon'),
                'col'   => 6,
            ],
            'is_core' => [
                'type'  => 'toggle',
                'label' => __('mtschool::structure.core_subject'),
                'col'   => 6,
            ],
            'active' => [
                'type'  => 'toggle',
                'label' => __('mtschool::structure.subject_active'),
                'col'   => 6,
            ],
            'description' => [
                'type'  => 'textarea',
                'label' => __('mtschool::common.description'),
                'col'   => 12,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);

        return [
            // Unicité du code PAR ÉCOLE (cf. CLAUDE.md : « uniques par école »).
            'code' => [
                $isEdit ? 'nullable' : 'required', 'string', 'max:30',
                Rule::unique('subjects', 'code')
                    ->where('school_id', currentSchoolId())
                    ->ignore($modelId),
            ],
            'abbreviation' => 'nullable|string|max:15',
            'label'        => 'nullable',
            'group'        => ['nullable', Rule::in(array_keys(SubjectGroup::options()))],
            'color'        => 'nullable|string|max:20',
            'icon'         => 'nullable|string|max:60',
            'is_core'      => 'boolean',
            'active'       => 'boolean',
            // Traduisible (array {fr,en}) → pas de règle 'string'.
            'description'  => 'nullable|array',
        ];
    }

    public function messages(): array
    {
        return [
            'code.required' => __('mtschool::structure.code_required'),
            'code.unique'   => __('mtschool::structure.code_unique'),
        ];
    }

    public static function modelClass(): string
    {
        return Subject::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            // La colonne `color` est NOT NULL : à défaut, on hérite de la couleur du
            // groupe de matières (chaque groupe a sa couleur sémantique).
            if (empty($data['color'])) {
                $data['color'] = (SubjectGroup::tryFrom($data['group'] ?? '') ?? SubjectGroup::OTHER)->color();
            }

            if ($model) {
                $model->update($data);
            } else {
                $model = Subject::create($data);
            }

            return $model;
        });
    }
}
