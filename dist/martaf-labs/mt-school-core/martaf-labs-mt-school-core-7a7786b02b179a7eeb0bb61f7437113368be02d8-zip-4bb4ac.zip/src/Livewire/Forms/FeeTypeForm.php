<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\FeeType;
use Mt\MtUi\Livewire\Forms\GenericForm;

/**
 * Type de frais (catalogue de l'école) : Inscription, Scolarité, Cantine…
 * Les montants par niveau vivent dans la grille tarifaire (FeeSchedule).
 */
class FeeTypeForm extends GenericForm
{
    public $code           = null;
    public $label          = null;
    public $characteristic = 'mandatory';
    public $order          = 0;
    public $active         = true;
    public $description    = null;

    public function schema(): array
    {
        return [
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::academics.fee_type_code_ph'),
                'placeholder' => 'SCOL',
                'col'         => 6,
            ],
            'characteristic' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.characteristic'),
                'options' => ['mandatory' => __('mtschool::academics.mandatory'), 'optional' => __('mtschool::academics.optional')],
                'col'     => 6,
            ],
            'label' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.label_field'),
                'col'   => 8,
            ],
            'order' => [
                'type'  => 'number',
                'label' => __('mtschool::common.order'),
                'col'   => 4,
            ],
            'active'      => ['type' => 'toggle', 'label' => __('mtschool::academics.fee_type_active'), 'col' => 12],
            'description' => ['type' => 'textarea', 'label' => __('mtschool::academics.fee_type_desc_opt'), 'col' => 12],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);

        return [
            'code' => [
                $isEdit ? 'nullable' : 'required', 'string', 'max:30',
                Rule::unique('fee_types', 'code')
                    ->where('school_id', currentSchoolId())
                    ->ignore($modelId),
            ],
            'label'          => 'required|array',
            'characteristic' => ['nullable', Rule::in(['mandatory', 'optional'])],
            'order'          => 'nullable|integer|min:0',
            'active'         => 'boolean',
            'description'    => 'nullable|array',
        ];
    }

    public function messages(): array
    {
        return [
            'code.required' => __('mtschool::academics.fee_type_code_required'),
            'code.unique'   => __('mtschool::academics.fee_type_code_unique'),
            'label.required'=> __('mtschool::academics.fee_type_label_required'),
        ];
    }

    public static function modelClass(): string
    {
        return FeeType::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            if ($model) {
                $model->update($data);
            } else {
                $model = FeeType::create($data);
            }

            return $model;
        });
    }
}
