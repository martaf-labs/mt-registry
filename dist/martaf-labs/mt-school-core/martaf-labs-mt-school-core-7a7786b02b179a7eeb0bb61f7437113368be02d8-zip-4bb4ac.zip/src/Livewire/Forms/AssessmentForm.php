<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Enums\AssessmentStatus;
use Mt\MtSchoolCore\Enums\AssessmentType;
use Mt\MtSchoolCore\Models\Assessment;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtUi\Livewire\Forms\GenericForm;

/**
 * Évaluation (devoir/composition) pour une classe + matière + période.
 * L'enseignant et le coefficient sont HÉRITÉS de l'affectation (CourseAssignment)
 * quand elle existe — la chaîne maquette → affectation → évaluation.
 */
class AssessmentForm extends GenericForm
{
    public $class_id        = null;
    public $subject_id      = null;
    public $period_id       = null;
    public $label           = null;
    public $type            = 'test';
    public $max_score       = 20;
    public $coefficient     = 1;
    public $assessment_date = null;

    public function schema(): array
    {
        return [
            'class_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.class_field'),
                'options' => Classroom::where('active', true)->orderBy('code')->get()
                                ->mapWithKeys(fn ($c) => [$c->id => $c->label])->toArray(),
                'col'     => 6,
            ],
            'subject_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.subject_field'),
                'options' => Subject::active()->orderBy('code')->get()
                                ->mapWithKeys(fn ($s) => [$s->id => $s->code . ' · ' . $s->label])->toArray(),
                'col'     => 6,
            ],
            'period_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.period_field'),
                'options' => Period::orderBy('id')->get()
                                ->mapWithKeys(fn ($p) => [$p->id => $p->label])->toArray(),
                'col'     => 6,
            ],
            'type' => [
                'type'    => 'select',
                'label'   => __('mtschool::common.type'),
                'options' => AssessmentType::options(),
                'col'     => 6,
            ],
            'label' => [
                'type'        => 'text',
                'label'       => __('mtschool::academics.title_field2'),
                'placeholder' => __('mtschool::academics.title_ph2'),
                'col'         => 12,
            ],
            'max_score'       => ['type' => 'number', 'label' => __('mtschool::academics.max_score_field'), 'col' => 4],
            'coefficient'     => ['type' => 'number', 'label' => __('mtschool::academics.coefficient_field'), 'col' => 4],
            'assessment_date' => ['type' => 'date', 'label' => __('mtschool::academics.date_field2'), 'col' => 4],
        ];
    }

    public function rules(): array
    {
        return [
            'class_id'        => 'required|integer|exists:classes,id',
            'subject_id'      => 'required|integer|exists:subjects,id',
            'period_id'       => 'required|integer|exists:periods,id',
            'label'           => 'required|array', // traduisible {fr,en}
            'type'            => ['required', Rule::in(array_keys(AssessmentType::options()))],
            'max_score'       => 'required|numeric|min:1|max:100',
            'coefficient'     => 'required|numeric|min:0|max:50',
            'assessment_date' => 'nullable|date',
        ];
    }

    public function messages(): array
    {
        return [
            'class_id.required'   => __('mtschool::academics.class_required'),
            'subject_id.required' => __('mtschool::academics.subject_required'),
            'period_id.required'  => __('mtschool::academics.period_required'),
            'label.required'      => __('mtschool::academics.title_required2'),
        ];
    }

    public static function modelClass(): string
    {
        return Assessment::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            // Enseignant hérité de l'affectation (classe + matière + année active).
            $assignment = CourseAssignment::where('class_id', $data['class_id'])
                ->where('subject_id', $data['subject_id'])
                ->first();

            $payload = [
                'class_id'        => $data['class_id'],
                'subject_id'      => $data['subject_id'],
                'period_id'       => $data['period_id'],
                'teacher_id'      => $assignment?->teacher_id,
                'label'           => $data['label'], // déjà {fr,en} (traduisible)
                'type'            => $data['type'],
                'max_score'       => $data['max_score'],
                'coefficient'     => $data['coefficient'],
                'assessment_date' => $data['assessment_date'] ?: null,
            ];

            if ($model) {
                $model->update($payload);
            } else {
                $payload['code']      = 'EV-' . strtoupper(substr(uniqid(), -6));
                $payload['status']    = AssessmentStatus::SCHEDULED->value;
                $payload['published'] = false;
                $model = Assessment::create($payload);
            }

            return $model;
        });
    }
}
