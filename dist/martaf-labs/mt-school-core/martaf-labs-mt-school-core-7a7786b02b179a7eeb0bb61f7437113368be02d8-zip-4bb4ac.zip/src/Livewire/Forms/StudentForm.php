<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtMedia\Services\MediaService;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtUi\Livewire\Forms\GenericForm;

/**
 * Édition des attributs propres à l'ÉLÈVE (nom, naissance, coordonnées…), distincte de
 * l'assistant d'inscription (qui, lui, crée élève + tuteur + inscription).
 * Champs de nom/lieu traduisibles → règle `array` (jamais `string`).
 */
class StudentForm extends GenericForm
{
    public $last_name   = null;
    public $first_name  = null;
    public $gender      = null;
    public $birth_date  = null;
    public $birth_place = null;
    public $nationality = null;
    public $email       = null;
    public $phone       = null;
    public $address     = null;
    public $active      = true;
    public $photo       = null; // upload → média « photo » vedette (même convention que l'assistant)

    public function schema(): array
    {
        // Aperçu de la photo existante en édition : chemin (encodé) du média vedette.
        $photoPath = null;
        if (is_numeric($this->getModelId())) {
            $media = Student::find($this->getModelId())?->image;
            $photoPath = $media?->path ? \Mt\MtMedia\Models\BaseMedia::encodeUrlPath($media->path) : null;
        }

        return [
            'photo'      => ['type' => 'image', 'label' => __('mtschool::enrollment.student_photo'), 'col' => 12, 'oldvalue' => $photoPath],
            'last_name'  => ['type' => 'text', 'label' => __('mtschool::students.last_name'), 'col' => 6],
            'first_name' => ['type' => 'text', 'label' => __('mtschool::students.first_name'), 'col' => 6],
            // Genre = enum mt-foundation (M / F / non précisé) — cf. North Star base-form.
            'gender'     => [
                'type'    => 'select',
                'label'   => __('mtschool::students.gender'),
                'options' => \Mt\MtFoundation\Enums\SexePersonnel::options(),
                'col'     => 4,
            ],
            'birth_date'  => ['type' => 'date', 'label' => __('mtschool::students.birth_date'), 'col' => 4],
            'active'      => ['type' => 'toggle', 'label' => __('mtschool::common.active'), 'col' => 4],
            'birth_place' => ['type' => 'text', 'label' => __('mtschool::students.birth_place'), 'col' => 6],
            'nationality' => ['type' => 'text', 'label' => __('mtschool::students.nationality'), 'col' => 6],
            'email'       => ['type' => 'email', 'label' => __('mtschool::students.email'), 'col' => 6],
            'phone'       => ['type' => 'text', 'label' => __('mtschool::students.phone'), 'col' => 6],
            'address'     => ['type' => 'textarea', 'label' => __('mtschool::students.address'), 'col' => 12],
        ];
    }

    public function rules(): array
    {
        return [
            'last_name'   => 'required|array',   // traduisible → array
            'first_name'  => 'required|array',
            'gender'      => ['nullable', Rule::in(array_keys(\Mt\MtFoundation\Enums\SexePersonnel::options()))],
            'birth_date'  => 'nullable|date',
            'birth_place' => 'nullable|array',
            'nationality' => 'nullable|array',
            'email'       => 'nullable|email|max:255',
            'phone'       => 'nullable|string|max:30',
            'address'     => 'nullable|array',
            'active'      => 'boolean',
            'photo'       => 'nullable|image|max:5120',
        ];
    }

    public function messages(): array
    {
        return [
            'last_name.required'  => __('mtschool::students.last_name_required'),
            'first_name.required' => __('mtschool::students.first_name_required'),
        ];
    }

    public static function modelClass(): string
    {
        return Student::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();
            unset($data['photo']); // upload → média, jamais la colonne
            $data = array_filter($data, fn ($v) => ! is_null($v));

            if ($model) {
                $model->update($data);
            } else {
                $data['reference'] = null; // clé présente ⇒ HasReference génère STU-...
                $model = Student::create($data);
            }

            // Nouvelle photo : elle remplace la vedette (l'ancienne reste en galerie).
            if ($this->photo instanceof \Illuminate\Http\UploadedFile) {
                $model->images()->where('is_featured', true)->update(['is_featured' => false]);
                app(MediaService::class)->attach($model, $this->photo, ['type' => 'photo', 'is_featured' => true]);
            }

            return $model;
        });
    }
}
