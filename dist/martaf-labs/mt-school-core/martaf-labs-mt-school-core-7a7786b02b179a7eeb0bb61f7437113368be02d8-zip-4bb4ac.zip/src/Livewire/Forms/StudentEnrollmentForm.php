<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Mt\MtMedia\Services\MediaService;
use Mt\MtUi\Contracts\HasBaseFormContract;
use Mt\MtUi\Livewire\Forms\GenericForm;
use Mt\MtSchoolCore\Enums\EnrollmentStatus;
use Mt\MtSchoolCore\Enums\Relationship;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\Student;

/**
 * Inscription d'un élève — formulaire multi-étapes framework-natif (mt-ui).
 *
 * Une seule entité « Inscription » mais qui orchestre la cascade
 * cycle → niveau → classe, le choix élève (existant/nouveau),
 * le tuteur (existant/nouveau) et les documents (via mt-media),
 * le tout rendu par le blade générique base-form.
 */
class StudentEnrollmentForm extends GenericForm implements HasBaseFormContract
{
    // ── Cascade affectation ───────────────────────────────────────────────────
    public $cycle_id       = null;
    public $grade_level_id = null;
    public $class_id       = null;

    // ── Élève : existant ou nouveau ───────────────────────────────────────────
    public $student_existing_id = null;
    public $student = [
        'last_name'                => ['fr' => '', 'en' => '', 'ar' => ''],
        'first_name'               => ['fr' => '', 'en' => '', 'ar' => ''],
        'gender'                   => null,
        'birth_date'               => null,
        'birth_place'              => null,
        'nationality'              => 'Tchadienne',
        'birth_certificate_number' => null,
        'is_repeating'             => false,
        'is_transferred'           => false,
        'previous_school'          => null,
        'previous_class'           => null,
        'previous_year'            => null,
        'notes'                    => null,
    ];

    // ── Tuteur : existant ou nouveau ──────────────────────────────────────────
    public $guardian_existing_id = null;
    public $guardian = [
        'title'      => 'M.',
        'gender'     => 'M',
        'last_name'  => ['fr' => '', 'en' => '', 'ar' => ''],
        'first_name' => ['fr' => '', 'en' => '', 'ar' => ''],
        'phone'      => null,
        'email'      => null,
        'occupation' => null,
        'address'    => null,
    ];
    public $guardian_relationship  = null;
    public $guardian_is_primary    = true;
    public $guardian_can_pickup    = true;
    public $guardian_portal_access = false;

    // ── Documents (attachés au save via mt-media) ─────────────────────────────
    public $photo             = null;
    public $birth_certificate = null;
    public $report_card       = null;
    public $other_document    = null;

    // ── Inscription ───────────────────────────────────────────────────────────
    public $date             = null;
    public $enrollment_notes = null;

    // =========================================================================
    // SCHEMA
    // =========================================================================

    public function schema(): array
    {
        if ($this->isEdit()) {
            return [
                'date' => ['type' => 'date', 'label' => __('mtschool::enrollment.enrollment_date'), 'col' => 6],
                'enrollment_notes' => ['type' => 'textarea', 'label' => __('mtschool::enrollment.notes'), 'col' => 12],
            ];
        }

        $needsReportCard = ($this->student['is_repeating'] ?? false) || ($this->student['is_transferred'] ?? false);

        // Classe ouverte — déjà filtrée sur l'année active via le global scope de Classroom
        $hasClasses = fn ($query) => $query->where('active', true);

        return array_filter([
            // ── Cascade (uniquement ce qui mène à une classe) ─────────────────
            'cycle_id' => [
                'type'    => 'card-select',
                'label'   => __('mtschool::enrollment.cycle'),
                'live'    => true,
                'help'    => __('mtschool::enrollment.cycle_help'),
                'options' => Cycle::where('active', true)
                    ->whereHas('gradeLevels', fn ($q) => $q->where('active', true)->whereHas('classes', $hasClasses))
                    ->orderBy('order')->get()
                    ->mapWithKeys(fn ($c) => [$c->id => [
                        'title' => $this->loc($c),
                        'badge' => $c->code,
                        'icon'  => $c->icon ?: null,
                        'meta'  => __('mtschool::enrollment.level_available', [
                            'n' => GradeLevel::where('cycle_id', $c->id)->where('active', true)
                                ->whereHas('classes', $hasClasses)->count(),
                        ]),
                    ]]),
                'col'     => 12,
            ],
            'grade_level_id' => [
                'type'    => 'card-select',
                'label'   => __('mtschool::enrollment.level'),
                'live'    => true,
                'options' => $this->cycle_id
                    ? GradeLevel::where('cycle_id', $this->cycle_id)->where('active', true)
                        ->whereHas('classes', $hasClasses)
                        ->orderBy('order')->get()
                        ->mapWithKeys(fn ($g) => [$g->id => [
                            'title' => $this->loc($g),
                            'badge' => $g->code,
                            'meta'  => __('mtschool::enrollment.class_count', ['n' => $g->classes()->where('active', true)->count()]),
                        ]])
                    : [],
                'col'     => 12,
            ],
            'class_id' => [
                'type'    => 'card-select',
                'label'   => __('mtschool::enrollment.classroom'),
                'live'    => true,
                'options' => $this->classCardOptions(),
                'col'     => 12,
            ],

            // ── Élève existant ────────────────────────────────────────────────
            'student_existing_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::enrollment.existing_student'),
                'options' => Student::where('active', true)->orderBy('last_name')->get()
                    ->mapWithKeys(fn ($s) => [$s->id => $s->full_name . ' — ' . $s->reference]),
                'col'     => 12,
                'help'    => __('mtschool::enrollment.existing_student_help'),
            ],

            // ── Nouvel élève ──────────────────────────────────────────────────
            'student.last_name'  => ['type' => 'text', 'label' => __('mtschool::enrollment.last_name'), 'multilingual' => true, 'col' => 6],
            'student.first_name' => ['type' => 'text', 'label' => __('mtschool::enrollment.first_names'), 'multilingual' => true, 'col' => 6],
            'student.gender'     => ['type' => 'select', 'label' => __('mtschool::enrollment.sex'), 'options' => ['M' => __('mtschool::enrollment.sex_m'), 'F' => __('mtschool::enrollment.sex_f')], 'col' => 4],
            'student.birth_date' => ['type' => 'date', 'label' => __('mtschool::enrollment.birth_date'), 'col' => 4],
            'student.birth_place'=> ['type' => 'text', 'label' => __('mtschool::enrollment.birth_place'), 'col' => 4],
            'student.nationality'=> ['type' => 'text', 'label' => __('mtschool::enrollment.nationality'), 'col' => 6],
            'student.birth_certificate_number' => ['type' => 'text', 'label' => __('mtschool::enrollment.birth_cert_number'), 'col' => 6],
            'student.is_repeating'   => ['type' => 'checkbox', 'label' => __('mtschool::enrollment.repeating'), 'checkbox_label' => __('mtschool::enrollment.repeating_label'), 'col' => 6],
            'student.is_transferred' => ['type' => 'checkbox', 'label' => __('mtschool::enrollment.transferred'), 'checkbox_label' => __('mtschool::enrollment.transferred_label'), 'col' => 6],
            'student.previous_school'=> ['type' => 'text', 'label' => __('mtschool::enrollment.previous_school'), 'col' => 4],
            'student.previous_class' => ['type' => 'text', 'label' => __('mtschool::enrollment.previous_class'), 'col' => 4],
            'student.previous_year'  => ['type' => 'text', 'label' => __('mtschool::enrollment.previous_year'), 'col' => 4],
            'student.notes'          => ['type' => 'textarea', 'label' => __('mtschool::enrollment.internal_notes'), 'col' => 12],

            // ── Tuteur existant ───────────────────────────────────────────────
            'guardian_existing_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::enrollment.existing_guardian'),
                'options' => Guardian::where('active', true)->orderBy('last_name')->get()
                    ->mapWithKeys(fn ($g) => [$g->id => $g->full_name . ' — ' . $g->phone]),
                'col'     => 8,
                'help'    => __('mtschool::enrollment.existing_guardian_help'),
            ],
            'guardian_relationship' => [
                'type'    => 'select',
                'label'   => __('mtschool::enrollment.relationship'),
                'options' => Relationship::options(),
                'col'     => 4,
            ],

            // ── Nouveau tuteur ────────────────────────────────────────────────
            'guardian.title'      => ['type' => 'select', 'label' => __('mtschool::enrollment.guardian_title'), 'options' => ['M.' => 'M.', 'Mme' => 'Mme', 'Dr.' => 'Dr.', 'Prof.' => 'Prof.'], 'col' => 3],
            'guardian.gender'     => ['type' => 'select', 'label' => __('mtschool::enrollment.sex'), 'options' => ['M' => __('mtschool::enrollment.sex_m'), 'F' => __('mtschool::enrollment.sex_f')], 'col' => 3],
            'guardian.last_name'  => ['type' => 'text', 'label' => __('mtschool::enrollment.last_name'), 'multilingual' => true, 'col' => 6],
            'guardian.first_name' => ['type' => 'text', 'label' => __('mtschool::enrollment.first_names'), 'multilingual' => true, 'col' => 6],
            'guardian.phone'      => ['type' => 'tel', 'label' => __('mtschool::enrollment.phone'), 'col' => 6],
            'guardian.email'      => ['type' => 'email', 'label' => __('mtschool::enrollment.email'), 'col' => 6],
            'guardian.occupation' => ['type' => 'text', 'label' => __('mtschool::enrollment.occupation'), 'col' => 6],
            'guardian.address'    => ['type' => 'text', 'label' => __('mtschool::enrollment.address'), 'col' => 12],
            'guardian_is_primary'    => ['type' => 'checkbox', 'label' => __('mtschool::enrollment.primary_contact'), 'checkbox_label' => __('mtschool::enrollment.primary_contact'), 'col' => 4],
            'guardian_can_pickup'    => ['type' => 'checkbox', 'label' => __('mtschool::enrollment.pickup'), 'checkbox_label' => __('mtschool::enrollment.pickup_label'), 'col' => 4],
            'guardian_portal_access' => ['type' => 'checkbox', 'label' => __('mtschool::enrollment.portal'), 'checkbox_label' => __('mtschool::enrollment.portal_label'), 'col' => 4],

            // ── Documents ─────────────────────────────────────────────────────
            'photo'             => ['type' => 'image', 'label' => __('mtschool::enrollment.student_photo'), 'col' => 12],
            'birth_certificate' => ['type' => 'document', 'label' => __('mtschool::enrollment.birth_certificate'), 'col' => 12],
            'report_card'       => $needsReportCard ? ['type' => 'document', 'label' => __('mtschool::enrollment.previous_report_card'), 'col' => 12] : null,
            'other_document'    => ['type' => 'document', 'label' => __('mtschool::enrollment.other_document_opt'), 'col' => 12],

            // ── Inscription ───────────────────────────────────────────────────
            'date'             => ['type' => 'date', 'label' => __('mtschool::enrollment.enrollment_date'), 'col' => 6],
            'enrollment_notes' => ['type' => 'textarea', 'label' => __('mtschool::enrollment.notes'), 'col' => 12],
        ]);
    }

    // =========================================================================
    // RULES (par étape réelle)
    // =========================================================================

    public function rules(): array
    {
        if ($this->isEdit()) {
            return [
                'date'             => 'required|date',
                'enrollment_notes' => 'nullable|string',
            ];
        }

        $rel = 'required|string|in:' . implode(',', array_keys(Relationship::options()));

        return [
            1 => ['cycle_id'       => 'required|integer|exists:cycles,id'],
            2 => ['grade_level_id' => 'required|integer|exists:grade_levels,id'],
            3 => ['class_id'       => 'required|integer|exists:classes,id'],
            4 => ['student_existing_id' => 'nullable|integer|exists:students,id'],
            5 => [
                'student.last_name.fr'   => 'required|string|max:100',
                'student.last_name.*'    => 'nullable|string|max:100',
                'student.first_name.fr'  => 'required|string|max:100',
                'student.first_name.*'   => 'nullable|string|max:100',
                'student.gender'      => 'required|in:M,F',
                'student.birth_date'  => 'required|date|before:today|after:' . now()->subYears(30)->format('Y-m-d'),
                'student.birth_place' => 'required|string|max:100',
                'student.nationality' => 'required|string|max:80',
                'student.birth_certificate_number' => 'nullable|string|max:60',
                'student.previous_school' => 'nullable|string|max:150',
                'student.previous_class'  => 'nullable|string|max:50',
                'student.previous_year'   => 'nullable|string|max:20',
                'student.notes'           => 'nullable|string',
            ],
            6 => [
                'guardian_existing_id'  => 'nullable|integer|exists:guardians,id',
                'guardian_relationship' => $rel,
            ],
            7 => [
                'guardian.last_name.fr'  => 'required|string|max:100',
                'guardian.last_name.*'   => 'nullable|string|max:100',
                'guardian.first_name.fr' => 'required|string|max:100',
                'guardian.first_name.*'  => 'nullable|string|max:100',
                'guardian.phone'        => 'required|string|max:30',
                'guardian.email'        => 'nullable|email|max:150',
                'guardian.occupation'   => 'nullable|string|max:100',
                'guardian.address'      => 'nullable|string|max:200',
                'guardian_relationship' => $rel,
            ],
            8 => [
                'photo'             => 'nullable|image|max:5120',
                'birth_certificate' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
                'report_card'       => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
                'other_document'    => 'nullable|file|mimes:pdf,doc,docx,jpg,jpeg,png|max:5120',
            ],
            9 => ['date' => 'required|date'],
        ];
    }

    public function messages(): array
    {
        if ($this->isEdit()) return [];

        return [
            1 => ['cycle_id.required'       => __('mtschool::enrollment.select_cycle')],
            2 => ['grade_level_id.required' => __('mtschool::enrollment.select_level')],
            3 => ['class_id.required'       => __('mtschool::enrollment.select_class')],
            5 => [
                'student.last_name.fr.required'   => __('mtschool::enrollment.last_name_required'),
                'student.first_name.fr.required'  => __('mtschool::enrollment.first_name_required'),
                'student.gender.required'      => __('mtschool::enrollment.sex_required'),
                'student.birth_date.required'  => __('mtschool::enrollment.birth_date_required'),
                'student.birth_date.before'    => __('mtschool::enrollment.birth_date_before'),
                'student.birth_date.after'     => __('mtschool::enrollment.birth_date_after'),
                'student.birth_place.required' => __('mtschool::enrollment.birth_place_required'),
                'student.nationality.required' => __('mtschool::enrollment.nationality_required'),
            ],
            6 => ['guardian_relationship.required' => __('mtschool::enrollment.relationship_required')],
            7 => [
                'guardian.last_name.fr.required'  => __('mtschool::enrollment.guardian_last_name_required'),
                'guardian.first_name.fr.required' => __('mtschool::enrollment.guardian_first_name_required'),
                'guardian.phone.required'      => __('mtschool::enrollment.guardian_phone_required'),
                'guardian_relationship.required' => __('mtschool::enrollment.relationship_required'),
            ],
        ];
    }

    public function fieldActions(): array
    {
        return [];
    }

    public function getCriticalFields(): array
    {
        return [
            'cycle_id', 'grade_level_id',
            'student_existing_id', 'guardian_existing_id',
            'student.is_repeating', 'student.is_transferred',
        ];
    }

    public static function modelClass(): string
    {
        return Enrollment::class;
    }

    // =========================================================================
    // SAVE
    // =========================================================================

    public function save(?Model $model = null): Model
    {
        // Édition : on ne touche qu'aux infos d'inscription
        if ($model) {
            $model->update(array_filter([
                'enrollment_date' => $this->date,
                'notes'           => $this->enrollment_notes,
            ], fn ($v) => ! is_null($v)));
            return $model;
        }

        $media = app(MediaService::class);

        return DB::transaction(function () use ($media) {
            // 1. Élève (existant ou nouveau)
            if ($this->student_existing_id) {
                $student = Student::findOrFail($this->student_existing_id);
            } else {
                $student = Student::create([
                    'reference'                => $this->generateRef('STU', Student::class),
                    'last_name'                => $this->trArray($this->student['last_name'], 'mb_strtoupper'),
                    'first_name'               => $this->trArray($this->student['first_name']),
                    'gender'                   => $this->student['gender'],
                    'birth_date'               => $this->student['birth_date'],
                    'birth_place'              => trim((string) $this->student['birth_place']),
                    'nationality'              => trim((string) $this->student['nationality']),
                    'birth_certificate_number' => $this->student['birth_certificate_number'] ?: null,
                    'is_repeating'             => (bool) $this->student['is_repeating'],
                    'previous_school'          => $this->student['previous_school'] ?: null,
                    'previous_class'           => $this->student['previous_class'] ?: null,
                    'previous_year'            => $this->student['previous_year'] ?: null,
                    'notes'                    => $this->student['notes'] ?: null,
                    'active'                   => true,
                ]);

                // 2. Tuteur (uniquement pour un nouvel élève)
                $guardian = $this->guardian_existing_id
                    ? Guardian::findOrFail($this->guardian_existing_id)
                    : Guardian::create([
                        'reference'  => $this->generateRef('GRD', Guardian::class),
                        'last_name'  => $this->trArray($this->guardian['last_name'], 'mb_strtoupper'),
                        'first_name' => $this->trArray($this->guardian['first_name']),
                        'gender'     => $this->guardian['gender'],
                        'title'      => $this->guardian['title'],
                        'phone'      => trim((string) $this->guardian['phone']),
                        'email'      => $this->guardian['email'] ?: null,
                        'occupation' => $this->guardian['occupation'] ?: null,
                        'address'    => $this->guardian['address'] ?: null,
                        'active'     => true,
                    ]);

                if (! $student->guardians()->where('guardians.id', $guardian->id)->exists()) {
                    $student->guardians()->attach($guardian->id, [
                        'relationship'       => $this->guardian_relationship,
                        'is_primary_contact' => (bool) $this->guardian_is_primary,
                        'can_pickup'         => (bool) $this->guardian_can_pickup,
                        'portal_access'      => (bool) $this->guardian_portal_access,
                    ]);
                }
            }

            // 3. Inscription (school_year_id auto via BelongsToSchoolYear).
            $enrollment = Enrollment::create([
                'reference'       => $this->generateRef('ENR', Enrollment::class),
                'student_id'      => $student->id,
                'class_id'        => $this->class_id,
                'status'          => EnrollmentStatus::PENDING,
                'enrollment_date' => $this->date,
                'is_repeating'    => (bool) ($this->student['is_repeating'] ?? false),
                'is_transferred'  => (bool) ($this->student['is_transferred'] ?? false),
                'notes'           => $this->enrollment_notes ?: null,
            ]);

            // Validation immédiate : l'assistant back-office (admin) fait foi. Sans cela,
            // l'inscription reste PENDING et l'élève est INVISIBLE partout (les écrans aval
            // filtrent ->validated()). Le statut PENDING est réservé aux futures demandes
            // en self-service (portail parent) qui, elles, passeront par un écran de validation.
            $enrollment->validate((int) auth()->id());

            // 4. Documents
            if ($this->photo) {
                $media->attach($student, $this->photo, ['type' => 'photo', 'is_featured' => true]);
            }
            if ($this->birth_certificate) {
                $media->attach($student, $this->birth_certificate, ['type' => 'birth_certificate']);
            }
            if ($this->report_card) {
                $media->attach($enrollment, $this->report_card, ['type' => 'report_card']);
            }
            if ($this->other_document) {
                $media->attach($enrollment, $this->other_document, ['type' => 'other']);
            }

            return $enrollment;
        });
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    protected function isEdit(): bool
    {
        try {
            return isset($this->component) && ! is_null($this->component->modelData());
        } catch (\Throwable) {
            return false;
        }
    }

    protected function classCardOptions()
    {
        if (! $this->grade_level_id) return [];

        // Classroom déjà filtré sur l'année active (global scope)
        return Classroom::where('grade_level_id', $this->grade_level_id)
            ->where('active', true)
            ->orderBy('code')->get()
            ->mapWithKeys(fn ($c) => [$c->id => [
                'title' => $c->code,
                'badge' => $c->isFull() ? __('mtschool::enrollment.full') : null,
                'meta'  => __('mtschool::enrollment.spots_available', ['n' => $c->availableSpots()]),
            ]]);
    }

    protected function loc($model): string
    {
        $label = $model->label ?? null;
        if (is_array($label)) {
            return $label[app()->getLocale()] ?? (reset($label) ?: $model->code);
        }
        return $label ?: $model->code;
    }

    /**
     * Normalise une valeur traduisible (champ multilingue) pour la persistance :
     * trim chaque locale, transforme (ex. mb_strtoupper), retire les locales vides.
     */
    protected function trArray($value, ?callable $fn = null): ?array
    {
        if (! is_array($value)) {
            $value = ($value !== null && $value !== '') ? [app()->getLocale() => $value] : [];
        }

        $out = [];
        foreach ($value as $loc => $v) {
            $v = trim((string) $v);
            if ($v === '') {
                continue;
            }
            $out[$loc] = $fn ? $fn($v) : $v;
        }

        return $out ?: null;
    }

    protected function generateRef(string $prefix, string $modelClass): string
    {
        $year = now()->year;
        $last = $modelClass::where('reference', 'like', "{$prefix}-{$year}-%")->max('reference');
        $num  = $last ? ((int) substr($last, -5)) + 1 : 1;
        return $prefix . '-' . $year . '-' . str_pad((string) $num, 5, '0', STR_PAD_LEFT);
    }
}
