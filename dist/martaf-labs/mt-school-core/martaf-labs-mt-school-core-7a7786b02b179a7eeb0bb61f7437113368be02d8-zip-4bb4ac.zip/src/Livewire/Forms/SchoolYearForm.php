<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Services\PeriodTemplateService;
use Mt\MtUi\Livewire\Forms\GenericForm;

class SchoolYearForm extends GenericForm
{
    public $code        = null;
    public $label       = null;
    public $start_date  = null;
    public $end_date    = null;
    public $is_active   = false;
    public $is_closed   = false;
    public $description = null;

    /** Découpage à générer à la création (trimester|semester|none). Non persisté. */
    public $period_template = 'trimester';

    public function schema(): array
    {
        $schema = [
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.year_code_ph'),
                'placeholder' => '2024-2025',
                'col'         => 6,
            ],
            'label' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.label_field'),
                'col'   => 6,
            ],
            'start_date' => [
                'type'  => 'date',
                'label' => __('mtschool::structure.start_date'),
                'col'   => 6,
            ],
            'end_date' => [
                'type'  => 'date',
                'label' => __('mtschool::structure.end_date'),
                'col'   => 6,
            ],
            'description' => [
                'type'  => 'textarea',
                'label' => __('mtschool::common.description'),
                'col'   => 12,
            ],
            'is_active' => [
                'type'  => 'checkbox',
                'label' => __('mtschool::structure.active_school_year'),
                'col'   => 6,
            ],
        ];

        // À la création uniquement : proposer de générer le découpage en périodes.
        if (! is_numeric($this->getModelId())) {
            $schema['period_template'] = [
                'type'    => 'select',
                'label'   => __('mtschool::structure.period_template'),
                'options' => PeriodTemplateService::options(),
                'hint'    => __('mtschool::structure.period_template_hint'),
                'col'     => 6,
            ];
        }

        return $schema;
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);

        return [
            'code'            => [$isEdit ? 'nullable' : 'required', 'string', 'max:20', Rule::unique('school_years', 'code')->where('school_id', currentSchoolId())->ignore($modelId)], // unicité PAR école
            'label'           => 'nullable',
            'start_date'      => 'required|date',
            'end_date'        => 'required|date|after:start_date',
            'is_active'       => 'boolean',
            'is_closed'       => 'boolean',
            // description est traduisible ($translatables) → valeur = tableau {locale:...}
            // comme label. Une règle |string casserait la validation (cf. simulation).
            'description'     => 'nullable|array',
            'period_template' => 'nullable|string|in:none,trimester,semester',
        ];
    }

    public function messages(): array
    {
        return [
            'code.required'       => __('mtschool::structure.year_code_required'),
            'code.unique'         => __('mtschool::structure.year_code_unique'),
            'start_date.required' => __('mtschool::common.date_start_required'),
            'end_date.required'   => __('mtschool::common.date_end_required'),
            'end_date.after'      => __('mtschool::common.date_end_after'),
        ];
    }

    public static function modelClass(): string
    {
        return SchoolYear::class;
    }

    protected function getModelId(): ?int
    {
        if (!isset($this->component)) {
            return null;
        }
        try {
            return $this->component->modelData()?->id ?? null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            // period_template n'est pas une colonne : on l'extrait avant l'écriture.
            $template = $data['period_template'] ?? 'none';
            unset($data['period_template']);

            if ($model) {
                // Si on active cette année, désactiver les autres
                if ($data['is_active'] ?? false) {
                    SchoolYear::query()->update(['is_active' => false]);
                }
                $model->update($data);
                return $model;
            }

            if ($data['is_active'] ?? false) {
                SchoolYear::query()->update(['is_active' => false]);
            }

            $year = SchoolYear::create($data);

            // Nouvelle année : générer d'emblée le découpage en périodes choisi.
            if (PeriodTemplateService::isTemplate($template)) {
                app(PeriodTemplateService::class)->generate($year, $template);
            }

            return $year;
        });
    }
}
