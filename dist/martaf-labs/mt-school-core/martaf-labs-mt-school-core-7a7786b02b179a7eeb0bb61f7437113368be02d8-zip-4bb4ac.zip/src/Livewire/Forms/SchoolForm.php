<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Mt\MtSchoolCore\Models\School;
use Mt\MtUi\Contracts\HasBaseFormContract;
use Mt\MtUi\Livewire\Forms\GenericForm;

/**
 * Identité de l'établissement (singleton).
 *
 * Le logo / cachet / signature / en-tête sont des médias (mt-media) gérés
 * séparément par le MediaManager sur la page hôte — pas dans ce form.
 */
class SchoolForm extends GenericForm implements HasBaseFormContract
{
    // Champs traduisibles (JSON) — saisie multilingue auto selon les langues de l'école.
    public $name        = ['fr' => '', 'en' => '', 'ar' => ''];
    public $short_name  = ['fr' => '', 'en' => '', 'ar' => ''];
    public $address     = ['fr' => '', 'en' => '', 'ar' => ''];
    public $description  = ['fr' => '', 'en' => '', 'ar' => ''];
    public $footer_text  = ['fr' => '', 'en' => '', 'ar' => ''];

    // Champs simples
    public $email           = null;
    public $phone           = null;
    public $phone_secondary = null;
    public $website         = null;
    public $city            = null;
    public $state           = null;
    public $country         = 'CM';
    public $postal_code     = null;
    public $registration_number = null;
    public $ministry_code   = null;
    public $type            = 'private';
    public $education_level  = 'mixed';
    public $founded_year    = null;
    public $timezone        = 'Africa/Douala';
    public $currency        = 'XAF';
    public $locale          = 'fr';

    // =========================================================================
    // SCHEMA
    // =========================================================================

    public function schema(): array
    {
        return [
            // ── Identité ──
            'name'       => ['type' => 'text', 'label' => __('mtschool::structure.school_full_name'), 'multilingual' => true, 'col' => 8],
            'short_name' => ['type' => 'text', 'label' => __('mtschool::structure.school_short_name'), 'multilingual' => true, 'col' => 4],
            'type' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.school_status'),
                'options' => [
                    'public'        => __('mtschool::structure.school_type_public'),
                    'private'       => __('mtschool::structure.school_type_private'),
                    'confessional'  => __('mtschool::structure.school_type_confessional'),
                    'community'     => __('mtschool::structure.school_type_community'),
                ],
                'col' => 6,
            ],
            'education_level' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.education_level'),
                'options' => [
                    'preschool' => __('mtschool::structure.level_preschool'),
                    'primary'   => __('mtschool::structure.level_primary'),
                    'secondary' => __('mtschool::structure.level_secondary'),
                    'higher'    => __('mtschool::structure.level_higher'),
                    'mixed'     => __('mtschool::structure.level_mixed'),
                ],
                'col' => 6,
            ],

            // ── Contact ──
            'email'           => ['type' => 'email', 'label' => __('mtschool::enrollment.email'), 'col' => 6],
            'website'         => ['type' => 'text',  'label' => __('mtschool::structure.website'), 'placeholder' => 'https://…', 'col' => 6],
            'phone'           => ['type' => 'text',  'label' => __('mtschool::enrollment.phone'), 'col' => 6],
            'phone_secondary' => ['type' => 'text',  'label' => __('mtschool::structure.phone_secondary'), 'col' => 6],

            // ── Adresse ──
            'address'     => ['type' => 'textarea', 'label' => __('mtschool::enrollment.address'), 'multilingual' => true, 'col' => 12],
            'city'        => ['type' => 'text', 'label' => __('mtschool::structure.city'), 'col' => 4],
            'state'       => ['type' => 'text', 'label' => __('mtschool::structure.region'), 'col' => 4],
            'postal_code' => ['type' => 'text', 'label' => __('mtschool::structure.postal_code'), 'col' => 4],
            'country'     => ['type' => 'text', 'label' => __('mtschool::structure.country_iso'), 'placeholder' => 'CM', 'col' => 4],

            // ── Administratif ──
            'registration_number' => ['type' => 'text', 'label' => __('mtschool::structure.registration_number'), 'col' => 4],
            'ministry_code'       => ['type' => 'text', 'label' => __('mtschool::structure.ministry_code'), 'col' => 4],
            'founded_year'        => ['type' => 'number', 'label' => __('mtschool::structure.founded_year'), 'col' => 4],
            'currency'            => ['type' => 'text', 'label' => __('mtschool::structure.currency_iso'), 'placeholder' => 'XAF', 'col' => 4],
            'timezone'            => ['type' => 'text', 'label' => __('mtschool::structure.timezone'), 'col' => 4],
            'locale' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.default_locale'),
                'options' => collect(get_available_locales())->mapWithKeys(fn ($o, $code) => [
                    $code => is_array($o) ? ($o['label'] ?? strtoupper($code)) : $o,
                ])->all(),
                'col'     => 4,
            ],

            // ── Documents ──
            'description' => ['type' => 'textarea', 'label' => __('mtschool::common.description'), 'multilingual' => true, 'col' => 12],
            'footer_text' => ['type' => 'textarea', 'label' => __('mtschool::structure.footer_text'), 'multilingual' => true, 'col' => 12],
        ];
    }

    // =========================================================================
    // RULES
    // =========================================================================

    public function rules(): array
    {
        return [
            'name'        => 'required|array',
            'name.fr'     => 'required|string|max:255',
            'name.*'      => 'nullable|string|max:255',
            'short_name'  => 'nullable|array',
            'short_name.*' => 'nullable|string|max:100',
            'address'     => 'nullable|array',
            'address.*'   => 'nullable|string|max:500',
            'description' => 'nullable|array',
            'description.*' => 'nullable|string|max:2000',
            'footer_text' => 'nullable|array',
            'footer_text.*' => 'nullable|string|max:1000',

            'email'           => 'nullable|email|max:255',
            'website'         => 'nullable|string|max:255',
            'phone'           => 'nullable|string|max:50',
            'phone_secondary' => 'nullable|string|max:50',
            'city'            => 'nullable|string|max:120',
            'state'           => 'nullable|string|max:120',
            'country'         => 'required|string|max:3',
            'postal_code'     => 'nullable|string|max:20',
            'registration_number' => 'nullable|string|max:100',
            'ministry_code'   => 'nullable|string|max:100',
            'type'            => 'required|string|max:30',
            'education_level' => 'required|string|max:30',
            'founded_year'    => 'nullable|integer|min:1800|max:2100',
            'currency'        => 'required|string|max:3',
            'timezone'        => 'required|string|max:60',
            'locale'          => 'required|string|max:5',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required'    => __('mtschool::structure.school_name_required'),
            'name.fr.required' => __('mtschool::structure.school_name_fr_required'),
            'country.required' => __('mtschool::structure.country_required'),
        ];
    }

    public static function modelClass(): string
    {
        return School::class;
    }

    // =========================================================================
    // SAVE
    // =========================================================================

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = [
                'name'        => $this->trArray($this->name),
                'short_name'  => $this->trArray($this->short_name),
                'address'     => $this->trArray($this->address),
                'description' => $this->trArray($this->description),
                'footer_text' => $this->trArray($this->footer_text),
                'email'           => $this->email ?: null,
                'website'         => $this->website ?: null,
                'phone'           => $this->phone ?: null,
                'phone_secondary' => $this->phone_secondary ?: null,
                'city'            => $this->city ?: null,
                'state'           => $this->state ?: null,
                'country'         => strtoupper(trim((string) $this->country)) ?: 'CM',
                'postal_code'     => $this->postal_code ?: null,
                'registration_number' => $this->registration_number ?: null,
                'ministry_code'   => $this->ministry_code ?: null,
                'type'            => $this->type,
                'education_level' => $this->education_level,
                'founded_year'    => $this->founded_year ?: null,
                'currency'        => strtoupper(trim((string) $this->currency)) ?: 'XAF',
                'timezone'        => $this->timezone ?: 'Africa/Douala',
                'locale'          => $this->locale ?: 'fr',
            ];

            if ($model) {
                $model->update($data);
                return $model;
            }

            // Création du singleton : actif par défaut.
            $data['active'] = true;

            return School::create($data);
        });
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /** Normalise un champ traduisible : trim par locale, vide → null. */
    protected function trArray($value): ?array
    {
        if (! is_array($value)) {
            $value = ($value !== null && $value !== '') ? [app()->getLocale() => $value] : [];
        }
        $out = [];
        foreach ($value as $loc => $v) {
            $v = trim((string) $v);
            if ($v === '') {
                continue;
            }
            $out[$loc] = $v;
        }
        return $out ?: null;
    }
}
