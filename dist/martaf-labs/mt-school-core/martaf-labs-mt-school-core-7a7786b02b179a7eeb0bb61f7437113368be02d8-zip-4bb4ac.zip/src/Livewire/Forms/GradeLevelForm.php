<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtUi\Livewire\Forms\GenericForm;

class GradeLevelForm extends GenericForm
{
    public $cycle_id     = null;
    public $code         = null;
    public $label        = null;
    public $abbreviation = null;
    public $order        = 1;
    public $active       = true;
    public $description  = null;

    public function schema(): array
    {
        return [
            'cycle_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.cycle_select'),
                'options' => Cycle::active()->orderBy('order')->pluck('code', 'id'),
                'col'     => 6,
            ],
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.level_code_ph'),
                'placeholder' => 'CE1',
                'col'         => 6,
            ],
            'abbreviation' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.abbreviation'),
                'placeholder' => 'CE1',
                'col'         => 6,
            ],
            'label' => [
                'type'         => 'text',
                'label'        => __('mtschool::structure.full_label_field'),
                'multilingual' => true,
                'col'          => 6,
            ],
            'order' => [
                'type'  => 'number',
                'label' => __('mtschool::common.order'),
                'col'   => 6,
            ],
            'active' => [
                'type'  => 'checkbox',
                'label' => __('mtschool::structure.level_active'),
                'col'   => 6,
            ],
            'description' => [
                'type'  => 'textarea',
                'label' => __('mtschool::common.description'),
                'col'   => 12,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);

        return [
            'cycle_id'    => 'required|exists:cycles,id',
            'code'        => [$isEdit ? 'nullable' : 'required', 'string', 'max:30', Rule::unique('grade_levels', 'code')->where('school_id', currentSchoolId())->ignore($modelId)], // unicité PAR école (était absente → erreur SQL brute sur doublon)
            'label'       => 'nullable',
            'abbreviation' => 'nullable|string|max:20',
            'order'       => 'required|integer|min:1',
            'active'      => 'boolean',
            'description' => 'nullable|array', // traduisible → coerce en tableau par le base-form ; |string casse (cf. SchoolYearForm)
        ];
    }

    public function messages(): array
    {
        return [
            'cycle_id.required' => __('mtschool::structure.cycle_required'),
            'code.required'     => __('mtschool::structure.level_code_required'),
        ];
    }

    public static function modelClass(): string
    {
        return GradeLevel::class;
    }

    protected function getModelId(): ?int
    {
        if (!isset($this->component)) {
            return null;
        }
        try {
            return $this->component->modelData()?->id ?? null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();
            // Colonnes NOT NULL à défaut DB : ne pas forcer null.
            $data = array_filter($data, fn ($v) => !is_null($v));

            if ($model) {
                $model->update($data);
                return $model;
            }

            return GradeLevel::create($data);
        });
    }
}
