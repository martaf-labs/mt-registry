<?php

namespace Mt\MtSchoolCore\Livewire\Concerns;

use Illuminate\Database\Eloquent\Model;
use Mt\MtSchoolCore\Models\CustomField;
use Mt\MtSchoolCore\Models\CustomFieldGroup;

/**
 * À poser sur un FormComponent (extends mt-ui BaseForm) dont le modèle porte
 * le trait HasCustomFields. Implémente les points d'extension génériques de BaseForm
 * (extraSections / hydrateExtra / persistExtra) à partir du système EAV par école.
 *
 * Sans définition de champ pour l'entité → aucune section affichée (no-op).
 * Si le modèle du formulaire n'est pas une entité EAV (ex. assistant d'inscription
 * dont le modèle est Enrollment) → `entityType` null → sections vides (inoffensif).
 */
trait InjectsCustomFields
{
    /** Clé logique de l'entité EAV pour le modèle de CE formulaire, ou null. */
    protected function customFieldEntityType(): ?string
    {
        $map = config('mt-school-core.custom_fields.entities', []);
        foreach ($map as $key => $def) {
            if (($def['model'] ?? null) === ($this->modelClass ?? null)) {
                return $key;
            }
        }
        return null;
    }

    /** Sections de champs perso (groupées) pour l'affichage dans le formulaire. */
    public function extraSections(): array
    {
        $type = $this->customFieldEntityType();
        if (! $type) {
            return [];
        }

        $fields = CustomField::forEntity($type)->active()->orderBy('position')->get();
        if ($fields->isEmpty()) {
            return [];
        }

        // Map des groupes (pour les titres de section).
        $groups = CustomFieldGroup::forEntity($type)->get()->keyBy('id');

        // Regroupe : group_id (ou 0 = sans groupe).
        $byGroup = $fields->groupBy(fn (CustomField $f) => $f->group_id ?? 0);

        $sections = [];
        foreach ($byGroup as $groupId => $groupFields) {
            $title = $groupId && $groups->has($groupId)
                ? $groups->get($groupId)->name
                : 'Champs personnalisés';

            $sections[] = [
                'title'  => $title,
                'fields' => $groupFields->map(fn (CustomField $f) => $this->mapField($f))->all(),
            ];
        }

        return $sections;
    }

    /** Transforme un CustomField en schéma de champ pour le partial extra-sections. */
    protected function mapField(CustomField $field): array
    {
        $schema = $field->toFormField();
        // Le partial lie sur `extraData.<clé>`.
        $schema['name'] = 'extraData.' . $field->key;
        return $schema;
    }

    /** Hydrate `extraData` depuis les valeurs existantes (édition). */
    protected function hydrateExtra(?Model $model): void
    {
        if ($model && method_exists($model, 'customFieldData')) {
            $this->extraData = $model->customFieldData();
        }
    }

    /** Persiste `extraData` après enregistrement. */
    protected function persistExtra(Model $model): void
    {
        if (method_exists($model, 'saveCustomFields')) {
            $model->saveCustomFields($this->extraData);
        }
    }
}
