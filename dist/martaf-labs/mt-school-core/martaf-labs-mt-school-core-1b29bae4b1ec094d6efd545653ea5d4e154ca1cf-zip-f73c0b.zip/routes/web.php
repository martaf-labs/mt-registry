<?php

// Les routes de mt-school-core sont définies dans l'application mt-school (routes/web.php).
// Ce fichier est intentionnellement vide.
