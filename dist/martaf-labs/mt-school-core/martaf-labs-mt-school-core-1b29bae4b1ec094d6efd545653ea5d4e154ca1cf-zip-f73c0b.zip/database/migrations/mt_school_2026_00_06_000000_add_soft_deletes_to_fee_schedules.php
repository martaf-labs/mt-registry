<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * `fee_schedules` utilise MtBaseModel (SoftDeletes) mais la table d'origine n'avait
 * pas de colonne `deleted_at` → toute requête échouait. On la rajoute.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('fee_schedules') && ! Schema::hasColumn('fee_schedules', 'deleted_at')) {
            Schema::table('fee_schedules', function (Blueprint $table) {
                $table->softDeletes();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('fee_schedules', 'deleted_at')) {
            Schema::table('fee_schedules', function (Blueprint $table) {
                $table->dropSoftDeletes();
            });
        }
    }
};
