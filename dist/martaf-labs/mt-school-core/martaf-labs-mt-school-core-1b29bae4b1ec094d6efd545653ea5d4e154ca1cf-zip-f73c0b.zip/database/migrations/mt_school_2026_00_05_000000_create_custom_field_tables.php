<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Champs personnalisés par école (EAV — Entity / Attribute / Value).
 *
 * Permet à CHAQUE école de définir ses propres champs sur les entités métier
 * (élève, parent, personnel…) sans toucher au schéma. Inspiré du pattern
 * GroupeSpecification / ChampSpecification / Specification de sgni/core.
 *
 * TOUT est TENANT (school_id) : une école ne voit que SES définitions et SES valeurs.
 *
 *   - custom_field_groups : regroupements d'affichage (« Informations médicales »…)
 *   - custom_fields       : définition d'un champ (clé, libellé, type, options…)
 *   - custom_field_values : la valeur d'un champ pour une entité donnée
 *
 * `entity_type` = clé LOGIQUE ('student', 'guardian', 'staff'), résolue vers une
 * classe via config('mt-school-core.custom_fields.entities'). On ne stocke jamais
 * le FQCN en base (refactor-safe).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('custom_field_groups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('school_id')->constrained('schools')->cascadeOnDelete();
            $table->string('entity_type');             // clé logique : student|guardian|staff…
            $table->json('name');                      // libellé multilingue du groupe
            $table->json('description')->nullable();
            $table->unsignedInteger('position')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->index(['school_id', 'entity_type']);
        });

        Schema::create('custom_fields', function (Blueprint $table) {
            $table->id();
            $table->foreignId('school_id')->constrained('schools')->cascadeOnDelete();
            $table->foreignId('group_id')->nullable()
                  ->constrained('custom_field_groups')->nullOnDelete();
            $table->string('entity_type');
            $table->string('key');                     // slug stable (ex. 'matricule_interne')
            $table->json('label');                     // libellé multilingue
            $table->json('help')->nullable();          // texte d'aide multilingue
            $table->string('type')->default('text');   // cf. CustomFieldType
            $table->json('options')->nullable();        // [{value,label}] pour select/multiselect
            $table->boolean('required')->default(false);
            $table->json('default')->nullable();        // valeur par défaut éventuelle
            $table->unsignedInteger('position')->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();
            $table->softDeletes();

            // Unicité de la clé PAR école ET par type d'entité.
            $table->unique(['school_id', 'entity_type', 'key']);
            $table->index(['school_id', 'entity_type', 'active']);
        });

        Schema::create('custom_field_values', function (Blueprint $table) {
            $table->id();
            $table->foreignId('school_id')->constrained('schools')->cascadeOnDelete();
            $table->foreignId('custom_field_id')->constrained('custom_fields')->cascadeOnDelete();
            $table->string('entity_type');
            $table->unsignedBigInteger('entity_id');
            $table->text('value')->nullable();          // scalaire ou JSON (multiselect)
            $table->timestamps();
            $table->softDeletes();

            // Une seule valeur par (champ, entité).
            $table->unique(['custom_field_id', 'entity_id']);
            $table->index(['school_id', 'entity_type', 'entity_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('custom_field_values');
        Schema::dropIfExists('custom_fields');
        Schema::dropIfExists('custom_field_groups');
    }
};
