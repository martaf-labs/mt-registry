<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * `TimeSlot` étend MtBaseModel (qui applique SoftDeletes) mais la table `time_slots`
 * a été créée sans `softDeletes()` (uniquement `timestamps()` + `deleted_by`).
 * Résultat : TOUTE requête TimeSlot échoue (« Unknown column 'time_slots.deleted_at' »)
 * → la fonctionnalité Emploi du temps (grille admin + vue élève) est entièrement en 500.
 * On ajoute la colonne manquante.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('time_slots') && ! Schema::hasColumn('time_slots', 'deleted_at')) {
            Schema::table('time_slots', function (Blueprint $table) {
                $table->softDeletes();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('time_slots', 'deleted_at')) {
            Schema::table('time_slots', function (Blueprint $table) {
                $table->dropSoftDeletes();
            });
        }
    }
};
