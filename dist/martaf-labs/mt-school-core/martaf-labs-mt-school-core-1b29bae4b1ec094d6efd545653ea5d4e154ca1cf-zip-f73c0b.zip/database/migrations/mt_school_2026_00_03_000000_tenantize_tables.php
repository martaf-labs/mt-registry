<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tenantisation (SaaS base partagée — tenant = école).
 *
 * 1. Ajoute `school_id` (FK schools, indexé) à TOUTES les tables tenant.
 * 2. Re-scope les uniques globaux (code/key/reference/serial_number) en
 *    uniques PAR ÉCOLE — sinon une 2ᵉ école ne pourrait pas réutiliser un code.
 *
 * Exclus :
 *   - `schools`         : racine de tenant (pas de school_id sur soi-même).
 *   - `users`           : déjà doté de school_id (migration _00_02_).
 *   - tables PIVOT pures : isolées via leurs deux parents (déjà tenant-scopés) :
 *     curriculum_subject, grade_level_specialization, teacher_subject,
 *     student_guardian, study_group_enrollment.
 *
 * Voir CLAUDE.md (north-star multi-tenant).
 */
return new class extends Migration
{
    /** Tables tenant recevant `school_id`. */
    private array $tenantTables = [
        'absence_justifications', 'announcement_reads', 'announcements', 'assessments',
        'attendances', 'buildings', 'cafeteria_menus', 'cafeteria_subscriptions',
        'calendar_events', 'class_councils', 'classes', 'conversation_participants',
        'conversations', 'council_participants', 'course_assignments', 'curricula',
        'cycles', 'data_operations', 'disciplinary_sanctions', 'enrollments',
        'equipment_stock', 'fee_schedules', 'fee_types', 'grade_levels', 'grades',
        'guardians', 'holiday_periods', 'homework_submissions', 'homeworks',
        'meal_reservations', 'messages', 'payment_installments', 'payments',
        'period_averages', 'periods', 'report_cards', 'rooms', 'schedule_exceptions',
        'scholarships', 'school_certificates', 'school_fees', 'school_notifications',
        'school_settings', 'school_years', 'specializations', 'staff', 'stock_movements',
        'students', 'study_groups', 'subject_averages', 'subjects', 'teachers',
        'teaching_resources', 'time_slots', 'timetables',
    ];

    /** Uniques globaux à re-scoper par école : table => [colonnes]. */
    private array $rescopeUnique = [
        'school_years'            => ['code'],
        'cycles'                  => ['code'],
        'grade_levels'            => ['code'],
        'specializations'         => ['code'],
        'buildings'               => ['code'],
        'rooms'                   => ['code'],
        'subjects'                => ['code'],
        'fee_types'               => ['code'],
        'school_settings'         => ['key'],
        'staff'                   => ['reference'],
        'students'                => ['reference'],
        'guardians'               => ['reference'],
        'enrollments'             => ['reference'],
        'report_cards'            => ['reference'],
        'school_fees'             => ['reference'],
        'payments'                => ['reference'],
        'scholarships'            => ['reference'],
        'disciplinary_sanctions'  => ['reference'],
        'school_certificates'     => ['reference'],
        'cafeteria_subscriptions' => ['reference'],
        'equipment_stock'         => ['reference', 'serial_number'],
    ];

    public function up(): void
    {
        // 1. Colonne school_id + FK
        foreach ($this->tenantTables as $t) {
            if (! Schema::hasTable($t) || Schema::hasColumn($t, 'school_id')) {
                continue;
            }
            Schema::table($t, function (Blueprint $table) {
                $table->unsignedBigInteger('school_id')->nullable()->after('id')->index();
                $table->foreign('school_id')->references('id')->on('schools')->cascadeOnDelete();
            });
        }

        // 2. Re-scoping des uniques globaux → par école
        foreach ($this->rescopeUnique as $t => $cols) {
            if (! Schema::hasTable($t)) {
                continue;
            }
            Schema::table($t, function (Blueprint $table) use ($cols) {
                foreach ($cols as $col) {
                    $table->dropUnique([$col]);                 // {table}_{col}_unique
                    $table->unique(['school_id', $col]);
                }
            });
        }
    }

    public function down(): void
    {
        foreach ($this->rescopeUnique as $t => $cols) {
            if (! Schema::hasTable($t)) {
                continue;
            }
            Schema::table($t, function (Blueprint $table) use ($cols) {
                foreach ($cols as $col) {
                    $table->dropUnique(['school_id', $col]);
                    $table->unique([$col]);
                }
            });
        }

        foreach ($this->tenantTables as $t) {
            if (! Schema::hasTable($t) || ! Schema::hasColumn($t, 'school_id')) {
                continue;
            }
            Schema::table($t, function (Blueprint $table) {
                $table->dropForeign(['school_id']);
                $table->dropColumn('school_id');
            });
        }
    }
};
