<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Abonnements & modules (SaaS modulable).
 *
 * GLOBAL (référentiel plateforme, PAS de school_id) :
 *   - modules       : registre des modules activables
 *   - plans         : plans tarifaires
 *   - plan_module   : quels modules sont inclus dans quel plan (éditable)
 *
 * TENANT :
 *   - subscriptions : l'abonnement d'une école (school_id), accédé via la relation.
 *
 * Voir CLAUDE.md (§3 Abonnements & modules).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('modules', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();          // 'attendance', 'finance'… (ref globale)
            $table->json('name');                      // libellé multilingue
            $table->json('description')->nullable();
            $table->string('group')->nullable();       // catégorie d'affichage
            $table->boolean('is_core')->default(false); // inclus dans TOUS les plans
            $table->unsignedInteger('order')->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('plans', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();
            $table->json('name');
            $table->json('description')->nullable();
            $table->decimal('price', 12, 2)->default(0);
            $table->string('currency', 3)->default('XAF');
            $table->string('billing_period')->default('yearly'); // monthly|yearly|term
            $table->unsignedInteger('max_students')->nullable();  // null = illimité
            $table->boolean('is_public')->default(true);          // visible sur la page tarifs
            $table->boolean('active')->default(true);
            $table->unsignedInteger('order')->default(0);
            $table->timestamps();
        });

        Schema::create('plan_module', function (Blueprint $table) {
            $table->id();
            $table->foreignId('plan_id')->constrained('plans')->cascadeOnDelete();
            $table->foreignId('module_id')->constrained('modules')->cascadeOnDelete();
            $table->unique(['plan_id', 'module_id']);
        });

        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();
            // Tenant : nullable car l'achat peut précéder la création de l'école.
            $table->foreignId('school_id')->nullable()->constrained('schools')->cascadeOnDelete();
            $table->foreignId('plan_id')->constrained('plans');
            $table->string('status')->default('pending'); // pending|trial|active|expired|cancelled
            $table->date('starts_at')->nullable();
            $table->date('ends_at')->nullable();           // valid_until
            $table->unsignedInteger('max_students')->nullable(); // snapshot du plan, ajustable
            $table->boolean('auto_renew')->default(false);

            // Paiement (factice pour l'instant, derrière PaymentGateway).
            $table->decimal('amount', 12, 2)->default(0);
            $table->string('currency', 3)->default('XAF');
            $table->string('payment_status')->default('unpaid'); // unpaid|paid|refunded
            $table->string('payment_gateway')->nullable();        // 'fake'|'stripe'…
            $table->string('payment_reference')->nullable();
            $table->timestamp('paid_at')->nullable();

            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['school_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('subscriptions');
        Schema::dropIfExists('plan_module');
        Schema::dropIfExists('plans');
        Schema::dropIfExists('modules');
    }
};
