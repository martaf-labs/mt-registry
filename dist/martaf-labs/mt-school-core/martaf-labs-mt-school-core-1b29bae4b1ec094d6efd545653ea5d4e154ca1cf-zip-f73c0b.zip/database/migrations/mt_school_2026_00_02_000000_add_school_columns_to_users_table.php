<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Adds school-specific columns to the users table.
 *
 * school_id     — tenant identifier (which school the user belongs to)
 * school_role   — role within the school (principal, teacher, student, etc.)
 * is_active     — can the user log in?
 * avatar        — profile picture path (storage-relative)
 * phone         — contact phone number
 * locale        — preferred UI language (fr / en / ar)
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'school_id')) {
                $table->unsignedBigInteger('school_id')->nullable()->after('id');
                $table->index('school_id');
            }

            if (!Schema::hasColumn('users', 'school_role')) {
                $table->string('school_role')->nullable()->after('school_id');
            }

            if (!Schema::hasColumn('users', 'is_active')) {
                $table->boolean('is_active')->default(true)->after('school_role');
            }

            if (!Schema::hasColumn('users', 'avatar')) {
                $table->string('avatar')->nullable()->after('is_active');
            }

            if (!Schema::hasColumn('users', 'phone')) {
                $table->string('phone', 30)->nullable()->after('avatar');
            }

            if (!Schema::hasColumn('users', 'locale')) {
                $table->string('locale', 5)->nullable()->default('fr')->after('phone');
            }
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['school_id', 'school_role', 'is_active', 'avatar', 'phone', 'locale']);
        });
    }
};
