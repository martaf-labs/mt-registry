<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Consolidated migration — mt-school (all tables, strict FK dependency order)
 *
 * Creation order:
 *   01. school_years           (root anchor)
 *   02. periods                (→ school_years, self-ref)
 *   03. cycles
 *   04. grade_levels           (→ cycles)
 *   05. specializations
 *   06. grade_level_specialization  (→ grade_levels, specializations)
 *   07. buildings
 *   08. rooms                  (→ buildings)
 *   09. classes                (→ school_years, grade_levels, specializations, rooms)
 *   10. subjects
 *   11. curricula              (→ school_years, grade_levels, specializations)
 *   12. curriculum_subject     (→ curricula, subjects)
 *   13. staff                  (personnel)
 *   14. teachers               (→ staff, subjects)
 *   15. teacher_subject        (→ teachers, subjects)
 *   16. course_assignments     (→ school_years, teachers, classes, subjects)
 *   17. timetables             (→ school_years, classes)
 *   18. time_slots             (→ timetables, course_assignments, subjects, teachers, rooms)
 *   19. schedule_exceptions    (→ time_slots, rooms)
 *   20. students
 *   21. guardians
 *   22. student_guardian       (→ students, guardians)
 *   23. enrollments            (→ school_years, students, classes, self-ref)
 *   24. assessments            (→ school_years, periods, classes, subjects, teachers)
 *   25. grades                 (→ assessments, enrollments)
 *   26. subject_averages       (→ enrollments, periods, subjects)
 *   27. period_averages        (→ enrollments, periods)
 *   28. report_cards           (→ enrollments, periods, period_averages)
 *   29. attendances            (→ enrollments, time_slots, subjects, teachers)
 *   30. absence_justifications (→ enrollments)
 *   31. circular FK: attendances → absence_justifications
 *   32. fee_types
 *   33. fee_schedules          (→ school_years, fee_types, grade_levels, specializations)
 *   34. school_fees            (→ enrollments, fee_types)
 *   35. payment_installments   (→ school_fees)
 *   36. payments               (→ school_fees, payment_installments)
 *   37. scholarships           (→ enrollments)
 *   38. announcements          (→ school_years)
 *   39. announcement_reads     (→ announcements)
 *   40. conversations          (→ school_years)
 *   41. conversation_participants (→ conversations)
 *   42. messages               (→ conversations, self-ref)
 *   43. calendar_events        (→ school_years, rooms)
 *   44. disciplinary_sanctions (→ enrollments)
 *   45. class_councils         (→ school_years, classes, periods)
 *   46. council_participants   (→ class_councils)
 *   47. teaching_resources     (→ school_years, subjects, classes, grade_levels, teachers)
 *   48. homeworks              (→ school_years, classes, subjects, teachers, periods, assessments)
 *   49. homework_submissions   (→ homeworks, enrollments)
 *   50. school_settings        (→ school_years)
 *   51. school_notifications
 *   52. data_operations        (→ school_years)
 *   53. school_certificates    (→ enrollments)
 *   54. study_groups           (→ classes, subjects)
 *   55. study_group_enrollment (→ study_groups, enrollments)
 *   56. holiday_periods        (→ school_years)
 *   57. cafeteria_menus        (→ school_years)   [optional]
 *   58. cafeteria_subscriptions (→ enrollments)   [optional]
 *   59. meal_reservations      (→ cafeteria_subscriptions, cafeteria_menus) [optional]
 *   60. equipment_stock        (→ rooms)          [optional]
 *   61. stock_movements        (→ equipment_stock, rooms) [optional]
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── 00. SCHOOLS (school profile) ──────────────────────────────────────
        if (!Schema::hasTable('schools')) {
            Schema::create('schools', function (Blueprint $table) {
                $table->id();
                $table->json('name');                          // Full institution name
                $table->json('short_name')->nullable();        // Short name / acronym
                // Logo / seal / signature / header → gérés via mt-media (relation polymorphe)
                $table->string('phone')->nullable();
                $table->string('phone_secondary')->nullable();
                $table->string('email')->nullable();
                $table->string('website')->nullable();
                $table->json('address')->nullable();
                $table->string('city')->nullable();
                $table->string('state')->nullable();             // Region / province
                $table->string('country', 3)->default('CM');    // ISO 3166-1 alpha-3
                $table->string('postal_code')->nullable();
                $table->string('registration_number')->nullable(); // Official registration number
                $table->string('ministry_code')->nullable();     // Ministry-assigned code
                // 'public'|'private'|'confessional'|'community'
                $table->string('type')->default('private');
                // 'preschool'|'primary'|'secondary'|'higher'|'mixed'
                $table->string('education_level')->default('mixed');
                $table->unsignedSmallInteger('founded_year')->nullable();
                $table->string('timezone')->default('Africa/Douala');
                $table->string('currency', 3)->default('XAF');
                $table->string('locale')->default('fr');         // Default UI language
                $table->json('description')->nullable();
                $table->json('footer_text')->nullable();         // Footer text for documents
                $table->boolean('active')->default(true);
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ── 01. SCHOOL YEARS ─────────────────────────────────────────────────
        if (!Schema::hasTable('school_years')) {
            Schema::create('school_years', function (Blueprint $table) {
                $table->id();
                $table->json('label');           // {'fr':'Année 2024-2025','en':'Year 2024-2025','ar':'…'}
                $table->string('code')->unique(); // '2024-2025'
                $table->date('start_date');
                $table->date('end_date');
                $table->boolean('is_active')->default(false)->index();
                $table->boolean('is_closed')->default(false);
                $table->json('description')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 02. PERIODS ────────────────────────────────────────────────────
        if (!Schema::hasTable('periods')) {
            Schema::create('periods', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->cascadeOnDelete();
                $table->foreignId('parent_id')->nullable()->constrained('periods')->nullOnDelete();
                $table->json('label');           // {'fr':'Trimestre 1','en':'Term 1','ar':'…'}
                $table->string('code');           // 'T1','SEQ1','S1'
                // 'term'|'semester'|'sequence'|'annual'|'other'
                $table->string('type')->default('term');
                $table->integer('order')->default(1);
                $table->date('start_date')->nullable();
                $table->date('end_date')->nullable();
                $table->boolean('is_active')->default(false)->index();
                $table->boolean('is_closed')->default(false);
                $table->decimal('weight', 5, 2)->default(100.00);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['school_year_id', 'code']);
            });
        }

        // ── 03. CYCLES ────────────────────────────────────────────────────
        if (!Schema::hasTable('cycles')) {
            Schema::create('cycles', function (Blueprint $table) {
                $table->id();
                $table->json('label');            // {'fr':'Primaire','en':'Primary'}
                $table->string('code')->unique();  // 'PRESCHOOL'|'PRIMARY'|'MIDDLE'|'HIGH'|'HIGHER'
                // 'preschool'|'primary'|'secondary'|'higher'
                $table->string('type')->default('primary');
                $table->integer('order')->default(1);
                $table->string('color')->default('#3b82f6');
                $table->string('icon')->nullable();
                $table->json('description')->nullable();
                $table->boolean('active')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 04. GRADE LEVELS ──────────────────────────────────────────────
        if (!Schema::hasTable('grade_levels')) {
            Schema::create('grade_levels', function (Blueprint $table) {
                $table->id();
                $table->foreignId('cycle_id')->constrained('cycles')->restrictOnDelete();
                $table->json('label');             // {'fr':'Sixième','en':'Year 7','ar':'السادسة'}
                $table->string('code')->unique();   // 'SIX','CM2','TLE','L1-INFO'
                $table->string('abbreviation')->nullable(); // '6e','Tle'
                $table->integer('order')->default(1);
                $table->boolean('active')->default(true);
                $table->json('description')->nullable();
                $table->json('metadata')->nullable(); // {min_age, max_age, retention_threshold}
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 05. SPECIALIZATIONS ────────────────────────────────────────────
        if (!Schema::hasTable('specializations')) {
            Schema::create('specializations', function (Blueprint $table) {
                $table->id();
                $table->json('label');             // {'fr':'Scientifique','en':'Science'}
                $table->string('code')->unique();   // 'SCI'|'LIT'|'TECH'|'IT'|'MGT'
                $table->string('abbreviation')->nullable();
                $table->string('color')->default('#10b981');
                $table->boolean('active')->default(true);
                $table->json('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 06. GRADE_LEVEL_SPECIALIZATION (pivot) ────────────────────────
        if (!Schema::hasTable('grade_level_specialization')) {
            Schema::create('grade_level_specialization', function (Blueprint $table) {
                $table->id();
                $table->foreignId('grade_level_id')->constrained('grade_levels')->cascadeOnDelete();
                $table->foreignId('specialization_id')->constrained('specializations')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['grade_level_id', 'specialization_id'], 'gls_grade_spec_unique');
            });
        }

        // ── 07. BUILDINGS ─────────────────────────────────────────────────
        if (!Schema::hasTable('buildings')) {
            Schema::create('buildings', function (Blueprint $table) {
                $table->id();
                $table->json('label');            // {'fr':'Bâtiment A','en':'Building A'}
                $table->string('code')->unique();  // 'BLD-A'
                $table->json('description')->nullable();
                $table->boolean('active')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 08. ROOMS ─────────────────────────────────────────────────────
        if (!Schema::hasTable('rooms')) {
            Schema::create('rooms', function (Blueprint $table) {
                $table->id();
                $table->foreignId('building_id')->nullable()->constrained('buildings')->nullOnDelete();
                $table->json('label');             // {'fr':'Salle 101','en':'Room 101'}
                $table->string('code')->unique();   // 'R101','LAB-SCI','HALL-A'
                // 'classroom'|'lab'|'auditorium'|'computer_lab'|'gym'|'other'
                $table->string('type')->default('classroom');
                $table->unsignedInteger('capacity')->default(40);
                $table->boolean('active')->default(true);
                $table->json('description')->nullable();
                $table->json('equipment')->nullable(); // ['projector','whiteboard']
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 09. CLASSES ───────────────────────────────────────────────────
        if (!Schema::hasTable('classes')) {
            Schema::create('classes', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('grade_level_id')->constrained('grade_levels')->restrictOnDelete();
                $table->foreignId('specialization_id')->nullable()->constrained('specializations')->nullOnDelete();
                $table->foreignId('room_id')->nullable()->constrained('rooms')->nullOnDelete();
                $table->unsignedBigInteger('homeroom_teacher_id')->nullable()->index();
                $table->json('label');             // {'fr':'Sixième A','en':'Year 7A'}
                $table->string('code')->index();   // '6A','TLE-S1','L1-INFO-A'
                $table->string('abbreviation')->nullable();
                $table->unsignedInteger('max_capacity')->default(60);
                $table->unsignedInteger('current_enrollment')->default(0);
                $table->string('teaching_language')->nullable(); // 'fr'|'en'|'ar'
                $table->boolean('active')->default(true);
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['school_year_id', 'code']);
            });
        }

        // ── 10. SUBJECTS ──────────────────────────────────────────────────
        if (!Schema::hasTable('subjects')) {
            Schema::create('subjects', function (Blueprint $table) {
                $table->id();
                $table->json('label');             // {'fr':'Mathématiques','en':'Mathematics','ar':'الرياضيات'}
                $table->string('code')->unique();   // 'MATH','FR','PHYS','IT'
                $table->string('abbreviation')->nullable();
                // 'literary'|'scientific'|'technical'|'physical'|'artistic'|'other'
                $table->string('group')->default('other');
                $table->string('color')->default('#6366f1');
                $table->string('icon')->nullable();
                $table->boolean('active')->default(true);
                $table->boolean('is_core')->default(false);
                $table->json('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 11. CURRICULA ─────────────────────────────────────────────────
        if (!Schema::hasTable('curricula')) {
            Schema::create('curricula', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('grade_level_id')->constrained('grade_levels')->restrictOnDelete();
                $table->foreignId('specialization_id')->nullable()->constrained('specializations')->nullOnDelete();
                $table->json('label');             // {'fr':'Programme Tle S 2024-2025'}
                $table->string('code');             // 'CURR-TLE-S-2024'
                $table->boolean('active')->default(true);
                $table->json('description')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['school_year_id', 'grade_level_id', 'specialization_id', 'code'], 'curricula_unique');
            });
        }

        // ── 12. CURRICULUM_SUBJECT (pivot) ────────────────────────────────
        if (!Schema::hasTable('curriculum_subject')) {
            Schema::create('curriculum_subject', function (Blueprint $table) {
                $table->id();
                $table->foreignId('curriculum_id')->constrained('curricula')->cascadeOnDelete();
                $table->foreignId('subject_id')->constrained('subjects')->restrictOnDelete();
                $table->decimal('coefficient', 5, 2)->default(1.00);
                $table->decimal('weekly_hours', 5, 2)->nullable();
                $table->unsignedInteger('order')->default(1);
                $table->boolean('is_eliminating')->default(false);
                $table->decimal('eliminating_grade', 5, 2)->nullable();
                $table->boolean('on_report_card')->default(true);
                $table->timestamps();
                $table->unique(['curriculum_id', 'subject_id']);
            });
        }

        // ── 13. STAFF ─────────────────────────────────────────────────────
        if (!Schema::hasTable('staff')) {
            Schema::create('staff', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->json('last_name');
                $table->json('first_name');
                $table->string('gender')->nullable();    // 'M'|'F'|'other'
                $table->string('title')->nullable();     // 'Mr'|'Mrs'|'Dr'|'Prof'
                $table->date('birth_date')->nullable();
                $table->json('birth_place')->nullable();
                $table->json('nationality')->nullable();
                $table->string('id_card_number')->nullable();
                // 'teacher'|'administrative'|'technical'|'management'
                $table->string('type')->default('administrative')->index();
                $table->string('position')->nullable();
                $table->string('grade')->nullable();
                // 'permanent'|'temporary'|'contractual'|'intern'|'volunteer'
                $table->string('contract_status')->nullable();
                $table->date('hire_date')->nullable();
                $table->date('contract_end_date')->nullable();
                $table->string('email')->nullable();
                $table->string('phone')->nullable();
                $table->string('emergency_phone')->nullable();
                $table->json('address')->nullable();
                $table->boolean('has_user_account')->default(false);
                $table->boolean('active')->default(true);
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 14. TEACHERS ──────────────────────────────────────────────────
        if (!Schema::hasTable('teachers')) {
            Schema::create('teachers', function (Blueprint $table) {
                $table->id();
                $table->foreignId('staff_id')->unique()->constrained('staff')->cascadeOnDelete();
                $table->foreignId('primary_subject_id')->nullable()->constrained('subjects')->nullOnDelete();
                $table->string('degree')->nullable();
                $table->json('specialty')->nullable();
                $table->decimal('contract_hours', 5, 2)->nullable();
                $table->timestamps();
            });
        }

        // ── 15. TEACHER_SUBJECT (pivot) ───────────────────────────────────
        if (!Schema::hasTable('teacher_subject')) {
            Schema::create('teacher_subject', function (Blueprint $table) {
                $table->id();
                $table->foreignId('teacher_id')->constrained('teachers')->cascadeOnDelete();
                $table->foreignId('subject_id')->constrained('subjects')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['teacher_id', 'subject_id']);
            });
        }

        // ── 16. COURSE ASSIGNMENTS ────────────────────────────────────────
        if (!Schema::hasTable('course_assignments')) {
            Schema::create('course_assignments', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('teacher_id')->constrained('teachers')->restrictOnDelete();
                $table->foreignId('class_id')->constrained('classes')->cascadeOnDelete();
                $table->foreignId('subject_id')->constrained('subjects')->restrictOnDelete();
                $table->decimal('weekly_hours', 5, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->nullable();
                $table->boolean('active')->default(true);
                $table->date('start_date')->nullable();
                $table->date('end_date')->nullable();
                $table->json('notes')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['school_year_id', 'teacher_id', 'class_id', 'subject_id'], 'course_assign_unique');
            });
        }

        // ── 17. TIMETABLES ────────────────────────────────────────────────
        if (!Schema::hasTable('timetables')) {
            Schema::create('timetables', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('class_id')->constrained('classes')->cascadeOnDelete();
                $table->json('label')->nullable();
                $table->string('code')->nullable();
                // 'draft'|'published'|'archived'
                $table->string('status')->default('draft');
                $table->date('valid_from')->nullable();
                $table->date('valid_until')->nullable();
                $table->boolean('is_active')->default(true);
                $table->json('notes')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 18. TIME SLOTS ────────────────────────────────────────────────
        if (!Schema::hasTable('time_slots')) {
            Schema::create('time_slots', function (Blueprint $table) {
                $table->id();
                $table->foreignId('timetable_id')->constrained('timetables')->cascadeOnDelete();
                $table->foreignId('course_assignment_id')->nullable()->constrained('course_assignments')->nullOnDelete();
                $table->foreignId('subject_id')->constrained('subjects')->restrictOnDelete();
                $table->foreignId('teacher_id')->nullable()->constrained('teachers')->nullOnDelete();
                $table->foreignId('room_id')->nullable()->constrained('rooms')->nullOnDelete();
                $table->unsignedTinyInteger('day_of_week'); // 1=Mon … 7=Sun (ISO 8601)
                $table->time('start_time');
                $table->time('end_time');
                // 'lecture'|'tutorial'|'lab'|'exam'|'study_hall'|'break'|'other'
                $table->string('type')->default('lecture');
                // 'every_week'|'even_weeks'|'odd_weeks'
                $table->string('recurrence')->default('every_week');
                $table->boolean('active')->default(true);
                $table->json('notes')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 19. SCHEDULE EXCEPTIONS ───────────────────────────────────────
        if (!Schema::hasTable('schedule_exceptions')) {
            Schema::create('schedule_exceptions', function (Blueprint $table) {
                $table->id();
                $table->foreignId('time_slot_id')->constrained('time_slots')->cascadeOnDelete();
                $table->date('exception_date');
                // 'cancelled'|'rescheduled'|'replaced'
                $table->string('type')->default('cancelled');
                $table->foreignId('new_time_slot_id')->nullable()->constrained('time_slots')->nullOnDelete();
                $table->date('new_date')->nullable();
                $table->time('new_start_time')->nullable();
                $table->time('new_end_time')->nullable();
                $table->foreignId('new_room_id')->nullable()->constrained('rooms')->nullOnDelete();
                $table->json('reason')->nullable(); // {'fr':'Jour férié','en':'Public holiday'}
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['time_slot_id', 'exception_date']);
            });
        }

        // ── 20. STUDENTS ──────────────────────────────────────────────────
        if (!Schema::hasTable('students')) {
            Schema::create('students', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->json('last_name');
                $table->json('first_name');
                $table->string('gender')->nullable();       // 'M'|'F'
                $table->date('birth_date')->nullable();
                $table->json('birth_place')->nullable();
                $table->json('nationality')->nullable();
                $table->string('birth_certificate_number')->nullable();
                $table->string('photo')->nullable();
                $table->string('email')->nullable();
                $table->string('phone')->nullable();
                $table->json('address')->nullable();
                $table->string('blood_type')->nullable();   // 'A+'|'O-'…
                $table->json('allergies')->nullable();
                $table->json('medical_notes')->nullable();
                $table->json('previous_school')->nullable();
                $table->string('previous_class')->nullable();
                $table->string('previous_year')->nullable();
                $table->string('native_language')->nullable();
                $table->boolean('has_user_account')->default(false);
                $table->boolean('active')->default(true);
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 21. GUARDIANS ─────────────────────────────────────────────────
        if (!Schema::hasTable('guardians')) {
            Schema::create('guardians', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->json('last_name');
                $table->json('first_name');
                $table->string('gender')->nullable();
                $table->string('title')->nullable();
                $table->json('occupation')->nullable();
                $table->json('workplace')->nullable();
                $table->string('email')->nullable();
                $table->string('phone')->nullable()->index();
                $table->string('work_phone')->nullable();
                $table->json('address')->nullable();
                $table->string('id_card_number')->nullable();
                $table->boolean('has_user_account')->default(false);
                $table->boolean('active')->default(true);
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 22. STUDENT_GUARDIAN (pivot) ──────────────────────────────────
        if (!Schema::hasTable('student_guardian')) {
            Schema::create('student_guardian', function (Blueprint $table) {
                $table->id();
                $table->foreignId('student_id')->constrained('students')->cascadeOnDelete();
                $table->foreignId('guardian_id')->constrained('guardians')->cascadeOnDelete();
                // 'father'|'mother'|'guardian'|'grandparent'|'sibling'|'other'
                $table->string('relationship')->default('guardian');
                $table->boolean('is_primary_contact')->default(false);
                $table->boolean('can_pickup')->default(true);
                $table->boolean('portal_access')->default(false);
                $table->timestamps();
                $table->unique(['student_id', 'guardian_id']);
            });
        }

        // ── 23. ENROLLMENTS ───────────────────────────────────────────────
        if (!Schema::hasTable('enrollments')) {
            Schema::create('enrollments', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // ENR-2024-00001
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('student_id')->constrained('students')->restrictOnDelete();
                $table->foreignId('class_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('previous_enrollment_id')
                    ->nullable()->constrained('enrollments')->nullOnDelete();
                // 'pending'|'validated'|'rejected'|'cancelled'|'transferred'
                $table->string('status')->default('pending')->index();
                $table->date('enrollment_date')->nullable();
                $table->date('validation_date')->nullable();
                $table->unsignedBigInteger('validated_by')->nullable();
                // 'admitted'|'retained'|'promoted'|'expelled'|'withdrawn'|'transferred'
                $table->string('result')->nullable()->index();
                $table->decimal('annual_average', 6, 2)->nullable();
                $table->unsignedInteger('annual_rank')->nullable();
                $table->string('source_school')->nullable();
                $table->string('destination_school')->nullable();
                $table->string('exam_seat_number')->nullable();
                $table->boolean('has_scholarship')->default(false);
                $table->boolean('is_repeating')->default(false);
                $table->boolean('is_transferred')->default(false);
                $table->json('rejection_reason')->nullable();
                $table->json('notes')->nullable();
                $table->json('documents')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['school_year_id', 'student_id'], 'enrollment_unique_per_year');
            });
        }

        // ── 24. ASSESSMENTS ───────────────────────────────────────────────
        if (!Schema::hasTable('assessments')) {
            Schema::create('assessments', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('period_id')->constrained('periods')->restrictOnDelete();
                $table->foreignId('class_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('subject_id')->constrained('subjects')->restrictOnDelete();
                $table->foreignId('teacher_id')->nullable()->constrained('teachers')->nullOnDelete();
                $table->json('label');             // {'fr':'Devoir Surveillé N°1','en':'Test 1'}
                $table->string('code')->nullable(); // 'TEST1-MATH-6A-SEQ1'
                // 'test'|'exam'|'quiz'|'lab'|'oral'|'project'|'other'
                $table->string('type')->default('test');
                $table->decimal('max_score', 5, 2)->default(20.00);
                $table->decimal('coefficient', 5, 2)->default(1.00);
                $table->decimal('weight', 5, 2)->default(100.00);
                $table->date('assessment_date')->nullable();
                $table->date('entry_deadline')->nullable();
                // 'scheduled'|'in_progress'|'corrected'|'entered'|'validated'
                $table->string('status')->default('scheduled')->index();
                $table->boolean('published')->default(false);
                $table->text('instructions')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 25. GRADES ────────────────────────────────────────────────────
        if (!Schema::hasTable('grades')) {
            Schema::create('grades', function (Blueprint $table) {
                $table->id();
                $table->foreignId('assessment_id')->constrained('assessments')->cascadeOnDelete();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->decimal('score', 6, 2)->nullable();
                $table->decimal('bonus', 5, 2)->default(0);
                $table->decimal('penalty', 5, 2)->default(0);
                $table->decimal('final_score', 6, 2)->nullable(); // score + bonus - penalty
                $table->boolean('is_absent')->default(false);
                $table->boolean('justified_absence')->default(false);
                $table->boolean('is_missing')->default(false);
                $table->json('appreciation')->nullable();
                $table->unsignedInteger('rank')->nullable();
                $table->boolean('is_validated')->default(false);
                $table->unsignedBigInteger('validated_by')->nullable();
                $table->timestamp('validated_at')->nullable();
                $table->json('notes')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['assessment_id', 'enrollment_id']);
            });
        }

        // ── 26. SUBJECT AVERAGES ──────────────────────────────────────────
        if (!Schema::hasTable('subject_averages')) {
            Schema::create('subject_averages', function (Blueprint $table) {
                $table->id();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->foreignId('period_id')->constrained('periods')->restrictOnDelete();
                $table->foreignId('subject_id')->constrained('subjects')->restrictOnDelete();
                $table->decimal('average', 6, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->default(1.00);
                $table->decimal('weighted_average', 8, 2)->nullable();
                $table->unsignedInteger('rank')->nullable();
                $table->decimal('class_average', 6, 2)->nullable();
                $table->decimal('class_max_score', 6, 2)->nullable();
                $table->decimal('class_min_score', 6, 2)->nullable();
                $table->json('appreciation')->nullable();
                $table->boolean('is_eliminating')->default(false);
                $table->boolean('is_manual')->default(false);
                $table->boolean('is_validated')->default(false);
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['enrollment_id', 'period_id', 'subject_id'], 'subj_avg_unique');
            });
        }

        // ── 27. PERIOD AVERAGES ───────────────────────────────────────────
        if (!Schema::hasTable('period_averages')) {
            Schema::create('period_averages', function (Blueprint $table) {
                $table->id();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->foreignId('period_id')->constrained('periods')->restrictOnDelete();
                $table->decimal('overall_average', 6, 2)->nullable();
                $table->decimal('total_points', 8, 2)->nullable();
                $table->decimal('total_coefficients', 8, 2)->nullable();
                $table->unsignedInteger('rank')->nullable();
                $table->unsignedInteger('class_size')->nullable();
                $table->decimal('class_average', 6, 2)->nullable();
                $table->decimal('class_max_average', 6, 2)->nullable();
                $table->decimal('class_min_average', 6, 2)->nullable();
                // 'Excellent'|'Very Good'|'Good'|'Satisfactory'|'Pass'|'Failing'
                $table->string('mention')->nullable();
                $table->json('overall_assessment')->nullable(); // multilingual
                // 'pass'|'conditional_pass'|'retention'|'orientation'
                $table->string('council_decision')->nullable();
                $table->json('council_notes')->nullable();
                $table->unsignedInteger('justified_absences')->default(0);
                $table->unsignedInteger('unjustified_absences')->default(0);
                $table->unsignedInteger('tardiness_count')->default(0);
                $table->boolean('is_validated')->default(false);
                $table->unsignedBigInteger('validated_by')->nullable();
                $table->timestamp('validated_at')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['enrollment_id', 'period_id'], 'period_avg_unique');
            });
        }

        // ── 28. REPORT CARDS ──────────────────────────────────────────────
        if (!Schema::hasTable('report_cards')) {
            Schema::create('report_cards', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // RC-2024-001-SEQ1
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->foreignId('period_id')->constrained('periods')->restrictOnDelete();
                $table->foreignId('period_average_id')->nullable()->constrained('period_averages')->nullOnDelete();
                // 'draft'|'generated'|'validated'|'published'|'archived'
                $table->string('status')->default('draft')->index();
                $table->string('pdf_file')->nullable();
                $table->json('principal_name')->nullable();
                $table->json('form_teacher_name')->nullable();
                $table->string('signature_hash')->nullable();
                $table->timestamp('generated_at')->nullable();
                $table->timestamp('validated_at')->nullable();
                $table->timestamp('published_at')->nullable();
                $table->boolean('visible_on_portal')->default(false);
                // 'standard'|'detailed'|'compact'
                $table->string('layout')->default('standard');
                $table->json('metadata')->nullable();
                $table->json('notes')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['enrollment_id', 'period_id'], 'report_card_unique');
            });
        }

        // ── 29. ATTENDANCES ───────────────────────────────────────────────
        if (!Schema::hasTable('attendances')) {
            Schema::create('attendances', function (Blueprint $table) {
                $table->id();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->foreignId('time_slot_id')->nullable()->constrained('time_slots')->nullOnDelete();
                $table->foreignId('subject_id')->nullable()->constrained('subjects')->nullOnDelete();
                $table->foreignId('teacher_id')->nullable()->constrained('teachers')->nullOnDelete();
                $table->date('date');
                // 'time_slot'|'half_day'|'full_day'
                $table->string('mode')->default('full_day');
                // 'morning'|'afternoon'|'full_day' — null if mode=time_slot
                $table->string('day_period')->nullable();
                // 'present'|'absent'|'late'|'excluded'
                $table->string('status')->default('present')->index();
                $table->unsignedInteger('lateness_minutes')->default(0);
                $table->unsignedBigInteger('justification_id')->nullable(); // FK added after
                $table->boolean('is_justified')->default(false);
                $table->unsignedBigInteger('recorded_by')->nullable();
                $table->json('notes')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->index(['enrollment_id', 'date']);
                $table->index(['date', 'status']);
            });
        }

        // ── 30. ABSENCE JUSTIFICATIONS ────────────────────────────────────
        if (!Schema::hasTable('absence_justifications')) {
            Schema::create('absence_justifications', function (Blueprint $table) {
                $table->id();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->date('start_date');
                $table->date('end_date');
                // 'illness'|'bereavement'|'family_event'|'travel'|'other'
                $table->string('reason')->default('other');
                $table->json('reason_details')->nullable();
                $table->string('document')->nullable();
                // 'pending'|'accepted'|'rejected'
                $table->string('status')->default('pending');
                $table->unsignedBigInteger('processed_by')->nullable();
                $table->timestamp('processed_at')->nullable();
                $table->json('rejection_reason')->nullable();
                // 'guardian'|'student'|'admin'
                $table->string('submitter_type')->nullable();
                $table->unsignedBigInteger('submitter_id')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 31. CIRCULAR FK: attendances → absence_justifications ─────────
        Schema::table('attendances', function (Blueprint $table) {
            $table->foreign('justification_id')
                ->references('id')
                ->on('absence_justifications')
                ->nullOnDelete();
        });

        // ── 32. FEE TYPES ─────────────────────────────────────────────────
        if (!Schema::hasTable('fee_types')) {
            Schema::create('fee_types', function (Blueprint $table) {
                $table->id();
                $table->json('label');             // {'fr':'Frais de scolarité','en':'Tuition fees'}
                $table->string('code')->unique();   // 'TUITION'|'REGISTRATION'|'CAFETERIA'|'TRANSPORT'
                // 'mandatory'|'optional'|'conditional'
                $table->string('characteristic')->default('mandatory');
                $table->boolean('active')->default(true);
                $table->integer('order')->default(1);
                $table->json('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 33. FEE SCHEDULES ─────────────────────────────────────────────
        if (!Schema::hasTable('fee_schedules')) {
            Schema::create('fee_schedules', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('fee_type_id')->constrained('fee_types')->restrictOnDelete();
                $table->foreignId('grade_level_id')->nullable()->constrained('grade_levels')->nullOnDelete();
                $table->foreignId('specialization_id')->nullable()->constrained('specializations')->nullOnDelete();
                $table->decimal('amount', 12, 2);
                $table->string('currency', 3)->default('XAF');
                $table->boolean('active')->default(true);
                $table->json('description')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(
                    ['school_year_id', 'fee_type_id', 'grade_level_id', 'specialization_id'],
                    'fee_schedule_unique'
                );
            });
        }

        // ── 34. SCHOOL FEES ───────────────────────────────────────────────
        if (!Schema::hasTable('school_fees')) {
            Schema::create('school_fees', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // FEE-2024-00001
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->foreignId('fee_type_id')->constrained('fee_types')->restrictOnDelete();
                $table->decimal('gross_amount', 12, 2);
                $table->decimal('discount', 12, 2)->default(0);
                $table->decimal('net_amount', 12, 2);
                $table->decimal('amount_paid', 12, 2)->default(0);
                $table->decimal('remaining_amount', 12, 2);
                $table->string('currency', 3)->default('XAF');
                // 'pending'|'partial'|'paid'|'exempt'|'cancelled'
                $table->string('status')->default('pending')->index();
                $table->boolean('is_exempt')->default(false);
                $table->json('exemption_reason')->nullable();
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['enrollment_id', 'fee_type_id']);
            });
        }

        // ── 35. PAYMENT INSTALLMENTS ──────────────────────────────────────
        if (!Schema::hasTable('payment_installments')) {
            Schema::create('payment_installments', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_fee_id')->constrained('school_fees')->cascadeOnDelete();
                $table->json('label')->nullable(); // {'fr':'1er versement','en':'1st payment'}
                $table->integer('order')->default(1);
                $table->decimal('amount', 12, 2);
                $table->date('due_date');
                // 'pending'|'overdue'|'partial'|'paid'
                $table->string('status')->default('pending')->index();
                $table->decimal('amount_paid', 12, 2)->default(0);
                $table->decimal('remaining_amount', 12, 2);
                $table->timestamps();
            });
        }

        // ── 36. PAYMENTS ──────────────────────────────────────────────────
        if (!Schema::hasTable('payments')) {
            Schema::create('payments', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // PAY-2024-00001
                $table->foreignId('school_fee_id')->constrained('school_fees')->cascadeOnDelete();
                $table->foreignId('installment_id')->nullable()->constrained('payment_installments')->nullOnDelete();
                $table->decimal('amount', 12, 2);
                $table->string('currency', 3)->default('XAF');
                $table->date('payment_date');
                // 'cash'|'bank_transfer'|'check'|'mobile_money'|'card'|'other'
                $table->string('payment_method')->default('cash');
                $table->string('transaction_number')->nullable();
                // 'pending'|'confirmed'|'rejected'|'refunded'
                $table->string('status')->default('confirmed')->index();
                $table->string('receipt_file')->nullable();
                $table->boolean('receipt_sent')->default(false);
                $table->unsignedBigInteger('collected_by')->nullable();
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 37. SCHOLARSHIPS ──────────────────────────────────────────────
        if (!Schema::hasTable('scholarships')) {
            Schema::create('scholarships', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->json('label');             // {'fr':'Bourse d\'excellence','en':'Merit scholarship'}
                // 'merit'|'social'|'government'|'other'
                $table->string('type')->default('other');
                $table->decimal('amount', 12, 2);
                $table->string('currency', 3)->default('XAF');
                // 'full'|'partial'
                $table->string('coverage')->default('partial');
                $table->decimal('coverage_rate', 5, 2)->nullable();
                $table->date('award_date');
                $table->date('end_date')->nullable();
                // 'pending'|'active'|'suspended'|'withdrawn'
                $table->string('status')->default('pending');
                $table->json('organization')->nullable();
                $table->json('conditions')->nullable();
                $table->json('notes')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 38. ANNOUNCEMENTS ─────────────────────────────────────────────
        if (!Schema::hasTable('announcements')) {
            Schema::create('announcements', function (Blueprint $table) {
                $table->id();
                $table->json('title');             // {'fr':'Réunion parents','en':'Parent meeting'}
                $table->json('content');
                $table->unsignedBigInteger('author_id')->index();
                // 'all'|'students'|'parents'|'teachers'|'staff'|'class'|'grade_level'
                $table->string('audience_type')->default('all');
                $table->json('audience_ids')->nullable();
                $table->foreignId('school_year_id')->nullable()->constrained('school_years')->nullOnDelete();
                // 'draft'|'published'|'archived'
                $table->string('status')->default('draft')->index();
                // 'normal'|'important'|'urgent'
                $table->string('importance')->default('normal');
                $table->timestamp('published_at')->nullable();
                $table->timestamp('expires_at')->nullable();
                $table->boolean('email_notification')->default(false);
                $table->boolean('sms_notification')->default(false);
                $table->unsignedInteger('views_count')->default(0);
                $table->json('attachments')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 39. ANNOUNCEMENT READS ────────────────────────────────────────
        if (!Schema::hasTable('announcement_reads')) {
            Schema::create('announcement_reads', function (Blueprint $table) {
                $table->id();
                $table->foreignId('announcement_id')->constrained('announcements')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id')->index();
                $table->timestamp('read_at')->useCurrent();
                $table->unique(['announcement_id', 'user_id']);
            });
        }

        // ── 40. CONVERSATIONS ─────────────────────────────────────────────
        if (!Schema::hasTable('conversations')) {
            Schema::create('conversations', function (Blueprint $table) {
                $table->id();
                $table->json('subject')->nullable();
                // 'private'|'group'
                $table->string('type')->default('private');
                $table->foreignId('school_year_id')->nullable()->constrained('school_years')->nullOnDelete();
                $table->timestamp('last_message_at')->nullable()->index();
                $table->unsignedInteger('messages_count')->default(0);
                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ── 41. CONVERSATION PARTICIPANTS ─────────────────────────────────
        if (!Schema::hasTable('conversation_participants')) {
            Schema::create('conversation_participants', function (Blueprint $table) {
                $table->id();
                $table->foreignId('conversation_id')->constrained('conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id')->index();
                $table->timestamp('last_seen_at')->nullable();
                $table->boolean('is_admin')->default(false);
                $table->boolean('is_muted')->default(false);
                $table->timestamps();
                $table->unique(['conversation_id', 'user_id']);
            });
        }

        // ── 42. MESSAGES ──────────────────────────────────────────────────
        if (!Schema::hasTable('messages')) {
            Schema::create('messages', function (Blueprint $table) {
                $table->id();
                $table->foreignId('conversation_id')->constrained('conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('sender_id')->index();
                $table->foreignId('parent_id')->nullable()->constrained('messages')->nullOnDelete();
                $table->text('content');
                // 'text'|'image'|'file'
                $table->string('content_type')->default('text');
                $table->json('attachments')->nullable();
                // 'sent'|'read'|'deleted'
                $table->string('status')->default('sent');
                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ── 43. CALENDAR EVENTS ───────────────────────────────────────────
        if (!Schema::hasTable('calendar_events')) {
            Schema::create('calendar_events', function (Blueprint $table) {
                $table->id();
                $table->json('title');
                $table->json('description')->nullable();
                // 'class_council'|'exam'|'holiday'|'meeting'|'field_trip'|'public_holiday'|'other'
                $table->string('type')->default('other');
                $table->foreignId('school_year_id')->nullable()->constrained('school_years')->nullOnDelete();
                $table->string('audience_type')->default('all');
                $table->json('audience_ids')->nullable();
                $table->dateTime('starts_at');
                $table->dateTime('ends_at')->nullable();
                $table->boolean('all_day')->default(false);
                $table->boolean('recurring')->default(false);
                $table->json('recurrence_config')->nullable();
                $table->json('location')->nullable();
                $table->foreignId('room_id')->nullable()->constrained('rooms')->nullOnDelete();
                $table->string('color')->default('#3b82f6');
                $table->string('icon')->nullable();
                $table->boolean('published')->default(true);
                $table->boolean('notification_sent')->default(false);
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 44. DISCIPLINARY SANCTIONS ────────────────────────────────────
        if (!Schema::hasTable('disciplinary_sanctions')) {
            Schema::create('disciplinary_sanctions', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                // 'warning'|'reprimand'|'temp_suspension'|'expulsion'|'detention'|'parent_summons'
                $table->string('type')->default('warning');
                $table->json('label')->nullable();
                $table->json('reason');
                $table->date('sanction_date');
                $table->date('end_date')->nullable();
                $table->unsignedBigInteger('issued_by')->nullable();
                // 'active'|'lifted'|'archived'
                $table->string('status')->default('active');
                $table->boolean('parent_notified')->default(false);
                $table->timestamp('parent_notified_at')->nullable();
                $table->json('follow_up')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 45. CLASS COUNCILS ────────────────────────────────────────────
        if (!Schema::hasTable('class_councils')) {
            Schema::create('class_councils', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('class_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('period_id')->constrained('periods')->restrictOnDelete();
                $table->json('title')->nullable();
                $table->dateTime('council_date');
                $table->json('location')->nullable();
                // 'planned'|'held'|'minutes_drafted'|'validated'
                $table->string('status')->default('planned');
                $table->unsignedBigInteger('president_id')->nullable();
                $table->json('minutes_content')->nullable();
                $table->string('minutes_file')->nullable();
                $table->timestamp('validated_at')->nullable();
                $table->unsignedBigInteger('validated_by')->nullable();
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['class_id', 'period_id'], 'class_council_unique');
            });
        }

        // ── 46. COUNCIL PARTICIPANTS ──────────────────────────────────────
        if (!Schema::hasTable('council_participants')) {
            Schema::create('council_participants', function (Blueprint $table) {
                $table->id();
                $table->foreignId('class_council_id')->constrained('class_councils')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id');
                // 'president'|'secretary'|'member'
                $table->string('council_role')->nullable();
                $table->boolean('present')->default(true);
                $table->boolean('has_signed')->default(false);
                $table->timestamps();
                $table->unique(['class_council_id', 'user_id']);
            });
        }

        // ── 47. TEACHING RESOURCES ────────────────────────────────────────
        if (!Schema::hasTable('teaching_resources')) {
            Schema::create('teaching_resources', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->nullable()->constrained('school_years')->nullOnDelete();
                $table->foreignId('subject_id')->nullable()->constrained('subjects')->nullOnDelete();
                $table->foreignId('class_id')->nullable()->constrained('classes')->nullOnDelete();
                $table->foreignId('grade_level_id')->nullable()->constrained('grade_levels')->nullOnDelete();
                $table->foreignId('teacher_id')->nullable()->constrained('teachers')->nullOnDelete();
                $table->json('title');
                $table->json('description')->nullable();
                // 'document'|'video'|'audio'|'link'|'image'|'exercise'|'answer_key'|'other'
                $table->string('type')->default('document');
                $table->string('file')->nullable();
                $table->string('external_url')->nullable();
                $table->string('mime_type')->nullable();
                $table->unsignedBigInteger('file_size')->nullable();
                // 'class'|'grade_level'|'teachers'|'all'
                $table->string('audience')->default('class');
                $table->boolean('published')->default(false);
                $table->unsignedInteger('downloads')->default(0);
                $table->unsignedInteger('views')->default(0);
                $table->json('tags')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 48. HOMEWORKS ─────────────────────────────────────────────────
        if (!Schema::hasTable('homeworks')) {
            Schema::create('homeworks', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->restrictOnDelete();
                $table->foreignId('class_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('subject_id')->constrained('subjects')->restrictOnDelete();
                $table->foreignId('teacher_id')->nullable()->constrained('teachers')->nullOnDelete();
                $table->foreignId('period_id')->nullable()->constrained('periods')->nullOnDelete();
                $table->foreignId('assessment_id')->nullable()->constrained('assessments')->nullOnDelete();
                $table->json('title');
                $table->json('instructions')->nullable();
                $table->date('assigned_date');
                $table->dateTime('submission_deadline');
                $table->boolean('is_graded')->default(false);
                $table->decimal('max_score', 5, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->default(1.00);
                // 'draft'|'published'|'closed'
                $table->string('status')->default('published');
                $table->json('resources')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 49. HOMEWORK SUBMISSIONS ──────────────────────────────────────
        if (!Schema::hasTable('homework_submissions')) {
            Schema::create('homework_submissions', function (Blueprint $table) {
                $table->id();
                $table->foreignId('homework_id')->constrained('homeworks')->cascadeOnDelete();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->string('file')->nullable();
                $table->json('comment')->nullable();
                $table->timestamp('submitted_at')->nullable();
                $table->boolean('is_late')->default(false);
                $table->decimal('score', 6, 2)->nullable();
                $table->json('correction')->nullable();
                $table->string('correction_file')->nullable();
                $table->timestamp('corrected_at')->nullable();
                // 'submitted'|'corrected'|'returned'
                $table->string('status')->default('submitted');
                $table->timestamps();
                $table->unique(['homework_id', 'enrollment_id']);
            });
        }

        // ── 50. SCHOOL SETTINGS ───────────────────────────────────────────
        if (!Schema::hasTable('school_settings')) {
            Schema::create('school_settings', function (Blueprint $table) {
                $table->id();
                $table->string('key')->unique();
                $table->text('value')->nullable();
                // 'general'|'grading'|'report_card'|'enrollment'|'finance'|'communication'
                $table->string('group')->default('general')->index();
                // 'string'|'integer'|'decimal'|'boolean'|'json'|'array'|'date'
                $table->string('value_type')->default('string');
                $table->json('label')->nullable();
                $table->json('description')->nullable();
                $table->boolean('is_editable')->default(true);
                $table->foreignId('school_year_id')->nullable()->constrained('school_years')->nullOnDelete();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 51. SCHOOL NOTIFICATIONS ──────────────────────────────────────
        if (!Schema::hasTable('school_notifications')) {
            Schema::create('school_notifications', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id')->index();
                $table->json('title');
                $table->json('body')->nullable();
                // 'info'|'success'|'warning'|'error'
                $table->string('type')->default('info');
                // 'grade'|'report_card'|'absence'|'payment'|'announcement'|'homework'|'other'
                $table->string('category')->default('other');
                $table->string('notifiable_type')->nullable();
                $table->unsignedBigInteger('notifiable_id')->nullable();
                $table->index(['notifiable_type', 'notifiable_id']);
                $table->string('url')->nullable();
                $table->boolean('is_read')->default(false)->index();
                $table->timestamp('read_at')->nullable();
                $table->timestamps();
            });
        }

        // ── 52. DATA OPERATIONS (imports / exports) ───────────────────────
        if (!Schema::hasTable('data_operations')) {
            Schema::create('data_operations', function (Blueprint $table) {
                $table->id();
                // 'import'|'export'
                $table->string('operation')->default('import');
                // 'students'|'teachers'|'grades'|'report_cards'|'payments'…
                $table->string('entity');
                // 'csv'|'xlsx'|'pdf'|'json'|'zip'
                $table->string('format')->default('csv');
                $table->string('file')->nullable();
                // 'pending'|'processing'|'completed'|'failed'|'partial'
                $table->string('status')->default('pending');
                $table->unsignedInteger('total_rows')->default(0);
                $table->unsignedInteger('rows_ok')->default(0);
                $table->unsignedInteger('rows_error')->default(0);
                $table->unsignedInteger('rows_skipped')->default(0);
                $table->json('error_report')->nullable();
                $table->foreignId('school_year_id')->nullable()->constrained('school_years')->nullOnDelete();
                $table->timestamp('started_at')->nullable();
                $table->timestamp('finished_at')->nullable();
                $table->json('notes')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 53. SCHOOL CERTIFICATES ───────────────────────────────────────
        if (!Schema::hasTable('school_certificates')) {
            Schema::create('school_certificates', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->unique();
                $table->foreignId('enrollment_id')->constrained('enrollments')->restrictOnDelete();
                // 'enrollment_certificate'|'attendance_attestation'|'transcript'
                // 'diploma'|'transfer_attestation'|'enrollment_receipt'|'other'
                $table->string('type')->default('enrollment_certificate')->index();
                $table->json('title');
                $table->string('reason')->nullable();
                $table->json('reason_details')->nullable();
                $table->json('recipient')->nullable();
                $table->string('language')->default('fr');
                $table->string('pdf_file')->nullable();
                $table->string('signature_hash')->nullable();
                $table->string('qr_code')->nullable();
                // 'requested'|'processing'|'issued'|'cancelled'
                $table->string('status')->default('requested')->index();
                $table->unsignedBigInteger('requested_by')->nullable();
                $table->timestamp('requested_at')->nullable();
                $table->unsignedBigInteger('issued_by')->nullable();
                $table->timestamp('issued_at')->nullable();
                $table->unsignedSmallInteger('copies_count')->default(1);
                $table->date('valid_until')->nullable();
                $table->json('notes')->nullable();
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 54. STUDY GROUPS (TD/TP sub-groups) ───────────────────────────
        if (!Schema::hasTable('study_groups')) {
            Schema::create('study_groups', function (Blueprint $table) {
                $table->id();
                $table->foreignId('class_id')->constrained('classes')->cascadeOnDelete();
                $table->foreignId('subject_id')->nullable()->constrained('subjects')->nullOnDelete();
                $table->json('label');             // {'fr':'Groupe A','en':'Group A'}
                $table->string('code');            // 'GRP-A','TUT1','LAB-IT-B'
                // 'tutorial'|'lab'|'oral'|'other'
                $table->string('type')->default('tutorial');
                $table->unsignedInteger('max_capacity')->default(25);
                $table->unsignedInteger('current_size')->default(0);
                $table->boolean('active')->default(true);
                $table->json('notes')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['class_id', 'subject_id', 'code'], 'study_group_unique');
            });
        }

        // Attach study_group_id to time_slots
        if (Schema::hasTable('time_slots') && !Schema::hasColumn('time_slots', 'study_group_id')) {
            Schema::table('time_slots', function (Blueprint $table) {
                $table->foreignId('study_group_id')
                    ->nullable()->after('room_id')
                    ->constrained('study_groups')->nullOnDelete();
            });
        }

        // ── 55. STUDY GROUP ENROLLMENT (pivot) ────────────────────────────
        if (!Schema::hasTable('study_group_enrollment')) {
            Schema::create('study_group_enrollment', function (Blueprint $table) {
                $table->id();
                $table->foreignId('study_group_id')->constrained('study_groups')->cascadeOnDelete();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['study_group_id', 'enrollment_id']);
            });
        }

        // ── 56. HOLIDAY PERIODS ───────────────────────────────────────────
        if (!Schema::hasTable('holiday_periods')) {
            Schema::create('holiday_periods', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->cascadeOnDelete();
                $table->json('label');             // {'fr':'Vacances de Noël','en':'Christmas break','ar':'…'}
                // 'holiday'|'public_holiday'|'exam_period'|'event'|'other'
                $table->string('type')->default('holiday')->index();
                $table->date('start_date');
                $table->date('end_date');
                // 'institution'|'national'|'regional'
                $table->string('scope')->default('institution');
                $table->boolean('classes_suspended')->default(true);
                $table->boolean('absences_neutralized')->default(true);
                $table->string('color')->default('#f59e0b');
                $table->boolean('active')->default(true);
                $table->json('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── 57–59. OPTIONAL: CAFETERIA MODULE ─────────────────────────────
        if (!Schema::hasTable('cafeteria_menus')) {
            Schema::create('cafeteria_menus', function (Blueprint $table) {
                $table->id();
                $table->foreignId('school_year_id')->constrained('school_years')->cascadeOnDelete();
                $table->json('label');
                $table->json('description')->nullable();
                $table->date('date');
                // 'breakfast'|'lunch'|'snack'|'dinner'
                $table->string('meal_type')->default('lunch');
                $table->decimal('price', 10, 2)->default(0);
                $table->string('currency', 3)->default('XAF');
                $table->unsignedInteger('capacity')->default(0);
                $table->unsignedInteger('reservations_count')->default(0);
                $table->json('allergens')->nullable();
                $table->json('nutritional_values')->nullable();
                $table->boolean('active')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['school_year_id', 'date', 'meal_type'], 'cafeteria_menu_unique');
            });
        }

        if (!Schema::hasTable('cafeteria_subscriptions')) {
            Schema::create('cafeteria_subscriptions', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->foreignId('enrollment_id')->constrained('enrollments')->cascadeOnDelete();
                // 'annual'|'quarterly'|'monthly'|'weekly'|'daily'
                $table->string('subscription_type')->default('monthly');
                $table->json('active_days')->nullable();  // [1,2,3,4,5] = Mon-Fri
                $table->string('meal_type')->default('lunch');
                $table->decimal('amount', 10, 2)->default(0);
                $table->string('currency', 3)->default('XAF');
                $table->date('start_date');
                $table->date('end_date')->nullable();
                // 'active'|'suspended'|'cancelled'|'expired'
                $table->string('status')->default('active')->index();
                $table->string('diet')->nullable(); // 'standard'|'vegetarian'|'gluten_free'|'halal'
                $table->json('notes')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('meal_reservations')) {
            Schema::create('meal_reservations', function (Blueprint $table) {
                $table->id();
                $table->foreignId('cafeteria_subscription_id')->constrained('cafeteria_subscriptions')->cascadeOnDelete();
                $table->foreignId('cafeteria_menu_id')->constrained('cafeteria_menus')->cascadeOnDelete();
                $table->date('date');
                // 'reserved'|'consumed'|'absent'|'cancelled'
                $table->string('status')->default('reserved');
                $table->decimal('price_paid', 10, 2)->nullable();
                $table->timestamp('checked_at')->nullable();
                $table->timestamps();
                $table->unique(['cafeteria_subscription_id', 'cafeteria_menu_id', 'date'], 'meal_reservation_unique');
            });
        }

        // ── 60–61. OPTIONAL: EQUIPMENT STOCK MODULE ───────────────────────
        if (!Schema::hasTable('equipment_stock')) {
            Schema::create('equipment_stock', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->json('label');
                $table->json('description')->nullable();
                // 'it'|'furniture'|'book'|'supplies'|'sports'|'science'|'av'|'other'
                $table->string('category')->default('other')->index();
                $table->string('brand')->nullable();
                $table->string('model')->nullable();
                $table->string('serial_number')->nullable()->unique();
                $table->unsignedInteger('total_quantity')->default(1);
                $table->unsignedInteger('available_quantity')->default(1);
                $table->unsignedInteger('assigned_quantity')->default(0);
                $table->unsignedInteger('out_of_service_quantity')->default(0);
                $table->foreignId('room_id')->nullable()->constrained('rooms')->nullOnDelete();
                $table->decimal('unit_value', 12, 2)->nullable();
                $table->string('currency', 3)->default('XAF');
                $table->date('acquisition_date')->nullable();
                $table->date('warranty_end_date')->nullable();
                // 'good'|'worn'|'needs_repair'|'out_of_service'
                $table->string('condition')->default('good');
                $table->boolean('active')->default(true);
                $table->json('metadata')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('stock_movements')) {
            Schema::create('stock_movements', function (Blueprint $table) {
                $table->id();
                $table->foreignId('equipment_stock_id')->constrained('equipment_stock')->cascadeOnDelete();
                // 'in'|'out'|'assignment'|'return'|'loss'|'repair'
                $table->string('type')->default('out')->index();
                $table->unsignedInteger('quantity')->default(1);
                $table->date('movement_date');
                $table->date('expected_return_date')->nullable();
                $table->date('actual_return_date')->nullable();
                $table->string('recipient_type')->nullable();
                $table->unsignedBigInteger('recipient_id')->nullable();
                $table->index(['recipient_type', 'recipient_id']);
                $table->foreignId('destination_room_id')->nullable()->constrained('rooms')->nullOnDelete();
                // 'in_progress'|'returned'|'lost'|'out_of_service'
                $table->string('status')->default('in_progress');
                $table->json('reason')->nullable();
                $table->json('notes')->nullable();
                $table->unsignedBigInteger('handed_by')->nullable();
                $table->unsignedBigInteger('received_by')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    // ── ROLLBACK ───────────────────────────────────────────────────────────
    public function down(): void
    {
        // Drop circular FK first
        Schema::table('attendances', function (Blueprint $table) {
            $table->dropForeign(['justification_id']);
        });

        // Remove study_group_id from time_slots
        if (Schema::hasTable('time_slots') && Schema::hasColumn('time_slots', 'study_group_id')) {
            Schema::table('time_slots', function (Blueprint $table) {
                $table->dropForeign(['study_group_id']);
                $table->dropColumn('study_group_id');
            });
        }

        $tables = [
            'stock_movements', 'equipment_stock',
            'meal_reservations', 'cafeteria_subscriptions', 'cafeteria_menus',
            'holiday_periods',
            'study_group_enrollment',
            'school_certificates', 'data_operations', 'school_notifications', 'school_settings',
            'homework_submissions', 'homeworks',
            'teaching_resources',
            'council_participants', 'class_councils',
            'disciplinary_sanctions',
            'calendar_events',
            'messages', 'conversation_participants', 'conversations',
            'announcement_reads', 'announcements',
            'scholarships',
            'payments', 'payment_installments', 'school_fees', 'fee_schedules', 'fee_types',
            'absence_justifications', 'attendances',
            'report_cards', 'period_averages', 'subject_averages', 'grades',
            'assessments',
            'enrollments',
            'student_guardian', 'guardians', 'students',
            'schedule_exceptions', 'time_slots', 'timetables',
            'course_assignments', 'teacher_subject', 'teachers',
            'staff',
            'curriculum_subject', 'curricula', 'subjects',
            'classes',
            'rooms', 'buildings',
            'grade_level_specialization', 'specializations', 'grade_levels',
            'cycles',
            'periods',
            'school_years',
        ];

        foreach ($tables as $table) {
            Schema::dropIfExists($table);
        }

        Schema::dropIfExists('study_groups');
        Schema::dropIfExists('schools');
    }
};
