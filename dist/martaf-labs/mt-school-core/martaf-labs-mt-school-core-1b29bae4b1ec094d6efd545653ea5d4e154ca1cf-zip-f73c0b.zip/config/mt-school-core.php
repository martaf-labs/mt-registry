<?php

/**
 * mt-school-core configuration
 *
 * School profile information (name, logo, contact, etc.) is stored in the
 * `schools` database table — NOT here. This file holds behavioural settings
 * that drive application logic, not school identity data.
 *
 * All values can be overridden via environment variables.
 */

return [

    /*
    |--------------------------------------------------------------------------
    | Multi-tenant (SaaS base partagée — tenant = école)
    |--------------------------------------------------------------------------
    | Voir CLAUDE.md. L'école courante = école du user connecté (SchoolResolver).
    |
    | transitional_single_school : repli TEMPORAIRE de dev — quand aucune école
    | n'est résolue (pas de tenant en session ni de user->school_id), on retombe
    | sur la première école active. À PASSER À `false` avant d'ouvrir le SaaS à
    | plusieurs écoles (sinon risque de fuite de données entre tenants).
    */
    'tenant' => [
        'transitional_single_school' => env('SCHOOL_TENANT_TRANSITIONAL', true),
    ],

    /*
    |--------------------------------------------------------------------------
    | Setup wizard
    |--------------------------------------------------------------------------
    | Cycles proposés à l'installation (modèle Afrique francophone) : Maternelle,
    | Primaire, Collège (secondaire 1er cycle) et Lycée (secondaire 2nd cycle).
    | Le SUPÉRIEUR n'est pas encore couvert — ajouter 'higher' quand l'offre s'élargira
    | (le wizard est déjà multi-cycles et le référentiel piloté par cette config).
    */
    'setup' => [
        'cycles' => explode(',', env('SCHOOL_SETUP_CYCLES', 'preschool,primary,college,lycee')),
    ],

    /*
    |--------------------------------------------------------------------------
    | Multilingual support
    |--------------------------------------------------------------------------
    | Relies on Mt\MtFoundation\Helpers\MtLocale and spatie/laravel-translatable.
    */
    'multilingual' => [
        'enabled' => env('SCHOOL_MULTILINGUAL', false),
        'locales' => explode(',', env('SCHOOL_LOCALES', 'fr')), // ['fr','en','ar']
        'default' => env('SCHOOL_DEFAULT_LOCALE', 'fr'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Grading system
    |--------------------------------------------------------------------------
    */
    'grading' => [
        'max_score'        => env('SCHOOL_MAX_SCORE', 20),
        'passing_score'    => env('SCHOOL_PASSING_SCORE', 10),
        'decimal_places'   => env('SCHOOL_DECIMAL_PLACES', 2),
        // 'numeric' | 'letter' | 'appreciation'
        'system'           => env('SCHOOL_GRADING_SYSTEM', 'numeric'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Notifications
    |--------------------------------------------------------------------------
    | En plus des notifications in-app (SchoolNotification + cloche), l'école peut
    | recevoir un e-mail RÉEL par notification. Désactivé par défaut : rien n'est
    | envoyé tant que SCHOOL_NOTIFY_EMAIL n'est pas activé ET que le mailer (SMTP)
    | n'est pas configuré. Un échec d'envoi ne casse jamais la notification in-app.
    */
    'notifications' => [
        'email_enabled' => env('SCHOOL_NOTIFY_EMAIL', false),
    ],

    /*
    |--------------------------------------------------------------------------
    | Report cards
    |--------------------------------------------------------------------------
    */
    'report_card' => [
        'sequences_per_term' => env('SCHOOL_SEQUENCES_PER_TERM', 2),
        'terms_per_year'     => env('SCHOOL_TERMS', 3),
        'show_appreciation'  => env('SCHOOL_SHOW_APPRECIATION', true),
        'show_rank'          => env('SCHOOL_SHOW_RANK', true),
        'show_class_size'    => env('SCHOOL_SHOW_CLASS_SIZE', true),
        // 'standard' | 'detailed' | 'compact'
        'layout'             => env('SCHOOL_REPORT_LAYOUT', 'standard'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Enrollment / Registration
    |--------------------------------------------------------------------------
    */
    'enrollment' => [
        'online_registration' => env('SCHOOL_ONLINE_REGISTRATION', false),
        'payment_required'    => env('SCHOOL_ENROLLMENT_PAYMENT', false),
        'documents_required'  => env('SCHOOL_ENROLLMENT_DOCS', true),
    ],

    /*
    |--------------------------------------------------------------------------
    | Attendance
    |--------------------------------------------------------------------------
    */
    'attendance' => [
        'enabled'           => env('SCHOOL_ATTENDANCE', true),
        // Absenteeism threshold (%) before triggering an alert
        'alert_threshold'   => env('SCHOOL_ABSENCE_THRESHOLD', 20),
        'notify_parents'    => env('SCHOOL_NOTIFY_PARENTS', false),
    ],

    /*
    |--------------------------------------------------------------------------
    | Timetable / Schedule
    |--------------------------------------------------------------------------
    */
    'timetable' => [
        'enabled'           => env('SCHOOL_TIMETABLE', true),
        'slot_duration_min' => env('SCHOOL_SLOT_DURATION', 55),   // minutes per slot
        'first_day_of_week' => env('SCHOOL_FIRST_DAY', 1),        // 1=Mon … 7=Sun (ISO)
        'active_days'       => [1, 2, 3, 4, 5],                   // Mon–Fri
    ],

    /*
    |--------------------------------------------------------------------------
    | Finances / Payments
    |--------------------------------------------------------------------------
    */
    'finance' => [
        'enabled'          => env('SCHOOL_FINANCE', true),
        'payment_gateways' => explode(',', env('SCHOOL_PAYMENT_GATEWAYS', 'cash')),
        'auto_receipts'    => env('SCHOOL_AUTO_RECEIPTS', true),
        'scholarships'     => env('SCHOOL_SCHOLARSHIPS', false),
    ],

    /*
    |--------------------------------------------------------------------------
    | Communication (messaging, announcements)
    |--------------------------------------------------------------------------
    */
    'communication' => [
        'messaging'     => env('SCHOOL_MESSAGING', true),
        'announcements' => env('SCHOOL_ANNOUNCEMENTS', true),
        'sms'           => env('SCHOOL_SMS', false),
        'email_notify'  => env('SCHOOL_EMAIL_NOTIFY', true),
    ],

    /*
    |--------------------------------------------------------------------------
    | Application roles
    |--------------------------------------------------------------------------
    */
    'roles' => [
        'super_admin' => 'super_admin',
        'principal'   => 'principal',
        'vice_principal' => 'vice_principal',
        'accountant'  => 'accountant',
        'teacher'     => 'teacher',
        'student'     => 'student',
        'parent'      => 'parent',
        'staff'       => 'staff',
    ],

    /*
    |--------------------------------------------------------------------------
    | Route middleware
    |--------------------------------------------------------------------------
    */
    'middleware' => ['web', 'auth'],

    /*
    |--------------------------------------------------------------------------
    | Champs personnalisés (EAV — par école)
    |--------------------------------------------------------------------------
    | Chaque école peut définir ses propres champs sur les entités ci-dessous.
    | `entities` mappe une clé LOGIQUE stable (stockée en base) vers la classe
    | du modèle. On ne persiste jamais le FQCN (refactor-safe).
    | Ajouter une entité = ajouter le trait HasCustomFields au modèle + une
    | entrée ici (label affiché dans l'admin).
    | ⚠️ 'label' = une CLÉ de traduction (mtschool::custom_fields.<clé>), jamais
    | de texte en dur ni d'appel __() ici : ce fichier est évalué une fois par
    | config:cache, un __() y figerait la locale active au moment du cache.
    */
    'custom_fields' => [
        'entities' => [
            'student'  => ['model' => \Mt\MtSchoolCore\Models\Student::class,     'label' => 'entity_student'],
            'guardian' => ['model' => \Mt\MtSchoolCore\Models\Guardian::class,    'label' => 'entity_guardian'],
            'staff'    => ['model' => \Mt\MtSchoolCore\Models\StaffMember::class, 'label' => 'entity_staff'],
        ],
    ],

];
