<div>
    <x-mt::screen :title="__('mtschool::messaging.title')" :description="__('mtschool::messaging.subtitle')" :breadcrumbs="[['label' => __('mtschool::messaging.title')]]" width="5xl">
        <x-slot:actions>
            <x-mt::button variant="primary" size="sm" icon="pencil-square" wire:click="openNew">{{ __('mtschool::messaging.new_message') }}</x-mt::button>
        </x-slot:actions>

        <div class="grid grid-cols-1 gap-4 md:grid-cols-[20rem_1fr]">

            {{-- Liste des conversations --}}
            <div class="overflow-hidden rounded-2xl border"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                @if ($this->conversations->isEmpty())
                    <x-mt::empty-state icon="chat-bubble" :title="__('mtschool::messaging.no_conversations')" />
                @else
                    <div class="divide-y">
                        @foreach ($this->conversations as $c)
                            <button type="button" wire:click="open({{ $c->id }})" wire:key="conv-{{ $c->id }}"
                                    class="flex w-full items-start gap-3 px-4 py-3 text-left transition hover:opacity-90"
                                    style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5); {{ $activeId === $c->id ? 'background: rgba(var(--mt-primary),0.08)' : '' }}">
                                <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white"
                                     style="background: rgb(var(--mt-primary))">
                                    {{ \Illuminate\Support\Str::of($c->title)->explode(' ')->map(fn($w)=>mb_substr($w,0,1))->take(2)->implode('') }}
                                </div>
                                <div class="min-w-0 flex-1">
                                    <div class="flex items-center justify-between gap-2">
                                        <span class="truncate text-sm font-semibold mt-text">{{ $c->title }}</span>
                                        @if ($c->unread)
                                            <span class="h-2 w-2 shrink-0 rounded-full" style="background: rgb(var(--mt-primary))"></span>
                                        @endif
                                    </div>
                                    <div class="mt-text-muted truncate text-xs">{{ $c->preview }}</div>
                                </div>
                            </button>
                        @endforeach
                    </div>
                @endif
            </div>

            {{-- Fil de la conversation active --}}
            <div class="flex min-h-[24rem] flex-col overflow-hidden rounded-2xl border"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                @if (! $this->active)
                    <div class="flex flex-1 items-center justify-center">
                        <x-mt::empty-state icon="chat-bubble" :title="__('mtschool::messaging.select_prompt')" />
                    </div>
                @else
                    <div class="flex-1 space-y-3 overflow-y-auto px-4 py-4" style="max-height: 26rem">
                        @foreach ($this->active->messages as $m)
                            @php $mine = (int) $m->sender_id === (int) auth()->id(); @endphp
                            <div class="flex {{ $mine ? 'justify-end' : 'justify-start' }}">
                                <div class="max-w-[80%] rounded-2xl px-3 py-2"
                                     style="background: {{ $mine ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text),0.06)' }}">
                                    @unless ($mine)
                                        <div class="mb-0.5 text-xs font-semibold" style="color: rgb(var(--mt-primary))">{{ $m->sender_name }}</div>
                                    @endunless
                                    <div class="whitespace-pre-wrap text-sm" style="color: {{ $mine ? 'rgb(var(--mt-primary-content))' : 'rgb(var(--mt-text))' }}">{{ $m->content }}</div>
                                    <div class="mt-1 text-[10px]" style="color: {{ $mine ? 'rgba(var(--mt-primary-content),0.7)' : 'rgba(var(--mt-text),0.45)' }}">{{ $m->created_at?->format('d/m H:i') }}</div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    <form wire:submit="send" class="flex items-end gap-2 border-t px-3 py-3"
                          style="border-color: rgba(var(--mt-ui-card-border),0.6)">
                        <textarea wire:model="body" rows="1" placeholder="{{ __('mtschool::messaging.write_placeholder') }}"
                                  class="flex-1 resize-none rounded-xl px-3 py-2 text-sm mt-text"
                                  style="background: rgb(var(--mt-ui-input-bg)); border: 1px solid rgb(var(--mt-ui-input-border))"></textarea>
                        <x-mt::button variant="primary" size="sm" icon="paper-airplane" type="submit">{{ __('mtschool::common.send') }}</x-mt::button>
                    </form>
                @endif
            </div>
        </div>

        {{-- Modale nouvelle conversation --}}
        <x-mt::modal name="new-conversation" openEvent="open-new-conversation" :title="__('mtschool::messaging.new_message')" icon="pencil-square" wire="showNew">
            <form wire:submit="startConversation" class="space-y-4">
                <x-mt::form.select :label="__('mtschool::messaging.recipient')" wire:model="recipientId" required :error="$errors->first('recipientId')">
                    <option value="">{{ __('mtschool::messaging.choose') }}</option>
                    @foreach ($this->recipients as $u)
                        <option value="{{ $u->id }}">{{ $u->name }} ({{ $u->school_role?->value }})</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.textarea :label="__('mtschool::messaging.message')" model="firstMessage" rows="4" required :error="$errors->first('firstMessage')" />
            </form>
            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'new-conversation' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
                <x-mt::button variant="primary" wire:click="startConversation" icon="paper-airplane">{{ __('mtschool::common.send') }}</x-mt::button>
            </x-slot:footer>
        </x-mt::modal>
    </x-mt::screen>
</div>
