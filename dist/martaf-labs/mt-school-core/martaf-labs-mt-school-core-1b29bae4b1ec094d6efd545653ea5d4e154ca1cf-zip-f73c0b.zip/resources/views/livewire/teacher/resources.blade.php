<div>
    <x-mt::screen :title="__('mtschool::pedagogy.my_resources')" :description="__('mtschool::pedagogy.resources_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_courses'), 'lien' => mt_get_route('teacher_home')], ['label' => __('mtschool::pedagogy.my_resources')]]" width="3xl">
        <x-slot:actions>
            @if ($this->assignments->isNotEmpty())
                <x-mt::button variant="primary" size="sm" icon="plus" wire:click="openCreate">{{ __('mtschool::pedagogy.new_resource') }}</x-mt::button>
            @endif
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        @if ($this->resources->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::pedagogy.no_resources') }}</p>
            </div>
        @else
            <div class="space-y-3">
                @foreach ($this->resources as $r)
                    <div class="flex items-center justify-between gap-3 rounded-2xl border p-4" wire:key="res-{{ $r->id }}"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="flex min-w-0 items-center gap-3">
                            <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
                                 style="background: rgba(var(--mt-primary),0.12)">
                                <x-mt::icon name="{{ $r->type === 'link' ? 'link' : 'document' }}" size="sm" class="mt-text-primary" />
                            </div>
                            <div class="min-w-0">
                                <div class="truncate font-medium mt-text">{{ $r->title }}</div>
                                <div class="mt-text-muted text-xs">
                                    {{ $r->subject?->label }} · {{ $r->classroom?->label }}
                                    @if (! $r->published) · <span style="color: rgba(var(--mt-text),0.5)">{{ __('mtschool::common.draft') }}</span> @endif
                                </div>
                            </div>
                        </div>
                        <div class="flex shrink-0 items-center gap-1">
                            @if ($r->type === 'link' && $r->external_url)
                                <a href="{{ $r->external_url }}" target="_blank" rel="noopener" class="mt-btn-icon mt-btn-icon-sm" title="Ouvrir">
                                    <x-mt::icon name="arrow-top-right-on-square" size="sm" />
                                </a>
                            @endif
                            <button wire:click="togglePublish({{ $r->id }})" class="mt-btn-icon mt-btn-icon-sm" title="Publier / dépublier">
                                <x-mt::icon name="{{ $r->published ? 'eye' : 'eye-slash' }}" size="sm" />
                            </button>
                            <button wire:click="delete({{ $r->id }})" wire:confirm="{{ __('mtschool::pedagogy.resource_delete_confirm') }}" class="mt-btn-icon mt-btn-icon-sm" title="{{ __('mtschool::common.delete') }}">
                                <x-mt::icon name="trash" size="sm" />
                            </button>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif

        {{-- Modale création ressource --}}
        <x-mt::modal name="create-resource" openEvent="open-create-resource" :title="__('mtschool::pedagogy.new_resource')" icon="document-plus" wire="showCreate">
            <form wire:submit="createResource" class="space-y-4">
                <x-mt::form.select :label="__('mtschool::pedagogy.course_field')" wire:model="assignmentId" required :error="$errors->first('assignmentId')">
                    @foreach ($this->assignments as $a)
                        <option value="{{ $a->id }}">{{ $a->subject?->label }} — {{ $a->classroom?->label }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.input :label="__('mtschool::pedagogy.title_field')" model="title" :placeholder="__('mtschool::pedagogy.resource_title_ph')" required :error="$errors->first('title')" />
                <x-mt::form.textarea :label="__('mtschool::pedagogy.description')" model="description" rows="2" />

                <x-mt::form.select :label="__('mtschool::pedagogy.type')" wire:model.live="kind">
                    <option value="link">{{ __('mtschool::pedagogy.type_link') }}</option>
                    <option value="document">{{ __('mtschool::pedagogy.type_document') }}</option>
                </x-mt::form.select>

                @if ($kind === 'link')
                    <x-mt::form.input :label="__('mtschool::pedagogy.link')" model="externalUrl" placeholder="https://…" :error="$errors->first('externalUrl')" />
                @else
                    <div>
                        <label class="mb-1 block text-sm font-medium mt-text">{{ __('mtschool::pedagogy.file') }}</label>
                        <input type="file" wire:model="upload"
                               class="block w-full text-sm mt-text file:mr-3 file:rounded-lg file:border-0 file:px-3 file:py-2 file:text-sm"
                               style="--tw-file-bg: rgb(var(--mt-primary))">
                        <div wire:loading wire:target="upload" class="mt-text-muted mt-1 text-xs">{{ __('mtschool::pedagogy.uploading') }}</div>
                        @error('upload') <p class="mt-1 text-xs" style="color: rgb(var(--mt-danger))">{{ $message }}</p> @enderror
                    </div>
                @endif
            </form>
            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'create-resource' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
                <x-mt::button variant="primary" wire:click="createResource" icon="check">{{ __('mtschool::pedagogy.share') }}</x-mt::button>
            </x-slot:footer>
        </x-mt::modal>
    </x-mt::screen>
</div>
