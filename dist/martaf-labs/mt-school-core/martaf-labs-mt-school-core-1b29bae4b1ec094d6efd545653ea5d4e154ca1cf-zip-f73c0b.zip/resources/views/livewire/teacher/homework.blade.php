<div>
    <x-mt::screen :title="__('mtschool::pedagogy.my_homework')" :description="__('mtschool::pedagogy.teacher_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_courses'), 'lien' => mt_get_route('teacher_home')], ['label' => __('mtschool::pedagogy.my_homework')]]" width="3xl">
        <x-slot:actions>
            @if ($this->assignments->isNotEmpty())
                <x-mt::button variant="primary" size="sm" icon="plus" wire:click="openCreate">{{ __('mtschool::pedagogy.new_homework') }}</x-mt::button>
            @endif
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        @if ($this->assignments->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::pedagogy.no_course_assigned') }}</p>
            </div>
        @elseif ($this->homeworks->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::pedagogy.no_homework_yet') }}</p>
            </div>
        @else
            <div class="space-y-3">
                @foreach ($this->homeworks as $hw)
                    <div class="rounded-2xl border p-4" wire:key="hw-{{ $hw->id }}"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <div class="flex items-center gap-2">
                                    <span class="inline-block h-5 w-1.5 shrink-0 rounded-full"
                                          style="background: {{ $hw->subject?->color ?: 'rgb(var(--mt-primary))' }}"></span>
                                    <span class="truncate font-semibold mt-text">{{ $hw->title }}</span>
                                </div>
                                <div class="mt-text-muted mt-1 text-xs">
                                    {{ $hw->subject?->label }} · {{ $hw->classroom?->label }}
                                    · {{ __('mtschool::pedagogy.due_on', ['date' => $hw->submission_deadline?->format('d/m/Y H:i')]) }}
                                </div>
                            </div>
                            <div class="flex shrink-0 items-center gap-2">
                                @if ($hw->status === 'published')
                                    <span class="rounded-full px-2 py-0.5 text-xs"
                                          style="background: rgba(var(--mt-success),0.15); color: rgb(var(--mt-success))">{{ __('mtschool::common.published') }}</span>
                                @else
                                    <span class="rounded-full px-2 py-0.5 text-xs"
                                          style="background: rgba(var(--mt-text),0.1); color: rgba(var(--mt-text),0.6)">{{ __('mtschool::common.draft') }}</span>
                                @endif
                            </div>
                        </div>

                        <div class="mt-3 flex flex-wrap items-center gap-2">
                            <a href="{{ mt_get_route('teacher_homework_submissions', ['homework' => $hw->id]) }}" wire:navigate>
                                <x-mt::button variant="secondary" size="sm" icon="inbox-stack">
                                    {{ __('mtschool::pedagogy.submissions') }} ({{ $hw->submissions_count }})
                                </x-mt::button>
                            </a>
                            <x-mt::button variant="ghost" size="sm" wire:click="togglePublish({{ $hw->id }})">
                                {{ $hw->status === 'published' ? __('mtschool::common.unpublish') : __('mtschool::common.publish') }}
                            </x-mt::button>
                            <x-mt::button variant="ghost" size="sm" icon="trash"
                                          wire:click="delete({{ $hw->id }})"
                                          wire:confirm="{{ __('mtschool::pedagogy.delete_confirm') }}">{{ __('mtschool::common.delete') }}</x-mt::button>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif

        {{-- Modale création devoir --}}
        <x-mt::modal name="create-homework" openEvent="open-create-homework" :title="__('mtschool::pedagogy.new_homework')" icon="clipboard-document-list" wire="showCreate">
            <form wire:submit="createHomework" class="space-y-4">
                <x-mt::form.select :label="__('mtschool::pedagogy.course_field')" wire:model="assignmentId" required :error="$errors->first('assignmentId')">
                    @foreach ($this->assignments as $a)
                        <option value="{{ $a->id }}">{{ $a->subject?->label }} — {{ $a->classroom?->label }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.input :label="__('mtschool::pedagogy.title_field')" model="title" :placeholder="__('mtschool::pedagogy.title_placeholder')" required :error="$errors->first('title')" />
                <x-mt::form.textarea :label="__('mtschool::pedagogy.instructions_field')" model="instructions" rows="3" :placeholder="__('mtschool::pedagogy.instructions_ph')" />
                <x-mt::form.input :label="__('mtschool::pedagogy.due_before')" type="datetime-local" model="deadline" required :error="$errors->first('deadline')" />

                <label class="flex items-center gap-2 text-sm mt-text">
                    <input type="checkbox" wire:model.live="isGraded" class="rounded"> {{ __('mtschool::pedagogy.graded') }}
                </label>
                @if ($isGraded)
                    <div class="grid grid-cols-2 gap-4">
                        <x-mt::form.input :label="__('mtschool::pedagogy.max_score')" type="number" model="maxScore" />
                        <x-mt::form.input :label="__('mtschool::pedagogy.coefficient')" type="number" model="coefficient" />
                    </div>
                @endif
            </form>
            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'create-homework' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
                <x-mt::button variant="primary" wire:click="createHomework" icon="check">{{ __('mtschool::common.publish') }}</x-mt::button>
            </x-slot:footer>
        </x-mt::modal>
    </x-mt::screen>
</div>
