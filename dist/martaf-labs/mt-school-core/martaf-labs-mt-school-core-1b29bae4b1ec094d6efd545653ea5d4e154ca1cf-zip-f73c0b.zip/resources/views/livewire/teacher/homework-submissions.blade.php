@php
    $screenDesc = collect([
        $homework->subject?->label,
        $homework->classroom?->label,
        __('mtschool::pedagogy.due_on', ['date' => $homework->submission_deadline?->format('d/m/Y H:i')]),
        $homework->is_graded ? __('mtschool::pedagogy.scored_out_of', ['max' => rtrim(rtrim((string) $homework->max_score, '0'), '.')]) : null,
    ])->filter()->implode(' · ');
@endphp
<div>
    <x-mt::screen :title="$homework->title" :description="$screenDesc" :breadcrumbs="[['label' => __('mtschool::pedagogy.my_homework'), 'lien' => mt_get_route('teacher_homework')], ['label' => $homework->title]]" width="3xl">
        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        <div class="overflow-hidden rounded-2xl border"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <div class="divide-y">
                @foreach ($this->rows as $row)
                    <div class="p-4" wire:key="sub-{{ $row->enrollment_id }}"
                         style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                        <div class="flex flex-wrap items-center justify-between gap-3">
                            <div class="min-w-0">
                                <div class="font-medium mt-text">{{ $row->name }}</div>
                                <div class="mt-text-muted text-xs">
                                    @if ($row->submitted_at)
                                        {{ __('mtschool::pedagogy.submitted_on', ['date' => $row->submitted_at?->format('d/m/Y H:i')]) }}
                                        @if ($row->is_late)
                                            <span style="color: rgb(var(--mt-warning))">· {{ __('mtschool::pedagogy.late') }}</span>
                                        @endif
                                    @else
                                        <span style="color: rgba(var(--mt-text),0.5)">{{ __('mtschool::pedagogy.not_submitted_yet') }}</span>
                                    @endif
                                </div>
                            </div>
                            @if ($row->file)
                                <x-mt::button variant="ghost" size="sm" icon="arrow-down-tray"
                                              wire:click="download({{ $row->enrollment_id }})">{{ __('mtschool::pedagogy.file') }}</x-mt::button>
                            @endif
                        </div>

                        @if ($row->comment)
                            <p class="mt-2 rounded-lg px-3 py-2 text-sm mt-text"
                               style="background: rgba(var(--mt-text),0.04)">{{ is_array($row->comment) ? ($row->comment['fr'] ?? '') : $row->comment }}</p>
                        @endif

                        <div class="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-[7rem_1fr_auto] sm:items-end">
                            @if ($homework->is_graded)
                                <x-mt::form.input :label="__('mtschool::pedagogy.score')" type="number"
                                                  wire:model="scores.{{ $row->enrollment_id }}" />
                            @else
                                <div></div>
                            @endif
                            <x-mt::form.input :label="__('mtschool::pedagogy.appreciation')"
                                              wire:model="corrections.{{ $row->enrollment_id }}"
                                              :placeholder="__('mtschool::pedagogy.appreciation_ph')" />
                            <x-mt::button variant="primary" size="sm" icon="check"
                                          wire:click="saveRow({{ $row->enrollment_id }})">{{ __('mtschool::common.save') }}</x-mt::button>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </x-mt::screen>
</div>
