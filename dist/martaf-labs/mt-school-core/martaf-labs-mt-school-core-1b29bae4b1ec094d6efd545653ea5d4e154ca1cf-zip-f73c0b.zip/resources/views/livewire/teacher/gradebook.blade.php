@php
    $screenDesc = collect([
        $assignment->classroom?->label,
        $this->rosterCount . ' ' . __('mtschool::common.students'),
    ])->filter()->implode(' · ');
@endphp
<div>
    <x-mt::screen :title="$assignment->subject?->label" :description="$screenDesc" :breadcrumbs="[['label' => __('mtschool::portal.my_courses'), 'lien' => mt_get_route('teacher_home')], ['label' => $assignment->subject?->label]]" width="3xl">
        <x-slot:actions>
            <x-mt::button variant="primary" size="sm" icon="plus" wire:click="openCreate">{{ __('mtschool::portal.new_assessment') }}</x-mt::button>
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        <div class="overflow-hidden rounded-2xl border"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            @if ($this->assessments->isEmpty())
                <div class="px-5 py-12 text-center">
                    <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_assessments') }}</p>
                </div>
            @else
                <div class="divide-y">
                    @foreach ($this->assessments as $a)
                        <a href="{{ mt_get_route('teacher_grades', ['id' => $a->id]) }}" wire:navigate
                           class="flex items-center justify-between gap-3 px-4 py-3 transition hover:opacity-80"
                           style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)" wire:key="ass-{{ $a->id }}">
                            <div class="min-w-0">
                                <div class="truncate font-medium mt-text">{{ $a->label }}</div>
                                <div class="mt-text-muted text-xs">{{ $a->period }} · /{{ rtrim(rtrim((string) $a->max_score,'0'),'.') }}
                                    · {{ $a->done }}/{{ $this->rosterCount }} {{ __('mtschool::portal.entries') }}</div>
                            </div>
                            <div class="flex items-center gap-2 shrink-0">
                                @if ($a->published)
                                    <span class="rounded-full px-2 py-0.5 text-xs" style="background: rgba(var(--mt-success),0.15); color: rgb(var(--mt-success))">{{ __('mtschool::common.published_f') }}</span>
                                @endif
                                <x-mt::icon name="chevron-right" size="sm" class="mt-text-muted" />
                            </div>
                        </a>
                    @endforeach
                </div>
            @endif
        </div>

        {{-- Modale création évaluation --}}
        <x-mt::modal name="create-assessment" openEvent="open-create-assessment" :title="__('mtschool::portal.new_assessment')" icon="pencil-square" wire="showCreate">
            <form wire:submit="createAssessment" class="space-y-4">
                <x-mt::form.input :label="__('mtschool::portal.assessment_label')" model="label" placeholder="{{ __('mtschool::portal.assessment_label_ph') }}" required :error="$errors->first('label')" />
                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <x-mt::form.select :label="__('mtschool::portal.period')" wire:model="periodId">
                        @foreach ($this->periods as $id => $lbl)
                            <option value="{{ $id }}">{{ $lbl }}</option>
                        @endforeach
                    </x-mt::form.select>
                    <x-mt::form.date-picker :label="__('mtschool::portal.date')" model="date" />
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <x-mt::form.input :label="__('mtschool::portal.max_score')" type="number" model="maxScore" />
                    <x-mt::form.input :label="__('mtschool::portal.coefficient')" type="number" model="coefficient" />
                </div>
            </form>
            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'create-assessment' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
                <x-mt::button variant="primary" wire:click="createAssessment" icon="check">{{ __('mtschool::common.create') }}</x-mt::button>
            </x-slot:footer>
        </x-mt::modal>
    </x-mt::screen>
</div>
