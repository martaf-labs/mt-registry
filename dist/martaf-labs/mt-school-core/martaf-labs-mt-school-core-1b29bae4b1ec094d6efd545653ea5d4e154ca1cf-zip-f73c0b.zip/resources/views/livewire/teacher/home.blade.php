<div>
    <x-mt::screen :title="__('mtschool::portal.my_courses')" :description="__('mtschool::portal.courses_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_courses')]]" width="3xl">

        @if ($this->assignments->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_courses') }}</p>
            </div>
        @else
            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                @foreach ($this->assignments as $a)
                    <div class="rounded-2xl border p-4"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="flex items-center gap-2">
                            <span class="inline-block h-7 w-1.5 shrink-0 rounded-full"
                                  style="background: {{ $a->subject?->color ?: 'rgb(var(--mt-primary))' }}"></span>
                            <div class="min-w-0">
                                <div class="truncate font-semibold mt-text">{{ $a->subject?->label }}</div>
                                <div class="mt-text-muted text-xs">{{ $a->classroom?->label }}</div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="{{ mt_get_route('teacher_gradebook', ['assignment' => $a->id]) }}" wire:navigate>
                                <x-mt::button variant="primary" size="sm" icon="pencil-square">{{ __('mtschool::portal.gradebook_title') }}</x-mt::button>
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </x-mt::screen>
</div>
