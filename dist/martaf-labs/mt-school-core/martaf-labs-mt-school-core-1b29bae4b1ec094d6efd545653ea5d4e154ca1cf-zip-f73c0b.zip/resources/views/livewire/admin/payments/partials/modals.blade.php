{{-- Modales de l'écran Encaissement — rendues via extraPartials() du base-index. --}}
<div>
    {{-- Modale d'encaissement --}}
    <x-mt::modal name="pay" openEvent="open-pay-modal" :title="__('mtschool::finances.collect_payment')" icon="credit-card" wire="showPay">
        <form wire:submit="savePayment" class="space-y-4">
            <p class="text-sm mt-text">{{ __('mtschool::finances.student_label') }} <strong>{{ $payStudent }}</strong></p>
            <x-mt::form.input label="{{ __('mtschool::finances.amount') }}" type="number" model="payAmount" required
                              :error="$errors->first('payAmount')" />
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <x-mt::form.select label="{{ __('mtschool::finances.payment_method') }}" model="payMethod">
                    @foreach ($this->paymentMethods() as $val => $lbl)
                        <option value="{{ $val }}">{{ $lbl }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.date-picker label="{{ __('mtschool::finances.date2') }}" model="payDate" />
            </div>
        </form>
        <x-slot:footer>
            <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'pay' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
            <x-mt::button variant="primary" wire:click="savePayment" icon="check">{{ __('mtschool::common.save') }}</x-mt::button>
        </x-slot:footer>
    </x-mt::modal>

    {{-- Modale de bourse --}}
    <x-mt::modal name="scholarship" openEvent="open-sch-modal" :title="__('mtschool::finances.grant_scholarship')" icon="gift" wire="showScholarship">
        <form wire:submit="saveScholarship" class="space-y-4">
            <p class="text-sm mt-text">{{ __('mtschool::finances.student_label') }} <strong>{{ $schStudent }}</strong></p>
            <x-mt::form.input label="{{ __('mtschool::finances.title_optional') }}" model="schLabel" placeholder="{{ __('mtschool::finances.scholarship_ph') }}" />
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <x-mt::form.select label="{{ __('mtschool::finances.discount_type') }}" wire:model.live="schMode">
                    <option value="percent">{{ __('mtschool::finances.percent_mode') }}</option>
                    <option value="amount">{{ __('mtschool::finances.amount_mode') }}</option>
                </x-mt::form.select>
                <x-mt::form.input label="{{ $schMode === 'percent' ? __('mtschool::finances.rate_percent') : __('mtschool::finances.amount') }}"
                                  type="number" model="schValue" required :error="$errors->first('schValue')" />
            </div>
            <x-mt::form.select label="{{ __('mtschool::finances.concerned_fees') }}" model="schFeeTypeId">
                <option value="">{{ __('mtschool::finances.all_fees') }}</option>
                @foreach ($this->feeTypes as $id => $lbl)
                    <option value="{{ $id }}">{{ $lbl }}</option>
                @endforeach
            </x-mt::form.select>
        </form>
        <x-slot:footer>
            <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'scholarship' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
            <x-mt::button variant="primary" wire:click="saveScholarship" icon="check">{{ __('mtschool::finances.grant') }}</x-mt::button>
        </x-slot:footer>
    </x-mt::modal>
</div>
