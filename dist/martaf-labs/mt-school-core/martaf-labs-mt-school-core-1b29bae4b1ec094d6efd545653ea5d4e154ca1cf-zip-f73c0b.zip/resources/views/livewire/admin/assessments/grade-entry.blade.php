@php
    $isTeacher  = auth()->user()?->school_role?->value === 'teacher';
    $backLabel  = $isTeacher ? __('mtschool::portal.my_courses') : __('mtschool::academics.assessments');
    $screenDesc = collect([
        $assessment->classroom?->label,
        $assessment->subject?->label,
        $assessment->period?->label,
        __('mtschool::academics.scale_meta', ['n' => rtrim(rtrim((string) $assessment->max_score, '0'), '.')]),
    ])->filter()->implode(' · ');
@endphp
<div>
    <x-mt::screen :title="$assessment->label" :description="$screenDesc" :breadcrumbs="[['label' => $backLabel, 'lien' => $this->backRoute()], ['label' => $assessment->label]]" width="4xl">
        <x-slot:actions>
            <div class="flex shrink-0 items-stretch gap-3">
                <div class="rounded-xl px-4 py-2 text-center" style="background: rgba(var(--mt-primary),0.1)">
                    <div class="text-lg font-bold mt-text-primary">{{ $this->classAverage !== null ? number_format($this->classAverage, 2, ',', ' ') : '—' }}</div>
                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::academics.average') }}</div>
                </div>
                <div class="rounded-xl px-4 py-2 text-center" style="background: rgba(var(--mt-info),0.1)">
                    <div class="text-lg font-bold" style="color: rgb(var(--mt-info))">{{ $this->enteredCount }}/{{ count($rows) }}</div>
                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::academics.entries') }}</div>
                </div>
            </div>
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        @if (empty($rows))
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::academics.no_validated_students') }}</p>
            </div>
        @else
            <div class="overflow-hidden rounded-2xl border"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                                <th class="px-4 py-3 font-medium" style="width:40px">#</th>
                                <th class="px-4 py-3 font-medium">{{ __('mtschool::academics.col_student2') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:130px">{{ __('mtschool::academics.col_score', ['n' => rtrim(rtrim((string) $assessment->max_score, '0'), '.')]) }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:90px">{{ __('mtschool::academics.col_absent') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:80px">{{ __('mtschool::academics.col_retained') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php $i = 0; @endphp
                            @foreach ($rows as $eid => $row)
                                @php $i++; @endphp
                                <tr wire:key="grade-row-{{ $eid }}"
                                    style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                    <td class="px-4 py-3 mt-text-muted">{{ $i }}</td>
                                    <td class="px-4 py-3">
                                        <div class="font-medium mt-text">{{ $row['student'] }}</div>
                                        @if($row['reference'])
                                            <div class="mt-text-muted text-xs">{{ $row['reference'] }}</div>
                                        @endif
                                    </td>
                                    <td class="px-3 py-2">
                                        <input type="number" step="0.25" min="0" max="{{ $assessment->max_score }}"
                                               class="mt-input mt-input-sm text-center"
                                               wire:model.blur="rows.{{ $eid }}.score"
                                               @disabled($row['is_absent'])
                                               placeholder="—" />
                                    </td>
                                    <td class="px-3 py-2 text-center">
                                        <x-mt::form.toggle wire:model="rows.{{ $eid }}.is_absent" />
                                    </td>
                                    <td class="px-3 py-3 text-center font-semibold mt-text">
                                        @if($row['is_absent'])
                                            <span class="text-xs" style="color: rgb(var(--mt-warning))">{{ __('mtschool::academics.abs_short') }}</span>
                                        @elseif($row['final_score'] !== null)
                                            {{ rtrim(rtrim(number_format($row['final_score'], 2, '.', ''), '0'), '.') }}
                                        @else
                                            <span class="mt-text-muted">—</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="mt-4 flex justify-end">
                <x-mt::button variant="primary" icon="check" wire:click="publish"
                              wire:confirm="{{ __('mtschool::academics.confirm_publish_grades') }}">
                    {{ $assessment->published ? __('mtschool::academics.republish') : __('mtschool::academics.publish_grades') }}
                </x-mt::button>
            </div>
        @endif
    </x-mt::screen>
</div>
