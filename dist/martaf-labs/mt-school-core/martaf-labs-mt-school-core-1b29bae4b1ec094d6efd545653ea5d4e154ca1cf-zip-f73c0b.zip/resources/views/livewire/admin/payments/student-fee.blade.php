@php
    $screenTitle = $enrollment->student?->full_name_reverse ?? $enrollment->student?->full_name;
    $screenDesc  = collect([$enrollment->classroom?->label, $enrollment->student?->reference])->filter()->implode(' · ');
@endphp
<div>
    <x-mt::screen :title="$screenTitle" :description="$screenDesc" :breadcrumbs="[['label' => __('mtschool::finances.payments_title'), 'lien' => mt_get_route('finances_payments')], ['label' => $screenTitle]]" width="4xl">
        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        {{-- Frais (édition / exonération) --}}
        <h3 class="mb-2 text-sm font-semibold mt-text">{{ __('mtschool::finances.fees_adjustments') }}</h3>
        <div class="mb-6 overflow-hidden rounded-2xl border"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::finances.col_type') }}</th>
                            <th class="px-3 py-3 font-medium text-right" style="width:90px">{{ __('mtschool::finances.col_gross') }}</th>
                            <th class="px-3 py-3 font-medium text-right" style="width:120px">{{ __('mtschool::finances.col_discount') }}</th>
                            <th class="px-3 py-3 font-medium text-right" style="width:90px">{{ __('mtschool::finances.col_net') }}</th>
                            <th class="px-3 py-3 font-medium text-right" style="width:90px">{{ __('mtschool::finances.col_remaining') }}</th>
                            <th class="px-3 py-3 font-medium text-center" style="width:80px">{{ __('mtschool::finances.col_exempt') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($rows as $fid => $row)
                            <tr wire:key="sf-{{ $fid }}" style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                <td class="px-4 py-3 font-medium mt-text">{{ $row['type'] }}</td>
                                <td class="px-3 py-3 text-right mt-text">{{ number_format($row['gross'], 0, ',', ' ') }}</td>
                                <td class="px-3 py-2">
                                    <input type="number" step="500" min="0" max="{{ $row['gross'] }}"
                                           class="mt-input mt-input-sm text-right"
                                           wire:model.blur="rows.{{ $fid }}.discount"
                                           @disabled($row['is_exempt']) />
                                </td>
                                <td class="px-3 py-3 text-right font-semibold mt-text">{{ number_format($row['net'], 0, ',', ' ') }}</td>
                                <td class="px-3 py-3 text-right" style="color: rgb(var(--mt-danger))">{{ number_format($row['remaining'], 0, ',', ' ') }}</td>
                                <td class="px-3 py-2 text-center">
                                    <x-mt::form.toggle wire:model="rows.{{ $fid }}.is_exempt" />
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="px-4 py-8 text-center mt-text-muted">{{ __('mtschool::finances.no_fees_hint') }}</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Échéancier --}}
        @if (! empty($rows))
            <h3 class="mb-2 text-sm font-semibold mt-text">{{ __('mtschool::finances.installments_title') }}</h3>
            <div class="mb-4 rounded-2xl border p-4"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <div class="flex flex-col gap-3 sm:flex-row sm:items-end">
                    <div class="grow">
                        <x-mt::form.select label="{{ __('mtschool::finances.fee_to_schedule') }}" wire:model="instFeeId">
                            <option value="">{{ __('mtschool::finances.choose') }}</option>
                            @foreach ($this->fees as $f)
                                <option value="{{ $f->id }}">{{ $f->feeType?->label }} ({{ number_format((float)$f->net_amount,0,',',' ') }})</option>
                            @endforeach
                        </x-mt::form.select>
                    </div>
                    <div style="width:120px">
                        <x-mt::form.input label="{{ __('mtschool::finances.installments_count') }}" type="number" model="instCount" />
                    </div>
                    <div style="width:170px">
                        <x-mt::form.date-picker label="{{ __('mtschool::finances.first_due_date') }}" model="instFirstDate" />
                    </div>
                    <x-mt::button variant="secondary" icon="calendar-days" wire:click="generateInstallments">{{ __('mtschool::finances.generate') }}</x-mt::button>
                </div>
                @error('instFeeId') <p class="mt-2 text-xs" style="color: rgb(var(--mt-danger))">{{ $message }}</p> @enderror
            </div>

            {{-- Affichage des échéances par frais --}}
            @foreach ($this->fees as $f)
                @if ($f->installments->isNotEmpty())
                    <div class="mb-3 rounded-xl border p-3" style="border-color: rgb(var(--mt-ui-card-border))">
                        <div class="mb-2 text-sm font-medium mt-text">{{ $f->feeType?->label }}</div>
                        <table class="w-full text-sm">
                            <tbody>
                                @php $cum = 0; @endphp
                                @foreach ($f->installments as $inst)
                                    @php
                                        $st = $this->installmentStatus($f, $inst, $cum);
                                        $cum += (float) $inst->amount;
                                        $map = ['paid'=>[__('mtschool::finances.inst_status_paid'),'success'],'partial'=>[__('mtschool::finances.inst_status_partial'),'warning'],'overdue'=>[__('mtschool::finances.inst_status_overdue'),'danger'],'pending'=>[__('mtschool::finances.inst_status_pending'),'secondary']];
                                        [$lbl,$col] = $map[$st];
                                    @endphp
                                    <tr style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.4)">
                                        <td class="py-2 mt-text">{{ is_array($inst->label) ? ($inst->label['fr'] ?? '') : $inst->label }}</td>
                                        <td class="py-2 mt-text-muted">{{ __('mtschool::finances.due_prefix') }} {{ $inst->due_date?->format('d/m/Y') }}</td>
                                        <td class="py-2 text-right font-medium mt-text">{{ number_format((float)$inst->amount,0,',',' ') }}</td>
                                        <td class="py-2 text-right" style="width:90px">
                                            <span class="rounded-full px-2 py-0.5 text-xs font-medium"
                                                  style="background: rgba(var(--mt-{{ $col }}),0.15); color: rgb(var(--mt-{{ $col }}))">{{ $lbl }}</span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            @endforeach
        @endif

        {{-- Historique des paiements --}}
        <h3 class="mb-2 mt-6 text-sm font-semibold mt-text">{{ __('mtschool::finances.payment_history') }}</h3>
        <div class="overflow-hidden rounded-2xl border"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            @if ($this->payments->isEmpty())
                <div class="px-5 py-8 text-center mt-text-muted text-sm">{{ __('mtschool::finances.no_payments') }}</div>
            @else
                <table class="w-full text-sm">
                    <thead>
                        <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                            <th class="px-4 py-2 font-medium">{{ __('mtschool::finances.col_date') }}</th>
                            <th class="px-3 py-2 font-medium">{{ __('mtschool::finances.col_reference') }}</th>
                            <th class="px-3 py-2 font-medium">{{ __('mtschool::finances.col_method') }}</th>
                            <th class="px-3 py-2 font-medium text-right">{{ __('mtschool::finances.col_amount2') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php $methods = ['cash'=>__('mtschool::finances.method_cash'),'mobile_money'=>__('mtschool::finances.method_mobile_money'),'bank_transfer'=>__('mtschool::finances.method_bank_transfer'),'check'=>__('mtschool::finances.method_check'),'card'=>__('mtschool::finances.method_card'),'other'=>__('mtschool::finances.method_other')]; @endphp
                        @foreach ($this->payments as $p)
                            <tr style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.4)">
                                <td class="px-4 py-2 mt-text">{{ $p->payment_date?->format('d/m/Y') }}</td>
                                <td class="px-3 py-2 mt-text-muted">{{ $p->reference }}</td>
                                <td class="px-3 py-2 mt-text">{{ $methods[$p->payment_method?->value ?? $p->payment_method] ?? '' }}</td>
                                <td class="px-3 py-2 text-right font-medium mt-text">{{ number_format((float)$p->amount,0,',',' ') }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </x-mt::screen>
</div>
