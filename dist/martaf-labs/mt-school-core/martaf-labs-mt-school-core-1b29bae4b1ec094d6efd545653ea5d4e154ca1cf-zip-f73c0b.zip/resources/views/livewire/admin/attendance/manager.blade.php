<div>
    <x-mt::screen :title="__('mtschool::attendance.title')" :description="__('mtschool::attendance.subtitle')" :breadcrumbs="[['label' => __('mtschool::attendance.title')]]" width="3xl">

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        {{-- Sélecteurs + résumé --}}
        <div class="mb-5 rounded-2xl border p-4"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-end">
                <div class="grow">
                    <x-mt::form.select label="{{ __('mtschool::attendance.classroom') }}" wire:model.live="classId">
                        @foreach ($this->classes as $id => $name)
                            <option value="{{ $id }}">{{ $name }}</option>
                        @endforeach
                    </x-mt::form.select>
                </div>
                <div style="width:170px">
                    <x-mt::form.date-picker label="{{ __('mtschool::attendance.date') }}" wire:model.live="date" />
                </div>
                <div style="width:150px">
                    <x-mt::form.select label="{{ __('mtschool::attendance.day_period') }}" wire:model.live="dayPeriod">
                        @foreach ($this->dayPeriods() as $val => $lbl)
                            <option value="{{ $val }}">{{ $lbl }}</option>
                        @endforeach
                    </x-mt::form.select>
                </div>
            </div>
            @if (! empty($rows))
                <div class="mt-3 flex justify-end">
                    <x-mt::button variant="ghost" size="sm" icon="check" wire:click="markAllPresent">{{ __('mtschool::attendance.mark_all_present') }}</x-mt::button>
                </div>
            @endif
        </div>

        {{-- Compteurs : composant de stats unifié (même rendu que dashboard / base-index). --}}
        @if (! empty($rows))
        <div class="mb-5">
            <x-mt::stats-scroll :stats="[
                ['label' => __('mtschool::attendance.stat_present'), 'value' => $this->summary['present'], 'icon' => 'check-circle', 'color' => 'success'],
                ['label' => __('mtschool::attendance.stat_absent'),  'value' => $this->summary['absent'],  'icon' => 'x-circle',     'color' => 'danger'],
                ['label' => __('mtschool::attendance.stat_late'),    'value' => $this->summary['late'],    'icon' => 'clock',        'color' => 'warning'],
            ]" />
        </div>
        @endif

        {{-- Roster --}}
        @if (empty($rows))
            <x-mt::empty-state icon="users" :title="__('mtschool::attendance.no_students')" />
        @else
            <div class="overflow-hidden rounded-2xl border"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <div class="divide-y">
                    @php $i = 0; @endphp
                    @foreach ($rows as $eid => $row)
                        @php $i++; @endphp
                        <div class="flex items-center justify-between gap-3 px-4 py-3"
                             style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)"
                             wire:key="att-{{ $eid }}">
                            <div class="flex items-center gap-3 min-w-0">
                                <span class="mt-text-muted text-xs w-5 text-right">{{ $i }}</span>
                                <span class="truncate font-medium mt-text">{{ $row['student'] }}</span>
                            </div>
                            <div class="flex shrink-0 items-center gap-2">
                                @if ($row['status'] === 'absent')
                                    <button type="button" wire:click="toggleJustified({{ $eid }})"
                                            class="rounded-full px-2 py-0.5 text-xs font-medium transition"
                                            @style([
                                                'background: rgba(var(--mt-info),0.15); color: rgb(var(--mt-info))' => $row['justified'],
                                                'background: rgba(var(--mt-muted),0.12); color: rgb(var(--mt-muted))' => ! $row['justified'],
                                            ])>
                                        {{ $row['justified'] ? __('mtschool::attendance.justified') : __('mtschool::attendance.to_justify') }}
                                    </button>
                                @endif
                                @php
                                    $opts = ['present'=>['P','success'],'absent'=>['A','danger'],'late'=>['R','warning']];
                                @endphp
                                @foreach ($opts as $st => $o)
                                    @php [$ltr,$col] = $o; $active = $row['status'] === $st; @endphp
                                    <button type="button" wire:click="setStatus({{ $eid }}, '{{ $st }}')"
                                            class="flex h-8 w-8 items-center justify-center rounded-lg text-sm font-bold transition"
                                            @style([
                                                "background: rgb(var(--mt-$col)); color: #fff" => $active,
                                                "background: rgba(var(--mt-$col),0.12); color: rgb(var(--mt-$col))" => ! $active,
                                            ])
                                            title="{{ ['present'=>__('mtschool::attendance.status_present'),'absent'=>__('mtschool::attendance.status_absent'),'late'=>__('mtschool::attendance.status_late')][$st] }}">
                                        {{ $ltr }}
                                    </button>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </x-mt::screen>
</div>
