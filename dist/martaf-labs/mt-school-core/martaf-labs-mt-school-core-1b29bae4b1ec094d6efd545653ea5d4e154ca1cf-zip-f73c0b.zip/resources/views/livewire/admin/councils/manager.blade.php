@php $canManage = auth()->user()?->can('school.class_councils.manage'); @endphp
<div>
    <x-mt::screen :title="__('mtschool::councils.title')" :description="__('mtschool::councils.subtitle')" :breadcrumbs="[['label' => __('mtschool::councils.title')]]">
        <x-slot:actions>
            @if ($canManage)
                <x-mt::button variant="primary" size="sm" icon="plus" wire:click="openCreate">{{ __('mtschool::councils.plan') }}</x-mt::button>
            @endif
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        {{-- Stats : cartes compactes façon base-index (carte neutre + puce d'icône teintée).
             flex-wrap + flex-basis inline : grid-cols-3 / md:grid-cols-* ne sont PAS dans le CSS
             précompilé (d'où l'empilement plein écran précédent). --}}
        <div class="mb-5 flex flex-wrap gap-4">
            @foreach ([
                ['key' => 'planned',   'color' => 'info',    'icon' => 'calendar-days'],
                ['key' => 'held',      'color' => 'warning', 'icon' => 'clock'],
                ['key' => 'validated', 'color' => 'success', 'icon' => 'check-circle'],
            ] as $card)
                <div class="mt-card flex items-center gap-3 p-4" style="flex: 1 1 11rem">
                    <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg"
                         style="background: rgba(var(--mt-{{ $card['color'] }}),0.12)">
                        <span style="color: rgb(var(--mt-{{ $card['color'] }}))"><x-mt::icon name="{{ $card['icon'] }}" /></span>
                    </div>
                    <div class="min-w-0">
                        <div class="text-2xl font-bold leading-none mt-text">{{ $this->stats[$card['key']] }}</div>
                        <div class="mt-1 text-xs mt-text-muted">{{ __('mtschool::councils.status_' . $card['key'] . '_plural') }}</div>
                    </div>
                </div>
            @endforeach
        </div>

        {{-- Filtres --}}
        <div class="mb-4 flex flex-wrap items-end gap-3">
            <div class="w-40">
                <x-mt::form.select label="{{ __('mtschool::councils.period') }}" wire:model.live="filterPeriodId">
                    <option value="">{{ __('mtschool::councils.all_periods') }}</option>
                    @foreach ($this->periods as $period)
                        <option value="{{ $period->id }}">{{ $period->label }}</option>
                    @endforeach
                </x-mt::form.select>
            </div>
            <div class="w-36">
                <x-mt::form.select label="{{ __('mtschool::pedagogy.sup_class') }}" wire:model.live="filterClassId">
                    <option value="">{{ __('mtschool::pedagogy.sup_all_classes') }}</option>
                    @foreach ($this->classes as $class)
                        <option value="{{ $class->id }}">{{ $class->code }}</option>
                    @endforeach
                </x-mt::form.select>
            </div>
            <div class="w-44">
                <x-mt::form.select label="{{ __('mtschool::pedagogy.sup_state') }}" wire:model.live="filterStatus">
                    <option value="">{{ __('mtschool::pedagogy.sup_all_states') }}</option>
                    <option value="planned">{{ __('mtschool::councils.status_planned') }}</option>
                    <option value="held">{{ __('mtschool::councils.status_held') }}</option>
                    <option value="minutes_drafted">{{ __('mtschool::councils.status_minutes_drafted') }}</option>
                    <option value="validated">{{ __('mtschool::councils.status_validated') }}</option>
                </x-mt::form.select>
            </div>
        </div>

        {{-- Liste --}}
        @if ($this->councils->isEmpty())
            <x-mt::empty-state icon="users" :title="__('mtschool::councils.none')">
                @if ($canManage)
                    <x-mt::button variant="primary" size="sm" icon="plus" wire:click="openCreate">{{ __('mtschool::councils.plan') }}</x-mt::button>
                @endif
            </x-mt::empty-state>
        @else
            <div class="w-full overflow-x-auto rounded-xl border" style="border-color: rgb(var(--mt-ui-card-border))">
                <table class="w-full border-collapse text-xs">
                    <thead>
                        <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::pedagogy.sup_class') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::councils.period') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::councils.date') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::councils.location') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::councils.participants') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::pedagogy.sup_state') }}</th>
                            <th class="px-4 py-3 text-right font-medium">{{ __('mtschool::common.actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($this->councils as $c)
                            @php
                                $variant = ['planned' => 'info', 'held' => 'warning', 'minutes_drafted' => 'warning', 'validated' => 'success'][$c->status] ?? 'muted';
                            @endphp
                            <tr wire:key="council-{{ $c->id }}" class="transition-colors"
                                style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)"
                                onmouseover="this.style.background='rgba(var(--mt-text),0.03)'" onmouseout="this.style.background=''">
                                <td class="px-4 py-3 text-sm font-medium mt-text">{{ $c->classroom?->code }}</td>
                                <td class="px-4 py-3 text-sm mt-text">{{ $c->period?->label }}</td>
                                <td class="px-4 py-3 text-sm mt-text-muted whitespace-nowrap">{{ $c->council_date?->format('d/m/Y H:i') }}</td>
                                <td class="px-4 py-3 text-sm mt-text">{{ $c->location ?: '—' }}</td>
                                <td class="px-4 py-3 text-sm mt-text">{{ $c->participants_count }}</td>
                                <td class="px-4 py-3">
                                    <x-mt::badge :label="__('mtschool::councils.status_' . $c->status)" :variant="$variant" class="px-2 py-0.5" style="font-size:10px" />
                                </td>
                                <td class="px-4 py-3 whitespace-nowrap text-right">
                                    <button wire:click="openManage({{ $c->id }})" class="mt-btn-icon mt-btn-icon-sm" title="{{ __('mtschool::councils.manage') }}">
                                        <x-mt::icon name="eye" size="sm" />
                                    </button>
                                    @if ($canManage && ! $c->isValidated())
                                        <button wire:click="deleteCouncil({{ $c->id }})"
                                                wire:confirm="{{ __('mtschool::councils.delete_confirm') }}"
                                                class="mt-btn-icon mt-btn-icon-sm" title="{{ __('mtschool::common.delete') }}"
                                                style="color: rgb(var(--mt-danger))">
                                            <x-mt::icon name="trash" size="sm" />
                                        </button>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif

        {{-- Modale : planifier un conseil --}}
        <x-mt::modal name="create-council" openEvent="open-create-council" :title="__('mtschool::councils.plan')" icon="users" wire="showCreate">
            <form wire:submit="createCouncil" class="space-y-4">
                <x-mt::form.select label="{{ __('mtschool::pedagogy.sup_class') }}" wire:model="classId" :error="$errors->first('classId')">
                    <option value="">—</option>
                    @foreach ($this->classes as $class)
                        <option value="{{ $class->id }}">{{ $class->code }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.select label="{{ __('mtschool::councils.period') }}" wire:model="periodId" :error="$errors->first('periodId')">
                    <option value="">—</option>
                    @foreach ($this->periods as $period)
                        <option value="{{ $period->id }}">{{ $period->label }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.input type="datetime-local" label="{{ __('mtschool::councils.date') }}" wire:model="councilDate" :error="$errors->first('councilDate')" />
                <x-mt::form.input label="{{ __('mtschool::councils.location') }}" wire:model="location" placeholder="{{ __('mtschool::councils.location_ph') }}" />
                <div class="flex justify-end gap-2">
                    <x-mt::button type="submit" variant="primary" icon="check">{{ __('mtschool::councils.plan_submit') }}</x-mt::button>
                </div>
            </form>
        </x-mt::modal>

        {{-- Modale : gérer un conseil (cycle de vie + PV + participants) --}}
        <x-mt::modal name="manage-council" openEvent="open-manage-council" :title="__('mtschool::councils.manage')" icon="users" wire="managedId" maxWidth="2xl">
            @if ($this->managed)
                @php $m = $this->managed; @endphp
                <div class="mb-4 flex flex-wrap items-center justify-between gap-2">
                    <div>
                        <div class="font-semibold mt-text">{{ $m->title ?: ($m->classroom?->code . ' · ' . $m->period?->label) }}</div>
                        <div class="mt-text-muted mt-0.5 text-xs">
                            {{ $m->council_date?->format('d/m/Y H:i') }}
                            @if ($m->location) · {{ $m->location }} @endif
                        </div>
                    </div>
                    <x-mt::badge :label="__('mtschool::councils.status_' . $m->status)"
                                 :variant="['planned' => 'info', 'held' => 'warning', 'minutes_drafted' => 'warning', 'validated' => 'success'][$m->status] ?? 'muted'"
                                 class="px-2 py-0.5 text-[10px]" />
                </div>

                {{-- Cycle de vie --}}
                @if ($canManage && ! $m->isValidated())
                    <div class="mb-4 flex flex-wrap gap-2">
                        @if ($m->status === 'planned')
                            <x-mt::button variant="secondary" size="sm" icon="check" wire:click="markHeld">{{ __('mtschool::councils.mark_held') }}</x-mt::button>
                        @endif
                        @if ($m->status === 'minutes_drafted')
                            <x-mt::button variant="primary" size="sm" icon="check-circle" wire:click="validateCouncil"
                                          wire:confirm="{{ __('mtschool::councils.validate_confirm') }}">{{ __('mtschool::councils.validate') }}</x-mt::button>
                        @endif
                    </div>
                @endif

                {{-- PV --}}
                @if ($m->isHeld() || $m->isValidated())
                    <div class="mb-4">
                        <div class="mb-1 text-xs font-semibold uppercase tracking-wide mt-text-muted">{{ __('mtschool::councils.minutes') }}</div>
                        @if ($canManage && ! $m->isValidated())
                            <x-mt::form.textarea model="minutes" :placeholder="__('mtschool::councils.minutes_ph')" rows="5" />
                            <div class="mt-2 flex justify-end">
                                <x-mt::button variant="secondary" size="sm" icon="document-text" wire:click="saveMinutes">{{ __('mtschool::councils.save_minutes') }}</x-mt::button>
                            </div>
                        @elseif ($m->minutes_content)
                            <div class="rounded-xl p-3 text-sm mt-text" style="background: rgba(var(--mt-text),0.04); white-space: pre-wrap">{{ $m->minutes_content }}</div>
                        @else
                            <p class="mt-text-muted text-sm">{{ __('mtschool::councils.no_minutes') }}</p>
                        @endif
                    </div>
                @endif

                {{-- Participants --}}
                <div>
                    <div class="mb-1 text-xs font-semibold uppercase tracking-wide mt-text-muted">{{ __('mtschool::councils.participants') }}</div>

                    @if ($m->participants->isEmpty())
                        <p class="mt-text-muted py-2 text-sm">{{ __('mtschool::councils.no_participants') }}</p>
                    @else
                        <div class="mb-3 space-y-1.5">
                            @foreach ($m->participants as $p)
                                <div wire:key="cp-{{ $p->id }}" class="flex items-center justify-between gap-2 rounded-xl border px-3 py-2"
                                     style="border-color: rgb(var(--mt-ui-card-border))">
                                    <div class="min-w-0">
                                        <span class="text-sm font-medium mt-text">{{ $this->participantNames[$p->user_id] ?? '#' . $p->user_id }}</span>
                                        <span class="mt-text-muted ml-1 text-xs">{{ __('mtschool::councils.role_' . ($p->council_role ?: 'member')) }}</span>
                                    </div>
                                    <div class="flex shrink-0 items-center gap-1.5">
                                        @if ($canManage && ! $m->isValidated())
                                            <button wire:click="toggleParticipant({{ $p->id }}, 'present')" class="mt-btn-icon mt-btn-icon-sm"
                                                    title="{{ __('mtschool::councils.present') }}"
                                                    style="color: rgb(var(--mt-{{ $p->present ? 'success' : 'danger' }}))">
                                                <x-mt::icon :name="$p->present ? 'check-circle' : 'x-circle'" size="sm" />
                                            </button>
                                            <button wire:click="toggleParticipant({{ $p->id }}, 'has_signed')" class="mt-btn-icon mt-btn-icon-sm"
                                                    title="{{ __('mtschool::councils.signed') }}"
                                                    style="{{ $p->has_signed ? 'color: rgb(var(--mt-success))' : '' }}">
                                                <x-mt::icon name="pencil" size="sm" />
                                            </button>
                                            <button wire:click="removeParticipant({{ $p->id }})" class="mt-btn-icon mt-btn-icon-sm"
                                                    style="color: rgb(var(--mt-danger))">
                                                <x-mt::icon name="trash" size="sm" />
                                            </button>
                                        @else
                                            @if ($p->present)<x-mt::badge :label="__('mtschool::councils.present')" variant="success" class="px-1.5 py-0.5 text-[10px]" />@endif
                                            @if ($p->has_signed)<x-mt::badge :label="__('mtschool::councils.signed')" variant="info" class="px-1.5 py-0.5 text-[10px]" />@endif
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif

                    @if ($canManage && ! $m->isValidated())
                        <div class="flex flex-wrap items-end gap-2">
                            <div class="min-w-44 flex-1">
                                <x-mt::form.select label="{{ __('mtschool::councils.add_participant') }}" wire:model="newParticipantId" :error="$errors->first('newParticipantId')">
                                    <option value="">—</option>
                                    @foreach ($this->staffUsers as $u)
                                        <option value="{{ $u->id }}">{{ $u->fullName() }}</option>
                                    @endforeach
                                </x-mt::form.select>
                            </div>
                            <div class="w-40">
                                <x-mt::form.select label="{{ __('mtschool::councils.role') }}" wire:model="newParticipantRole">
                                    <option value="member">{{ __('mtschool::councils.role_member') }}</option>
                                    <option value="president">{{ __('mtschool::councils.role_president') }}</option>
                                    <option value="secretary">{{ __('mtschool::councils.role_secretary') }}</option>
                                </x-mt::form.select>
                            </div>
                            <x-mt::button variant="secondary" size="sm" icon="plus" wire:click="addParticipant">{{ __('mtschool::common.add') }}</x-mt::button>
                        </div>
                    @endif
                </div>
            @endif
        </x-mt::modal>
    </x-mt::screen>
</div>
