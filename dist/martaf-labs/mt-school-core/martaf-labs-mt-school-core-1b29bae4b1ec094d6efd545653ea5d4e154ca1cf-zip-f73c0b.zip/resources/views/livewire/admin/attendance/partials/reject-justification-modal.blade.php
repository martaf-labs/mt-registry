{{-- Modale de refus d'un justificatif (motif) — rendue via extraPartials() du base-index. --}}
<x-mt::modal name="reject-justification" openEvent="open-reject-justification" wire="rejectingId"
             :title="__('mtschool::portal.reject')" icon="x-circle">
    <div class="space-y-4">
        <x-mt::form.textarea model="rejectReason" rows="3"
                             :placeholder="__('mtschool::portal.rejection_reason')" />
        <div class="flex justify-end gap-2">
            <x-mt::button variant="ghost" size="sm" wire:click="cancelReject">{{ __('mtschool::common.cancel') }}</x-mt::button>
            <x-mt::button variant="danger" size="sm" icon="x-circle" wire:click="confirmReject">{{ __('mtschool::portal.reject') }}</x-mt::button>
        </div>
    </div>
</x-mt::modal>
