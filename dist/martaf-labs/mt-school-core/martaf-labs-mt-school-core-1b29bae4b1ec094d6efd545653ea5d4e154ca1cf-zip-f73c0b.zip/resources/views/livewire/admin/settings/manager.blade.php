<div>
    <x-mt::screen :title="__('mtschool::settings.title')" :description="__('mtschool::settings.subtitle')" :breadcrumbs="[['label' => __('mtschool::settings.title')]]" width="2xl">

        @if ($savedMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$savedMessage" dismissible /></div>
        @endif

        <form wire:submit="save" class="flex flex-col gap-6">

            {{-- Notifications --}}
            <div class="rounded-2xl border p-5"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::settings.notifications_section') }}</h2>
                <p class="mt-text-muted mb-4 text-sm">{{ __('mtschool::settings.notify_email_hint') }}</p>
                <x-mt::form.toggle wire:model="notify_email" label="{{ __('mtschool::settings.notify_email') }}" />
            </div>

            {{-- Notation --}}
            <div class="rounded-2xl border p-5"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::settings.grading_section') }}</h2>
                <p class="mt-text-muted mb-4 text-sm">{{ __('mtschool::settings.grading_hint') }}</p>
                <div class="grid grid-cols-2 gap-4">
                    <x-mt::form.input type="number" step="0.5" min="0" model="passing_score"
                                      label="{{ __('mtschool::settings.passing_score') }}" :error="$errors->first('passing_score')" />
                    <x-mt::form.input type="number" step="1" min="1" model="max_score"
                                      label="{{ __('mtschool::settings.max_score') }}" :error="$errors->first('max_score')" />
                </div>
            </div>

            <div class="flex justify-end">
                <x-mt::button type="submit" variant="primary" icon="check">{{ __('mtschool::common.save') }}</x-mt::button>
            </div>
        </form>
    </x-mt::screen>
</div>
