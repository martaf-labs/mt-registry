@if ($fields->isEmpty())
    <div class="px-5 py-6 text-center">
        <p class="mt-text-muted text-sm">{{ __('mtschool::custom_fields.no_fields_here') }}</p>
    </div>
@else
    <div class="divide-y" style="--tw-divide-opacity:1">
        @foreach ($fields as $field)
            <div class="flex items-center justify-between gap-3 px-5 py-3"
                 style="border-top: 1px solid rgba(var(--mt-ui-card-border), 0.5)"
                 wire:key="field-{{ $field->id }}">
                <div class="min-w-0">
                    <div class="flex items-center gap-2">
                        <span class="truncate text-sm font-medium mt-text">{{ $field->label }}</span>
                        @unless ($field->active)
                            <span class="rounded px-1.5 py-0.5 text-[10px] mt-text-muted"
                                  style="background: rgba(var(--mt-muted),0.15)">{{ __('mtschool::custom_fields.inactive') }}</span>
                        @endunless
                        @if ($field->required)
                            <span class="text-[10px]" style="color: rgb(var(--mt-danger))">{{ __('mtschool::custom_fields.required') }}</span>
                        @endif
                    </div>
                    <div class="mt-text-muted mt-0.5 flex items-center gap-2 text-xs">
                        <code>{{ $field->key }}</code>
                        <span>·</span>
                        <span>{{ $field->type->label() }}</span>
                        @if ($field->type->hasOptions())
                            <span>· {{ __('mtschool::custom_fields.option_count', ['n' => count($field->options ?? [])]) }}</span>
                        @endif
                    </div>
                </div>
                <div class="flex shrink-0 items-center gap-1">
                    <x-mt::button variant="ghost" size="sm"
                                  :icon="$field->active ? 'toggle-on' : 'toggle-off'"
                                  wire:click="toggleField({{ $field->id }})" />
                    <x-mt::button variant="ghost" size="sm" icon="pencil" wire:click="editField({{ $field->id }})" />
                    <x-mt::button variant="ghost" size="sm" icon="trash"
                                  wire:click="deleteField({{ $field->id }})"
                                  wire:confirm="{{ __('mtschool::custom_fields.confirm_delete_field') }}" />
                </div>
            </div>
        @endforeach
    </div>
@endif
