<div>
    <x-mt::screen :title="__('mtschool::team.title')" :description="__('mtschool::team.subtitle')" :breadcrumbs="[['label' => __('mtschool::team.title')]]">
        <x-slot:actions>
            @unless ($showForm)
                <x-mt::button variant="primary" icon="plus" wire:click="create">{{ __('mtschool::team.add') }}</x-mt::button>
            @endunless
        </x-slot:actions>

        @if ($savedMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$savedMessage" dismissible /></div>
        @endif

        {{-- Formulaire création / édition --}}
        @if ($showForm)
            <div class="mb-6 rounded-2xl border p-5"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <div class="mb-4 text-sm font-semibold mt-text">
                    {{ $editingId ? __('mtschool::team.edit_title') : __('mtschool::team.add_title') }}
                </div>

                <form wire:submit="save" class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <x-mt::form.input label="{{ __('mtschool::team.name') }}" model="name" :error="$errors->first('name')" />
                    <x-mt::form.input type="email" label="{{ __('mtschool::team.email') }}" model="email" :error="$errors->first('email')" />

                    <x-mt::form.input label="{{ __('mtschool::team.phone') }}" model="phone" :error="$errors->first('phone')" />

                    <x-mt::form.select label="{{ __('mtschool::team.role') }}" wire:model="role" :error="$errors->first('role')">
                        <option value="">{{ __('mtschool::team.role_choose') }}</option>
                        @foreach ($this->roleOptions() as $value => $label)
                            <option value="{{ $value }}">{{ $label }}</option>
                        @endforeach
                    </x-mt::form.select>

                    <x-mt::form.input type="password" model="password"
                                      label="{{ $editingId ? __('mtschool::team.password_edit') : __('mtschool::team.password') }}"
                                      :error="$errors->first('password')" />

                    <div class="flex items-end">
                        <x-mt::form.toggle model="isActive" label="{{ __('mtschool::team.active') }}" />
                    </div>

                    <div class="sm:col-span-2 flex justify-end gap-2">
                        <x-mt::button type="button" variant="ghost" wire:click="cancel">{{ __('mtschool::team.cancel') }}</x-mt::button>
                        <x-mt::button type="submit" variant="primary" icon="check">{{ __('mtschool::team.save') }}</x-mt::button>
                    </div>
                </form>

                <p class="mt-3 text-xs mt-text-muted">{{ __('mtschool::team.role_hint') }}</p>
            </div>
        @endif

        {{-- Liste des membres --}}
        <div class="w-full overflow-x-auto rounded-xl border" style="border-color: rgb(var(--mt-ui-card-border))">
            <table class="w-full border-collapse text-xs">
                <thead>
                    <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                        <th class="px-4 py-3 font-medium">{{ __('mtschool::team.name') }}</th>
                        <th class="px-4 py-3 font-medium">{{ __('mtschool::team.email') }}</th>
                        <th class="px-4 py-3 font-medium">{{ __('mtschool::team.role') }}</th>
                        <th class="px-4 py-3 font-medium">{{ __('mtschool::team.status') }}</th>
                        <th class="px-4 py-3 font-medium text-right">{{ __('mtschool::team.actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($this->members as $m)
                        <tr wire:key="member-{{ $m->id }}" class="transition-colors"
                            style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)"
                            onmouseover="this.style.background='rgba(var(--mt-text),0.03)'" onmouseout="this.style.background=''">
                            <td class="px-4 py-3 text-sm mt-text">
                                {{ $m->name }}
                                @if ($m->isSelf)
                                    <span class="mt-text-muted text-xs">· {{ __('mtschool::team.you') }}</span>
                                @endif
                            </td>
                            <td class="px-4 py-3 text-sm mt-text-muted">{{ $m->email }}</td>
                            <td class="px-4 py-3">
                                <x-mt::badge :type="$m->badge" :label="$m->role?->label()" />
                            </td>
                            <td class="px-4 py-3">
                                @if ($m->active)
                                    <x-mt::badge type="success" label="{{ __('mtschool::team.active') }}" />
                                @else
                                    <x-mt::badge type="secondary" label="{{ __('mtschool::team.inactive') }}" />
                                @endif
                            </td>
                            <td class="px-4 py-3">
                                @if ($m->isOwner)
                                    <div class="flex justify-end">
                                        <span class="mt-text-muted text-xs">{{ __('mtschool::team.owner') }}</span>
                                    </div>
                                @elseif ($m->isSelf)
                                    <div class="flex justify-end">
                                        <span class="mt-text-muted text-xs">—</span>
                                    </div>
                                @else
                                    <div class="flex justify-end gap-1">
                                        <x-mt::button size="sm" variant="ghost" icon="pencil" wire:click="edit({{ $m->id }})">
                                            {{ __('mtschool::team.edit') }}
                                        </x-mt::button>
                                        <x-mt::button size="sm" variant="{{ $m->active ? 'ghost' : 'success' }}"
                                                      icon="{{ $m->active ? 'x-circle' : 'check' }}"
                                                      wire:click="toggleActive({{ $m->id }})">
                                            {{ $m->active ? __('mtschool::team.deactivate') : __('mtschool::team.activate') }}
                                        </x-mt::button>
                                    </div>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-mt::screen>
</div>
