<div>
    <x-mt::screen :title="__('mtschool::timetable.title')" :description="__('mtschool::timetable.subtitle')" :breadcrumbs="[['label' => __('mtschool::timetable.title')]]" width="5xl">

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        <div class="mb-5 rounded-2xl border p-4"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <div class="sm:w-1/2">
                <x-mt::form.select label="{{ __('mtschool::structure.col_classroom') }}" wire:model.live="classId">
                    @foreach ($this->classes as $id => $name)
                        <option value="{{ $id }}">{{ $name }}</option>
                    @endforeach
                </x-mt::form.select>
            </div>
            @if (empty($this->assignments))
                <p class="mt-2 text-xs" style="color: rgb(var(--mt-warning))">
                    {{ __('mtschool::timetable.no_assignments') }}
                    <a href="{{ mt_get_route('staff_assignments') }}" wire:navigate class="underline">{{ __('mtschool::timetable.assign_teachers') }}</a> {{ __('mtschool::timetable.first') }}
                </p>
            @endif
        </div>

        {{-- Grille --}}
        <div class="overflow-x-auto rounded-2xl border"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <table class="w-full border-collapse text-sm">
                <thead>
                    <tr>
                        <th class="p-2 text-xs font-medium mt-text-muted" style="width:70px"></th>
                        @foreach ($days as $d => $dname)
                            <th class="p-2 text-center text-xs font-semibold mt-text"
                                style="border-left: 1px solid rgb(var(--mt-ui-card-border))">{{ $dname }}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach ($periods as [$start, $end])
                        <tr style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                            <td class="p-2 text-center text-[11px] mt-text-muted whitespace-nowrap">{{ $start }}<br>{{ $end }}</td>
                            @foreach ($days as $d => $dname)
                                @php $cell = $slots["{$d}_{$start}"] ?? null; @endphp
                                <td class="p-1 align-top" style="border-left: 1px solid rgb(var(--mt-ui-card-border)); height:62px">
                                    <button type="button" wire:click="openCell({{ $d }}, '{{ $start }}', '{{ $end }}')"
                                            class="flex h-full w-full flex-col items-center justify-center rounded-lg px-1 py-1 text-center transition"
                                            @style([
                                                'background: rgba(var(--mt-primary),0.12)' => $cell,
                                                'background: transparent' => ! $cell,
                                            ])>
                                        @if ($cell)
                                            <span class="text-xs font-bold mt-text-primary">{{ $cell['subject'] }}</span>
                                            @if($cell['teacher'])<span class="text-[10px] mt-text-muted truncate w-full">{{ $cell['teacher'] }}</span>@endif
                                            @if($cell['room'])<span class="text-[9px] mt-text-muted">{{ $cell['room'] }}</span>@endif
                                        @else
                                            <span class="text-base mt-text-muted opacity-40">+</span>
                                        @endif
                                    </button>
                                </td>
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        {{-- Modale de case --}}
        <x-mt::modal name="cell" openEvent="open-cell-modal" :title="__('mtschool::timetable.course_modal_title')" icon="calendar-days" wire="showCell">
            <form wire:submit="saveCell" class="space-y-4">
                <p class="text-sm mt-text">{{ $cellLabel }}</p>
                @if ($conflictMessage)
                    <div class="rounded-lg px-3 py-2 text-sm"
                         style="background: rgba(var(--mt-danger),0.12); color: rgb(var(--mt-danger))">
                        {{ $conflictMessage }}
                    </div>
                @endif
                <x-mt::form.select label="{{ __('mtschool::timetable.course_field') }}" wire:model="cellAssignmentId">
                    <option value="">{{ __('mtschool::timetable.empty_free_cell') }}</option>
                    @foreach ($this->assignments as $id => $lbl)
                        <option value="{{ $id }}">{{ $lbl }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.select label="{{ __('mtschool::timetable.room_optional') }}" wire:model="cellRoomId">
                    <option value="">{{ __('mtschool::timetable.none') }}</option>
                    @foreach ($this->rooms as $id => $code)
                        <option value="{{ $id }}">{{ $code }}</option>
                    @endforeach
                </x-mt::form.select>
            </form>
            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'cell' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
                <x-mt::button variant="primary" wire:click="saveCell" icon="check">{{ __('mtschool::common.save') }}</x-mt::button>
            </x-slot:footer>
        </x-mt::modal>
    </x-mt::screen>
</div>
