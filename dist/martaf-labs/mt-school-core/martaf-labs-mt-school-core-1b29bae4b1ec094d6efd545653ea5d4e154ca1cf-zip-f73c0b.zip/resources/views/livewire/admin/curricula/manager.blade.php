@php
    $screenDesc = collect([
        $curriculum->gradeLevel?->label,
        $curriculum->specialization?->code,
        __('mtschool::structure.subject_count', ['n' => count($rows)]),
    ])->filter()->implode(' · ');
@endphp
<div>
    <x-mt::screen :title="$curriculum->label" :description="$screenDesc" :breadcrumbs="[['label' => __('mtschool::structure.curricula'), 'lien' => mt_get_route('curricula')], ['label' => $curriculum->label]]" width="5xl">
        <x-slot:actions>
            {{-- Totaux de coefficients --}}
            <div class="flex shrink-0 gap-3">
                <div class="rounded-xl px-4 py-2 text-center"
                     style="background: rgba(var(--mt-primary),0.1)">
                    <div class="text-lg font-bold mt-text-primary">{{ number_format($this->totalCoef, 2, ',', ' ') }}</div>
                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::structure.total_coefficient') }}</div>
                </div>
                <div class="rounded-xl px-4 py-2 text-center"
                     style="background: rgba(var(--mt-info),0.1)">
                    <div class="text-lg font-bold" style="color: rgb(var(--mt-info))">{{ number_format($this->reportCoef, 2, ',', ' ') }}</div>
                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::structure.on_report_card') }}</div>
                </div>
            </div>
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        {{-- Ajout d'une matière depuis le catalogue --}}
        <div class="mb-5 rounded-2xl border p-4"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-end">
                <div class="grow">
                    <x-mt::form.select label="{{ __('mtschool::structure.add_subject') }}" wire:model="subjectToAdd"
                                       :error="$errors->first('subjectToAdd')">
                        <option value="">{{ __('mtschool::structure.choose_from_catalog') }}</option>
                        @foreach ($this->availableSubjects as $s)
                            <option value="{{ $s->id }}">{{ $s->code }} · {{ $s->label }}</option>
                        @endforeach
                    </x-mt::form.select>
                </div>
                <x-mt::button variant="primary" icon="plus" wire:click="addSubject" wire:loading.attr="disabled">
                    {{ __('mtschool::structure.add') }}
                </x-mt::button>
            </div>
            @if ($this->availableSubjects->isEmpty())
                <p class="mt-text-muted mt-2 text-xs">
                    {{ __('mtschool::structure.all_subjects_in_curriculum') }}
                    <a href="{{ mt_get_route('subjects') }}" wire:navigate class="mt-text-primary underline">{{ __('mtschool::structure.manage_catalog') }}</a>.
                </p>
            @endif
        </div>

        {{-- Table des matières de la maquette --}}
        <div class="overflow-hidden rounded-2xl border"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            @if (empty($rows))
                <div class="px-5 py-12 text-center">
                    <p class="mt-text-muted text-sm">{{ __('mtschool::structure.no_subjects_in_curriculum') }}</p>
                    <p class="mt-text-muted mt-1 text-xs">{{ __('mtschool::structure.add_subjects_hint') }}</p>
                </div>
            @else
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                                <th class="px-4 py-3 font-medium">{{ __('mtschool::academics.col_subject2') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:90px">{{ __('mtschool::academics.col_coef') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:90px">{{ __('mtschool::structure.col_weekly_hours2') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:80px">{{ __('mtschool::structure.col_order') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:90px">{{ __('mtschool::structure.col_report_card') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:90px">{{ __('mtschool::structure.col_eliminating') }}</th>
                                <th class="px-3 py-3" style="width:50px"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($rows as $sid => $row)
                                <tr wire:key="curr-row-{{ $sid }}"
                                    style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                    <td class="px-4 py-3">
                                        <div class="flex items-center gap-2">
                                            <span class="inline-block h-6 w-1.5 shrink-0 rounded-full"
                                                  style="background: {{ $row['color'] ?: 'rgb(var(--mt-primary))' }}"></span>
                                            <div class="min-w-0">
                                                <div class="truncate font-medium mt-text">{{ $row['label'] }}</div>
                                                <div class="mt-text-muted text-xs">{{ $row['code'] }} · {{ $row['group'] }}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-3 py-2">
                                        <input type="number" step="0.25" min="0"
                                               class="mt-input mt-input-sm text-center"
                                               wire:model.blur="rows.{{ $sid }}.coefficient" />
                                    </td>
                                    <td class="px-3 py-2">
                                        <input type="number" step="0.5" min="0"
                                               class="mt-input mt-input-sm text-center"
                                               wire:model.blur="rows.{{ $sid }}.weekly_hours" />
                                    </td>
                                    <td class="px-3 py-2">
                                        <input type="number" step="1" min="1"
                                               class="mt-input mt-input-sm text-center"
                                               wire:model.blur="rows.{{ $sid }}.order" />
                                    </td>
                                    <td class="px-3 py-2 text-center">
                                        <x-mt::form.toggle wire:model="rows.{{ $sid }}.on_report_card" />
                                    </td>
                                    <td class="px-3 py-2 text-center">
                                        <x-mt::form.toggle wire:model="rows.{{ $sid }}.is_eliminating" />
                                    </td>
                                    <td class="px-3 py-2 text-center">
                                        <x-mt::button variant="ghost" size="sm" icon="trash"
                                                      wire:click="removeSubject({{ $sid }})"
                                                      wire:confirm="{{ __('mtschool::structure.confirm_remove_subject') }}" />
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </x-mt::screen>
</div>
