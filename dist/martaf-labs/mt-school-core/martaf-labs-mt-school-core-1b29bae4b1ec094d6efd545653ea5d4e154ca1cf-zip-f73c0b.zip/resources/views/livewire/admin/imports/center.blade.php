<div>
    <x-mt::screen :title="__('mtschool::imports.title')" :description="__('mtschool::imports.subtitle')" :breadcrumbs="[['label' => __('mtschool::imports.title')]]" width="3xl">

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        {{-- ─────────── EXPORTS ─────────── --}}
        <div class="mb-8 rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::imports.export_section') }}</h2>
            <p class="mt-text-muted mb-4 text-sm">{{ __('mtschool::imports.export_hint') }}</p>
            <div class="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <x-mt::button variant="secondary" icon="arrow-down-tray" wire:click="exportStudents">{{ __('mtschool::imports.students') }}</x-mt::button>
                <x-mt::button variant="secondary" icon="arrow-down-tray" wire:click="exportResults">{{ __('mtschool::imports.results') }}</x-mt::button>
                <x-mt::button variant="secondary" icon="arrow-down-tray" wire:click="exportFees">{{ __('mtschool::imports.fees') }}</x-mt::button>
            </div>
        </div>

        {{-- ─────────── ACCÈS PORTAIL ─────────── --}}
        <div class="mb-8 rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::imports.provision_section') }}</h2>
            <p class="mt-text-muted mb-4 text-sm">{{ __('mtschool::imports.provision_hint') }}</p>
            <div class="flex flex-wrap gap-3">
                <x-mt::button variant="secondary" icon="identification" wire:click="provisionParents"
                              wire:confirm="{{ __('mtschool::imports.provision_confirm') }}">
                    {{ __('mtschool::imports.provision_parents') }}
                </x-mt::button>
                <x-mt::button variant="secondary" icon="identification" wire:click="provisionStudents"
                              wire:confirm="{{ __('mtschool::imports.provision_confirm_students') }}">
                    {{ __('mtschool::imports.provision_students') }}
                </x-mt::button>
            </div>
        </div>

        {{-- ─────────── IMPORT ─────────── --}}
        <div class="rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::imports.import_section') }}</h2>
            <p class="mt-text-muted mb-3 text-sm">
                {{ __('mtschool::imports.columns_hint') }} <code class="mt-text">matricule ; nom ; prenom ; genre ; naissance ; lieu_naissance ; classe ; tuteur_nom ; tuteur_telephone ; tuteur_email ; tuteur_lien</code>
                {{ __('mtschool::imports.columns_note') }}
            </p>

            <div class="mb-3">
                <x-mt::button variant="secondary" size="sm" icon="arrow-down-tray" wire:click="downloadTemplate">
                    {{ __('mtschool::imports.download_template') }}
                </x-mt::button>
            </div>

            <div class="mb-3 rounded-xl px-3 py-2 text-xs mt-text-muted" style="background: rgba(var(--mt-text),0.04)">
                {{ __('mtschool::imports.available_codes') }}
                @foreach ($this->classes as $c)
                    <span class="mt-text">{{ $c->code }}</span>@if (! $loop->last), @endif
                @endforeach
            </div>

            @if (! $parsed)
                <form wire:submit="parse" class="space-y-3">
                    <x-mt::form.file-upload wire:model="file" item-type="file" accept=".csv,text/csv"
                        :placeholder="__('mtschool::imports.csv_drop')" :hint="__('mtschool::imports.csv_hint')"
                        :error="$errors->first('file')" />
                    <x-mt::button variant="primary" size="sm" icon="eye" type="submit">{{ __('mtschool::common.analyze') }}</x-mt::button>
                </form>
            @else
                <div class="mb-3 flex items-center justify-between">
                    <span class="text-sm mt-text">
                        {{ __('mtschool::imports.valid_of', ['valid' => collect($preview)->where('valid', true)->count(), 'total' => count($preview)]) }}
                    </span>
                    <x-mt::button variant="ghost" size="sm" wire:click="cancelImport">{{ __('mtschool::imports.change_file') }}</x-mt::button>
                </div>

                <div class="overflow-x-auto rounded-xl border" style="border-color: rgba(var(--mt-ui-card-border),0.6)">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="mt-text-muted text-left text-xs" style="background: rgba(var(--mt-text),0.04)">
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_line') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_matricule') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_lastname') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_firstname') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_gender') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_birth') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_class') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_guardian') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.col_status') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($preview as $row)
                                <tr style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                    <td class="px-3 py-2 mt-text-muted">{{ $row['line'] }}</td>
                                    <td class="px-3 py-2 mt-text-muted text-xs">{{ $row['matricule'] ?: '—' }}</td>
                                    <td class="px-3 py-2 mt-text">{{ $row['nom'] }}</td>
                                    <td class="px-3 py-2 mt-text">{{ $row['prenom'] }}</td>
                                    <td class="px-3 py-2 mt-text">{{ $row['genre'] }}</td>
                                    <td class="px-3 py-2 mt-text">{{ $row['naissance'] }}</td>
                                    <td class="px-3 py-2 mt-text">{{ $row['classe'] }}</td>
                                    <td class="px-3 py-2 mt-text-muted text-xs">{{ $row['tuteur_nom'] ?: '—' }}</td>
                                    <td class="px-3 py-2">
                                        @if ($row['valid'])
                                            <span class="rounded-full px-2 py-0.5 text-xs" style="background: rgba(var(--mt-success),0.15); color: rgb(var(--mt-success))">{{ __('mtschool::imports.status_ok') }}</span>
                                        @else
                                            <span class="rounded-full px-2 py-0.5 text-xs" style="background: rgba(var(--mt-danger),0.15); color: rgb(var(--mt-danger))" title="{{ implode(', ', $row['errors']) }}">{{ implode(', ', $row['errors']) }}</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="mt-4 flex flex-wrap justify-end gap-2">
                    @if (collect($preview)->where('valid', false)->count() > 0)
                        <x-mt::button variant="secondary" size="sm" icon="arrow-down-tray" wire:click="downloadErrors">
                            {{ __('mtschool::imports.download_errors', ['n' => collect($preview)->where('valid', false)->count()]) }}
                        </x-mt::button>
                    @endif
                    <x-mt::button variant="ghost" size="sm" wire:click="cancelImport">{{ __('mtschool::common.cancel') }}</x-mt::button>
                    <x-mt::button variant="primary" size="sm" icon="check" wire:click="import"
                                  wire:confirm="{{ __('mtschool::imports.import_confirm') }}">
                        {{ __('mtschool::imports.import_n', ['n' => collect($preview)->where('valid', true)->count()]) }}
                    </x-mt::button>
                </div>
            @endif
        </div>

        {{-- ─────────── IMPORT PERSONNEL ─────────── --}}
        <div class="mt-8 rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::imports.staff_section') }}</h2>
            <p class="mt-text-muted mb-3 text-sm">
                {{ __('mtschool::imports.staff_hint') }} <code class="mt-text">nom ; prenom ; genre ; email ; telephone ; fonction</code>
            </p>
            <div class="mb-3">
                <x-mt::button variant="secondary" size="sm" icon="arrow-down-tray" wire:click="downloadStaffTemplate">
                    {{ __('mtschool::imports.download_template') }}
                </x-mt::button>
            </div>
            <form wire:submit="importStaff" class="space-y-3">
                <x-mt::form.file-upload wire:model="staffFile" item-type="file" accept=".csv,text/csv"
                    :placeholder="__('mtschool::imports.csv_drop')" :hint="__('mtschool::imports.csv_hint')"
                    :error="$errors->first('staffFile')" />
                <x-mt::button variant="primary" size="sm" icon="arrow-up-tray" type="submit"
                              wire:confirm="{{ __('mtschool::imports.staff_confirm') }}">
                    {{ __('mtschool::imports.import_staff') }}
                </x-mt::button>
            </form>
        </div>

        {{-- ─────────── IMPORT MATIÈRES ─────────── --}}
        <div class="mt-8 rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::imports.subjects_section') }}</h2>
            <p class="mt-text-muted mb-3 text-sm">
                {{ __('mtschool::imports.staff_hint') }} <code class="mt-text">code ; nom ; abreviation ; groupe</code>
            </p>
            <div class="mb-3">
                <x-mt::button variant="secondary" size="sm" icon="arrow-down-tray" wire:click="downloadSubjectTemplate">
                    {{ __('mtschool::imports.download_template') }}
                </x-mt::button>
            </div>
            <form wire:submit="importSubjects" class="space-y-3">
                <x-mt::form.file-upload wire:model="subjectFile" item-type="file" accept=".csv,text/csv"
                    :placeholder="__('mtschool::imports.csv_drop')" :hint="__('mtschool::imports.csv_hint')"
                    :error="$errors->first('subjectFile')" />
                <x-mt::button variant="primary" size="sm" icon="arrow-up-tray" type="submit">
                    {{ __('mtschool::imports.import_subjects') }}
                </x-mt::button>
            </form>
        </div>

        {{-- ─────────── IMPORT AFFECTATIONS ─────────── --}}
        <div class="mt-8 rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <h2 class="mb-1 font-semibold mt-text">{{ __('mtschool::imports.assign_section') }}</h2>
            <p class="mt-text-muted mb-3 text-sm">
                {{ __('mtschool::imports.assign_hint') }} <code class="mt-text">enseignant_email ; classe ; matiere ; heures ; coefficient</code>
            </p>
            <div class="mb-3">
                <x-mt::button variant="secondary" size="sm" icon="arrow-down-tray" wire:click="downloadAssignTemplate">
                    {{ __('mtschool::imports.download_template') }}
                </x-mt::button>
            </div>
            <form wire:submit="importAssignments" class="space-y-3">
                <x-mt::form.file-upload wire:model="assignFile" item-type="file" accept=".csv,text/csv"
                    :placeholder="__('mtschool::imports.csv_drop')" :hint="__('mtschool::imports.csv_hint')"
                    :error="$errors->first('assignFile')" />
                <x-mt::button variant="primary" size="sm" icon="arrow-up-tray" type="submit">
                    {{ __('mtschool::imports.import_assignments') }}
                </x-mt::button>
            </form>
        </div>

        {{-- ─────────── HISTORIQUE DES IMPORTS (audit) ─────────── --}}
        @if ($this->recentImports->isNotEmpty())
            <div class="mt-8 rounded-2xl border p-5"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <h2 class="mb-3 font-semibold mt-text">{{ __('mtschool::imports.history_section') }}</h2>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="mt-text-muted text-left text-xs" style="background: rgba(var(--mt-text),0.04)">
                                <th class="px-3 py-2">{{ __('mtschool::imports.history_date') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.history_type') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.history_result') }}</th>
                                <th class="px-3 py-2">{{ __('mtschool::imports.history_by') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($this->recentImports as $log)
                                <tr style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                    <td class="px-3 py-2 mt-text-muted">{{ optional($log->created_at)->format('d/m/Y H:i') }}</td>
                                    <td class="px-3 py-2 mt-text">{{ __('mtschool::imports.type_' . $log->type) }}</td>
                                    <td class="px-3 py-2 mt-text">
                                        <span style="color: rgb(var(--mt-success))">{{ $log->imported }}</span>
                                        @if ($log->skipped > 0) · <span class="mt-text-muted">{{ $log->skipped }} {{ __('mtschool::imports.history_skipped') }}</span>@endif
                                    </td>
                                    <td class="px-3 py-2 mt-text-muted">{{ $log->user?->name ?? '—' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @endif
    </x-mt::screen>
</div>
