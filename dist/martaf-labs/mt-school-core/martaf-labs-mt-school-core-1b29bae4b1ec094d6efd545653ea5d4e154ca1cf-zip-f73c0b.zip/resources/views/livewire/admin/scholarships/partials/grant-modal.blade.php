{{-- Modale d'attribution d'une bourse — rendue via extraPartials() du base-index. --}}
@php $loc = fn ($v) => is_array($v) ? ($v[app()->getLocale()] ?? reset($v)) : $v; @endphp
<x-mt::modal name="grant-scholarship" openEvent="open-grant-scholarship"
             :title="__('mtschool::finances.scholarship_grant')" icon="gift" maxWidth="2xl">
    <form wire:submit="grant" class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <x-mt::form.select label="{{ __('mtschool::finances.scholarship_class') }}" wire:model.live="classId">
            <option value="">—</option>
            @foreach ($this->classes as $class)
                <option value="{{ $class->id }}">{{ $class->code }}</option>
            @endforeach
        </x-mt::form.select>

        <x-mt::form.select label="{{ __('mtschool::finances.scholarship_student') }}" wire:model="enrollmentId" :error="$errors->first('enrollmentId')">
            <option value="">{{ __('mtschool::finances.scholarship_choose_student') }}</option>
            @foreach ($this->enrollments as $e)
                <option value="{{ $e->id }}">{{ $e->name }}</option>
            @endforeach
        </x-mt::form.select>

        <x-mt::form.select label="{{ __('mtschool::finances.scholarship_mode') }}" wire:model="mode">
            <option value="percent">{{ __('mtschool::finances.scholarship_mode_percent') }}</option>
            <option value="amount">{{ __('mtschool::finances.scholarship_mode_amount') }}</option>
        </x-mt::form.select>

        <x-mt::form.input type="number" step="0.01" min="0.01"
                          label="{{ __('mtschool::finances.scholarship_value') }}" model="value"
                          :error="$errors->first('value')" />

        <x-mt::form.select label="{{ __('mtschool::finances.scholarship_coverage') }}" wire:model="feeTypeId">
            <option value="">{{ __('mtschool::finances.scholarship_coverage_all') }}</option>
            @foreach ($this->feeTypes as $ft)
                <option value="{{ $ft->id }}">{{ $loc($ft->label) }}</option>
            @endforeach
        </x-mt::form.select>

        <x-mt::form.select label="{{ __('mtschool::finances.scholarship_category') }}" wire:model="category">
            @foreach ($this->categories() as $cat)
                <option value="{{ $cat }}">{{ __('mtschool::finances.scholarship_cat_' . $cat) }}</option>
            @endforeach
        </x-mt::form.select>

        <div class="sm:col-span-2">
            <x-mt::form.input label="{{ __('mtschool::finances.scholarship_label') }}" model="label"
                              placeholder="{{ __('mtschool::finances.scholarship_label_ph') }}" />
        </div>
    </form>
    <x-slot:footer>
        <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'grant-scholarship' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
        <x-mt::button variant="primary" wire:click="grant" icon="gift">{{ __('mtschool::finances.scholarship_grant') }}</x-mt::button>
    </x-slot:footer>
</x-mt::modal>
