@php
    $screenDesc = collect([
        $classroom->gradeLevel?->label,
        $classroom->specialization?->code,
        $curriculum ? __('mtschool::academics.subjects_meta', ['n' => count($rows)]) : null,
        $curriculum ? __('mtschool::academics.assigned_meta', ['n' => $this->assignedCount]) : null,
    ])->filter()->implode(' · ');
@endphp
<div>
    <x-mt::screen :title="$classroom->label" :description="$screenDesc" :breadcrumbs="[['label' => __('mtschool::academics.assignments'), 'lien' => mt_get_route('staff_assignments')], ['label' => $classroom->label]]" width="5xl">
        <x-slot:actions>
            @if($curriculum)
                <div class="rounded-xl px-4 py-2 text-center shrink-0"
                     style="background: rgba(var(--mt-primary),0.1)">
                    <div class="text-lg font-bold mt-text-primary">{{ $this->assignedCount }}/{{ count($rows) }}</div>
                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::academics.assigned') }}</div>
                </div>
            @endif
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        @if (! $curriculum)
            {{-- Pas de maquette → on relie au module Maquettes --}}
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text text-sm font-medium">{{ __('mtschool::academics.no_curriculum') }}</p>
                <p class="mt-text-muted mt-1 text-xs">
                    {{ __('mtschool::academics.no_curriculum_hint', ['level' => $classroom->gradeLevel?->label]) }}
                </p>
                <div class="mt-4">
                    <x-mt::button variant="primary" size="sm" icon="rectangle-stack"
                                  :href="mt_get_route('curricula')">
                        {{ __('mtschool::academics.go_to_curricula') }}
                    </x-mt::button>
                </div>
            </div>
        @elseif (empty($rows))
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::academics.empty_curriculum') }}</p>
                <div class="mt-4">
                    <x-mt::button variant="secondary" size="sm" icon="book"
                                  :href="mt_get_route('curricula_manage', ['id' => $curriculum->id])">
                        {{ __('mtschool::academics.manage_curriculum_subjects') }}
                    </x-mt::button>
                </div>
            </div>
        @else
            @if (empty($this->teachers))
                <div class="mb-4 rounded-xl px-4 py-3 text-sm"
                     style="background: rgba(var(--mt-warning),0.12); color: rgb(var(--mt-warning))">
                    {{ __('mtschool::academics.no_active_teachers') }} <a href="{{ mt_get_route('staff_teachers') }}" wire:navigate class="underline">{{ __('mtschool::academics.add_teachers') }}</a> {{ __('mtschool::academics.add_teachers_suffix') }}
                </div>
            @endif

            <div class="overflow-hidden rounded-2xl border"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                                <th class="px-4 py-3 font-medium">{{ __('mtschool::academics.col_subject2') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:80px">{{ __('mtschool::academics.col_coef') }}</th>
                                <th class="px-3 py-3 font-medium" style="min-width:200px">{{ __('mtschool::academics.col_teacher2') }}</th>
                                <th class="px-3 py-3 font-medium text-center" style="width:100px">{{ __('mtschool::academics.col_weekly_hours') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($rows as $sid => $row)
                                <tr wire:key="assign-row-{{ $sid }}"
                                    style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                    <td class="px-4 py-3">
                                        <div class="flex items-center gap-2">
                                            <span class="inline-block h-6 w-1.5 shrink-0 rounded-full"
                                                  style="background: {{ $row['color'] ?: 'rgb(var(--mt-primary))' }}"></span>
                                            <div class="min-w-0">
                                                <div class="truncate font-medium mt-text">{{ $row['label'] }}</div>
                                                <div class="mt-text-muted text-xs">{{ $row['code'] }}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-3 py-3 text-center mt-text-muted">
                                        {{ rtrim(rtrim(number_format($row['coefficient'], 2, '.', ''), '0'), '.') }}
                                    </td>
                                    <td class="px-3 py-2">
                                        <x-mt::form.select wire:model.live="rows.{{ $sid }}.teacher_id">
                                            <option value="">{{ __('mtschool::academics.not_assigned') }}</option>
                                            @foreach ($this->teachers as $tid => $tname)
                                                <option value="{{ $tid }}">{{ $tname }}</option>
                                            @endforeach
                                        </x-mt::form.select>
                                    </td>
                                    <td class="px-3 py-2">
                                        <input type="number" step="0.5" min="0"
                                               class="mt-input mt-input-sm text-center"
                                               wire:model.blur="rows.{{ $sid }}.weekly_hours"
                                               @disabled(empty($row['teacher_id'])) />
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        @endif
    </x-mt::screen>
</div>
