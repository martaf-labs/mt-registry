<div class="mx-auto w-full max-w-3xl px-4 py-6">

    {{-- Barre d'actions (masquée à l'impression) --}}
    <div class="mb-4 flex items-center justify-between print:hidden">
        <a href="{{ mt_get_route('academics_report_cards') }}" wire:navigate class="mt-btn-icon mt-btn-icon-sm">
            <x-mt::icon name="arrow-left" size="sm" />
        </a>
        <div class="flex items-center gap-2">
            <a href="{{ mt_get_route('academics_report_cards_pdf', ['enrollment' => $enrollmentId, 'period' => $periodId]) }}"
               target="_blank">
                <x-mt::button variant="primary" size="sm" icon="document-text">PDF</x-mt::button>
            </a>
            @isset($yearId)
            <a href="{{ mt_get_route('academics_report_cards_annual_pdf', ['enrollment' => $enrollmentId, 'year' => $yearId]) }}"
               target="_blank">
                <x-mt::button variant="secondary" size="sm" icon="document-text">{{ __('mtschool::documents.annual_report_card_title') }}</x-mt::button>
            </a>
            @endisset
            <x-mt::button variant="secondary" size="sm" icon="document-text" onclick="window.print()">
                {{ __('mtschool::report_card.print') }}
            </x-mt::button>
        </div>
    </div>

    {{-- Bulletin --}}
    <div class="rounded-2xl border p-6 print:border-0"
         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">

        {{-- En-tête établissement --}}
        <div class="mb-5 flex items-center justify-between border-b pb-4"
             style="border-color: rgb(var(--mt-ui-card-border))">
            <div class="flex items-center gap-3">
                @if(function_exists('mt_brand_logo') && mt_brand_logo())
                    <img src="{{ mt_brand_logo() }}" alt="" class="h-12 w-12 rounded-lg object-cover">
                @endif
                <div>
                    <div class="text-lg font-bold mt-text">{{ function_exists('mt_brand_name') ? mt_brand_name() : '' }}</div>
                    <div class="mt-text-muted text-xs">{{ __('mtschool::report_card.report_card') }}</div>
                </div>
            </div>
            <div class="text-right text-xs mt-text-muted">
                <div class="font-medium mt-text">{{ $period->label }}</div>
                <div>{{ $enrollment->classroom?->schoolYear?->label ?? '' }}</div>
            </div>
        </div>

        {{-- Identité élève --}}
        <div class="mb-5 grid grid-cols-2 gap-3 text-sm">
            <div>
                <span class="mt-text-muted">{{ __('mtschool::report_card.student') }} : </span>
                <span class="font-semibold mt-text">{{ $enrollment->student?->full_name_reverse ?? $enrollment->student?->full_name }}</span>
            </div>
            <div class="text-right">
                <span class="mt-text-muted">{{ __('mtschool::report_card.classroom') }} : </span>
                <span class="font-semibold mt-text">{{ $enrollment->classroom?->label }}</span>
            </div>
            @if($enrollment->student?->reference)
                <div><span class="mt-text-muted">{{ __('mtschool::report_card.reference') }} : </span><span class="mt-text">{{ $enrollment->student->reference }}</span></div>
            @endif
            @if($periodAverage)
                <div class="text-right"><span class="mt-text-muted">{{ __('mtschool::report_card.class_size') }} : </span><span class="mt-text">{{ $periodAverage->class_size }}</span></div>
            @endif
        </div>

        {{-- Tableau des matières --}}
        <table class="w-full text-sm">
            <thead>
                <tr class="text-left mt-text-muted" style="border-bottom: 2px solid rgb(var(--mt-ui-card-border))">
                    <th class="py-2 font-medium">{{ __('mtschool::report_card.col_subject') }}</th>
                    <th class="py-2 font-medium text-center" style="width:70px">{{ __('mtschool::report_card.col_average') }}</th>
                    <th class="py-2 font-medium text-center" style="width:55px">{{ __('mtschool::report_card.col_coefficient') }}</th>
                    <th class="py-2 font-medium text-center" style="width:70px">{{ __('mtschool::report_card.col_weighted') }}</th>
                    <th class="py-2 font-medium text-center" style="width:55px">{{ __('mtschool::report_card.col_rank') }}</th>
                    <th class="py-2 font-medium text-center" style="width:70px">{{ __('mtschool::report_card.col_class_average') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($subjects as $sa)
                    <tr style="border-bottom: 1px solid rgba(var(--mt-ui-card-border),0.4)">
                        <td class="py-2 font-medium mt-text">
                            {{ $sa->subject?->label }}
                            <input type="text" placeholder="{{ __('mtschool::report_card.appreciation_placeholder') }}"
                                   class="mt-input mt-input-sm mt-1 w-full text-xs print:hidden"
                                   wire:model.blur="subjAppr.{{ $sa->id }}" />
                            @php $ap = is_array($sa->appreciation) ? ($sa->appreciation['fr'] ?? '') : (string) ($sa->appreciation ?? ''); @endphp
                            @if ($ap)
                                <div class="hidden text-xs italic mt-text-muted print:block">{{ $ap }}</div>
                            @endif
                        </td>
                        <td class="py-2 text-center font-semibold mt-text">{{ number_format((float) $sa->average, 2, ',', ' ') }}</td>
                        <td class="py-2 text-center mt-text-muted">{{ rtrim(rtrim((string) $sa->coefficient, '0'), '.') }}</td>
                        <td class="py-2 text-center mt-text">{{ number_format((float) $sa->weighted_average, 2, ',', ' ') }}</td>
                        <td class="py-2 text-center mt-text-muted">{{ $sa->rank }}<span class="text-xs">e</span></td>
                        <td class="py-2 text-center mt-text-muted">{{ $sa->class_average !== null ? number_format((float) $sa->class_average, 2, ',', ' ') : '—' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="py-6 text-center mt-text-muted">{{ __('mtschool::report_card.no_averages') }}</td></tr>
                @endforelse
            </tbody>
            @if($periodAverage)
                <tfoot>
                    <tr style="border-top: 2px solid rgb(var(--mt-ui-card-border))">
                        <td class="py-2 font-bold mt-text">{{ __('mtschool::report_card.total') }}</td>
                        <td></td>
                        <td class="py-2 text-center font-bold mt-text">{{ rtrim(rtrim((string) $periodAverage->total_coefficients, '0'), '.') }}</td>
                        <td class="py-2 text-center font-bold mt-text">{{ number_format((float) $periodAverage->total_points, 2, ',', ' ') }}</td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
            @endif
        </table>

        {{-- Synthèse --}}
        @if($periodAverage)
            <div class="mt-5 flex flex-col gap-3 sm:flex-row sm:items-stretch">
                <div class="flex-1 rounded-xl p-4 text-center" style="background: rgba(var(--mt-primary),0.1)">
                    <div class="text-3xl font-bold mt-text-primary">{{ number_format((float) $periodAverage->overall_average, 2, ',', ' ') }}</div>
                    <div class="mt-text-muted text-xs">{{ __('mtschool::report_card.overall_average') }}</div>
                </div>
                <div class="flex-1 rounded-xl p-4 text-center" style="background: rgba(var(--mt-info),0.1)">
                    <div class="text-3xl font-bold" style="color: rgb(var(--mt-info))">{{ $periodAverage->rank }}<span class="text-lg">/{{ $periodAverage->class_size }}</span></div>
                    <div class="mt-text-muted text-xs">{{ __('mtschool::report_card.rank') }}</div>
                </div>
                @if($periodAverage->mention)
                    <div class="flex-1 rounded-xl p-4 text-center"
                         style="background: rgba(var(--mt-{{ $periodAverage->mention->badge() }}),0.12)">
                        <div class="text-xl font-bold" style="color: rgb(var(--mt-{{ $periodAverage->mention->badge() }}))">{{ $periodAverage->mention->label() }}</div>
                        <div class="mt-text-muted text-xs">{{ __('mtschool::report_card.mention') }}</div>
                    </div>
                @endif
            </div>
            <div class="mt-3 grid grid-cols-3 gap-3 text-center text-xs mt-text-muted">
                <div>{{ __('mtschool::report_card.class_average') }} : <span class="font-semibold mt-text">{{ number_format((float) $periodAverage->class_average, 2, ',', ' ') }}</span></div>
                <div>{{ __('mtschool::report_card.class_max') }} : <span class="font-semibold mt-text">{{ number_format((float) $periodAverage->class_max_average, 2, ',', ' ') }}</span></div>
                <div>{{ __('mtschool::report_card.class_min') }} : <span class="font-semibold mt-text">{{ number_format((float) $periodAverage->class_min_average, 2, ',', ' ') }}</span></div>
            </div>

            {{-- Assiduité --}}
            <div class="mt-3 grid grid-cols-3 gap-3 text-center text-xs mt-text-muted">
                <div>{{ __('mtschool::report_card.justified_absences') }} : <span class="font-semibold mt-text">{{ (int) $periodAverage->justified_absences }}</span></div>
                <div>{{ __('mtschool::report_card.unjustified_absences') }} : <span class="font-semibold" style="color: rgb(var(--mt-danger))">{{ (int) $periodAverage->unjustified_absences }}</span></div>
                <div>{{ __('mtschool::report_card.tardiness') }} : <span class="font-semibold mt-text">{{ (int) $periodAverage->tardiness_count }}</span></div>
            </div>

            {{-- Appréciation générale + distinction du conseil --}}
            <div class="mt-6">
                <div class="mb-1 text-sm font-semibold mt-text">{{ __('mtschool::report_card.council_assessment') }}</div>

                {{-- Édition (masquée à l'impression) --}}
                <div class="space-y-3 print:hidden">
                    <x-mt::form.textarea wire:model="appreciation" rows="2"
                                         :placeholder="__('mtschool::report_card.general_placeholder')" />
                    <div class="flex flex-col gap-3 sm:flex-row sm:items-end">
                        <div class="grow">
                            <x-mt::form.select :label="__('mtschool::report_card.distinction')" wire:model="decision">
                                @foreach ($distinctions as $val => $lbl)
                                    <option value="{{ $val }}">{{ $lbl }}</option>
                                @endforeach
                            </x-mt::form.select>
                        </div>
                        <x-mt::button variant="secondary" size="sm" icon="check" wire:click="saveAppreciation">
                            {{ __('mtschool::report_card.save_appreciation') }}
                        </x-mt::button>
                    </div>
                    @if ($savedMessage)
                        <p class="text-xs" style="color: rgb(var(--mt-success))">{{ $savedMessage }}</p>
                    @endif
                </div>

                {{-- Rendu impression --}}
                <div class="hidden text-sm mt-text print:block">
                    <p>{{ $appreciation ?: '—' }}</p>
                    @if ($decision)
                        <p class="mt-2 font-semibold">{{ __('mtschool::report_card.distinction') }} : {{ $decision }}</p>
                    @endif
                </div>
            </div>
        @endif
    </div>
</div>
