{{-- Modale détail d'un devoir (consignes + rendus, lecture seule) — via extraPartials() du base-index. --}}
<x-mt::modal name="homework-detail" openEvent="open-homework-detail" :title="__('mtschool::pedagogy.sup_detail')" icon="clipboard-document-list" wire="detailId" maxWidth="2xl">
    @if ($this->detail)
        <div class="mb-3">
            <div class="font-semibold mt-text">{{ $this->detail->title }}</div>
            <div class="mt-text-muted mt-0.5 text-xs">
                {{ $this->detail->classroom?->code }} · {{ $this->detail->subject?->label }}
                · {{ $this->detail->teacher?->full_name }}
                · {{ __('mtschool::pedagogy.due_on', ['date' => $this->detail->submission_deadline?->format('d/m/Y H:i')]) }}
            </div>
        </div>

        @if ($this->detail->instructions)
            <div class="mb-4 rounded-xl p-3 text-sm mt-text" style="background: rgba(var(--mt-text),0.04)">
                {{ $this->detail->instructions }}
            </div>
        @endif

        @if ($this->detail->submissions->isEmpty())
            <p class="mt-text-muted py-4 text-center text-sm">{{ __('mtschool::pedagogy.sup_no_submissions') }}</p>
        @else
            <div class="overflow-hidden rounded-xl border" style="border-color: rgb(var(--mt-ui-card-border))">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="text-left text-[11px] uppercase mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                            <th class="px-3 py-2">{{ __('mtschool::academics.student_field') }}</th>
                            <th class="px-3 py-2">{{ __('mtschool::pedagogy.submitted_label') }}</th>
                            <th class="px-3 py-2">{{ __('mtschool::pedagogy.score') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($this->detail->submissions as $s)
                            <tr wire:key="sub-{{ $s->id }}" style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                <td class="px-3 py-2 mt-text">{{ $s->enrollment?->student?->full_name_reverse ?? $s->enrollment?->student?->full_name }}</td>
                                <td class="px-3 py-2 mt-text-muted whitespace-nowrap">
                                    {{ $s->submitted_at?->format('d/m/Y H:i') }}
                                    @if ($s->is_late)
                                        <x-mt::badge :label="__('mtschool::pedagogy.late')" variant="warning" class="ml-1 px-1.5 py-0.5 text-[10px]" />
                                    @endif
                                </td>
                                <td class="px-3 py-2 mt-text whitespace-nowrap">
                                    @if ($s->status === 'corrected' && $s->score !== null)
                                        {{ rtrim(rtrim((string) $s->score, '0'), '.') }} / {{ rtrim(rtrim((string) $this->detail->max_score, '0'), '.') }}
                                    @else
                                        <span class="mt-text-muted">—</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    @endif
</x-mt::modal>
