<div>
    <x-mt::screen
        :title="__('mtschool::structure.new_year_title')"
        :description="__('mtschool::structure.new_year_intro')"
        :breadcrumbs="[['label' => __('mtschool::structure.new_year_title')]]"
    >
        {{-- Fil des étapes --}}
        <div class="flex flex-wrap gap-2 mb-6">
            @foreach ([1 => 'new_year_step_target', 2 => 'new_year_step_clone', 3 => 'new_year_step_promote', 4 => 'new_year_step_activate'] as $i => $lbl)
                <span class="font-semibold text-xs rounded-full" style="padding:4px 12px;
                    background: {{ $step >= $i ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text),.06)' }};
                    color: {{ $step >= $i ? 'rgb(var(--mt-primary-content))' : 'rgba(var(--mt-text),.6)' }};">
                    {{ $i }}. {{ __('mtschool::structure.' . $lbl) }}
                </span>
            @endforeach
        </div>

        @if (session('success'))
            <div class="mb-4"><x-mt::alert type="success" :message="session('success')" dismissible /></div>
        @endif

        {{-- ÉTAPE 1 : année cible --}}
        @if ($step === 1)
            <div class="mb-4">
                <span class="mt-text-muted">{{ __('mtschool::structure.new_year_source') }} :</span>
                <strong>{{ $sourceYear?->code ?? '—' }}</strong>
            </div>
            <div class="flex flex-wrap gap-4">
                <div style="flex:1 1 12rem">
                    <x-mt::form.input
                        type="text"
                        :label="__('mtschool::structure.year_code_ph')"
                        wire:model="year_code"
                        placeholder="2029-2030"
                        :error="$errors->first('year_code')"
                    />
                </div>
                <div style="flex:1 1 12rem">
                    <x-mt::form.input
                        type="date"
                        :label="__('mtschool::structure.start_date')"
                        wire:model="start_date"
                        :error="$errors->first('start_date')"
                    />
                </div>
                <div style="flex:1 1 12rem">
                    <x-mt::form.input
                        type="date"
                        :label="__('mtschool::structure.end_date')"
                        wire:model="end_date"
                        :error="$errors->first('end_date')"
                    />
                </div>
            </div>
            <div class="mt-6 flex justify-end">
                <x-mt::button variant="primary" wire:click="createTarget">{{ __('mtschool::structure.new_year_create_continue') }}</x-mt::button>
            </div>
        @endif

        {{-- ÉTAPE 2 : clonage --}}
        @if ($step === 2)
            <p class="mb-3">{{ __('mtschool::structure.new_year_clone_intro', ['from' => $sourceYear?->code, 'to' => $targetYear?->code]) }}</p>
            <div class="flex flex-col gap-2 mb-6">
                @foreach (['classes' => 'classrooms', 'curricula' => 'curricula', 'fees' => 'nav_fees', 'periods' => 'periods', 'assignments' => 'nav_assignments'] as $key => $lbl)
                    <label class="flex items-center gap-2">
                        <input type="checkbox" wire:model="clone.{{ $key }}">
                        {{ __('mtschool::structure.new_year_clone_' . $key) }}
                    </label>
                @endforeach
            </div>
            <div class="flex justify-end">
                <x-mt::button variant="primary" wire:click="doClone" wire:loading.attr="disabled">{{ __('mtschool::structure.new_year_do_clone') }}</x-mt::button>
            </div>
        @endif

        {{-- ÉTAPE 3 : promotion --}}
        @if ($step === 3)
            @if (!empty($cloneCounts))
                <div class="mb-4 text-sm" style="padding:10px 14px; border-radius:8px; background:rgba(var(--mt-success),.12); color:rgb(var(--mt-success));">
                    {{ __('mtschool::structure.new_year_cloned', [
                        'classes' => $cloneCounts['classes'] ?? 0, 'curricula' => $cloneCounts['curricula'] ?? 0,
                        'fees' => $cloneCounts['fees'] ?? 0, 'periods' => $cloneCounts['periods'] ?? 0,
                        'assignments' => $cloneCounts['assignments'] ?? 0]) }}
                </div>
            @endif
            {{-- Résultats annuels : renseignent la décision recommandée (redouble si < seuil) --}}
            @if (!$resultsComputed)
                <div class="flex items-center justify-between gap-4 mb-4" style="padding:12px 14px; border-radius:8px; background:rgba(var(--mt-info),.10); border:1px solid rgba(var(--mt-info),.3);">
                    <span class="text-sm">{{ __('mtschool::structure.new_year_results_hint') }}</span>
                    <x-mt::button variant="secondary" wire:click="computeResults" wire:loading.attr="disabled" wire:target="computeResults" class="whitespace-nowrap">
                        <span wire:loading.remove wire:target="computeResults">{{ __('mtschool::structure.new_year_compute_results') }}</span>
                        <span wire:loading wire:target="computeResults">{{ __('mtschool::structure.new_year_computing') }}</span>
                    </x-mt::button>
                </div>
            @else
                <div class="mb-4 text-sm" style="padding:10px 14px; border-radius:8px; background:rgba(var(--mt-success),.12); color:rgb(var(--mt-success));">
                    {{ __('mtschool::structure.new_year_results_done', [
                        'classes' => $resultCounts['classes'] ?? 0, 'computed' => $resultCounts['computed'] ?? 0,
                        'promoted' => $resultCounts['promoted'] ?? 0, 'retained' => $resultCounts['retained'] ?? 0]) }}
                </div>
            @endif
            <p class="mb-3">{{ __('mtschool::structure.new_year_promote_intro', ['count' => count($plan)]) }}</p>
            <div class="w-full overflow-x-auto rounded-xl border" style="border-color:rgb(var(--mt-ui-card-border)); max-height:360px; overflow-y:auto;">
                <table class="w-full border-collapse text-xs">
                    <thead class="mt-text-muted">
                        <tr style="text-align:left;">
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::students.col_student') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::structure.new_year_from_class') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::structure.new_year_avg') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::structure.new_year_action') }}</th>
                            <th class="px-4 py-3 font-medium">{{ __('mtschool::structure.new_year_target_class') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach ($plan as $row)
                        <tr style="border-top:1px solid rgb(var(--mt-ui-card-border));">
                            <td class="px-4 py-3">{{ $row['student'] }}</td>
                            <td class="px-4 py-3">{{ $row['from_class'] ?? '—' }}</td>
                            <td class="px-4 py-3">
                                @if (!is_null($row['annual_average'] ?? null))
                                    <span @style([
                                        'font-weight:600',
                                        'color:rgb(var(--mt-danger))' => ($row['annual_result'] ?? null) === 'retained',
                                        'color:rgb(var(--mt-success))' => ($row['annual_result'] ?? null) === 'promoted',
                                    ])>{{ number_format((float) $row['annual_average'], 2) }}</span>
                                @else
                                    <span class="mt-text-muted">—</span>
                                @endif
                            </td>
                            <td class="px-4 py-3">
                                <select wire:model="actions.{{ $row['enrollment_id'] }}" class="mt-input" style="min-width:130px;">
                                    <option value="promote">{{ __('mtschool::structure.new_year_act_promote') }}</option>
                                    <option value="retain">{{ __('mtschool::structure.new_year_act_retain') }}</option>
                                    <option value="graduate">{{ __('mtschool::structure.new_year_act_graduate') }}</option>
                                    <option value="transfer">{{ __('mtschool::structure.new_year_act_transfer') }}</option>
                                </select>
                            </td>
                            <td class="px-4 py-3">{{ $row['target_class'] ?? '—' }}@if(!empty($row['target_class_new'])) <span class="mt-text-muted" style="font-size:11px;">({{ __('mtschool::structure.new_year_target_new') }})</span>@endif</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div class="mt-4 flex items-center justify-between gap-3 flex-wrap">
                <x-mt::form.toggle wire:model="carry_balances" label="{{ __('mtschool::structure.new_year_carry_balances') }}" />
                <x-mt::button variant="primary" wire:click="doPromote" wire:loading.attr="disabled">{{ __('mtschool::structure.new_year_do_promote') }}</x-mt::button>
            </div>
        @endif

        {{-- ÉTAPE 4 : activation --}}
        @if ($step === 4)
            <div class="mb-6" style="padding:14px; border-radius:8px; background:rgba(var(--mt-success),.12); color:rgb(var(--mt-success));">
                {{ __('mtschool::structure.new_year_promoted', [
                    'promoted' => $promoteCounts['promoted'] ?? 0, 'retained' => $promoteCounts['retained'] ?? 0,
                    'graduated' => $promoteCounts['graduated'] ?? 0, 'transferred' => $promoteCounts['transferred'] ?? 0]) }}
                @if (($promoteCounts['created_classes'] ?? 0) > 0)
                    <div style="margin-top:6px;">{{ __('mtschool::structure.new_year_created_classes', ['count' => $promoteCounts['created_classes']]) }}</div>
                @endif
                @if (($carryCounts['carried'] ?? 0) > 0)
                    <div style="margin-top:6px;">{{ __('mtschool::structure.new_year_carried', ['count' => $carryCounts['carried'], 'total' => number_format($carryCounts['total'] ?? 0, 0, ',', ' ')]) }}</div>
                @endif
            </div>
            <p class="mb-6">{{ __('mtschool::structure.new_year_activate_intro', ['year' => $targetYear?->code]) }}</p>
            <div class="flex justify-end">
                <x-mt::button variant="primary" wire:click="activateTarget">{{ __('mtschool::structure.new_year_activate', ['year' => $targetYear?->code]) }}</x-mt::button>
            </div>
        @endif
    </x-mt::screen>
</div>
