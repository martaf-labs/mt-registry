@php $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v; @endphp
<div>
    <x-mt::screen :title="__('mtschool::documents.certificates_title')" :description="__('mtschool::documents.certificates_subtitle')" :breadcrumbs="[['label' => __('mtschool::documents.certificates_title')]]">

        @if ($savedMessage)
            <div class="mb-4 rounded-lg px-4 py-3 text-sm"
                 style="background: rgba(var(--mt-success),0.12); color: rgb(var(--mt-success))">
                {{ $savedMessage }}
            </div>
        @endif

        {{-- Formulaire de délivrance --}}
        <div class="rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <form wire:submit="issue" class="grid grid-cols-1 gap-4 sm:grid-cols-4 sm:items-end">
                <x-mt::form.select label="{{ __('mtschool::documents.classroom') }}" wire:model.live="classId">
                    <option value="">—</option>
                    @foreach ($this->classes as $class)
                        <option value="{{ $class->id }}">{{ $class->code }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.select label="{{ __('mtschool::documents.student') }}" wire:model="enrollmentId" :error="$errors->first('enrollmentId')">
                    <option value="">{{ __('mtschool::documents.cert_choose_student') }}</option>
                    @foreach ($this->enrollments as $e)
                        <option value="{{ $e->id }}">{{ $e->name }}</option>
                    @endforeach
                </x-mt::form.select>
                <x-mt::form.select label="{{ __('mtschool::documents.cert_type') }}" wire:model="type">
                    @foreach ($this->types() as $t)
                        <option value="{{ $t }}">{{ __('mtschool::documents.cert_title_' . $t) }}</option>
                    @endforeach
                </x-mt::form.select>
                <div>
                    <x-mt::button type="submit" variant="primary" icon="document-check" class="w-full">
                        {{ __('mtschool::documents.cert_issue') }}
                    </x-mt::button>
                </div>
            </form>
        </div>

        {{-- Certificats délivrés --}}
        <div class="mt-6">
            <div class="mb-2 text-xs font-semibold mt-text-muted uppercase tracking-wide">{{ __('mtschool::documents.cert_issued_list') }}</div>
            @if ($this->certificates->isEmpty())
                <x-mt::empty-state icon="document-text" :title="__('mtschool::documents.cert_none')" />
            @else
                <div class="w-full overflow-x-auto rounded-xl border"
                     style="border-color: rgb(var(--mt-ui-card-border))">
                    <table class="w-full border-collapse text-xs">
                        <thead>
                            <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                                <th class="px-4 py-3 font-medium">{{ __('mtschool::documents.cert_reference') }}</th>
                                <th class="px-4 py-3 font-medium">{{ __('mtschool::documents.student') }}</th>
                                <th class="px-4 py-3 font-medium">{{ __('mtschool::documents.cert_type') }}</th>
                                <th class="px-4 py-3 font-medium">{{ __('mtschool::documents.cert_issued_on') }}</th>
                                <th class="px-4 py-3 font-medium text-right"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($this->certificates as $c)
                                <tr wire:key="cert-{{ $c->id }}" class="transition-colors"
                                    style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)"
                                    onmouseover="this.style.background='rgba(var(--mt-text),0.03)'" onmouseout="this.style.background=''">
                                    <td class="px-4 py-3 text-xs mt-text-muted">{{ $c->ref }}</td>
                                    <td class="px-4 py-3 text-sm mt-text">{{ $c->student }}</td>
                                    <td class="px-4 py-3 text-sm mt-text">{{ __('mtschool::documents.cert_title_' . $c->type) }}</td>
                                    <td class="px-4 py-3 text-sm mt-text-muted">{{ optional($c->issued)->format('d/m/Y') }}</td>
                                    <td class="px-4 py-3 text-right">
                                        <a href="{{ mt_get_route('certificates_pdf', ['certificate' => $c->id]) }}" target="_blank">
                                            <x-mt::button variant="secondary" size="sm" icon="document-text">PDF</x-mt::button>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </x-mt::screen>
</div>
