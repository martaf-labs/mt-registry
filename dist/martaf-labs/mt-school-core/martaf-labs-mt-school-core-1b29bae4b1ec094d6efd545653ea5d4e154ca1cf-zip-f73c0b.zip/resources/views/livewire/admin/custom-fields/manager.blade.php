<div>
    <x-mt::screen :title="__('mtschool::custom_fields.title')" :description="__('mtschool::custom_fields.subtitle')" :breadcrumbs="[['label' => __('mtschool::custom_fields.title')]]" width="5xl">
        <x-slot:actions>
            <x-mt::help key="custom_fields.intro" />
            <button type="button" x-data @click="$dispatch('start-tour', { name: 'custom-fields' })"
                    class="inline-flex items-center gap-1 text-xs mt-text-muted hover:mt-text-primary transition">
                <x-mt::icon name="question-circle" /> {{ __('mtschool::custom_fields.review_guide') }}
            </button>
            <x-mt::button id="cf-new-group" variant="secondary" size="sm" icon="folder" wire:click="createGroup">
                {{ __('mtschool::custom_fields.new_group') }}
            </x-mt::button>
            <x-mt::button id="cf-new-field" variant="primary" size="sm" icon="plus" wire:click="createField">
                {{ __('mtschool::custom_fields.new_field') }}
            </x-mt::button>
        </x-slot:actions>

        {{-- Messages --}}
        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif
        @if ($errorMessage)
            <div class="mb-4"><x-mt::alert type="danger" :message="$errorMessage" dismissible /></div>
        @endif

        {{-- Onglets : type d'entité --}}
        <div id="cf-tabs" class="mb-6 flex flex-wrap gap-2 border-b" style="border-color: rgb(var(--mt-ui-card-border))">
            @foreach ($this->entities as $entity)
                <button type="button" wire:click="setEntity('{{ $entity['key'] }}')"
                        @class([
                            'relative -mb-px px-4 py-2 text-sm font-medium transition',
                            'mt-text border-b-2' => $entityType === $entity['key'],
                            'mt-text-muted border-b-2 border-transparent hover:mt-text' => $entityType !== $entity['key'],
                        ])
                        @style(['border-color: rgb(var(--mt-primary))' => $entityType === $entity['key']])>
                    {{ $entity['label'] }}
                </button>
            @endforeach
        </div>

        {{-- Groupes + champs --}}
        <div class="space-y-5">

            @forelse ($this->groups as $group)
                <div class="rounded-2xl border"
                     style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                    <div class="flex items-center justify-between gap-3 px-5 py-3"
                         style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                        <div class="flex items-center gap-2 min-w-0">
                            <span class="mt-text-primary"><x-mt::icon name="folder" /></span>
                            <h3 class="truncate text-sm font-semibold mt-text">{{ $group->name }}</h3>
                            <span class="mt-text-muted text-xs">{{ __('mtschool::custom_fields.field_count', ['n' => $group->fields->count()]) }}</span>
                        </div>
                        <div class="flex items-center gap-1">
                            <x-mt::button variant="ghost" size="sm" icon="plus" wire:click="createField({{ $group->id }})" />
                            <x-mt::button variant="ghost" size="sm" icon="pencil" wire:click="editGroup({{ $group->id }})" />
                            <x-mt::button variant="ghost" size="sm" icon="trash"
                                          wire:click="deleteGroup({{ $group->id }})"
                                          wire:confirm="{{ __('mtschool::custom_fields.confirm_delete_group') }}" />
                        </div>
                    </div>
                    @include('mtschool::livewire.admin.custom-fields.partials.fields-table', ['fields' => $group->fields])
                </div>
            @empty
            @endforelse

            {{-- Champs sans groupe --}}
            <div class="rounded-2xl border"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <div class="flex items-center justify-between gap-3 px-5 py-3"
                     style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                    <h3 class="text-sm font-semibold mt-text">{{ __('mtschool::custom_fields.ungrouped_fields') }}</h3>
                    <span class="mt-text-muted text-xs">{{ __('mtschool::custom_fields.field_count', ['n' => $this->ungroupedFields->count()]) }}</span>
                </div>
                @if ($this->ungroupedFields->isEmpty() && $this->groups->isEmpty())
                    <x-mt::empty-state icon="adjustments-horizontal" :title="__('mtschool::custom_fields.no_custom_fields')">
                        <x-mt::button variant="primary" size="sm" icon="plus" wire:click="createField">
                            {{ __('mtschool::custom_fields.create_first_field') }}
                        </x-mt::button>
                    </x-mt::empty-state>
                @else
                    @include('mtschool::livewire.admin.custom-fields.partials.fields-table', ['fields' => $this->ungroupedFields])
                @endif
            </div>
        </div>

        {{-- ─────────── Modale CHAMP ─────────── --}}
        <x-mt::modal name="custom-field" openEvent="open-custom-field-modal" maxWidth="lg"
                     :title="$editingFieldId ? __('mtschool::custom_fields.edit_field') : __('mtschool::custom_fields.new_field_modal')" icon="tag"
                     wire="showFieldModal">
            <form wire:submit="saveField" class="space-y-4">
                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <x-mt::form.input label="{{ __('mtschool::custom_fields.label_field') }}" model="fieldForm.label" required
                                      :error="$errors->first('fieldForm.label')" />
                    <div>
                        <div class="mb-1 flex items-center gap-1.5">
                            <span class="text-sm font-medium mt-text">{{ __('mtschool::custom_fields.technical_key') }}</span>
                            <x-mt::help key="custom_fields.key" size="sm" />
                        </div>
                        <x-mt::form.input model="fieldForm.key"
                                          help="{{ __('mtschool::custom_fields.key_help') }}"
                                          :error="$errors->first('fieldForm.key')" />
                    </div>
                </div>

                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <x-mt::form.select label="{{ __('mtschool::custom_fields.type') }}" wire:model.live="fieldForm.type"
                                       :error="$errors->first('fieldForm.type')">
                        @foreach ($this->fieldTypes as $value => $label)
                            <option value="{{ $value }}">{{ $label }}</option>
                        @endforeach
                    </x-mt::form.select>

                    <x-mt::form.select label="{{ __('mtschool::custom_fields.group') }}" model="fieldForm.group_id">
                        <option value="">{{ __('mtschool::custom_fields.no_group') }}</option>
                        @foreach ($this->groupOptions as $id => $name)
                            <option value="{{ $id }}">{{ $name }}</option>
                        @endforeach
                    </x-mt::form.select>
                </div>

                {{-- Éditeur d'options (types à choix) --}}
                @php $isOption = in_array($fieldForm['type'], ['select', 'multiselect'], true); @endphp
                @if ($isOption)
                    <div class="rounded-xl border p-3" style="border-color: rgb(var(--mt-ui-card-border))">
                        <div class="mb-2 flex items-center justify-between">
                            <span class="text-sm font-medium mt-text">{{ __('mtschool::custom_fields.options') }}</span>
                            <x-mt::button variant="ghost" size="sm" icon="plus" wire:click="addOption" type="button">
                                {{ __('mtschool::custom_fields.add') }}
                            </x-mt::button>
                        </div>
                        @error('fieldForm.options')
                            <p class="mb-2 text-xs" style="color: rgb(var(--mt-danger))">{{ $message }}</p>
                        @enderror
                        <div class="space-y-2">
                            @forelse ($fieldForm['options'] as $i => $opt)
                                <div class="flex items-center gap-2" wire:key="opt-{{ $i }}">
                                    <input type="text" class="mt-input mt-input-sm flex-1"
                                           placeholder="{{ __('mtschool::custom_fields.option_label_ph') }}" wire:model="fieldForm.options.{{ $i }}.label" />
                                    <input type="text" class="mt-input mt-input-sm w-40"
                                           placeholder="{{ __('mtschool::custom_fields.option_value_ph') }}" wire:model="fieldForm.options.{{ $i }}.value" />
                                    <x-mt::button variant="ghost" size="sm" icon="trash"
                                                  wire:click="removeOption({{ $i }})" type="button" />
                                </div>
                            @empty
                                <p class="mt-text-muted text-xs">{{ __('mtschool::custom_fields.no_options') }}</p>
                            @endforelse
                        </div>
                    </div>
                @endif

                <x-mt::form.textarea label="{{ __('mtschool::custom_fields.help_optional') }}" model="fieldForm.help" rows="2" />

                <div class="flex items-center gap-6">
                    <x-mt::form.toggle label="{{ __('mtschool::custom_fields.required_toggle') }}" model="fieldForm.required" />
                    <x-mt::form.toggle label="{{ __('mtschool::custom_fields.active_toggle') }}" model="fieldForm.active" />
                </div>
            </form>

            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'custom-field' })">
                    {{ __('mtschool::common.cancel') }}
                </x-mt::button>
                <x-mt::button variant="primary" wire:click="saveField" icon="check">
                    {{ $editingFieldId ? __('mtschool::common.save') : __('mtschool::custom_fields.add') }}
                </x-mt::button>
            </x-slot:footer>
        </x-mt::modal>

        {{-- ─────────── Modale GROUPE ─────────── --}}
        <x-mt::modal name="custom-field-group" openEvent="open-custom-field-group-modal" maxWidth="md"
                     :title="$editingGroupId ? __('mtschool::custom_fields.edit_group') : __('mtschool::custom_fields.new_group_modal')" icon="folder"
                     wire="showGroupModal">
            <form wire:submit="saveGroup" class="space-y-4">
                <x-mt::form.input label="{{ __('mtschool::custom_fields.group_name') }}" model="groupForm.name" required
                                  :error="$errors->first('groupForm.name')" />
                <x-mt::form.textarea label="{{ __('mtschool::custom_fields.description_optional') }}" model="groupForm.description" rows="2" />
            </form>
            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'custom-field-group' })">
                    {{ __('mtschool::common.cancel') }}
                </x-mt::button>
                <x-mt::button variant="primary" wire:click="saveGroup" icon="check">
                    {{ $editingGroupId ? __('mtschool::common.save') : __('mtschool::custom_fields.add') }}
                </x-mt::button>
            </x-slot:footer>
        </x-mt::modal>

        {{-- Visite guidée (config/tours.php → 'custom-fields') --}}
        <x-mt::tour name="custom-fields" />
    </x-mt::screen>
</div>
