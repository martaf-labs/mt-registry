<div>
    <x-mt::screen :title="__('mtschool::pedagogy.parent_title')" :description="__('mtschool::pedagogy.parent_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_children'), 'lien' => mt_get_route('parent_home')], ['label' => __('mtschool::pedagogy.parent_title')]]" width="2xl">

        @forelse ($this->children as $child)
            <div class="mb-6">
                <div class="mb-2 flex items-center gap-2">
                    <span class="font-semibold mt-text">{{ $child->student->full_name ?? $child->student->last_name }}</span>
                    @if ($child->class)
                        <span class="mt-text-muted text-xs">· {{ $child->class }}</span>
                    @endif
                </div>

                @if ($child->homeworks->isEmpty())
                    <div class="rounded-2xl border px-5 py-6 text-center"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <p class="mt-text-muted text-sm">{{ __('mtschool::pedagogy.no_current_homework') }}</p>
                    </div>
                @else
                    <div class="overflow-hidden rounded-2xl border"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="divide-y">
                            @foreach ($child->homeworks as $hw)
                                <div class="flex items-center justify-between gap-3 px-4 py-3"
                                     style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)">
                                    <div class="min-w-0">
                                        <div class="truncate font-medium mt-text">{{ $hw->title }}</div>
                                        <div class="mt-text-muted text-xs">
                                            {{ $hw->subject }} · {{ $hw->deadline?->format('d/m/Y') }}
                                        </div>
                                    </div>
                                    <div class="shrink-0">
                                        @if ($hw->is_graded && $hw->score !== null)
                                            <span class="rounded-full px-2 py-0.5 text-xs"
                                                  style="background: rgba(var(--mt-success),0.15); color: rgb(var(--mt-success))">
                                                {{ rtrim(rtrim((string) $hw->score, '0'), '.') }}/{{ rtrim(rtrim((string) $hw->max_score, '0'), '.') }}
                                            </span>
                                        @elseif ($hw->submitted)
                                            <span class="rounded-full px-2 py-0.5 text-xs"
                                                  style="background: rgba(var(--mt-info),0.15); color: rgb(var(--mt-info))">{{ __('mtschool::pedagogy.status_submitted') }}</span>
                                        @elseif ($hw->expired)
                                            <span class="rounded-full px-2 py-0.5 text-xs"
                                                  style="background: rgba(var(--mt-danger),0.15); color: rgb(var(--mt-danger))">{{ __('mtschool::pedagogy.status_missing') }}</span>
                                        @else
                                            <span class="rounded-full px-2 py-0.5 text-xs"
                                                  style="background: rgba(var(--mt-warning),0.15); color: rgb(var(--mt-warning))">{{ __('mtschool::pedagogy.status_todo') }}</span>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif
            </div>
        @empty
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::pedagogy.no_child') }}</p>
            </div>
        @endforelse
    </x-mt::screen>
</div>
