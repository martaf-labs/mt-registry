@php
    $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v;
@endphp
<div>
    <x-mt::screen :title="__('mtschool::portal.report_cards_title')" :description="__('mtschool::portal.report_cards_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.report_cards_title')]]" width="4xl">

        @if ($this->children->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_children') }}</p>
            </div>
        @else
            <div class="flex flex-col gap-5">
                @foreach ($this->children as $c)
                    <div class="rounded-2xl border p-5"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">

                        {{-- En-tête enfant --}}
                        <div class="flex items-center gap-3">
                            <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold"
                                 style="background: rgba(var(--mt-primary),0.15); color: rgb(var(--mt-primary))">
                                {{ mb_substr($c->student->first_name ?? '', 0, 1) }}{{ mb_substr($c->student->last_name ?? '', 0, 1) }}
                            </div>
                            <div class="min-w-0">
                                <div class="truncate font-semibold mt-text">{{ $c->student->full_name_reverse ?? $c->student->full_name }}</div>
                                <div class="mt-text-muted text-xs">{{ $loc($c->class) ?: __('mtschool::portal.not_enrolled_year') }}</div>
                            </div>
                        </div>

                        @if (! $c->enrollment_id)
                            <p class="mt-text-muted mt-4 text-sm">{{ __('mtschool::portal.not_enrolled_year') }}</p>
                        @else
                            {{-- Bulletins de période --}}
                            @if ($c->periods->isNotEmpty())
                                <div class="mt-4 flex flex-col gap-2">
                                    @foreach ($c->periods as $p)
                                        <div class="flex items-center justify-between rounded-lg px-3 py-2"
                                             style="background: rgba(var(--mt-primary),0.05)">
                                            <div class="min-w-0">
                                                <div class="font-medium mt-text">{{ $loc($p->period) }}</div>
                                                @if ($p->published_at)
                                                    <div class="mt-text-muted text-xs">{{ __('mtschool::portal.published_on') }} {{ optional($p->published_at)->format('d/m/Y') }}</div>
                                                @endif
                                            </div>
                                            <a href="{{ mt_get_route('parent_bulletin', ['enrollment' => $c->enrollment_id, 'period' => $p->period_id]) }}" target="_blank">
                                                <x-mt::button variant="primary" size="sm" icon="document-text">{{ __('mtschool::portal.download') }}</x-mt::button>
                                            </a>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <p class="mt-text-muted mt-4 text-sm">{{ __('mtschool::portal.no_report_cards') }}</p>
                            @endif

                            {{-- Bulletin annuel --}}
                            @if ($c->annual)
                                <div class="mt-4 rounded-xl border p-4"
                                     style="border-color: rgb(var(--mt-primary) / .3); background: rgba(var(--mt-primary),0.06)">
                                    <div class="flex items-center justify-between gap-3">
                                        <div>
                                            <div class="font-semibold mt-text">{{ __('mtschool::portal.annual_report_card') }}</div>
                                            <div class="mt-text-muted mt-0.5 text-xs">
                                                {{ __('mtschool::portal.annual_average') }} : <strong class="mt-text">{{ number_format($c->annual->average, 2, ',', ' ') }}</strong>
                                                @if ($c->annual->rank) · {{ __('mtschool::portal.rank') }} {{ $c->annual->rank }} @endif
                                                @if ($c->annual->result) · {{ $c->annual->result }} @endif
                                            </div>
                                        </div>
                                        <a href="{{ mt_get_route('parent_annual_bulletin', ['enrollment' => $c->enrollment_id, 'year' => $c->year_id]) }}" target="_blank">
                                            <x-mt::button variant="secondary" size="sm" icon="document-text">{{ __('mtschool::portal.download') }}</x-mt::button>
                                        </a>
                                    </div>
                                </div>
                            @endif
                        @endif
                    </div>
                @endforeach
            </div>
        @endif
    </x-mt::screen>
</div>
