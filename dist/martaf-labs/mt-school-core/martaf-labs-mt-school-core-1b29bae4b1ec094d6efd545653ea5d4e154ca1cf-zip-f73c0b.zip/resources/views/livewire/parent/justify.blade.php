@php
    $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v;
    $stColor = ['pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger'];
@endphp
<div>
    <x-mt::screen :title="__('mtschool::portal.justify_title')" :description="__('mtschool::portal.justify_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.justify_title')]]" width="3xl">

        @if ($savedMessage)
            <div class="mb-4 rounded-lg px-4 py-3 text-sm"
                 style="background: rgba(var(--mt-success),0.12); color: rgb(var(--mt-success))">
                {{ $savedMessage }}
            </div>
        @endif

        {{-- Formulaire de dépôt --}}
        <div class="rounded-2xl border p-5"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            @if ($this->children->isEmpty())
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_children') }}</p>
            @else
                <form wire:submit="submit" class="flex flex-col gap-4">
                    <x-mt::form.select label="{{ __('mtschool::portal.child') }}" wire:model="studentId" :error="$errors->first('studentId')">
                        <option value="">{{ __('mtschool::portal.choose_child') }}</option>
                        @foreach ($this->children as $child)
                            <option value="{{ $child->id }}">{{ $child->name }}</option>
                        @endforeach
                    </x-mt::form.select>

                    <div class="grid grid-cols-2 gap-3">
                        <x-mt::form.date-picker label="{{ __('mtschool::portal.from_date') }}" model="start_date" :error="$errors->first('start_date')" />
                        <x-mt::form.date-picker label="{{ __('mtschool::portal.to_date') }}" model="end_date" :error="$errors->first('end_date')" />
                    </div>

                    <x-mt::form.select label="{{ __('mtschool::portal.reason') }}" wire:model="reason">
                        @foreach ($reasons as $r)
                            <option value="{{ $r }}">{{ __('mtschool::portal.reason_' . $r) }}</option>
                        @endforeach
                    </x-mt::form.select>

                    <x-mt::form.textarea label="{{ __('mtschool::portal.details') }}" model="reason_details"
                                         rows="2" placeholder="{{ __('mtschool::portal.details_placeholder') }}"
                                         :error="$errors->first('reason_details')" />

                    <div>
                        <label class="mb-1 block text-sm font-medium mt-text">{{ __('mtschool::portal.document') }} <span class="mt-text-muted">({{ __('mtschool::portal.optional') }})</span></label>
                        <input type="file" wire:model="document" class="mt-input w-full">
                        <div wire:loading wire:target="document" class="mt-1 text-xs mt-text-muted">{{ __('mtschool::portal.uploading') }}</div>
                        @error('document') <span class="text-xs" style="color: rgb(var(--mt-danger))">{{ $message }}</span> @enderror
                    </div>

                    <div class="flex justify-end">
                        <x-mt::button type="submit" variant="primary" icon="paper-airplane" wire:loading.attr="disabled" wire:target="submit">
                            {{ __('mtschool::portal.submit_justification') }}
                        </x-mt::button>
                    </div>
                </form>
            @endif
        </div>

        {{-- Historique des dépôts --}}
        @if ($this->justifications->isNotEmpty())
            <div class="mt-6">
                <div class="mb-2 text-xs font-semibold mt-text-muted uppercase tracking-wide">{{ __('mtschool::portal.my_justifications') }}</div>
                <div class="flex flex-col gap-2">
                    @foreach ($this->justifications as $j)
                        <div class="rounded-xl border p-4"
                             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                            <div class="flex items-center justify-between gap-2">
                                <div class="min-w-0">
                                    <div class="font-medium mt-text">{{ $j->student }}</div>
                                    <div class="mt-text-muted text-xs">
                                        {{ optional($j->start)->format('d/m/Y') }} → {{ optional($j->end)->format('d/m/Y') }}
                                        · {{ __('mtschool::portal.reason_' . $j->reason) }}
                                        @if ($j->has_doc) · <span class="mt-text-muted">📎</span> @endif
                                    </div>
                                </div>
                                <span class="shrink-0 rounded-full px-2.5 py-0.5 text-[11px] font-medium"
                                      style="background: rgba(var(--mt-{{ $stColor[$j->status] ?? 'muted' }}),0.15); color: rgb(var(--mt-{{ $stColor[$j->status] ?? 'muted' }}))">
                                    {{ __('mtschool::portal.justif_' . $j->status) }}
                                </span>
                            </div>
                            @if ($j->status === 'rejected' && $loc($j->rejection))
                                <div class="mt-2 text-xs" style="color: rgb(var(--mt-danger))">
                                    {{ __('mtschool::portal.rejection_reason') }} : {{ $loc($j->rejection) }}
                                </div>
                            @endif
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </x-mt::screen>
</div>
