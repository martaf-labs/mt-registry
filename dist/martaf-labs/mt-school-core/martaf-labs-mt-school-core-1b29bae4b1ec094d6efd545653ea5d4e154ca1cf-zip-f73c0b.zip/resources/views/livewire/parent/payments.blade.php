@php
    $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v;
    $statusColor = ['paid' => 'success', 'partial' => 'warning', 'pending' => 'danger', 'exempt' => 'info', 'none' => 'muted'];
    $instColor   = ['paid' => 'success', 'overdue' => 'danger', 'pending' => 'warning'];
@endphp
<div>
    <x-mt::screen :title="__('mtschool::portal.fees_title')" :description="__('mtschool::portal.fees_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.fees_title')]]" width="4xl">

        @if ($this->children->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_children') }}</p>
            </div>
        @else
            <div class="flex flex-col gap-5">
                @foreach ($this->children as $c)
                    <div class="rounded-2xl border p-5"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">

                        {{-- En-tête enfant --}}
                        <div class="flex items-center justify-between gap-3">
                            <div class="flex items-center gap-3 min-w-0">
                                <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold"
                                     style="background: rgba(var(--mt-primary),0.15); color: rgb(var(--mt-primary))">
                                    {{ mb_substr($c->student->first_name ?? '', 0, 1) }}{{ mb_substr($c->student->last_name ?? '', 0, 1) }}
                                </div>
                                <div class="min-w-0">
                                    <div class="truncate font-semibold mt-text">{{ $c->student->full_name_reverse ?? $c->student->full_name }}</div>
                                    <div class="mt-text-muted text-xs">{{ $loc($c->class) ?: __('mtschool::portal.not_enrolled_year') }}</div>
                                </div>
                            </div>
                            @if ($c->enrollment_id)
                                <a href="{{ mt_get_route('parent_statement', ['enrollment' => $c->enrollment_id]) }}" target="_blank">
                                    <x-mt::button variant="secondary" size="sm" icon="document-text">{{ __('mtschool::portal.download_statement') }}</x-mt::button>
                                </a>
                            @endif
                        </div>

                        @if (! $c->enrollment_id)
                            <p class="mt-text-muted mt-4 text-sm">{{ __('mtschool::portal.not_enrolled_year') }}</p>
                        @else
                            {{-- Synthèse --}}
                            <div class="mt-4 grid grid-cols-3 gap-3">
                                <div class="rounded-xl p-3 text-center" style="background: rgba(var(--mt-primary),0.08)">
                                    <div class="text-base font-bold mt-text">{{ number_format($c->total_net, 0, ',', ' ') }}</div>
                                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.total_billed') }}</div>
                                </div>
                                <div class="rounded-xl p-3 text-center" style="background: rgba(var(--mt-success),0.1)">
                                    <div class="text-base font-bold" style="color: rgb(var(--mt-success))">{{ number_format($c->total_paid, 0, ',', ' ') }}</div>
                                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.total_paid') }}</div>
                                </div>
                                <div class="rounded-xl p-3 text-center"
                                     style="background: rgba(var(--mt-{{ $c->total_remaining > 0 ? 'danger' : 'success' }}),0.1)">
                                    <div class="text-base font-bold" style="color: rgb(var(--mt-{{ $c->total_remaining > 0 ? 'danger' : 'success' }}))">
                                        {{ number_format($c->total_remaining, 0, ',', ' ') }}
                                    </div>
                                    <div class="text-[11px] mt-text-muted">{{ $c->total_remaining > 0 ? __('mtschool::portal.remaining_to_pay') : __('mtschool::portal.up_to_date') }}</div>
                                </div>
                            </div>

                            {{-- Détail des frais --}}
                            @if ($c->fees->isNotEmpty())
                                <div class="mt-5 overflow-x-auto">
                                    <table class="w-full text-sm" style="border-collapse: collapse;">
                                        <thead>
                                            <tr class="mt-text-muted text-left text-xs">
                                                <th class="py-2 pr-2">{{ __('mtschool::portal.fee_type') }}</th>
                                                <th class="py-2 px-2 text-right">{{ __('mtschool::portal.total_billed') }}</th>
                                                <th class="py-2 px-2 text-right">{{ __('mtschool::portal.total_paid') }}</th>
                                                <th class="py-2 px-2 text-right">{{ __('mtschool::portal.remaining_to_pay') }}</th>
                                                <th class="py-2 pl-2 text-right">{{ __('mtschool::portal.status') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($c->fees as $f)
                                                <tr style="border-top: 1px solid rgb(var(--mt-ui-card-border));">
                                                    <td class="py-2 pr-2 mt-text">{{ $loc($f->type) }}</td>
                                                    <td class="py-2 px-2 text-right mt-text">{{ number_format($f->net, 0, ',', ' ') }}</td>
                                                    <td class="py-2 px-2 text-right mt-text">{{ number_format($f->paid, 0, ',', ' ') }}</td>
                                                    <td class="py-2 px-2 text-right mt-text">{{ number_format($f->remaining, 0, ',', ' ') }}</td>
                                                    <td class="py-2 pl-2 text-right">
                                                        <span class="rounded-full px-2 py-0.5 text-[11px] font-medium"
                                                              style="background: rgba(var(--mt-{{ $statusColor[$f->status] ?? 'muted' }}),0.15); color: rgb(var(--mt-{{ $statusColor[$f->status] ?? 'muted' }}))">
                                                            {{ __('mtschool::portal.fee_status_' . $f->status) }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <p class="mt-text-muted mt-4 text-sm">{{ __('mtschool::portal.no_fees') }}</p>
                            @endif

                            {{-- Échéancier --}}
                            @if ($c->installments->isNotEmpty())
                                <div class="mt-5">
                                    <div class="mb-2 text-xs font-semibold mt-text-muted uppercase tracking-wide">{{ __('mtschool::portal.installments') }}</div>
                                    <div class="flex flex-col gap-1.5">
                                        @foreach ($c->installments as $i)
                                            <div class="flex items-center justify-between rounded-lg px-3 py-2 text-sm"
                                                 style="background: rgba(var(--mt-{{ $instColor[$i->status] ?? 'muted' }}),0.08)">
                                                <span class="mt-text">{{ $loc($i->label) }}</span>
                                                <div class="flex items-center gap-3">
                                                    <span class="mt-text-muted text-xs">{{ optional($i->due_date)->format('d/m/Y') }}</span>
                                                    <span class="mt-text font-medium">{{ number_format($i->amount, 0, ',', ' ') }}</span>
                                                    <span class="rounded-full px-2 py-0.5 text-[11px] font-medium"
                                                          style="background: rgba(var(--mt-{{ $instColor[$i->status] ?? 'muted' }}),0.18); color: rgb(var(--mt-{{ $instColor[$i->status] ?? 'muted' }}))">
                                                        {{ __('mtschool::portal.installment_' . $i->status) }}
                                                    </span>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @endif

                            {{-- Historique des paiements --}}
                            @if ($c->payments->isNotEmpty())
                                <div class="mt-5">
                                    <div class="mb-2 text-xs font-semibold mt-text-muted uppercase tracking-wide">{{ __('mtschool::portal.payment_history') }}</div>
                                    <div class="overflow-x-auto">
                                        <table class="w-full text-sm" style="border-collapse: collapse;">
                                            <thead>
                                                <tr class="mt-text-muted text-left text-xs">
                                                    <th class="py-1.5 pr-2">{{ __('mtschool::portal.date') }}</th>
                                                    <th class="py-1.5 px-2">{{ __('mtschool::portal.method') }}</th>
                                                    <th class="py-1.5 px-2">{{ __('mtschool::portal.reference') }}</th>
                                                    <th class="py-1.5 pl-2 text-right">{{ __('mtschool::portal.amount') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($c->payments as $p)
                                                    <tr style="border-top: 1px solid rgb(var(--mt-ui-card-border));">
                                                        <td class="py-1.5 pr-2 mt-text-muted">{{ optional($p->date)->format('d/m/Y') }}</td>
                                                        <td class="py-1.5 px-2 mt-text">{{ $p->method }}</td>
                                                        <td class="py-1.5 px-2 mt-text-muted text-xs">{{ $p->reference }}</td>
                                                        <td class="py-1.5 pl-2 text-right mt-text font-medium">{{ number_format($p->amount, 0, ',', ' ') }}</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            @endif
                        @endif
                    </div>
                @endforeach
            </div>
        @endif
    </x-mt::screen>
</div>
