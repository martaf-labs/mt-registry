<div>
    <x-mt::screen :title="__('mtschool::portal.my_children')" :description="__('mtschool::portal.children_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_children')]]" width="4xl">

        @if ($this->children->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_children') }}</p>
            </div>
        @else
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                @foreach ($this->children as $c)
                    <div class="rounded-2xl border p-5"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="flex items-center gap-3">
                            <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold"
                                 style="background: rgba(var(--mt-primary),0.15); color: rgb(var(--mt-primary))">
                                {{ mb_substr($c->student->first_name ?? '', 0, 1) }}{{ mb_substr($c->student->last_name ?? '', 0, 1) }}
                            </div>
                            <div class="min-w-0">
                                <div class="truncate font-semibold mt-text">{{ $c->student->full_name_reverse ?? $c->student->full_name }}</div>
                                <div class="mt-text-muted text-xs">{{ $c->class ?? __('mtschool::portal.not_enrolled_year') }}</div>
                            </div>
                        </div>

                        @if ($c->enrollment_id)
                            <div class="mt-4 grid grid-cols-2 gap-3">
                                <div class="rounded-xl p-3 text-center" style="background: rgba(var(--mt-primary),0.08)">
                                    <div class="text-lg font-bold mt-text-primary">
                                        {{ $c->average !== null ? number_format((float) $c->average, 2, ',', ' ') : '—' }}
                                    </div>
                                    <div class="text-[11px] mt-text-muted">
                                        {{ $c->average !== null ? (__('mtschool::portal.average') . ' · ' . $c->period_label) : __('mtschool::portal.no_average_yet') }}
                                        @if($c->rank) · {{ $c->rank }}/{{ $c->class_size }} @endif
                                    </div>
                                </div>
                                <div class="rounded-xl p-3 text-center"
                                     style="background: rgba(var(--mt-{{ $c->remaining > 0 ? 'danger' : 'success' }}),0.1)">
                                    <div class="text-lg font-bold" style="color: rgb(var(--mt-{{ $c->remaining > 0 ? 'danger' : 'success' }}))">
                                        {{ number_format($c->remaining, 0, ',', ' ') }}
                                    </div>
                                    <div class="text-[11px] mt-text-muted">{{ $c->remaining > 0 ? __('mtschool::portal.remaining_to_pay') : __('mtschool::portal.up_to_date') }}</div>
                                </div>
                            </div>

                            <div class="mt-4 flex flex-wrap gap-2">
                                @if ($c->period_id)
                                    <a href="{{ mt_get_route('parent_bulletin', ['enrollment' => $c->enrollment_id, 'period' => $c->period_id]) }}"
                                       target="_blank">
                                        <x-mt::button variant="primary" size="sm" icon="document-text">{{ __('mtschool::portal.report_card') }}</x-mt::button>
                                    </a>
                                @endif
                                <a href="{{ mt_get_route('parent_statement', ['enrollment' => $c->enrollment_id]) }}" target="_blank">
                                    <x-mt::button variant="secondary" size="sm" icon="banknotes">{{ __('mtschool::portal.financial_status') }}</x-mt::button>
                                </a>
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
        @endif
    </x-mt::screen>
</div>
