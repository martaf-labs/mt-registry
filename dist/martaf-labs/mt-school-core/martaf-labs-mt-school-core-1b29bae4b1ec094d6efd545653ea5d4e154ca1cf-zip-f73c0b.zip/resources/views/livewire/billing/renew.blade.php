<div class="mx-auto w-full max-w-md px-4 py-8">
    <div class="mb-8 text-center">
        <div class="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl"
             style="background: rgba(var(--mt-danger),0.12)">
            <span style="color:rgb(var(--mt-danger))"><x-mt::icon name="exclamation-triangle" size="lg" /></span>
        </div>
        <h1 class="text-2xl font-bold mt-text">{{ __('mtschool::billing.expired_heading') }}</h1>
        <p class="mt-text-muted mt-2 text-sm">
            {!! __('mtschool::billing.expired_intro', ['name' => '<strong>' . e($school?->name) . '</strong>']) !!}
        </p>
    </div>

    @if ($plan)
        <div class="rounded-2xl border p-6"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card))">

            <div class="mb-1 text-xs font-medium uppercase tracking-wide mt-text-muted">{{ __('mtschool::billing.your_plan') }}</div>
            <h2 class="text-lg font-semibold mt-text">{{ $plan->name }}</h2>

            <div class="my-4">
                <span class="text-3xl font-bold mt-text">{{ number_format((float) $plan->price, 0, ',', ' ') }}</span>
                <span class="mt-text-muted text-sm">{{ $plan->currency }}
                    / {{ ['monthly' => __('mtschool::billing.per_month'), 'term' => __('mtschool::billing.per_term')][$plan->billing_period] ?? __('mtschool::billing.per_year') }}</span>
            </div>

            <div class="mt-text-muted mb-4 text-xs">
                {{ $plan->max_students ? __('mtschool::billing.max_students', ['count' => $plan->max_students]) : __('mtschool::billing.unlimited_students') }}
            </div>

            <ul class="mb-6 space-y-2 text-sm">
                @foreach ($plan->moduleCodes() as $code)
                    <li class="flex items-center gap-2 mt-text">
                        <span class="shrink-0" style="color:rgb(var(--mt-success))"><x-mt::icon name="check" size="sm" /></span>
                        {{ $moduleNames[$code] ?? $code }}
                    </li>
                @endforeach
            </ul>

            <button type="button"
                    wire:click="renew"
                    wire:loading.attr="disabled"
                    wire:target="renew"
                    class="block w-full rounded-xl px-4 py-2.5 text-center text-sm font-medium text-white transition disabled:opacity-60"
                    style="background: rgb(var(--mt-primary))">
                <span wire:loading.remove wire:target="renew">
                    {{ __('mtschool::billing.renew_button', ['amount' => number_format((float) $plan->price, 0, ',', ' '), 'currency' => $plan->currency]) }}
                </span>
                <span wire:loading wire:target="renew">{{ __('mtschool::billing.processing') }}</span>
            </button>

            <p class="mt-3 text-center text-xs mt-text-muted">{{ __('mtschool::billing.simulated_payment') }}</p>
        </div>
    @else
        <div class="rounded-2xl border p-6 text-center mt-text-muted"
             style="border-color: rgb(var(--mt-ui-card-border))">
            {{ __('mtschool::billing.no_plan_to_renew') }}
            <a href="{{ route('pricing') }}" class="underline mt-text-primary">{{ __('mtschool::billing.see_plans') }}</a>
        </div>
    @endif

    <p class="mt-6 text-center text-xs mt-text-muted">
        <a href="#" class="underline"
           onclick="event.preventDefault(); document.getElementById('renew-logout').submit();">{{ __('mtschool::billing.logout') }}</a>
    </p>
    <form id="renew-logout" method="POST" action="{{ route('logout') }}" class="hidden">@csrf</form>
</div>
