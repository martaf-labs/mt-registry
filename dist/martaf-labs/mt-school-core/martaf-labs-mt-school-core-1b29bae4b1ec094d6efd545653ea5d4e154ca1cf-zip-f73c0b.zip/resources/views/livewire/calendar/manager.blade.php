<div>
    <x-mt::screen :title="__('mtschool::calendar.title')" :description="__('mtschool::calendar.subtitle')" :breadcrumbs="[['label' => __('mtschool::calendar.title')]]" width="3xl">
        <x-slot:actions>
            @if ($this->canManage)
                <x-mt::button variant="primary" size="sm" icon="plus" wire:click="openCreate">{{ __('mtschool::calendar.new_event') }}</x-mt::button>
            @endif
        </x-slot:actions>

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        @if ($this->events->isEmpty())
            <x-mt::empty-state icon="calendar-days" :title="__('mtschool::calendar.no_events')" />
        @else
            <div class="space-y-6">
                @foreach ($this->events->groupBy(fn ($e) => $e->starts_at?->format('Y-m-d')) as $day => $dayEvents)
                    <div>
                        <div class="mb-2 flex items-baseline gap-2">
                            <span class="text-sm font-bold mt-text">{{ $dayEvents->first()->starts_at?->translatedFormat('l d F Y') }}</span>
                        </div>
                        <div class="space-y-2">
                            @foreach ($dayEvents as $e)
                                <div class="flex items-center gap-3 rounded-2xl border p-3" wire:key="ev-{{ $e->id }}"
                                     style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                                    <span class="h-10 w-1.5 shrink-0 rounded-full" style="background: {{ $e->color }}"></span>
                                    <div class="min-w-0 flex-1">
                                        <div class="flex items-center gap-2">
                                            <span class="truncate font-semibold mt-text">{{ $e->title }}</span>
                                            {{-- Chip couleur PROPRE à l'événement (hex data-driven → pas un badge token).
                                                 py-0.5/text-[11px] absents du CSS servi → padding/taille inline. --}}
                                            <span class="rounded-full"
                                                  style="background: {{ $e->color }}22; color: {{ $e->color }}; padding: 2px 8px; font-size: 11px">{{ $e->type_label }}</span>
                                            @if ($this->canManage && ! $e->published)
                                                <x-mt::badge :label="__('mtschool::common.draft')" variant="secondary" class="px-2" style="font-size:11px" />
                                            @endif
                                        </div>
                                        <div class="mt-text-muted text-xs">
                                            {{ $e->all_day ? __('mtschool::calendar.all_day') : $e->starts_at?->format('H:i') }}
                                            @if ($e->ends_at && ! $e->all_day) – {{ $e->ends_at?->format('H:i') }} @endif
                                            @if ($e->location) · {{ $e->location }} @endif
                                        </div>
                                    </div>
                                    @if ($this->canManage)
                                        <div class="flex shrink-0 items-center gap-1">
                                            <button wire:click="togglePublish({{ $e->id }})" class="mt-btn-icon mt-btn-icon-sm" title="{{ __('mtschool::common.publish') }}">
                                                <x-mt::icon name="{{ $e->published ? 'eye' : 'eye-slash' }}" size="sm" />
                                            </button>
                                            <button wire:click="delete({{ $e->id }})" wire:confirm="{{ __('mtschool::common.confirm_delete') }}" class="mt-btn-icon mt-btn-icon-sm" title="{{ __('mtschool::common.delete') }}">
                                                <x-mt::icon name="trash" size="sm" />
                                            </button>
                                        </div>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>
        @endif

        @if ($this->canManage)
            <x-mt::modal name="create-event" openEvent="open-create-event" :title="__('mtschool::calendar.new_event')" icon="calendar-days" wire="showCreate">
                <form wire:submit="createEvent" class="space-y-4">
                    <x-mt::form.input :label="__('mtschool::calendar.title_field')" model="title" :placeholder="__('mtschool::calendar.title_ph')" required :error="$errors->first('title')" />
                    <x-mt::form.select :label="__('mtschool::calendar.type')" wire:model="type">
                        @foreach (array_keys(\Mt\MtSchoolCore\Livewire\Calendar\CalendarManager::TYPES) as $val)
                            <option value="{{ $val }}">{{ __('mtschool::calendar.type_' . $val) }}</option>
                        @endforeach
                    </x-mt::form.select>
                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <x-mt::form.input :label="__('mtschool::calendar.start')" type="datetime-local" model="startsAt" required :error="$errors->first('startsAt')" />
                        <x-mt::form.input :label="__('mtschool::calendar.end')" type="datetime-local" model="endsAt" :error="$errors->first('endsAt')" />
                    </div>
                    <x-mt::form.input :label="__('mtschool::calendar.location')" model="location" :placeholder="__('mtschool::calendar.location_ph')" />
                </form>
                <x-slot:footer>
                    <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'create-event' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
                    <x-mt::button variant="primary" wire:click="createEvent" icon="check">{{ __('mtschool::common.add') }}</x-mt::button>
                </x-slot:footer>
            </x-mt::modal>
        @endif
    </x-mt::screen>
</div>
