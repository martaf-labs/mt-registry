<div class="mx-auto w-full max-w-5xl px-4 py-8">
    <div class="mb-8 text-center">
        <h1 class="text-2xl font-bold mt-text">{{ __('mtschool::billing.pricing_heading') }}</h1>
        <p class="mt-text-muted mt-2 text-sm">{{ __('mtschool::billing.pricing_subtitle') }}</p>
    </div>

    <div class="grid gap-6 md:grid-cols-3">
        @foreach ($plans as $plan)
            <div class="flex flex-col rounded-2xl border p-6"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card))">

                <h2 class="text-lg font-semibold mt-text">{{ $plan->name }}</h2>
                @if ($plan->description)
                    <p class="mt-text-muted mt-1 text-xs">{{ $plan->description }}</p>
                @endif

                <div class="my-4">
                    <span class="text-3xl font-bold mt-text">{{ number_format((float) $plan->price, 0, ',', ' ') }}</span>
                    <span class="mt-text-muted text-sm">{{ $plan->currency }}
                        / {{ ['monthly' => __('mtschool::billing.per_month'), 'term' => __('mtschool::billing.per_term')][$plan->billing_period] ?? __('mtschool::billing.per_year') }}</span>
                </div>

                <div class="mt-text-muted mb-4 text-xs">
                    {{ $plan->max_students ? __('mtschool::billing.max_students', ['count' => $plan->max_students]) : __('mtschool::billing.unlimited_students') }}
                </div>

                <ul class="mb-6 flex-1 space-y-2 text-sm">
                    @foreach ($plan->moduleCodes() as $code)
                        <li class="flex items-center gap-2 mt-text">
                            <span class="shrink-0" style="color:rgb(var(--mt-success))"><x-mt::icon name="check" size="sm" /></span>
                            {{ $moduleNames[$code] ?? $code }}
                        </li>
                    @endforeach
                </ul>

                <a href="{{ route('checkout', ['plan' => $plan->code]) }}" wire:navigate
                   class="block rounded-xl px-4 py-2.5 text-center text-sm font-medium text-white transition"
                   style="background: rgb(var(--mt-primary))">
                    {{ __('mtschool::billing.choose_plan', ['name' => $plan->name]) }}
                </a>
            </div>
        @endforeach
    </div>

    <p class="mt-text-muted mt-6 text-center text-xs">
        {{ __('mtschool::billing.already_account') }} <a href="{{ route('login') }}" class="underline" wire:navigate>{{ __('mtschool::billing.login') }}</a>
    </p>
</div>
