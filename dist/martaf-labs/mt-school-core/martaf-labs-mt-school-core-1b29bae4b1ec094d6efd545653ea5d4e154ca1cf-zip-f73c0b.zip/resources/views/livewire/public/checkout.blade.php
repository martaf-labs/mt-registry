<div class="mx-auto w-full max-w-md px-4 py-8">
    <div class="mb-6 text-center">
        <h1 class="text-xl font-bold mt-text">{{ __('mtschool::billing.checkout_title') }}</h1>
        <p class="mt-text-muted mt-1 text-sm">{{ __('mtschool::billing.checkout_subtitle') }}</p>
    </div>

    {{-- Récap du plan --}}
    <div class="mb-6 flex items-center justify-between rounded-xl border p-4"
         style="border-color: rgba(var(--mt-primary),0.2); background: rgba(var(--mt-primary),0.06)">
        <div>
            <div class="text-sm font-semibold mt-text">{{ __('mtschool::billing.plan_label', ['name' => $this->plan->name]) }}</div>
            <div class="mt-text-muted text-xs">
                {{ $this->plan->max_students ? __('mtschool::billing.max_students', ['count' => $this->plan->max_students]) : __('mtschool::billing.unlimited_students') }}
            </div>
        </div>
        <div class="text-right">
            <div class="text-lg font-bold mt-text">{{ number_format((float) $this->plan->price, 0, ',', ' ') }} {{ $this->plan->currency }}</div>
            <div class="mt-text-muted text-xs">/ {{ ['monthly' => __('mtschool::billing.per_month'), 'term' => __('mtschool::billing.per_term')][$this->plan->billing_period] ?? __('mtschool::billing.per_year') }}</div>
        </div>
    </div>

    <form wire:submit="pay" class="space-y-4">
        <div>
            <x-mt::form.label :value="__('mtschool::billing.your_name')" :required="true" />
            <x-mt::form.input type="text" wire:model="name" :error="$errors->first('name')" :invalid="$errors->has('name')" />
        </div>

        <div>
            <x-mt::form.label :value="__('mtschool::billing.school_name_optional')" />
            <x-mt::form.input type="text" wire:model="school_name" placeholder="{{ __('mtschool::billing.school_name_ph') }}"
                :error="$errors->first('school_name')" :invalid="$errors->has('school_name')" />
        </div>

        <div>
            <x-mt::form.label :value="__('mtschool::billing.email')" :required="true" />
            <x-mt::form.input type="email" wire:model="email" :error="$errors->first('email')" :invalid="$errors->has('email')" />
        </div>

        <div>
            <x-mt::form.label :value="__('mtschool::billing.password')" :required="true" />
            <x-mt::form.input type="password" wire:model="password" :error="$errors->first('password')" :invalid="$errors->has('password')" />
        </div>

        <div>
            <x-mt::form.label :value="__('mtschool::billing.password_confirm')" :required="true" />
            <x-mt::form.input type="password" wire:model="password_confirmation" />
        </div>

        <button type="submit" wire:loading.attr="disabled" wire:target="pay"
                class="w-full rounded-xl px-4 py-3 text-sm font-medium text-white transition disabled:opacity-60"
                style="background: rgb(var(--mt-primary))">
            <span wire:loading.remove wire:target="pay">
                {{ __('mtschool::billing.pay_button', ['amount' => number_format((float) $this->plan->price, 0, ',', ' '), 'currency' => $this->plan->currency]) }}
            </span>
            <span wire:loading wire:target="pay">{{ __('mtschool::billing.processing') }}</span>
        </button>

        <p class="mt-text-muted text-center text-xs">
            {{ __('mtschool::billing.simulated_payment_long') }}
        </p>
    </form>
</div>
