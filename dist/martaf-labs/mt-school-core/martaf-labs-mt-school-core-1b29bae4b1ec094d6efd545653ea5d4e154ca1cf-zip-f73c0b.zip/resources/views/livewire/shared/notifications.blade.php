<div>
    @php
        $unreadLabel = $unread > 0
            ? __('mtschool::portal.notifications_unread', ['count' => $unread])
            : '';
    @endphp

    <x-mt::screen
        :title="__('mtschool::portal.notifications_title')"
        :description="$unreadLabel"
        :breadcrumbs="[['label' => __('mtschool::portal.notifications_title')]]"
        width="3xl"
    >
        @if ($unread > 0)
            <x-slot:actions>
                <x-mt::button variant="secondary" size="sm" wire:click="markAllRead">
                    {{ __('mtschool::portal.mark_all_read') }}
                </x-mt::button>
            </x-slot:actions>
        @endif

        <div class="flex flex-col gap-2">
            @forelse ($notifications as $n)
                <div wire:key="notif-{{ $n->id }}"
                     class="flex items-start gap-3 rounded-xl p-3"
                     style="border:1px solid rgb(var(--mt-ui-card-border));
                            background: {{ $n->is_read ? 'transparent' : 'rgba(var(--mt-primary), .06)' }};">
                    <div style="width:8px; height:8px; border-radius:999px; margin-top:6px; flex-shrink:0;
                                background: {{ $n->is_read ? 'rgba(var(--mt-text), .35)' : 'rgb(var(--mt-primary))' }};"></div>
                    <div style="flex:1 1 0; min-width:0;">
                        <div class="mt-text" style="font-weight:{{ $n->is_read ? '500' : '700' }}; font-size:14px;">{{ $n->title }}</div>
                        @if ($n->body)
                            <div class="mt-text-muted" style="font-size:13px; margin-top:2px;">{{ \Illuminate\Support\Str::limit((string) $n->body, 200) }}</div>
                        @endif
                        <div class="mt-text-muted" style="font-size:11px; margin-top:4px;">{{ $n->created_at?->diffForHumans() }}</div>
                    </div>
                    @if (! $n->is_read)
                        <x-mt::button variant="ghost" size="sm" wire:click="markRead({{ $n->id }})">
                            {{ __('mtschool::portal.mark_read') }}
                        </x-mt::button>
                    @endif
                </div>
            @empty
                <x-mt::empty-state icon="bell" :title="__('mtschool::portal.no_notifications')" />
            @endforelse
        </div>
    </x-mt::screen>
</div>
