<div>
    <x-mt::screen :title="__('mtschool::portal.announcements')" :description="__('mtschool::portal.announcements_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.announcements')]]" width="3xl">

        @if ($this->announcements->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_announcements') }}</p>
            </div>
        @else
            <div class="space-y-3">
                @foreach ($this->announcements as $a)
                    @php
                        $impMap = ['urgent'=>[__('mtschool::portal.importance_urgent'),'danger'],'important'=>[__('mtschool::portal.importance_important'),'warning'],'normal'=>[null,'secondary']];
                        [$impLbl,$impCol] = $impMap[$a->importance ?? 'normal'] ?? [null,'secondary'];
                    @endphp
                    <div class="rounded-2xl border p-4"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))
                                @if($a->importance==='urgent'); border-left:3px solid rgb(var(--mt-danger)) @endif">
                        <div class="flex items-start justify-between gap-3">
                            <h3 class="font-semibold mt-text">{{ $a->title }}</h3>
                            @if ($impLbl)
                                <span class="shrink-0 rounded-full px-2 py-0.5 text-xs font-medium"
                                      style="background: rgba(var(--mt-{{ $impCol }}),0.15); color: rgb(var(--mt-{{ $impCol }}))">{{ $impLbl }}</span>
                            @endif
                        </div>
                        <p class="mt-text-muted mt-1 text-sm whitespace-pre-line">{{ $a->content }}</p>
                        <div class="mt-2 text-xs mt-text-muted">{{ $a->published_at?->format('d/m/Y') }}</div>
                    </div>
                @endforeach
            </div>
        @endif
    </x-mt::screen>
</div>
