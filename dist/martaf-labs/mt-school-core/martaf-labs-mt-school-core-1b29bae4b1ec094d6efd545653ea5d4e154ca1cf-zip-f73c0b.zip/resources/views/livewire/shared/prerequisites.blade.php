{{--
    Vue partagée « prérequis manquants » — rendue par les composants d'écran quand
    PrerequisiteService::missingFor($screen) n'est pas vide (à la place du formulaire).
    Posée dans le CADRE GLOBAL <x-mt::screen> (même frame que base-index/base-form).
    $missing = [['message','url','cta'], …] ; $screenTitle = titre de l'écran d'origine.
--}}
<div>
    <x-mt::screen :title="$screenTitle" width="4xl" :breadcrumbs="[['label' => $screenTitle]]">
        <x-mt::prerequisite-gate :items="$missing" />
    </x-mt::screen>
</div>
