<div>
    <x-mt::screen :title="$d['student']?->full_name ?? __('mtschool::portal.my_space')" :description="$d['class'] ?? __('mtschool::portal.not_enrolled_year')" :breadcrumbs="[['label' => __('mtschool::portal.my_space')]]" width="3xl">
        @php $enrollment = $d['enrollment'] ?? null; $period = $d['period'] ?? null; @endphp


        @if (! $enrollment)
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_active_enrollment') }}</p>
            </div>
        @else
            {{-- Synthèse --}}
            <div class="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div class="rounded-2xl p-4 text-center" style="background: rgba(var(--mt-primary),0.1)">
                    <div class="text-2xl font-bold mt-text-primary">{{ $period?->overall_average !== null ? number_format((float) $period->overall_average, 2, ',', ' ') : '—' }}</div>
                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.average') }}{{ $period ? ' · ' . $period->period?->label : '' }}</div>
                </div>
                <div class="rounded-2xl p-4 text-center" style="background: rgba(var(--mt-info),0.1)">
                    <div class="text-2xl font-bold" style="color: rgb(var(--mt-info))">{{ $period?->rank ? $period->rank . '/' . $period->class_size : '—' }}</div>
                    <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.rank') }}</div>
                </div>
                <div class="rounded-2xl p-4 text-center" style="background: rgba(var(--mt-{{ ($d['remaining'] ?? 0) > 0 ? 'danger' : 'success' }}),0.1)">
                    <div class="text-2xl font-bold" style="color: rgb(var(--mt-{{ ($d['remaining'] ?? 0) > 0 ? 'danger' : 'success' }}))">{{ number_format($d['remaining'] ?? 0, 0, ',', ' ') }}</div>
                    <div class="text-[11px] mt-text-muted">{{ ($d['remaining'] ?? 0) > 0 ? __('mtschool::portal.remaining_to_pay') : __('mtschool::portal.up_to_date') }}</div>
                </div>
            </div>

            {{-- Actions --}}
            <div class="mb-5 flex flex-wrap gap-2">
                @if ($period)
                    <a href="{{ mt_get_route('student_bulletin', ['period' => $period->period_id]) }}" target="_blank">
                        <x-mt::button variant="primary" size="sm" icon="document-text">{{ __('mtschool::portal.my_report_card') }}</x-mt::button>
                    </a>
                @endif
                <a href="{{ mt_get_route('student_timetable') }}" wire:navigate>
                    <x-mt::button variant="secondary" size="sm" icon="table-cells">{{ __('mtschool::portal.my_timetable') }}</x-mt::button>
                </a>
            </div>

            {{-- Résultats par matière --}}
            @if ($d['subjects']->isNotEmpty())
                <div class="overflow-hidden rounded-2xl border"
                     style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                    <div class="px-4 py-3 text-sm font-semibold mt-text" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                        {{ __('mtschool::portal.results') }} · {{ $period?->period?->label }}
                    </div>
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgba(var(--mt-ui-card-border),0.6)">
                                <th class="px-4 py-2 font-medium">{{ __('mtschool::portal.col_subject') }}</th>
                                <th class="px-3 py-2 font-medium text-center" style="width:80px">{{ __('mtschool::portal.col_avg') }}</th>
                                <th class="px-3 py-2 font-medium text-center" style="width:70px">{{ __('mtschool::portal.col_rank') }}</th>
                                <th class="px-3 py-2 font-medium text-center" style="width:80px">{{ __('mtschool::portal.col_class_avg') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($d['subjects'] as $sa)
                                <tr style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.4)">
                                    <td class="px-4 py-2 mt-text">{{ $sa->subject?->label }}</td>
                                    <td class="px-3 py-2 text-center font-semibold mt-text">{{ number_format((float) $sa->average, 2, ',', ' ') }}</td>
                                    <td class="px-3 py-2 text-center mt-text-muted">{{ $sa->rank }}</td>
                                    <td class="px-3 py-2 text-center mt-text-muted">{{ $sa->class_average !== null ? number_format((float) $sa->class_average, 2, ',', ' ') : '—' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        @endif
    </x-mt::screen>
</div>
