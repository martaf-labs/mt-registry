@php
    $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v;
@endphp
<div>
    <x-mt::screen :title="__('mtschool::portal.my_grades')" :description="__('mtschool::portal.my_grades_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_grades')]]" width="3xl">

        @if ($this->periods->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_average_yet') }}</p>
            </div>
        @else
            <div class="flex flex-col gap-5">
                @foreach ($this->periods as $p)
                    <div class="rounded-2xl border p-5"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="flex items-center justify-between">
                            <div class="font-semibold mt-text">{{ $loc($p->period) }}</div>
                            <div class="flex items-center gap-3 text-sm">
                                <span class="rounded-lg px-3 py-1 font-bold mt-text-primary" style="background: rgba(var(--mt-primary),0.1)">
                                    {{ number_format($p->average, 2, ',', ' ') }}
                                </span>
                                @if ($p->rank)<span class="mt-text-muted">{{ __('mtschool::portal.rank') }} {{ $p->rank }}/{{ $p->class_size }}</span>@endif
                                @if ($p->mention)<span class="mt-text-muted">· {{ $p->mention }}</span>@endif
                            </div>
                        </div>

                        @if ($p->subjects->isNotEmpty())
                            <div class="mt-4 overflow-x-auto">
                                <table class="w-full text-sm" style="border-collapse: collapse;">
                                    <thead>
                                        <tr class="mt-text-muted text-left text-xs">
                                            <th class="py-2 pr-2">{{ __('mtschool::documents.subject') }}</th>
                                            <th class="py-2 px-2 text-right">{{ __('mtschool::documents.average_short') }}</th>
                                            <th class="py-2 px-2 text-right">{{ __('mtschool::documents.coefficient_short') }}</th>
                                            <th class="py-2 pl-2 text-right">{{ __('mtschool::documents.rank') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($p->subjects as $s)
                                            <tr style="border-top: 1px solid rgb(var(--mt-ui-card-border));">
                                                <td class="py-2 pr-2 mt-text">{{ $loc($s->subject) }}</td>
                                                <td class="py-2 px-2 text-right mt-text font-medium">{{ number_format($s->average, 2, ',', ' ') }}</td>
                                                <td class="py-2 px-2 text-right mt-text-muted">{{ rtrim(rtrim(number_format($s->coef, 2), '0'), ',') }}</td>
                                                <td class="py-2 pl-2 text-right mt-text-muted">{{ $s->rank ?? '—' }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
        @endif
    </x-mt::screen>
</div>
