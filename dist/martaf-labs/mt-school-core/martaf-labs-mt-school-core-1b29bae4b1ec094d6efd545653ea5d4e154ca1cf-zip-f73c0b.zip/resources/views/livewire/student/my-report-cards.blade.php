@php
    $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v;
@endphp
<div>
    <x-mt::screen :title="__('mtschool::portal.my_report_cards')" :description="__('mtschool::portal.my_report_cards_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_report_cards')]]" width="3xl">

        @if (! $d['enrollment_id'])
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.not_enrolled_year') }}</p>
            </div>
        @else
            <div class="rounded-2xl border p-5"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                @if ($d['periods']->isNotEmpty())
                    <div class="flex flex-col gap-2">
                        @foreach ($d['periods'] as $p)
                            <div class="flex items-center justify-between rounded-lg px-3 py-2" style="background: rgba(var(--mt-primary),0.05)">
                                <div class="min-w-0">
                                    <div class="font-medium mt-text">{{ $loc($p->period) }}</div>
                                    @if ($p->published_at)
                                        <div class="mt-text-muted text-xs">{{ __('mtschool::portal.published_on') }} {{ optional($p->published_at)->format('d/m/Y') }}</div>
                                    @endif
                                </div>
                                <a href="{{ mt_get_route('student_bulletin', ['period' => $p->period_id]) }}" target="_blank">
                                    <x-mt::button variant="primary" size="sm" icon="document-text">{{ __('mtschool::portal.download') }}</x-mt::button>
                                </a>
                            </div>
                        @endforeach
                    </div>
                @else
                    <p class="mt-text-muted text-sm">{{ __('mtschool::portal.no_report_cards') }}</p>
                @endif

                @if ($d['annual'])
                    <div class="mt-4 rounded-xl border p-4"
                         style="border-color: rgb(var(--mt-primary) / .3); background: rgba(var(--mt-primary),0.06)">
                        <div class="flex items-center justify-between gap-3">
                            <div>
                                <div class="font-semibold mt-text">{{ __('mtschool::portal.annual_report_card') }}</div>
                                <div class="mt-text-muted mt-0.5 text-xs">
                                    {{ __('mtschool::portal.annual_average') }} : <strong class="mt-text">{{ number_format($d['annual']->average, 2, ',', ' ') }}</strong>
                                    @if ($d['annual']->rank) · {{ __('mtschool::portal.rank') }} {{ $d['annual']->rank }} @endif
                                    @if ($d['annual']->result) · {{ $d['annual']->result }} @endif
                                </div>
                            </div>
                            <a href="{{ mt_get_route('student_annual_bulletin', ['year' => $d['year_id']]) }}" target="_blank">
                                <x-mt::button variant="secondary" size="sm" icon="document-text">{{ __('mtschool::portal.download') }}</x-mt::button>
                            </a>
                        </div>
                    </div>
                @endif
            </div>
        @endif
    </x-mt::screen>
</div>
