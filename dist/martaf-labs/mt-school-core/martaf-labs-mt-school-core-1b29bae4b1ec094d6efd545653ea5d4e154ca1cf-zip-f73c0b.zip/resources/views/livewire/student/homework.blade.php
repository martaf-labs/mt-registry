<div>
    <x-mt::screen :title="__('mtschool::pedagogy.my_homework')" :description="__('mtschool::pedagogy.student_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_space'), 'lien' => mt_get_route('student_home')], ['label' => __('mtschool::pedagogy.my_homework')]]" width="2xl">

        @if ($successMessage)
            <div class="mb-4"><x-mt::alert type="success" :message="$successMessage" dismissible /></div>
        @endif

        @if ($this->homeworks->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::pedagogy.student_empty') }}</p>
            </div>
        @else
            <div class="space-y-3">
                @foreach ($this->homeworks as $hw)
                    <div class="rounded-2xl border p-4" wire:key="shw-{{ $hw->id }}"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <div class="truncate font-semibold mt-text">{{ $hw->title }}</div>
                                <div class="mt-text-muted mt-1 text-xs">
                                    {{ $hw->subject }}@if ($hw->teacher) · {{ $hw->teacher }} @endif
                                </div>
                            </div>
                            @if ($hw->corrected)
                                <span class="shrink-0 rounded-full px-2 py-0.5 text-xs"
                                      style="background: rgba(var(--mt-success),0.15); color: rgb(var(--mt-success))">
                                    {{ __('mtschool::pedagogy.status_corrected') }}@if ($hw->is_graded && $hw->score !== null) · {{ rtrim(rtrim((string) $hw->score, '0'), '.') }}/{{ rtrim(rtrim((string) $hw->max_score, '0'), '.') }} @endif
                                </span>
                            @elseif ($hw->submitted)
                                <span class="shrink-0 rounded-full px-2 py-0.5 text-xs"
                                      style="background: rgba(var(--mt-info),0.15); color: rgb(var(--mt-info))">{{ __('mtschool::pedagogy.status_submitted') }}</span>
                            @elseif ($hw->expired)
                                <span class="shrink-0 rounded-full px-2 py-0.5 text-xs"
                                      style="background: rgba(var(--mt-danger),0.15); color: rgb(var(--mt-danger))">{{ __('mtschool::pedagogy.status_missing') }}</span>
                            @else
                                <span class="shrink-0 rounded-full px-2 py-0.5 text-xs"
                                      style="background: rgba(var(--mt-warning),0.15); color: rgb(var(--mt-warning))">{{ __('mtschool::pedagogy.status_todo') }}</span>
                            @endif
                        </div>

                        @if ($hw->instructions)
                            <p class="mt-2 text-sm mt-text-muted">{{ is_array($hw->instructions) ? ($hw->instructions['fr'] ?? '') : $hw->instructions }}</p>
                        @endif

                        @if ($hw->corrected && $hw->correction)
                            <p class="mt-2 rounded-lg px-3 py-2 text-sm mt-text" style="background: rgba(var(--mt-success),0.08)">
                                <span class="font-medium">{{ __('mtschool::pedagogy.correction_label') }}</span>
                                {{ is_array($hw->correction) ? ($hw->correction['fr'] ?? '') : $hw->correction }}
                            </p>
                        @endif

                        <div class="mt-3 flex items-center justify-between gap-3">
                            <span class="text-xs {{ $hw->expired && ! $hw->submitted ? '' : 'mt-text-muted' }}"
                                  @if ($hw->expired && ! $hw->submitted) style="color: rgb(var(--mt-danger))" @endif>
                                {{ __('mtschool::pedagogy.due_on', ['date' => $hw->deadline?->format('d/m/Y H:i')]) }}
                            </span>
                            @if (! $hw->corrected)
                                <x-mt::button variant="{{ $hw->submitted ? 'secondary' : 'primary' }}" size="sm" icon="paper-airplane"
                                              wire:click="openSubmit({{ $hw->id }})">
                                    {{ $hw->submitted ? __('mtschool::pedagogy.edit_submission') : __('mtschool::pedagogy.submit') }}
                                </x-mt::button>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        @endif

        {{-- Modale rendu --}}
        <x-mt::modal name="submit-homework" openEvent="open-submit-homework" :title="__('mtschool::pedagogy.submit_modal_title')" icon="paper-airplane" wire="showSubmit">
            <form wire:submit="submit" class="space-y-4">
                <x-mt::form.textarea :label="__('mtschool::pedagogy.comment_field')" model="comment" rows="3" :placeholder="__('mtschool::pedagogy.comment_ph')" />
                <div>
                    <label class="mb-1 block text-sm font-medium mt-text">{{ __('mtschool::pedagogy.file_optional') }}</label>
                    <input type="file" wire:model="upload"
                           class="block w-full text-sm mt-text file:mr-3 file:rounded-lg file:border-0 file:px-3 file:py-2 file:text-sm">
                    <div wire:loading wire:target="upload" class="mt-text-muted mt-1 text-xs">{{ __('mtschool::pedagogy.uploading') }}</div>
                    @error('upload') <p class="mt-1 text-xs" style="color: rgb(var(--mt-danger))">{{ $message }}</p> @enderror
                </div>
            </form>
            <x-slot:footer>
                <x-mt::button variant="ghost" x-on:click="$dispatch('close-modal', { name: 'submit-homework' })">{{ __('mtschool::common.cancel') }}</x-mt::button>
                <x-mt::button variant="primary" wire:click="submit" icon="check">{{ __('mtschool::common.send') }}</x-mt::button>
            </x-slot:footer>
        </x-mt::modal>
    </x-mt::screen>
</div>
