<div>
    <x-mt::screen :title="__('mtschool::pedagogy.resources')" :description="__('mtschool::pedagogy.student_res_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_space'), 'lien' => mt_get_route('student_home')], ['label' => __('mtschool::pedagogy.resources')]]" width="2xl">

        @if ($this->resources->isEmpty())
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::pedagogy.no_resources_student') }}</p>
            </div>
        @else
            <div class="space-y-3">
                @foreach ($this->resources as $r)
                    <div class="flex items-center justify-between gap-3 rounded-2xl border p-4" wire:key="sres-{{ $r->id }}"
                         style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <div class="flex min-w-0 items-center gap-3">
                            <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
                                 style="background: rgba(var(--mt-primary),0.12)">
                                <x-mt::icon name="{{ $r->type === 'link' ? 'link' : 'document' }}" size="sm" class="mt-text-primary" />
                            </div>
                            <div class="min-w-0">
                                <div class="truncate font-medium mt-text">{{ $r->title }}</div>
                                <div class="mt-text-muted text-xs">
                                    {{ $r->subject?->label }}@if ($r->teacher) · {{ $r->teacher->full_name ?? $r->teacher->last_name }} @endif
                                </div>
                                @if ($r->description)
                                    <div class="mt-text-muted mt-0.5 text-xs">{{ is_array($r->description) ? ($r->description['fr'] ?? '') : $r->description }}</div>
                                @endif
                            </div>
                        </div>
                        <div class="shrink-0">
                            @if ($r->type === 'link' && $r->external_url)
                                <a href="{{ $r->external_url }}" target="_blank" rel="noopener">
                                    <x-mt::button variant="secondary" size="sm" icon="arrow-top-right-on-square">{{ __('mtschool::common.open') }}</x-mt::button>
                                </a>
                            @elseif ($r->file)
                                <x-mt::button variant="secondary" size="sm" icon="arrow-down-tray"
                                              wire:click="download({{ $r->id }})">{{ __('mtschool::common.download') }}</x-mt::button>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </x-mt::screen>
</div>
