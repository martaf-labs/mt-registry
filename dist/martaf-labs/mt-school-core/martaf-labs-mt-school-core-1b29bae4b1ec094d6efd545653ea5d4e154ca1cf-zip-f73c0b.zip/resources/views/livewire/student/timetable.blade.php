<div>
    <x-mt::screen :title="__('mtschool::portal.my_timetable')" :description="$className ?? '—'" :breadcrumbs="[['label' => __('mtschool::portal.my_space'), 'lien' => mt_get_route('student_home')], ['label' => __('mtschool::portal.my_timetable')]]" width="5xl">
        <div class="overflow-x-auto rounded-2xl border"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <table class="w-full border-collapse text-sm">
                <thead>
                    <tr>
                        <th class="p-2" style="width:70px"></th>
                        @foreach ($days as $d => $dname)
                            <th class="p-2 text-center text-xs font-semibold mt-text"
                                style="border-left: 1px solid rgb(var(--mt-ui-card-border))">{{ $dname }}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach ($periods as [$start, $end])
                        <tr style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                            <td class="p-2 text-center text-[11px] mt-text-muted whitespace-nowrap">{{ $start }}<br>{{ $end }}</td>
                            @foreach ($days as $d => $dname)
                                @php $cell = $slots["{$d}_{$start}"] ?? null; @endphp
                                <td class="p-1 align-top" style="border-left: 1px solid rgb(var(--mt-ui-card-border)); height:60px">
                                    @if ($cell)
                                        <div class="flex h-full flex-col items-center justify-center rounded-lg px-1 text-center"
                                             style="background: rgba(var(--mt-primary),0.12)">
                                            <span class="text-xs font-bold mt-text-primary">{{ $cell['subject'] }}</span>
                                            @if($cell['teacher'])<span class="text-[10px] mt-text-muted truncate w-full">{{ $cell['teacher'] }}</span>@endif
                                            @if($cell['room'])<span class="text-[9px] mt-text-muted">{{ $cell['room'] }}</span>@endif
                                        </div>
                                    @endif
                                </td>
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-mt::screen>
</div>
