@php $evColor = ['absent' => 'danger', 'late' => 'warning']; @endphp
<div>
    <x-mt::screen :title="__('mtschool::portal.my_attendance')" :description="__('mtschool::portal.my_attendance_subtitle')" :breadcrumbs="[['label' => __('mtschool::portal.my_attendance')]]" width="3xl">

        @if (! $d['enrollment'])
            <div class="rounded-2xl border px-5 py-12 text-center"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <p class="mt-text-muted text-sm">{{ __('mtschool::portal.not_enrolled_year') }}</p>
            </div>
        @else
            <div class="rounded-2xl border p-5"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                <div class="grid grid-cols-4 gap-3">
                    <div class="rounded-xl p-3 text-center" style="background: rgba(var(--mt-success),0.1)">
                        <div class="text-lg font-bold" style="color: rgb(var(--mt-success))">{{ $d['present'] }}</div>
                        <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.att_present') }}</div>
                    </div>
                    <div class="rounded-xl p-3 text-center" style="background: rgba(var(--mt-danger),0.1)">
                        <div class="text-lg font-bold" style="color: rgb(var(--mt-danger))">{{ $d['absent'] }}</div>
                        <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.att_absent') }}</div>
                    </div>
                    <div class="rounded-xl p-3 text-center" style="background: rgba(var(--mt-warning),0.1)">
                        <div class="text-lg font-bold" style="color: rgb(var(--mt-warning))">{{ $d['late'] }}</div>
                        <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.att_late') }}</div>
                    </div>
                    <div class="rounded-xl p-3 text-center" style="background: rgba(var(--mt-danger),0.14)">
                        <div class="text-lg font-bold" style="color: rgb(var(--mt-danger))">{{ $d['unjustified'] }}</div>
                        <div class="text-[11px] mt-text-muted">{{ __('mtschool::portal.att_unjustified') }}</div>
                    </div>
                </div>

                @if ($d['events']->isNotEmpty())
                    <div class="mt-5">
                        <div class="mb-2 text-xs font-semibold mt-text-muted uppercase tracking-wide">{{ __('mtschool::portal.recent_events') }}</div>
                        <div class="flex flex-col gap-1.5">
                            @foreach ($d['events'] as $e)
                                <div class="flex items-center justify-between rounded-lg px-3 py-2 text-sm"
                                     style="background: rgba(var(--mt-{{ $evColor[$e->status] ?? 'muted' }}),0.08)">
                                    <div class="flex items-center gap-2">
                                        <span class="rounded-full px-2 py-0.5 text-[11px] font-medium"
                                              style="background: rgba(var(--mt-{{ $evColor[$e->status] ?? 'muted' }}),0.18); color: rgb(var(--mt-{{ $evColor[$e->status] ?? 'muted' }}))">
                                            {{ __('mtschool::portal.att_' . $e->status) }}
                                        </span>
                                        @if ($e->status === 'late' && $e->lateness > 0)
                                            <span class="mt-text-muted text-xs">{{ $e->lateness }} min</span>
                                        @endif
                                    </div>
                                    <div class="flex items-center gap-3">
                                        @if ($e->status === 'absent')
                                            <span class="text-[11px]" @style(['color:rgb(var(--mt-danger))' => ! $e->justified, 'color:rgb(var(--mt-muted))' => $e->justified])>
                                                {{ $e->justified ? __('mtschool::portal.justified') : __('mtschool::portal.unjustified') }}
                                            </span>
                                        @endif
                                        <span class="mt-text-muted text-xs">{{ optional($e->date)->format('d/m/Y') }}</span>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @else
                    <p class="mt-text-muted mt-4 text-sm">{{ __('mtschool::portal.no_attendance') }}</p>
                @endif
            </div>
        @endif
    </x-mt::screen>
</div>
