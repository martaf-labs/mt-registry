<div class="min-h-screen flex flex-col items-center justify-center p-4 lg:p-8">

    {{-- Conteneur principal --}}
    <div class="w-full max-w-2xl">

        {{-- En-tête --}}
        <div class="mb-8 text-center">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 mt-bg-primary">
                <span class="text-white"><x-mt::icon name="academic-cap" size="xl" /></span>
            </div>
            <h1 class="text-2xl font-bold mt-text">{{ __('mtschool::setup.title') }}</h1>
            <p class="mt-1 text-sm mt-text-muted">{{ __('mtschool::setup.header_subtitle') }}</p>
        </div>

        {{-- Barre de progression --}}
        <div class="mb-6">
            <div class="flex items-center justify-between mb-2">
                <span class="text-xs font-medium mt-text-muted">{{ __('mtschool::setup.step_of', ['current' => $currentStep, 'total' => $totalSteps]) }}</span>
                <span class="text-xs font-medium mt-text-muted">{{ $progressPercent }}%</span>
            </div>
            <div class="w-full h-2 rounded-full" style="background: rgb(var(--mt-ui-card-border))">
                <div class="h-2 rounded-full transition-all duration-500 mt-bg-primary"
                     style="width: {{ $progressPercent }}%"></div>
            </div>
        </div>

        {{-- Steps indicators --}}
        <div class="flex items-center justify-between mb-8">
            @foreach($steps as $num => $step)
                @php
                    $isCompleted = in_array($num, $completedSteps);
                    $isCurrent   = $num === $currentStep;
                    $isPending   = $num > $currentStep;
                @endphp
                <div class="flex flex-col items-center gap-1 flex-1">
                    <div class="flex items-center w-full">
                        {{-- Ligne gauche --}}
                        @if($num > 1)
                            <div class="flex-1 h-0.5 transition-colors duration-300"
                                 style="background: {{ $isCompleted || $isCurrent ? 'rgb(var(--mt-primary))' : 'rgb(var(--mt-ui-card-border))' }}"></div>
                        @endif

                        {{-- Cercle --}}
                        <div class="flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold transition-all duration-300 shrink-0
                            @if($isCompleted) text-white
                            @elseif($isCurrent) text-white
                            @else mt-text-muted
                            @endif"
                             style="
                                @if($isCompleted) background: rgb(var(--mt-success));
                                @elseif($isCurrent) background: rgb(var(--mt-primary));
                                @else background: rgb(var(--mt-ui-card-border));
                                @endif
                             ">
                            @if($isCompleted)
                                ✓
                            @else
                                {{ $num }}
                            @endif
                        </div>

                        {{-- Ligne droite --}}
                        @if($num < $totalSteps)
                            <div class="flex-1 h-0.5 transition-colors duration-300"
                                 style="background: {{ $isCompleted ? 'rgb(var(--mt-primary))' : 'rgb(var(--mt-ui-card-border))' }}"></div>
                        @endif
                    </div>
                    <span class="text-xs mt-text-muted hidden sm:block">{{ $step['title'] }}</span>
                </div>
            @endforeach
        </div>

        {{-- Carte principale --}}
        <div class="mt-card rounded-2xl p-6 lg:p-8">

            {{-- Titre de l'étape --}}
            <div class="mb-6">
                <h2 class="text-lg font-bold mt-text">{{ $steps[$currentStep]['title'] }}</h2>
                <p class="text-sm mt-text-muted">{{ $steps[$currentStep]['description'] }}</p>
            </div>

            {{-- Erreurs de validation --}}
            @if($errors->any())
                <div class="mb-4 p-4 rounded-xl" style="background: rgba(var(--mt-danger),0.08); border:1px solid rgba(var(--mt-danger),0.3)">
                    <ul class="space-y-1">
                        @foreach($errors->all() as $error)
                            <li class="text-sm" style="color: rgb(var(--mt-danger))">{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            {{-- ── STEP 1 : Bienvenue ─────────────────────────────────────── --}}
            @if($currentStep === 1)
                <div class="space-y-4 text-center py-4">
                    <p class="mt-text">
                        {{ __('mtschool::setup.welcome_intro_before') }} <strong>MT School</strong>{{ __('mtschool::setup.welcome_intro_after') }}
                    </p>
                    <div class="grid grid-cols-2 gap-3 mt-6 text-left">
                        @foreach([
                            ['icon' => 'calendar',         'label' => __('mtschool::setup.feature_school_year')],
                            ['icon' => 'globe',            'label' => __('mtschool::setup.feature_languages')],
                            ['icon' => 'rectangle-stack',  'label' => __('mtschool::setup.feature_cycle')],
                            ['icon' => 'academic-cap',     'label' => __('mtschool::setup.feature_first_level')],
                        ] as $item)
                            <div class="flex items-center gap-3 p-3 rounded-xl"
                                 style="background: rgba(var(--mt-primary),0.06); border:1px solid rgba(var(--mt-primary),0.12)">
                                {{-- SVG inline (le mask CSS mt-icon-* rend des carrés pleins) --}}
                                <x-mt::icon :name="$item['icon']" class="shrink-0" style="color: rgb(var(--mt-primary))" />
                                <span class="text-sm font-medium mt-text">{{ $item['label'] }}</span>
                            </div>
                        @endforeach
                    </div>
                    <p class="text-xs mt-text-muted mt-4">
                        {{ __('mtschool::setup.welcome_note_before') }} <strong>{{ __('mtschool::setup.welcome_note_bold') }}</strong> {{ __('mtschool::setup.welcome_note_after') }}
                    </p>
                </div>
            @endif

            {{-- ── STEP 3 : Identité de l'école (dans les langues choisies en 2) ── --}}
            @if($currentStep === 3)
                <div class="space-y-5">
                    <p class="mt-text text-sm">
                        {{ __('mtschool::setup.school_intro_before') }} <strong>{{ __('mtschool::setup.school_intro_bold') }}</strong>{{ __('mtschool::setup.school_intro_after') }}
                    </p>

                    {{-- Nom complet (multilingue selon les langues choisies) --}}
                    <div>
                        <x-mt::form.label :value="__('mtschool::setup.school_full_name')" :required="true" />
                        @foreach($teaching_languages as $lang)
                            <div class="mb-2">
                                <x-mt::form.input
                                    type="text"
                                    wire:model="sc_name.{{ $lang }}"
                                    placeholder="{{ __('mtschool::setup.school_name_placeholder', ['lang' => strtoupper($lang)]) }}"
                                    :error="$errors->first('sc_name.'.$lang)"
                                    :invalid="$errors->has('sc_name.'.$lang)"
                                />
                            </div>
                        @endforeach
                        @error('sc_name.fr')<p class="text-xs" style="color:rgb(var(--mt-danger))">{{ $message }}</p>@enderror
                    </div>

                    {{-- Sigle / nom court --}}
                    <div>
                        <x-mt::form.label :value="__('mtschool::setup.school_short_name')" />
                        @foreach($teaching_languages as $lang)
                            <div class="mb-2">
                                <x-mt::form.input
                                    type="text"
                                    wire:model="sc_short_name.{{ $lang }}"
                                    placeholder="{{ __('mtschool::setup.school_short_placeholder', ['lang' => strtoupper($lang)]) }}"
                                />
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif

            {{-- ── STEP 4 : Année scolaire ────────────────────────────────── --}}
            @if($currentStep === 4)
                <div class="space-y-5">

                    {{-- Année DÉTERMINÉE AUTOMATIQUEMENT selon la date du jour (pas de choix :
                         une 1re année dans le passé ou le futur = école fantôme ; les années
                         suivantes se créent via « Nouvelle année », avec promotion + reports). --}}
                    <div class="flex items-center gap-4 p-4 rounded-xl"
                         style="background: rgba(var(--mt-primary),0.06); border:1px solid rgba(var(--mt-primary),0.15)">
                        <span class="shrink-0" style="color:rgb(var(--mt-primary))"><x-mt::icon name="calendar" size="md" /></span>
                        <div>
                            <div class="text-sm font-semibold mt-text">{{ $syCode }}</div>
                            <div class="text-xs mt-text-muted">{{ __('mtschool::setup.sy_auto_hint') }}</div>
                        </div>
                    </div>

                    {{-- Dates (ajustables) --}}
                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div>
                            <x-mt::form.label :value="__('mtschool::setup.start_date')" :required="true" />
                            <x-mt::form.date-picker
                                type="date"
                                model="sy_start_date"
                                icon="calendar"
                                min="{{ $sy_start_year }}-01-01"
                                max="{{ $sy_start_year }}-12-31"
                                :error="$errors->first('sy_start_date')"
                                :invalid="$errors->has('sy_start_date')"
                            />
                        </div>
                        <div>
                            <x-mt::form.label :value="__('mtschool::setup.end_date')" :required="true" />
                            <x-mt::form.date-picker
                                type="date"
                                model="sy_end_date"
                                icon="calendar"
                                min="{{ $sy_start_year }}-01-02"
                                max="{{ $sy_start_year + 1 }}-12-31"
                                :error="$errors->first('sy_end_date')"
                                :invalid="$errors->has('sy_end_date')"
                            />
                        </div>
                    </div>

                    <p class="text-xs mt-text-muted">
                        {{ __('mtschool::setup.year_note_before') }} <strong>{{ __('mtschool::setup.year_note_bold') }}</strong>{{ __('mtschool::setup.year_note_after') }}
                    </p>
                    <p class="text-xs mt-text-muted">
                        {{ __('mtschool::setup.sy_next_years_hint') }}
                    </p>
                </div>
            @endif

            {{-- ── STEP 2 : Langues d'enseignement (conditionnent le nom multilingue) ── --}}
            @if($currentStep === 2)
                <div class="space-y-3">
                    @if($errors->has('teaching_languages'))
                        <p class="text-sm" style="color:rgb(var(--mt-danger))">
                            {{ $errors->first('teaching_languages') }}
                        </p>
                    @endif
                    @foreach($availableLanguages as $code => $label)
                        <label class="flex items-center gap-3 p-4 rounded-xl cursor-pointer transition-colors"
                               style="border: 1px solid {{ in_array($code, $teaching_languages) ? 'rgb(var(--mt-primary))' : 'rgb(var(--mt-ui-card-border))' }};
                                      background: {{ in_array($code, $teaching_languages) ? 'rgba(var(--mt-primary),0.06)' : 'transparent' }}">
                            <input
                                type="checkbox"
                                wire:model="teaching_languages"
                                value="{{ $code }}"
                                class="rounded mt-checkbox"
                            />
                            <div>
                                <div class="font-medium mt-text">{{ $label }}</div>
                                <div class="text-xs mt-text-muted uppercase tracking-widest">{{ $code }}</div>
                            </div>
                        </label>
                    @endforeach
                    <p class="text-xs mt-text-muted mt-2">
                        {{ __('mtschool::setup.languages_note') }}
                    </p>
                </div>
            @endif

            {{-- ── STEP 5 : Cycle ─────────────────────────────────────────── --}}
            @if($currentStep === 5)
                <div class="space-y-4">

                    @if($errors->has('selected_cycle_types'))
                        <p class="text-sm" style="color:rgb(var(--mt-danger))">
                            {{ $errors->first('selected_cycle_types') }}
                        </p>
                    @endif

                    {{-- MULTI-SÉLECTION : un complexe scolaire combine plusieurs cycles.
                         Si l'offre est restreinte (config setup.cycles, ex. supérieur absent),
                         une note « à venir » s'affiche en plus. --}}
                    @if(count($cyclePresets) > 1)
                        <p class="text-sm mt-text-muted">{{ __('mtschool::setup.cycles_multi_hint') }}</p>
                    @endif
                    @if($cyclesRestricted)
                        <p class="text-xs mt-text-muted">{{ __('mtschool::setup.cycles_limited_note') }}</p>
                    @endif

                    <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        @foreach($cyclePresets as $type => $preset)
                            @php $isSelected = in_array($type, $selected_cycle_types, true); @endphp
                            <button
                                type="button"
                                wire:click="toggleCycle('{{ $type }}')"
                                class="text-left p-4 rounded-xl transition-all duration-200 w-full"
                                style="
                                    border: 2px solid {{ $isSelected ? 'rgb(var(--mt-primary))' : 'rgb(var(--mt-ui-card-border))' }};
                                    background: {{ $isSelected ? 'rgba(var(--mt-primary),0.07)' : 'transparent' }};
                                "
                            >
                                <div class="flex items-start gap-3">
                                    {{-- SVG inline (mask CSS = carré plein ; --mt-ui-muted n'existe pas comme token) --}}
                                    <x-mt::icon :name="$preset['icon']" class="shrink-0 mt-0.5"
                                                style="color: {{ $isSelected ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text), 0.55)' }}" />
                                    <div class="min-w-0">
                                        <div class="font-semibold text-sm mt-text flex items-center gap-2">
                                            {{ $preset['label'] }}
                                            <span class="text-xs font-mono px-1.5 py-0.5 rounded"
                                                  style="background:rgba(var(--mt-ui-card-border),0.8); color:rgb(var(--mt-ui-muted))">
                                                {{ $preset['code'] }}
                                            </span>
                                        </div>
                                        <div class="text-xs mt-text-muted mt-0.5">{{ $preset['description'] }}</div>
                                        <div class="text-xs mt-text-muted mt-1">
                                            {{ __('mtschool::setup.levels_proposed', ['count' => count($preset['grades'])]) }}
                                        </div>
                                    </div>
                                    @if($isSelected)
                                        <span class="ml-auto shrink-0" style="color:rgb(var(--mt-primary))"><x-mt::icon name="check" size="md" /></span>
                                    @endif
                                </div>
                            </button>
                        @endforeach
                    </div>

                    <p class="text-xs mt-text-muted">
                        {{ __('mtschool::setup.cycle_note_before') }} <strong>{{ __('mtschool::setup.cycle_note_bold') }}</strong>{{ __('mtschool::setup.cycle_note_after') }}
                    </p>
                </div>
            @endif

            {{-- ── STEP 6 : Niveaux ───────────────────────────────────────── --}}
            @if($currentStep === 6)
                <div class="space-y-4">

                    @if($errors->has('selected_grade_levels'))
                        <p class="text-sm" style="color:rgb(var(--mt-danger))">
                            {{ $errors->first('selected_grade_levels') }}
                        </p>
                    @endif

                    {{-- Niveaux GROUPÉS PAR CYCLE coché (complexe scolaire = plusieurs sections) --}}
                    @foreach($gradePresetsByCycle as $ctype => $cpreset)
                        <div class="flex items-center gap-2 p-3 rounded-xl text-sm"
                             style="background: rgba(var(--mt-primary),0.06); border:1px solid rgba(var(--mt-primary),0.15)">
                            <span class="shrink-0" style="color:rgb(var(--mt-primary))"><x-mt::icon :name="$cpreset['icon']" size="sm" /></span>
                            <span class="font-medium mt-text">{{ $cpreset['label'] }}</span>
                            <span class="text-xs font-mono ml-auto mt-text-muted">{{ $cpreset['code'] }}</span>
                        </div>

                        <div class="grid grid-cols-1 gap-2 sm:grid-cols-2">
                            @foreach($cpreset['grades'] as $code => $label)
                                @php $isChecked = in_array($code, $selected_grade_levels[$ctype] ?? []); @endphp
                                <label class="flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-colors"
                                       style="
                                           border: 1px solid {{ $isChecked ? 'rgb(var(--mt-primary))' : 'rgb(var(--mt-ui-card-border))' }};
                                           background: {{ $isChecked ? 'rgba(var(--mt-primary),0.05)' : 'transparent' }};
                                       ">
                                    <input
                                        type="checkbox"
                                        wire:model.live="selected_grade_levels.{{ $ctype }}"
                                        value="{{ $code }}"
                                        class="rounded mt-checkbox"
                                    />
                                    <div class="min-w-0">
                                        <div class="text-sm font-medium mt-text">{{ $label }}</div>
                                        <div class="text-xs font-mono mt-text-muted">{{ $code }}</div>
                                    </div>
                                </label>
                            @endforeach
                        </div>
                    @endforeach

                    <p class="text-xs mt-text-muted">
                        {{ __('mtschool::setup.levels_selected', ['count' => collect($selected_grade_levels)->flatten()->count()]) }}
                        {{ __('mtschool::setup.levels_note_before') }} <strong>{{ __('mtschool::setup.levels_note_bold') }}</strong>{{ __('mtschool::setup.levels_note_after') }}
                    </p>

                    {{-- Pré-remplissage de données types --}}
                    <label class="mt-5 flex items-start gap-3 rounded-xl border p-4 cursor-pointer"
                           style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
                        <input type="checkbox" wire:model="prefill_reference" class="mt-1">
                        <span>
                            <span class="block text-sm font-medium mt-text">{{ __('mtschool::setup.prefill_title') }}</span>
                            <span class="block text-xs mt-text-muted mt-0.5">{{ __('mtschool::setup.prefill_hint') }}</span>
                        </span>
                    </label>
                </div>
            @endif

            {{-- ── Boutons de navigation ──────────────────────────────────── --}}
            <div class="flex items-center justify-between mt-8 pt-6"
                 style="border-top: 1px solid rgb(var(--mt-ui-card-border))">

                {{-- Précédent --}}
                <div>
                    @if($currentStep > 1)
                        <x-mt::button
                            type="button"
                            wire:click="previous"
                            variant="outline"
                            icon="chevron-left"
                            label="{{ __('mtschool::setup.previous') }}"
                        />
                    @endif
                </div>

                {{-- Suivant / Terminer --}}
                <div>
                    @if($currentStep < $totalSteps)
                        <x-mt::button
                            type="button"
                            wire:click="next"
                            wire:loading.attr="disabled"
                            wire:target="next"
                            variant="primary"
                            endIcon="chevron-right"
                            label="{{ $currentStep === 1 ? __('mtschool::setup.start') : __('mtschool::setup.next') }}"
                        />
                    @else
                        <x-mt::button
                            type="button"
                            wire:click="complete"
                            :loading="'complete'"
                            variant="success"
                            icon="check"
                            label="{{ __('mtschool::setup.complete') }}"
                        />
                    @endif
                </div>
            </div>

            {{-- Message de création : PLEINE LARGEUR sous les boutons (hors de la rangée flex
                 justify-between, sinon il se coince en 3e colonne et chevauche « Terminer »).
                 Préremplir plusieurs cycles prend plusieurs minutes → rassure l'utilisateur. --}}
            <div wire:loading wire:target="complete"
                 class="mt-4 flex items-center gap-3 rounded-xl p-4 text-sm"
                 style="background: rgba(var(--mt-primary),0.06); border:1px solid rgba(var(--mt-primary),0.15)">
                <svg class="w-4 h-4 shrink-0 animate-spin" style="color: rgb(var(--mt-primary))" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                </svg>
                <span class="mt-text">{{ __('mtschool::setup.completing_hint') }}</span>
            </div>
        </div>

        {{-- Footer --}}
        <p class="mt-4 text-center text-xs mt-text-muted">
            {{ __('mtschool::setup.footer') }}
        </p>
    </div>
</div>
