<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $subjectLine }}</title>
</head>
<body style="margin:0; padding:0; background:#f4f5f7; font-family: Arial, Helvetica, sans-serif; color:#1a1a1a;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7; padding:24px 0;">
        <tr>
            <td align="center">
                <table role="presentation" width="560" cellpadding="0" cellspacing="0"
                       style="width:560px; max-width:92%; background:#ffffff; border-radius:12px; overflow:hidden; border:1px solid #e6e8eb;">
                    {{-- En-tête / marque --}}
                    <tr>
                        <td style="background:#111827; padding:18px 28px;">
                            <span style="color:#ffffff; font-size:16px; font-weight:bold;">{{ $brand ?: config('app.name') }}</span>
                        </td>
                    </tr>
                    {{-- Corps --}}
                    <tr>
                        <td style="padding:28px;">
                            <h1 style="margin:0 0 12px; font-size:18px; color:#111827;">{{ $subjectLine }}</h1>
                            @if ($bodyText)
                                <p style="margin:0 0 20px; font-size:14px; line-height:1.6; color:#374151;">{{ $bodyText }}</p>
                            @endif
                            @if ($actionUrl)
                                <table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 4px;">
                                    <tr>
                                        <td style="background:#2563eb; border-radius:8px;">
                                            <a href="{{ $actionUrl }}"
                                               style="display:inline-block; padding:11px 22px; font-size:14px; font-weight:bold; color:#ffffff; text-decoration:none;">
                                                {{ __('mtschool::portal.open') }}
                                            </a>
                                        </td>
                                    </tr>
                                </table>
                            @endif
                        </td>
                    </tr>
                    {{-- Pied --}}
                    <tr>
                        <td style="padding:16px 28px; border-top:1px solid #eef0f2; background:#fafbfc;">
                            <p style="margin:0; font-size:11px; color:#9ca3af;">{{ __('mtschool::portal.email_footer') }}</p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
