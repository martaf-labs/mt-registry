@php $__loc = app()->getLocale(); $__rtl = in_array($__loc, ['ar', 'fa', 'he', 'ur', 'ps', 'ku', 'dv'], true); @endphp
<!DOCTYPE html>
<html lang="{{ $__loc }}" dir="{{ $__rtl ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 13px; color: #1a1a1a; margin: 0; }
        .page { padding: 48px 56px; }
        .head { width: 100%; border-bottom: 2px solid #333; padding-bottom: 14px; margin-bottom: 40px; text-align: center; }
        .school { font-size: 20px; font-weight: bold; letter-spacing: .5px; }
        .ref { color: #666; font-size: 11px; margin-top: 4px; }
        .title { text-align: center; font-size: 22px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin: 30px 0 40px; }
        .body { font-size: 14px; line-height: 2; text-align: justify; margin: 0 8px; }
        .body .name { font-weight: bold; }
        .meta { margin-top: 40px; font-size: 13px; }
        .meta td { padding: 4px 0; }
        .place-date { text-align: right; margin-top: 48px; font-size: 13px; }
        .sign { text-align: right; margin-top: 8px; font-size: 13px; }
        .sign .line { display: inline-block; width: 220px; border-top: 1px solid #999; margin-top: 60px; padding-top: 6px; text-align: center; color: #444; }
        .foot { margin-top: 60px; border-top: 1px solid #ddd; padding-top: 10px; font-size: 10px; color: #999; text-align: center; }
    </style>
</head>
<body>
    <div class="page">
        <div class="head">
            <div class="school">{{ $schoolName }}</div>
            <div class="ref">{{ __('mtschool::documents.cert_reference') }} : {{ $data['ref'] }}</div>
        </div>

        <div class="title">{{ $data['title'] }}</div>

        <div class="body">
            <p>{{ $data['body'] }}</p>
        </div>

        <table class="meta">
            <tr>
                <td style="width:120px; color:#666;">{{ __('mtschool::documents.student') }}</td>
                <td><strong>{{ $data['student'] }}</strong></td>
            </tr>
            <tr>
                <td style="color:#666;">{{ __('mtschool::documents.classroom') }}</td>
                <td>{{ $data['class'] ?: '—' }}</td>
            </tr>
            <tr>
                <td style="color:#666;">{{ __('mtschool::documents.school_year') }}</td>
                <td>{{ $data['year'] ?: '—' }}</td>
            </tr>
        </table>

        <div class="place-date">{{ __('mtschool::documents.cert_done_on', ['date' => $data['issued']]) }}</div>
        <div class="sign"><span class="line">{{ __('mtschool::documents.head_of_school') }}</span></div>

        <div class="foot">{{ __('mtschool::documents.cert_footer') }}</div>
    </div>
</body>
</html>
