@php $__loc = app()->getLocale(); $__rtl = in_array($__loc, ['ar', 'fa', 'he', 'ur', 'ps', 'ku', 'dv'], true); @endphp
<!DOCTYPE html>
<html lang="{{ $__loc }}" dir="{{ $__rtl ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #1a1a1a; margin: 0; }
        .card { padding: 24px 28px; page-break-after: always; }
        .card:last-child { page-break-after: auto; }
        .head { width: 100%; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 14px; }
        .head td { vertical-align: middle; }
        .school { font-size: 17px; font-weight: bold; }
        .sub { color: #666; font-size: 10px; }
        .period { text-align: right; }
        .period .p1 { font-weight: bold; }
        .ident { width: 100%; margin-bottom: 12px; }
        .ident td { padding: 2px 0; font-size: 11px; }
        .muted { color: #666; }
        table.grades { width: 100%; border-collapse: collapse; margin-bottom: 14px; }
        table.grades th { text-align: left; border-bottom: 2px solid #333; padding: 6px 4px; font-size: 10px; color: #444; }
        table.grades td { padding: 6px 4px; border-bottom: 1px solid #e2e2e2; }
        table.grades .c { text-align: center; }
        table.grades .annual { font-weight: bold; }
        .synth { width: 100%; margin: 10px 0; }
        .synth td { width: 33%; padding: 10px; text-align: center; border: 1px solid #ddd; }
        .synth .big { font-size: 22px; font-weight: bold; }
        .synth .lbl { font-size: 9px; color: #666; }
        .deci { margin-top: 12px; border: 1px solid #ddd; padding: 12px; text-align: center; font-size: 14px; }
        .deci .lbl { font-size: 9px; color: #666; display: block; margin-bottom: 4px; }
        .deci strong { font-size: 16px; }
        .sign { width: 100%; margin-top: 26px; font-size: 10px; color: #555; }
        .sign td { width: 50%; text-align: center; padding-top: 28px; border-top: 1px solid #ccc; }
    </style>
</head>
<body>
@php
    $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v;
    $fmt = fn($v) => $v === null ? '—' : number_format((float) $v, 2, ',', ' ');
@endphp
@foreach ($cards as $c)
    @php $e = $c['enrollment']; $rows = $c['rows']; $result = $c['result']; @endphp
    <div class="card">
        {{-- En-tête --}}
        <table class="head"><tr>
            <td><div class="school">{{ $schoolName }}</div><div class="sub">{{ __('mtschool::documents.annual_report_card_title') }}</div></td>
            <td class="period"><div class="p1">{{ $schoolYear }}</div></td>
        </tr></table>

        {{-- Identité --}}
        <table class="ident"><tr>
            <td><span class="muted">{{ __('mtschool::documents.student') }} :</span> <strong>{{ $e->student?->full_name_reverse ?? $e->student?->full_name }}</strong></td>
            <td style="text-align:right"><span class="muted">{{ __('mtschool::documents.classroom') }} :</span> <strong>{{ $loc($e->classroom?->label) }}</strong></td>
        </tr><tr>
            <td><span class="muted">{{ __('mtschool::documents.reference') }} :</span> {{ $e->student?->reference ?? '—' }}</td>
            <td style="text-align:right"><span class="muted">{{ __('mtschool::documents.class_size') }} :</span> {{ $c['class_size'] ?? '—' }}</td>
        </tr></table>

        {{-- Matières : une colonne par période + moyenne annuelle --}}
        <table class="grades">
            <thead><tr>
                <th>{{ __('mtschool::documents.subject') }}</th>
                @foreach ($periods as $p)
                    <th class="c">{{ $loc($p->label) }}</th>
                @endforeach
                <th class="c">{{ __('mtschool::documents.coefficient_short') }}</th>
                <th class="c">{{ __('mtschool::documents.annual_average') }}</th>
            </tr></thead>
            <tbody>
            @forelse ($rows as $r)
                <tr>
                    <td>{{ $loc($r['subject']?->label) }}</td>
                    @foreach ($periods as $p)
                        <td class="c">{{ $fmt($r['periods'][$p->id] ?? null) }}</td>
                    @endforeach
                    <td class="c">{{ rtrim(rtrim((string) $r['coef'], '0'), '.') }}</td>
                    <td class="c annual">{{ $fmt($r['annual']) }}</td>
                </tr>
            @empty
                <tr><td colspan="{{ $periods->count() + 3 }}" class="c muted">{{ __('mtschool::documents.no_data') }}</td></tr>
            @endforelse
            </tbody>
        </table>

        {{-- Synthèse annuelle --}}
        <table class="synth"><tr>
            <td><div class="big">{{ $fmt($c['annual_average']) }}</div><div class="lbl">{{ __('mtschool::documents.annual_average') }}</div></td>
            <td><div class="big">{{ $c['annual_rank'] ?? '—' }}@if(!is_null($c['annual_rank']))/{{ $c['class_size'] }}@endif</div><div class="lbl">{{ __('mtschool::documents.annual_rank') }}</div></td>
            <td><div class="big" style="font-size:15px">{{ $result?->label() ?? '—' }}</div><div class="lbl">{{ __('mtschool::documents.decision') }}</div></td>
        </tr></table>

        <table class="sign"><tr>
            <td>{{ __('mtschool::documents.main_teacher') }}</td>
            <td>{{ __('mtschool::documents.head_of_school') }}</td>
        </tr></table>
    </div>
@endforeach
</body>
</html>
