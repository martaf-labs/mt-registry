@php $__loc = app()->getLocale(); $__rtl = in_array($__loc, ['ar', 'fa', 'he', 'ur', 'ps', 'ku', 'dv'], true); @endphp
<!DOCTYPE html>
<html lang="{{ $__loc }}" dir="{{ $__rtl ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #1a1a1a; margin: 0; }
        .card { padding: 24px 28px; page-break-after: always; }
        .card:last-child { page-break-after: auto; }
        .head { width: 100%; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 14px; }
        .head td { vertical-align: middle; }
        .school { font-size: 17px; font-weight: bold; }
        .sub { color: #666; font-size: 10px; }
        .period { text-align: right; }
        .period .p1 { font-weight: bold; }
        .ident { width: 100%; margin-bottom: 12px; }
        .ident td { padding: 2px 0; font-size: 11px; }
        .muted { color: #666; }
        table.grades { width: 100%; border-collapse: collapse; margin-bottom: 14px; }
        table.grades th { text-align: left; border-bottom: 2px solid #333; padding: 6px 4px; font-size: 10px; color: #444; }
        table.grades td { padding: 6px 4px; border-bottom: 1px solid #e2e2e2; }
        table.grades .c { text-align: center; }
        table.grades tfoot td { border-top: 2px solid #333; font-weight: bold; }
        .appr { font-size: 9px; color: #555; font-style: italic; }
        .synth { width: 100%; margin: 10px 0; }
        .synth td { width: 33%; padding: 10px; text-align: center; border: 1px solid #ddd; }
        .synth .big { font-size: 22px; font-weight: bold; }
        .synth .lbl { font-size: 9px; color: #666; }
        .stats { width: 100%; font-size: 10px; color: #555; text-align: center; margin-top: 6px; }
        .stats td { padding: 2px; }
        .apprbox { margin-top: 14px; border: 1px solid #ddd; padding: 10px; }
        .apprbox .t { font-weight: bold; margin-bottom: 4px; }
        .deci { margin-top: 6px; font-weight: bold; }
        .sign { width: 100%; margin-top: 26px; font-size: 10px; color: #555; }
        .sign td { width: 50%; text-align: center; padding-top: 28px; border-top: 1px solid #ccc; }
    </style>
</head>
<body>
@foreach ($cards as $c)
    @php
        $e = $c['enrollment']; $p = $c['period']; $subs = $c['subjects']; $pa = $c['periodAverage'];
        $loc = fn($v) => is_array($v) ? ($v[app()->getLocale()] ?? $v['fr'] ?? reset($v) ?: '') : (string) $v;
    @endphp
    <div class="card">
        {{-- En-tête --}}
        <table class="head"><tr>
            <td><div class="school">{{ $schoolName }}</div><div class="sub">{{ __('mtschool::documents.report_card_title') }}</div></td>
            <td class="period"><div class="p1">{{ $loc($p->label) }}</div><div class="sub">{{ $schoolYear }}</div></td>
        </tr></table>

        {{-- Identité --}}
        <table class="ident"><tr>
            <td><span class="muted">{{ __('mtschool::documents.student') }} :</span> <strong>{{ $e->student?->full_name_reverse ?? $e->student?->full_name }}</strong></td>
            <td style="text-align:right"><span class="muted">{{ __('mtschool::documents.classroom') }} :</span> <strong>{{ $loc($e->classroom?->label) }}</strong></td>
        </tr><tr>
            <td><span class="muted">{{ __('mtschool::documents.reference') }} :</span> {{ $e->student?->reference ?? '—' }}</td>
            <td style="text-align:right"><span class="muted">{{ __('mtschool::documents.class_size') }} :</span> {{ $pa?->class_size ?? '—' }}</td>
        </tr></table>

        {{-- Matières --}}
        <table class="grades">
            <thead><tr>
                <th>{{ __('mtschool::documents.subject') }}</th><th class="c">{{ __('mtschool::documents.average_short') }}</th><th class="c">{{ __('mtschool::documents.coefficient_short') }}</th>
                <th class="c">{{ __('mtschool::documents.weighted_short') }}</th><th class="c">{{ __('mtschool::documents.rank') }}</th><th class="c">{{ __('mtschool::documents.class_average_short') }}</th>
            </tr></thead>
            <tbody>
            @foreach ($subs as $sa)
                <tr>
                    <td>{{ $loc($sa->subject?->label) }}
                        @if($loc($sa->appreciation))<div class="appr">{{ $loc($sa->appreciation) }}</div>@endif
                    </td>
                    <td class="c"><strong>{{ number_format((float) $sa->average, 2, ',', ' ') }}</strong></td>
                    <td class="c">{{ rtrim(rtrim((string) $sa->coefficient, '0'), '.') }}</td>
                    <td class="c">{{ number_format((float) $sa->weighted_average, 2, ',', ' ') }}</td>
                    <td class="c">{{ $sa->rank }}</td>
                    <td class="c">{{ $sa->class_average !== null ? number_format((float) $sa->class_average, 2, ',', ' ') : '—' }}</td>
                </tr>
            @endforeach
            </tbody>
            @if($pa)
            <tfoot><tr>
                <td>{{ __('mtschool::common.total') }}</td><td></td>
                <td class="c">{{ rtrim(rtrim((string) $pa->total_coefficients, '0'), '.') }}</td>
                <td class="c">{{ number_format((float) $pa->total_points, 2, ',', ' ') }}</td>
                <td colspan="2"></td>
            </tr></tfoot>
            @endif
        </table>

        @if($pa)
            {{-- Synthèse --}}
            <table class="synth"><tr>
                <td><div class="big">{{ number_format((float) $pa->overall_average, 2, ',', ' ') }}</div><div class="lbl">{{ __('mtschool::documents.overall_average') }}</div></td>
                <td><div class="big">{{ $pa->rank }}/{{ $pa->class_size }}</div><div class="lbl">{{ __('mtschool::documents.rank') }}</div></td>
                <td><div class="big" style="font-size:15px">{{ $pa->mention?->label() ?? '—' }}</div><div class="lbl">{{ __('mtschool::documents.mention') }}</div></td>
            </tr></table>
            <table class="stats"><tr>
                <td>{{ __('mtschool::documents.class_average') }} : <strong>{{ number_format((float) $pa->class_average, 2, ',', ' ') }}</strong></td>
                <td>{{ __('mtschool::documents.highest') }} : <strong>{{ number_format((float) $pa->class_max_average, 2, ',', ' ') }}</strong></td>
                <td>{{ __('mtschool::documents.lowest') }} : <strong>{{ number_format((float) $pa->class_min_average, 2, ',', ' ') }}</strong></td>
            </tr></table>

            {{-- Appréciation --}}
            <div class="apprbox">
                <div class="t">{{ __('mtschool::documents.council_assessment') }}</div>
                <div>{{ $loc($pa->overall_assessment) ?: '—' }}</div>
                @if($pa->council_decision)<div class="deci">{{ __('mtschool::documents.distinction') }} : {{ $pa->council_decision }}</div>@endif
            </div>
        @endif

        <table class="sign"><tr>
            <td>{{ __('mtschool::documents.main_teacher') }}</td>
            <td>{{ __('mtschool::documents.head_of_school') }}</td>
        </tr></table>
    </div>
@endforeach
</body>
</html>
