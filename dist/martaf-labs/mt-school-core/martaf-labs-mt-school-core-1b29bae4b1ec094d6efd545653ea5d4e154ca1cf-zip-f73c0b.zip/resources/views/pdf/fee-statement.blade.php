<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #1a1a1a; margin: 0; padding: 24px 28px; }
        .head { width: 100%; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 14px; }
        .head td { vertical-align: middle; }
        .school { font-size: 17px; font-weight: bold; }
        .sub { color: #666; font-size: 10px; }
        .muted { color: #666; }
        .ident { width: 100%; margin-bottom: 14px; }
        .ident td { padding: 2px 0; }
        h3 { font-size: 12px; margin: 16px 0 6px; }
        table.t { width: 100%; border-collapse: collapse; }
        table.t th { text-align: left; border-bottom: 2px solid #333; padding: 6px 4px; font-size: 10px; color: #444; }
        table.t td { padding: 6px 4px; border-bottom: 1px solid #e2e2e2; }
        table.t .r { text-align: right; }
        table.t tfoot td { border-top: 2px solid #333; font-weight: bold; }
        .pill { font-size: 9px; padding: 1px 5px; border-radius: 8px; }
        .paid { background:#dcfce7; color:#166534; }
        .partial { background:#fef9c3; color:#854d0e; }
        .pending { background:#fee2e2; color:#991b1b; }
        .totbox { margin-top: 12px; width: 100%; }
        .totbox td { width: 33%; text-align: center; padding: 8px; border: 1px solid #ddd; }
        .totbox .big { font-size: 16px; font-weight: bold; }
        .totbox .lbl { font-size: 9px; color: #666; }
    </style>
</head>
<body>
    @php
        $loc = fn($v) => is_array($v) ? ($v['fr'] ?? reset($v) ?: '') : (string) $v;
        $methods = ['cash'=>__('mtschool::documents.method_cash'),'mobile_money'=>__('mtschool::documents.method_mobile_money'),'bank_transfer'=>__('mtschool::documents.method_bank_transfer'),'check'=>__('mtschool::documents.method_check'),'card'=>__('mtschool::documents.method_card'),'other'=>__('mtschool::documents.method_other')];
        $statusLbl = ['paid'=>__('mtschool::documents.status_paid'),'partial'=>__('mtschool::documents.status_partial'),'pending'=>__('mtschool::documents.status_pending'),'exempt'=>__('mtschool::documents.status_exempt'),'cancelled'=>__('mtschool::documents.status_cancelled')];
        $totDue = $fees->sum('net_amount'); $totPaid = $fees->sum('amount_paid'); $totRem = $fees->sum('remaining_amount');
    @endphp

    <table class="head"><tr>
        <td><div class="school">{{ $schoolName }}</div><div class="sub">{{ __('mtschool::documents.fee_statement_title') }}</div></td>
        <td style="text-align:right" class="sub">{{ $schoolYear }}<br>{{ __('mtschool::documents.edited_on') }} {{ now()->format('d/m/Y') }}</td>
    </tr></table>

    <table class="ident"><tr>
        <td><span class="muted">{{ __('mtschool::documents.student') }} :</span> <strong>{{ $enrollment->student?->full_name_reverse ?? $enrollment->student?->full_name }}</strong></td>
        <td style="text-align:right"><span class="muted">{{ __('mtschool::documents.classroom') }} :</span> <strong>{{ $loc($enrollment->classroom?->label) }}</strong></td>
    </tr><tr>
        <td><span class="muted">{{ __('mtschool::documents.reference') }} :</span> {{ $enrollment->student?->reference ?? '—' }}</td>
    </tr></table>

    <h3>{{ __('mtschool::documents.fees') }}</h3>
    <table class="t">
        <thead><tr>
            <th>{{ __('mtschool::documents.col_type') }}</th><th class="r">{{ __('mtschool::documents.gross') }}</th><th class="r">{{ __('mtschool::documents.discount') }}</th><th class="r">{{ __('mtschool::documents.net') }}</th>
            <th class="r">{{ __('mtschool::documents.paid') }}</th><th class="r">{{ __('mtschool::documents.remaining') }}</th><th>{{ __('mtschool::documents.col_status') }}</th>
        </tr></thead>
        <tbody>
        @forelse ($fees as $f)
            <tr>
                <td>{{ $loc($f->feeType?->label) }}</td>
                <td class="r">{{ number_format((float) $f->gross_amount, 0, ',', ' ') }}</td>
                <td class="r">{{ number_format((float) $f->discount, 0, ',', ' ') }}</td>
                <td class="r">{{ number_format((float) $f->net_amount, 0, ',', ' ') }}</td>
                <td class="r">{{ number_format((float) $f->amount_paid, 0, ',', ' ') }}</td>
                <td class="r">{{ number_format((float) $f->remaining_amount, 0, ',', ' ') }}</td>
                <td><span class="pill {{ $f->status?->value ?? $f->status }}">{{ $statusLbl[$f->status?->value ?? $f->status] ?? '' }}</span></td>
            </tr>
        @empty
            <tr><td colspan="7" style="text-align:center; color:#888; padding:14px">{{ __('mtschool::documents.no_fees') }}</td></tr>
        @endforelse
        </tbody>
        <tfoot><tr>
            <td>{{ __('mtschool::documents.total') }}</td><td class="r"></td><td class="r"></td>
            <td class="r">{{ number_format((float) $totDue, 0, ',', ' ') }}</td>
            <td class="r">{{ number_format((float) $totPaid, 0, ',', ' ') }}</td>
            <td class="r">{{ number_format((float) $totRem, 0, ',', ' ') }}</td>
            <td></td>
        </tr></tfoot>
    </table>

    <table class="totbox"><tr>
        <td><div class="big">{{ number_format((float) $totDue, 0, ',', ' ') }}</div><div class="lbl">{{ __('mtschool::documents.total_due') }}</div></td>
        <td><div class="big">{{ number_format((float) $totPaid, 0, ',', ' ') }}</div><div class="lbl">{{ __('mtschool::documents.collected') }}</div></td>
        <td><div class="big">{{ number_format((float) $totRem, 0, ',', ' ') }}</div><div class="lbl">{{ __('mtschool::documents.remaining_to_pay') }}</div></td>
    </tr></table>

    @if ($payments->isNotEmpty())
        <h3>{{ __('mtschool::documents.payments') }}</h3>
        <table class="t">
            <thead><tr><th>{{ __('mtschool::documents.date') }}</th><th>{{ __('mtschool::documents.payment_reference') }}</th><th>{{ __('mtschool::documents.method') }}</th><th class="r">{{ __('mtschool::documents.amount') }}</th></tr></thead>
            <tbody>
            @foreach ($payments as $p)
                <tr>
                    <td>{{ $p->payment_date?->format('d/m/Y') }}</td>
                    <td>{{ $p->reference }}</td>
                    <td>{{ $methods[$p->payment_method?->value ?? $p->payment_method] ?? '' }}</td>
                    <td class="r">{{ number_format((float) $p->amount, 0, ',', ' ') }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    @endif
</body>
</html>
