{{--
    Widget « mise en route » du dashboard : la chaîne de prérequis dans l'ordre
    recommandé (PrerequisiteService::checklist). Chaque étape non faite est un lien
    direct vers l'écran concerné. Le widget disparaît quand tout est en place.
    $steps = [['key','label','met','url'], …]
--}}
@php $done = collect($steps)->where('met', true)->count(); @endphp

<div class="mb-3 flex items-center justify-between">
    <span class="text-xs mt-text-muted">{{ $done }} / {{ count($steps) }}</span>
    <div class="h-1.5 w-32 overflow-hidden rounded-full" style="background: rgba(var(--mt-text), 0.08)">
        <div class="h-full rounded-full" style="width: {{ count($steps) ? (int) round($done / count($steps) * 100) : 0 }}%; background: rgb(var(--mt-success))"></div>
    </div>
</div>

<ul class="space-y-1.5">
    @foreach($steps as $step)
        <li>
            @if($step['met'])
                <div class="flex items-center gap-2.5 rounded-lg px-2 py-1.5">
                    <span class="shrink-0" style="color: rgb(var(--mt-success))"><x-mt::icon name="check-circle" size="sm" /></span>
                    <span class="text-sm mt-text-muted" style="text-decoration: line-through">{{ $step['label'] }}</span>
                </div>
            @else
                <a href="{{ $step['url'] }}" wire:navigate
                   class="flex items-center gap-2.5 rounded-lg px-2 py-1.5 transition-colors"
                   onmouseover="this.style.background='rgba(var(--mt-text),0.05)'" onmouseout="this.style.background=''">
                    <span class="shrink-0 mt-text-muted"><x-mt::icon name="x-circle" size="sm" /></span>
                    <span class="text-sm mt-text">{{ $step['label'] }}</span>
                    <span class="ml-auto shrink-0 mt-text-muted"><x-mt::icon name="chevron-right" size="sm" /></span>
                </a>
            @endif
        </li>
    @endforeach
</ul>
