<div class="space-y-3">
    <div class="flex items-center gap-2">
        <span class="rounded-lg px-2.5 py-1 text-sm font-semibold"
              style="background: rgba(var(--mt-primary),0.12); color: rgb(var(--mt-primary))">
            {{ $planName ?? '—' }}
        </span>
        <span class="text-xs mt-text-muted">
            {{ $status === 'active' ? __('mtschool::common.active') : $status }}
        </span>
    </div>

    <dl class="space-y-1.5 text-sm">
        <div class="flex items-center justify-between gap-2">
            <dt class="mt-text-muted">{{ __('mtschool::dashboard.plan_valid_until') }}</dt>
            <dd class="font-medium mt-text">{{ $endsAt ? $endsAt->format('d/m/Y') : '—' }}</dd>
        </div>
        <div class="flex items-center justify-between gap-2">
            <dt class="mt-text-muted">{{ __('mtschool::dashboard.plan_quota') }}</dt>
            <dd class="font-medium mt-text">{{ $maxStudents ? number_format($maxStudents, 0, ',', ' ') : __('mtschool::dashboard.plan_unlimited') }}</dd>
        </div>
        <div class="flex items-center justify-between gap-2">
            <dt class="mt-text-muted">{{ __('mtschool::dashboard.plan_modules') }}</dt>
            <dd class="font-medium mt-text">{{ $moduleCount }}</dd>
        </div>
    </dl>
</div>
