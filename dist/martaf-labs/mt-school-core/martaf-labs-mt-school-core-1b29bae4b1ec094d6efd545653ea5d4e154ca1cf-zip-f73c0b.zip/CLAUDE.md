# mt-school-core — règles de tenantisation (à lire AVANT toute modification)

> Package métier du SaaS multi-tenant `mt-school`. Le north-star complet est dans
> `martaf-cloud/mt-school/CLAUDE.md`. Ici : les règles concrètes côté package.

## Multi-tenant : base de données partagée, tenant = école (`schools`)

Hiérarchie d'isolation : **École (tenant) → Année scolaire → données**.

### Règle d'or
Tout modèle métier appartenant à une école DOIT être cloisonné par `school_id` :

1. Sa table porte une colonne `school_id` (FK `schools`), indexée.
2. Il utilise le trait **`BelongsToSchool`** qui :
   - ajoute un **`SchoolScope` global** filtrant par l'école courante ;
   - **remplit `school_id` à la création** depuis l'école courante (hook `creating`) ;
   - expose la relation `school()`.
   C'est le **miroir exact** de `BelongsToSchoolYear` / `SchoolYearScope`, un cran au-dessus.
3. Les unicités sont **par école** : `Rule::unique(...)->where('school_id', currentSchoolId())`.

### École courante
- = `auth()->user()->school_id`, exposée par `SchoolResolver` / `currentSchool[Id]()`.
- **PRIORITÉ : l'utilisateur authentifié PRIME sur la session.** `users.school_id` est la
  source de vérité ; `session('current_school_id')` n'est qu'un repli (onboarding / contexte
  non authentifié). ⚠️ Si la session prime sur l'auth, une session périmée fait scoper TOUTES
  les requêtes vers la mauvaise école = **fuite de données cross-tenant**. Ne JAMAIS réinverser cet ordre.
- **JAMAIS** `School::where('active', true)->first()` (singleton interdit).
- `School::current()` doit renvoyer l'école **du user connecté**.

### Année scolaire (déjà existant, à tenantiser)
- `school_years` doit porter `school_id` ; `code` unique **par école**.
- `SchoolYearResolver` doit résoudre l'année active **de l'école courante**, pas globalement.
- `BelongsToSchoolYear` reste, mais s'empile SOUS `BelongsToSchool`.

### Données non-tenant (référence globale)
Si une table est volontairement partagée par toutes les écoles (référentiel), le documenter
explicitement et NE PAS y mettre `school_id`. Par défaut, tout est tenant.

## Champs personnalisés par école (EAV)

Chaque école peut définir SES propres champs sur les entités métier (élève, parent,
personnel) **sans toucher au schéma** — pattern EAV inspiré de sgni/core
(GroupeSpecification / ChampSpecification / Specification).

- **3 tables TENANT** (`school_id`, SoftDeletes) : `custom_field_groups` (regroupements
  d'affichage), `custom_fields` (définition : `key` unique par école+entité, `type`,
  `options`, `required`…), `custom_field_values` (1 valeur par champ+entité).
- **`entity_type` = clé LOGIQUE** ('student'|'guardian'|'staff'), jamais le FQCN.
  Mappée vers la classe via `config('mt-school-core.custom_fields.entities')` (refactor-safe).
- **Enum `CustomFieldType`** (text/textarea/number/date/email/phone/toggle/select/multiselect) :
  `cast()`/`serialize()` (multiselect ↔ JSON, toggle ↔ '0'/'1'), `validationRules()`,
  `formType()` (mappe vers le framework de formulaires mt-views).
- **Trait `HasCustomFields`** (sur Student/Guardian/StaffMember) :
  `customFieldDefinitions()` (schéma actif de l'école), `customFieldData()` (valeurs typées
  par clé), `customField($key)`, `saveCustomFields([$key=>$val])` (upsert, **ignore les clés
  non définies**, supprime sur valeur vide). Nettoie les valeurs au `deleting` de l'entité
  (entity_id n'est PAS une FK SQL).
- `CustomField::toFormField()` → schéma de champ prêt pour le base-form mt-views
  (`name` = `custom_fields.<key>`), pour injecter une section dynamique dans les formulaires.
- Isolation vérifiée (école A définit/écrit, école B voit 0 champ / 0 valeur).
- **Module gérable `custom_fields`** (optionnel, inclus dans premium) — route
  `custom-fields` (clé logique `custom_fields`) gatée `middleware('module:custom_fields')`,
  item de menu sous Administration gaté par le même module.
- **UI de définition** : composant dédié `Livewire\Admin\CustomFields\CustomFieldManager`
  (alias `mtschool.admin.custom-fields.manager`) — onglets = type d'entité, groupes +
  champs, modales inline (philosophie « Manager » type sgni ProjetManager). Vérifié de
  bout en bout (Livewire::test : créer groupe + champ select avec options + auto-clé).
- **Injection formulaire** : point d'extension générique ajouté à mt-views `BaseForm`
  (`extraData` + hooks no-op `extraSections()`/`hydrateExtra()`/`persistExtra()`, partial
  `base/partials/extra-sections`). Côté mt-school-core, le trait
  `Livewire\Concerns\InjectsCustomFields` les implémente via le système EAV : il résout
  l'entityType depuis `$this->modelClass`, construit les sections (groupées) depuis les
  définitions actives, hydrate/persiste via `customFieldData()`/`saveCustomFields()`.
  Vérifié (extraSections + hydrate/persist round-trip ; non-régression sur un form existant).
- ⏳ Reste : poser `use InjectsCustomFields` sur les futurs FormComponent CRUD d'entité
  (parent/personnel/édition élève). Le form actuel d'élève est un assistant d'inscription
  (`modelClass=Enrollment`) → pas d'entityState EAV (sections vides, inoffensif).

## Modules & abonnement
- L'accès à une fonctionnalité dépend des **modules du plan de l'école** (table en base),
  pas d'un flag `.env`. `@moduleEnabled('x')` lit l'abonnement du tenant.
- Le menu (`config/sidebar.php`) et les routes doivent se filtrer selon les modules actifs.

## Conventions package
- Livewire : `Livewire\Admin\<Module>\<Module>{Index,Form}Component` ; Forms dans `Livewire\Forms\`.
- Enregistrer chaque composant Livewire dans `MtSchoolCoreServiceProvider` (sinon 419).
- `$translatables` (JSON) : ne jamais relire/réécrire `$model->{champ}` traduisible dans un hook
  (le `__get` aplatit à la locale courante — cf. `capitalizeFields`).
- PSR-4 : une classe par fichier.
- **UI = thème global mt-views (voir §0 du North Star mt-views).** Toute vue de ce package
  (managers inclus) pose son contenu dans `<x-mt::screen>` (organisation base-index, largeur 7xl
  pour les listes/tableaux), n'utilise que les composants mt-views (`empty-state` pour les états
  vides), et respecte tokens `--mt-*` + icônes mt-icons SVG + i18n fr/en/ar. Vérifier qu'une classe
  Tailwind existe dans le mt-views.css servi avant de l'utiliser (beaucoup absentes → style inline).

## Construction des modules (pattern + pièges)

Les **modèles** (55+) préexistent tous ; construire un module = **UI + logique métier**.
**Ordre (dépendances)** : Matières → Enseignants → Affectations → Évaluations+Notes →
Moyennes/Bulletins (= MVP SIS, FAIT) → Présences → Emploi du temps → Finances → Communication.

**Pattern CRUD** (réplique de Subjects/Specializations) :
1. `Livewire/Indexes/XIndex extends GenericIndex` (modelClass, columns, configuration, getStatistics,
   rowActions — `custom` = actions route/livewire vers un Manager).
2. `Livewire/Forms/XForm extends GenericForm` (props publiques, schema(), rules(), save() en transaction).
3. `Livewire/Admin/Xs/Xs{Index,Form}Component` (thin, `extends BaseIndex/BaseForm`).
4. **Manager dédié** (`extends Livewire\Component`) pour l'édition relationnelle inline (coefficients,
   affectations, saisie notes) — style « ProjetManager » : `rows[]` + hook `updated()` + `updateOrCreate`.
5. Enregistrer les alias dans `MtSchoolCoreServiceProvider` (sinon 419) ; routes app + clés
   `config/routes.php` + item `config/sidebar.php` (clé `module` du groupe = gating).

**Pièges à éviter d'emblée :**
- ⚠️ NE PAS redéfinir `getModelId()` (le parent `GenericForm` le fournit en **protected** ; le mettre
  `private` = FatalError). Bug corrigé sur les 6 Forms structure.
- ⚠️ **Champs traduisibles** (`$translatables`) = array `{fr,en}` → règle `array` (jamais `string`),
  bind `champ.fr`, NE PAS re-wrapper en save.
- ⚠️ **Colonnes NOT NULL sans défaut** (ex. `subjects.color`) → défaut dans `save()`. `BaseForm::save()`
  **avale** les exceptions (échec silencieux — piste de debug).
- ⚠️ Unicité d'un code = **par école** : `Rule::unique(...)->where('school_id', currentSchoolId())`.
- ⚠️ **`MtBaseModel` soft-delete TOUS les modèles** (trait hérité, invisible dans le modèle enfant) →
  toute `Rule::unique` DOIT ajouter `->whereNull('deleted_at')`, sinon une ligne supprimée bloque à
  jamais la re-création (vécu : grille tarifaire). Et un `delete()` ne libère PAS la contrainte SQL
  unique si elle existe en base (cf. ReferenceSchoolService : contrôles `withTrashed()`).
- ⚠️ Pivots tenantisés en théorie mais **`curriculum_subject`/`course_assignments` n'ont pas de
  `school_id`** réel → ne pas le passer à `attach()` ; isolation via le parent school-scoped.
- ⚠️ Édition inline en `Livewire::test` : `->set()` déclenche le hook `updated` ; `->call("updated")` interdit.

La **chaîne de coefficients** : `curriculum_subject.coefficient` (maquette) → `CourseAssignment` →
`SubjectAverage.coefficient` → moyenne générale pondérée → bulletin. Calcul = `Services\ReportCardComputer`.

## État actuel
**Toute la colonne vertébrale SIS est FAITE & vérifiée** (cf. §6.B de `martaf-cloud/mt-school/CLAUDE.md`) :
- ✅ Plateforme : `SchoolScope`/`BelongsToSchool`/`SchoolResolver`, 55 tables tenant, abonnements/plans/
  modules, gating menu+routes strict, parcours d'achat, retrait Flux. Isolation vérifiée.
- ✅ Modules : Structure, **Matières**, **Maquette+coefficients**, **Enseignants**, **Affectations**,
  **Évaluations+Saisie notes**, **Moyennes/Rangs/Bulletins**. + EAV champs perso, aide d'usage, icônes.
- ✅ **Modules indépendants (session 2026-07)** : Présences (+ **justificatifs** parent→admin), Emploi du temps
  (grille + **collisions prof/salle** + samedi via `timetable.active_days`), Finances (frais/paiements/bourses/
  échéances + relevé PDF), Communication (annonces + **notifications in-app + e-mail réel**), Pédagogie (portails),
  **Imports pro** (élèves+tuteurs/personnel/matières/affectations, aperçu, export erreurs, **journal `import_logs`**, accès masse).
- ✅ **Consolidation bulletins** : `ReportCard` publiable + **PDF période ET annuel** (`ReportCardService`),
  appréciations, **résultat annuel** (`AnnualResultComputer` : moyenne/rang/décision + **matière éliminatoire**),
  **rendu arabe PDF** (trait `Support\RendersLocalizedPdf` + ar-php).
- ✅ **Fin d'année** : `SchoolYearRolloverService` (clone + promotion + création classe + **report reliquat frais**).
- ✅ **Certificats** : `CertificateService` (+ 4 types + PDF) + `CertificateManager`.
- ✅ **Portails teacher/student/parent — COMPLETS** (voir mémoire [[portals-foundation]]) + provision comptes
  (unitaire + masse via `PortalAccountService::bulkProvision{Guardians,Students}`).
- ✅ **RBAC / délégation d'accès** (voir mémoire [[rbac-permissions-layer]]) : `RoleSchool::permissions()`
  (carte rôle→abilities) + `User::hasPermission()` + `Gate::before` (résout tout `school.*`).
  Menu gaté par PERMISSION (point d'extension mt-views `permission_gate` → `Support\SchoolPermissionGate`,
  clé `permission` sur les items sidebar) ET routes gatées `can:school.X` (host web.php). Écran
  `Livewire\Admin\Team\TeamManager` (route `team`, gaté `can:school.users.manage`) pour créer des comptes
  back-office et attribuer un rôle (comptable/censeur/personnel/directeur). Vérifié : menu + 84 routes,
  0 verrouillage, isolation tenant, anti-verrouillage (n'édite ni soi ni un super_admin).
  ⚠️ Piège : group-gater un groupe de ROUTES mixte = verrouillage d'un rôle à accès partiel (cf. mémoire).
- ⏳ Reste : recette navigateur complète, suite de tests auto étendue, paiement en ligne réel, e-mail en file.

### ⚠️ Pièges enum/colonne récurrents (vérifier au build)
- **Champs castés en enum** (`SchoolFee::status`/FeeStatus, `Payment::payment_method`, `StaffMember::type`/StaffType,
  `Subject::group`/SubjectGroup, `Attendance::status`, `DisciplinarySanction::type`, `Enrollment::result`, `SchoolCertificate` n/a) :
  NE PAS assigner une string arbitraire (ex. « Comptable » sur `type` = `ValueError`) → **mapper vers une valeur
  d'enum valide** ; et pour l'affichage, `->value`/`->label()` (jamais `echo $enum` direct = « could not be converted to string »).
- **Sélection de colonnes** : `classes` a `label` (traduisible), PAS `name` → `->get(['id','code'])` (un `get([...'name'])`
  = 500 au rendu). **Render-tester** les managers à formulaire (`Livewire::test()->html()`), pas seulement leur service.
- **Composants form mt-views** : `x-mt::form.select`/`toggle` acceptent l'attribut `wire:model` ; `date-picker`/`textarea`
  bindent via la **prop `model="prop"`** (@entangle) — un `wire:model` en attribut sur eux = champ NON lié.
