<?php

namespace Mt\MtSchoolCore\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * E-mail d'une notification école (miroir e-mail d'une SchoolNotification).
 *
 * Les propriétés publiques sont exposées à la vue `mtschool::mail.notification`.
 * L'envoi est déclenché par NotificationService uniquement si l'e-mail est activé
 * (config `mt-school-core.notifications.email_enabled`) — sinon rien n'est envoyé.
 */
class SchoolNotificationMail extends Mailable
{
    use Queueable;
    use SerializesModels;

    public function __construct(
        public string $subjectLine,
        public string $bodyText,
        public ?string $actionUrl,
        public string $brand,
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->subjectLine !== '' ? $this->subjectLine : $this->brand,
        );
    }

    public function content(): Content
    {
        return new Content(view: 'mtschool::mail.notification');
    }
}
