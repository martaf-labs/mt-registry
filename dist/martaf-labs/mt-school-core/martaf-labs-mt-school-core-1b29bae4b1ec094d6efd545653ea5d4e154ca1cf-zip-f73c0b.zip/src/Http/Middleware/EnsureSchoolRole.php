<?php

namespace Mt\MtSchoolCore\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Restreint une route à un ou plusieurs rôles d'école (portails).
 * Usage : ->middleware('school_role:parent') ou 'school_role:teacher,student'.
 */
class EnsureSchoolRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $role = $request->user()?->school_role?->value;

        abort_unless($role && in_array($role, $roles, true), 403);

        return $next($request);
    }
}
