<?php

namespace Mt\MtSchoolCore\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Mt\MtSchoolCore\Models\Setting;
use Symfony\Component\HttpFoundation\Response;

class EnsureSetupComplete
{
    public function handle(Request $request, Closure $next): Response
    {
        // Skip setup route itself and all auth/Livewire internals
        if ($request->routeIs('setup.*') || $request->routeIs('setup')) {
            return $next($request);
        }

        if (! Setting::isSetupComplete()) {
            return redirect()->route(config('routes.setup', 'setup'));
        }

        return $next($request);
    }
}
