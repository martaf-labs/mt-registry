<?php

namespace Mt\MtSchoolCore\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Mt\MtSchoolCore\Models\Setting;
use Mt\MtSchoolCore\Support\SchoolResolver;
use Symfony\Component\HttpFoundation\Response;

/**
 * Résout le TENANT (école) à chaque requête web authentifiée.
 *
 * Source de vérité = `users.school_id`. On aligne `session('current_school_id')`
 * dessus pour que le SchoolScope filtre par l'école du user connecté.
 *
 * C'est aussi le point d'accroche futur pour la validation d'abonnement
 * (étapes 4-6 : refuser l'accès si abonnement expiré, gating des modules).
 *
 * À enregistrer dans le groupe 'web' (après le démarrage de session / auth).
 */
class ResolveTenant
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user && $user->school_id) {
            if ((int) session('current_school_id') !== (int) $user->school_id) {
                app(SchoolResolver::class)->setCurrent($user->school_id);
            }

            // Langues d'enseignement PAR ÉCOLE → alimentent les locales disponibles
            // (onglets multilingues des formulaires, sélecteur de langue).
            $this->configureLocales();

            // Menu PAR RÔLE : les portails (parent/élève/enseignant) ont leur propre
            // sidebar (`config/sidebar_<role>.php`). Sinon → menu admin par défaut.
            $this->configureSidebar($user);
        }

        return $next($request);
    }

    /** Bascule le menu sur la sidebar du rôle si elle existe (portails). */
    protected function configureSidebar($user): void
    {
        $role = $user->school_role?->value;
        if ($role && config()->has("sidebar_{$role}")) {
            config(['sidebar' => config("sidebar_{$role}")]);
        }
    }

    /**
     * Branche les langues de l'établissement courant sur app.available_locales.
     * Tenant déjà résolu → Setting est scopé sur la bonne école.
     */
    protected function configureLocales(): void
    {
        try {
            $langs = Setting::getJson('teaching_languages', []);
            if (! empty($langs) && is_array($langs)) {
                config(['app.available_locales' => $langs]);
            }
        } catch (\Throwable) {
            // BDD indisponible / table absente — on ignore.
        }
    }
}
