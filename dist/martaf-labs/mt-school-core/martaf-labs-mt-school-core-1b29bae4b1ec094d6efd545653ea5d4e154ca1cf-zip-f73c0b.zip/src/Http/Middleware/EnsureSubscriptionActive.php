<?php

namespace Mt\MtSchoolCore\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Bloque l'accès à l'app si l'école courante n'a pas d'abonnement VALIDE
 * (actif et non expiré) → redirige vers l'écran de renouvellement.
 *
 * À appliquer sur le groupe applicatif (après auth + ResolveTenant), MAIS PAS
 * sur la route de renouvellement elle-même (sinon boucle de redirection).
 * Les données de l'école sont conservées ; le super-admin peut renouveler.
 */
class EnsureSubscriptionActive
{
    public function handle(Request $request, Closure $next): Response
    {
        $school = currentSchool();

        // Pas d'école résolue (onboarding avant rattachement) → on laisse passer.
        if (! $school) {
            return $next($request);
        }

        if (! $school->activeSubscription()) {
            return redirect()->route(config('routes.subscription_renew', 'subscription.renew'));
        }

        return $next($request);
    }
}
