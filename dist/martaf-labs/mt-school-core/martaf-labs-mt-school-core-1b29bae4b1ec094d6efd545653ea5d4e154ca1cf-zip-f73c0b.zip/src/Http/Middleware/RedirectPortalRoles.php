<?php

namespace Mt\MtSchoolCore\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Cloisonne les rôles-portail (parent/élève) hors de l'administration : s'ils visent
 * une route qui n'est pas leur portail (ni une route partagée), on les renvoie chez eux.
 * Empêche un parent/élève d'accéder aux écrans admin (et donc aux données de toute l'école)
 * par URL directe. À appendre au groupe 'web' après ResolveTenant.
 */
class RedirectPortalRoles
{
    /** rôle => [préfixe de portail autorisé, route d'accueil]. */
    protected array $portals = [
        'parent'  => ['parent', 'parent.home'],
        'student' => ['student', 'student.home'],
        'teacher' => ['my', 'teacher.home'],
    ];

    public function handle(Request $request, Closure $next): Response
    {
        $role = $request->user()?->school_role?->value;
        $conf = $this->portals[$role] ?? null;

        if ($conf) {
            [$prefix, $home] = $conf;

            // Routes toujours autorisées (portail + partagées + interne).
            // `notifications` = écran PARTAGÉ (Livewire/Shared, double cloisonnement
            // SchoolScope + user_id) — cible du « Voir toutes les notifications » de la cloche.
            $allowed = $request->is($prefix, $prefix . '/*', 'logout', 'profile', 'profile/*',
                'notifications', 'dev/*', 'livewire/*', 'locale/*');

            if (! $allowed && \Illuminate\Support\Facades\Route::has($home)) {
                return redirect()->route($home);
            }
        }

        return $next($request);
    }
}
