<?php

namespace Mt\MtSchoolCore\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Mt\MtSchoolCore\Models\Module;
use Symfony\Component\HttpFoundation\Response;

/**
 * Bloque l'accès direct (par URL) à un module non inclus dans le plan de l'école.
 *
 * Complément du gating du menu (SchoolNav) : le menu masque, ce middleware
 * empêche l'accès même si l'utilisateur connaît l'URL.
 *
 * Usage route : ->middleware('module:finance')
 *
 * S'appuie sur `moduleEnabled()` (repli config `.env` en dev / sans abonnement,
 * gating réel dès qu'un abonnement actif existe). Le tenant est déjà résolu
 * (middleware ResolveTenant, groupe web) à ce stade.
 */
class EnsureModuleEnabled
{
    public function handle(Request $request, Closure $next, string $module): Response
    {
        if (moduleEnabled($module)) {
            return $next($request);
        }

        $label = Module::where('code', $module)->first()?->name ?? $module;

        return redirect()
            ->route(config('routes.dashboard', 'dashboard'))
            ->with('error', "Le module « {$label} » n'est pas inclus dans votre abonnement.");
    }
}
