<?php

namespace Mt\MtSchoolCore\Livewire\Setup;

use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Enums\CycleType;
use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Models\Setting;

#[Layout('mt::components.layouts.auth')]
class SetupWizardComponent extends Component
{
    // ── Step state ────────────────────────────────────────────────────────────
    public int   $currentStep    = 1;
    public int   $totalSteps     = 6;
    public array $completedSteps = [];

    // ── Step 2 : Identité de l'école ──────────────────────────────────────────
    public array $sc_name       = ['fr' => '', 'en' => '', 'ar' => ''];
    public array $sc_short_name = ['fr' => '', 'en' => '', 'ar' => ''];

    // ── Step 3 : Année scolaire ───────────────────────────────────────────────
    public int    $sy_start_year = 0;
    public string $sy_start_date = '';
    public string $sy_end_date   = '';

    // ── Step 3 : Langues ─────────────────────────────────────────────────────
    public array $teaching_languages = ['fr'];

    // ── Step 5 : Cycles (MULTI — un complexe scolaire en combine plusieurs) ───
    public array $selected_cycle_types = [];

    // ── Step 6 : Niveaux PAR CYCLE ── ['preschool' => ['PS', …], 'primary' => […]]
    public array $selected_grade_levels = [];
    /** Cycles créés : type => id. */
    public array $created_cycle_ids = [];

    // Pré-remplissage de données types (matières + 1 classe + maquette par niveau).
    // Opt-in : décoché par défaut → « ne rien toucher » ne crée AUCUNE donnée
    // (le pré-remplissage type est une aide explicite, pas un défaut surprise).
    public bool $prefill_reference = false;
    public array $prefillCounts = [];

    // ── Mount ─────────────────────────────────────────────────────────────────

    public function mount(): void
    {
        if (Setting::isSetupComplete()) {
            $this->redirectRoute('dashboard', navigate: true);
            return;
        }

        $savedStep = (int) Setting::get('setup_current_step', 1);
        $this->currentStep = max(1, min($savedStep, $this->totalSteps));

        // Identité de l'école : pré-remplir si déjà saisie
        $school = \Mt\MtSchoolCore\Models\School::current();
        if ($school) {
            $this->sc_name       = array_merge(['fr' => '', 'en' => '', 'ar' => ''], json_decode($school->getRawOriginal('name') ?? '[]', true) ?: []);
            $this->sc_short_name = array_merge(['fr' => '', 'en' => '', 'ar' => ''], json_decode($school->getRawOriginal('short_name') ?? '[]', true) ?: []);
        }

        // Pré-remplir depuis les données existantes en base si disponibles
        $activeYear = SchoolYear::query()->where('is_active', true)->first();
        if ($activeYear) {
            [$startYear]         = explode('-', $activeYear->code . '-0');
            $this->sy_start_year = (int) $startYear ?: (int) now()->format('Y');
            $this->sy_start_date = $activeYear->start_date?->format('Y-m-d') ?? '';
            $this->sy_end_date   = $activeYear->end_date?->format('Y-m-d') ?? '';
        } else {
            // Année scolaire DÉTERMINÉE AUTOMATIQUEMENT par la date du jour (rentrée en
            // septembre) : juillet→décembre = rentrée de l'année civile courante ;
            // janvier→juin = année scolaire EN COURS (rentrée de l'an passé). L'utilisateur
            // n'ajuste que les jours/mois de début et de fin — les années suivantes se
            // créent via « Nouvelle année » (promotion + reports), jamais depuis le setup.
            $today = now();
            $this->sy_start_year = $today->month >= 7 ? $today->year : $today->year - 1;
            $this->fillDatesFromYear($this->sy_start_year);
        }

        $saved = Setting::getJson('teaching_languages', []);
        $this->teaching_languages = ! empty($saved) ? $saved : ['fr'];

        // Reprise MULTI-CYCLES : setup_cycle_ids (type => id) ; repli sur les cycles
        // existants en base (héritage de l'ancien setup mono-cycle / setup_cycle_id).
        $savedIds = Setting::getJson('setup_cycle_ids', []);
        if (empty($savedIds)) {
            foreach (\Mt\MtSchoolCore\Models\Cycle::query()->orderBy('order')->get() as $cycle) {
                $type = $cycle->type instanceof CycleType ? $cycle->type->value : (string) $cycle->type;
                if ($type !== '') {
                    $savedIds[$type] = $cycle->id;
                }
            }
        }

        $presets = $this->cyclePresets();
        foreach ($savedIds as $type => $id) {
            if (! isset($presets[$type])) {
                continue;
            }
            $this->selected_cycle_types[]   = $type;
            $this->created_cycle_ids[$type] = (int) $id;

            $existing = \Mt\MtSchoolCore\Models\GradeLevel::query()
                ->where('cycle_id', (int) $id)
                ->pluck('code')
                ->toArray();
            $this->selected_grade_levels[$type] = ! empty($existing)
                ? $existing
                : array_keys($presets[$type]['grades']);
        }

        // Offre mono-cycle (ex. secondaire seul) : pré-cocher d'office — l'étape
        // Cycle devient une simple confirmation.
        if (empty($this->selected_cycle_types) && count($presets) === 1) {
            $type = array_key_first($presets);
            $this->selected_cycle_types[]       = $type;
            $this->selected_grade_levels[$type] = array_keys($presets[$type]['grades']);
        }
    }

    // ── Reactive hooks ────────────────────────────────────────────────────────

    public function updatedSyStartYear(int $year): void
    {
        $this->fillDatesFromYear($year);
    }


    // ── Helpers ───────────────────────────────────────────────────────────────

    protected function fillDatesFromYear(int $year): void
    {
        $this->sy_start_date = "{$year}-09-01";
        $this->sy_end_date   = ($year + 1) . '-06-30';
    }

    /** Coche/décoche un cycle (multi-sélection — complexe scolaire). */
    public function toggleCycle(string $type): void
    {
        $presets = $this->cyclePresets();
        if (! isset($presets[$type])) {
            return;
        }

        if (in_array($type, $this->selected_cycle_types, true)) {
            $this->selected_cycle_types = array_values(array_diff($this->selected_cycle_types, [$type]));
            unset($this->selected_grade_levels[$type]);
        } else {
            $this->selected_cycle_types[]       = $type;
            $this->selected_grade_levels[$type] = array_keys($presets[$type]['grades']);
        }
    }

    // ── Computed properties ───────────────────────────────────────────────────

    public function getSyCodeProperty(): string
    {
        return $this->sy_start_year . '-' . ($this->sy_start_year + 1);
    }

    // ── Presets ───────────────────────────────────────────────────────────────

    public function cyclePresets(): array
    {
        // Offre restreinte par config (mt-school = SECONDAIRE uniquement pour le moment).
        // Le catalogue complet reste défini ci-dessous : élargir = ajouter les clés
        // dans mt-school-core.setup.cycles (ou SCHOOL_SETUP_CYCLES), rien d'autre.
        $enabled = (array) config('mt-school-core.setup.cycles', ['secondary']);

        return array_filter($this->cycleCatalog(), fn ($k) => in_array($k, $enabled, true), ARRAY_FILTER_USE_KEY);
    }

    /** Catalogue COMPLET des cycles (indépendant de l'offre activée). */
    protected function cycleCatalog(): array
    {
        return [
            'preschool' => [
                'code'        => 'MAT',
                'label'       => 'Maternelle',
                'icon'        => 'face-smile',
                'description' => 'Toute petite section jusqu\'à grande section',
                'grades'      => [
                    'TPS' => 'Toute Petite Section',
                    'PS'  => 'Petite Section',
                    'MS'  => 'Moyenne Section',
                    'GS'  => 'Grande Section',
                ],
            ],
            'primary' => [
                'code'        => 'PRI',
                'label'       => 'Primaire',
                'icon'        => 'pencil',
                'description' => 'Du CP1 au CM2 (CEP)',
                'grades'      => [
                    'CP1'  => 'Cours Préparatoire 1',
                    'CP2'  => 'Cours Préparatoire 2',
                    'CE1'  => 'Cours Élémentaire 1',
                    'CE2'  => 'Cours Élémentaire 2',
                    'CM1'  => 'Cours Moyen 1',
                    'CM2'  => 'Cours Moyen 2',
                ],
            ],
            // Secondaire 1er cycle : Collège (6e→3e, BEPC).
            'college' => [
                'code'        => 'COL',
                'label'       => 'Collège',
                'icon'        => 'book-open',
                'description' => 'De la 6ème à la 3ème (BEPC)',
                'grades'      => [
                    '6EME' => 'Sixième',
                    '5EME' => 'Cinquième',
                    '4EME' => 'Quatrième',
                    '3EME' => 'Troisième',
                ],
            ],
            // Secondaire 2nd cycle : Lycée (2nde→Terminale, BAC).
            'lycee' => [
                'code'        => 'LYC',
                'label'       => 'Lycée',
                'icon'        => 'academic-cap',
                'description' => 'De la Seconde à la Terminale (BAC)',
                'grades'      => [
                    '2NDE' => 'Seconde',
                    '1ERE' => 'Première',
                    'TERM' => 'Terminale',
                ],
            ],
            'higher' => [
                'code'        => 'SUP',
                'label'       => 'Supérieur',
                'icon'        => 'academic-cap',
                'description' => 'Licence, Master, Doctorat',
                'grades'      => [
                    'L1' => 'Licence 1',
                    'L2' => 'Licence 2',
                    'L3' => 'Licence 3',
                    'M1' => 'Master 1',
                    'M2' => 'Master 2',
                    'D'  => 'Doctorat',
                ],
            ],
        ];
    }

    // ── Steps definition ──────────────────────────────────────────────────────

    public function steps(): array
    {
        return [
            1 => [
                'title'       => __('mtschool::setup.step1_title'),
                'description' => __('mtschool::setup.step1_description'),
                'icon'        => 'academic-cap',
            ],
            // Ordre : LANGUES avant l'ÉCOLE — le nom de l'établissement est saisi dans
            // les langues d'enseignement choisies (sinon on demandait Nom EN/AR avant
            // même de savoir si l'école les utilise). Les clés de trad restent liées
            // au CONTENU (step4_* = langues), seule la position change.
            2 => [
                'title'       => __('mtschool::setup.step4_title'),
                'description' => __('mtschool::setup.step4_description'),
                'icon'        => 'globe',
            ],
            3 => [
                'title'       => __('mtschool::setup.step2_title'),
                'description' => __('mtschool::setup.step2_description'),
                'icon'        => 'building-library',
            ],
            4 => [
                'title'       => __('mtschool::setup.step3_title'),
                'description' => __('mtschool::setup.step3_description'),
                'icon'        => 'calendar',
            ],
            5 => [
                'title'       => __('mtschool::setup.step5_title'),
                'description' => __('mtschool::setup.step5_description'),
                'icon'        => 'rectangle-stack',
            ],
            6 => [
                'title'       => __('mtschool::setup.step6_title'),
                'description' => __('mtschool::setup.step6_description'),
                'icon'        => 'list-bullet',
            ],
        ];
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    public function next(): void
    {
        if (! $this->validateCurrentStep()) {
            return;
        }

        $this->saveCurrentStep();

        $this->completedSteps[] = $this->currentStep;
        $this->currentStep++;

        // La progression est PAR ÉCOLE : on ne persiste qu'une fois le tenant créé
        // (étape 3 — École). Avant, pas de school_id → on évite une ligne orpheline.
        if (currentSchoolId()) {
            Setting::set('setup_current_step', $this->currentStep);
        }
    }

    public function previous(): void
    {
        if ($this->currentStep > 1) {
            $this->currentStep--;
        }
    }

    public function complete(): void
    {
        if (! $this->validateCurrentStep()) {
            return;
        }

        $this->saveCurrentStep();

        Setting::set('setup_completed', 'true');
        Setting::set('setup_current_step', $this->totalSteps);

        $this->redirectRoute('dashboard', navigate: true);
    }

    // ── Validation ────────────────────────────────────────────────────────────

    protected function validateCurrentStep(): bool
    {
        $rules = $this->stepRules($this->currentStep);
        if (empty($rules)) return true;

        $this->validate($rules, $this->stepMessages($this->currentStep));
        return true;
    }

    protected function stepRules(int $step): array
    {
        return match ($step) {
            2 => [
                'teaching_languages' => 'required|array|min:1',
            ],
            3 => [
                'sc_name'    => 'required|array',
                'sc_name.fr' => 'required|string|max:255',
                'sc_name.*'  => 'nullable|string|max:255',
                'sc_short_name.*' => 'nullable|string|max:100',
            ],
            4 => [
                'sy_start_year' => 'required|integer|min:2000|max:2100',
                // Cohérence avec l'année déterminée automatiquement : le début reste dans
                // l'année civile de la rentrée (N), la fin au plus tard dans N+1, et la
                // durée ne peut pas excéder 12 mois (pas d'année fantôme type 2031).
                'sy_start_date' => [
                    'required', 'date',
                    'after_or_equal:'  . $this->sy_start_year . '-01-01',
                    'before_or_equal:' . $this->sy_start_year . '-12-31',
                ],
                'sy_end_date' => [
                    'required', 'date', 'after:sy_start_date',
                    'before_or_equal:' . ($this->sy_start_year + 1) . '-12-31',
                    function ($attribute, $value, $fail) {
                        if ($this->sy_start_date
                            && strtotime($value) > strtotime($this->sy_start_date . ' +1 year')) {
                            $fail(__('mtschool::setup.sy_max_duration'));
                        }
                    },
                ],
            ],
            5 => [
                'selected_cycle_types'   => 'required|array|min:1',
                'selected_cycle_types.*' => 'string|in:' . implode(',', array_keys($this->cyclePresets())),
            ],
            6 => [
                'selected_grade_levels' => ['required', 'array',
                    // Chaque cycle coché doit garder AU MOINS un niveau (sinon décocher le cycle).
                    function ($attribute, $value, $fail) {
                        foreach ($this->selected_cycle_types as $type) {
                            if (count($value[$type] ?? []) < 1) {
                                $label = $this->cyclePresets()[$type]['label'] ?? $type;
                                $fail(__('mtschool::setup.levels_per_cycle', ['cycle' => $label]));
                                return;
                            }
                        }
                    },
                ],
            ],
            default => [],
        };
    }

    protected function stepMessages(int $step): array
    {
        return match ($step) {
            2 => [
                'teaching_languages.required' => __('mtschool::setup.teaching_languages_required'),
                'teaching_languages.min'      => __('mtschool::setup.teaching_languages_min'),
            ],
            3 => [
                'sc_name.required'    => __('mtschool::setup.sc_name_required'),
                'sc_name.fr.required' => __('mtschool::setup.sc_name_fr_required'),
            ],
            4 => [
                'sy_start_year.required' => __('mtschool::setup.sy_start_year_required'),
                'sy_start_date.required' => __('mtschool::setup.sy_start_date_required'),
                'sy_start_date.after_or_equal'  => __('mtschool::setup.sy_start_in_year', ['year' => $this->sy_start_year]),
                'sy_start_date.before_or_equal' => __('mtschool::setup.sy_start_in_year', ['year' => $this->sy_start_year]),
                'sy_end_date.required'   => __('mtschool::setup.sy_end_date_required'),
                'sy_end_date.after'      => __('mtschool::setup.sy_end_date_after'),
                'sy_end_date.before_or_equal' => __('mtschool::setup.sy_end_in_year', ['year' => $this->sy_start_year + 1]),
            ],
            5 => [
                'selected_cycle_types.required' => __('mtschool::setup.cycle_type_required'),
                'selected_cycle_types.min'      => __('mtschool::setup.cycle_type_required'),
                'selected_cycle_types.*.in'     => __('mtschool::setup.cycle_type_in'),
            ],
            6 => [
                'selected_grade_levels.required' => __('mtschool::setup.grade_levels_required'),
                'selected_grade_levels.min'      => __('mtschool::setup.grade_levels_min'),
            ],
            default => [],
        };
    }

    // ── Sauvegarde ────────────────────────────────────────────────────────────

    protected function saveCurrentStep(): void
    {
        match ($this->currentStep) {
            // Étape 2 (langues) : simple état du composant — le Setting est school-scopé,
            // il ne peut être écrit qu'après la création du tenant (étape 3).
            3 => $this->saveSchoolAndLanguages(),
            4 => $this->saveSchoolYear(),
            5 => $this->saveCycles(),
            6 => $this->saveGradeLevels(),
            default => null,
        };
    }

    /** Crée le tenant PUIS persiste les langues choisies à l'étape 2 (Setting school-scopé). */
    protected function saveSchoolAndLanguages(): void
    {
        $this->saveSchool();
        $this->saveLanguages();
    }

    protected function saveSchool(): void
    {
        $name  = array_filter(array_map('trim', $this->sc_name));
        $short = array_filter(array_map('trim', $this->sc_short_name));

        $user = auth()->user();

        // Source de vérité = l'école du user (onboarding). Pas de singleton ici.
        $school = $user?->school_id
            ? \Mt\MtSchoolCore\Models\School::withoutGlobalScopes()->find($user->school_id)
            : null;

        if ($school) {
            $school->update(['name' => $name ?: ['fr' => '—'], 'short_name' => $short ?: null]);
        } else {
            $school = \Mt\MtSchoolCore\Models\School::create([
                'name'       => $name ?: ['fr' => '—'],
                'short_name' => $short ?: null,
                'active'     => true,
            ]);

            // L'acheteur devient super-admin de SON école.
            if ($user) {
                $user->forceFill([
                    'school_id'   => $school->id,
                    'school_role' => \Mt\MtSchoolCore\Enums\RoleSchool::SUPER_ADMIN,
                ])->save();
            }
        }

        // Fixe le tenant courant → les étapes suivantes (année, cycle, niveaux)
        // rempliront automatiquement school_id via BelongsToSchool.
        app(\Mt\MtSchoolCore\Support\SchoolResolver::class)->setCurrent($school->id);
    }

    protected function saveSchoolYear(): void
    {
        SchoolYear::query()->update(['is_active' => false]);

        $code  = $this->sy_start_year . '-' . ($this->sy_start_year + 1);
        $label = 'Année scolaire ' . $code;

        $year = SchoolYear::updateOrCreate(
            ['code' => $code],
            [
                'label'      => ['fr' => $label],
                'start_date' => $this->sy_start_date,
                'end_date'   => $this->sy_end_date,
                'is_active'  => true,
                'is_closed'  => false,
            ]
        );

        // Découpage en périodes d'emblée (trimestres par défaut) : sans période, aucune
        // évaluation/note/bulletin n'est possible → l'école ne peut rien produire juste
        // après l'achat. Idempotent (ne fait rien si l'année a déjà des périodes).
        app(\Mt\MtSchoolCore\Services\PeriodTemplateService::class)->generate($year, 'trimester');
    }

    protected function saveLanguages(): void
    {
        Setting::set('teaching_languages', $this->teaching_languages);
    }

    /** Crée TOUS les cycles cochés, dans l'ordre naturel (MAT → PRI → SEC → SUP). */
    protected function saveCycles(): void
    {
        $order = 1;
        foreach ($this->cyclePresets() as $type => $preset) {
            if (! in_array($type, $this->selected_cycle_types, true)) {
                continue;
            }

            $cycle = Cycle::updateOrCreate(
                ['code' => $preset['code']],
                [
                    'label'  => ['fr' => $preset['label']],
                    'type'   => $type,
                    'order'  => $order++,
                    'active' => true,
                ]
            );

            $this->created_cycle_ids[$type] = $cycle->id;
        }

        Setting::set('setup_cycle_ids', $this->created_cycle_ids);
        // Héritage : premier cycle pour tout consommateur legacy de setup_cycle_id.
        Setting::set('setup_cycle_id', (string) (reset($this->created_cycle_ids) ?: ''));
    }

    protected function saveGradeLevels(): void
    {
        $presets = $this->cyclePresets();
        $totals  = [];

        foreach ($presets as $type => $preset) {
            if (! in_array($type, $this->selected_cycle_types, true)) {
                continue;
            }
            $cycleId = $this->created_cycle_ids[$type] ?? null;
            if (! $cycleId) {
                continue;
            }

            $order = 1;
            foreach ($this->selected_grade_levels[$type] ?? [] as $code) {
                if (! isset($preset['grades'][$code])) {
                    continue;
                }
                GradeLevel::updateOrCreate(
                    ['cycle_id' => $cycleId, 'code' => $code],
                    [
                        'label'  => ['fr' => $preset['grades'][$code]],
                        'order'  => $order++,
                        'active' => true,
                    ]
                );
            }

            // Pré-remplissage PAR CYCLE : matières standard + 1 classe + maquette par
            // niveau (les matières communes se dédupliquent par code, unique par école).
            if ($this->prefill_reference) {
                foreach (app(\Mt\MtSchoolCore\Services\ReferenceDataService::class)->prefill($cycleId) as $k => $n) {
                    $totals[$k] = ($totals[$k] ?? 0) + (int) $n;
                }
            }
        }

        $this->prefillCounts = $totals;
    }

    // ── Render ────────────────────────────────────────────────────────────────

    public function getProgressPercent(): int
    {
        return (int) round((($this->currentStep - 1) / ($this->totalSteps - 1)) * 100);
    }

    public function render()
    {
        $presets = $this->cyclePresets();

        // Niveaux de l'étape 6, groupés par cycle coché, dans l'ordre naturel des presets.
        $byCycle = [];
        foreach ($presets as $type => $preset) {
            if (in_array($type, $this->selected_cycle_types, true)) {
                $byCycle[$type] = $preset;
            }
        }

        return view('mtschool::livewire.setup.wizard', [
            'steps'               => $this->steps(),
            'progressPercent'     => $this->getProgressPercent(),
            'syCode'              => $this->syCode,
            'availableLanguages'  => [
                'fr' => 'Français',
                'en' => 'English',
                'ar' => 'العربية',
            ],
            'cyclePresets'        => $presets,
            'cyclesRestricted'    => count($presets) < count($this->cycleCatalog()),
            'gradePresetsByCycle' => $byCycle,
        ])->title(__('mtschool::setup.title'));
    }
}
