<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Livewire\Admin\Timetable\TimetableGridManager;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\Timetable;

/** Emploi du temps de la classe de l'élève (lecture seule). */
#[Layout('mt::components.layouts.app')]
class StudentTimetable extends Component
{
    public function render()
    {
        $u = Auth::user()?->userable;
        $student = $u instanceof Student ? $u : null;
        $enrollment = $student?->enrollmentFor();

        $slots = [];
        $className = null;

        if ($enrollment?->classroom) {
            $className = $enrollment->classroom->label;
            $timetable = Timetable::where('class_id', $enrollment->class_id)
                ->where('school_year_id', activeSchoolYearId())->first();

            if ($timetable) {
                foreach ($timetable->timeSlots()->with(['subject', 'teacher.staff', 'room'])->get() as $s) {
                    $key = $s->day_of_week->value . '_' . substr((string) $s->start_time, 0, 5);
                    $slots[$key] = [
                        'subject' => $s->subject?->abbreviation ?: $s->subject?->code,
                        'teacher' => $s->teacher?->staff?->last_name,
                        'room'    => $s->room?->code,
                    ];
                }
            }
        }

        return view('mtschool::livewire.student.timetable', [
            'periods'   => TimetableGridManager::PERIODS,
            'days'      => TimetableGridManager::translatedDays(),
            'slots'     => $slots,
            'className' => $className,
        ])->title(__('mtschool::timetable.my_title'));
    }
}
