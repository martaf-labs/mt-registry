<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\ReportCard;
use Mt\MtSchoolCore\Models\Student;

/**
 * Portail élève — MES BULLETINS : les bulletins de période PUBLIÉS (téléchargeables) et
 * le bulletin ANNUEL avec sa synthèse dès que le résultat annuel est calculé.
 */
#[Layout('mt::components.layouts.app')]
class MyReportCards extends Component
{
    protected function enrollment()
    {
        $s = Auth::user()?->userable;
        return $s instanceof Student ? $s->enrollmentFor() : null;
    }

    #[Computed]
    public function data(): array
    {
        $enrollment = $this->enrollment();
        if (! $enrollment) {
            return ['enrollment_id' => null, 'year_id' => null, 'periods' => collect(), 'annual' => null];
        }

        $periods = ReportCard::where('enrollment_id', $enrollment->id)
            ->published()->with('period')->get()
            ->sortBy(fn ($rc) => $rc->period?->order)
            ->map(fn ($rc) => (object) [
                'period_id'    => $rc->period_id,
                'period'       => $rc->period?->label,
                'published_at' => $rc->published_at,
            ])->values();

        $annual = $enrollment->annual_average !== null
            ? (object) [
                'average' => (float) $enrollment->annual_average,
                'rank'    => $enrollment->annual_rank,
                'result'  => $enrollment->result?->label(),
            ]
            : null;

        return [
            'enrollment_id' => $enrollment->id,
            'year_id'       => $enrollment->school_year_id,
            'periods'       => $periods,
            'annual'        => $annual,
        ];
    }

    public function render()
    {
        return view('mtschool::livewire.student.my-report-cards', ['d' => $this->data])
            ->title(__('mtschool::portal.my_report_cards'));
    }
}
