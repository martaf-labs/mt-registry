<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Payment;
use Mt\MtSchoolCore\Models\SchoolFee;
use Mt\MtSchoolCore\Models\Student;

/**
 * Portail élève — MES FRAIS : détail des frais par type, totaux facturé/payé/restant +
 * statut, échéancier (retards), historique des paiements, relevé PDF. Élève connecté.
 */
#[Layout('mt::components.layouts.app')]
class MyFees extends Component
{
    protected function enrollment()
    {
        $s = Auth::user()?->userable;
        return $s instanceof Student ? $s->enrollmentFor() : null;
    }

    #[Computed]
    public function data(): array
    {
        $enrollment = $this->enrollment();
        if (! $enrollment) {
            return ['enrollment' => null, 'fees' => collect(), 'installments' => collect(), 'payments' => collect(),
                    'total_net' => 0.0, 'total_paid' => 0.0, 'total_remaining' => 0.0, 'currency' => '', 'status' => 'none'];
        }

        $fees = SchoolFee::where('enrollment_id', $enrollment->id)
            ->with(['feeType', 'installments'])->get();

        $feeRows = $fees->map(fn ($f) => (object) [
            'type'      => $f->feeType?->label,
            'net'       => (float) $f->net_amount,
            'paid'      => (float) $f->amount_paid,
            'remaining' => (float) $f->remaining_amount,
            'status'    => $this->feeStatus($f),
        ]);

        $installments = $fees->flatMap(fn ($f) => $f->installments->map(fn ($i) => (object) [
            'label'    => $i->label,
            'amount'   => (float) $i->amount,
            'due_date' => $i->due_date,
            'status'   => $this->installmentStatus($i),
        ]))->sortBy(fn ($i) => $i->due_date)->values();

        $payments = Payment::whereIn('school_fee_id', $fees->pluck('id'))
            ->orderByDesc('payment_date')->limit(20)->get()
            ->map(fn ($p) => (object) [
                'date'      => $p->payment_date,
                'amount'    => (float) $p->amount,
                'method'    => $p->payment_method instanceof \BackedEnum
                    ? (method_exists($p->payment_method, 'label') ? $p->payment_method->label() : $p->payment_method->value)
                    : (string) $p->payment_method,
                'reference' => $p->reference,
            ]);

        $totalPaid      = (float) $fees->sum('amount_paid');
        $totalRemaining = (float) $fees->sum('remaining_amount');

        return [
            'enrollment'      => $enrollment,
            'fees'            => $feeRows,
            'installments'    => $installments,
            'payments'        => $payments,
            'total_net'       => (float) $fees->sum('net_amount'),
            'total_paid'      => $totalPaid,
            'total_remaining' => $totalRemaining,
            'currency'        => (string) ($fees->first()?->currency ?? ''),
            'status'          => $totalRemaining <= 0 && $fees->isNotEmpty()
                ? 'paid'
                : ($totalPaid > 0 ? 'partial' : 'pending'),
        ];
    }

    protected function feeStatus(SchoolFee $fee): string
    {
        if ($fee->is_exempt) {
            return 'exempt';
        }
        $net  = (float) $fee->net_amount;
        $paid = (float) $fee->amount_paid;
        if ($net <= 0 || $paid >= $net) {
            return 'paid';
        }
        return $paid > 0 ? 'partial' : 'pending';
    }

    protected function installmentStatus($installment): string
    {
        if ($installment->status === 'paid') {
            return 'paid';
        }
        if ($installment->due_date && $installment->due_date->isPast()) {
            return 'overdue';
        }
        return 'pending';
    }

    public function render()
    {
        return view('mtschool::livewire.student.my-fees', ['d' => $this->data])
            ->title(__('mtschool::portal.my_fees'));
    }
}
