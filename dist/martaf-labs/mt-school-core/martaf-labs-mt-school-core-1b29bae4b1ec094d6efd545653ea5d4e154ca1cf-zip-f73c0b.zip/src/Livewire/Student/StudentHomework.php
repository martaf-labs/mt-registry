<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Homework;
use Mt\MtSchoolCore\Models\HomeworkSubmission;
use Mt\MtSchoolCore\Models\Student;

/**
 * Portail élève — ses devoirs (de sa classe) avec état (à faire / rendu / corrigé)
 * et dépôt d'un rendu (commentaire + fichier optionnel). Données limitées à l'élève.
 */
#[Layout('mt::components.layouts.app')]
class StudentHomework extends Component
{
    use WithFileUploads;

    // Modale de rendu
    public bool $showSubmit = false;
    public ?int $activeHomeworkId = null;
    public string $comment = '';
    public $upload = null;

    public string $successMessage = '';

    protected function enrollment(): ?Enrollment
    {
        $student = Auth::user()?->userable;
        if (! $student instanceof Student) {
            return null;
        }

        return $student->enrollmentFor();
    }

    public function mount(): void
    {
        abort_unless($this->enrollment(), 403);
    }

    #[Computed]
    public function homeworks()
    {
        $enr = $this->enrollment();

        $mine = HomeworkSubmission::where('enrollment_id', $enr->id)
            ->get()->keyBy('homework_id');

        return Homework::where('class_id', $enr->class_id)
            ->published()
            ->with(['subject', 'teacher'])
            ->orderByDesc('submission_deadline')
            ->get()
            ->map(function ($hw) use ($mine) {
                $s = $mine->get($hw->id);
                return (object) [
                    'id'           => $hw->id,
                    'title'        => $hw->title,
                    'instructions' => $hw->instructions,
                    'subject'      => $hw->subject?->label,
                    'teacher'      => $hw->teacher?->full_name ?? $hw->teacher?->last_name,
                    'deadline'     => $hw->submission_deadline,
                    'expired'      => $hw->submission_deadline?->isPast(),
                    'is_graded'    => $hw->is_graded,
                    'max_score'    => $hw->max_score,
                    'submitted'    => $s?->submitted_at !== null, // vrai dépôt, pas juste une note saisie
                    'submitted_at' => $s?->submitted_at,
                    'is_late'      => (bool) ($s?->is_late),
                    'score'        => $s?->score,
                    'correction'   => $s?->correction,
                    'corrected'    => $s?->status === 'corrected',
                ];
            });
    }

    public function openSubmit(int $homeworkId): void
    {
        $enr = $this->enrollment();
        $hw  = Homework::where('class_id', $enr->class_id)->published()->findOrFail($homeworkId);

        $this->activeHomeworkId = $hw->id;
        $this->reset(['comment', 'upload']);

        $existing = HomeworkSubmission::where('homework_id', $hw->id)
            ->where('enrollment_id', $enr->id)->first();
        if ($existing) {
            $this->comment = is_array($existing->comment)
                ? ($existing->comment[config('mt-school-core.multilingual.default', 'fr')] ?? '')
                : (string) $existing->comment;
        }

        $this->showSubmit = true;
        $this->dispatch('open-submit-homework');
    }

    public function submit(): void
    {
        $this->validate([
            'comment' => 'nullable|string|max:3000',
            'upload'  => 'nullable|file|max:10240',
        ]);

        $enr = $this->enrollment();
        $hw  = Homework::where('class_id', $enr->class_id)->published()->findOrFail($this->activeHomeworkId);

        $sub = HomeworkSubmission::firstOrNew([
            'homework_id'   => $hw->id,
            'enrollment_id' => $enr->id,
        ]);

        $locale = config('mt-school-core.multilingual.default', 'fr');
        $sub->comment = trim($this->comment) !== '' ? [$locale => trim($this->comment)] : null;

        if ($this->upload) {
            if ($sub->file && Storage::disk('public')->exists($sub->file)) {
                Storage::disk('public')->delete($sub->file);
            }
            $sub->file = $this->upload->store('homework-submissions', 'public');
        }

        $sub->submitted_at = now();
        $sub->is_late      = $hw->submission_deadline && now()->greaterThan($hw->submission_deadline);
        $sub->status       = 'submitted';
        $sub->save();

        $this->showSubmit = false;
        unset($this->homeworks);
        $this->dispatch('close-modal', name: 'submit-homework');
        $this->successMessage = 'Devoir rendu.';
    }

    public function render()
    {
        return view('mtschool::livewire.student.homework')
            ->title(__('mtschool::pedagogy.my_homework'));
    }
}
