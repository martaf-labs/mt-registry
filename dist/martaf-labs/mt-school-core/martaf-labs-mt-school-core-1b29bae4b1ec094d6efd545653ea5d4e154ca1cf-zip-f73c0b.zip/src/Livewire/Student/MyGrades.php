<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\SubjectAverage;

/**
 * Portail élève — MES NOTES : pour chaque période, la moyenne générale + rang + mention,
 * et le détail par matière (moyenne, coefficient, rang). Strictement l'élève connecté.
 */
#[Layout('mt::components.layouts.app')]
class MyGrades extends Component
{
    protected function enrollment()
    {
        $s = Auth::user()?->userable;
        return $s instanceof Student ? $s->enrollmentFor() : null;
    }

    #[Computed]
    public function periods()
    {
        $enrollment = $this->enrollment();
        if (! $enrollment) {
            return collect();
        }

        return PeriodAverage::where('enrollment_id', $enrollment->id)
            ->with('period')->get()
            ->sortByDesc(fn ($pa) => $pa->period?->order ?? $pa->period_id)
            ->map(function ($pa) use ($enrollment) {
                $subjects = SubjectAverage::where('enrollment_id', $enrollment->id)
                    ->where('period_id', $pa->period_id)->with('subject')->get()
                    ->sortBy(fn ($sa) => $sa->subject?->code)
                    ->map(fn ($sa) => (object) [
                        'subject' => $sa->subject?->label,
                        'average' => (float) $sa->average,
                        'coef'    => (float) $sa->coefficient,
                        'rank'    => $sa->rank,
                    ])->values();

                return (object) [
                    'period'     => $pa->period?->label,
                    'average'    => (float) $pa->overall_average,
                    'rank'       => $pa->rank,
                    'class_size' => $pa->class_size,
                    'mention'    => $pa->mention?->label(),
                    'subjects'   => $subjects,
                ];
            })->values();
    }

    public function render()
    {
        return view('mtschool::livewire.student.my-grades')
            ->title(__('mtschool::portal.my_grades'));
    }
}
