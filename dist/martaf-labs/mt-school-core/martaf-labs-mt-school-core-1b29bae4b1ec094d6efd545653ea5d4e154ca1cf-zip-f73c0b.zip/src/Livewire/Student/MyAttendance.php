<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Attendance;
use Mt\MtSchoolCore\Models\Student;

/**
 * Portail élève — MES PRÉSENCES : compteurs (présences / absences / retards / non
 * justifiées) + dernières absences et retards. Strictement l'élève connecté.
 */
#[Layout('mt::components.layouts.app')]
class MyAttendance extends Component
{
    protected function enrollment()
    {
        $s = Auth::user()?->userable;
        return $s instanceof Student ? $s->enrollmentFor() : null;
    }

    #[Computed]
    public function data(): array
    {
        $enrollment = $this->enrollment();
        if (! $enrollment) {
            return ['enrollment' => null, 'present' => 0, 'absent' => 0, 'late' => 0, 'unjustified' => 0, 'events' => collect()];
        }

        $eid = $enrollment->id;

        $events = Attendance::where('enrollment_id', $eid)
            ->whereIn('status', ['absent', 'late'])
            ->orderByDesc('date')->limit(15)->get()
            ->map(fn ($a) => (object) [
                'date'      => $a->date,
                'status'    => $a->status instanceof \BackedEnum ? $a->status->value : (string) $a->status,
                'justified' => (bool) $a->is_justified,
                'lateness'  => (int) ($a->lateness_minutes ?? 0),
            ]);

        return [
            'enrollment'  => $enrollment,
            'present'     => Attendance::where('enrollment_id', $eid)->where('status', 'present')->count(),
            'absent'      => Attendance::where('enrollment_id', $eid)->where('status', 'absent')->count(),
            'late'        => Attendance::where('enrollment_id', $eid)->where('status', 'late')->count(),
            'unjustified' => Attendance::where('enrollment_id', $eid)
                ->where('status', 'absent')->where('is_justified', false)->count(),
            'events'      => $events,
        ];
    }

    public function render()
    {
        return view('mtschool::livewire.student.my-attendance', ['d' => $this->data])
            ->title(__('mtschool::portal.my_attendance'));
    }
}
