<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\SchoolFee;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\SubjectAverage;

/**
 * Accueil du portail élève : SES résultats (moyenne/rang + par matière sur la dernière
 * période), SA situation financière et l'accès à SON bulletin. Données strictement
 * limitées à l'élève connecté (userable = Student).
 */
#[Layout('mt::components.layouts.app')]
class StudentHome extends Component
{
    public function student(): ?Student
    {
        $u = Auth::user()?->userable;
        return $u instanceof Student ? $u : null;
    }

    #[Computed]
    public function data(): array
    {
        $student = $this->student();
        $enrollment = $student?->enrollmentFor();
        if (! $enrollment) {
            return ['student' => $student, 'enrollment' => null];
        }

        $latest = PeriodAverage::where('enrollment_id', $enrollment->id)
            ->with('period')->orderByDesc('period_id')->first();

        $subjects = $latest
            ? SubjectAverage::where('enrollment_id', $enrollment->id)
                ->where('period_id', $latest->period_id)
                ->with('subject')->get()->sortBy(fn ($s) => $s->subject?->code)
            : collect();

        return [
            'student'    => $student,
            'enrollment' => $enrollment,
            'class'      => $enrollment->classroom?->label,
            'period'     => $latest,
            'subjects'   => $subjects,
            'remaining'  => (float) SchoolFee::where('enrollment_id', $enrollment->id)->sum('remaining_amount'),
        ];
    }

    public function render()
    {
        return view('mtschool::livewire.student.home', ['d' => $this->data])
            ->title(__('mtschool::portal.my_space'));
    }
}
