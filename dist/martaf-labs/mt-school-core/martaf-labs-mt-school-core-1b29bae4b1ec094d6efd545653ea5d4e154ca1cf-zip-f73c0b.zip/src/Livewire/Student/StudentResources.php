<?php

namespace Mt\MtSchoolCore\Livewire\Student;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\TeachingResource;

/**
 * Portail élève — ressources pédagogiques publiées pour sa classe ou son niveau.
 * Lecture seule (ouvrir un lien / télécharger un document). Limité à l'élève.
 */
#[Layout('mt::components.layouts.app')]
class StudentResources extends Component
{
    protected function enrollment(): ?Enrollment
    {
        $student = Auth::user()?->userable;
        if (! $student instanceof Student) {
            return null;
        }

        return $student->enrollmentFor();
    }

    public function mount(): void
    {
        abort_unless($this->enrollment(), 403);
    }

    #[Computed]
    public function resources()
    {
        $enr = $this->enrollment();
        $classroom = $enr->classroom;

        return TeachingResource::published()
            ->where(function ($q) use ($enr, $classroom) {
                $q->where('class_id', $enr->class_id);
                if ($classroom?->grade_level_id) {
                    $q->orWhere('grade_level_id', $classroom->grade_level_id);
                }
            })
            ->with(['subject', 'teacher'])
            ->orderByDesc('id')
            ->get();
    }

    public function download(int $id)
    {
        $enr = $this->enrollment();
        $r   = $this->resources->firstWhere('id', $id);
        abort_unless($r && $r->file && Storage::disk('public')->exists($r->file), 404);

        $r->incrementDownloads();

        return Storage::disk('public')->download($r->file);
    }

    public function render()
    {
        return view('mtschool::livewire.student.resources')
            ->title(__('mtschool::pedagogy.resources'));
    }
}
