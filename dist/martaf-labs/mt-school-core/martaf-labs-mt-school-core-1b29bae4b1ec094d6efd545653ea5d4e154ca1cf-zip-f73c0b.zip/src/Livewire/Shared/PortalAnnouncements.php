<?php

namespace Mt\MtSchoolCore\Livewire\Shared;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Announcement;

/**
 * Annonces des PORTAILS (parent / élève / enseignant) — un seul écran partagé,
 * l'audience est résolue depuis le rôle du user connecté. Publiées, non expirées,
 * ciblées « tout le monde » ou le public du rôle. School-scopé via Announcement.
 */
#[Layout('mt::components.layouts.app')]
class PortalAnnouncements extends Component
{
    /** Audience de l'annonce correspondant au rôle-portail connecté. */
    protected function audience(): string
    {
        return match (auth()->user()?->school_role?->value) {
            'student' => 'students',
            'teacher' => 'teachers',
            default   => 'parents',
        };
    }

    #[Computed]
    public function announcements()
    {
        return Announcement::where('status', 'published')
            ->whereIn('audience_type', ['all', $this->audience()])
            ->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()))
            ->orderByDesc('published_at')
            ->limit(50)
            ->get();
    }

    public function render()
    {
        return view('mtschool::livewire.shared.announcements')
            ->title(__('mtschool::portal.announcements'));
    }
}
