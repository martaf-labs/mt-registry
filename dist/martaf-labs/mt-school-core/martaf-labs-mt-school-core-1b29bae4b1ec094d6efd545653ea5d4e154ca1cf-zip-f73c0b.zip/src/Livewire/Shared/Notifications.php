<?php

namespace Mt\MtSchoolCore\Livewire\Shared;

use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\SchoolNotification;

/**
 * Centre de notifications de l'utilisateur connecté (in-app). Accessible à tous les rôles.
 * Double cloisonnement : SchoolScope (école) + filtre user_id.
 */
#[Layout('mt::components.layouts.app')]
class Notifications extends Component
{
    public function markRead(int $id): void
    {
        $n = SchoolNotification::where('user_id', auth()->id())->find($id);
        $n?->markAsRead();
    }

    public function markAllRead(): void
    {
        SchoolNotification::where('user_id', auth()->id())
            ->where('is_read', false)
            ->update(['is_read' => true, 'read_at' => now()]);
    }

    public function render()
    {
        $notifications = SchoolNotification::where('user_id', auth()->id())
            ->orderByDesc('created_at')
            ->limit(100)
            ->get();

        $unread = SchoolNotification::where('user_id', auth()->id())
            ->where('is_read', false)
            ->count();

        return view('mtschool::livewire.shared.notifications', compact('notifications', 'unread'))
            ->title(__('mtschool::portal.notifications_title'));
    }
}
