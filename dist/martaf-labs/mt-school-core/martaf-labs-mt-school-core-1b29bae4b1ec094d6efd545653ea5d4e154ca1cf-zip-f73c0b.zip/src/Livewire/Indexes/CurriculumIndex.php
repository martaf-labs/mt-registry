<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtViews\Livewire\Indexes\GenericIndex;

/**
 * Maquettes pédagogiques (programmes) de l'année active.
 * Action « Gérer les matières » → CurriculumManager (coefficients).
 */
class CurriculumIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Curriculum::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [
                [
                    'type'  => 'route',
                    'route' => mt_get_route('curricula_manage', ['id' => $rowId]),
                    'label' => __('mtschool::structure.manage_subjects'),
                    'icon'  => 'book',
                ],
            ],
        ];
    }

    public function columns($rowId = null): array
    {
        $data       = $rowId ? Curriculum::with(['gradeLevel', 'specialization', 'subjects'])->find($rowId) : null;
        $subjects   = $data?->subjects ?? collect();
        $totalCoef  = $subjects->sum(fn ($s) => (float) ($s->pivot->coefficient ?? 0));

        return [
            'firstColumn' => [
                'field'       => 'label',
                'label'       => __('mtschool::structure.col_curriculum'),
                'value'       => $data?->label,
                'showLetters' => true,
                'letters'     => $data?->gradeLevel?->abbreviation ?? $data?->gradeLevel?->code,
                'metaDatas'   => array_filter([
                    $data?->gradeLevel?->label,
                    $data?->specialization?->code,
                ]),
            ],

            'othersColumns' => [
                'subjects' => [
                    'label' => __('mtschool::structure.subjects'),
                    'value' => __('mtschool::structure.subject_count', ['n' => $subjects->count()]),
                ],
                'coef' => [
                    'label' => __('mtschool::structure.total_coefficient'),
                    'value' => number_format($totalCoef, 2, ',', ' '),
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_f') : __('mtschool::common.inactive_f'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'curriculum',
            'model_plural' => 'curricula',
            'mainLabel'    => __('mtschool::structure.curricula'),
            'title'        => __('mtschool::structure.curricula'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'code',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code'],
            'searchableFields' => [
                'direct'    => ['code'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_maquettes'),
                'value' => Curriculum::count(),
                'icon'  => 'rectangle-stack',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active'),
                'value' => Curriculum::where('active', true)->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
