<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\ClassCouncil;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtViews\Livewire\Indexes\GenericIndex;

/**
 * Conseils de classe = INSTANCE de base-index. Liste + filtres (période / classe /
 * statut) + stats du cycle de vie (planifiés / tenus / validés). La logique métier
 * (planification, PV, participants, validation) vit sur le composant hôte
 * ClassCouncilManager (modales via extraPartials()).
 */
class ClassCouncilIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return ClassCouncil::class;
    }

    public function mainActions(): array
    {
        $custom = [];

        if (auth()->user()?->can('school.class_councils.manage')) {
            $custom[] = [
                'label'   => __('mtschool::councils.plan'),
                'icon'    => 'plus',
                'method'  => 'openCreate',
                'variant' => 'primary',
            ];
        }

        return ['create' => false, 'custom' => $custom];
    }

    public function rowActions($rowId): array
    {
        $council = ClassCouncil::find($rowId);

        $custom = [[
            'type'   => 'livewire',
            'method' => 'openManage',
            'params' => $rowId,
            'label'  => __('mtschool::councils.manage'),
            'icon'   => 'eye',
        ]];

        if (auth()->user()?->can('school.class_councils.manage') && $council && ! $council->isValidated()) {
            $custom[] = [
                'type'    => 'livewire',
                'method'  => 'deleteCouncil',
                'params'  => $rowId,
                'label'   => __('mtschool::common.delete'),
                'icon'    => 'trash',
                'variant' => 'danger',
            ];
        }

        return ['edit' => false, 'delete' => false, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $c = $rowId
            ? ClassCouncil::with(['classroom', 'period'])->withCount('participants')->find($rowId)
            : null;

        $variant = [
            'planned' => 'info', 'held' => 'warning',
            'minutes_drafted' => 'warning', 'validated' => 'success',
        ][$c?->status] ?? 'secondary';

        return [
            'firstColumn' => [
                'field'     => 'title',
                'label'     => __('mtschool::pedagogy.sup_class'),
                'value'     => $c?->classroom?->code ?? '—',
                'metaDatas' => array_filter([$c?->period?->label]),
            ],
            'othersColumns' => [
                'council_date' => [
                    'label' => __('mtschool::councils.date'),
                    'value' => $c?->council_date?->format('d/m/Y H:i') ?? '—',
                ],
                'location' => [
                    'label' => __('mtschool::councils.location'),
                    'value' => $c && $c->location ? $c->location : '—',
                ],
                'participants' => [
                    'label' => __('mtschool::councils.participants'),
                    'value' => $c ? (int) $c->participants_count : 0,
                    'align' => 'center',
                ],
                'state' => [
                    'label'      => __('mtschool::pedagogy.sup_state'),
                    'value'      => $c ? __('mtschool::councils.status_' . $c->status) : '—',
                    'badgeDatas' => $c ? [
                        'label' => __('mtschool::councils.status_' . $c->status),
                        'type'  => $variant,
                    ] : [],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'class_council',
            'model_plural' => 'class_councils',
            'mainLabel'    => __('mtschool::councils.title'),
            'title'        => __('mtschool::councils.title'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => false,
                'perPage'              => 25,
                'defaultSort'          => 'council_date',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['council_date'],
            'searchableFields' => [],
        ];
    }

    public function getFiltersConfig(): array
    {
        return [
            'period_id' => [
                'label'   => __('mtschool::councils.period'),
                'type'    => 'select',
                'options' => Period::orderBy('order')->orderBy('start_date')
                    ->get()->mapWithKeys(fn ($p) => [$p->id => $p->label])->toArray(),
            ],
            'class_id' => [
                'label'   => __('mtschool::pedagogy.sup_class'),
                'type'    => 'select',
                'options' => Classroom::orderBy('code')->pluck('code', 'id')->toArray(),
            ],
            'status' => [
                'label'   => __('mtschool::pedagogy.sup_state'),
                'type'    => 'select',
                'options' => [
                    'planned'         => __('mtschool::councils.status_planned'),
                    'held'            => __('mtschool::councils.status_held'),
                    'minutes_drafted' => __('mtschool::councils.status_minutes_drafted'),
                    'validated'       => __('mtschool::councils.status_validated'),
                ],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::councils.status_planned_plural'),
                'value' => ClassCouncil::where('status', 'planned')->count(),
                'icon'  => 'calendar-days',
                'color' => 'info',
            ],
            [
                'label' => __('mtschool::councils.status_held_plural'),
                'value' => ClassCouncil::whereIn('status', ['held', 'minutes_drafted'])->count(),
                'icon'  => 'clock',
                'color' => 'warning',
            ],
            [
                'label' => __('mtschool::councils.status_validated_plural'),
                'value' => ClassCouncil::where('status', 'validated')->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
