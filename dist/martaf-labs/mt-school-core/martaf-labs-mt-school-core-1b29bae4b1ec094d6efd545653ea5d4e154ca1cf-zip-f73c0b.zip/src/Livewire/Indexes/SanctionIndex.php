<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\DisciplinarySanction;
use Mt\MtViews\Livewire\Indexes\GenericIndex;

/** Sanctions disciplinaires (vie scolaire). */
class SanctionIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return DisciplinarySanction::class;
    }

    public function mainActions(): array
    {
        return ['create' => true, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        $custom   = [];
        $sanction = DisciplinarySanction::find($rowId);

        if ($sanction) {
            if ($sanction->status === 'active') {
                $custom[] = [
                    'type' => 'livewire', 'method' => 'liftSanction', 'params' => $rowId,
                    'label' => __('mtschool::academics.sanction_lift'), 'icon' => 'check-circle',
                ];
            }
            if (! $sanction->parent_notified) {
                $custom[] = [
                    'type' => 'livewire', 'method' => 'markParentNotified', 'params' => $rowId,
                    'label' => __('mtschool::academics.sanction_notify'), 'icon' => 'bell',
                ];
            }
        }

        return ['edit' => true, 'delete' => true, 'custom' => $custom];
    }

    public function columns($rowId = null): array
    {
        $data    = $rowId ? DisciplinarySanction::with('enrollment.student')->find($rowId) : null;
        $student = $data?->enrollment?->student;
        $active  = ($data?->status ?? 'active') === 'active';

        return [
            'firstColumn' => [
                'field'       => 'label',
                'label'       => __('mtschool::academics.col_sanction'),
                'value'       => $student?->full_name_reverse ?? $student?->full_name ?? '—',
                'showLetters' => true,
                'letters'     => $student ? mb_substr($student->first_name ?? '', 0, 1) . mb_substr($student->last_name ?? '', 0, 1) : null,
                'metaDatas'   => array_filter([
                    $data?->type?->label(),
                    $data?->sanction_date?->format('d/m/Y'),
                ]),
            ],
            'othersColumns' => [
                'type' => [
                    'label' => __('mtschool::common.type'),
                    'value' => $data?->type?->label() ?? '—',
                ],
                'parent' => [
                    'label'      => __('mtschool::academics.parent_col'),
                    'value'      => $data?->parent_notified ? __('mtschool::academics.notified') : __('mtschool::academics.not_notified'),
                    'badgeDatas' => $data?->parent_notified
                        ? ['label' => __('mtschool::academics.notified'), 'color' => 'success']
                        : ['label' => __('mtschool::common.no'), 'color' => 'secondary'],
                ],
                'status' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $active ? __('mtschool::academics.status_ongoing') : __('mtschool::academics.status_lifted'),
                    'badgeDatas' => $active
                        ? ['label' => __('mtschool::academics.status_ongoing'), 'color' => 'warning']
                        : ['label' => __('mtschool::academics.status_lifted'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'sanction',
            'model_plural' => 'sanctions',
            'mainLabel'    => __('mtschool::academics.sanctions'),
            'title'        => __('mtschool::academics.sanctions'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'sanction_date',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['sanction_date'],
            'searchableFields' => ['direct' => ['reference'], 'relations' => []],
        ];
    }

    public function getStatistics(): array
    {
        return [
            ['label' => __('mtschool::academics.sanctions'), 'value' => DisciplinarySanction::count(), 'icon' => 'exclamation-triangle', 'color' => 'primary'],
            ['label' => __('mtschool::academics.stat_ongoing'), 'value' => DisciplinarySanction::where('status', 'active')->count(), 'icon' => 'shield-exclamation', 'color' => 'warning'],
        ];
    }
}
