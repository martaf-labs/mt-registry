<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtViews\Livewire\Indexes\GenericIndex;

/**
 * Classes de l'année active, avec leur progression d'affectation des enseignants.
 * Action « Gérer les affectations » → CourseAssignmentManager.
 */
class ClassAssignmentIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Classroom::class;
    }

    public function mainActions(): array
    {
        return ['create' => false, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => false,
            'delete' => false,
            'custom' => [
                [
                    'type'  => 'route',
                    'route' => mt_get_route('staff_assignments_manage', ['id' => $rowId]),
                    'label' => __('mtschool::academics.manage_assignments'),
                    'icon'  => 'arrow-right-left',
                ],
            ],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = $rowId ? Classroom::with('gradeLevel', 'specialization')->find($rowId) : null;

        $total = 0;
        if ($data) {
            $curriculum = Curriculum::where('grade_level_id', $data->grade_level_id)
                ->where('specialization_id', $data->specialization_id)->first();
            $total = $curriculum ? $curriculum->subjects()->count() : 0;
        }

        $assigned = $data ? CourseAssignment::where('class_id', $data->id)->distinct('subject_id')->count('subject_id') : 0;

        return [
            'firstColumn' => [
                'field'       => 'label',
                'label'       => __('mtschool::structure.col_classroom'),
                'value'       => $data?->label,
                'showLetters' => true,
                'letters'     => $data?->abbreviation ?? $data?->code,
                'metaDatas'   => array_filter([
                    $data?->gradeLevel?->label,
                    $data?->specialization?->code,
                ]),
            ],

            'othersColumns' => [
                'progress' => [
                    'label'      => __('mtschool::academics.assignments_progress'),
                    'value'      => $assigned . '/' . $total,
                    'badgeDatas' => $total > 0 && $assigned >= $total
                        ? ['label' => __('mtschool::academics.complete'), 'color' => 'success']
                        : ($assigned > 0
                            ? ['label' => $assigned . '/' . $total, 'color' => 'warning']
                            : ['label' => __('mtschool::academics.todo'), 'color' => 'secondary']),
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_f') : __('mtschool::common.inactive_f'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_f'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'classroom',
            'model_plural' => 'classes',
            'mainLabel'    => __('mtschool::academics.assignments'),
            'title'        => __('mtschool::academics.assignments'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'code',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code'],
            'searchableFields' => [
                'direct'    => ['code', 'abbreviation'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.classrooms'),
                'value' => Classroom::count(),
                'icon'  => 'user-group',
                'color' => 'primary',
            ],
        ];
    }
}
