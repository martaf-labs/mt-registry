<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtViews\Livewire\Indexes\GenericIndex;

class CycleIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Cycle::class;
    }

    public function mainActions(): array
    {
        return [
            'create' => true,
            'custom' => [],
        ];
    }

    public function rowActions($rowId): array
    {
        return [
            'edit'   => true,
            'delete' => true,
            'custom' => [],
        ];
    }

    public function columns($rowId = null): array
    {
        $data = Cycle::find($rowId);

        return [
            'firstColumn' => [
                'field'       => 'code',
                'label'       => __('mtschool::structure.col_cycle'),
                'value'       => $data?->code,
                'showLetters' => true,
                'letters'     => $data?->code,
                'metaDatas'   => array_filter([
                    $data?->type?->label(),
                    __('mtschool::structure.level_count', ['n' => $data?->gradeLevels()->count()]),
                ]),
            ],

            'othersColumns' => [
                'type' => [
                    'label'      => __('mtschool::common.type'),
                    'value'      => $data?->type?->label(),
                    'badgeDatas' => $data?->type
                        ? ['label' => $data->type->label(), 'color' => $data->type->badge()]
                        : null,
                ],
                'active' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $data?->active ? __('mtschool::common.active_m') : __('mtschool::common.inactive_m'),
                    'badgeDatas' => $data?->active
                        ? ['label' => __('mtschool::common.active_m'), 'color' => 'success']
                        : ['label' => __('mtschool::common.inactive_m'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'cycle',
            'model_plural' => 'cycles',
            'mainLabel'    => __('mtschool::structure.cycles'),
            'title'        => __('mtschool::structure.cycles'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'order',
                'defaultSortDirection' => 'asc',
            ],

            'filters'          => [],
            'sortableFields'   => ['code', 'order'],
            'searchableFields' => [
                'direct'    => ['code'],
                'relations' => [],
            ],
        ];
    }

    public function getStatistics(): array
    {
        return [
            [
                'label' => __('mtschool::structure.stat_total'),
                'value' => Cycle::count(),
                'icon'  => 'rectangle-stack',
                'color' => 'primary',
            ],
            [
                'label' => __('mtschool::structure.stat_active_m'),
                'value' => Cycle::active()->count(),
                'icon'  => 'check-circle',
                'color' => 'success',
            ],
        ];
    }
}
