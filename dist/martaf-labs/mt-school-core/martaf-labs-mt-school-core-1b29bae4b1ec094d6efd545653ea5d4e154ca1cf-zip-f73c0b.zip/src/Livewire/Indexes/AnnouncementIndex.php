<?php

namespace Mt\MtSchoolCore\Livewire\Indexes;

use Mt\MtSchoolCore\Models\Announcement;
use Mt\MtViews\Livewire\Indexes\GenericIndex;

/** Annonces de l'établissement. */
class AnnouncementIndex extends GenericIndex
{
    public static function modelClass(): string
    {
        return Announcement::class;
    }

    public function mainActions(): array
    {
        return ['create' => true, 'custom' => []];
    }

    public function rowActions($rowId): array
    {
        return ['edit' => true, 'delete' => true, 'custom' => []];
    }

    public function columns($rowId = null): array
    {
        $data = Announcement::find($rowId);

        $audienceLabels = [
            'all'      => __('mtschool::academics.audience_all'),
            'students' => __('mtschool::academics.audience_students'),
            'parents'  => __('mtschool::academics.audience_parents'),
            'teachers' => __('mtschool::academics.audience_teachers'),
        ];
        $impMap = [
            'urgent'    => [__('mtschool::academics.importance_urgent'), 'danger'],
            'important' => [__('mtschool::academics.importance_important'), 'warning'],
            'normal'    => [__('mtschool::academics.importance_normal'), 'secondary'],
        ];
        [$impLbl, $impCol] = $impMap[$data?->importance ?? 'normal'] ?? $impMap['normal'];
        $published = ($data?->status ?? 'draft') === 'published';

        return [
            'firstColumn' => [
                'field'       => 'title',
                'label'       => __('mtschool::academics.col_announcement'),
                'value'       => $data?->title,
                'showLetters' => true,
                'letters'     => 'A',
                'metaDatas'   => array_filter([
                    $audienceLabels[$data?->audience_type ?? 'all'] ?? null,
                    $data?->published_at?->format('d/m/Y'),
                ]),
            ],
            'othersColumns' => [
                'importance' => [
                    'label'      => __('mtschool::academics.importance'),
                    'value'      => $impLbl,
                    'badgeDatas' => ['label' => $impLbl, 'color' => $impCol],
                ],
                'status' => [
                    'label'      => __('mtschool::common.status'),
                    'value'      => $published ? __('mtschool::common.published_f') : __('mtschool::common.draft'),
                    'badgeDatas' => $published
                        ? ['label' => __('mtschool::common.published_f'), 'color' => 'success']
                        : ['label' => __('mtschool::common.draft'), 'color' => 'secondary'],
                ],
            ],
        ];
    }

    public function configuration(): array
    {
        return [
            'model'        => 'announcement',
            'model_plural' => 'announcements',
            'mainLabel'    => __('mtschool::academics.announcements'),
            'title'        => __('mtschool::academics.announcements'),

            'features' => [
                'canAddImages'         => false,
                'searchable'           => true,
                'perPage'              => 20,
                'defaultSort'          => 'id',
                'defaultSortDirection' => 'desc',
            ],

            'filters'          => [],
            'sortableFields'   => ['id'],
            'searchableFields' => ['direct' => [], 'relations' => []],
        ];
    }

    public function getStatistics(): array
    {
        return [
            ['label' => __('mtschool::academics.announcements'), 'value' => Announcement::count(), 'icon' => 'megaphone', 'color' => 'primary'],
            ['label' => __('mtschool::academics.stat_published'), 'value' => Announcement::where('status', 'published')->count(), 'icon' => 'check-circle', 'color' => 'success'],
        ];
    }
}
