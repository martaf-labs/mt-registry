<?php

namespace Mt\MtSchoolCore\Livewire\Calendar;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Mt\MtSchoolCore\Enums\RoleSchool;
use Mt\MtSchoolCore\Models\CalendarEvent;

/**
 * Calendrier de l'établissement. Le personnel (direction/staff) gère les événements
 * (création, publication, suppression) ; les rôles-portail (parent/élève/enseignant)
 * consultent en lecture seule les événements publiés. Cloisonné par école + année.
 */
#[Layout('mt::components.layouts.app')]
class CalendarManager extends Component
{
    public bool $showCreate = false;
    public string $title = '';
    public string $type = 'event';
    public $startsAt = null;
    public $endsAt = null;
    public string $location = '';

    public string $successMessage = '';

    public const TYPES = [
        'event'   => 'Événement',
        'meeting' => 'Réunion',
        'exam'    => 'Examen',
        'holiday' => 'Congé',
        'other'   => 'Autre',
    ];

    public const TYPE_COLORS = [
        'event'   => '#6366f1',
        'meeting' => '#0ea5e9',
        'exam'    => '#f59e0b',
        'holiday' => '#22c55e',
        'other'   => '#64748b',
    ];

    /** Le personnel non-portail peut gérer ; les rôles-portail sont en lecture seule. */
    #[Computed]
    public function canManage(): bool
    {
        $role = Auth::user()?->school_role;

        return $role !== null && ! in_array($role, [
            RoleSchool::PARENT, RoleSchool::STUDENT, RoleSchool::TEACHER,
        ], true);
    }

    #[Computed]
    public function events()
    {
        $q = CalendarEvent::query()->orderBy('starts_at');

        // Les portails ne voient que le publié ; le staff voit tout.
        if (! $this->canManage) {
            $q->where('published', true);
        }

        return $q->where('starts_at', '>=', now()->startOfDay())
            ->limit(50)
            ->get()
            ->map(function ($e) {
                return (object) [
                    'id'        => $e->id,
                    'title'     => $e->title,
                    'type'      => $e->type,
                    'type_label'=> __('mtschool::calendar.type_' . $e->type),
                    'color'     => $e->color ?: (self::TYPE_COLORS[$e->type] ?? '#6366f1'),
                    'starts_at' => $e->starts_at,
                    'ends_at'   => $e->ends_at,
                    'all_day'   => $e->all_day,
                    'location'  => $e->location,
                    'published' => $e->published,
                ];
            });
    }

    public function openCreate(): void
    {
        abort_unless($this->canManage, 403);
        $this->reset(['title', 'location']);
        $this->type = 'event';
        $this->startsAt = now()->addDay()->setTime(9, 0)->format('Y-m-d\TH:i');
        $this->endsAt = now()->addDay()->setTime(10, 0)->format('Y-m-d\TH:i');
        $this->showCreate = true;
        $this->dispatch('open-create-event');
    }

    public function createEvent(): void
    {
        abort_unless($this->canManage, 403);

        $this->validate([
            'title'    => 'required|string|max:180',
            'type'     => 'required|in:' . implode(',', array_keys(self::TYPES)),
            'startsAt' => 'required|date',
            'endsAt'   => 'nullable|date|after_or_equal:startsAt',
            'location' => 'nullable|string|max:180',
        ], [], ['title' => 'intitulé', 'startsAt' => 'début', 'endsAt' => 'fin']);

        $locale = config('mt-school-core.multilingual.default', 'fr');

        CalendarEvent::create([
            'title'         => [$locale => $this->title],
            'type'          => $this->type,
            'audience_type' => 'all',
            'starts_at'     => $this->startsAt,
            'ends_at'       => $this->endsAt ?: null,
            'all_day'       => false,
            'location'      => $this->location ? [$locale => $this->location] : null,
            'color'         => self::TYPE_COLORS[$this->type] ?? '#6366f1',
            'published'     => true,
        ]);

        $this->showCreate = false;
        unset($this->events);
        $this->dispatch('close-modal', name: 'create-event');
        $this->successMessage = __('mtschool::calendar.event_added');
    }

    public function togglePublish(int $id): void
    {
        abort_unless($this->canManage, 403);
        $e = CalendarEvent::findOrFail($id);
        $e->update(['published' => ! $e->published]);
        unset($this->events);
    }

    public function delete(int $id): void
    {
        abort_unless($this->canManage, 403);
        CalendarEvent::findOrFail($id)->delete();
        unset($this->events);
        $this->successMessage = __('mtschool::calendar.event_deleted');
    }

    public function render()
    {
        return view('mtschool::livewire.calendar.manager')
            ->title(__('mtschool::calendar.title'));
    }
}
