<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Specialization;
use Mt\MtViews\Livewire\Forms\GenericForm;

class SpecializationForm extends GenericForm
{
    public $code         = null;
    public $label        = null;
    public $abbreviation = null;
    public $color        = null;
    public $description  = null;
    public $active       = true;
    public $grade_level_ids = [];

    public function schema(): array
    {
        return [
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.spec_code_ph'),
                'placeholder' => 'SCI',
                'col'         => 6,
            ],
            'abbreviation' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.abbreviation'),
                'placeholder' => 'S',
                'col'         => 6,
            ],
            'label' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.full_label_field'),
                'col'   => 12,
            ],
            'color' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.color_hex'),
                'col'   => 6,
            ],
            'active' => [
                'type'  => 'checkbox',
                'label' => __('mtschool::structure.spec_active'),
                'col'   => 6,
            ],
            'description' => [
                'type'  => 'textarea',
                'label' => __('mtschool::common.description'),
                'col'   => 12,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);

        return [
            'code'            => [$isEdit ? 'nullable' : 'required', 'string', 'max:30', Rule::unique('specializations', 'code')->where('school_id', currentSchoolId())->ignore($modelId)], // unicité PAR école
            'label'           => 'nullable',
            'abbreviation'    => 'nullable|string|max:10',
            'color'           => 'nullable|string|max:20',
            'description'     => 'nullable|array', // traduisible → coerce en tableau par le base-form ; |string casse (cf. SchoolYearForm)
            'active'          => 'boolean',
            'grade_level_ids' => 'nullable|array',
            'grade_level_ids.*' => 'exists:grade_levels,id',
        ];
    }

    public function messages(): array
    {
        return [
            'code.required' => __('mtschool::structure.spec_code_required'),
            'code.unique'   => __('mtschool::structure.spec_code_unique'),
        ];
    }

    public static function modelClass(): string
    {
        return Specialization::class;
    }

    public function fillModel(Model $model): void
    {
        parent::fillModel($model);
        $this->grade_level_ids = $model->gradeLevels()->pluck('grade_levels.id')->toArray();
    }

    protected function getModelId(): ?int
    {
        if (!isset($this->component)) {
            return null;
        }
        try {
            return $this->component->modelData()?->id ?? null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            $gradeLevelIds = $data['grade_level_ids'] ?? [];
            unset($data['grade_level_ids']);
            // Colonnes NOT NULL à défaut DB (ex. color) : ne pas forcer null.
            $data = array_filter($data, fn ($v) => !is_null($v));

            if ($model) {
                $model->update($data);
            } else {
                $model = Specialization::create($data);
            }

            $model->gradeLevels()->sync($gradeLevelIds);

            return $model;
        });
    }
}
