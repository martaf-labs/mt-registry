<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Specialization;
use Mt\MtViews\Livewire\Forms\GenericForm;

/**
 * Maquette pédagogique (programme) : pour un niveau (+ filière) de l'année active.
 * Le code et le libellé sont AUTO-générés. Les matières & coefficients se gèrent
 * ensuite dans le CurriculumManager (curriculum_subject).
 */
class CurriculumForm extends GenericForm
{
    public $grade_level_id    = null;
    public $specialization_id = null;
    public $active            = true;

    public function schema(): array
    {
        return [
            'grade_level_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.grade_level_select'),
                'options' => GradeLevel::orderBy('order')->get()
                                ->mapWithKeys(fn ($g) => [$g->id => $g->label])->toArray(),
                'col'     => 6,
            ],
            'specialization_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.specialization_opt'),
                'options' => Specialization::active()->orderBy('code')->pluck('code', 'id')->toArray(),
                'col'     => 6,
            ],
            'active' => [
                'type'  => 'toggle',
                'label' => __('mtschool::structure.curriculum_active'),
                'col'   => 12,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();

        return [
            'grade_level_id' => [
                'required', 'integer', 'exists:grade_levels,id',
                // Une seule maquette par (niveau, filière) pour l'année active.
                Rule::unique('curricula', 'grade_level_id')
                    ->where('school_id', currentSchoolId())
                    ->where('school_year_id', activeSchoolYearId())
                    ->where('specialization_id', $this->specialization_id)
                    ->ignore($modelId),
            ],
            'specialization_id' => 'nullable|integer|exists:specializations,id',
            'active'            => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'grade_level_id.required' => __('mtschool::structure.level_required'),
            'grade_level_id.unique'   => __('mtschool::structure.curriculum_level_unique'),
        ];
    }

    public static function modelClass(): string
    {
        return Curriculum::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            // Code + libellé auto-générés depuis le niveau (+ filière).
            $gl = GradeLevel::find($data['grade_level_id']);
            $sp = $data['specialization_id'] ? Specialization::find($data['specialization_id']) : null;

            $glTag = $gl?->abbreviation ?: $gl?->code ?: ('N' . $data['grade_level_id']);
            $data['code']  = 'CURR-' . strtoupper($glTag) . ($sp ? '-' . strtoupper($sp->code) : '');

            $locale = config('mt-school-core.multilingual.default', 'fr');
            $levelLabel = ($gl?->label ?? '') . ($sp ? ' — ' . $sp->code : '');
            $data['label'] = [$locale => __('mtschool::structure.program_label', ['level' => $levelLabel])];

            if ($model) {
                $model->update($data);
            } else {
                $model = Curriculum::create($data);
            }

            return $model;
        });
    }
}
