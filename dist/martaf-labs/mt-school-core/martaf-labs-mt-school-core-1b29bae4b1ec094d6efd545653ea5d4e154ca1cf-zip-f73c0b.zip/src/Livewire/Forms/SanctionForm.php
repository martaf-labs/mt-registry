<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Enums\SanctionType;
use Mt\MtSchoolCore\Models\DisciplinarySanction;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtViews\Livewire\Forms\GenericForm;

/** Sanction disciplinaire d'un élève (vie scolaire). */
class SanctionForm extends GenericForm
{
    public $enrollment_id   = null;
    public $type            = 'warning';
    public $reason          = null;
    public $sanction_date   = null;
    public $end_date        = null;
    public $status          = 'active';
    public $parent_notified = false;
    public $follow_up       = null;

    public function schema(): array
    {
        return [
            'enrollment_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.student_field'),
                'options' => Enrollment::validated()->with(['student', 'classroom'])->get()
                                ->mapWithKeys(fn ($e) => [
                                    $e->id => ($e->student?->full_name_reverse ?? '—') . ' — ' . ($e->classroom?->label ?? ''),
                                ])->toArray(),
                'col'     => 12,
            ],
            'type' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.sanction_type_field'),
                'options' => collect(SanctionType::cases())->mapWithKeys(fn ($t) => [$t->value => $t->label()])->toArray(),
                'col'     => 6,
            ],
            'status' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.sanction_status_field'),
                'options' => ['active' => __('mtschool::academics.status_ongoing'), 'lifted' => __('mtschool::academics.status_lifted')],
                'col'     => 6,
            ],
            'sanction_date' => ['type' => 'date', 'label' => __('mtschool::academics.date_field'), 'col' => 6],
            'end_date'      => ['type' => 'date', 'label' => __('mtschool::academics.end_date_optional'), 'col' => 6],
            'reason'        => ['type' => 'textarea', 'label' => __('mtschool::academics.reason_field'), 'col' => 12],
            'follow_up'     => ['type' => 'textarea', 'label' => __('mtschool::academics.follow_up_field'), 'col' => 12],
            'parent_notified' => ['type' => 'toggle', 'label' => __('mtschool::academics.parent_notified_field'), 'col' => 12],
        ];
    }

    public function rules(): array
    {
        return [
            'enrollment_id'   => 'required|integer|exists:enrollments,id',
            'type'            => ['required', Rule::in(array_map(fn ($c) => $c->value, SanctionType::cases()))],
            'reason'          => 'required|array',
            'sanction_date'   => 'required|date',
            'end_date'        => 'nullable|date',
            'status'          => ['nullable', Rule::in(['active', 'lifted'])],
            'parent_notified' => 'boolean',
            'follow_up'       => 'nullable|array',
        ];
    }

    public function messages(): array
    {
        return [
            'enrollment_id.required' => __('mtschool::academics.student_required'),
            'reason.required'        => __('mtschool::academics.reason_required'),
            'sanction_date.required' => __('mtschool::academics.sanction_date_required'),
        ];
    }

    public static function modelClass(): string
    {
        return DisciplinarySanction::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data   = $this->validate();
            $locale = config('mt-school-core.multilingual.default', 'fr');

            $data['label'] = [$locale => SanctionType::from($data['type'])->label()];

            if ($model) {
                $model->update($data);
            } else {
                $data['reference']  = 'SAN-' . strtoupper(substr(uniqid(), -6));
                $data['issued_by']  = auth()->id(); // tracer QUI a émis la sanction
                if (! empty($data['parent_notified'])) {
                    $data['parent_notified_at'] = now();
                }
                $model = DisciplinarySanction::create($data);
                // Notifie les tuteurs de l'élève de la nouvelle sanction.
                app(\Mt\MtSchoolCore\Services\NotificationService::class)->notifySanction($model);
            }

            return $model;
        });
    }
}
