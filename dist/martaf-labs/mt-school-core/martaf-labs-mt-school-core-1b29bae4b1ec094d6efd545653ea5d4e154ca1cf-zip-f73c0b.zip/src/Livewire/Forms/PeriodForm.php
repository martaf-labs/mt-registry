<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Mt\MtSchoolCore\Enums\PeriodType;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtViews\Livewire\Forms\GenericForm;

class PeriodForm extends GenericForm
{
    public $school_year_id = null;
    public $parent_id      = null;
    public $code           = null;
    public $label          = null;
    public $type           = PeriodType::TERM->value;
    public $order          = 1;
    public $start_date     = null;
    public $end_date       = null;
    public $weight         = 1.00;
    public $is_active      = true;
    public $is_closed      = false;

    public function schema(): array
    {
        return [
            'school_year_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.period_school_year'),
                'options' => SchoolYear::orderByDesc('start_date')->pluck('code', 'id'),
                'col'     => 6,
            ],
            'type' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.period_type'),
                'options' => PeriodType::options(),
                'col'     => 6,
            ],
            'parent_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.parent_period'),
                'options' => Period::whereNull('parent_id')->orderBy('order')->pluck('code', 'id'),
                'col'     => 6,
            ],
            'code' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.period_code_ph'),
                'col'   => 6,
            ],
            'label' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.label_field'),
                'col'   => 12,
            ],
            'start_date' => [
                'type'  => 'date',
                'label' => __('mtschool::structure.start_date'),
                'col'   => 6,
            ],
            'end_date' => [
                'type'  => 'date',
                'label' => __('mtschool::structure.end_date'),
                'col'   => 6,
            ],
            'order' => [
                'type'  => 'number',
                'label' => __('mtschool::common.order'),
                'col'   => 4,
            ],
            'weight' => [
                'type'  => 'number',
                'label' => __('mtschool::structure.weight'),
                'col'   => 4,
            ],
            'is_active' => [
                'type'  => 'toggle',
                'label' => __('mtschool::structure.period_active'),
                'col'   => 4,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();

        return [
            'school_year_id' => 'required|exists:school_years,id',
            'parent_id'      => 'nullable|exists:periods,id',
            'code'           => 'required|string|max:20',
            'label'          => 'nullable',
            'type'           => 'required|string|in:' . implode(',', array_column(PeriodType::cases(), 'value')),
            'order'          => 'required|integer|min:1',
            'start_date'     => 'required|date',
            'end_date'       => 'required|date|after:start_date',
            'weight'         => 'required|numeric|min:0',
            'is_active'      => 'boolean',
            'is_closed'      => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'school_year_id.required' => __('mtschool::structure.year_required'),
            'code.required'           => __('mtschool::structure.period_code_required'),
            'type.required'           => __('mtschool::structure.period_type_required'),
            'start_date.required'     => __('mtschool::common.date_start_required'),
            'end_date.required'       => __('mtschool::common.date_end_required'),
            'end_date.after'          => __('mtschool::common.date_end_after'),
        ];
    }

    public static function modelClass(): string
    {
        return Period::class;
    }

    protected function getModelId(): ?int
    {
        if (!isset($this->component)) {
            return null;
        }
        try {
            return $this->component->modelData()?->id ?? null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            if ($model) {
                $model->update($data);
                return $model;
            }

            return Period::create($data);
        });
    }
}
