<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Room;
use Mt\MtSchoolCore\Models\Specialization;
use Mt\MtViews\Contracts\HasBaseFormContract;
use Mt\MtViews\Livewire\Forms\GenericForm;

class ClassroomForm extends GenericForm implements HasBaseFormContract
{
    public $cycle_id          = null;   // transient — cascade uniquement, non persisté
    public $grade_level_id    = null;
    public $specialization_id = null;
    public $room_id           = null;
    public $code              = null;
    public $label             = ['fr' => '', 'en' => '', 'ar' => ''];
    public $abbreviation      = null;
    public $max_capacity      = 40;
    public $teaching_language = null;
    public $active            = true;
    public $notes             = ['fr' => '', 'en' => '', 'ar' => ''];

    // =========================================================================
    // SCHEMA
    // =========================================================================

    public function schema(): array
    {
        // Détails communs. L'année scolaire est IMPLICITE (année active).
        // Le code est ABSENT ici : proposé en création, FIGÉ en édition.
        $details = [
            'label'        => ['type' => 'text', 'label' => __('mtschool::structure.proposed_label'), 'col' => 6],
            'abbreviation' => ['type' => 'text', 'label' => __('mtschool::structure.abbreviation'), 'placeholder' => 'CM1A', 'col' => 6],
            'specialization_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.specialization_opt'),
                'options' => Specialization::active()->orderBy('code')->pluck('code', 'id'),
                'col'     => 6,
            ],
            'room_id' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.room_opt'),
                'options' => Room::active()->orderBy('code')->pluck('code', 'id'),
                'col'     => 6,
            ],
            'teaching_language' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.teaching_language'),
                'options' => ['fr' => 'Français', 'en' => 'English', 'ar' => 'العربية'],
                'col'     => 6,
            ],
            'max_capacity' => ['type' => 'number', 'label' => __('mtschool::structure.max_capacity'), 'col' => 6],
            'active'       => ['type' => 'toggle', 'label' => __('mtschool::structure.classroom_active'), 'col' => 6],
            'notes'        => ['type' => 'textarea', 'label' => __('mtschool::structure.notes'), 'col' => 12],
        ];

        // ── Édition : formulaire plat. Code figé (non affiché, visible au fil d'Ariane). ──
        if ($this->isEdit()) {
            return array_merge([
                'grade_level_id' => [
                    'type'    => 'select',
                    'label'   => __('mtschool::structure.grade_level_select'),
                    'options' => GradeLevel::active()->with('cycle')->orderBy('order')->get()
                        ->mapWithKeys(fn ($gl) => [$gl->id => $gl->cycle?->code . ' — ' . $gl->code]),
                    'col'     => 6,
                ],
            ], $details);
        }

        // ── Création : cascade Cycle → Niveau → détails (code + label proposés) ──
        return array_merge([
            'cycle_id' => [
                'type'    => 'card-select',
                'label'   => __('mtschool::structure.cycle_select'),
                'live'    => true,
                'options' => Cycle::where('active', true)
                    ->whereHas('gradeLevels', fn ($q) => $q->where('active', true))
                    ->orderBy('order')->get()
                    ->mapWithKeys(fn ($c) => [$c->id => [
                        'title' => $this->loc($c),
                        'badge' => $c->code,
                        'icon'  => $c->icon ?: null,
                        'meta'  => __('mtschool::structure.level_count', ['n' => GradeLevel::where('cycle_id', $c->id)->where('active', true)->count()]),
                    ]]),
                'col'     => 12,
            ],
            'grade_level_id' => [
                'type'    => 'card-select',
                'label'   => __('mtschool::structure.grade_level_select'),
                'live'    => true,
                'options' => $this->cycle_id
                    ? GradeLevel::where('cycle_id', $this->cycle_id)->where('active', true)->orderBy('order')->get()
                        ->mapWithKeys(fn ($g) => [$g->id => [
                            'title' => $this->loc($g),
                            'badge' => $g->code,
                            'meta'  => __('mtschool::structure.existing_class_count', ['n' => $g->classes()->count()]),
                        ]])
                    : [],
                'col'     => 12,
            ],
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.class_code_ph'),
                'placeholder' => 'CM1-A',
                'help'        => __('mtschool::structure.class_code_help'),
                'col'         => 6,
            ],
        ], $details);
    }

    // =========================================================================
    // RULES
    // =========================================================================

    public function rules(): array
    {
        $detailRules = [
            'abbreviation'      => 'nullable|string|max:20',
            'label'             => 'nullable|array',          // champ JSON traduisible
            'label.*'           => 'nullable|string|max:100',
            'specialization_id' => 'nullable|exists:specializations,id',
            'room_id'           => 'nullable|exists:rooms,id',
            'teaching_language' => 'nullable|string|in:fr,en,ar',
            'max_capacity'      => 'required|integer|min:1',
            'active'            => 'boolean',
            'notes'             => 'nullable|array',
        ];

        // Édition : pas de règle sur le code (figé).
        if ($this->isEdit()) {
            return array_merge(['grade_level_id' => 'required|exists:grade_levels,id'], $detailRules);
        }

        return [
            1 => ['cycle_id'       => 'required|integer|exists:cycles,id'],
            2 => ['grade_level_id' => 'required|integer|exists:grade_levels,id'],
            3 => array_merge([
                // Code unique PAR ANNÉE active (le global scope ne s'applique pas au Rule::unique)
                'code' => ['required', 'string', 'max:30', Rule::unique('classes', 'code')
                    ->where(fn ($q) => $q->where('school_year_id', activeSchoolYearId())->whereNull('deleted_at'))],
            ], $detailRules),
        ];
    }

    public function messages(): array
    {
        if ($this->isEdit()) {
            return [
                'grade_level_id.required' => __('mtschool::structure.level_required'),
                'max_capacity.required'   => __('mtschool::structure.max_capacity_required'),
            ];
        }

        return [
            1 => ['cycle_id.required'       => __('mtschool::structure.select_cycle')],
            2 => ['grade_level_id.required' => __('mtschool::structure.select_level')],
            3 => [
                'code.required'         => __('mtschool::structure.class_code_required'),
                'code.unique'           => __('mtschool::structure.class_code_unique'),
                'max_capacity.required' => __('mtschool::structure.max_capacity_required'),
            ],
        ];
    }

    /**
     * Le système propose le CODE et le LIBELLÉ selon le niveau choisi, via le
     * mécanisme natif fieldActions « map » : niveau → code (« CM1-A ») + libellé.
     */
    public function fieldActions(): array
    {
        if ($this->isEdit()) {
            return [];
        }

        $codeMap = [];
        $labelMap = [];
        $locales  = array_keys(get_available_locales());

        foreach (GradeLevel::where('active', true)->get() as $gl) {
            $letter           = $this->nextSectionLetter($gl);
            $codeMap[$gl->id] = mb_strtoupper($gl->code) . '-' . $letter;

            // Libellé proposé PAR LANGUE : « <nom du niveau dans la langue> <lettre> »
            $glLabel = is_array($gl->label) ? $gl->label : ['fr' => (string) $gl->label];
            $labelMap[$gl->id] = collect($locales)->mapWithKeys(fn ($loc) => [
                $loc => trim(($glLabel[$loc] ?? $glLabel['fr'] ?? $gl->code) . ' ' . $letter),
            ])->all();
        }

        return [
            'grade_level_id' => [
                ['type' => 'map', 'target' => 'code',  'map' => $codeMap],
                ['type' => 'map', 'target' => 'label', 'map' => $labelMap],
            ],
        ];
    }

    public function getCriticalFields(): array
    {
        return ['cycle_id'];
    }

    /**
     * Prochaine lettre de section libre pour un niveau (année active via global scope).
     */
    protected function nextSectionLetter(GradeLevel $gl): string
    {
        $taken = $gl->classes()
            ->pluck('code')->map(fn ($c) => mb_strtoupper(trim((string) $c)))->all();

        $base = mb_strtoupper($gl->code) . '-';

        foreach (range('A', 'Z') as $letter) {
            if (! in_array($base . $letter, $taken, true)) {
                return $letter;
            }
        }

        return 'A';
    }

    public static function modelClass(): string
    {
        return Classroom::class;
    }

    // =========================================================================
    // SAVE
    // =========================================================================

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $code = $this->code ? strtoupper(trim($this->code)) : $this->code;

            // Libellé JSON traduisible : on garde les locales remplies, sinon dérivé du code
            $label = array_filter(is_array($this->label) ? $this->label : ['fr' => (string) $this->label]);
            if (empty($label)) {
                $label = ['fr' => $code ?: '—'];
            }

            $data = [
                'grade_level_id'    => $this->grade_level_id,
                'specialization_id' => $this->specialization_id ?: null,
                'room_id'           => $this->room_id ?: null,
                'abbreviation'      => $this->abbreviation ?: null,
                'label'             => $label,
                'max_capacity'      => $this->max_capacity,
                'teaching_language' => $this->teaching_language ?: null,
                'active'            => (bool) $this->active,
                'notes'             => $this->notes ?: null,
            ];

            // Édition : le code est FIGÉ (jamais réécrit). Année implicite intacte.
            if ($model) {
                $model->update($data);
                return $model;
            }

            // Création : code défini + school_year_id auto (BelongsToSchoolYear).
            $data['code'] = $code;

            return Classroom::create($data);
        });
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    protected function isEdit(): bool
    {
        try {
            return isset($this->component) && ! is_null($this->component->modelData());
        } catch (\Throwable) {
            return false;
        }
    }

    protected function loc($model): string
    {
        $label = $model->label ?? null;
        if (is_array($label)) {
            return $label[app()->getLocale()] ?? (reset($label) ?: $model->code);
        }
        return $label ?: $model->code;
    }
}
