<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Models\Announcement;
use Mt\MtViews\Livewire\Forms\GenericForm;

/** Annonce diffusée à un public (tous / élèves / parents / enseignants). */
class AnnouncementForm extends GenericForm
{
    public $title              = null;
    public $content            = null;
    public $audience_type      = 'all';
    public $importance         = 'normal';
    public $status             = 'draft';
    public $published_at       = null;
    public $expires_at         = null;
    public $email_notification = false;

    public function schema(): array
    {
        return [
            'title'   => ['type' => 'text', 'label' => __('mtschool::academics.title_field'), 'col' => 12],
            'content' => ['type' => 'textarea', 'label' => __('mtschool::academics.content_field'), 'rows' => 5, 'col' => 12],

            'audience_type' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.audience_field'),
                'options' => [
                    'all'      => __('mtschool::academics.audience_all'),
                    'students' => __('mtschool::academics.audience_students'),
                    'parents'  => __('mtschool::academics.audience_parents'),
                    'teachers' => __('mtschool::academics.audience_teachers'),
                ],
                'col'     => 6,
            ],
            'importance' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.importance'),
                'options' => [
                    'normal'    => __('mtschool::academics.importance_normal'),
                    'important' => __('mtschool::academics.importance_important'),
                    'urgent'    => __('mtschool::academics.importance_urgent'),
                ],
                'col'     => 6,
            ],
            'status' => [
                'type'    => 'select',
                'label'   => __('mtschool::academics.status_field'),
                'options' => ['draft' => __('mtschool::common.draft'), 'published' => __('mtschool::common.published_f')],
                'col'     => 6,
            ],
            'expires_at'   => ['type' => 'date', 'label' => __('mtschool::academics.expires_at'), 'col' => 6],

            'email_notification' => ['type' => 'toggle', 'label' => __('mtschool::academics.notify_email'), 'col' => 12],
        ];
    }

    public function rules(): array
    {
        return [
            'title'              => 'required|array',
            'content'            => 'required|array',
            'audience_type'      => ['required', Rule::in(['all', 'students', 'parents', 'teachers'])],
            'importance'         => ['nullable', Rule::in(['normal', 'important', 'urgent'])],
            'status'             => ['nullable', Rule::in(['draft', 'published'])],
            'expires_at'         => 'nullable|date',
            'email_notification' => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'title.required'   => __('mtschool::academics.title_required'),
            'content.required' => __('mtschool::academics.content_required'),
        ];
    }

    public static function modelClass(): string
    {
        return Announcement::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();

            // Publication immédiate si statut = publiée et pas de date fixée.
            if (($data['status'] ?? 'draft') === 'published') {
                $data['published_at'] = $model?->published_at ?? now();
            }

            if ($model) {
                $model->update($data);
            } else {
                $data['author_id'] = auth()->id();
                $model = Announcement::create($data);
            }

            // Notifie les destinataires (in-app) si l'annonce est publiée. Idempotent.
            app(\Mt\MtSchoolCore\Services\NotificationService::class)->notifyAnnouncement($model->refresh());

            return $model;
        });
    }
}
