<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtFoundation\Enums\CivilitePersonnel;
use Mt\MtFoundation\Enums\SexePersonnel;
use Mt\MtMedia\Services\MediaService;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtViews\Livewire\Forms\GenericForm;

/**
 * Tuteur (parent / responsable légal). Champs de nom traduisibles (règle `array`,
 * jamais `string`, cf. piège des formulaires structure).
 */
class GuardianForm extends GenericForm
{
    public $last_name  = null;
    public $first_name = null;
    public $gender     = null;
    public $title      = null;
    public $email      = null;
    public $phone      = null;
    public $occupation = null;
    public $address    = null;
    public $active     = true;
    public $photo      = null; // upload → média « photo » vedette (même convention que l'élève)

    public function schema(): array
    {
        // Aperçu de la photo existante en édition : chemin (encodé) du média vedette.
        $photoPath = null;
        if (is_numeric($this->getModelId())) {
            $media = Guardian::find($this->getModelId())?->image;
            $photoPath = $media?->path ? \Mt\MtMedia\Models\BaseMedia::encodeUrlPath($media->path) : null;
        }

        return [
            'photo'      => ['type' => 'image', 'label' => __('mtschool::students.guardian_photo'), 'col' => 12, 'oldvalue' => $photoPath],
            'last_name'  => ['type' => 'text', 'label' => __('mtschool::students.last_name'), 'col' => 6],
            'first_name' => ['type' => 'text', 'label' => __('mtschool::students.first_name'), 'col' => 6],
            // Genre = enum mt-foundation (M / F / non précisé), comme la civilité.
            'gender'     => [
                'type'    => 'select',
                'label'   => __('mtschool::students.gender'),
                'options' => SexePersonnel::options(),
                'col'     => 4,
            ],
            // Civilité = enum mt-foundation (M / Mme / Mlle / non précisée), plus de texte libre.
            'title'  => [
                'type'    => 'select',
                'label'   => __('mtschool::students.civility'),
                'options' => CivilitePersonnel::options(),
                'col'     => 4,
            ],
            'active' => ['type' => 'toggle', 'label' => __('mtschool::common.active'), 'col' => 4],
            'email'  => ['type' => 'email', 'label' => __('mtschool::students.email'), 'col' => 6],
            'phone'  => ['type' => 'text', 'label' => __('mtschool::students.phone'), 'col' => 6],
            'occupation' => ['type' => 'text', 'label' => __('mtschool::students.occupation'), 'col' => 6],
            'address'    => ['type' => 'textarea', 'label' => __('mtschool::students.address'), 'col' => 6],
        ];
    }

    public function rules(): array
    {
        return [
            'last_name'  => 'required|array',   // traduisible → array (jamais |string)
            'first_name' => 'required|array',
            'gender'     => ['nullable', Rule::in(array_keys(SexePersonnel::options()))],
            'title'      => ['nullable', Rule::in(array_keys(CivilitePersonnel::options()))],
            'photo'      => 'nullable|image|max:5120',
            'email'      => 'nullable|email|max:255',
            'phone'      => 'nullable|string|max:30',
            'occupation' => 'nullable|array',
            'address'    => 'nullable|array',
            'active'     => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'last_name.required'  => __('mtschool::students.last_name_required'),
            'first_name.required' => __('mtschool::students.first_name_required'),
        ];
    }

    /**
     * Interdépendances entre champs (fieldActions, exécutées par BaseForm au
     * changement d'un champ .live). Cohérence Genre ⇄ Civilité :
     *   - Masculin → Monsieur ; Féminin → Madame ;
     *   - Monsieur → Masculin ; Madame/Mademoiselle → Féminin.
     * Pas de boucle : une écriture serveur ($form->title = …) ne re-déclenche
     * pas updatedForm (seul un changement CLIENT le fait).
     */
    public function fieldActions(): array
    {
        return [
            'gender' => [
                ['type' => 'map', 'target' => 'title', 'map' => [
                    SexePersonnel::MASCULIN->value    => CivilitePersonnel::MONSIEUR->value,
                    SexePersonnel::FEMININ->value     => CivilitePersonnel::MADAME->value,
                    // Sexe inconnu ⇒ civilité inconnue (on ne peut pas la déduire).
                    SexePersonnel::NON_PRECISE->value => CivilitePersonnel::NON_PRECISEE->value,
                ]],
            ],
            'title' => [
                ['type' => 'map', 'target' => 'gender', 'map' => [
                    CivilitePersonnel::MONSIEUR->value     => SexePersonnel::MASCULIN->value,
                    CivilitePersonnel::MADAME->value       => SexePersonnel::FEMININ->value,
                    CivilitePersonnel::MADEMOISELLE->value => SexePersonnel::FEMININ->value,
                    CivilitePersonnel::NON_PRECISEE->value => SexePersonnel::NON_PRECISE->value,
                ]],
            ],
        ];
    }

    public static function modelClass(): string
    {
        return Guardian::class;
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();
            unset($data['photo']); // upload → média, jamais une colonne
            // Ne pas forcer null sur d'éventuelles colonnes à défaut DB.
            $data = array_filter($data, fn ($v) => ! is_null($v));

            if ($model) {
                $model->update($data);
            } else {
                $data['reference'] = null; // clé présente ⇒ HasReference génère GRD-...
                $model = Guardian::create($data);
            }

            // Nouvelle photo : elle remplace la vedette (l'ancienne reste en galerie).
            if ($this->photo instanceof \Illuminate\Http\UploadedFile) {
                $model->images()->where('is_featured', true)->update(['is_featured' => false]);
                app(MediaService::class)->attach($model, $this->photo, ['type' => 'photo', 'is_featured' => true]);
            }

            return $model;
        });
    }
}
