<?php

namespace Mt\MtSchoolCore\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Mt\MtSchoolCore\Enums\CycleType;
use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtViews\Livewire\Forms\GenericForm;

class CycleForm extends GenericForm
{
    public $code        = null;
    public $label       = null;
    public $type        = CycleType::PRIMARY->value;
    public $order       = 1;
    public $color       = null;
    public $icon        = null;
    public $description = null;
    public $active      = true;

    public function schema(): array
    {
        return [
            'code' => [
                'type'        => 'text',
                'label'       => __('mtschool::structure.cycle_code_ph'),
                'placeholder' => 'PRIM',
                'col'         => 6,
            ],
            'type' => [
                'type'    => 'select',
                'label'   => __('mtschool::structure.cycle_type'),
                'options' => CycleType::options(),
                'col'     => 6,
            ],
            'label' => [
                'type'         => 'text',
                'label'        => __('mtschool::structure.label_field'),
                'multilingual' => true,
                'col'          => 12,
            ],
            'color' => [
                'type'  => 'text',
                'label' => __('mtschool::structure.color_hex'),
                'col'   => 4,
            ],
            'icon' => [
                'type'  => 'text',
                'label' => __('mtschool::common.icon'),
                'col'   => 4,
            ],
            'order' => [
                'type'  => 'number',
                'label' => __('mtschool::common.order'),
                'col'   => 4,
            ],
            'description' => [
                'type'  => 'textarea',
                'label' => __('mtschool::common.description'),
                'col'   => 12,
            ],
            'active' => [
                'type'  => 'checkbox',
                'label' => __('mtschool::structure.cycle_active'),
                'col'   => 12,
            ],
        ];
    }

    public function rules(): array
    {
        $modelId = $this->getModelId();
        $isEdit  = is_numeric($modelId);

        return [
            'code'        => [$isEdit ? 'nullable' : 'required', 'string', 'max:30', Rule::unique('cycles', 'code')->where('school_id', currentSchoolId())->ignore($modelId)], // unicité PAR école
            'label'       => 'nullable',
            'type'        => 'required|string|in:' . implode(',', array_column(CycleType::cases(), 'value')),
            'order'       => 'required|integer|min:1',
            'color'       => 'nullable|string|max:20',
            'icon'        => 'nullable|string|max:100',
            'description' => 'nullable|array', // traduisible → coerce en tableau par le base-form ; |string casse (cf. SchoolYearForm)
            'active'      => 'boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'code.required' => __('mtschool::structure.cycle_code_required'),
            'code.unique'   => __('mtschool::structure.cycle_code_unique'),
            'type.required' => __('mtschool::structure.cycle_type_required'),
        ];
    }

    public static function modelClass(): string
    {
        return Cycle::class;
    }

    protected function getModelId(): ?int
    {
        if (!isset($this->component)) {
            return null;
        }
        try {
            return $this->component->modelData()?->id ?? null;
        } catch (\Throwable) {
            return null;
        }
    }

    public function save(?Model $model = null): Model
    {
        return DB::transaction(function () use ($model) {
            $data = $this->validate();
            // Colonnes NOT NULL à défaut DB (ex. color) : ne pas forcer null (viole la contrainte).
            $data = array_filter($data, fn ($v) => !is_null($v));

            if ($model) {
                $model->update($data);
                return $model;
            }

            return Cycle::create($data);
        });
    }
}
