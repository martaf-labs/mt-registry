<?php

namespace Mt\MtSchoolCore\Livewire\Billing;

use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Module;
use Mt\MtSchoolCore\Models\Plan;
use Mt\MtSchoolCore\Services\SubscriptionPurchaseService;

#[Layout('mt::components.layouts.auth')]
class RenewComponent extends Component
{
    public bool $processing = false;

    /** Le plan à reconduire = celui du dernier abonnement de l'école (pas de changement de formule ici). */
    protected function currentPlan(): ?Plan
    {
        $school = currentSchool();

        return $school?->subscriptions()->with('plan')->latest('id')->first()?->plan;
    }

    public function renew()
    {
        $school = currentSchool();
        abort_unless($school, 403);

        $plan = $this->currentPlan();
        abort_unless($plan, 404);

        $this->processing = true;
        app(SubscriptionPurchaseService::class)->renew($school, $plan);

        session()->flash('status', __('mtschool::billing.renew_reactivated'));
        return redirect()->route(config('routes.dashboard', 'dashboard'));
    }

    public function render()
    {
        $plan = $this->currentPlan();

        return view('mtschool::livewire.billing.renew', [
            'plan'        => $plan,
            'moduleNames' => Module::active()->get()->mapWithKeys(fn ($m) => [$m->code => $m->name]),
            'school'      => currentSchool(),
        ])->title(__('mtschool::billing.renew_title'));
    }
}
