<?php

namespace Mt\MtSchoolCore\Livewire\Teacher;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Homework;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Portail enseignant — gestion de SES devoirs (Homework) : liste avec suivi des
 * rendus, création (sur l'un de ses cours = classe + matière), publication,
 * suppression. Données limitées à l'enseignant connecté.
 */
#[Layout('mt::components.layouts.app')]
class TeacherHomework extends Component
{
    // Modale de création
    public bool $showCreate = false;
    public $assignmentId = null;       // CourseAssignment choisi (classe + matière)
    public string $title = '';
    public string $instructions = '';
    public $deadline = null;
    public bool $isGraded = false;
    public $maxScore = 20;
    public $coefficient = 1;

    public string $successMessage = '';

    protected function teacher(): ?Teacher
    {
        $u = Auth::user()?->userable;

        return $u instanceof Teacher ? $u : null;
    }

    public function mount(): void
    {
        abort_unless($this->teacher(), 403);
    }

    /** Les cours de l'enseignant (classe + matière) où il peut poser un devoir. */
    #[Computed]
    public function assignments()
    {
        return CourseAssignment::where('teacher_id', $this->teacher()->id)
            ->where('active', true)
            ->with(['classroom', 'subject'])
            ->get();
    }

    #[Computed]
    public function homeworks()
    {
        return Homework::where('teacher_id', $this->teacher()->id)
            ->with(['classroom', 'subject'])
            ->withCount('submissions')
            ->orderByDesc('assigned_date')
            ->orderByDesc('id')
            ->get();
    }

    public function openCreate(): void
    {
        $this->reset(['title', 'instructions', 'deadline', 'isGraded', 'maxScore', 'coefficient']);
        $this->maxScore = 20;
        $this->coefficient = 1;
        $this->assignmentId = $this->assignments->first()?->id;
        $this->deadline = now()->addWeek()->format('Y-m-d\TH:i');
        $this->showCreate = true;
        $this->dispatch('open-create-homework');
    }

    public function createHomework(): void
    {
        $this->validate([
            'assignmentId' => 'required|integer',
            'title'        => 'required|string|max:180',
            'instructions' => 'nullable|string|max:5000',
            'deadline'     => 'required|date',
            'maxScore'     => 'required|numeric|min:1|max:100',
            'coefficient'  => 'required|numeric|min:0|max:50',
        ], [], ['assignmentId' => 'cours', 'title' => 'intitulé', 'deadline' => 'échéance']);

        $ca = $this->assignments->firstWhere('id', (int) $this->assignmentId);
        abort_unless($ca, 403);

        $locale = config('mt-school-core.multilingual.default', 'fr');

        Homework::create([
            'class_id'            => $ca->class_id,
            'subject_id'          => $ca->subject_id,
            'teacher_id'          => $this->teacher()->id,
            'period_id'           => Period::query()->terms()->active()->value('id'),
            'title'               => [$locale => $this->title],
            'instructions'        => $this->instructions ? [$locale => $this->instructions] : null,
            'assigned_date'       => now()->toDateString(),
            'submission_deadline' => $this->deadline,
            'is_graded'           => $this->isGraded,
            'max_score'           => $this->isGraded ? $this->maxScore : 20,
            'coefficient'         => $this->isGraded ? $this->coefficient : 1,
            'status'              => 'published',
        ]);

        $this->showCreate = false;
        unset($this->homeworks);
        $this->dispatch('close-modal', name: 'create-homework');
        $this->successMessage = 'Devoir publié.';
    }

    public function togglePublish(int $id): void
    {
        $hw = Homework::where('teacher_id', $this->teacher()->id)->findOrFail($id);
        $hw->update(['status' => $hw->status === 'published' ? 'draft' : 'published']);
        unset($this->homeworks);
    }

    public function delete(int $id): void
    {
        Homework::where('teacher_id', $this->teacher()->id)->findOrFail($id)->delete();
        unset($this->homeworks);
        $this->successMessage = 'Devoir supprimé.';
    }

    public function render()
    {
        return view('mtschool::livewire.teacher.homework')
            ->title(__('mtschool::pedagogy.my_homework'));
    }
}
