<?php

namespace Mt\MtSchoolCore\Livewire\Teacher;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Homework;
use Mt\MtSchoolCore\Models\HomeworkSubmission;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Portail enseignant — suivi & correction des rendus d'un devoir. Liste tous les
 * élèves de la classe (rendus + manquants), saisie inline d'une note + d'une
 * appréciation par rendu (style « Manager »). Accès réservé au propriétaire du devoir.
 */
#[Layout('mt::components.layouts.app')]
class TeacherHomeworkSubmissions extends Component
{
    public int $homeworkId;

    /** Saisie inline par enrollment : ['scores' => [enrollmentId => x], 'corrections' => [...]] */
    public array $scores = [];
    public array $corrections = [];

    public string $successMessage = '';

    protected function teacher(): ?Teacher
    {
        $u = Auth::user()?->userable;

        return $u instanceof Teacher ? $u : null;
    }

    public function mount(int $homework): void
    {
        $this->homeworkId = $homework;
        $hw = $this->homework();

        $t = $this->teacher();
        abort_unless($t && (int) $hw->teacher_id === (int) $t->id, 403);

        foreach ($hw->submissions as $s) {
            $this->scores[$s->enrollment_id]      = $s->score;
            $this->corrections[$s->enrollment_id] = is_array($s->correction)
                ? ($s->correction[config('mt-school-core.multilingual.default', 'fr')] ?? '')
                : $s->correction;
        }
    }

    public function homework(): Homework
    {
        return Homework::with(['classroom', 'subject', 'submissions'])->findOrFail($this->homeworkId);
    }

    /** Tous les élèves de la classe + leur rendu éventuel. */
    #[Computed]
    public function rows()
    {
        $hw       = $this->homework();
        $subs     = $hw->submissions->keyBy('enrollment_id');

        return Enrollment::where('class_id', $hw->class_id)
            ->validated()
            ->with('student')
            ->get()
            ->map(function ($e) use ($subs) {
                $s = $subs->get($e->id);
                return (object) [
                    'enrollment_id' => $e->id,
                    'name'          => $e->student?->full_name ?? $e->student?->last_name ?? '—',
                    'submission'    => $s,
                    'submitted_at'  => $s?->submitted_at,
                    'is_late'       => (bool) ($s?->is_late),
                    'comment'       => $s?->comment,
                    'file'          => $s?->file,
                    'status'        => $s?->status,
                ];
            })
            ->sortBy('name')
            ->values();
    }

    public function saveRow(int $enrollmentId): void
    {
        $hw = $this->homework();

        $sub = HomeworkSubmission::firstOrNew([
            'homework_id'   => $hw->id,
            'enrollment_id' => $enrollmentId,
        ]);

        $score = $this->scores[$enrollmentId] ?? null;
        if ($score !== null && $score !== '') {
            $score = max(0, min((float) $score, (float) ($hw->max_score ?? 20)));
        } else {
            $score = null;
        }

        $locale = config('mt-school-core.multilingual.default', 'fr');
        $corr   = trim((string) ($this->corrections[$enrollmentId] ?? ''));

        $sub->fill([
            'score'        => $score,
            'correction'   => $corr !== '' ? [$locale => $corr] : null,
            'corrected_at' => now(),
            'status'       => 'corrected',
        ]);
        // NE PAS fabriquer submitted_at : noter un élève qui n'a rien rendu ne doit
        // pas le faire passer pour « rendu à l'heure ». submitted_at ne reflète QUE
        // les vrais dépôts (StudentHomework::submit) ; un rendu réel garde sa date.
        $sub->save();

        unset($this->rows);
        $this->successMessage = 'Correction enregistrée.';
    }

    public function download(int $enrollmentId)
    {
        $hw  = $this->homework();
        $sub = $hw->submissions->firstWhere('enrollment_id', $enrollmentId);
        abort_unless($sub && $sub->file && Storage::disk('public')->exists($sub->file), 404);

        return Storage::disk('public')->download($sub->file);
    }

    public function render()
    {
        return view('mtschool::livewire.teacher.homework-submissions', ['homework' => $this->homework()])
            ->title(__('mtschool::pedagogy.submissions_title'));
    }
}
