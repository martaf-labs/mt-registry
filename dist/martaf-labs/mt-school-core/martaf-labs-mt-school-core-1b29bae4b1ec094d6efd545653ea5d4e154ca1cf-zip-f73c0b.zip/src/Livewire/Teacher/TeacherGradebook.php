<?php

namespace Mt\MtSchoolCore\Livewire\Teacher;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Enums\AssessmentStatus;
use Mt\MtSchoolCore\Models\Assessment;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Carnet de notes d'un cours de l'enseignant (CourseAssignment) : ses évaluations
 * pour cette classe + matière, création d'évaluation, accès à la saisie des notes.
 */
#[Layout('mt::components.layouts.app')]
class TeacherGradebook extends Component
{
    public int $assignmentId;

    // Modale de création d'évaluation
    public bool $showCreate = false;
    public string $label = '';
    public $periodId = null;
    public string $type = 'test';
    public $maxScore = 20;
    public $coefficient = 1;
    public $date = null;

    public string $successMessage = '';

    public function mount(int $assignment): void
    {
        $this->assignmentId = $assignment;
        $ca = $this->assignment();

        // L'enseignant ne peut ouvrir que SES cours.
        $teacher = Auth::user()?->userable;
        abort_unless($teacher instanceof Teacher && (int) $ca->teacher_id === (int) $teacher->id, 403);

        $this->periodId = Period::orderBy('id')->value('id');
        $this->date = now()->format('Y-m-d');
    }

    /** Charge le CourseAssignment (pas en propriété publique → évite la collision Livewire). */
    public function assignment(): CourseAssignment
    {
        return CourseAssignment::with(['classroom', 'subject'])->findOrFail($this->assignmentId);
    }

    #[Computed]
    public function periods(): array
    {
        return Period::orderBy('id')->get()->mapWithKeys(fn ($p) => [$p->id => $p->label])->toArray();
    }

    #[Computed]
    public function rosterCount(): int
    {
        return Enrollment::where('class_id', $this->assignment()->class_id)->validated()->count();
    }

    #[Computed]
    public function assessments()
    {
        return Assessment::where('class_id', $this->assignment()->class_id)
            ->where('subject_id', $this->assignment()->subject_id)
            ->where('teacher_id', $this->assignment()->teacher_id)
            ->with('period')
            ->orderByDesc('id')
            ->get()
            ->map(function ($a) {
                $entered = $a->grades()->whereNotNull('final_score')->count();
                $absent  = $a->grades()->where('is_absent', true)->count();
                return (object) [
                    'id'        => $a->id,
                    'label'     => $a->label,
                    'period'    => $a->period?->label,
                    'max_score' => $a->max_score,
                    'done'      => $entered + $absent,
                    'published' => $a->published,
                ];
            });
    }

    public function openCreate(): void
    {
        $this->label = '';
        $this->type = 'test';
        $this->maxScore = 20;
        $this->coefficient = 1;
        $this->date = now()->format('Y-m-d');
        $this->showCreate = true;
        $this->dispatch('open-create-assessment');
    }

    public function createAssessment(): void
    {
        $this->validate([
            'label'       => 'required|string|max:150',
            'periodId'    => 'required|integer|exists:periods,id',
            'maxScore'    => 'required|numeric|min:1|max:100',
            'coefficient' => 'required|numeric|min:0|max:50',
            'date'        => 'nullable|date',
        ], [], ['label' => __('mtschool::portal.attr_label'), 'periodId' => __('mtschool::portal.attr_period')]);

        $locale = config('mt-school-core.multilingual.default', 'fr');

        Assessment::create([
            'class_id'        => $this->assignment()->class_id,
            'subject_id'      => $this->assignment()->subject_id,
            'teacher_id'      => $this->assignment()->teacher_id,
            'period_id'       => $this->periodId,
            'label'           => [$locale => $this->label],
            'type'            => $this->type,
            'max_score'       => $this->maxScore,
            'coefficient'     => $this->coefficient,
            'assessment_date' => $this->date ?: null,
            'code'            => 'EV-' . strtoupper(substr(uniqid(), -6)),
            'status'          => AssessmentStatus::SCHEDULED->value,
            'published'       => false,
        ]);

        $this->showCreate = false;
        unset($this->assessments);
        $this->dispatch('close-modal', name: 'create-assessment');
        $this->successMessage = __('mtschool::portal.assessment_created');
    }

    public function render()
    {
        return view('mtschool::livewire.teacher.gradebook', ['assignment' => $this->assignment()])
            ->title(__('mtschool::portal.gradebook_title'));
    }
}
