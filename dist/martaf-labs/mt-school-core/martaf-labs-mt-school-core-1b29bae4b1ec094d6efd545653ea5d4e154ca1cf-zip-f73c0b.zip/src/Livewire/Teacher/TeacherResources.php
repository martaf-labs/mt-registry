<?php

namespace Mt\MtSchoolCore\Livewire\Teacher;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\TeachingResource;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Portail enseignant — ressources pédagogiques partagées (document ou lien).
 * L'enseignant publie pour l'une de ses classes/matières ; les élèves (et parents)
 * y accèdent en lecture. Données limitées à l'enseignant connecté.
 */
#[Layout('mt::components.layouts.app')]
class TeacherResources extends Component
{
    use WithFileUploads;

    public bool $showCreate = false;
    public $assignmentId = null;
    public string $title = '';
    public string $description = '';
    public string $kind = 'link';        // link | document
    public string $externalUrl = '';
    public $upload = null;

    public string $successMessage = '';

    protected function teacher(): ?Teacher
    {
        $u = Auth::user()?->userable;

        return $u instanceof Teacher ? $u : null;
    }

    public function mount(): void
    {
        abort_unless($this->teacher(), 403);
    }

    #[Computed]
    public function assignments()
    {
        return CourseAssignment::where('teacher_id', $this->teacher()->id)
            ->where('active', true)
            ->with(['classroom', 'subject'])
            ->get();
    }

    #[Computed]
    public function resources()
    {
        return TeachingResource::where('teacher_id', $this->teacher()->id)
            ->with(['classroom', 'subject'])
            ->orderByDesc('id')
            ->get();
    }

    public function openCreate(): void
    {
        $this->reset(['title', 'description', 'externalUrl', 'upload']);
        $this->kind = 'link';
        $this->assignmentId = $this->assignments->first()?->id;
        $this->showCreate = true;
        $this->dispatch('open-create-resource');
    }

    public function createResource(): void
    {
        $this->validate([
            'assignmentId' => 'required|integer',
            'title'        => 'required|string|max:180',
            'description'  => 'nullable|string|max:2000',
            'kind'         => 'required|in:link,document',
            'externalUrl'  => 'required_if:kind,link|nullable|url|max:500',
            'upload'       => 'required_if:kind,document|nullable|file|max:10240',
        ], [], ['assignmentId' => 'cours', 'title' => 'intitulé', 'externalUrl' => 'lien', 'upload' => 'fichier']);

        $ca = $this->assignments->firstWhere('id', (int) $this->assignmentId);
        abort_unless($ca, 403);

        $locale = config('mt-school-core.multilingual.default', 'fr');

        $data = [
            'subject_id'     => $ca->subject_id,
            'class_id'       => $ca->class_id,
            'grade_level_id' => $ca->classroom?->grade_level_id,
            'teacher_id'     => $this->teacher()->id,
            'title'          => [$locale => $this->title],
            'description'    => $this->description ? [$locale => $this->description] : null,
            'type'           => $this->kind,
            'audience'       => 'students',
            'published'      => true,
        ];

        if ($this->kind === 'link') {
            $data['external_url'] = $this->externalUrl;
        } else {
            $path = $this->upload->store('teaching-resources', 'public');
            $data['file']      = $path;
            $data['mime_type'] = $this->upload->getMimeType();
            $data['file_size'] = $this->upload->getSize();
        }

        TeachingResource::create($data);

        $this->showCreate = false;
        unset($this->resources);
        $this->dispatch('close-modal', name: 'create-resource');
        $this->successMessage = 'Ressource partagée.';
    }

    public function togglePublish(int $id): void
    {
        $r = TeachingResource::where('teacher_id', $this->teacher()->id)->findOrFail($id);
        $r->update(['published' => ! $r->published]);
        unset($this->resources);
    }

    public function delete(int $id): void
    {
        $r = TeachingResource::where('teacher_id', $this->teacher()->id)->findOrFail($id);
        if ($r->file && Storage::disk('public')->exists($r->file)) {
            Storage::disk('public')->delete($r->file);
        }
        $r->delete();
        unset($this->resources);
        $this->successMessage = 'Ressource supprimée.';
    }

    public function render()
    {
        return view('mtschool::livewire.teacher.resources')
            ->title(__('mtschool::pedagogy.my_resources'));
    }
}
