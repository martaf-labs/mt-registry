<?php

namespace Mt\MtSchoolCore\Livewire\Teacher;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Accueil du portail enseignant : ses cours (CourseAssignment = classe + matière),
 * avec accès à la saisie des notes. Données limitées à l'enseignant connecté.
 */
#[Layout('mt::components.layouts.app')]
class TeacherHome extends Component
{
    #[Computed]
    public function assignments()
    {
        $u = Auth::user()?->userable;
        if (! $u instanceof Teacher) {
            return collect();
        }

        return CourseAssignment::where('teacher_id', $u->id)->where('active', true)
            ->with(['classroom', 'subject'])
            ->get()
            ->sortBy(fn ($a) => ($a->classroom?->code ?? '') . ($a->subject?->code ?? ''));
    }

    public function render()
    {
        return view('mtschool::livewire.teacher.home')
            ->title(__('mtschool::portal.my_courses'));
    }
}
