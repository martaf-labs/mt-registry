<?php

namespace Mt\MtSchoolCore\Livewire\ParentPortal;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtSchoolCore\Models\AbsenceJustification;
use Mt\MtSchoolCore\Models\Guardian;

/**
 * Portail parent — dépôt de JUSTIFICATIFS D'ABSENCE (flux d'écriture).
 *
 * Le tuteur choisit un de SES enfants, la période d'absence, le motif, un détail et un
 * document facultatif → crée une AbsenceJustification `pending` que l'admin traitera
 * (approuve → marque les absences justifiées / refuse → motif). Liste de ses dépôts + statut.
 *
 * Cloisonnement : l'enfant choisi DOIT appartenir au tuteur connecté (vérif à la soumission).
 */
#[Layout('mt::components.layouts.app')]
class Justify extends Component
{
    use WithFileUploads;

    /** Motifs proposés (la valeur stockée est la clé ; libellé via lang portal.reason_*). */
    public const REASONS = ['illness', 'medical', 'family', 'travel', 'other'];

    public ?int $studentId = null;
    public string $start_date = '';
    public string $end_date = '';
    public string $reason = 'illness';
    public string $reason_details = '';
    public $document = null;

    public string $savedMessage = '';

    protected function guardian(): ?Guardian
    {
        $g = Auth::user()?->userable;
        return $g instanceof Guardian ? $g : null;
    }

    /** Enfants du tuteur inscrits cette année (pour le sélecteur). */
    #[Computed]
    public function children()
    {
        $guardian = $this->guardian();
        if (! $guardian) {
            return collect();
        }

        return $guardian->students()->get()
            ->filter(fn ($s) => $s->enrollmentFor() !== null)
            ->map(fn ($s) => (object) [
                'id'    => $s->id,
                'name'  => $s->full_name_reverse ?? $s->full_name,
            ])->values();
    }

    /** Justificatifs déjà déposés par le tuteur (pour ses enfants). */
    #[Computed]
    public function justifications()
    {
        $guardian = $this->guardian();
        if (! $guardian) {
            return collect();
        }

        // Ids d'inscription de TOUS les enfants du tuteur (toutes années) → ownership.
        $enrollmentIds = $guardian->students()->get()
            ->flatMap(fn ($s) => $s->enrollments()->pluck('id'))->all();

        if (empty($enrollmentIds)) {
            return collect();
        }

        return AbsenceJustification::whereIn('enrollment_id', $enrollmentIds)
            ->with('enrollment.student')
            ->orderByDesc('created_at')->limit(20)->get()
            ->map(fn ($j) => (object) [
                'student'   => $j->enrollment?->student?->full_name_reverse ?? $j->enrollment?->student?->full_name ?? '—',
                'start'     => $j->start_date,
                'end'       => $j->end_date,
                'reason'    => $j->reason,
                'status'    => $j->status,
                'rejection' => $j->rejection_reason, // traduisible → aplati
                'has_doc'   => (bool) $j->document,
            ]);
    }

    public function submit()
    {
        $data = $this->validate([
            'studentId'      => 'required|integer',
            'start_date'     => 'required|date',
            'end_date'       => 'required|date|after_or_equal:start_date',
            'reason'         => 'required|in:' . implode(',', self::REASONS),
            'reason_details' => 'nullable|string|max:1000',
            'document'       => 'nullable|file|max:5120|mimes:pdf,jpg,jpeg,png',
        ]);

        $guardian = $this->guardian();
        abort_unless($guardian, 403);

        // Ownership : l'enfant choisi doit être un enfant du tuteur.
        $student = $guardian->students()->where('students.id', $this->studentId)->first();
        abort_unless($student, 403);

        $enrollment = $student->enrollmentFor();
        if (! $enrollment) {
            $this->addError('studentId', __('mtschool::portal.not_enrolled_year'));
            return;
        }

        $path = $this->document ? $this->document->store('justifications', 'public') : null;
        $loc  = config('mt-school-core.multilingual.default', 'fr');

        AbsenceJustification::create([
            'enrollment_id'  => $enrollment->id,
            'start_date'     => $this->start_date,
            'end_date'       => $this->end_date,
            'reason'         => $this->reason,
            'reason_details' => filled($this->reason_details) ? [$loc => $this->reason_details] : null,
            'document'       => $path,
            'status'         => 'pending',
            'submitter_type' => 'guardian',
            'submitter_id'   => $guardian->id,
        ]);

        $this->reset(['studentId', 'start_date', 'end_date', 'reason_details', 'document']);
        $this->reason = 'illness';
        unset($this->justifications);
        $this->savedMessage = __('mtschool::portal.justify_submitted');
    }

    public function render()
    {
        return view('mtschool::livewire.parent.justify', ['reasons' => self::REASONS])
            ->title(__('mtschool::portal.justify_title'));
    }
}
