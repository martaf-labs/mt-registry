<?php

namespace Mt\MtSchoolCore\Livewire\ParentPortal;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Attendance;
use Mt\MtSchoolCore\Models\DisciplinarySanction;
use Mt\MtSchoolCore\Models\Guardian;

/**
 * Portail parent — SUIVI de ses enfants (lecture seule) : assiduité (présences /
 * absences / retards, absences non justifiées) + dernières absences/retards +
 * sanctions disciplinaires actives.
 *
 * Cloisonnement : uniquement les enfants rattachés au tuteur connecté (morph userable
 * → Guardian → students()). Données lues par enrollment de l'année active.
 */
#[Layout('mt::components.layouts.app')]
class FollowUp extends Component
{
    #[Computed]
    public function children()
    {
        $guardian = Auth::user()?->userable;
        if (! $guardian instanceof Guardian) {
            return collect();
        }

        return $guardian->students()->get()->map(function ($student) {
            $enrollment = $student->enrollmentFor(); // inscription de l'année active

            if (! $enrollment) {
                return (object) [
                    'student'      => $student,
                    'enrollment_id'=> null,
                    'class'        => null,
                    'present'      => 0, 'absent' => 0, 'late' => 0, 'unjustified' => 0,
                    'events'       => collect(),
                    'sanctions'    => collect(),
                ];
            }

            $eid = $enrollment->id;

            $events = Attendance::where('enrollment_id', $eid)
                ->whereIn('status', ['absent', 'late'])
                ->orderByDesc('date')->limit(12)->get()
                ->map(fn ($a) => (object) [
                    'date'        => $a->date,
                    'status'      => $a->status instanceof \BackedEnum ? $a->status->value : (string) $a->status,
                    'justified'   => (bool) $a->is_justified,
                    'lateness'    => (int) ($a->lateness_minutes ?? 0),
                ]);

            $sanctions = DisciplinarySanction::where('enrollment_id', $eid)
                ->orderByDesc('sanction_date')->limit(8)->get()
                ->map(fn ($s) => (object) [
                    'type'      => $s->type instanceof \BackedEnum ? $s->type->value : (string) $s->type,
                    'label'     => $s->label,        // traduisible → aplati à la locale
                    'reason'    => $s->reason,       // traduisible → aplati
                    'date'      => $s->sanction_date,
                    'active'    => $s->status === 'active',
                ]);

            return (object) [
                'student'       => $student,
                'enrollment_id' => $eid,
                'class'         => $enrollment->classroom?->label,
                'present'       => Attendance::where('enrollment_id', $eid)->where('status', 'present')->count(),
                'absent'        => Attendance::where('enrollment_id', $eid)->where('status', 'absent')->count(),
                'late'          => Attendance::where('enrollment_id', $eid)->where('status', 'late')->count(),
                'unjustified'   => Attendance::where('enrollment_id', $eid)
                    ->where('status', 'absent')->where('is_justified', false)->count(),
                'events'        => $events,
                'sanctions'     => $sanctions,
            ];
        });
    }

    public function render()
    {
        return view('mtschool::livewire.parent.follow-up')
            ->title(__('mtschool::portal.followup_title'));
    }
}
