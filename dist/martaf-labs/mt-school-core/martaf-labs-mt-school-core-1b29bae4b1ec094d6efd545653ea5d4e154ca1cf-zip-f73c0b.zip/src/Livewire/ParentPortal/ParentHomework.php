<?php

namespace Mt\MtSchoolCore\Livewire\ParentPortal;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\Homework;
use Mt\MtSchoolCore\Models\HomeworkSubmission;

/**
 * Portail parent — suivi des devoirs de ses enfants (lecture seule). Pour chaque
 * enfant : les devoirs publiés de sa classe, avec l'état du rendu et la note
 * éventuelle. Données cloisonnées aux enfants rattachés au tuteur connecté.
 */
#[Layout('mt::components.layouts.app')]
class ParentHomework extends Component
{
    #[Computed]
    public function children()
    {
        $guardian = Auth::user()?->userable;
        if (! $guardian instanceof Guardian) {
            return collect();
        }

        return $guardian->students()->get()->map(function ($student) {
            $enrollment = $student->enrollmentFor();
            if (! $enrollment) {
                return (object) ['student' => $student, 'class' => null, 'homeworks' => collect()];
            }

            $subs = HomeworkSubmission::where('enrollment_id', $enrollment->id)
                ->get()->keyBy('homework_id');

            $homeworks = Homework::where('class_id', $enrollment->class_id)
                ->published()
                ->with('subject')
                ->orderByDesc('submission_deadline')
                ->limit(15)
                ->get()
                ->map(function ($hw) use ($subs) {
                    $s = $subs->get($hw->id);
                    return (object) [
                        'title'     => $hw->title,
                        'subject'   => $hw->subject?->label,
                        'deadline'  => $hw->submission_deadline,
                        'expired'   => $hw->submission_deadline?->isPast(),
                        'submitted' => $s?->submitted_at !== null, // vrai dépôt, pas juste une note saisie
                        'is_late'   => (bool) ($s?->is_late),
                        'score'     => $s?->score,
                        'is_graded' => $hw->is_graded,
                        'max_score' => $hw->max_score,
                    ];
                });

            return (object) [
                'student'   => $student,
                'class'     => $enrollment->classroom?->label,
                'homeworks' => $homeworks,
            ];
        });
    }

    public function render()
    {
        return view('mtschool::livewire.parent.homework')
            ->title(__('mtschool::pedagogy.parent_title'));
    }
}
