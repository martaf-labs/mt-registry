<?php

namespace Mt\MtSchoolCore\Livewire\ParentPortal;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\ReportCard;

/**
 * Portail parent — BULLETINS de ses enfants (lecture seule).
 *
 * Par enfant (année active) : la liste des bulletins de période PUBLIÉS (téléchargeables
 * en PDF), et le bulletin ANNUEL avec sa synthèse (moyenne/rang/décision) dès que le
 * résultat annuel est calculé.
 *
 * Cloisonnement : uniquement les enfants du tuteur connecté. Les routes PDF re-vérifient
 * l'appartenance (`$guardChild`) côté hôte → double garde.
 */
#[Layout('mt::components.layouts.app')]
class ReportCards extends Component
{
    #[Computed]
    public function children()
    {
        $guardian = Auth::user()?->userable;
        if (! $guardian instanceof Guardian) {
            return collect();
        }

        return $guardian->students()->get()->map(function ($student) {
            $enrollment = $student->enrollmentFor(); // inscription de l'année active

            if (! $enrollment) {
                return (object) [
                    'student'       => $student,
                    'enrollment_id' => null,
                    'year_id'       => null,
                    'class'         => null,
                    'periods'       => collect(),
                    'annual'        => null,
                ];
            }

            // Seuls les bulletins PUBLIÉS sont visibles côté parent.
            $periods = ReportCard::where('enrollment_id', $enrollment->id)
                ->published()->with('period')->get()
                ->sortBy(fn ($rc) => $rc->period?->order)
                ->map(fn ($rc) => (object) [
                    'period_id'    => $rc->period_id,
                    'period'       => $rc->period?->label,
                    'published_at' => $rc->published_at,
                ])->values();

            // Bulletin annuel : proposé dès que le résultat annuel est calculé.
            $annual = $enrollment->annual_average !== null
                ? (object) [
                    'average' => (float) $enrollment->annual_average,
                    'rank'    => $enrollment->annual_rank,
                    'result'  => $enrollment->result?->label(),
                ]
                : null;

            return (object) [
                'student'       => $student,
                'enrollment_id' => $enrollment->id,
                'year_id'       => $enrollment->school_year_id,
                'class'         => $enrollment->classroom?->label,
                'periods'       => $periods,
                'annual'        => $annual,
            ];
        });
    }

    public function render()
    {
        return view('mtschool::livewire.parent.report-cards')
            ->title(__('mtschool::portal.report_cards_title'));
    }
}
