<?php

namespace Mt\MtSchoolCore\Livewire\ParentPortal;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\SchoolFee;

/**
 * Accueil du portail parent : la liste de ses enfants avec, pour chacun, la classe,
 * la dernière moyenne/rang et le reste à payer. Lecture seule, données cloisonnées
 * (uniquement les enfants rattachés au tuteur connecté).
 */
#[Layout('mt::components.layouts.app')]
class ParentHome extends Component
{
    #[Computed]
    public function children()
    {
        // Lien parent → profil via le morph `userable` (et non un FK user_id).
        $guardian = Auth::user()?->userable;
        if (! $guardian instanceof Guardian) {
            return collect();
        }

        return $guardian->students()->with('guardians')->get()->map(function ($student) {
            $enrollment = $student->enrollmentFor();           // inscription de l'année active
            $classroom  = $enrollment?->classroom;

            $latestAvg = $enrollment
                ? PeriodAverage::where('enrollment_id', $enrollment->id)
                    ->with('period')->orderByDesc('period_id')->first()
                : null;

            $remaining = $enrollment
                ? (float) SchoolFee::where('enrollment_id', $enrollment->id)->sum('remaining_amount')
                : 0;

            return (object) [
                'student'       => $student,
                'enrollment_id' => $enrollment?->id,
                'class'         => $classroom?->label,
                'average'       => $latestAvg?->overall_average,
                'rank'          => $latestAvg?->rank,
                'class_size'    => $latestAvg?->class_size,
                'period_id'     => $latestAvg?->period_id,
                'period_label'  => $latestAvg?->period?->label,
                'remaining'     => $remaining,
            ];
        });
    }

    public function render()
    {
        return view('mtschool::livewire.parent.home')
            ->title(__('mtschool::portal.my_children'));
    }
}
