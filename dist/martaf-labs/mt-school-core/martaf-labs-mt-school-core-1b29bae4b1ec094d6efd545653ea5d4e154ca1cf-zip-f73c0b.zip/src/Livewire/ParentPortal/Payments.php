<?php

namespace Mt\MtSchoolCore\Livewire\ParentPortal;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\Payment;
use Mt\MtSchoolCore\Models\SchoolFee;

/**
 * Portail parent — SITUATION FINANCIÈRE de ses enfants (lecture seule).
 *
 * Pour chaque enfant (année active) : le détail des frais par type, le total facturé /
 * payé / restant + statut, l'échéancier (versements + dates d'échéance, retards mis en
 * évidence), l'historique des paiements, et le lien vers le relevé PDF.
 *
 * Cloisonnement : uniquement les enfants rattachés au tuteur connecté (via le morph
 * `userable` → Guardian → students()). Frais/paiements sont school- ET year-scopés.
 */
#[Layout('mt::components.layouts.app')]
class Payments extends Component
{
    #[Computed]
    public function children()
    {
        // Lien parent → profil via le morph `userable` (anti-fuite : seuls ses enfants).
        $guardian = Auth::user()?->userable;
        if (! $guardian instanceof Guardian) {
            return collect();
        }

        return $guardian->students()->get()->map(function ($student) {
            $enrollment = $student->enrollmentFor(); // inscription de l'année active

            if (! $enrollment) {
                return (object) [
                    'student'         => $student,
                    'enrollment_id'   => null,
                    'class'           => null,
                    'fees'            => collect(),
                    'installments'    => collect(),
                    'payments'        => collect(),
                    'total_net'       => 0.0,
                    'total_paid'      => 0.0,
                    'total_remaining' => 0.0,
                    'currency'        => '',
                    'status'          => 'none',
                ];
            }

            $fees = SchoolFee::where('enrollment_id', $enrollment->id)
                ->with(['feeType', 'installments'])->get();

            $feeRows = $fees->map(fn ($f) => (object) [
                'type'      => $f->feeType?->label, // traduisible → aplati à la locale
                'net'       => (float) $f->net_amount,
                'paid'      => (float) $f->amount_paid,
                'remaining' => (float) $f->remaining_amount,
                'status'    => $this->feeStatus($f),
            ]);

            $installments = $fees->flatMap(fn ($f) => $f->installments->map(fn ($i) => (object) [
                'label'    => $i->label,
                'amount'   => (float) $i->amount,
                'due_date' => $i->due_date,
                'status'   => $this->installmentStatus($i),
            ]))->sortBy(fn ($i) => $i->due_date)->values();

            $payments = Payment::whereIn('school_fee_id', $fees->pluck('id'))
                ->orderByDesc('payment_date')->limit(20)->get()
                ->map(fn ($p) => (object) [
                    'date'      => $p->payment_date,
                    'amount'    => (float) $p->amount,
                    'method'    => $this->methodLabel($p->payment_method),
                    'reference' => $p->reference,
                ]);

            $totalPaid      = (float) $fees->sum('amount_paid');
            $totalRemaining = (float) $fees->sum('remaining_amount');

            return (object) [
                'student'         => $student,
                'enrollment_id'   => $enrollment->id,
                'class'           => $enrollment->classroom?->label,
                'fees'            => $feeRows,
                'installments'    => $installments,
                'payments'        => $payments,
                'total_net'       => (float) $fees->sum('net_amount'),
                'total_paid'      => $totalPaid,
                'total_remaining' => $totalRemaining,
                'currency'        => (string) ($fees->first()?->currency ?? ''),
                'status'          => $totalRemaining <= 0 && $fees->isNotEmpty()
                    ? 'paid'
                    : ($totalPaid > 0 ? 'partial' : 'pending'),
            ];
        });
    }

    /** Statut d'un frais : exonéré / soldé / partiel / impayé. */
    protected function feeStatus(SchoolFee $fee): string
    {
        if ($fee->is_exempt) {
            return 'exempt';
        }
        $net  = (float) $fee->net_amount;
        $paid = (float) $fee->amount_paid;
        if ($net <= 0 || $paid >= $net) {
            return 'paid';
        }
        return $paid > 0 ? 'partial' : 'pending';
    }

    /** Statut d'une échéance : payée / en retard / à venir. */
    protected function installmentStatus($installment): string
    {
        if ($installment->status === 'paid') {
            return 'paid';
        }
        if ($installment->due_date && $installment->due_date->isPast()) {
            return 'overdue';
        }
        return 'pending';
    }

    /** Libellé du mode de paiement (enum-safe). */
    protected function methodLabel($method): string
    {
        if ($method instanceof \BackedEnum) {
            return method_exists($method, 'label') ? $method->label() : (string) $method->value;
        }
        return (string) $method;
    }

    public function render()
    {
        return view('mtschool::livewire.parent.payments')
            ->title(__('mtschool::portal.fees_title'));
    }
}
