<?php

namespace Mt\MtSchoolCore\Livewire\Concerns;

use Mt\MtSchoolCore\Services\PrerequisiteService;

/**
 * Garde de PRÉREQUIS d'écran : à appeler en tête de render().
 *
 *     if ($gate = $this->prerequisiteGate('payments', __('…title'))) return $gate;
 *
 * Quand des prérequis manquent (cf. PrerequisiteService), l'écran affiche le
 * panneau « avant de continuer » (messages + CTA vers l'écran amont) au lieu
 * d'un formulaire inutilisable. La navigation n'est jamais bloquée.
 */
trait ChecksPrerequisites
{
    protected function prerequisiteGate(string $screen, string $title)
    {
        $missing = app(PrerequisiteService::class)->missingFor($screen);

        if (empty($missing)) {
            return null;
        }

        return view('mtschool::livewire.shared.prerequisites', [
            'missing'     => $missing,
            'screenTitle' => $title,
        ])->title($title);
    }
}
