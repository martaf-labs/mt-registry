<?php

namespace Mt\MtSchoolCore\Livewire;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Mt\MtViews\Livewire\MtDashboard;
use Mt\MtSchoolCore\Enums\ReportCardStatus;
use Mt\MtSchoolCore\Models\AbsenceJustification;
use Mt\MtSchoolCore\Models\Announcement;
use Mt\MtSchoolCore\Models\Attendance;
use Mt\MtSchoolCore\Models\CalendarEvent;
use Mt\MtSchoolCore\Models\ClassCouncil;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\DisciplinarySanction;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Payment;
use Mt\MtSchoolCore\Models\PaymentInstallment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\ReportCard;
use Mt\MtSchoolCore\Models\SchoolFee;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtSchoolCore\Models\SubjectAverage;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Tableau de bord DIRECTEUR — un cockpit organisé en bandes :
 *   1. Files d'action (ce qu'il faut traiter aujourd'hui)
 *   2. Tendances (courbes temporelles : trésorerie, moyennes, absences)
 *   3. Structure & distribution (effectifs, capacité, mixité, dispersion des notes)
 *   4. Ciblage (classes à relancer, matières faibles, élèves absents)
 *   5. Vie de l'établissement (activité, agenda, conseils, discipline)
 *
 * Tous les widgets sont CONDITIONNELS : masqués tant qu'il n'y a pas de données
 * (un dashboard ne montre jamais de bloc mort). Tout est cloisonné par école
 * (SchoolScope) et, le cas échéant, par année active (BelongsToSchoolYear).
 * Construit 100 % côté hôte via les points d'extension de MtDashboard.
 */
class Dashboard extends MtDashboard
{
    /** Mémo pour éviter de rejouer les requêtes entre getStats() et getWidgets(). */
    protected ?Period $term = null;
    protected bool $termResolved = false;

    public function getTitle(): string
    {
        return __('mtschool::dashboard.title');
    }

    /** Titre de l'onglet navigateur (le layout ajoute le suffixe = sigle de l'école). */
    public function render()
    {
        return parent::render()->title($this->getTitle());
    }

    public function getSubtitle(): string
    {
        $year = activeSchoolYear();

        return $year
            ? __('mtschool::dashboard.subtitle_year', ['year' => $year->code])
            : __('mtschool::dashboard.subtitle_default');
    }

    public function getQuickActions(): array
    {
        return [
            [
                'label'   => __('mtschool::dashboard.new_student'),
                'icon'    => 'user-plus',
                'route'   => mt_get_route('students_index'),
                'variant' => 'primary',
            ],
            [
                'label'   => __('mtschool::dashboard.enrollments'),
                'icon'    => 'clipboard-document-check',
                'route'   => mt_get_route('students_enrollments'),
                'variant' => 'secondary',
            ],
        ];
    }

    public function getStats(): array
    {
        $enrolled = Enrollment::count();
        $teachers = Teacher::count();
        $classes  = Classroom::count();

        // — Recouvrement (finances) —
        $billed    = (float) SchoolFee::sum('net_amount');
        $collected = (float) SchoolFee::sum('amount_paid');
        $rate      = $billed > 0 ? round($collected / $billed * 100) : null;
        $remaining = max(0, $billed - $collected);

        // — Moyenne établissement (période active) —
        $term    = $this->resolveTerm();
        $avgQ    = PeriodAverage::query();
        if ($term) {
            $avgQ->where('period_id', $term->id);
        }
        $schoolAvg = $avgQ->avg('overall_average');

        // — Présence (assiduité) —
        $totalAtt   = Attendance::count();
        $absent     = Attendance::query()->absent()->count();
        $unjust     = Attendance::query()->unjustified()->count();
        $presence   = $totalAtt > 0 ? round(($totalAtt - $absent) / $totalAtt * 100) : null;

        return [
            [
                'label' => __('mtschool::dashboard.enrolled'),
                'value' => $enrolled,
                'icon'  => 'academic-cap',
                'color' => 'primary',
                'route' => mt_get_route('students_enrollments'),
            ],
            [
                'label'   => __('mtschool::dashboard.collection_rate'),
                'value'   => $rate !== null ? $rate . '%' : '—',
                'icon'    => 'banknotes',
                'color'   => $rate === null ? 'gray' : ($rate >= 80 ? 'success' : ($rate >= 50 ? 'warning' : 'danger')),
                'details' => $billed > 0 ? [
                    ['label' => __('mtschool::dashboard.collected'), 'value' => $this->money($collected)],
                    ['label' => __('mtschool::dashboard.remaining'), 'value' => $this->money($remaining)],
                ] : [],
            ],
            [
                'label'      => __('mtschool::dashboard.school_average'),
                'value'      => $schoolAvg !== null ? number_format((float) $schoolAvg, 2, ',', ' ') : '—',
                'icon'       => 'chart-bar',
                'color'      => $schoolAvg === null ? 'gray' : ((float) $schoolAvg >= 10 ? 'success' : 'warning'),
                'details'    => $term ? [['label' => __('mtschool::dashboard.period'), 'value' => (string) $term->label]] : [],
            ],
            [
                'label'   => __('mtschool::dashboard.attendance'),
                'value'   => $presence !== null ? $presence . '%' : '—',
                'icon'    => 'check-circle',
                'color'   => $presence === null ? 'gray' : ($presence >= 90 ? 'success' : 'warning'),
                'details' => $totalAtt > 0 ? [['label' => __('mtschool::dashboard.unjustified_abs'), 'value' => $unjust]] : [],
            ],
            [
                'label' => __('mtschool::dashboard.teachers'),
                'value' => $teachers,
                'icon'  => 'chalkboard',
                'color' => 'info',
            ],
            [
                'label' => __('mtschool::dashboard.classes'),
                'value' => $classes,
                'icon'  => 'building-library',
                'color' => 'gray',
            ],
        ];
    }

    public function getWidgets(): array
    {
        $widgets = [];
        $push = function (?array $w) use (&$widgets) {
            if ($w !== null) {
                $widgets[] = $w;
            }
        };

        // ── 0. Mise en route (interdépendance des modules) : guide tant que tout
        //       n'est pas en place, puis disparaît.
        $checklist = app(\Mt\MtSchoolCore\Services\PrerequisiteService::class)->checklist();
        if (collect($checklist)->contains(fn ($s) => ! $s['met'])) {
            $widgets[] = [
                'type'      => 'custom',
                'span'      => 2,
                'title'     => __('mtschool::prerequisites.checklist_title'),
                'view'      => 'mtschool::dashboard.setup-checklist',
                'view_data' => ['steps' => $checklist],
            ];
        }

        // ── BANDE 1 · Files d'action (à traiter aujourd'hui) ──────────────────
        $push($this->pendingEnrollmentsWidget());
        $push($this->pendingJustificationsWidget());
        $push($this->reportCardsWidget());
        $push($this->installmentsWidget());

        // ── BANDE 2 · Tendances (la dimension temporelle qui manquait) ────────
        $push($this->collectionTrendWidget());
        $push($this->averageTrendWidget());
        $push($this->absenceTrendWidget());

        // ── BANDE 3 · Structure & distribution ────────────────────────────────
        $push($this->enrollmentByLevelWidget());
        $push($this->classFillRateWidget());
        $push($this->gradeDistributionWidget());
        $push($this->genderSplitWidget());
        $push($this->collectionByLevelWidget());

        // ── BANDE 4 · Ciblage (qui / quoi suivre) ─────────────────────────────
        $push($this->classRankingWidget());
        $push($this->topClassesToChaseWidget());
        $push($this->weakestSubjectsWidget());
        $push($this->topAbsenteesWidget());

        // ── BANDE 5 · Vie de l'établissement ──────────────────────────────────
        $push($this->activityFeedWidget());
        $push($this->upcomingEventsWidget());
        $push($this->classCouncilsWidget());
        $push($this->recentSanctionsWidget());

        // ── Encadré : formule active ──────────────────────────────────────────
        $push($this->planWidget());

        return $widgets;
    }

    // ═══════════════════════ BANDE 1 · Files d'action ═══════════════════════

    /** Inscriptions en attente de validation — file d'action n°1. */
    protected function pendingEnrollmentsWidget(): ?array
    {
        $count = Enrollment::query()->pending()->count();
        if ($count === 0) {
            return null;
        }

        $rows = Enrollment::query()->pending()
            ->with(['student', 'classroom'])
            ->orderByDesc('enrollment_date')
            ->limit(8)
            ->get();

        return [
            'type'     => 'list',
            'span'     => 1,
            'title'    => __('mtschool::dashboard.pending_enrollments_title'),
            'subtitle' => __('mtschool::dashboard.pending_count', ['n' => $count]),
            'actions'  => ['label' => __('mtschool::dashboard.process_enrollment'), 'route' => mt_get_route('students_enrollments')],
            'data'     => $rows->map(fn ($e) => [
                'initials' => $this->studentInitials($e->student),
                'title'    => $this->studentName($e->student),
                'meta'     => trim(((string) ($e->classroom?->label ?? '')) . ' · ' . ($e->enrollment_date?->format('d/m') ?? ''), ' ·'),
                'badge'    => ['label' => __('mtschool::dashboard.badge_pending'), 'variant' => 'warning'],
            ])->all(),
        ];
    }

    /** Justificatifs d'absence en attente — chaque ligne = un parent qui attend. */
    protected function pendingJustificationsWidget(): ?array
    {
        $count = AbsenceJustification::query()->where('status', 'pending')->count();
        if ($count === 0) {
            return null;
        }

        $rows = AbsenceJustification::query()->where('status', 'pending')
            ->with(['enrollment.student', 'enrollment.classroom'])
            ->orderByDesc('created_at')
            ->limit(6)
            ->get();

        return [
            'type'     => 'list',
            'span'     => 1,
            'title'    => __('mtschool::dashboard.pending_justifications'),
            'subtitle' => __('mtschool::dashboard.justifications_count', ['n' => $count]),
            'actions'  => ['label' => __('mtschool::common.view'), 'route' => mt_get_route('attendance_justifications')],
            'data'     => $rows->map(fn ($j) => [
                'initials' => $this->studentInitials($j->enrollment?->student),
                'title'    => $this->studentName($j->enrollment?->student),
                'meta'     => trim(($j->start_date?->format('d/m') ?? '') . ' → ' . ($j->end_date?->format('d/m') ?? '') . ' · ' . (string) $j->reason, ' ·'),
                'badge'    => $j->document ? ['label' => __('mtschool::dashboard.justif_attachment'), 'variant' => 'info'] : null,
            ])->all(),
        ];
    }

    /** Bulletins de la période : publiés / à publier / à valider. */
    protected function reportCardsWidget(): ?array
    {
        $term = $this->resolveTerm();
        if (! $term) {
            return null;
        }

        $forPeriod = fn () => ReportCard::query()->where('period_id', $term->id);
        $total     = $forPeriod()->count();
        if ($total === 0) {
            return null;
        }

        $published  = $forPeriod()->where('status', ReportCardStatus::PUBLISHED->value)->count();
        $toPublish  = $forPeriod()->where('status', ReportCardStatus::VALIDATED->value)->count();
        $toValidate = $forPeriod()->where('status', ReportCardStatus::GENERATED->value)->count();

        return [
            'type'  => 'stat_group',
            'span'  => 1,
            'title' => __('mtschool::dashboard.reportcards_title'),
            'data'  => [
                [
                    'label' => __('mtschool::dashboard.reportcards_published'),
                    'value' => $published,
                    'icon'  => 'check-circle',
                    'badge' => ['label' => (string) $term->label, 'variant' => 'gray'],
                ],
                [
                    'label' => __('mtschool::dashboard.reportcards_to_publish'),
                    'value' => $toPublish,
                    'icon'  => 'document-text',
                    'badge' => $toPublish > 0 ? ['label' => __('mtschool::common.action'), 'variant' => 'warning'] : null,
                ],
                [
                    'label' => __('mtschool::dashboard.reportcards_to_validate'),
                    'value' => $toValidate,
                    'icon'  => 'clipboard-document-check',
                    'badge' => $toValidate > 0 ? ['label' => __('mtschool::common.action'), 'variant' => 'info'] : null,
                ],
            ],
        ];
    }

    /** Échéances de frais : en retard / à venir sous 30 jours (risque trésorerie). */
    protected function installmentsWidget(): ?array
    {
        $overdueCount  = PaymentInstallment::query()->overdue()->count();
        $overdueAmount = (float) PaymentInstallment::query()->overdue()->sum('remaining_amount');

        $soonQ      = PaymentInstallment::query()->where('status', 'pending')
            ->whereBetween('due_date', [now(), now()->copy()->addDays(30)]);
        $soonCount  = (clone $soonQ)->count();
        $soonAmount = (float) $soonQ->sum('remaining_amount');

        if ($overdueCount === 0 && $soonCount === 0) {
            return null;
        }

        return [
            'type'  => 'stat_group',
            'span'  => 1,
            'title' => __('mtschool::dashboard.installments_title'),
            'data'  => [
                [
                    'label' => __('mtschool::dashboard.overdue_amount'),
                    'value' => $this->money($overdueAmount),
                    'icon'  => 'exclamation-triangle',
                    'badge' => $overdueCount > 0
                        ? ['label' => __('mtschool::dashboard.installments_count', ['n' => $overdueCount]), 'variant' => 'danger']
                        : null,
                ],
                [
                    'label' => __('mtschool::dashboard.due_soon_30d'),
                    'value' => $this->money($soonAmount),
                    'icon'  => 'clock',
                    'badge' => $soonCount > 0
                        ? ['label' => __('mtschool::dashboard.installments_count', ['n' => $soonCount]), 'variant' => 'warning']
                        : null,
                ],
            ],
        ];
    }

    // ═══════════════════════ BANDE 2 · Tendances ═══════════════════════

    /** Courbe des encaissements confirmés, 12 mois glissants (trésorerie). */
    protected function collectionTrendWidget(): ?array
    {
        $since    = now()->copy()->startOfMonth()->subMonths(11);
        $payments = Payment::query()->confirmed()
            ->where('payment_date', '>=', $since)
            ->get(['amount', 'payment_date']);

        if ($payments->isEmpty()) {
            return null;
        }

        $byMonth = $payments->groupBy(fn ($p) => $p->payment_date->format('Y-m'))
            ->map(fn ($g) => (float) $g->sum('amount'));

        [$labels, $data] = $this->monthBuckets($since, 12, $byMonth);

        return [
            'type'       => 'chart',
            'span'       => 2,
            'title'      => __('mtschool::dashboard.collection_trend'),
            'chart_type' => 'line',
            'height'     => '260px',
            'legend'     => false,
            'data'       => [
                'labels'   => $labels,
                'datasets' => [[
                    'label'       => __('mtschool::dashboard.collected_dataset'),
                    'data'        => $data,
                    'tension'     => 0.35,
                    'fill'        => true,
                    'borderWidth' => 2,
                    'pointRadius' => 3,
                ]],
            ],
        ];
    }

    /** Évolution de la moyenne établissement, période par période. */
    protected function averageTrendWidget(): ?array
    {
        $rows = PeriodAverage::query()
            ->select('period_id', DB::raw('AVG(overall_average) as avg'))
            ->groupBy('period_id')
            ->get();

        if ($rows->count() < 2) {
            return null; // une courbe à un point n'est pas une tendance
        }

        $periods = Period::query()->whereIn('id', $rows->pluck('period_id'))
            ->orderBy('order')
            ->get();

        $avgByPeriod = $rows->keyBy('period_id');
        $labels = [];
        $data   = [];
        foreach ($periods as $p) {
            if (! isset($avgByPeriod[$p->id])) {
                continue;
            }
            $labels[] = (string) $p->label;
            $data[]   = round((float) $avgByPeriod[$p->id]->avg, 2);
        }

        if (count($data) < 2) {
            return null;
        }

        return [
            'type'       => 'chart',
            'span'       => 2,
            'title'      => __('mtschool::dashboard.average_trend_title'),
            'chart_type' => 'line',
            'height'     => '260px',
            'legend'     => false,
            'data'       => [
                'labels'   => $labels,
                'datasets' => [[
                    'label'       => __('mtschool::dashboard.average_trend_dataset'),
                    'data'        => $data,
                    'tension'     => 0.35,
                    'fill'        => true,
                    'borderWidth' => 2,
                    'pointRadius' => 4,
                ]],
            ],
        ];
    }

    /** Absences et retards jour par jour, 14 derniers jours. */
    protected function absenceTrendWidget(): ?array
    {
        $from = today()->copy()->subDays(13);

        $absents = Attendance::query()->absent()->forDateRange($from, today())
            ->selectRaw('DATE(date) as d, COUNT(*) as c')->groupBy('d')->pluck('c', 'd');
        $lates   = Attendance::query()->late()->forDateRange($from, today())
            ->selectRaw('DATE(date) as d, COUNT(*) as c')->groupBy('d')->pluck('c', 'd');

        if ($absents->sum() === 0 && $lates->sum() === 0) {
            return null;
        }

        $labels   = [];
        $absData  = [];
        $lateData = [];
        $cursor   = $from->copy();
        for ($i = 0; $i < 14; $i++) {
            $key        = $cursor->format('Y-m-d');
            $labels[]   = $cursor->format('d/m');
            $absData[]  = (int) ($absents[$key] ?? 0);
            $lateData[] = (int) ($lates[$key] ?? 0);
            $cursor->addDay();
        }

        return [
            'type'       => 'chart',
            'span'       => 2,
            'title'      => __('mtschool::dashboard.absence_trend'),
            'chart_type' => 'line',
            'height'     => '260px',
            'legend'     => true,
            'data'       => [
                'labels'   => $labels,
                'datasets' => [
                    [
                        'label'           => __('mtschool::dashboard.absences_dataset'),
                        'data'            => $absData,
                        'borderColor'     => '#ef4444',
                        'backgroundColor' => 'rgba(239,68,68,0.12)',
                        'tension'         => 0.35,
                        'fill'            => true,
                        'borderWidth'     => 2,
                        'pointRadius'     => 2,
                    ],
                    [
                        'label'           => __('mtschool::dashboard.late_dataset'),
                        'data'            => $lateData,
                        'borderColor'     => '#f59e0b',
                        'backgroundColor' => 'rgba(245,158,11,0.12)',
                        'tension'         => 0.35,
                        'fill'            => true,
                        'borderWidth'     => 2,
                        'pointRadius'     => 2,
                    ],
                ],
            ],
        ];
    }

    // ═══════════════════ BANDE 3 · Structure & distribution ═══════════════════

    /** Effectifs par niveau (bar). */
    protected function enrollmentByLevelWidget(): ?array
    {
        $byLevel = $this->enrollmentsByLevel();
        if ($byLevel->isEmpty()) {
            return null;
        }

        return [
            'type'       => 'chart',
            'span'       => 2,
            'title'      => __('mtschool::dashboard.enrollment_by_level'),
            'chart_type' => 'bar',
            'height'     => '260px',
            'legend'     => false,
            'data'       => [
                'labels'   => $byLevel->pluck('label')->all(),
                'datasets' => [[
                    'label'        => __('mtschool::dashboard.students_dataset'),
                    'data'         => $byLevel->pluck('count')->all(),
                    'borderRadius' => 6,
                ]],
            ],
        ];
    }

    /** Remplissage des classes vs capacité (progress, surchargées en tête). */
    protected function classFillRateWidget(): ?array
    {
        $rows = Classroom::query()->active()
            ->withCount(['enrollments as filled' => fn ($q) => $q->validated()])
            ->get(['id', 'label', 'code', 'max_capacity'])
            ->filter(fn ($c) => (int) $c->max_capacity > 0);

        if ($rows->isEmpty()) {
            return null;
        }

        $data = $rows->map(function ($c) {
            $cap     = (int) $c->max_capacity;
            $filled  = (int) $c->filled;
            $percent = $cap > 0 ? (int) round($filled / $cap * 100) : 0;
            $color   = $percent > 100 ? 'danger' : ($percent >= 90 ? 'warning' : ($filled > 0 ? 'success' : 'gray'));

            return [
                'label'   => (string) $c->label,
                'percent' => min(100, $percent),
                '_sort'   => $percent,
                'color'   => $color,
                'value'   => $filled . '/' . $cap,
                'meta'    => $percent > 100 ? __('mtschool::dashboard.overcrowded', ['n' => $percent]) : ($percent . '%'),
            ];
        })
        ->sortByDesc('_sort')
        ->values()
        ->map(fn ($r) => collect($r)->except('_sort')->all())
        ->all();

        return [
            'type'  => 'progress',
            'span'  => 2,
            'title' => __('mtschool::dashboard.class_fill_rate_title'),
            'data'  => $data,
        ];
    }

    /** Répartition des moyennes en tranches (doughnut) — dispersion des résultats. */
    protected function gradeDistributionWidget(): ?array
    {
        $term = $this->resolveTerm();
        if (! $term) {
            return null;
        }

        $avgs = PeriodAverage::query()->where('period_id', $term->id)->pluck('overall_average')
            ->filter(fn ($v) => $v !== null);

        if ($avgs->isEmpty()) {
            return null;
        }

        $bands = [0, 0, 0, 0, 0]; // <10, 10-12, 12-14, 14-16, 16+
        foreach ($avgs as $v) {
            $v = (float) $v;
            $bands[$v < 10 ? 0 : ($v < 12 ? 1 : ($v < 14 ? 2 : ($v < 16 ? 3 : 4)))]++;
        }

        return [
            'type'       => 'chart',
            'span'       => 1,
            'title'      => __('mtschool::dashboard.grade_distribution_title'),
            'chart_type' => 'doughnut',
            'height'     => '240px',
            'legend'     => true,
            'data'       => [
                'labels'   => [
                    __('mtschool::dashboard.grade_band_below10'),
                    __('mtschool::dashboard.grade_band_10_12'),
                    __('mtschool::dashboard.grade_band_12_14'),
                    __('mtschool::dashboard.grade_band_14_16'),
                    __('mtschool::dashboard.grade_band_16_plus'),
                ],
                'datasets' => [[
                    'data'            => $bands,
                    'backgroundColor' => ['#ef4444', '#f97316', '#f59e0b', '#22c55e', '#3b82f6'],
                    'borderWidth'     => 0,
                ]],
            ],
        ];
    }

    /** Répartition filles / garçons de la cohorte inscrite (doughnut). */
    protected function genderSplitWidget(): ?array
    {
        $rows = Enrollment::query()->validated()
            ->join('students', 'enrollments.student_id', '=', 'students.id')
            ->selectRaw('students.gender as g, COUNT(DISTINCT students.id) as c')
            ->groupBy('students.gender')
            ->pluck('c', 'g');

        $f = (int) ($rows['F'] ?? 0);
        $m = (int) ($rows['M'] ?? 0);
        if ($f + $m === 0) {
            return null;
        }

        $girlsPct = (int) round($f / ($f + $m) * 100);

        return [
            'type'       => 'chart',
            'span'       => 1,
            'title'      => __('mtschool::dashboard.gender_split_title'),
            'subtitle'   => __('mtschool::dashboard.parity_index', ['n' => $girlsPct]),
            'chart_type' => 'doughnut',
            'height'     => '240px',
            'legend'     => true,
            'data'       => [
                'labels'   => [__('mtschool::dashboard.girls'), __('mtschool::dashboard.boys')],
                'datasets' => [[
                    'data'            => [$f, $m],
                    'backgroundColor' => ['#ec4899', '#3b82f6'],
                    'borderWidth'     => 0,
                ]],
            ],
        ];
    }

    /** Recouvrement par niveau (progress). */
    protected function collectionByLevelWidget(): ?array
    {
        $feeByLevel = $this->collectionByLevel();
        if ($feeByLevel->isEmpty()) {
            return null;
        }

        return [
            'type'  => 'progress',
            'span'  => 2,
            'title' => __('mtschool::dashboard.collection_by_level'),
            'data'  => $feeByLevel->map(fn ($r) => [
                'label'   => $r['label'],
                'percent' => $r['percent'],
                'color'   => $r['percent'] >= 80 ? 'success' : ($r['percent'] >= 50 ? 'warning' : 'danger'),
                'value'   => $r['percent'] . '%',
                'meta'    => $this->money($r['collected']) . ' / ' . $this->money($r['billed']),
            ])->all(),
        ];
    }

    // ═══════════════════════ BANDE 4 · Ciblage ═══════════════════════

    /** Palmarès des classes (list). */
    protected function classRankingWidget(): ?array
    {
        $ranking = $this->classRanking();
        if ($ranking->isEmpty()) {
            return null;
        }

        return [
            'type'  => 'list',
            'span'  => 1,
            'title' => __('mtschool::dashboard.class_ranking'),
            'data'  => $ranking->values()->map(fn ($r, $i) => [
                'initials' => (string) ($i + 1),
                'title'    => $r['label'],
                'meta'     => __('mtschool::dashboard.students_count', ['n' => $r['count']]),
                'badge'    => number_format($r['avg'], 2, ',', ' '),
            ])->all(),
        ];
    }

    /** Top 5 des classes concentrant le plus d'impayés échus (relance ciblée). */
    protected function topClassesToChaseWidget(): ?array
    {
        $ct   = (new Classroom)->getTable();
        // Colonnes qualifiées : le scope overdue() utilise 'status'/'due_date' NON qualifiés,
        // ambigus après le join avec school_fees (qui a aussi une colonne 'status').
        $rows = PaymentInstallment::query()
            ->where('payment_installments.status', 'pending')
            ->where('payment_installments.due_date', '<', now())
            ->join('school_fees', 'payment_installments.school_fee_id', '=', 'school_fees.id')
            ->join('enrollments', 'school_fees.enrollment_id', '=', 'enrollments.id')
            ->join($ct, 'enrollments.class_id', '=', "$ct.id")
            ->select('enrollments.class_id', DB::raw('SUM(payment_installments.remaining_amount) as due'), DB::raw('COUNT(*) as n'))
            ->groupBy('enrollments.class_id')
            ->orderByDesc('due')
            ->limit(5)
            ->get();

        if ($rows->isEmpty()) {
            return null;
        }

        $classMap = Classroom::query()->whereIn('id', $rows->pluck('class_id'))->get()->keyBy('id');

        return [
            'type'  => 'list',
            'span'  => 1,
            'title' => __('mtschool::dashboard.classes_to_chase'),
            'data'  => $rows->map(fn ($r) => [
                'icon'  => 'banknotes',
                'title' => (string) ($classMap[$r->class_id]->label ?? '—'),
                'meta'  => __('mtschool::dashboard.overdue_installments_count', ['n' => (int) $r->n]),
                'badge' => ['label' => $this->money((float) $r->due), 'variant' => 'danger'],
            ])->all(),
        ];
    }

    /** Matières les plus faibles de la période (moyenne < 12). */
    protected function weakestSubjectsWidget(): ?array
    {
        $term = $this->resolveTerm();
        if (! $term) {
            return null;
        }

        $rows = SubjectAverage::query()->where('period_id', $term->id)
            ->select('subject_id', DB::raw('AVG(average) as avg'))
            ->groupBy('subject_id')
            ->orderBy('avg')
            ->limit(8)
            ->get()
            ->filter(fn ($r) => (float) $r->avg < 12)
            ->take(5);

        if ($rows->isEmpty()) {
            return null;
        }

        $subjectMap = Subject::query()->whereIn('id', $rows->pluck('subject_id'))->get()->keyBy('id');

        return [
            'type'  => 'list',
            'span'  => 1,
            'title' => __('mtschool::dashboard.weakest_subjects_title'),
            'data'  => $rows->values()->map(fn ($r) => [
                'icon'  => 'academic-cap',
                'title' => (string) ($subjectMap[$r->subject_id]->label ?? '—'),
                'badge' => ['label' => number_format((float) $r->avg, 2, ',', ' '), 'variant' => (float) $r->avg < 10 ? 'danger' : 'warning'],
            ])->all(),
        ];
    }

    /** Élèves les plus absents (cas individuels à suivre). */
    protected function topAbsenteesWidget(): ?array
    {
        $rows = Attendance::query()->absent()
            ->selectRaw('enrollment_id, COUNT(*) as c')
            ->groupBy('enrollment_id')
            ->orderByDesc('c')
            ->limit(5)
            ->get();

        if ($rows->isEmpty()) {
            return null;
        }

        $enr = Enrollment::query()->with(['student', 'classroom'])
            ->whereIn('id', $rows->pluck('enrollment_id'))->get()->keyBy('id');

        return [
            'type'  => 'list',
            'span'  => 1,
            'title' => __('mtschool::dashboard.top_absentees'),
            'data'  => $rows->map(function ($r) use ($enr) {
                $e = $enr[$r->enrollment_id] ?? null;
                return [
                    'initials' => $this->studentInitials($e?->student),
                    'title'    => $this->studentName($e?->student),
                    'meta'     => (string) ($e?->classroom?->label ?? ''),
                    'badge'    => ['label' => __('mtschool::dashboard.absences_short', ['n' => (int) $r->c]), 'variant' => 'danger'],
                ];
            })->all(),
        ];
    }

    // ═══════════════════ BANDE 5 · Vie de l'établissement ═══════════════════

    /** Fil d'activité récente : dernières inscriptions + paiements + annonces. */
    protected function activityFeedWidget(): ?array
    {
        $items = collect();

        Enrollment::query()->with('student')->latest('created_at')->limit(6)->get()
            ->each(fn ($e) => $items->push([
                'ts'   => $e->created_at,
                'icon' => 'user-plus',
                'text' => __('mtschool::dashboard.activity_new_enrollment', ['name' => $this->studentName($e->student)]),
            ]));

        Payment::query()->confirmed()->whereNotNull('payment_date')->latest('payment_date')->limit(6)->get()
            ->each(fn ($p) => $items->push([
                'ts'   => $p->payment_date,
                'icon' => 'banknotes',
                'text' => __('mtschool::dashboard.activity_payment_received', ['amount' => $this->money((float) $p->amount)]),
            ]));

        Announcement::query()->published()->whereNotNull('published_at')->latest('published_at')->limit(6)->get()
            ->each(fn ($a) => $items->push([
                'ts'   => $a->published_at,
                'icon' => 'megaphone',
                'text' => __('mtschool::dashboard.activity_announcement', ['title' => (string) $a->title]),
            ]));

        $items = $items->filter(fn ($i) => $i['ts'] !== null)->sortByDesc('ts')->take(8)->values();
        if ($items->isEmpty()) {
            return null;
        }

        return [
            'type'  => 'activity',
            'span'  => 2,
            'title' => __('mtschool::dashboard.activity_feed'),
            'data'  => $items->map(fn ($i) => [
                'icon' => $i['icon'],
                'text' => e($i['text']),
                'time' => $i['ts']->diffForHumans(),
            ])->all(),
        ];
    }

    /** Prochains événements de l'agenda (list). */
    protected function upcomingEventsWidget(): ?array
    {
        $rows = CalendarEvent::query()->published()->upcoming()
            ->orderBy('starts_at')->limit(6)->get();

        if ($rows->isEmpty()) {
            return null;
        }

        return [
            'type'  => 'list',
            'span'  => 1,
            'title' => __('mtschool::dashboard.upcoming_events'),
            'data'  => $rows->map(fn ($e) => [
                'initials' => $e->starts_at?->format('d/m') ?? '—',
                'title'    => (string) $e->title,
                'meta'     => $e->all_day
                    ? __('mtschool::dashboard.event_all_day')
                    : ($e->starts_at?->format('H:i') ?? ''),
            ])->all(),
        ];
    }

    /** Conseils de classe : à venir + PV à valider (pilotage pédagogique). */
    protected function classCouncilsWidget(): ?array
    {
        $upcoming = ClassCouncil::query()->with(['classroom', 'period'])
            ->where('status', 'planned')->where('council_date', '>=', now())
            ->orderBy('council_date')->limit(4)->get();

        $toValidate = ClassCouncil::query()->with(['classroom', 'period'])
            ->whereIn('status', ['held', 'minutes_drafted'])
            ->orderByDesc('council_date')->limit(4)->get();

        if ($upcoming->isEmpty() && $toValidate->isEmpty()) {
            return null;
        }

        $items = collect();
        foreach ($upcoming as $c) {
            $items->push([
                'icon'  => 'calendar-days',
                'title' => trim(((string) ($c->classroom?->label ?? '')) . ' · ' . ((string) ($c->period?->label ?? '')), ' ·'),
                'meta'  => $c->council_date?->format('d/m H:i') ?? '',
                'badge' => ['label' => __('mtschool::dashboard.council_planned'), 'variant' => 'info'],
            ]);
        }
        foreach ($toValidate as $c) {
            $items->push([
                'icon'  => 'clipboard-document-check',
                'title' => trim(((string) ($c->classroom?->label ?? '')) . ' · ' . ((string) ($c->period?->label ?? '')), ' ·'),
                'meta'  => $c->council_date?->format('d/m') ?? '',
                'badge' => ['label' => __('mtschool::dashboard.council_to_validate'), 'variant' => 'warning'],
            ]);
        }

        return [
            'type'  => 'list',
            'span'  => 1,
            'title' => __('mtschool::dashboard.class_councils'),
            'data'  => $items->take(6)->all(),
        ];
    }

    /** Sanctions disciplinaires actives récentes (activity). */
    protected function recentSanctionsWidget(): ?array
    {
        $rows = DisciplinarySanction::query()->with(['enrollment.student'])
            ->active()->orderByDesc('sanction_date')->limit(6)->get();

        if ($rows->isEmpty()) {
            return null;
        }

        return [
            'type'  => 'activity',
            'span'  => 1,
            'title' => __('mtschool::dashboard.recent_sanctions'),
            'data'  => $rows->map(function ($s) {
                $notified = (bool) $s->parent_notified;
                return [
                    'icon'  => 'shield-exclamation',
                    'text'  => e($this->studentName($s->enrollment?->student) . ' — ' . ($s->type?->label() ?? '')),
                    'time'  => $s->sanction_date?->diffForHumans() ?? '',
                    'badge' => $notified ? null : ['label' => __('mtschool::dashboard.parent_not_notified'), 'variant' => 'danger'],
                ];
            })->all(),
        ];
    }

    // ─────────────────────────── helpers ───────────────────────────

    protected function resolveTerm(): ?Period
    {
        if (! $this->termResolved) {
            $this->term = Period::query()->terms()->active()->first()
                ?? Period::query()->terms()->orderByDesc('order')->first();
            $this->termResolved = true;
        }

        return $this->term;
    }

    /** Nom lisible d'un élève (reverse si dispo), robuste au null. */
    protected function studentName(?Student $s): string
    {
        if (! $s) {
            return '—';
        }

        return $s->full_name_reverse ?: ($s->full_name ?: '—');
    }

    /** Initiales d'un élève pour l'avatar de liste. */
    protected function studentInitials(?Student $s): string
    {
        if (! $s) {
            return '—';
        }

        $ini = mb_strtoupper(mb_substr((string) $s->first_name, 0, 1) . mb_substr((string) $s->last_name, 0, 1));

        return $ini !== '' ? $ini : '—';
    }

    /**
     * Construit N buckets mensuels consécutifs à partir de $start, en comblant
     * les mois vides à 0. Renvoie [labels[], data[]].
     */
    protected function monthBuckets(Carbon $start, int $count, $byMonthKeyed): array
    {
        $labels = [];
        $data   = [];
        $cursor = $start->copy();
        for ($i = 0; $i < $count; $i++) {
            $key      = $cursor->format('Y-m');
            $labels[] = ucfirst($cursor->translatedFormat('M y'));
            $data[]   = round((float) ($byMonthKeyed[$key] ?? 0));
            $cursor->addMonth();
        }

        return [$labels, $data];
    }

    /** @return \Illuminate\Support\Collection<int,array{label:string,count:int}> */
    protected function enrollmentsByLevel()
    {
        $ct = (new Classroom)->getTable();

        $counts = Enrollment::query()
            ->join($ct, 'enrollments.class_id', '=', "$ct.id")
            ->select("$ct.grade_level_id", DB::raw('COUNT(*) as c'))
            ->groupBy("$ct.grade_level_id")
            ->pluck('c', 'grade_level_id');

        return $this->labelLevels($counts->keys()->all())
            ->map(fn ($lvl) => [
                'label' => (string) $lvl->label,
                'count' => (int) ($counts[$lvl->id] ?? 0),
            ]);
    }

    /** @return \Illuminate\Support\Collection<int,array> */
    protected function collectionByLevel()
    {
        $ct = (new Classroom)->getTable();

        $rows = SchoolFee::query()
            ->join('enrollments', 'school_fees.enrollment_id', '=', 'enrollments.id')
            ->join($ct, 'enrollments.class_id', '=', "$ct.id")
            ->select(
                "$ct.grade_level_id",
                DB::raw('SUM(school_fees.net_amount) as billed'),
                DB::raw('SUM(school_fees.amount_paid) as collected')
            )
            ->groupBy("$ct.grade_level_id")
            ->get()
            ->keyBy('grade_level_id');

        return $this->labelLevels($rows->keys()->all())
            ->map(function ($lvl) use ($rows) {
                $r       = $rows[$lvl->id] ?? null;
                $billed  = (float) ($r->billed ?? 0);
                $coll    = (float) ($r->collected ?? 0);

                return [
                    'label'     => (string) $lvl->label,
                    'billed'    => $billed,
                    'collected' => $coll,
                    'percent'   => $billed > 0 ? (int) round($coll / $billed * 100) : 0,
                ];
            })
            ->filter(fn ($r) => $r['billed'] > 0)
            ->values();
    }

    /** @return \Illuminate\Support\Collection<int,array> */
    protected function classRanking()
    {
        $term = $this->resolveTerm();

        $q = PeriodAverage::query()
            ->join('enrollments', 'period_averages.enrollment_id', '=', 'enrollments.id')
            ->select(
                'enrollments.class_id',
                DB::raw('AVG(period_averages.overall_average) as avg'),
                DB::raw('COUNT(*) as c')
            )
            ->groupBy('enrollments.class_id')
            ->orderByDesc('avg');

        if ($term) {
            $q->where('period_averages.period_id', $term->id);
        }

        $rows     = $q->limit(5)->get();
        $classMap = Classroom::query()
            ->whereIn('id', $rows->pluck("class_id"))
            ->get()
            ->keyBy('id');

        return $rows->map(fn ($r) => [
            'label' => (string) ($classMap[$r->class_id]->label ?? '—'),
            'avg'   => (float) $r->avg,
            'count' => (int) $r->c,
        ]);
    }

    /** Charge les GradeLevel pour des ids donnés, triés par order naturel. */
    protected function labelLevels(array $ids)
    {
        return GradeLevel::query()
            ->whereIn('id', $ids)
            ->orderBy('id')
            ->get();
    }

    protected function planWidget(): ?array
    {
        $school = currentSchool();
        $sub    = $school?->activeSubscription();

        if (! $sub) {
            return null;
        }

        return [
            'type'      => 'custom',
            'span'      => 1,
            'title'     => __('mtschool::dashboard.your_plan'),
            'view'      => 'mtschool::dashboard.active-plan',
            'view_data' => [
                'planName'    => $sub->plan?->name,
                'status'      => $sub->status,
                'endsAt'      => $sub->ends_at,
                'maxStudents' => $sub->max_students,
                'moduleCount' => count($school->enabledModuleCodes()),
            ],
        ];
    }

    protected function money(float $v): string
    {
        return number_format($v, 0, ',', ' ');
    }
}
