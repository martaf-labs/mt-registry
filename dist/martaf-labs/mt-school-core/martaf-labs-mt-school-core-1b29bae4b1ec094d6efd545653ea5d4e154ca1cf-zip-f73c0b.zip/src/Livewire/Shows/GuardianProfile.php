<?php

namespace Mt\MtSchoolCore\Livewire\Shows;

use Mt\MtFoundation\Enums\CivilitePersonnel;
use Mt\MtSchoolCore\Enums\Relationship;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtViews\Livewire\Shows\GenericProfile;

/**
 * FICHE TUTEUR (base-profile) — fiche de PERSONNE : avatar rond, onglets, sections.
 * Onglets : Profil (identité + coordonnées) · Enfants (élèves rattachés) ·
 * Compte portail. Lecture seule : l'édition passe par le form tuteur.
 */
class GuardianProfile extends GenericProfile
{
    public static function modelClass(): string
    {
        return Guardian::class;
    }

    public function configuration(): array
    {
        return [
            'model'        => 'guardian',
            'model_plural' => 'guardians',
            'mainLabel'    => __('mtschool::students.guardians'),
            'title'        => __('mtschool::students.guardian_model_name'),
            'features'     => ['canAddImages' => false], // photo unique → éditée dans le formulaire
        ];
    }

    private function initials($g): string
    {
        return mb_strtoupper(mb_substr((string) $g->first_name, 0, 1) . mb_substr((string) $g->last_name, 0, 1));
    }

    public function header($g): array
    {
        $hasAccount = (bool) app(PortalAccountService::class)->accountFor($g);
        $civility   = $g->title ? CivilitePersonnel::tryFrom($g->title)?->label() : null;

        $badges = [
            $hasAccount
                ? ['label' => __('mtschool::students.portal_account_active'), 'type' => 'success']
                : ['label' => __('mtschool::students.portal_account_none'), 'type' => 'secondary'],
        ];
        $badges[] = $g->active
            ? ['label' => __('mtschool::common.active_m'), 'type' => 'success']
            : ['label' => __('mtschool::common.inactive_m'), 'type' => 'secondary'];

        return [
            'image'    => $g->getVariantImage('medium') ?: null,
            'letters'  => $this->initials($g),
            'title'    => $g->full_name,
            'subtitle' => implode(' · ', array_filter([$g->reference, $civility, $g->occupation])),
            'badges'   => $badges,
        ];
    }

    public function actions($g): array
    {
        $actions = [
            [
                'label'   => __('mtschool::common.edit'),
                'icon'    => 'pencil',
                'route'   => mt_get_route('guardians_edit', ['id' => $g->id]),
                'variant' => 'primary',
            ],
        ];

        // Créer un accès portail si e-mail présent et pas encore de compte.
        if ($g->email && ! app(PortalAccountService::class)->accountFor($g)) {
            $actions[] = [
                'label'  => __('mtschool::portal.create_account'),
                'icon'   => 'identification',
                'method' => 'provisionPortal',
            ];
        }

        return $actions;
    }

    public function tabs(): array
    {
        return [
            'profile'  => __('mtschool::students.tab_profile'),
            'children' => __('mtschool::students.tab_children'),
        ];
    }

    public function sections($g): array
    {
        $civility = $g->title ? CivilitePersonnel::tryFrom($g->title)?->label() : null;

        return [
            /* ---------- Profil ---------- */
            [
                'tab'   => 'profile',
                'type'  => 'attributes',
                'title' => __('mtschool::students.identity'),
                'items' => [
                    __('mtschool::students.last_name')  => $g->last_name,
                    __('mtschool::students.first_name') => $g->first_name,
                    __('mtschool::students.civility')   => $civility,
                    __('mtschool::students.occupation') => $g->occupation,
                    __('mtschool::students.workplace')  => $g->workplace,
                ],
            ],
            [
                'tab'   => 'profile',
                'type'  => 'attributes',
                'title' => __('mtschool::students.contact_info'),
                'items' => [
                    __('mtschool::students.email')      => $g->email,
                    __('mtschool::students.phone')      => $g->phone,
                    __('mtschool::students.work_phone') => $g->work_phone,
                    __('mtschool::students.address')    => $g->address,
                ],
            ],

            /* ---------- Enfants ---------- */
            [
                'tab'       => 'children',
                'type'      => 'table',
                'title'     => __('mtschool::students.children'),
                'columns'   => [
                    __('mtschool::students.col_student'),
                    __('mtschool::students.col_classroom'),
                    __('mtschool::students.relationship'),
                    __('mtschool::students.primary_contact'),
                ],
                'rows'      => $g->students()->with('currentEnrollment.classroom')->get()->map(fn ($s) => [
                    $s->full_name,
                    $s->currentEnrollment?->classroom?->code ?? '—',
                    $s->pivot->relationship ? Relationship::tryFrom($s->pivot->relationship)?->label() : null,
                    $s->pivot->is_primary_contact
                        ? ['badge' => __('mtschool::common.yes'), 'type' => 'success']
                        : ['badge' => __('mtschool::common.no'), 'type' => 'secondary'],
                ])->all(),
                'empty'     => __('mtschool::students.no_children'),
                'emptyIcon' => 'user-group',
            ],
        ];
    }
}
