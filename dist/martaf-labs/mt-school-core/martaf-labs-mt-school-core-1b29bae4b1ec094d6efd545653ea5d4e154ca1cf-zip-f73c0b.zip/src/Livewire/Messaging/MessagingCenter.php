<?php

namespace Mt\MtSchoolCore\Livewire\Messaging;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Conversation;
use Mt\MtSchoolCore\Models\ConversationParticipant;
use Mt\MtSchoolCore\Models\Message;
use Mt\MtSchoolCore\Models\User;

/**
 * Messagerie interne — générique pour TOUT utilisateur authentifié (admin, enseignant,
 * parent…). Affiche les conversations où l'utilisateur est participant, le fil de la
 * conversation active, l'envoi de messages et la création d'une nouvelle conversation.
 * Cloisonnée par école (Conversation school-scopée + garde de participation).
 */
#[Layout('mt::components.layouts.app')]
class MessagingCenter extends Component
{
    public ?int $activeId = null;
    public string $body = '';

    // Nouvelle conversation
    public bool $showNew = false;
    public $recipientId = null;
    public string $firstMessage = '';

    protected function uid(): int
    {
        return (int) Auth::id();
    }

    /** Conversations de l'utilisateur, avec libellé (autre participant / sujet) + non-lu. */
    #[Computed]
    public function conversations()
    {
        $uid = $this->uid();

        $convs = Conversation::whereHas('participants', fn ($q) => $q->where('user_id', $uid))
            ->with(['participants', 'latestMessage'])
            ->orderByDesc('last_message_at')
            ->orderByDesc('id')
            ->get();

        // Noms des interlocuteurs (batch).
        $otherIds = $convs->flatMap(fn ($c) => $c->participants->pluck('user_id'))
            ->reject(fn ($id) => (int) $id === $uid)->unique()->values();
        $users = User::whereIn('id', $otherIds)->get()->keyBy('id');

        return $convs->map(function ($c) use ($uid, $users) {
            $me      = $c->participants->firstWhere('user_id', $uid);
            $others  = $c->participants->where('user_id', '!=', $uid);
            $title   = $c->type === 'group' && $c->subject
                ? $c->subject
                : ($others->map(fn ($p) => $users[$p->user_id]->name ?? 'Utilisateur')->implode(', ') ?: 'Conversation');
            $last    = $c->latestMessage->first();
            $unread  = $last
                && (int) $last->sender_id !== $uid
                && (! $me?->last_seen_at || $last->created_at?->greaterThan($me->last_seen_at));

            return (object) [
                'id'       => $c->id,
                'title'    => $title,
                'preview'  => $last ? \Illuminate\Support\Str::limit((string) $last->content, 48) : '—',
                'time'     => $c->last_message_at,
                'unread'   => (bool) $unread,
            ];
        });
    }

    /** Conversation active : messages + expéditeurs, avec garde de participation. */
    #[Computed]
    public function active()
    {
        if (! $this->activeId) {
            return null;
        }

        $c = Conversation::with(['participants', 'messages'])->find($this->activeId);
        if (! $c || ! $c->participants->contains('user_id', $this->uid())) {
            return null;
        }

        $senderIds = $c->messages->pluck('sender_id')->unique();
        $users     = User::whereIn('id', $senderIds)->get()->keyBy('id');

        $c->setRelation('messages', $c->messages->map(function ($m) use ($users) {
            $m->sender_name = $users[$m->sender_id]->name ?? 'Utilisateur';
            return $m;
        }));

        return $c;
    }

    /**
     * Destinataires possibles : les autres utilisateurs actifs de LA MÊME ÉCOLE.
     * ⚠️ User n'a pas de SchoolScope global (récursion à l'auth) → le filtre
     * `school_id` est OBLIGATOIRE ici, sinon fuite cross-tenant.
     */
    #[Computed]
    public function recipients()
    {
        return User::where('school_id', Auth::user()?->school_id)
            ->where('id', '!=', $this->uid())
            ->where('is_active', true)
            ->orderBy('name')
            ->get(['id', 'name', 'school_role']);
    }

    public function open(int $id): void
    {
        $c = Conversation::with('participants')->find($id);
        if (! $c || ! $c->participants->contains('user_id', $this->uid())) {
            abort(403);
        }

        $this->activeId = $id;
        $this->body = '';

        ConversationParticipant::where('conversation_id', $id)
            ->where('user_id', $this->uid())
            ->update(['last_seen_at' => now()]);

        unset($this->conversations, $this->active);
    }

    public function send(): void
    {
        $this->validate(['body' => 'required|string|max:5000'], [], ['body' => 'message']);

        $c = Conversation::with('participants')->findOrFail($this->activeId);
        abort_unless($c->participants->contains('user_id', $this->uid()), 403);

        Message::create([
            'conversation_id' => $c->id,
            'sender_id'       => $this->uid(),
            'content'         => trim($this->body),
            'content_type'    => 'text',
            'status'          => 'sent',
        ]);

        $c->update(['last_message_at' => now(), 'messages_count' => ($c->messages_count ?? 0) + 1]);

        $this->body = '';
        unset($this->conversations, $this->active);
    }

    public function openNew(): void
    {
        $this->reset(['recipientId', 'firstMessage']);
        $this->showNew = true;
        $this->dispatch('open-new-conversation');
    }

    public function startConversation(): void
    {
        $this->validate([
            'recipientId'  => 'required|integer|exists:users,id',
            'firstMessage' => 'required|string|max:5000',
        ], [], ['recipientId' => 'destinataire', 'firstMessage' => 'message']);

        $uid = $this->uid();
        $rid = (int) $this->recipientId;
        abort_if($rid === $uid, 422);

        // Le destinataire DOIT appartenir à la même école (User non auto-scopé).
        $sameSchool = User::where('id', $rid)
            ->where('school_id', Auth::user()?->school_id)->exists();
        abort_unless($sameSchool, 403);

        // Réutilise une conversation privée existante entre les deux, sinon en crée une.
        $existing = Conversation::private()
            ->whereHas('participants', fn ($q) => $q->where('user_id', $uid))
            ->whereHas('participants', fn ($q) => $q->where('user_id', $rid))
            ->first();

        $c = $existing ?: Conversation::create(['type' => 'private', 'last_message_at' => now()]);

        if (! $existing) {
            foreach ([$uid, $rid] as $pid) {
                ConversationParticipant::create([
                    'conversation_id' => $c->id,
                    'user_id'         => $pid,
                    'is_admin'        => $pid === $uid,
                ]);
            }
        }

        Message::create([
            'conversation_id' => $c->id,
            'sender_id'       => $uid,
            'content'         => trim($this->firstMessage),
            'content_type'    => 'text',
            'status'          => 'sent',
        ]);
        $c->update(['last_message_at' => now(), 'messages_count' => ($c->messages_count ?? 0) + 1]);

        $this->showNew = false;
        $this->dispatch('close-modal', name: 'new-conversation');
        $this->activeId = $c->id;
        unset($this->conversations, $this->active);
    }

    public function render()
    {
        return view('mtschool::livewire.messaging.center')
            ->title(__('mtschool::messaging.title'));
    }
}
