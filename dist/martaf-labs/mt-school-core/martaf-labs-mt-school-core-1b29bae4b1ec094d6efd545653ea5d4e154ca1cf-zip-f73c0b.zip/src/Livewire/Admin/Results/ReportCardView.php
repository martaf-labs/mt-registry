<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Results;

use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\SubjectAverage;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Bulletin d'un élève pour une période (imprimable). L'appréciation générale et la
 * distinction du conseil sont éditables ici et persistées sur le PeriodAverage.
 */
#[Layout('mt::components.layouts.app')]
class ReportCardView extends Component
{
    public int $enrollmentId;
    public int $periodId;

    public string $appreciation = '';
    public string $decision     = '';
    public string $savedMessage = '';

    /** Appréciations par matière, indexées par subject_average_id. */
    public array $subjAppr = [];

    public function mount(int $enrollment, int $period): void
    {
        $this->enrollmentId = $enrollment;
        $this->periodId     = $period;

        $pa = $this->periodAverage();
        if ($pa) {
            $this->appreciation = is_array($pa->overall_assessment)
                ? ($pa->overall_assessment['fr'] ?? reset($pa->overall_assessment) ?: '')
                : (string) ($pa->overall_assessment ?? '');
            $this->decision = (string) ($pa->council_decision ?? '');
        }

        foreach (SubjectAverage::where('enrollment_id', $enrollment)->where('period_id', $period)->get() as $sa) {
            $this->subjAppr[$sa->id] = is_array($sa->appreciation)
                ? ($sa->appreciation['fr'] ?? '') : (string) ($sa->appreciation ?? '');
        }
    }

    /** Sauvegarde d'une appréciation par matière dès qu'elle change (blur). */
    public function updated($name, $value): void
    {
        if (! str_starts_with($name, 'subjAppr.')) {
            return;
        }

        $id = (int) substr($name, strlen('subjAppr.'));
        $sa = SubjectAverage::find($id);
        if ($sa) {
            $sa->appreciation = filled($value) ? ['fr' => $value] : null;
            $sa->save();
            $this->savedMessage = __('mtschool::report_card.subject_appreciation_saved');
        }
    }

    protected function periodAverage(): ?PeriodAverage
    {
        return PeriodAverage::where('enrollment_id', $this->enrollmentId)
            ->where('period_id', $this->periodId)->first();
    }

    public function saveAppreciation(): void
    {
        $pa = $this->periodAverage();
        if (! $pa) {
            return;
        }

        $pa->update([
            'overall_assessment' => filled($this->appreciation) ? ['fr' => $this->appreciation] : null,
            'council_decision'   => filled($this->decision) ? $this->decision : null,
        ]);

        $this->savedMessage = __('mtschool::report_card.appreciation_saved');
    }

    public function render()
    {
        // Consultation d'un bulletin d'une année passée : on neutralise le
        // SchoolYearScope (le SchoolScope tenant reste appliqué → pas de fuite).
        $enrollment = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->with(['student', 'classroom.gradeLevel'])->findOrFail($this->enrollmentId);
        $period     = Period::withoutGlobalScope(SchoolYearScope::class)->findOrFail($this->periodId);

        $subjects = SubjectAverage::where('enrollment_id', $this->enrollmentId)
            ->where('period_id', $this->periodId)
            ->with('subject')
            ->get()
            ->sortBy(fn ($sa) => $sa->subject?->code);

        $periodAverage = $this->periodAverage();

        $distinctions = [
            ''                      => __('mtschool::report_card.distinction_none'),
            'Félicitations'         => __('mtschool::report_card.distinction_congratulations'),
            'Encouragements'        => __('mtschool::report_card.distinction_encouragements'),
            "Tableau d'honneur"     => __('mtschool::report_card.distinction_honor_roll'),
            'Avertissement travail' => __('mtschool::report_card.distinction_work_warning'),
            'Blâme'                 => __('mtschool::report_card.distinction_reprimand'),
        ];

        $yearId = $enrollment->school_year_id;

        return view('mtschool::livewire.admin.results.report-card', compact(
            'enrollment', 'period', 'subjects', 'periodAverage', 'distinctions', 'yearId'
        ))->title(__('mtschool::report_card.title'));
    }
}
