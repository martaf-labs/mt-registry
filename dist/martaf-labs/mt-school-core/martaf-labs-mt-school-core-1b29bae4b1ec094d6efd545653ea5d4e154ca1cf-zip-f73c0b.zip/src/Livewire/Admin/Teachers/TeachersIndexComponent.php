<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Teachers;

use Mt\MtSchoolCore\Livewire\Indexes\TeacherIndex;
use Mt\MtSchoolCore\Models\Teacher;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtViews\Livewire\Base\BaseIndex;

class TeachersIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return TeacherIndex::class;
    }

    /** Crée un accès portail (User + userable) pour l'enseignant et affiche ses identifiants. */
    public function provisionPortal(int $teacherId): void
    {
        $teacher = Teacher::find($teacherId);
        if (! $teacher) {
            return;
        }

        try {
            $result = app(PortalAccountService::class)->provision($teacher);

            if ($result['created']) {
                showAlert('success', __('mtschool::portal.account_created', [
                    'email'    => $result['user']->email,
                    'password' => $result['password'],
                ]));
            } else {
                showAlert('info', __('mtschool::portal.account_exists', ['email' => $result['user']->email]));
            }
        } catch (\Throwable $e) {
            showAlert('error', $e->getMessage());
        }
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::students.teachers'));
    }
}
