<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Settings;

use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Setting;

/**
 * Admin — PARAMÈTRES de l'école : préférences PAR ÉCOLE stockées dans `Setting`
 * (key/value, school-scopé), et LUES par les services → la config n'est plus globale.
 *   - `notify_email`   → lu par NotificationService (envoi e-mail on/off par école).
 *   - `passing_score`  → lu par AnnualResultComputer (note de passage / redoublement).
 * Repli sur la config `.env` si le réglage n'a jamais été posé.
 */
#[Layout('mt::components.layouts.app')]
class SettingsManager extends Component
{
    public bool $notify_email = false;
    public float $passing_score = 10;
    public float $max_score = 20;

    public string $savedMessage = '';

    public function mount(): void
    {
        $this->notify_email  = Setting::getBool('notify_email', (bool) config('mt-school-core.notifications.email_enabled'));
        $this->passing_score = (float) Setting::get('passing_score', config('mt-school-core.grading.passing_score', 10));
        $this->max_score     = (float) Setting::get('max_score', config('mt-school-core.grading.max_score', 20));
    }

    public function save(): void
    {
        $this->validate([
            'passing_score' => 'required|numeric|min:0',
            'max_score'     => 'required|numeric|min:1',
        ]);

        Setting::set('notify_email', $this->notify_email ? '1' : '0');
        Setting::set('passing_score', (string) $this->passing_score);
        Setting::set('max_score', (string) $this->max_score);

        $this->savedMessage = __('mtschool::settings.saved');
    }

    public function render()
    {
        return view('mtschool::livewire.admin.settings.manager')
            ->title(__('mtschool::settings.title'));
    }
}
