<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Rollover;

use Carbon\Carbon;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Services\AnnualResultComputer;
use Mt\MtSchoolCore\Services\SchoolYearRolloverService;

/**
 * Assistant « Nouvelle année scolaire » : crée l'année cible, CLONE la structure de
 * l'année source (classes, maquettes+coefficients, frais, périodes, affectations),
 * PROMEUT les élèves au niveau suivant (redoublant/sortant/transféré), puis active
 * la nouvelle année. S'appuie sur SchoolYearRolloverService (idempotent).
 */
#[Layout('mt::components.layouts.app')]
class SchoolYearRolloverManager extends Component
{
    public int $step = 1;

    // Étape 1 — année cible
    public ?int $sourceYearId = null;
    public ?string $year_code = null;
    public ?string $start_date = null;
    public ?string $end_date = null;

    // Étape 2 — options de clonage
    public array $clone = [
        'classes' => true, 'curricula' => true, 'fees' => true,
        'periods' => true, 'assignments' => true,
    ];

    public ?int $targetYearId = null;
    public array $cloneCounts = [];

    // Étape 3 — promotion
    public array $plan = [];       // lignes du plan
    public array $actions = [];    // enrollment_id => action
    public array $promoteCounts = [];
    public array $resultCounts = [];  // récap du calcul des résultats annuels
    public bool $resultsComputed = false;

    public bool $carry_balances = true;   // reporter les reliquats de frais
    public array $carryCounts = [];

    public string $message = '';

    public function mount(): void
    {
        $source = SchoolYear::active()->first();
        $this->sourceYearId = $source?->id;

        // Suggestion : année suivante (+1 an sur les dates de la source).
        if ($source) {
            $this->start_date = $source->start_date ? Carbon::parse($source->start_date)->addYear()->toDateString() : null;
            $this->end_date   = $source->end_date ? Carbon::parse($source->end_date)->addYear()->toDateString() : null;
            $this->year_code  = $this->guessNextCode($source->code);
        }
    }

    private function guessNextCode(?string $code): ?string
    {
        if ($code && preg_match('/^(\d{4})\D+(\d{4})$/', $code, $m)) {
            return ((int) $m[1] + 1) . '-' . ((int) $m[2] + 1);
        }
        return null;
    }

    public function source(): ?SchoolYear
    {
        return $this->sourceYearId ? SchoolYear::find($this->sourceYearId) : null;
    }

    public function target(): ?SchoolYear
    {
        return $this->targetYearId ? SchoolYear::find($this->targetYearId) : null;
    }

    // ── Étape 1 → 2 : créer l'année cible ────────────────────────────────────
    public function createTarget(): void
    {
        $this->validate([
            'year_code'  => 'required|string|max:20',
            'start_date' => 'required|date',
            'end_date'   => 'required|date|after:start_date',
        ]);

        // Idempotent : réutilise l'année si le code existe déjà (école courante).
        $year = SchoolYear::firstOrCreate(
            ['code' => $this->year_code],
            ['label' => [config('mt-school-core.multilingual.default', 'fr') => $this->year_code],
             'start_date' => $this->start_date, 'end_date' => $this->end_date, 'is_active' => false]
        );

        $this->targetYearId = $year->id;
        $this->step = 2;
    }

    // ── Étape 2 → 3 : cloner la structure ────────────────────────────────────
    public function doClone(SchoolYearRolloverService $svc): void
    {
        $from = $this->source();
        $to   = $this->target();
        abort_unless($from && $to, 404);

        $counts = $svc->cloneStructure($from, $to, $this->clone);
        unset($counts['class_map']);
        $this->cloneCounts = $counts;

        $this->loadPlan($svc);
        $this->step = 3;
    }

    // Calcule le résultat annuel (moyenne/rang/décision) de toute l'année source, puis
    // recharge le plan : les élèves « redoublants » basculent en action « retain » par défaut.
    public function computeResults(AnnualResultComputer $computer, SchoolYearRolloverService $svc): void
    {
        $from = $this->source();
        abort_unless($from, 404);

        $this->resultCounts    = $computer->computeForYear($from->id);
        $this->resultsComputed = true;
        $this->loadPlan($svc);
    }

    public function loadPlan(SchoolYearRolloverService $svc): void
    {
        $from = $this->source();
        $to   = $this->target();
        abort_unless($from && $to, 404);

        $this->plan    = $svc->promotionPlan($from, $to);
        $this->actions = collect($this->plan)
            ->mapWithKeys(fn ($r) => [$r['enrollment_id'] => $r['action']])
            ->toArray();
    }

    // ── Étape 3 → 4 : promouvoir ─────────────────────────────────────────────
    public function doPromote(SchoolYearRolloverService $svc): void
    {
        $from = $this->source();
        $to   = $this->target();
        abort_unless($from && $to, 404);

        $decisions = [];
        foreach ($this->actions as $enrollmentId => $action) {
            $decisions[(int) $enrollmentId] = ['action' => $action];
        }

        $this->promoteCounts = $svc->promote($from, $to, $decisions);

        // Reporte les reliquats de frais des élèves promus (la dette suit l'élève).
        if ($this->carry_balances) {
            $this->carryCounts = $svc->carryForwardBalances($from, $to);
        }

        $this->step = 4;
    }

    // ── Étape 4 : activer la nouvelle année ──────────────────────────────────
    public function activateTarget()
    {
        $to = $this->target();
        abort_unless($to, 404);
        $to->activate();

        session()->flash('success', __('mtschool::structure.new_year_activated', ['year' => $to->code]));
        // mt_get_route() renvoie une URL → redirect() (pas redirectRoute() qui attend un nom).
        return $this->redirect(mt_get_route('dashboard'), navigate: true);
    }

    public function render()
    {
        return view('mtschool::livewire.admin.rollover.new-year', [
            'sourceYear' => $this->source(),
            'targetYear' => $this->target(),
        ])->title(__('mtschool::structure.new_year_title'));
    }
}
