<?php

namespace Mt\MtSchoolCore\Livewire\Admin\CustomFields;

use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Enums\CustomFieldType;
use Mt\MtSchoolCore\Models\CustomField;
use Mt\MtSchoolCore\Models\CustomFieldGroup;

/**
 * Gestionnaire des champs personnalisés par école (EAV).
 *
 * Composant dédié (philosophie « Manager » : onglets = type d'entité, formulaires
 * inline en modale, computed pour la donnée). L'école définit ICI ses groupes et
 * ses champs ; les valeurs sont saisies dans les formulaires d'entités via le trait
 * HasCustomFields. Gaté par le module `custom_fields` (route protégée côté hôte).
 */
#[Layout('mt::components.layouts.app')]
class CustomFieldManager extends Component
{
    /** Onglet courant = type d'entité logique (student|guardian|staff). */
    public string $entityType = 'student';

    // ── Modale champ ──────────────────────────────────────────────────────────
    public bool $showFieldModal = false;
    public ?int $editingFieldId = null;
    public array $fieldForm = [
        'group_id' => null,
        'label'    => '',
        'key'      => '',
        'type'     => 'text',
        'required' => false,
        'help'     => '',
        'options'  => [],   // [['value'=>,'label'=>], …]
        'active'   => true,
    ];

    // ── Modale groupe ─────────────────────────────────────────────────────────
    public bool $showGroupModal = false;
    public ?int $editingGroupId = null;
    public array $groupForm = ['name' => '', 'description' => ''];

    public string $successMessage = '';
    public string $errorMessage = '';

    public function mount(): void
    {
        $first = array_key_first($this->entitiesMap());
        if ($first) {
            $this->entityType = $first;
        }
    }

    // ── Référentiel d'entités (config) ────────────────────────────────────────

    protected function entitiesMap(): array
    {
        return config('mt-school-core.custom_fields.entities', []);
    }

    #[Computed]
    public function entities(): array
    {
        return collect($this->entitiesMap())
            ->map(fn ($def, $key) => [
                'key'   => $key,
                'label' => isset($def['label']) ? __('mtschool::custom_fields.' . $def['label']) : Str::headline($key),
            ])
            ->values()->all();
    }

    #[Computed]
    public function fieldTypes(): array
    {
        return CustomFieldType::options();
    }

    // ── Donnée ────────────────────────────────────────────────────────────────

    #[Computed]
    public function groups()
    {
        return CustomFieldGroup::forEntity($this->entityType)
            ->with(['fields' => fn ($q) => $q->orderBy('position')])
            ->get();
    }

    #[Computed]
    public function ungroupedFields()
    {
        return CustomField::forEntity($this->entityType)
            ->whereNull('group_id')
            ->orderBy('position')
            ->get();
    }

    #[Computed]
    public function groupOptions(): array
    {
        return $this->groups->mapWithKeys(fn ($g) => [$g->id => $g->name])->all();
    }

    public function setEntity(string $type): void
    {
        if (array_key_exists($type, $this->entitiesMap())) {
            $this->entityType = $type;
            unset($this->groups, $this->ungroupedFields, $this->groupOptions);
        }
    }

    // ── CHAMPS ────────────────────────────────────────────────────────────────

    public function createField(?int $groupId = null): void
    {
        $this->resetValidation();
        $this->editingFieldId = null;
        $this->fieldForm = [
            'group_id' => $groupId,
            'label'    => '',
            'key'      => '',
            'type'     => 'text',
            'required' => false,
            'help'     => '',
            'options'  => [],
            'active'   => true,
        ];
        $this->showFieldModal = true;
        $this->dispatch('open-custom-field-modal');
    }

    public function editField(int $id): void
    {
        $field = CustomField::findOrFail($id);
        $this->resetValidation();
        $this->editingFieldId = $id;
        $this->fieldForm = [
            'group_id' => $field->group_id,
            'label'    => $field->label,
            'key'      => $field->key,
            'type'     => $field->type->value,
            'required' => (bool) $field->required,
            'help'     => $field->help ?? '',
            'options'  => $field->options ?? [],
            'active'   => (bool) $field->active,
        ];
        $this->showFieldModal = true;
        $this->dispatch('open-custom-field-modal');
    }

    public function addOption(): void
    {
        $this->fieldForm['options'][] = ['value' => '', 'label' => ''];
    }

    public function removeOption(int $i): void
    {
        unset($this->fieldForm['options'][$i]);
        $this->fieldForm['options'] = array_values($this->fieldForm['options']);
    }

    public function saveField(): void
    {
        $locale = config('mt-school-core.multilingual.default', 'fr');
        $type   = CustomFieldType::from($this->fieldForm['type']);

        // Clé auto depuis le libellé si vide.
        if (blank($this->fieldForm['key']) && filled($this->fieldForm['label'])) {
            $this->fieldForm['key'] = Str::slug($this->fieldForm['label'], '_');
        }

        $this->validate([
            'fieldForm.label' => 'required|string|max:120',
            'fieldForm.key'   => [
                'required', 'string', 'max:60', 'regex:/^[a-z][a-z0-9_]*$/',
                Rule::unique('custom_fields', 'key')
                    ->where('school_id', currentSchoolId())
                    ->where('entity_type', $this->entityType)
                    ->ignore($this->editingFieldId),
            ],
            'fieldForm.type'     => ['required', Rule::in(array_keys(CustomFieldType::options()))],
            'fieldForm.group_id' => 'nullable|integer',
        ], [
            'fieldForm.key.regex'  => __('mtschool::custom_fields.key_regex_error'),
            'fieldForm.key.unique' => __('mtschool::custom_fields.key_unique_error'),
        ]);

        // Nettoyage des options (types à choix uniquement).
        $options = null;
        if ($type->hasOptions()) {
            $options = collect($this->fieldForm['options'])
                ->filter(fn ($o) => filled($o['label'] ?? null))
                ->map(fn ($o) => [
                    'value' => filled($o['value'] ?? null) ? $o['value'] : Str::slug($o['label'], '_'),
                    'label' => $o['label'],
                ])->values()->all();

            if (empty($options)) {
                $this->addError('fieldForm.options', __('mtschool::custom_fields.options_required_error'));
                return;
            }
        }

        $payload = [
            'entity_type' => $this->entityType,
            'group_id'    => $this->fieldForm['group_id'] ?: null,
            'key'         => $this->fieldForm['key'],
            'label'       => [$locale => $this->fieldForm['label']],
            'help'        => filled($this->fieldForm['help']) ? [$locale => $this->fieldForm['help']] : null,
            'type'        => $type->value,
            'required'    => (bool) $this->fieldForm['required'],
            'options'     => $options,
            'active'      => (bool) $this->fieldForm['active'],
        ];

        if ($this->editingFieldId) {
            CustomField::findOrFail($this->editingFieldId)->update($payload);
            $this->successMessage = __('mtschool::custom_fields.field_updated');
        } else {
            $payload['position'] = (int) CustomField::forEntity($this->entityType)->max('position') + 1;
            CustomField::create($payload);
            $this->successMessage = __('mtschool::custom_fields.field_added');
        }

        $this->showFieldModal = false;
        $this->editingFieldId = null;
        unset($this->groups, $this->ungroupedFields);
    }

    public function toggleField(int $id): void
    {
        $field = CustomField::findOrFail($id);
        $field->update(['active' => ! $field->active]);
        unset($this->groups, $this->ungroupedFields);
    }

    public function deleteField(int $id): void
    {
        CustomField::findOrFail($id)->delete();
        $this->successMessage = __('mtschool::custom_fields.field_deleted');
        unset($this->groups, $this->ungroupedFields);
    }

    // ── GROUPES ───────────────────────────────────────────────────────────────

    public function createGroup(): void
    {
        $this->resetValidation();
        $this->editingGroupId = null;
        $this->groupForm = ['name' => '', 'description' => ''];
        $this->showGroupModal = true;
        $this->dispatch('open-custom-field-group-modal');
    }

    public function editGroup(int $id): void
    {
        $group = CustomFieldGroup::findOrFail($id);
        $this->resetValidation();
        $this->editingGroupId = $id;
        $this->groupForm = ['name' => $group->name, 'description' => $group->description ?? ''];
        $this->showGroupModal = true;
        $this->dispatch('open-custom-field-group-modal');
    }

    public function saveGroup(): void
    {
        $this->validate(['groupForm.name' => 'required|string|max:120']);
        $locale = config('mt-school-core.multilingual.default', 'fr');

        $payload = [
            'entity_type' => $this->entityType,
            'name'        => [$locale => $this->groupForm['name']],
            'description' => filled($this->groupForm['description']) ? [$locale => $this->groupForm['description']] : null,
        ];

        if ($this->editingGroupId) {
            CustomFieldGroup::findOrFail($this->editingGroupId)->update($payload);
            $this->successMessage = __('mtschool::custom_fields.group_updated');
        } else {
            $payload['position'] = (int) CustomFieldGroup::forEntity($this->entityType)->max('position') + 1;
            CustomFieldGroup::create($payload);
            $this->successMessage = __('mtschool::custom_fields.group_added');
        }

        $this->showGroupModal = false;
        $this->editingGroupId = null;
        unset($this->groups, $this->groupOptions);
    }

    public function deleteGroup(int $id): void
    {
        // Les champs du groupe deviennent « sans groupe » (nullOnDelete au niveau SQL,
        // mais ici on supprime explicitement le groupe ; les champs restent).
        CustomFieldGroup::findOrFail($id)->delete();
        $this->successMessage = __('mtschool::custom_fields.group_deleted');
        unset($this->groups, $this->ungroupedFields, $this->groupOptions);
    }

    public function render()
    {
        return view('mtschool::livewire.admin.custom-fields.manager')
            ->title(__('mtschool::custom_fields.title'));
    }
}
