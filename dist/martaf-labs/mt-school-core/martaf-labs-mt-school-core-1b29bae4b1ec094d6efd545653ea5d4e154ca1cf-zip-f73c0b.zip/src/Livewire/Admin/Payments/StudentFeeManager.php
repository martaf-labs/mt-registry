<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Payments;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Payment;
use Mt\MtSchoolCore\Models\SchoolFee;
use Mt\MtSchoolCore\Services\FeeService;

/**
 * Détail financier d'un élève : édition/exonération manuelle des frais, échéancier
 * par frais, historique des paiements.
 */
#[Layout('mt::components.layouts.app')]
class StudentFeeManager extends Component
{
    public int $enrollmentId;

    /** Lignes éditables indexées par school_fee_id. */
    public array $rows = [];

    // Échéancier
    public ?int $instFeeId = null;
    public int $instCount = 3;
    public ?string $instFirstDate = null;

    public string $successMessage = '';

    public function mount(int $enrollment): void
    {
        // Garde-fou tenant : findOrFail applique le SchoolScope.
        Enrollment::findOrFail($enrollment);
        $this->enrollmentId  = $enrollment;
        $this->instFirstDate = now()->format('Y-m-d');
        $this->loadRows();
    }

    protected function loadRows(): void
    {
        $this->rows = [];
        foreach (SchoolFee::where('enrollment_id', $this->enrollmentId)->with('feeType')->orderBy('id')->get() as $f) {
            $this->rows[$f->id] = [
                'type'      => $f->feeType?->label,
                'gross'     => (float) $f->gross_amount,
                'discount'  => (float) $f->discount,
                'net'       => (float) $f->net_amount,
                'paid'      => (float) $f->amount_paid,
                'remaining' => (float) $f->remaining_amount,
                'is_exempt' => (bool) $f->is_exempt,
                'status'    => $f->status?->value ?? (string) $f->status,
            ];
        }
    }

    public function updated($name, $value): void
    {
        if (! str_starts_with($name, 'rows.')) {
            return;
        }
        $parts  = explode('.', $name);
        $feeId  = (int) ($parts[1] ?? 0);
        if (! $feeId || ! isset($this->rows[$feeId])) {
            return;
        }

        // Appartenance : le frais DOIT être de l'inscription courante (le tableau `rows`
        // est public → un payload forgé pourrait viser un frais d'un autre élève de l'école).
        $fee = SchoolFee::where('enrollment_id', $this->enrollmentId)->find($feeId);
        if (! $fee) {
            return;
        }

        app(FeeService::class)->adjustFee(
            $fee,
            (float) ($this->rows[$feeId]['discount'] ?? 0),
            (bool) ($this->rows[$feeId]['is_exempt'] ?? false)
        );

        $this->loadRows();
        $this->successMessage = __('mtschool::finances.fee_updated');
    }

    #[Computed]
    public function fees()
    {
        return SchoolFee::where('enrollment_id', $this->enrollmentId)
            ->with(['feeType', 'installments' => fn ($q) => $q->orderBy('order')])
            ->orderBy('id')->get();
    }

    #[Computed]
    public function payments()
    {
        $feeIds = SchoolFee::where('enrollment_id', $this->enrollmentId)->pluck('id');
        return Payment::whereIn('school_fee_id', $feeIds)->orderByDesc('payment_date')->get();
    }

    public function generateInstallments(): void
    {
        $this->validate([
            'instFeeId'     => 'required|integer',
            'instCount'     => 'required|integer|min:1|max:12',
            'instFirstDate' => 'required|date',
        ], [], ['instFeeId' => __('mtschool::finances.fee_field_required'), 'instCount' => __('mtschool::finances.installments_count_required')]);

        $fee = SchoolFee::where('enrollment_id', $this->enrollmentId)->findOrFail($this->instFeeId);
        $n = app(FeeService::class)->generateInstallments($fee, $this->instCount, $this->instFirstDate);

        unset($this->fees);
        $this->successMessage = __('mtschool::finances.installments_created_msg', ['n' => $n]);
    }

    /** Statut d'une échéance déduit du cumulatif payé du frais. */
    public function installmentStatus($fee, $installment, float $cumulativeBefore): string
    {
        $paid = (float) $fee->amount_paid;
        $end  = $cumulativeBefore + (float) $installment->amount;

        if ($paid >= $end) return 'paid';
        if ($paid > $cumulativeBefore) return 'partial';
        if ($installment->due_date && $installment->due_date->isPast()) return 'overdue';
        return 'pending';
    }

    public function render()
    {
        $enrollment = Enrollment::with('student', 'classroom')->findOrFail($this->enrollmentId);
        return view('mtschool::livewire.admin.payments.student-fee', compact('enrollment'))
            ->title(__('mtschool::finances.student_detail_title'));
    }
}
