<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Enrollments;

use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Enums\EnrollmentStatus;
use Mt\MtSchoolCore\Livewire\Indexes\EnrollmentIndex;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtViews\Livewire\Base\BaseIndex;

/**
 * Écran Inscriptions = INSTANCE de base-index (pilote de la doctrine
 * « vues généralistes d'abord »). La liste/stats/filtres/recherche viennent
 * du moteur ; ici seulement la logique métier : valider / refuser (avec motif).
 * Remplace l'ancien EnrollmentManager (vue bespoke).
 */
#[Layout('mt::components.layouts.app')]
class EnrollmentsIndexComponent extends BaseIndex
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public ?int $rejectingId = null;
    public string $rejectReason = '';

    public function indexClass(): string
    {
        return EnrollmentIndex::class;
    }

    /**
     * Filtre « en attente » par défaut UNIQUEMENT s'il y a des dossiers à traiter
     * (sa vocation : valider). Sinon, montrer toutes les inscriptions — un écran
     * vide alors que le badge de la sidebar en annonce des centaines est déroutant.
     */
    public function mount(): void
    {
        parent::mount();

        if (Enrollment::pending()->exists()) {
            $this->filterValues  = ['status' => EnrollmentStatus::PENDING->value];
            $this->activeFilters = ['status' => EnrollmentStatus::PENDING->value];
        }
    }

    /** Modale de refus, rendue en fin de base-index (point d'extension mt-views). */
    public function extraPartials(): array
    {
        return ['mtschool::livewire.admin.enrollments.partials.reject-modal'];
    }

    // ⚠️ NE PAS nommer `validate()` : écraserait la validation de formulaire de Livewire.
    public function validateEnrollment(int $id): void
    {
        $enrollment = Enrollment::find($id); // school+year scoped → tenant-safe
        if ($enrollment && $enrollment->isPending()) {
            $enrollment->validate((int) auth()->id()); // → VALIDATED + recalc effectif classe
            showAlert('success', __('mtschool::students.enrollment_validated_ok'));
        }
    }

    public function openReject(int $id): void
    {
        $this->rejectingId  = $id;
        $this->rejectReason = '';
        $this->dispatch('open-reject-enrollment');
    }

    public function cancelReject(): void
    {
        $this->rejectingId  = null;
        $this->rejectReason = '';
    }

    public function confirmReject(): void
    {
        if (! $this->rejectingId) {
            return;
        }

        $enrollment = Enrollment::find($this->rejectingId);
        if ($enrollment && $enrollment->isPending()) {
            $enrollment->reject($this->rejectReason !== '' ? $this->rejectReason : '—', (int) auth()->id());
            showAlert('success', __('mtschool::students.enrollment_rejected_ok'));
        }

        $this->cancelReject();
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('enrollments', __('mtschool::students.enrollments_title'))) {
            return $gate;
        }

        return parent::render();
    }
}
