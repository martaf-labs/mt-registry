<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Certificates;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\SchoolCertificate;
use Mt\MtSchoolCore\Services\CertificateService;

/**
 * Admin — délivrance des CERTIFICATS. Choisir une classe → un élève → un type, délivrer
 * (crée un SchoolCertificate « issued »), puis télécharger le PDF. Liste des derniers
 * certificats délivrés. Tout est school-scopé (tenant).
 */
#[Layout('mt::components.layouts.app')]
class CertificateManager extends Component
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public ?int $classId = null;
    public ?int $enrollmentId = null;
    public string $type = 'enrollment';

    public string $savedMessage = '';

    #[Computed]
    public function classes()
    {
        return Classroom::orderBy('code')->get(['id', 'code']);
    }

    #[Computed]
    public function enrollments()
    {
        if (! $this->classId) {
            return collect();
        }

        return Enrollment::where('class_id', $this->classId)->where('status', 'validated')
            ->with('student')->get()
            ->map(fn ($e) => (object) [
                'id'   => $e->id,
                'name' => $e->student?->full_name_reverse ?? $e->student?->full_name ?? '—',
            ])
            ->sortBy('name')->values();
    }

    #[Computed]
    public function certificates()
    {
        return SchoolCertificate::with('enrollment.student')
            ->orderByDesc('issued_at')->limit(30)->get()
            ->map(fn ($c) => (object) [
                'id'      => $c->id,
                'ref'     => $c->reference,
                'student' => $c->enrollment?->student?->full_name_reverse ?? $c->enrollment?->student?->full_name ?? '—',
                'type'    => $c->type,
                'issued'  => $c->issued_at,
            ]);
    }

    public function types(): array
    {
        return CertificateService::TYPES;
    }

    public function issue(CertificateService $service): void
    {
        $this->validate([
            'enrollmentId' => 'required|integer',
            'type'         => 'required|string',
        ]);

        // Appartenance tenant : l'inscription choisie doit exister dans l'école courante.
        $exists = Enrollment::where('id', $this->enrollmentId)->exists();
        if (! $exists) {
            $this->addError('enrollmentId', __('mtschool::documents.cert_student_required'));
            return;
        }

        $service->issue($this->enrollmentId, $this->type);

        $this->reset(['enrollmentId']);
        unset($this->certificates);
        $this->savedMessage = __('mtschool::documents.cert_issued_ok');
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('certificates', __('mtschool::documents.certificates_title'))) {
            return $gate;
        }

        return view('mtschool::livewire.admin.certificates.manager')
            ->title(__('mtschool::documents.certificates_title'));
    }
}
