<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Guardians;

use Mt\MtSchoolCore\Livewire\Shows\GuardianProfile;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Services\PortalAccountService;
use Mt\MtViews\Livewire\Base\BaseShow;

/**
 * Fiche tuteur = INSTANCE de base-profile (fiche de PERSONNE — avatar rond,
 * onglets, sections). La présentation vient du moteur base-show ; la config
 * vit dans GuardianProfile (Shows\GenericProfile). Logique métier ici :
 * provisionner un accès portail (parent).
 */
class GuardiansProfileComponent extends BaseShow
{
    public function showClass(): string
    {
        return GuardianProfile::class;
    }

    /** Crée un accès portail (compte parent) pour le tuteur + affiche ses identifiants. */
    public function provisionPortal(): void
    {
        $guardian = Guardian::find($this->id);
        if (! $guardian) {
            return;
        }

        try {
            $result = app(PortalAccountService::class)->provision($guardian);

            if ($result['created']) {
                showAlert('success', __('mtschool::portal.account_created', [
                    'email'    => $result['user']->email,
                    'password' => $result['password'],
                ]));
            } else {
                showAlert('info', __('mtschool::portal.account_exists', ['email' => $result['user']->email]));
            }
        } catch (\Throwable $e) {
            showAlert('error', $e->getMessage());
        }
    }
}
