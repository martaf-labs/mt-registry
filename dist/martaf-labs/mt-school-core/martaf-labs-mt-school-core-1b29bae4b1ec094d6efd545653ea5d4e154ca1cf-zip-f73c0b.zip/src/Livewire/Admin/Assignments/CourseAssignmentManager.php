<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Assignments;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Affectations d'une classe : pour chaque matière de la MAQUETTE du niveau,
 * on assigne un enseignant (CourseAssignment). Coefficient & heures hérités
 * de la maquette par défaut. Persistance inline.
 *
 * Tenant : Classroom est school-scoped ; CourseAssignment school+year-scoped.
 */
#[Layout('mt::components.layouts.app')]
class CourseAssignmentManager extends Component
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public int $classId;
    public ?Classroom $classroom = null;
    public ?Curriculum $curriculum = null;

    /** Lignes indexées par subject_id. */
    public array $rows = [];

    public string $successMessage = '';

    public function mount(int $id): void
    {
        $this->classroom = Classroom::with(['gradeLevel', 'specialization'])->findOrFail($id);
        $this->classId   = $id;

        // Maquette du niveau (+ filière) pour l'année active (auto-scopée).
        $this->curriculum = Curriculum::where('grade_level_id', $this->classroom->grade_level_id)
            ->where('specialization_id', $this->classroom->specialization_id)
            ->with(['subjects' => fn ($q) => $q->orderBy('curriculum_subject.order')])
            ->first();

        $this->loadRows();
    }

    protected function loadRows(): void
    {
        $this->rows = [];

        if (! $this->curriculum) {
            return;
        }

        // Affectations existantes indexées par subject_id.
        $assignments = CourseAssignment::where('class_id', $this->classId)
            ->get()->keyBy('subject_id');

        foreach ($this->curriculum->subjects as $s) {
            $a = $assignments->get($s->id);

            $this->rows[$s->id] = [
                'label'         => $s->label,
                'code'          => $s->code,
                'color'         => $s->color,
                'coefficient'   => (float) ($s->pivot->coefficient ?? 1),
                'teacher_id'    => $a?->teacher_id,
                'weekly_hours'  => $a?->weekly_hours !== null
                                    ? (float) $a->weekly_hours
                                    : ($s->pivot->weekly_hours !== null ? (float) $s->pivot->weekly_hours : null),
                'assignment_id' => $a?->id,
            ];
        }
    }

    #[Computed]
    public function teachers()
    {
        return Teacher::with('staff')->active()->get()
            ->sortBy(fn ($t) => $t->full_name)
            ->mapWithKeys(fn ($t) => [$t->id => $t->full_name])
            ->toArray();
    }

    #[Computed]
    public function assignedCount(): int
    {
        return collect($this->rows)->filter(fn ($r) => ! empty($r['teacher_id']))->count();
    }

    public function updated($name, $value): void
    {
        if (! str_starts_with($name, 'rows.')) {
            return;
        }

        $parts = explode('.', $name);
        $subjectId = (int) ($parts[1] ?? 0);

        if (! $subjectId || ! isset($this->rows[$subjectId])) {
            return;
        }

        $this->persistAssignment($subjectId);
        unset($this->assignedCount);
    }

    protected function persistAssignment(int $subjectId): void
    {
        $row = $this->rows[$subjectId];

        // Pas d'enseignant → on retire l'affectation existante.
        if (empty($row['teacher_id'])) {
            CourseAssignment::where('class_id', $this->classId)
                ->where('subject_id', $subjectId)
                ->delete();
            $this->rows[$subjectId]['assignment_id'] = null;
            $this->successMessage = __('mtschool::academics.assignment_removed');
            return;
        }

        $assignment = CourseAssignment::updateOrCreate(
            [
                'class_id'       => $this->classId,
                'subject_id'     => $subjectId,
                'school_year_id' => activeSchoolYearId(),
            ],
            [
                'teacher_id'   => (int) $row['teacher_id'],
                'weekly_hours' => ($row['weekly_hours'] === '' || $row['weekly_hours'] === null)
                                    ? null : (float) $row['weekly_hours'],
                'coefficient'  => (float) ($row['coefficient'] ?? 1),
                'active'        => true,
            ]
        );

        $this->rows[$subjectId]['assignment_id'] = $assignment->id;
        $this->successMessage = __('mtschool::academics.assignment_saved');
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('assignments', __('mtschool::academics.assignments'))) {
            return $gate;
        }

        return view('mtschool::livewire.admin.assignments.manager')
            ->title(__('mtschool::academics.assignments'));
    }
}
