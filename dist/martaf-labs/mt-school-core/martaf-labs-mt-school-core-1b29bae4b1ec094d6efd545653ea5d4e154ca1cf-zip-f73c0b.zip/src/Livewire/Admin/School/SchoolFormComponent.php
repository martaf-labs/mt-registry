<?php

namespace Mt\MtSchoolCore\Livewire\Admin\School;

use Mt\MtSchoolCore\Livewire\Forms\SchoolForm;
use Mt\MtSchoolCore\Models\School;
use Mt\MtViews\Livewire\Base\BaseForm;

/**
 * Identité de l'établissement (singleton). Édite l'école active, ou la crée.
 */
class SchoolFormComponent extends BaseForm
{
    public function mount(?int $id = null): void
    {
        // Singleton : on édite toujours l'école active si elle existe.
        $id = $id ?? School::current()?->id;

        parent::mount($id);
    }

    public function formClass(): string
    {
        return SchoolForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.establishment_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.establishment_model_name');
    }

    public function getModelNavItems($data = null): array
    {
        return navItems('school', __('mtschool::structure.establishment_nav'))->add(__('mtschool::structure.identity'), '#')->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'settings.school';
    }
}
