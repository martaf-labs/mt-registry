<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Classrooms;

use Mt\MtSchoolCore\Livewire\Indexes\ClassroomIndex;
use Mt\MtViews\Livewire\Base\BaseIndex;

class ClassroomsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return ClassroomIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.classrooms'));
    }
}
