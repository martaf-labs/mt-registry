<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Fees;

use Mt\MtSchoolCore\Livewire\Indexes\FeeTypeIndex;
use Mt\MtViews\Livewire\Base\BaseIndex;

class FeeTypesIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return FeeTypeIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::academics.fee_types'));
    }
}
