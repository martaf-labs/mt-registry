<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Assessments;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Enums\AssessmentStatus;
use Mt\MtSchoolCore\Models\Assessment;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Grade;

/**
 * Saisie des notes d'une évaluation : roster des élèves inscrits (validés) de la
 * classe, une note par élève (ou absent). final_score auto-calculé (hook Grade).
 * Moyenne de classe & progression en direct.
 */
#[Layout('mt::components.layouts.app')]
class GradeEntryManager extends Component
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public int $assessmentId;
    public ?Assessment $assessment = null;

    /** Lignes indexées par enrollment_id. */
    public array $rows = [];

    public string $successMessage = '';

    public function mount(int $id): void
    {
        $this->assessment = Assessment::with(['classroom', 'subject', 'period'])->findOrFail($id);
        $this->assessmentId = $id;

        // Un enseignant ne peut saisir que SES évaluations.
        $user = auth()->user();
        if ($user?->school_role?->value === 'teacher') {
            $teacher = $user->userable;
            abort_unless($teacher && (int) $this->assessment->teacher_id === (int) $teacher->id, 403);
        }

        $this->loadRows();
    }

    /** Route de retour adaptée au rôle (portail enseignant vs admin). */
    public function backRoute(): string
    {
        return auth()->user()?->school_role?->value === 'teacher'
            ? mt_get_route('teacher_home')
            : mt_get_route('academics_assessments');
    }

    protected function loadRows(): void
    {
        $this->rows = [];

        $enrollments = Enrollment::where('class_id', $this->assessment->class_id)
            ->validated()
            ->with('student')
            ->get()
            ->sortBy(fn ($e) => $e->student?->full_name_reverse ?? '');

        $grades = Grade::where('assessment_id', $this->assessmentId)->get()->keyBy('enrollment_id');

        foreach ($enrollments as $e) {
            $g = $grades->get($e->id);

            $this->rows[$e->id] = [
                'student'           => $e->student?->full_name_reverse ?? $e->student?->full_name ?? '—',
                'reference'         => $e->student?->reference,
                'score'             => $g && $g->score !== null ? (float) $g->score : null,
                'is_absent'         => (bool) ($g?->is_absent),
                'justified_absence' => (bool) ($g?->justified_absence),
                'final_score'       => $g?->final_score !== null ? (float) $g->final_score : null,
                'grade_id'          => $g?->id,
            ];
        }
    }

    #[Computed]
    public function maxScore(): float
    {
        return (float) ($this->assessment->max_score ?? 20);
    }

    #[Computed]
    public function enteredCount(): int
    {
        return collect($this->rows)->filter(fn ($r) => $r['score'] !== null || $r['is_absent'])->count();
    }

    #[Computed]
    public function classAverage(): ?float
    {
        $scores = collect($this->rows)
            ->filter(fn ($r) => ! $r['is_absent'] && $r['final_score'] !== null)
            ->map(fn ($r) => (float) $r['final_score']);

        return $scores->isEmpty() ? null : round($scores->avg(), 2);
    }

    public function updated($name, $value): void
    {
        if (! str_starts_with($name, 'rows.')) {
            return;
        }

        $parts = explode('.', $name);
        $enrollmentId = (int) ($parts[1] ?? 0);

        if (! $enrollmentId || ! isset($this->rows[$enrollmentId])) {
            return;
        }

        $this->persistGrade($enrollmentId);
        unset($this->enteredCount, $this->classAverage);
    }

    protected function persistGrade(int $enrollmentId): void
    {
        $row    = $this->rows[$enrollmentId];
        $absent = (bool) $row['is_absent'];
        $score  = $row['score'];

        // Garde-fou de la note : REJETER hors [0..max] ou non numérique (au lieu de
        // l'écrêter en silence, ce qui transformait 155/20 en 20 ou 'abc' en 0).
        if (! $absent && $score !== null && $score !== '') {
            if (! is_numeric($score) || (float) $score < 0 || (float) $score > $this->maxScore) {
                $this->addError(
                    "rows.$enrollmentId.score",
                    __('mtschool::academics.grade_out_of_range', ['max' => $this->maxScore])
                );
                return; // on ne persiste PAS une valeur invalide
            }
            $score = (float) $score;
            $this->rows[$enrollmentId]['score'] = $score;
        } else {
            $score = null;
        }

        // Saisie valide : on lève une éventuelle erreur précédente sur ce champ.
        $this->resetErrorBag("rows.$enrollmentId.score");

        // Rien à enregistrer (ni note, ni absence) → on retire une éventuelle note.
        if ($score === null && ! $absent) {
            Grade::where('assessment_id', $this->assessmentId)->where('enrollment_id', $enrollmentId)->delete();
            $this->rows[$enrollmentId]['grade_id']    = null;
            $this->rows[$enrollmentId]['final_score'] = null;
            return;
        }

        $grade = Grade::updateOrCreate(
            ['assessment_id' => $this->assessmentId, 'enrollment_id' => $enrollmentId],
            [
                'score'             => $score,
                'is_absent'         => $absent,
                'justified_absence' => $absent ? (bool) $row['justified_absence'] : false,
            ]
        );

        $this->rows[$enrollmentId]['grade_id']    = $grade->id;
        $this->rows[$enrollmentId]['final_score'] = $grade->final_score !== null ? (float) $grade->final_score : null;
        $this->successMessage = __('mtschool::academics.grade_saved');
    }

    /** Marque l'évaluation comme « notes saisies » et publiable. */
    public function publish(): void
    {
        $this->assessment->update([
            'status'    => AssessmentStatus::ENTERED->value,
            'published' => true,
        ]);
        $this->assessment->refresh();
        $this->successMessage = __('mtschool::academics.grades_published');
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('grade_entry', __('mtschool::academics.grade_entry_title'))) {
            return $gate;
        }

        return view('mtschool::livewire.admin.assessments.grade-entry')
            ->title(__('mtschool::academics.grade_entry_title'));
    }
}
