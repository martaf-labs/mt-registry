<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Pedagogy;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\HomeworkSupervisionIndex;
use Mt\MtSchoolCore\Models\Homework;
use Mt\MtViews\Livewire\Base\BaseIndex;

/**
 * Supervision ADMIN des devoirs = INSTANCE de base-index. Liste/stats/filtres viennent
 * du moteur ; ici la logique : détail lecture seule (modale) + suppression (modération,
 * permission school.homeworks.manage). Le versant enseignant vit sur le portail.
 */
#[Layout('mt::components.layouts.app')]
class HomeworkSupervision extends BaseIndex
{
    public ?int $detailId = null;

    public function indexClass(): string
    {
        return HomeworkSupervisionIndex::class;
    }

    public function extraPartials(): array
    {
        return ['mtschool::livewire.admin.pedagogy.partials.homework-detail'];
    }

    /** Devoir affiché dans la modale de détail (rendus en lecture seule). */
    #[Computed]
    public function detail(): ?Homework
    {
        return $this->detailId
            ? Homework::with(['submissions.enrollment.student', 'classroom', 'subject', 'teacher.staff'])->find($this->detailId)
            : null;
    }

    public function showDetail(int $id): void
    {
        $this->detailId = $id;
        $this->dispatch('open-homework-detail');
    }

    // ⚠️ NE PAS nommer delete() : entre en conflit avec des méthodes internes ; méthode dédiée.
    public function deleteHomework(int $id): void
    {
        abort_unless(auth()->user()?->can('school.homeworks.manage'), 403);

        Homework::findOrFail($id)->delete();
        if ($this->detailId === $id) {
            $this->detailId = null;
        }
        showAlert('success', __('mtschool::pedagogy.sup_deleted'));
    }
}
