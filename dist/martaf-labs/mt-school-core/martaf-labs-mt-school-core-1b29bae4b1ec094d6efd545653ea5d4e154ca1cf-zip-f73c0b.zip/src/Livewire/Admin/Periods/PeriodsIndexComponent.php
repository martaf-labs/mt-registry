<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Periods;

use Mt\MtSchoolCore\Livewire\Indexes\PeriodIndex;
use Mt\MtViews\Livewire\Base\BaseIndex;

class PeriodsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return PeriodIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.periods'));
    }
}
