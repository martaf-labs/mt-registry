<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Periods;

use Mt\MtSchoolCore\Livewire\Forms\PeriodForm;
use Mt\MtViews\Livewire\Base\BaseForm;

class PeriodsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return PeriodForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.period_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.period_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('period', __('mtschool::structure.periods'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('period', __('mtschool::structure.periods'))
                ->add($data->code, mt_get_route('periods'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.periods';
    }

    public function steps(): array
    {
        return [];
    }
}
