<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Team;

use Illuminate\Validation\Rule;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Enums\RoleSchool;
use Mt\MtSchoolCore\Models\User;

/**
 * Admin — GESTION DE L'ÉQUIPE (RBAC). Le super-admin/principal crée des comptes
 * back-office et leur attribue un rôle (censeur, comptable, personnel). Le rôle
 * (`school_role`) pilote ce que l'utilisateur voit (menu gaté par permission) et peut
 * atteindre (routes gatées `can:`) — cf. RoleSchool::permissions() + Gate::before.
 *
 * ⚠️ Tenant-safe : User n'a PAS de SchoolScope (récursion auth) → TOUTES les requêtes
 * filtrent `school_id = currentSchoolId()` à la main (sinon fuite cross-tenant).
 * ⚠️ Anti-verrouillage : on n'édite/désactive ni soi-même ni un super-admin (propriétaire).
 * Les comptes portail (enseignant/élève/parent) ne sont PAS gérés ici (provisioning dédié).
 */
#[Layout('mt::components.layouts.app')]
class TeamManager extends Component
{
    public bool $showForm = false;
    public ?int $editingId = null;

    public string $name = '';
    public string $email = '';
    public string $phone = '';
    public string $role = '';
    public string $password = '';
    public bool $isActive = true;

    public string $savedMessage = '';

    public function mount(): void
    {
        abort_unless((bool) auth()->user()?->can('school.users.manage'), 403);
    }

    protected function schoolId(): ?int
    {
        return currentSchoolId();
    }

    #[Computed]
    public function members()
    {
        $backOffice = array_map(fn (RoleSchool $r) => $r->value, [
            RoleSchool::SUPER_ADMIN, RoleSchool::PRINCIPAL,
            RoleSchool::VICE_PRINCIPAL, RoleSchool::ACCOUNTANT, RoleSchool::STAFF,
        ]);

        return User::query()
            ->where('school_id', $this->schoolId())
            ->whereIn('school_role', $backOffice)
            ->orderByDesc('is_active')
            ->orderBy('name')
            ->get(['id', 'name', 'email', 'phone', 'school_role', 'is_active'])
            ->map(fn (User $u) => (object) [
                'id'       => $u->id,
                'name'     => $u->displayName(),
                'email'    => $u->email,
                'phone'    => $u->phone,
                'role'     => $u->school_role,          // enum
                'badge'    => $u->school_role?->badge() ?? 'secondary',
                'active'   => (bool) $u->is_active,
                'isOwner'  => $u->school_role === RoleSchool::SUPER_ADMIN,
                'isSelf'   => $u->id === auth()->id(),
            ]);
    }

    public function roleOptions(): array
    {
        return RoleSchool::assignableAdminOptions();
    }

    public function create(): void
    {
        $this->reset(['editingId', 'name', 'email', 'phone', 'role', 'password']);
        $this->isActive = true;
        $this->showForm = true;
    }

    public function edit(int $id): void
    {
        $user = $this->findTeamUser($id);

        // Ni un super-admin (propriétaire), ni soi-même : géré ailleurs, anti-verrouillage.
        if (! $user || $user->school_role === RoleSchool::SUPER_ADMIN || $user->id === auth()->id()) {
            abort(403);
        }

        $this->editingId = $user->id;
        $this->name      = (string) $user->name;
        $this->email     = (string) $user->email;
        $this->phone     = (string) $user->phone;
        $this->role      = $user->school_role?->value ?? '';
        $this->password  = '';
        $this->isActive  = (bool) $user->is_active;
        $this->showForm  = true;
    }

    public function save(): void
    {
        $schoolId    = $this->schoolId();
        $assignable  = array_keys($this->roleOptions());

        $this->validate([
            'name'     => ['required', 'string', 'max:150'],
            'email'    => ['required', 'email', 'max:190', Rule::unique('users', 'email')->ignore($this->editingId)],
            'phone'    => ['nullable', 'string', 'max:40'],
            'role'     => ['required', Rule::in($assignable)],
            'password' => [$this->editingId ? 'nullable' : 'required', 'nullable', 'string', 'min:8'],
        ]);

        if ($this->editingId) {
            $user = $this->findTeamUser($this->editingId);
            if (! $user || $user->school_role === RoleSchool::SUPER_ADMIN || $user->id === auth()->id()) {
                abort(403);
            }

            $user->name        = $this->name;
            $user->email       = $this->email;
            $user->phone       = $this->phone ?: null;
            $user->school_role = RoleSchool::from($this->role);
            $user->is_active   = $this->isActive;
            if ($this->password !== '') {
                $user->password = $this->password; // cast 'hashed' → haché automatiquement
            }
            $user->save();

            $this->savedMessage = __('mtschool::team.updated');
        } else {
            User::create([
                'name'        => $this->name,
                'email'       => $this->email,
                'phone'       => $this->phone ?: null,
                'password'    => $this->password,   // cast 'hashed'
                'school_id'   => $schoolId,
                'school_role' => RoleSchool::from($this->role),
                'is_active'   => $this->isActive,
                'role'        => null,              // rôle mt-auth générique réservé au super-admin
            ]);

            $this->savedMessage = __('mtschool::team.created');
        }

        $this->showForm = false;
        $this->reset(['editingId', 'name', 'email', 'phone', 'role', 'password']);
        unset($this->members);
    }

    public function toggleActive(int $id): void
    {
        $user = $this->findTeamUser($id);

        if (! $user || $user->school_role === RoleSchool::SUPER_ADMIN || $user->id === auth()->id()) {
            abort(403);
        }

        $user->is_active = ! $user->is_active;
        $user->save();
        unset($this->members);
    }

    public function cancel(): void
    {
        $this->showForm = false;
        $this->reset(['editingId', 'name', 'email', 'phone', 'role', 'password']);
    }

    /** Résout un utilisateur de l'ÉCOLE COURANTE uniquement (garde-fou tenant). */
    protected function findTeamUser(int $id): ?User
    {
        return User::query()
            ->where('school_id', $this->schoolId())
            ->whereKey($id)
            ->first();
    }

    public function render()
    {
        return view('mtschool::livewire.admin.team.manager')
            ->title(__('mtschool::team.title'));
    }
}
