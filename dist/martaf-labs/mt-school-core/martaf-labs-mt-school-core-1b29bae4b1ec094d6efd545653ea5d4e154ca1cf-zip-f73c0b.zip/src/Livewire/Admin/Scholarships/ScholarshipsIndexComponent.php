<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Scholarships;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\ScholarshipIndex;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\FeeType;
use Mt\MtSchoolCore\Services\FeeService;
use Mt\MtViews\Livewire\Base\BaseIndex;

/**
 * Écran Bourses = INSTANCE de base-index. L'attribution (classe → élève →
 * mode → couverture) se fait dans une modale (extraPartials) et réutilise
 * FeeService::grantScholarship (remise appliquée aux SchoolFee partout).
 * Remplace l'ancien ScholarshipManager (vue bespoke).
 */
#[Layout('mt::components.layouts.app')]
class ScholarshipsIndexComponent extends BaseIndex
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    // Formulaire d'attribution (modale)
    public ?int $classId = null;
    public ?int $enrollmentId = null;
    public string $mode = 'percent';       // percent | amount
    public $value = null;
    public ?int $feeTypeId = null;         // null = tous les frais
    public string $category = 'social';    // merit | social | government | other
    public string $label = '';

    public function indexClass(): string
    {
        return ScholarshipIndex::class;
    }

    public function extraPartials(): array
    {
        return ['mtschool::livewire.admin.scholarships.partials.grant-modal'];
    }

    #[Computed]
    public function classes()
    {
        return Classroom::orderBy('code')->get(['id', 'code']);
    }

    #[Computed]
    public function enrollments()
    {
        if (! $this->classId) {
            return collect();
        }

        return Enrollment::where('class_id', $this->classId)->where('status', 'validated')
            ->with('student')->get()
            ->map(fn ($e) => (object) [
                'id'   => $e->id,
                'name' => $e->student?->full_name_reverse ?? $e->student?->full_name ?? '—',
            ])
            ->sortBy('name')->values();
    }

    #[Computed]
    public function feeTypes()
    {
        return FeeType::where('active', true)->orderBy('order')->get(['id', 'label']);
    }

    public function categories(): array
    {
        return ['merit', 'social', 'government', 'other'];
    }

    public function openGrant(): void
    {
        $this->reset(['classId', 'enrollmentId', 'value', 'feeTypeId', 'label']);
        $this->mode     = 'percent';
        $this->category = 'social';
        $this->resetErrorBag();
        $this->dispatch('open-grant-scholarship');
    }

    public function grant(FeeService $fees): void
    {
        $this->validate([
            'enrollmentId' => 'required|integer',
            'mode'         => 'required|in:percent,amount',
            'value'        => 'required|numeric|min:0.01',
            'feeTypeId'    => 'nullable|integer',
        ]);

        // Appartenance tenant : l'inscription doit exister dans l'école courante.
        $enrollment = Enrollment::find($this->enrollmentId);
        if (! $enrollment) {
            $this->addError('enrollmentId', __('mtschool::finances.scholarship_student_required'));
            return;
        }

        $fees->grantScholarship($enrollment, [
            'mode'        => $this->mode,
            'value'       => (float) $this->value,
            'fee_type_id' => $this->feeTypeId ?: null,
            'type'        => $this->category,
            'label'       => $this->label !== '' ? $this->label : __('mtschool::finances.scholarship_default_label'),
        ]);

        showAlert('success', __('mtschool::finances.scholarship_granted'));
        $this->dispatch('close-modal', name: 'grant-scholarship');
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('scholarships', __('mtschool::finances.scholarships_title'))) {
            return $gate;
        }

        return parent::render();
    }
}
