<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Students;

use Mt\MtSchoolCore\Livewire\Concerns\InjectsCustomFields;
use Mt\MtSchoolCore\Livewire\Forms\StudentForm;
use Mt\MtViews\Livewire\Base\BaseForm;

/**
 * Édition d'un élève (attributs propres) + champs personnalisés de l'école (EAV, via
 * InjectsCustomFields). Distinct de l'assistant d'inscription (StudentsFormComponent).
 */
class StudentsEditFormComponent extends BaseForm
{
    use InjectsCustomFields;

    public function formClass(): string
    {
        return StudentForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::students.student_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::students.students');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('student', __('mtschool::students.students'))
                ->add(__('mtschool::common.edit'), '#')
                ->get()
            : navItems('student', __('mtschool::students.students'))
                ->add($data->full_name, mt_get_route('students_profile', ['id' => $data->id]))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'students.index';
    }

    public function steps(): array
    {
        return [];
    }
}
