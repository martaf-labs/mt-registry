<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Announcements;

use Mt\MtSchoolCore\Livewire\Indexes\AnnouncementIndex;
use Mt\MtViews\Livewire\Base\BaseIndex;

class AnnouncementsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return AnnouncementIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::academics.announcements'));
    }
}
