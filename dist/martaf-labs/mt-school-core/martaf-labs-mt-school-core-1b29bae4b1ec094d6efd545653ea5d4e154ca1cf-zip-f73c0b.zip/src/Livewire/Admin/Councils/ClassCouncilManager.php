<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Councils;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Enums\RoleSchool;
use Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;
use Mt\MtSchoolCore\Models\ClassCouncil;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CouncilParticipant;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\User;

/**
 * Conseils de classe : planification (classe + période, unique), cycle de vie
 * planned → held → minutes_drafted → validated, PV (procès-verbal) et
 * participants (président / secrétaire / membre, présence + signature).
 * Lecture = school.class_councils.view ; toute action = .manage.
 */
#[Layout('mt::components.layouts.app')]
class ClassCouncilManager extends Component
{
    use ChecksPrerequisites;

    // Filtres
    public $filterPeriodId = '';
    public $filterClassId = '';
    public string $filterStatus = '';

    // Modale de planification
    public bool $showCreate = false;
    public $classId = null;
    public $periodId = null;
    public $councilDate = null;
    public string $location = '';

    // Modale de gestion (conseil sélectionné)
    public ?int $managedId = null;
    public string $minutes = '';
    public $newParticipantId = null;
    public string $newParticipantRole = 'member';

    public string $successMessage = '';

    protected function canManage(): bool
    {
        return (bool) Auth::user()?->can('school.class_councils.manage');
    }

    #[Computed]
    public function classes()
    {
        return Classroom::query()->orderBy('code')->get(['id', 'code']);
    }

    #[Computed]
    public function periods()
    {
        return Period::query()->orderBy('order')->orderBy('start_date')->get();
    }

    #[Computed]
    public function councils()
    {
        return ClassCouncil::query()
            ->when($this->filterPeriodId, fn ($q) => $q->where('period_id', $this->filterPeriodId))
            ->when($this->filterClassId,  fn ($q) => $q->where('class_id', $this->filterClassId))
            ->when($this->filterStatus !== '', fn ($q) => $q->where('status', $this->filterStatus))
            ->with(['classroom', 'period'])
            ->withCount('participants')
            ->orderByDesc('council_date')
            ->get();
    }

    #[Computed]
    public function stats(): array
    {
        return [
            'planned'   => ClassCouncil::query()->where('status', 'planned')->count(),
            'held'      => ClassCouncil::query()->whereIn('status', ['held', 'minutes_drafted'])->count(),
            'validated' => ClassCouncil::query()->validated()->count(),
        ];
    }

    /** Conseil ouvert dans la modale de gestion. */
    #[Computed]
    public function managed(): ?ClassCouncil
    {
        return $this->managedId
            ? ClassCouncil::with(['classroom', 'period', 'participants'])->find($this->managedId)
            : null;
    }

    /** Personnels de l'école pouvant siéger (User n'est PAS school-scopé → filtre manuel). */
    #[Computed]
    public function staffUsers()
    {
        return User::query()
            ->where('school_id', currentSchoolId())
            ->whereIn('school_role', [
                RoleSchool::PRINCIPAL->value, RoleSchool::VICE_PRINCIPAL->value,
                RoleSchool::TEACHER->value, RoleSchool::STAFF->value,
            ])
            ->where('is_active', true)
            ->orderBy('name')
            ->get();
    }

    /** Noms des participants du conseil géré, indexés par user_id. */
    #[Computed]
    public function participantNames(): array
    {
        if (! $this->managed) {
            return [];
        }

        return User::query()
            ->where('school_id', currentSchoolId())
            ->whereIn('id', $this->managed->participants->pluck('user_id'))
            ->get()
            ->mapWithKeys(fn ($u) => [$u->id => $u->fullName()])
            ->all();
    }

    // ── Planification ─────────────────────────────────────────────────────

    public function openCreate(): void
    {
        abort_unless($this->canManage(), 403);

        $this->reset(['classId', 'periodId', 'location']);
        $this->councilDate = now()->addWeek()->setTime(16, 0)->format('Y-m-d\TH:i');
        $this->showCreate = true;
        $this->dispatch('open-create-council');
    }

    public function createCouncil(): void
    {
        abort_unless($this->canManage(), 403);

        $this->validate([
            'classId'     => 'required|integer',
            'periodId'    => 'required|integer',
            'councilDate' => 'required|date',
            'location'    => 'nullable|string|max:120',
        ]);

        // Unicité métier : un seul conseil par classe et par période.
        if (ClassCouncil::query()->where('class_id', $this->classId)->where('period_id', $this->periodId)->exists()) {
            $this->addError('classId', __('mtschool::councils.already_exists'));

            return;
        }

        $class  = Classroom::findOrFail($this->classId);
        $period = Period::findOrFail($this->periodId);
        $locale = config('mt-school-core.multilingual.default', 'fr');

        ClassCouncil::create([
            'class_id'     => $class->id,
            'period_id'    => $period->id,
            'title'        => [$locale => __('mtschool::councils.auto_title', ['class' => $class->code, 'period' => $period->label])],
            'council_date' => $this->councilDate,
            'location'     => $this->location !== '' ? [$locale => $this->location] : null,
            'status'       => 'planned',
        ]);

        $this->showCreate = false;
        unset($this->councils, $this->stats);
        $this->dispatch('close-modal', name: 'create-council');
        $this->successMessage = __('mtschool::councils.created');
    }

    // ── Cycle de vie ──────────────────────────────────────────────────────

    public function openManage(int $id): void
    {
        $council = ClassCouncil::findOrFail($id);
        $this->managedId = $council->id;
        $this->minutes   = (string) ($council->minutes_content ?? '');
        $this->newParticipantId = null;
        $this->newParticipantRole = 'member';
        $this->dispatch('open-manage-council');
    }

    public function markHeld(): void
    {
        abort_unless($this->canManage() && $this->managed, 403);
        abort_unless($this->managed->status === 'planned', 403);

        $this->managed->update(['status' => 'held']);
        unset($this->managed, $this->councils, $this->stats);
    }

    public function saveMinutes(): void
    {
        abort_unless($this->canManage() && $this->managed, 403);
        abort_unless($this->managed->isHeld() && ! $this->managed->isValidated(), 403);

        $this->validate(['minutes' => 'required|string|max:20000']);

        $locale  = app()->getLocale();
        $current = $this->managed->getRawOriginal('minutes_content');
        $content = is_string($current) ? (json_decode($current, true) ?: []) : [];
        $content[$locale] = $this->minutes;

        $this->managed->update([
            'minutes_content' => $content,
            'status'          => 'minutes_drafted',
        ]);
        unset($this->managed, $this->councils, $this->stats);
        $this->successMessage = __('mtschool::councils.minutes_saved');
    }

    public function validateCouncil(): void
    {
        abort_unless($this->canManage() && $this->managed, 403);
        abort_unless($this->managed->status === 'minutes_drafted', 403);

        $this->managed->validate((int) Auth::id());
        unset($this->managed, $this->councils, $this->stats);
        $this->successMessage = __('mtschool::councils.validated_msg');
    }

    public function deleteCouncil(int $id): void
    {
        abort_unless($this->canManage(), 403);

        $council = ClassCouncil::findOrFail($id);
        abort_if($council->isValidated(), 403);

        $council->participants()->delete();
        $council->delete();
        if ($this->managedId === $id) {
            $this->managedId = null;
        }
        unset($this->councils, $this->stats);
        $this->successMessage = __('mtschool::councils.deleted');
    }

    // ── Participants ──────────────────────────────────────────────────────

    public function addParticipant(): void
    {
        abort_unless($this->canManage() && $this->managed && ! $this->managed->isValidated(), 403);

        $this->validate([
            'newParticipantId'   => 'required|integer',
            'newParticipantRole' => 'required|in:president,secretary,member',
        ]);

        $user = User::query()->where('school_id', currentSchoolId())->findOrFail($this->newParticipantId);

        CouncilParticipant::query()->updateOrCreate(
            ['class_council_id' => $this->managed->id, 'user_id' => $user->id],
            ['council_role' => $this->newParticipantRole, 'present' => true],
        );

        if ($this->newParticipantRole === 'president') {
            $this->managed->update(['president_id' => $user->id]);
        }

        $this->newParticipantId = null;
        $this->newParticipantRole = 'member';
        unset($this->managed, $this->councils, $this->participantNames);
    }

    public function toggleParticipant(int $participantId, string $field): void
    {
        abort_unless($this->canManage() && $this->managed && ! $this->managed->isValidated(), 403);
        abort_unless(in_array($field, ['present', 'has_signed'], true), 403);

        $p = $this->managed->participants()->findOrFail($participantId);
        $p->update([$field => ! $p->{$field}]);
        unset($this->managed);
    }

    public function removeParticipant(int $participantId): void
    {
        abort_unless($this->canManage() && $this->managed && ! $this->managed->isValidated(), 403);

        $p = $this->managed->participants()->findOrFail($participantId);
        if ($this->managed->president_id === $p->user_id) {
            $this->managed->update(['president_id' => null]);
        }
        $p->delete();
        unset($this->managed, $this->councils, $this->participantNames);
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('class_councils', __('mtschool::councils.title'))) {
            return $gate;
        }

        return view('mtschool::livewire.admin.councils.manager')
            ->title(__('mtschool::councils.title'));
    }
}
