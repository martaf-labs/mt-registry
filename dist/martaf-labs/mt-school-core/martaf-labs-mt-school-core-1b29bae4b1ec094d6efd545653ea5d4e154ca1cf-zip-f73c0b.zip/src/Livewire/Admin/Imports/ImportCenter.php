<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Imports;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\ImportLog;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\SchoolFee;
use Mt\MtSchoolCore\Models\StaffMember;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * Centre d'import / export (module `imports`). Exports CSV natifs (élèves, résultats,
 * frais) et import d'élèves depuis un CSV avec aperçu validé avant création.
 * Toutes les données sont cloisonnées par école (modèles school-scopés).
 */
#[Layout('mt::components.layouts.app')]
class ImportCenter extends Component
{
    use WithFileUploads;

    public $file = null;
    public $staffFile = null;

    /** Aperçu analysé du CSV : lignes avec statut de validation. */
    public array $preview = [];
    public bool $parsed = false;
    public string $successMessage = '';

    /**
     * En-têtes attendus pour l'import d'élèves. matricule + lieu_naissance facultatifs ;
     * les colonnes tuteur_* sont facultatives (élève sans tuteur = colonnes vides) → le
     * tuteur est créé/réutilisé et LIÉ à l'élève dans la même passe.
     */
    public const COLUMNS = [
        'matricule', 'nom', 'prenom', 'genre', 'naissance', 'lieu_naissance', 'classe',
        'tuteur_nom', 'tuteur_telephone', 'tuteur_email', 'tuteur_lien',
    ];

    /** En-têtes attendus pour l'import du personnel. fonction = enseignant → crée aussi un Teacher. */
    public const STAFF_COLUMNS = ['nom', 'prenom', 'genre', 'email', 'telephone', 'fonction'];

    /** En-têtes import matières (code unique par école). */
    public const SUBJECT_COLUMNS = ['code', 'nom', 'abreviation', 'groupe'];

    /** En-têtes import affectations (prof matché par e-mail, classe/matière par code). */
    public const ASSIGN_COLUMNS = ['enseignant_email', 'classe', 'matiere', 'heures', 'coefficient'];

    public $subjectFile = null;
    public $assignFile = null;

    /** Classes de l'école (pour rattacher les élèves importés + gabarit). */
    #[Computed]
    public function classes()
    {
        return Classroom::orderBy('code')->get(['id', 'code', 'label']);
    }

    /** Historique des derniers imports (journal d'audit). */
    #[Computed]
    public function recentImports()
    {
        return ImportLog::with('user')->orderByDesc('id')->limit(15)->get();
    }

    /** Trace un import / provisioning dans le journal d'audit. */
    protected function logImport(string $type, array $counts, ?string $filename = null): void
    {
        ImportLog::create([
            'user_id'  => auth()->id(),
            'type'     => $type,
            'filename' => $filename,
            'total'    => $counts['total'] ?? (($counts['imported'] ?? 0) + ($counts['skipped'] ?? 0)),
            'imported' => $counts['imported'] ?? 0,
            'skipped'  => $counts['skipped'] ?? 0,
            'details'  => $counts,
        ]);
        unset($this->recentImports);
    }

    // ─────────────────────────── EXPORTS ───────────────────────────

    public function exportStudents()
    {
        $rows = Student::with(['enrollments' => fn ($q) => $q->latest('id')->limit(1)])->orderBy('last_name')->get();
        $classes = Classroom::get(['id', 'code'])->keyBy('id');

        return $this->streamCsv('eleves.csv', ['Référence', 'Nom', 'Prénom', 'Genre', 'Naissance', 'Classe'],
            $rows->map(function ($s) use ($classes) {
                $enr = $s->enrollments->first();
                return [
                    $s->reference, $s->last_name, $s->first_name, $s->gender,
                    optional($s->birth_date)->format('Y-m-d'),
                    $enr ? ($classes[$enr->class_id]->code ?? '') : '',
                ];
            }));
    }

    public function exportResults()
    {
        $rows = PeriodAverage::with(['enrollment.student', 'period'])->orderByDesc('overall_average')->get();

        return $this->streamCsv('resultats.csv', ['Élève', 'Période', 'Moyenne', 'Rang', 'Mention'],
            $rows->map(fn ($a) => [
                $a->enrollment?->student?->last_name . ' ' . $a->enrollment?->student?->first_name,
                $a->period?->label,
                number_format((float) $a->overall_average, 2, '.', ''),
                $a->rank,
                $a->mention?->label(),
            ]));
    }

    public function exportFees()
    {
        $rows = SchoolFee::with('enrollment.student')->get();

        return $this->streamCsv('frais.csv', ['Élève', 'Facturé', 'Payé', 'Reste', 'Statut'],
            $rows->map(fn ($f) => [
                $f->enrollment?->student?->last_name . ' ' . $f->enrollment?->student?->first_name,
                (string) $f->net_amount, (string) $f->amount_paid, (string) $f->remaining_amount,
                $f->status?->value,
            ]));
    }

    protected function streamCsv(string $filename, array $header, $rows)
    {
        return response()->streamDownload(function () use ($header, $rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // BOM UTF-8 (Excel)
            fputcsv($out, $header, ';');
            foreach ($rows as $r) {
                fputcsv($out, $r, ';');
            }
            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    // ─────────────────────── ACCÈS PORTAIL ─────────────────────────

    /** Génère EN MASSE les accès parents (tuteurs sans compte) + exporte les identifiants. */
    public function provisionParents()
    {
        $result = app(\Mt\MtSchoolCore\Services\PortalAccountService::class)->bulkProvisionGuardians();

        if (empty($result['credentials'])) {
            $this->successMessage = __('mtschool::imports.parents_none');
            return;
        }

        $this->logImport('access_parents', ['imported' => count($result['credentials']), 'skipped' => $result['skipped']]);

        return $this->streamCsv(
            'acces-parents.csv',
            [__('mtschool::imports.col_guardian'), __('mtschool::imports.access_login'), __('mtschool::imports.access_password')],
            collect($result['credentials'])->map(fn ($c) => [$c['guardian'], $c['login'], $c['password']]),
        );
    }

    /** Génère EN MASSE les accès élèves (sans compte) + exporte les identifiants. */
    public function provisionStudents()
    {
        $result = app(\Mt\MtSchoolCore\Services\PortalAccountService::class)->bulkProvisionStudents();

        if (empty($result['credentials'])) {
            $this->successMessage = __('mtschool::imports.students_none');
            return;
        }

        $this->logImport('access_students', ['imported' => count($result['credentials']), 'skipped' => $result['skipped']]);

        return $this->streamCsv(
            'acces-eleves.csv',
            [__('mtschool::imports.col_lastname'), __('mtschool::imports.access_login'), __('mtschool::imports.access_password')],
            collect($result['credentials'])->map(fn ($c) => [$c['student'], $c['login'], $c['password']]),
        );
    }

    // ─────────────────────────── IMPORT ───────────────────────────

    /** Gabarit d'import élèves prêt à remplir : en-têtes exacts + 1 ligne d'exemple. */
    public function downloadTemplate()
    {
        $mlFields = ['nom', 'prenom', 'tuteur_nom'];
        $header   = $this->templateHeader(self::COLUMNS, $mlFields);
        $example  = $this->exampleRow(self::COLUMNS, $mlFields, [
            'matricule' => '', 'nom' => 'DUPONT', 'prenom' => 'Marie', 'genre' => 'F',
            'naissance' => '2015-09-01', 'lieu_naissance' => 'Yaoundé',
            'classe' => $this->classes->first()?->code ?: 'CP-A',
            'tuteur_nom' => 'DUPONT Paul', 'tuteur_telephone' => '690000000',
            'tuteur_email' => 'paul.dupont@email.com', 'tuteur_lien' => 'père',
        ]);

        return $this->streamCsv('modele-import-eleves.csv', $header, [$example]);
    }

    public function parse(): void
    {
        $this->validate(['file' => 'required|file|mimes:csv,txt|max:5120']);

        $classesByCode = $this->classes->keyBy(fn ($c) => mb_strtolower($c->code));
        $rows = array_map('str_getcsv', file($this->file->getRealPath(), FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));

        // Détecte le séparateur (; ou ,) sur la 1re ligne.
        if (count($rows) && count($rows[0]) === 1 && str_contains($rows[0][0], ';')) {
            $rows = array_map(fn ($l) => str_getcsv($l[0], ';'), $rows);
        }

        $header = array_map(fn ($h) => mb_strtolower(trim((string) $h)), array_shift($rows) ?? []);
        $preview = [];

        foreach ($rows as $i => $cols) {
            // Champs traduisibles (colonnes par langue nom_<lang> ou colonne unique nom).
            $nom       = $this->mlValue($header, $cols, 'nom');
            $prenom    = $this->mlValue($header, $cols, 'prenom');
            $tuteurNom = $this->mlValue($header, $cols, 'tuteur_nom');
            // Champs non traduisibles.
            $data = $this->rowData($header, $cols, [
                'matricule', 'genre', 'naissance', 'lieu_naissance', 'classe',
                'tuteur_telephone', 'tuteur_email', 'tuteur_lien',
            ]);

            $errors = [];
            if (empty($nom)) { $errors[] = __('mtschool::imports.err_lastname'); }
            // Prénom facultatif (noms complets). Genre facultatif mais valide s'il est fourni.
            $gender = mb_strtoupper($data['genre']);
            if ($gender !== '' && ! in_array($gender, ['M', 'F'], true)) { $errors[] = __('mtschool::imports.err_gender'); }
            $date = null;
            if ($data['naissance'] !== '') {
                try { $date = Carbon::parse($data['naissance'])->format('Y-m-d'); }
                catch (\Throwable) { $errors[] = __('mtschool::imports.err_date'); }
            }
            $class = $classesByCode->get(mb_strtolower($data['classe']));
            if (! $class) { $errors[] = __('mtschool::imports.err_class'); }

            $preview[] = [
                'line'          => $i + 2,
                'matricule'     => $data['matricule'],           // facultatif
                // Clés d'AFFICHAGE (aperçu) + clés _ml portées vers l'import.
                'nom'           => $this->mlDisplay($nom),
                'prenom'        => $this->mlDisplay($prenom),
                'nom_ml'        => $nom,
                'prenom_ml'     => $prenom,
                'genre'         => $gender,
                'naissance'     => $date,
                'lieu'          => $data['lieu_naissance'],       // facultatif
                'classe'        => $data['classe'],
                'class_id'      => $class?->id,
                'tuteur_nom'    => $this->mlDisplay($tuteurNom),  // facultatifs (tuteur lié en 1 passe)
                'tuteur_nom_ml' => $tuteurNom,
                'tuteur_tel'    => $data['tuteur_telephone'],
                'tuteur_email'  => $data['tuteur_email'],
                'tuteur_lien'   => $data['tuteur_lien'],
                'valid'         => empty($errors),
                'errors'        => $errors,
            ];
        }

        $this->preview = $preview;
        $this->parsed = true;
    }

    public function import(): void
    {
        $valid   = array_filter($this->preview, fn ($r) => $r['valid']);
        $invalid = count($this->preview) - count($valid);

        if (empty($valid)) {
            $this->successMessage = __('mtschool::imports.no_valid_rows');
            return;
        }

        $primary    = $this->primaryLang();
        $imported   = 0;
        $duplicates = 0;
        $linked     = 0;
        $touched    = [];

        DB::transaction(function () use ($valid, $primary, &$imported, &$duplicates, &$linked, &$touched) {
            foreach ($valid as $r) {
                // Dédoublonnage : par MATRICULE s'il est fourni (clé autoritative, gère les
                // homonymes), sinon par nom (langue principale) + naissance. Évite les doublons.
                $matricule = trim((string) ($r['matricule'] ?? ''));
                $student = $matricule !== ''
                    ? Student::where('reference', $matricule)->first()
                    : Student::where("last_name->{$primary}", $r['nom'])
                        ->where('birth_date', $r['naissance'])
                        ->first();

                if (! $student) {
                    $student = Student::create([
                        // matricule fourni ⇒ on le respecte ; sinon HasReference génère STU-...
                        'reference'   => $matricule !== '' ? $matricule : null,
                        'last_name'   => $r['nom_ml'],                                    // JSON {lang=>nom}
                        'first_name'  => empty($r['prenom_ml']) ? $this->emptyName() : $r['prenom_ml'],
                        'gender'      => $r['genre'] ?: null,                             // facultatif
                        'birth_date'  => $r['naissance'],
                        'birth_place' => $r['lieu'] ?: null,
                        'active'      => true,
                    ]);
                }

                // Inscription unique par (élève, année) → évite le doublon au ré-import.
                $enrollment = Enrollment::firstOrCreate(
                    ['student_id' => $student->id, 'school_year_id' => activeSchoolYearId()],
                    [
                        'reference'       => null,
                        'class_id'        => $r['class_id'],
                        'status'          => 'validated',
                        'enrollment_date' => now()->toDateString(),
                        'validation_date' => now()->toDateString(),
                    ]
                );

                if ($enrollment->wasRecentlyCreated) {
                    $imported++;
                    $touched[$r['class_id']] = true;
                } else {
                    $duplicates++;
                }

                // Tuteur (facultatif) : créé/réutilisé puis LIÉ à l'élève, en une passe.
                $gName  = trim((string) ($r['tuteur_nom'] ?? ''));
                $gPhone = trim((string) ($r['tuteur_tel'] ?? ''));
                $gEmail = trim((string) ($r['tuteur_email'] ?? ''));

                if ($gName !== '' || $gPhone !== '' || $gEmail !== '') {
                    // Dédup tuteur : téléphone → e-mail → nom (école-scopé). Réutilise sinon crée.
                    $guardian = null;
                    if ($gPhone !== '') {
                        $guardian = Guardian::where('phone', $gPhone)->first();
                    }
                    if (! $guardian && $gEmail !== '') {
                        $guardian = Guardian::where('email', $gEmail)->first();
                    }
                    if (! $guardian && $gName !== '') {
                        $guardian = Guardian::where("last_name->{$primary}", $gName)->first();
                    }
                    if (! $guardian) {
                        // Nom du tuteur traduisible s'il vient de colonnes par langue.
                        $gLast = ! empty($r['tuteur_nom_ml']) ? $r['tuteur_nom_ml'] : [$primary => $gName !== '' ? $gName : '—'];
                        $guardian = Guardian::create([
                            'last_name'  => $gLast,
                            'first_name' => $this->emptyName(),
                            'phone'      => $gPhone ?: null,
                            'email'      => $gEmail ?: null,
                            'active'     => true,
                        ]);
                    }

                    // Lien élève↔tuteur (idempotent : unique(student_id, guardian_id)).
                    if (! $student->guardians()->where('guardians.id', $guardian->id)->exists()) {
                        $student->guardians()->attach($guardian->id, [
                            'relationship'       => trim((string) ($r['tuteur_lien'] ?? '')) ?: 'guardian',
                            'is_primary_contact' => true,
                            'portal_access'      => true,
                        ]);
                        $linked++;
                    }
                }
            }

            // Recalcule les effectifs des classes impactées (sinon compteurs faux).
            Classroom::whereIn('id', array_keys($touched))->get()
                ->each(fn ($c) => $c->recalculateEnrollment());
        });

        $this->logImport('students', [
            'imported'   => $imported,
            'skipped'    => $duplicates + $invalid,
            'total'      => count($this->preview),
            'duplicates' => $duplicates,
            'invalid'    => $invalid,
            'guardians'  => $linked,
        ]);

        $this->reset(['file', 'preview', 'parsed']);
        $this->successMessage = __('mtschool::imports.import_report', [
            'imported'   => $imported,
            'duplicates' => $duplicates,
            'invalid'    => $invalid,
            'guardians'  => $linked,
        ]);
    }

    /** Exporte les lignes REJETÉES de l'aperçu (avec le motif) → correction hors ligne. */
    public function downloadErrors()
    {
        $invalid = array_filter($this->preview, fn ($r) => ! $r['valid']);

        if (empty($invalid)) {
            $this->successMessage = __('mtschool::imports.no_errors');
            return;
        }

        return $this->streamCsv(
            'erreurs-import.csv',
            [
                __('mtschool::imports.col_line'), __('mtschool::imports.col_matricule'),
                __('mtschool::imports.col_lastname'), __('mtschool::imports.col_firstname'),
                __('mtschool::imports.col_class'), __('mtschool::imports.col_errors'),
            ],
            collect($invalid)->map(fn ($r) => [
                $r['line'], $r['matricule'], $r['nom'], $r['prenom'], $r['classe'], implode(' | ', $r['errors']),
            ]),
        );
    }

    public function cancelImport(): void
    {
        $this->reset(['file', 'preview', 'parsed']);
    }

    // ─────────────────────────── PERSONNEL ─────────────────────────

    /** Gabarit d'import du personnel : en-têtes + 1 ligne d'exemple. */
    public function downloadStaffTemplate()
    {
        $header  = $this->templateHeader(self::STAFF_COLUMNS, ['nom', 'prenom']);
        $example = $this->exampleRow(self::STAFF_COLUMNS, ['nom', 'prenom'], [
            'nom' => 'NGONO', 'prenom' => 'Alice', 'genre' => 'F',
            'email' => 'alice@ecole.test', 'telephone' => '690000001', 'fonction' => 'Enseignant',
        ]);

        return $this->streamCsv('modele-import-personnel.csv', $header, [$example]);
    }

    /**
     * Import du personnel (upload → validation + création directe, rapport par lot).
     * Une « fonction » enseignant/prof/teacher crée aussi l'enregistrement Teacher lié.
     * Dédup par e-mail sinon nom+prénom (école-scopé). Idempotent.
     */
    public function importStaff(): void
    {
        $this->validate(['staffFile' => 'required|file|mimes:csv,txt|max:2048']);

        [$header, $rows] = $this->readCsvRows($this->staffFile);
        $primary = $this->primaryLang();

        $imported = 0;
        $teachers = 0;
        $skipped  = 0;

        DB::transaction(function () use ($rows, $header, $primary, &$imported, &$teachers, &$skipped) {
            foreach ($rows as $cols) {
                $last  = $this->mlValue($header, $cols, 'nom');    // traduisible
                $first = $this->mlValue($header, $cols, 'prenom'); // facultatif
                $d     = $this->rowData($header, $cols, ['genre', 'email', 'telephone', 'fonction']);

                $gender = mb_strtoupper($d['genre']);
                // Nom requis ; genre facultatif mais valide s'il est fourni ; prénom facultatif.
                if (empty($last) || ($gender !== '' && ! in_array($gender, ['M', 'F'], true))) {
                    $skipped++;
                    continue;
                }

                // Dédup : e-mail sinon nom (langue principale).
                $staff = $d['email'] !== '' ? StaffMember::where('email', $d['email'])->first() : null;
                if (! $staff) {
                    $staff = StaffMember::where("last_name->{$primary}", $this->mlDisplay($last))->first();
                }

                // La « fonction » libre est mappée vers un StaffType valide (enum) ;
                // l'intitulé exact est conservé dans metadata.
                $isTeacher = (bool) preg_match('/enseign|prof|teacher/i', $d['fonction']);
                $type = match (true) {
                    $isTeacher                                                            => 'teacher',
                    (bool) preg_match('/direct|proviseur|censeur|manage/i', $d['fonction']) => 'management',
                    (bool) preg_match('/techn|maintenance|informat/i', $d['fonction'])      => 'technical',
                    default                                                               => 'administrative',
                };

                if (! $staff) {
                    $staff = StaffMember::create([
                        'reference'  => null,
                        'last_name'  => $last,
                        'first_name' => empty($first) ? $this->emptyName() : $first,
                        'gender'     => $gender ?: null,
                        'email'      => $d['email'] ?: null,
                        'phone'      => $d['telephone'] ?: null,
                        'type'       => $type,
                        'metadata'   => $d['fonction'] !== '' ? ['fonction' => $d['fonction']] : null,
                        'active'     => true,
                    ]);
                    $imported++;
                }

                // Rôle enseignant → enregistrement Teacher lié (idempotent).
                if ($isTeacher && ! $staff->teacher) {
                    Teacher::create(['staff_id' => $staff->id]);
                    $teachers++;
                }
            }
        });

        $this->logImport('staff', ['imported' => $imported, 'skipped' => $skipped, 'teachers' => $teachers]);

        $this->reset(['staffFile']);
        $this->successMessage = __('mtschool::imports.staff_report', [
            'imported' => $imported,
            'teachers' => $teachers,
            'skipped'  => $skipped,
        ]);
    }

    // ───────────────────── STRUCTURE (matières / affectations) ──────────────────

    /** Lit un CSV uploadé → [en-têtes normalisés, lignes]. Gère BOM + séparateur ; / , */
    protected function readCsvRows($file): array
    {
        $rows = array_map('str_getcsv', file($file->getRealPath(), FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
        if (count($rows) && count($rows[0]) === 1 && str_contains($rows[0][0], ';')) {
            $rows = array_map(fn ($l) => str_getcsv($l[0], ';'), $rows);
        }
        $header = array_map(fn ($h) => mb_strtolower(trim((string) $h)), array_shift($rows) ?? []);
        return [$header, $rows];
    }

    /** Extrait les colonnes attendues d'une ligne (par nom d'en-tête). */
    protected function rowData(array $header, array $cols, array $columns): array
    {
        $d = [];
        foreach ($columns as $col) {
            $idx     = array_search($col, $header, true);
            $d[$col] = $idx !== false ? trim((string) ($cols[$idx] ?? '')) : '';
        }
        return $d;
    }

    // ─────────────────────── MULTILINGUE (import language-aware) ───────────────────────
    // L'import respecte les LANGUES DE L'ÉCOLE (setting teaching_languages) : les champs
    // traduisibles (noms, libellés) acceptent des colonnes par langue `{base}_{lang}`
    // (ex. nom_ar/nom_fr/nom_en) ; à défaut, la colonne unique `{base}` est rangée dans
    // la langue PRINCIPALE de l'école (jamais 'fr' en dur). Rétro-compatible.

    /** Langues de l'école (ordre = principale d'abord). */
    protected function langs(): array
    {
        return school_languages();
    }

    /** Langue principale de l'école (destination d'une colonne unique). */
    protected function primaryLang(): string
    {
        return school_primary_language();
    }

    /**
     * Valeur TRADUISIBLE d'un champ depuis une ligne CSV. Renvoie {lang => valeur}
     * (seulement les langues renseignées). Colonnes par langue prioritaires, sinon
     * la colonne unique va dans la langue principale.
     */
    protected function mlValue(array $header, array $cols, string $base): array
    {
        $out = [];
        foreach ($this->langs() as $l) {
            $idx = array_search("{$base}_{$l}", $header, true);
            if ($idx !== false) {
                $v = trim((string) ($cols[$idx] ?? ''));
                if ($v !== '') {
                    $out[$l] = $v;
                }
            }
        }
        if (empty($out)) {
            $idx = array_search($base, $header, true);
            if ($idx !== false) {
                $v = trim((string) ($cols[$idx] ?? ''));
                if ($v !== '') {
                    $out[$this->primaryLang()] = $v;
                }
            }
        }
        return $out;
    }

    /** Représentation lisible d'un champ ml (langue principale sinon 1re dispo). */
    protected function mlDisplay(array $ml): string
    {
        if (empty($ml)) {
            return '';
        }
        return $ml[$this->primaryLang()] ?? (string) reset($ml);
    }

    /** first_name JSON valide même vide (colonne NOT NULL) : prénom facultatif. */
    protected function emptyName(): array
    {
        return [$this->primaryLang() => ''];
    }

    /** En-têtes de gabarit : les champs ml deviennent des colonnes par langue. */
    protected function templateHeader(array $columns, array $mlFields): array
    {
        $out = [];
        foreach ($columns as $c) {
            if (in_array($c, $mlFields, true)) {
                foreach ($this->langs() as $l) {
                    $out[] = "{$c}_{$l}";
                }
            } else {
                $out[] = $c;
            }
        }
        return $out;
    }

    /** Ligne d'exemple d'un gabarit (les champs ml répètent l'exemple par langue). */
    protected function exampleRow(array $columns, array $mlFields, array $values): array
    {
        $row = [];
        foreach ($columns as $c) {
            if (in_array($c, $mlFields, true)) {
                foreach ($this->langs() as $l) {
                    $row[] = $values["{$c}_{$l}"] ?? $values[$c] ?? '';
                }
            } else {
                $row[] = $values[$c] ?? '';
            }
        }
        return $row;
    }

    public function downloadSubjectTemplate()
    {
        // En-têtes adaptés aux langues de l'école : nom → nom_<lang> par langue.
        $header  = $this->templateHeader(self::SUBJECT_COLUMNS, ['nom']);
        $example = $this->exampleRow(self::SUBJECT_COLUMNS, ['nom'], [
            'code' => 'MATH', 'nom' => 'Mathématiques', 'abreviation' => 'Math', 'groupe' => 'Sciences',
        ]);

        return $this->streamCsv('modele-import-matieres.csv', $header, [$example]);
    }

    /** Mappe un « groupe » libre vers un SubjectGroup valide (enum). Vide → 'other'
     *  (la colonne subjects.group est NOT NULL ; un import sans groupe ne doit pas casser). */
    protected function mapSubjectGroup(string $group): string
    {
        $g = mb_strtolower(trim($group));
        if ($g === '') {
            return 'other';
        }
        return match (true) {
            str_contains($g, 'litt') || str_contains($g, 'liter')  => 'literary',
            str_contains($g, 'scien')                              => 'scientific',
            str_contains($g, 'techn')                              => 'technical',
            str_contains($g, 'phys') || str_contains($g, 'sport')  => 'physical',
            str_contains($g, 'art')                                => 'artistic',
            str_contains($g, 'lang')                               => 'language',
            default                                                => 'other',
        };
    }

    /** Import des matières (code unique par école, dédup par code). Direct + rapport. */
    public function importSubjects(): void
    {
        $this->validate(['subjectFile' => 'required|file|mimes:csv,txt|max:2048']);

        [$header, $rows] = $this->readCsvRows($this->subjectFile);
        $imported = 0;
        $skipped  = 0;

        DB::transaction(function () use ($rows, $header, &$imported, &$skipped) {
            foreach ($rows as $cols) {
                $d     = $this->rowData($header, $cols, ['code', 'abreviation', 'groupe']);
                $label = $this->mlValue($header, $cols, 'nom'); // libellé traduisible (nom_<lang> ou nom)
                if ($d['code'] === '' || empty($label)) {
                    $skipped++;
                    continue;
                }

                if (Subject::where('code', $d['code'])->exists()) {
                    $skipped++;
                    continue;
                }

                Subject::create([
                    'code'         => $d['code'],
                    'label'        => $label,
                    'abbreviation' => $d['abreviation'] ?: null,
                    'group'        => $this->mapSubjectGroup($d['groupe']), // enum SubjectGroup
                    'color'        => '#3B82F6', // NOT NULL sans défaut → couleur par défaut
                    'active'       => true,
                ]);
                $imported++;
            }
        });

        $this->logImport('subjects', ['imported' => $imported, 'skipped' => $skipped]);

        $this->reset(['subjectFile']);
        $this->successMessage = __('mtschool::imports.subjects_report', ['imported' => $imported, 'skipped' => $skipped]);
    }

    public function downloadAssignTemplate()
    {
        return $this->streamCsv('modele-import-affectations.csv', self::ASSIGN_COLUMNS,
            [['prof@ecole.test', $this->classes->first()?->code ?: 'CE1-A', 'MATH', '4', '2']]);
    }

    /**
     * Import des affectations (enseignant → classe → matière) pour l'année active.
     * Enseignant matché par l'e-mail de son StaffMember, classe/matière par code. Idempotent.
     */
    public function importAssignments(): void
    {
        $this->validate(['assignFile' => 'required|file|mimes:csv,txt|max:2048']);

        $year = activeSchoolYearId();
        [$header, $rows] = $this->readCsvRows($this->assignFile);
        $classesByCode  = Classroom::get()->keyBy(fn ($c) => mb_strtolower($c->code));
        $subjectsByCode = Subject::get()->keyBy(fn ($s) => mb_strtolower($s->code));
        $imported = 0;
        $skipped  = 0;

        DB::transaction(function () use ($rows, $header, $year, $classesByCode, $subjectsByCode, &$imported, &$skipped) {
            foreach ($rows as $cols) {
                $d = $this->rowData($header, $cols, self::ASSIGN_COLUMNS);

                $staff   = $d['enseignant_email'] !== '' ? StaffMember::where('email', $d['enseignant_email'])->first() : null;
                $teacher = $staff?->teacher;
                $class   = $classesByCode->get(mb_strtolower($d['classe']));
                $subject = $subjectsByCode->get(mb_strtolower($d['matiere']));

                if (! $teacher || ! $class || ! $subject) {
                    $skipped++;
                    continue;
                }

                $ca = CourseAssignment::firstOrCreate(
                    ['school_year_id' => $year, 'teacher_id' => $teacher->id, 'class_id' => $class->id, 'subject_id' => $subject->id],
                    ['weekly_hours' => $d['heures'] ?: null, 'coefficient' => $d['coefficient'] ?: 1, 'active' => true],
                );

                $ca->wasRecentlyCreated ? $imported++ : $skipped++;
            }
        });

        $this->logImport('assignments', ['imported' => $imported, 'skipped' => $skipped]);

        $this->reset(['assignFile']);
        $this->successMessage = __('mtschool::imports.assign_report', ['imported' => $imported, 'skipped' => $skipped]);
    }

    public function render()
    {
        return view('mtschool::livewire.admin.imports.center')
            ->title(__('mtschool::imports.title'));
    }
}
