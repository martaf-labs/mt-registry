<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Timetable;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Room;
use Mt\MtSchoolCore\Models\TimeSlot;
use Mt\MtSchoolCore\Models\Timetable;

/**
 * Emploi du temps d'une classe : grille jours × créneaux. Chaque case place un cours
 * issu des AFFECTATIONS de la classe (CourseAssignment → matière + enseignant) dans un TimeSlot.
 */
#[Layout('mt::components.layouts.app')]
class TimetableGridManager extends Component
{
    use \Mt\MtSchoolCore\Livewire\Concerns\ChecksPrerequisites;

    public const PERIODS = [
        ['08:00', '08:55'], ['09:00', '09:55'], ['10:10', '11:05'], ['11:10', '12:05'],
        ['14:00', '14:55'], ['15:00', '15:55'], ['16:10', '17:05'],
    ];

    /** Clés internes (non traduites) de TOUS les jours ISO — cf. {@see translatedDays()}. */
    public const DAYS = [1 => 'day_1', 2 => 'day_2', 3 => 'day_3', 4 => 'day_4', 5 => 'day_5', 6 => 'day_6', 7 => 'day_7'];

    /** Jours ouvrés de l'école (config, défaut Lun–Ven ; ex. + samedi = [1..6]). */
    public static function activeDays(): array
    {
        $days = config('mt-school-core.timetable.active_days', [1, 2, 3, 4, 5]);
        return array_values(array_filter((array) $days, fn ($d) => isset(self::DAYS[$d])));
    }

    /** Libellés des jours ACTIFS traduits dans la locale courante. */
    public static function translatedDays(): array
    {
        $out = [];
        foreach (self::activeDays() as $day) {
            $out[$day] = __('mtschool::timetable.' . self::DAYS[$day]);
        }
        return $out;
    }

    public ?int $classId = null;
    public ?int $timetableId = null;

    /** Cases occupées, clés "{jour}_{HH:MM}". */
    public array $slots = [];

    // Modale d'affectation de case
    public bool $showCell = false;
    public ?int $cellDay = null;
    public ?string $cellStart = null;
    public ?string $cellEnd = null;
    public string $cellLabel = '';
    public $cellAssignmentId = null;
    public $cellRoomId = null;

    public string $successMessage = '';
    public string $conflictMessage = '';

    public function mount(): void
    {
        $this->classId = Classroom::where('active', true)->orderBy('code')->value('id');
        $this->loadTimetable();
    }

    #[Computed]
    public function classes(): array
    {
        return Classroom::where('active', true)->orderBy('code')->get()
            ->mapWithKeys(fn ($c) => [$c->id => $c->label])->toArray();
    }

    public function updatedClassId(): void
    {
        $this->loadTimetable();
    }

    protected function loadTimetable(): void
    {
        $this->slots = [];
        if (! $this->classId) {
            return;
        }

        $timetable = Timetable::firstOrCreate(
            ['class_id' => $this->classId, 'school_year_id' => activeSchoolYearId()],
            // status ∈ {draft|published|archived} : l'EDT de la grille est l'emploi du temps
            // opérationnel (affiché aux élèves) → 'published' (et non 'active', hors vocabulaire,
            // que scopePublished() ne voyait jamais).
            ['label' => [config('mt-school-core.multilingual.default', 'fr') => __('mtschool::timetable.title')], 'code' => 'EDT-' . $this->classId, 'is_active' => true, 'status' => 'published']
        );
        $this->timetableId = $timetable->id;

        foreach ($timetable->timeSlots()->with(['subject', 'teacher.staff', 'room'])->get() as $s) {
            $key = $s->day_of_week->value . '_' . substr((string) $s->start_time, 0, 5);
            $this->slots[$key] = [
                'id'            => $s->id,
                'subject'       => $s->subject?->abbreviation ?: $s->subject?->code,
                'teacher'       => $s->teacher?->staff?->last_name,
                'room'          => $s->room?->code,
                'assignment_id' => $s->course_assignment_id,
                'room_id'       => $s->room_id,
            ];
        }
    }

    #[Computed]
    public function assignments(): array
    {
        if (! $this->classId) {
            return [];
        }
        return CourseAssignment::where('class_id', $this->classId)->where('active', true)
            ->with(['subject', 'teacher.staff'])->get()
            ->mapWithKeys(fn ($a) => [
                $a->id => ($a->subject?->code ?? '?') . ' — ' . ($a->teacher?->staff?->last_name ?? __('mtschool::timetable.no_teacher')),
            ])->toArray();
    }

    #[Computed]
    public function rooms(): array
    {
        return Room::where('active', true)->orderBy('code')->pluck('code', 'id')->toArray();
    }

    public function openCell(int $day, string $start, string $end): void
    {
        $this->cellDay   = $day;
        $this->cellStart = $start;
        $this->cellEnd   = $end;
        $this->cellLabel = (self::translatedDays()[$day] ?? '') . ' · ' . $start . '–' . $end;

        $existing = $this->slots["{$day}_{$start}"] ?? null;
        $this->cellAssignmentId = $existing['assignment_id'] ?? null;
        $this->cellRoomId       = $existing['room_id'] ?? null;
        $this->conflictMessage  = '';

        $this->showCell = true;
        $this->dispatch('open-cell-modal');
    }

    public function saveCell(): void
    {
        if (! $this->timetableId || ! $this->cellDay) {
            return;
        }

        $base = [
            'timetable_id' => $this->timetableId,
            'day_of_week'  => $this->cellDay,
            'start_time'   => $this->cellStart,
        ];

        if (empty($this->cellAssignmentId)) {
            TimeSlot::where($base)->delete();
        } else {
            $ca = CourseAssignment::find($this->cellAssignmentId);

            // Détection de collision : même prof / même salle déjà placé(e) sur ce
            // créneau dans une AUTRE classe (même année). Bloque l'enregistrement.
            $conflict = $this->findConflict((int) $this->cellDay, (string) $this->cellStart, $ca?->teacher_id, $this->cellRoomId ?: null);
            if ($conflict) {
                $this->conflictMessage = __('mtschool::timetable.conflict_' . $conflict['type'], ['class' => $conflict['class']]);
                return; // garde la modale ouverte, n'écrase rien
            }

            TimeSlot::updateOrCreate($base, [
                'end_time'             => $this->cellEnd,
                'course_assignment_id' => $ca?->id,
                'subject_id'           => $ca?->subject_id,
                'teacher_id'           => $ca?->teacher_id,
                'room_id'              => $this->cellRoomId ?: null,
                'type'                 => 'lecture',
                'active'               => true,
            ]);
        }

        $this->conflictMessage = '';
        $this->showCell = false;
        $this->loadTimetable();
        $this->dispatch('close-modal', name: 'cell');
        $this->successMessage = __('mtschool::timetable.timetable_updated');
    }

    /**
     * Cherche un conflit prof/salle sur ce créneau (même jour + même période) dans une
     * AUTRE classe de l'année active. Retourne ['type'=>'teacher'|'room','class'=>code] ou null.
     */
    protected function findConflict(int $day, string $start, ?int $teacherId, ?int $roomId): ?array
    {
        if (! $teacherId && ! $roomId) {
            return null;
        }

        $yearTimetableIds = Timetable::where('school_year_id', activeSchoolYearId())->pluck('id');

        $base = TimeSlot::where('day_of_week', $day)
            ->where('timetable_id', '!=', $this->timetableId)
            ->whereIn('timetable_id', $yearTimetableIds)
            ->where('start_time', 'like', $start . '%'); // même période (HH:MM)

        if ($teacherId) {
            $slot = (clone $base)->where('teacher_id', $teacherId)->first();
            if ($slot) {
                return ['type' => 'teacher', 'class' => $this->slotClassCode($slot)];
            }
        }
        if ($roomId) {
            $slot = (clone $base)->where('room_id', $roomId)->first();
            if ($slot) {
                return ['type' => 'room', 'class' => $this->slotClassCode($slot)];
            }
        }

        return null;
    }

    protected function slotClassCode(TimeSlot $slot): string
    {
        return Timetable::find($slot->timetable_id)?->classroom?->code ?? '?';
    }

    public function render()
    {
        if ($gate = $this->prerequisiteGate('timetable', __('mtschool::timetable.title'))) {
            return $gate;
        }

        return view('mtschool::livewire.admin.timetable.grid', [
            'periods' => self::PERIODS,
            'days'    => self::translatedDays(),
        ])->title(__('mtschool::timetable.title'));
    }
}
