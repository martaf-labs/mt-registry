<?php

namespace Mt\MtSchoolCore\Livewire\Admin\GradeLevels;

use Mt\MtSchoolCore\Livewire\Forms\GradeLevelForm;
use Mt\MtViews\Livewire\Base\BaseForm;

class GradeLevelsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return GradeLevelForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.level_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.level_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('grade-level', __('mtschool::structure.grade_levels'))->add(__('mtschool::common.new_m'), '#')->get()
            : navItems('grade-level', __('mtschool::structure.grade_levels'))
                ->add($data->code, mt_get_route('grade_levels'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.grade-levels';
    }

    public function steps(): array
    {
        return [];
    }
}
