<?php

namespace Mt\MtSchoolCore\Livewire\Admin\GradeLevels;

use Mt\MtSchoolCore\Livewire\Indexes\GradeLevelIndex;
use Mt\MtViews\Livewire\Base\BaseIndex;

class GradeLevelsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return GradeLevelIndex::class;
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::structure.grade_levels'));
    }
}
