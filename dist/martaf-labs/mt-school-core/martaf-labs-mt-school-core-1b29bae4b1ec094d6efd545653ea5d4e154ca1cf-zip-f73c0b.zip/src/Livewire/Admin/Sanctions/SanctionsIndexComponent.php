<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Sanctions;

use Mt\MtSchoolCore\Livewire\Indexes\SanctionIndex;
use Mt\MtSchoolCore\Models\DisciplinarySanction;
use Mt\MtViews\Livewire\Base\BaseIndex;

class SanctionsIndexComponent extends BaseIndex
{
    public function indexClass(): string
    {
        return SanctionIndex::class;
    }

    /** Lève une sanction active (fin de sanction). */
    public function liftSanction(int $id): void
    {
        $sanction = DisciplinarySanction::find($id);
        if ($sanction && $sanction->status === 'active') {
            $sanction->lift();
            showAlert('success', __('mtschool::academics.sanction_lifted'));
        }
    }

    /** Marque le parent comme notifié (le système d'envoi n'est pas encore branché). */
    public function markParentNotified(int $id): void
    {
        $sanction = DisciplinarySanction::find($id);
        if ($sanction && ! $sanction->parent_notified) {
            $sanction->notifyParent();
            showAlert('success', __('mtschool::academics.sanction_parent_notified'));
        }
    }

    public function render()
    {
        return parent::render()->title(__('mtschool::academics.sanctions'));
    }
}
