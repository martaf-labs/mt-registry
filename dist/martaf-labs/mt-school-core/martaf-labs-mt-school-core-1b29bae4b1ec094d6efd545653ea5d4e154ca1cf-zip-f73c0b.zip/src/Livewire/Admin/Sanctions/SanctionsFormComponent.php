<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Sanctions;

use Mt\MtSchoolCore\Livewire\Forms\SanctionForm;
use Mt\MtViews\Livewire\Base\BaseForm;

class SanctionsFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return SanctionForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::academics.sanction_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::academics.sanction_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('sanction', __('mtschool::academics.sanctions'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('sanction', __('mtschool::academics.sanctions'))
                ->add($data->reference ?? __('mtschool::academics.sanction_singular'), mt_get_route('discipline_sanctions'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'discipline.sanctions';
    }

    public function steps(): array
    {
        return [];
    }
}
