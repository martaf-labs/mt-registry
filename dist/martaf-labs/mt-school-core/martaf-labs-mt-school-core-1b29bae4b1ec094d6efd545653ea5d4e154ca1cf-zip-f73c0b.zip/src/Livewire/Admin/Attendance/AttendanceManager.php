<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Attendance;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Attendance;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Enrollment;

/**
 * Appel (présences) : pour une classe + date + demi-journée, statut de chaque élève
 * (présent / absent / retard). Persistance inline. Base du suivi d'assiduité et des
 * compteurs d'absences du bulletin.
 */
#[Layout('mt::components.layouts.app')]
class AttendanceManager extends Component
{
    public ?int $classId = null;
    public ?string $date = null;
    public string $dayPeriod = 'full_day';

    /** Lignes indexées par enrollment_id. */
    public array $rows = [];

    public string $successMessage = '';

    public function mount(): void
    {
        $this->classId = Classroom::where('active', true)->orderBy('code')->value('id');
        $this->date    = now()->format('Y-m-d');
        $this->loadRows();
    }

    #[Computed]
    public function classes(): array
    {
        return Classroom::where('active', true)->orderBy('code')->get()
            ->mapWithKeys(fn ($c) => [$c->id => $c->label])->toArray();
    }

    public function dayPeriods(): array
    {
        return [
            'full_day' => __('mtschool::attendance.period_full'),
            'morning'  => __('mtschool::attendance.period_morning'),
            'afternoon'=> __('mtschool::attendance.period_afternoon'),
        ];
    }

    protected function loadRows(): void
    {
        $this->rows = [];

        if (! $this->classId || ! $this->date) {
            return;
        }

        // attendances n'a pas de class_id → on passe par les inscriptions de la classe.
        $enrollments = Enrollment::where('class_id', $this->classId)->validated()->with('student')->get()
            ->sortBy(fn ($e) => $e->student?->full_name_reverse ?? '');

        $att = Attendance::whereIn('enrollment_id', $enrollments->pluck('id'))
            ->whereDate('date', $this->date)
            ->where('day_period', $this->dayPeriod)
            ->get()->keyBy('enrollment_id');

        foreach ($enrollments as $e) {
            $a = $att->get($e->id);
            $this->rows[$e->id] = [
                'student'   => $e->student?->full_name_reverse ?? $e->student?->full_name ?? '—',
                'status'    => $a?->status?->value ?? 'present',
                'lateness'  => (int) ($a?->lateness_minutes ?? 0),
                'justified' => (bool) ($a?->is_justified),
                'recorded'  => (bool) $a,
            ];
        }
    }

    public function updatedClassId(): void { $this->loadRows(); }
    public function updatedDate(): void { $this->loadRows(); }
    public function updatedDayPeriod(): void { $this->loadRows(); }

    public function setStatus(int $enrollmentId, string $status): void
    {
        if (! isset($this->rows[$enrollmentId]) || ! in_array($status, ['present', 'absent', 'late'], true)) {
            return;
        }

        $this->rows[$enrollmentId]['status'] = $status;
        $this->persist($enrollmentId);
        unset($this->summary);
    }

    public function toggleJustified(int $enrollmentId): void
    {
        if (! isset($this->rows[$enrollmentId]) || $this->rows[$enrollmentId]['status'] !== 'absent') {
            return;
        }
        $this->rows[$enrollmentId]['justified'] = ! $this->rows[$enrollmentId]['justified'];
        $this->persist($enrollmentId);
    }

    public function markAllPresent(): void
    {
        foreach (array_keys($this->rows) as $eid) {
            $this->rows[$eid]['status'] = 'present';
            $this->persist($eid);
        }
        unset($this->summary);
        $this->successMessage = __('mtschool::attendance.all_present_msg');
    }

    protected function persist(int $enrollmentId): void
    {
        $row = $this->rows[$enrollmentId];

        $attendance = Attendance::updateOrCreate(
            ['enrollment_id' => $enrollmentId, 'date' => $this->date, 'day_period' => $this->dayPeriod],
            [
                'status'           => $row['status'],
                'lateness_minutes' => $row['status'] === 'late' ? (int) $row['lateness'] : 0,
                'is_justified'     => (bool) $row['justified'],
                'recorded_by'      => auth()->id(),
            ]
        );

        // Prévenir les tuteurs à la TRANSITION vers « absent » uniquement (création absente
        // ou changement de statut) — un re-clic sur A ne re-notifie pas. Listener :
        // NotifyParentAbsence → NotificationService::notifyAbsence (in-app + e-mail).
        if ($row['status'] === 'absent'
            && ($attendance->wasRecentlyCreated || $attendance->wasChanged('status'))) {
            event(new \Mt\MtSchoolCore\Events\AbsenceRecorded($attendance));
        }

        $this->rows[$enrollmentId]['recorded'] = true;
    }

    #[Computed]
    public function summary(): array
    {
        $rows = collect($this->rows);
        return [
            'present' => $rows->where('status', 'present')->count(),
            'absent'  => $rows->where('status', 'absent')->count(),
            'late'    => $rows->where('status', 'late')->count(),
            'total'   => $rows->count(),
        ];
    }

    public function render()
    {
        return view('mtschool::livewire.admin.attendance.manager')
            ->title(__('mtschool::attendance.title'));
    }
}
