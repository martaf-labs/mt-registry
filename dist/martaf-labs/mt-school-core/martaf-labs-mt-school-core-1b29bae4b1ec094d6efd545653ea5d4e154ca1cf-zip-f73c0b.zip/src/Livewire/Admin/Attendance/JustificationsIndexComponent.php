<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Attendance;

use Livewire\Attributes\Layout;
use Mt\MtSchoolCore\Livewire\Indexes\JustificationIndex;
use Mt\MtSchoolCore\Models\AbsenceJustification;
use Mt\MtSchoolCore\Models\Attendance;
use Mt\MtViews\Livewire\Base\BaseIndex;

/**
 * Écran Justificatifs d'absence = INSTANCE de base-index (même pattern que
 * Inscriptions) : approuver → absences de la période justifiées ; refuser →
 * motif via modale. Remplace l'ancien JustificationManager (vue bespoke).
 */
#[Layout('mt::components.layouts.app')]
class JustificationsIndexComponent extends BaseIndex
{
    public ?int $rejectingId = null;
    public string $rejectReason = '';

    public function indexClass(): string
    {
        return JustificationIndex::class;
    }

    /** Défaut SOUPLE : « en attente » seulement s'il y a des dossiers à traiter. */
    public function mount(): void
    {
        parent::mount();

        if (AbsenceJustification::where('status', 'pending')->exists()) {
            $this->filterValues  = ['status' => 'pending'];
            $this->activeFilters = ['status' => 'pending'];
        }
    }

    public function extraPartials(): array
    {
        return ['mtschool::livewire.admin.attendance.partials.reject-justification-modal'];
    }

    public function approve(int $id): void
    {
        $j = AbsenceJustification::findOrFail($id); // SchoolScope → tenant-safe
        if ($j->status !== 'pending') {
            return;
        }

        $j->update([
            'status'       => 'approved',
            'processed_by' => auth()->id(),
            'processed_at' => now(),
        ]);

        // Marque les absences de la période comme justifiées (boucle avec le suivi parent).
        Attendance::where('enrollment_id', $j->enrollment_id)
            ->whereBetween('date', [$j->start_date, $j->end_date])
            ->where('status', 'absent')
            ->update(['is_justified' => true, 'justification_id' => $j->id]);

        showAlert('success', __('mtschool::portal.justif_approved_ok'));
    }

    public function openReject(int $id): void
    {
        $this->rejectingId  = $id;
        $this->rejectReason = '';
        $this->dispatch('open-reject-justification');
    }

    public function cancelReject(): void
    {
        $this->rejectingId  = null;
        $this->rejectReason = '';
    }

    public function confirmReject(): void
    {
        if (! $this->rejectingId) {
            return;
        }

        $j = AbsenceJustification::findOrFail($this->rejectingId);
        if ($j->status !== 'pending') {
            $this->cancelReject();
            return;
        }

        $loc = config('mt-school-core.multilingual.default', 'fr');
        $j->update([
            'status'           => 'rejected',
            'rejection_reason' => filled($this->rejectReason) ? [$loc => $this->rejectReason] : null,
            'processed_by'     => auth()->id(),
            'processed_at'     => now(),
        ]);

        $this->cancelReject();
        showAlert('success', __('mtschool::portal.justif_rejected_ok'));
    }
}
