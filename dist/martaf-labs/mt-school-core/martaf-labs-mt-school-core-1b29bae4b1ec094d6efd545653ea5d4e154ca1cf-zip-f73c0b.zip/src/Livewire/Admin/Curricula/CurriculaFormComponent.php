<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Curricula;

use Mt\MtSchoolCore\Livewire\Forms\CurriculumForm;
use Mt\MtViews\Livewire\Base\BaseForm;

class CurriculaFormComponent extends BaseForm
{
    public function formClass(): string
    {
        return CurriculumForm::class;
    }

    public function getModelName(): string
    {
        return __('mtschool::structure.curriculum_model_name');
    }

    public function getPluralModelName(): string
    {
        return __('mtschool::structure.curriculum_model_plural');
    }

    public function getModelNavItems($data = null): array
    {
        return is_null($data)
            ? navItems('curriculum', __('mtschool::structure.curricula'))->add(__('mtschool::common.new_f'), '#')->get()
            : navItems('curriculum', __('mtschool::structure.curricula'))
                ->add($data->code ?? __('mtschool::structure.curriculum_singular'), mt_get_route('curricula'))
                ->add(__('mtschool::common.edit'), '#')
                ->get();
    }

    public function getRedirectRouteName(): string
    {
        return 'structure.curricula';
    }

    public function steps(): array
    {
        return [];
    }
}
