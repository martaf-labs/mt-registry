<?php

namespace Mt\MtSchoolCore\Livewire\Admin\Curricula;

use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtSchoolCore\Models\Subject;

/**
 * Éditeur de maquette : matières d'un programme + coefficients (curriculum_subject).
 * Édition INLINE (coefficient, heures/sem, sur bulletin, éliminatoire, ordre),
 * persistée à la volée. Cœur du calcul des moyennes/bulletins.
 *
 * Tenant : Curriculum est school-scoped → findOrFail garantit l'appartenance.
 */
#[Layout('mt::components.layouts.app')]
class CurriculumManager extends Component
{
    public int $curriculumId;
    public ?Curriculum $curriculum = null;

    /** Lignes éditables indexées par subject_id. */
    public array $rows = [];

    /** Matière sélectionnée à ajouter. */
    public $subjectToAdd = null;

    public string $successMessage = '';

    public function mount(int $id): void
    {
        $this->curriculum = Curriculum::with(['gradeLevel', 'specialization'])->findOrFail($id);
        $this->curriculumId = $id;
        $this->loadRows();
    }

    protected function loadRows(): void
    {
        $this->rows = [];

        $subjects = $this->curriculum->subjects()
            ->orderBy('curriculum_subject.order')
            ->orderBy('subjects.code')
            ->get();

        foreach ($subjects as $s) {
            $this->rows[$s->id] = [
                'label'          => $s->label,
                'code'           => $s->code,
                'group'          => $s->group?->label(),
                'color'          => $s->color,
                'coefficient'    => (float) $s->pivot->coefficient,
                'weekly_hours'   => $s->pivot->weekly_hours !== null ? (float) $s->pivot->weekly_hours : null,
                'on_report_card' => (bool) $s->pivot->on_report_card,
                'is_eliminating' => (bool) $s->pivot->is_eliminating,
                'order'          => (int) $s->pivot->order,
            ];
        }
    }

    #[Computed]
    public function availableSubjects()
    {
        return Subject::active()
            ->whereNotIn('id', array_keys($this->rows))
            ->orderBy('code')
            ->get();
    }

    #[Computed]
    public function totalCoef(): float
    {
        return array_sum(array_map(fn ($r) => (float) ($r['coefficient'] ?? 0), $this->rows));
    }

    #[Computed]
    public function reportCoef(): float
    {
        return array_sum(array_map(
            fn ($r) => ($r['on_report_card'] ?? false) ? (float) ($r['coefficient'] ?? 0) : 0,
            $this->rows
        ));
    }

    public function addSubject(): void
    {
        $this->validate(
            ['subjectToAdd' => 'required|integer|exists:subjects,id'],
            ['subjectToAdd.required' => __('mtschool::structure.choose_subject_required')]
        );

        if (isset($this->rows[$this->subjectToAdd])) {
            return; // déjà présente
        }

        $nextOrder = (int) (collect($this->rows)->max('order') ?? 0) + 1;

        // NB : curriculum_subject n'a pas de school_id ; l'isolation est garantie par
        // le curriculum_id (Curriculum est school-scoped).
        $this->curriculum->subjects()->attach($this->subjectToAdd, [
            'coefficient'    => 1.00,
            'order'          => $nextOrder,
            'on_report_card' => true,
            'is_eliminating' => false,
        ]);

        $this->subjectToAdd = null;
        $this->loadRows();
        unset($this->availableSubjects, $this->totalCoef, $this->reportCoef);
        $this->successMessage = __('mtschool::structure.subject_added');
    }

    /** Persiste une ligne dès qu'un champ change (wire:model.blur / toggle). */
    public function updated($name, $value): void
    {
        if (! str_starts_with($name, 'rows.')) {
            return;
        }

        $parts = explode('.', $name);
        $subjectId = (int) ($parts[1] ?? 0);

        if (! $subjectId || ! isset($this->rows[$subjectId])) {
            return;
        }

        $this->persistPivot($subjectId);
        unset($this->totalCoef, $this->reportCoef);
    }

    protected function persistPivot(int $subjectId): void
    {
        $row = $this->rows[$subjectId];

        $this->curriculum->subjects()->updateExistingPivot($subjectId, [
            'coefficient'    => max(0, (float) ($row['coefficient'] ?? 1)),
            'weekly_hours'   => ($row['weekly_hours'] === '' || $row['weekly_hours'] === null)
                                    ? null : (float) $row['weekly_hours'],
            'on_report_card' => (bool) ($row['on_report_card'] ?? true),
            'is_eliminating' => (bool) ($row['is_eliminating'] ?? false),
            'order'          => (int) ($row['order'] ?? 1),
        ]);
    }

    public function removeSubject(int $subjectId): void
    {
        $this->curriculum->subjects()->detach($subjectId);
        unset($this->rows[$subjectId]);
        unset($this->availableSubjects, $this->totalCoef, $this->reportCoef);
        $this->successMessage = __('mtschool::structure.subject_removed');
    }

    public function render()
    {
        return view('mtschool::livewire.admin.curricula.manager')
            ->title(__('mtschool::structure.curriculum_title'));
    }
}
