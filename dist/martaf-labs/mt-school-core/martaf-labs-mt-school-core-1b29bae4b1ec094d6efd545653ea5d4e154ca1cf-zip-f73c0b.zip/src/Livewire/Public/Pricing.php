<?php

namespace Mt\MtSchoolCore\Livewire\Public;

use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Module;
use Mt\MtSchoolCore\Models\Plan;

#[Layout('mt::components.layouts.auth')]
class Pricing extends Component
{
    public function render()
    {
        $plans = Plan::public()->active()->with('modules')->orderBy('order')->get();

        // Noms de modules (localisés) indexés par code, pour l'affichage.
        $moduleNames = Module::active()->get()->mapWithKeys(fn ($m) => [$m->code => $m->name]);

        return view('mtschool::livewire.public.pricing', [
            'plans'       => $plans,
            'moduleNames' => $moduleNames,
        ])->title(__('mtschool::billing.pricing_title'));
    }
}
