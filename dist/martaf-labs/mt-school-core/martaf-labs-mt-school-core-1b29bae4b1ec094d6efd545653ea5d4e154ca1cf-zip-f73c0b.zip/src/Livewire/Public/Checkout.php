<?php

namespace Mt\MtSchoolCore\Livewire\Public;

use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Mt\MtSchoolCore\Models\Plan;
use Mt\MtSchoolCore\Services\SubscriptionPurchaseService;

#[Layout('mt::components.layouts.auth')]
class Checkout extends Component
{
    public string $planCode = '';

    public string $name = '';
    public string $email = '';
    public string $password = '';
    public string $password_confirmation = '';
    public string $school_name = '';

    public bool $processing = false;

    public function mount(string $plan): void
    {
        // Vérifie que le plan existe ET est public (sinon 404) : un plan retiré/confidentiel
        // ne doit pas être souscriptible par URL directe (aligné sur le catalogue Pricing).
        Plan::active()->public()->where('code', $plan)->firstOrFail();
        $this->planCode = $plan;
    }

    #[Computed]
    public function plan(): Plan
    {
        return Plan::active()->public()->where('code', $this->planCode)->firstOrFail();
    }

    protected function rules(): array
    {
        return [
            'name'        => 'required|string|max:255',
            'email'       => 'required|email|max:255|unique:users,email',
            'password'    => 'required|string|min:8|confirmed',
            'school_name' => 'nullable|string|max:255',
        ];
    }

    protected function messages(): array
    {
        return [
            'email.unique'       => __('mtschool::billing.email_unique'),
            'password.confirmed' => __('mtschool::billing.password_confirmed'),
        ];
    }

    public function pay()
    {
        $data = $this->validate();
        $this->processing = true;

        $result = app(SubscriptionPurchaseService::class)->purchase($this->plan, [
            'name'        => $data['name'],
            'email'       => $data['email'],
            'password'    => $data['password'],
            'school_name' => $data['school_name'] ?: null,
        ]);

        // Connecte le super-admin et fixe le tenant courant.
        Auth::login($result['user']);
        session(['current_school_id' => $result['school']->id]);

        // Vers la configuration de l'école.
        return redirect()->route(config('routes.setup', 'setup'));
    }

    public function render()
    {
        return view('mtschool::livewire.public.checkout')->title(__('mtschool::billing.checkout_title'));
    }
}
