<?php

namespace Mt\MtSchoolCore\Listeners;

use Mt\MtSchoolCore\Events\PaymentReceived;

class NotifyPaymentConfirmed
{
    public function handle(PaymentReceived $event): void
    {
        // TODO: notify family when payment is confirmed
    }
}
