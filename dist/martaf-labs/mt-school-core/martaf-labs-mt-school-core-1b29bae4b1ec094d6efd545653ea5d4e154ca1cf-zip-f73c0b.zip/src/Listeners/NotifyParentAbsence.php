<?php

namespace Mt\MtSchoolCore\Listeners;

use Mt\MtSchoolCore\Events\AbsenceRecorded;
use Mt\MtSchoolCore\Services\NotificationService;

class NotifyParentAbsence
{
    public function handle(AbsenceRecorded $event): void
    {
        app(NotificationService::class)->notifyAbsence($event->attendance);
    }
}
