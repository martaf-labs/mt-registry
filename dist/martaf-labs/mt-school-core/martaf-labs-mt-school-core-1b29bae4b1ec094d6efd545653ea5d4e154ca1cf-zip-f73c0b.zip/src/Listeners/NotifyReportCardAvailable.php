<?php

namespace Mt\MtSchoolCore\Listeners;

use Mt\MtSchoolCore\Events\ReportCardPublished;

class NotifyReportCardAvailable
{
    public function handle(ReportCardPublished $event): void
    {
        // TODO: notify student and guardian that report card is available
    }
}
