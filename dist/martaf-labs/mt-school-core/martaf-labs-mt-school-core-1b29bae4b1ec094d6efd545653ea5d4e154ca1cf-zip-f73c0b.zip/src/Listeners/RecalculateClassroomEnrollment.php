<?php

namespace Mt\MtSchoolCore\Listeners;

use Mt\MtSchoolCore\Events\EnrollmentValidated;

class RecalculateClassroomEnrollment
{
    public function handle(EnrollmentValidated $event): void
    {
        $enrollment = $event->enrollment;
        $classroom  = $enrollment->classroom;

        if ($classroom) {
            $classroom->recalculateEnrollment();
        }
    }
}
