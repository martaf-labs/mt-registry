<?php

namespace Mt\MtSchoolCore\Enums;

enum SanctionType: string
{
    case WARNING          = 'warning';
    case REPRIMAND        = 'reprimand';
    case TEMP_SUSPENSION  = 'temp_suspension';
    case EXPULSION        = 'expulsion';
    case DETENTION        = 'detention';
    case PARENT_SUMMONS   = 'parent_summons';
    case OTHER            = 'other';

    public function label(): string
    {
        return __('mtschool::academics.sanction_type_' . $this->value);
    }

    public function badge(): string
    {
        return match ($this) {
            self::WARNING         => 'warning',
            self::REPRIMAND       => 'orange',
            self::TEMP_SUSPENSION => 'danger',
            self::EXPULSION       => 'dark',
            self::DETENTION       => 'secondary',
            self::PARENT_SUMMONS  => 'info',
            self::OTHER           => 'light',
        };
    }

    public function isSevere(): bool
    {
        return in_array($this, [self::TEMP_SUSPENSION, self::EXPULSION]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
