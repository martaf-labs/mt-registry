<?php

namespace Mt\MtSchoolCore\Enums;

enum FeeStatus: string
{
    case PENDING  = 'pending';
    case PARTIAL  = 'partial';
    case PAID     = 'paid';
    case EXEMPT   = 'exempt';
    case CANCELLED = 'cancelled';

    public function label(): string
    {
        return match ($this) {
            self::PENDING   => 'Pending',
            self::PARTIAL   => 'Partial Payment',
            self::PAID      => 'Paid',
            self::EXEMPT    => 'Exempt',
            self::CANCELLED => 'Cancelled',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::PENDING   => 'warning',
            self::PARTIAL   => 'info',
            self::PAID      => 'success',
            self::EXEMPT    => 'secondary',
            self::CANCELLED => 'danger',
        };
    }

    public function isActive(): bool
    {
        return in_array($this, [self::PENDING, self::PARTIAL]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
