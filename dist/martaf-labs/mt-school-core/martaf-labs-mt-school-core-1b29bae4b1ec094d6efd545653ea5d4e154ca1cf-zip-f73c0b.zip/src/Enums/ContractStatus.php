<?php

namespace Mt\MtSchoolCore\Enums;

enum ContractStatus: string
{
    case PERMANENT    = 'permanent';
    case TEMPORARY    = 'temporary';
    case CONTRACTUAL  = 'contractual';
    case INTERN       = 'intern';
    case VOLUNTEER    = 'volunteer';

    public function label(): string
    {
        return match ($this) {
            self::PERMANENT   => 'Permanent',
            self::TEMPORARY   => 'Temporary',
            self::CONTRACTUAL => 'Contractual',
            self::INTERN      => 'Intern',
            self::VOLUNTEER   => 'Volunteer',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::PERMANENT   => 'success',
            self::TEMPORARY   => 'warning',
            self::CONTRACTUAL => 'info',
            self::INTERN      => 'secondary',
            self::VOLUNTEER   => 'light',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
