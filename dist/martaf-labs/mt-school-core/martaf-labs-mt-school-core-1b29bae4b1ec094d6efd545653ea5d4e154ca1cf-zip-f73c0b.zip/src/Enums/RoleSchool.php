<?php

namespace Mt\MtSchoolCore\Enums;

use Illuminate\Support\Str;

enum RoleSchool: string
{
    case SUPER_ADMIN   = 'super_admin';
    case PRINCIPAL     = 'principal';
    case VICE_PRINCIPAL = 'vice_principal';
    case ACCOUNTANT    = 'accountant';
    case TEACHER       = 'teacher';
    case STUDENT       = 'student';
    case PARENT        = 'parent';
    case STAFF         = 'staff';

    public function label(): string
    {
        return match ($this) {
            self::SUPER_ADMIN    => 'Super Administrator',
            self::PRINCIPAL      => 'Principal',
            self::VICE_PRINCIPAL => 'Vice-Principal',
            self::ACCOUNTANT     => 'Accountant',
            self::TEACHER        => 'Teacher',
            self::STUDENT        => 'Student',
            self::PARENT         => 'Parent / Guardian',
            self::STAFF          => 'Staff',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::SUPER_ADMIN    => 'danger',
            self::PRINCIPAL      => 'dark',
            self::VICE_PRINCIPAL => 'primary',
            self::ACCOUNTANT     => 'success',
            self::TEACHER        => 'info',
            self::STUDENT        => 'secondary',
            self::PARENT         => 'warning',
            self::STAFF          => 'light',
        };
    }

    /** Access level for hierarchy checks */
    public function accessLevel(): int
    {
        return match ($this) {
            self::SUPER_ADMIN    => 10,
            self::PRINCIPAL      => 8,
            self::VICE_PRINCIPAL => 7,
            self::ACCOUNTANT     => 5,
            self::TEACHER        => 4,
            self::STAFF          => 3,
            self::PARENT         => 2,
            self::STUDENT        => 1,
        };
    }

    public function canManageGrades(): bool
    {
        return in_array($this, [self::SUPER_ADMIN, self::PRINCIPAL, self::VICE_PRINCIPAL, self::TEACHER]);
    }

    public function canViewFinances(): bool
    {
        return in_array($this, [self::SUPER_ADMIN, self::PRINCIPAL, self::ACCOUNTANT]);
    }

    /**
     * Abilities (permissions) accordées à ce rôle — alimente le Gate RBAC.
     * super_admin / principal : accès total. Les autres rôles administratifs
     * n'obtiennent que les domaines métier qui les concernent (délégation).
     * teacher / student / parent : aucune permission admin (portail uniquement).
     */
    public function permissions(): array
    {
        if (in_array($this, [self::SUPER_ADMIN, self::PRINCIPAL], true)) {
            return Permission::values();
        }

        $domains = match ($this) {
            self::VICE_PRINCIPAL => [
                'school.years', 'school.periods', 'school.cycles', 'school.grade_levels', 'school.specializations',
                'school.classes', 'school.subjects', 'school.curricula', 'school.rooms', 'school.course_assignments',
                'school.assessments', 'school.grades', 'school.report_cards', 'school.timetable',
                'school.students', 'school.guardians', 'school.enrollments',
                'school.attendance', 'school.sanctions', 'school.class_councils',
                'school.certificates', 'school.resources', 'school.homeworks',
                'school.announcements', 'school.calendar', 'school.messaging',
            ],
            self::ACCOUNTANT => [
                'school.fees', 'school.payments', 'school.scholarships', 'school.accounting',
                'school.students', 'school.guardians', 'school.enrollments', 'school.certificates',
            ],
            self::STAFF => [
                'school.students', 'school.guardians', 'school.enrollments', 'school.certificates',
                'school.imports', 'school.attendance', 'school.announcements', 'school.calendar',
            ],
            default => [], // teacher / student / parent
        };

        $prefixes = array_map(static fn ($d) => $d . '.', $domains);

        return array_values(array_filter(
            Permission::values(),
            static fn (string $ability) => Str::startsWith($ability, $prefixes),
        ));
    }

    /** Ce rôle possède-t-il l'ability donnée ? (super_admin : toujours). */
    public function allows(string $ability): bool
    {
        return $this === self::SUPER_ADMIN || in_array($ability, $this->permissions(), true);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }

    /** Rôles back-office assignables à un membre d'équipe (hors portail auto-provisionné). */
    public static function assignableAdminRoles(): array
    {
        return [self::PRINCIPAL, self::VICE_PRINCIPAL, self::ACCOUNTANT, self::STAFF];
    }

    /** Ce rôle est-il un rôle back-office (admin) et non un rôle portail ? */
    public function isBackOffice(): bool
    {
        return ! in_array($this, [self::TEACHER, self::STUDENT, self::PARENT], true);
    }

    public static function assignableAdminOptions(): array
    {
        return collect(self::assignableAdminRoles())
            ->mapWithKeys(fn ($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
