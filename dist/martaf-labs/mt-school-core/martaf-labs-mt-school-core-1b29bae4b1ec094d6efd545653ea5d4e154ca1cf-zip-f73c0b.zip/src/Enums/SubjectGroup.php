<?php

namespace Mt\MtSchoolCore\Enums;

enum SubjectGroup: string
{
    case LITERARY   = 'literary';
    case SCIENTIFIC = 'scientific';
    case TECHNICAL  = 'technical';
    case PHYSICAL   = 'physical';
    case ARTISTIC   = 'artistic';
    case LANGUAGE   = 'language';
    case OTHER      = 'other';

    public function label(): string
    {
        return __('mtschool::structure.group_' . $this->value);
    }

    public function color(): string
    {
        return match ($this) {
            self::LITERARY   => '#8b5cf6',
            self::SCIENTIFIC => '#3b82f6',
            self::TECHNICAL  => '#f59e0b',
            self::PHYSICAL   => '#10b981',
            self::ARTISTIC   => '#ec4899',
            self::LANGUAGE   => '#06b6d4',
            self::OTHER      => '#6b7280',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
