<?php

namespace Mt\MtSchoolCore\Enums;

enum TimeSlotType: string
{
    case LECTURE    = 'lecture';
    case TUTORIAL   = 'tutorial';
    case LAB        = 'lab';
    case EXAM       = 'exam';
    case STUDY_HALL = 'study_hall';
    case BREAK      = 'break';
    case OTHER      = 'other';

    public function label(): string
    {
        return match ($this) {
            self::LECTURE    => 'Lecture',
            self::TUTORIAL   => 'Tutorial',
            self::LAB        => 'Lab / Practical',
            self::EXAM       => 'Exam',
            self::STUDY_HALL => 'Study Hall',
            self::BREAK      => 'Break / Recess',
            self::OTHER      => 'Other',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::LECTURE    => 'primary',
            self::TUTORIAL   => 'info',
            self::LAB        => 'success',
            self::EXAM       => 'danger',
            self::STUDY_HALL => 'warning',
            self::BREAK      => 'light',
            self::OTHER      => 'secondary',
        };
    }

    public function isTeachingSlot(): bool
    {
        return in_array($this, [self::LECTURE, self::TUTORIAL, self::LAB]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
