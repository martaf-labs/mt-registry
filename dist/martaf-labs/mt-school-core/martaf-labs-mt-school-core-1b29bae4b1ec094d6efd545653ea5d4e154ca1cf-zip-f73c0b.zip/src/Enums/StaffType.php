<?php

namespace Mt\MtSchoolCore\Enums;

enum StaffType: string
{
    case TEACHER        = 'teacher';
    case ADMINISTRATIVE = 'administrative';
    case TECHNICAL      = 'technical';
    case MANAGEMENT     = 'management';

    public function label(): string
    {
        // Traduisible : clés staff_type_* de lang/{fr,en,ar}/students.php
        // (sinon « Administrative »/« Management » anglais en dur fuyait dans les listes).
        return __('mtschool::students.staff_type_' . $this->value);
    }

    public function badge(): string
    {
        return match ($this) {
            self::TEACHER        => 'primary',
            self::ADMINISTRATIVE => 'info',
            self::TECHNICAL      => 'warning',
            self::MANAGEMENT     => 'success',
        };
    }

    public function isTeacher(): bool
    {
        return $this === self::TEACHER;
    }

    public function isManagement(): bool
    {
        return $this === self::MANAGEMENT;
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
