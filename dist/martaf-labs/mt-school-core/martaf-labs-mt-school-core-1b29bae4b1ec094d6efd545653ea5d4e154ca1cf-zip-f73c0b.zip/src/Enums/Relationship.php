<?php

namespace Mt\MtSchoolCore\Enums;

enum Relationship: string
{
    case FATHER       = 'father';
    case MOTHER       = 'mother';
    case GUARDIAN     = 'guardian';
    case GRANDPARENT  = 'grandparent';
    case SIBLING      = 'sibling';
    case AUNT_UNCLE   = 'aunt_uncle';
    case OTHER        = 'other';

    public function label(): string
    {
        return __('mtschool::enrollment.relationship_' . $this->value);
    }

    public function isDirectParent(): bool
    {
        return in_array($this, [self::FATHER, self::MOTHER]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
