<?php

namespace Mt\MtSchoolCore\Enums;

enum AssessmentStatus: string
{
    case SCHEDULED  = 'scheduled';
    case IN_PROGRESS = 'in_progress';
    case CORRECTED  = 'corrected';
    case ENTERED    = 'entered';
    case VALIDATED  = 'validated';

    public function label(): string
    {
        return __('mtschool::academics.assessment_status_' . $this->value);
    }

    public function badge(): string
    {
        return match ($this) {
            self::SCHEDULED   => 'secondary',
            self::IN_PROGRESS => 'warning',
            self::CORRECTED   => 'info',
            self::ENTERED     => 'primary',
            self::VALIDATED   => 'success',
        };
    }

    public function isEntered(): bool
    {
        return in_array($this, [self::ENTERED, self::VALIDATED]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
