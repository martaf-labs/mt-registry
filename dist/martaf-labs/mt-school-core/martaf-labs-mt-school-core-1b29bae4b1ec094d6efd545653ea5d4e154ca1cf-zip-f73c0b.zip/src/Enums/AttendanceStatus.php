<?php

namespace Mt\MtSchoolCore\Enums;

enum AttendanceStatus: string
{
    case PRESENT   = 'present';
    case ABSENT    = 'absent';
    case LATE      = 'late';
    case EXCLUDED  = 'excluded';

    public function label(): string
    {
        return match ($this) {
            self::PRESENT  => 'Present',
            self::ABSENT   => 'Absent',
            self::LATE     => 'Late',
            self::EXCLUDED => 'Excluded',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::PRESENT  => 'success',
            self::ABSENT   => 'danger',
            self::LATE     => 'warning',
            self::EXCLUDED => 'dark',
        };
    }

    public function icon(): string
    {
        return match ($this) {
            self::PRESENT  => 'fa-check-circle',
            self::ABSENT   => 'fa-times-circle',
            self::LATE     => 'fa-clock',
            self::EXCLUDED => 'fa-ban',
        };
    }

    public function isAbsence(): bool
    {
        return in_array($this, [self::ABSENT, self::EXCLUDED]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
