<?php

namespace Mt\MtSchoolCore\Enums;

/**
 * All permissions for the mt-school application.
 *
 * Convention: school.{module}.{action}
 * Standard actions: view | manage | create | edit | delete
 * Domain-specific actions: enter | validate | generate | publish | correct | justify
 */
enum Permission: string
{
    // ── Academic structure ────────────────────────────────────────────────────
    case SCHOOL_YEARS_VIEW      = 'school.years.view';
    case SCHOOL_YEARS_MANAGE    = 'school.years.manage';

    case PERIODS_VIEW           = 'school.periods.view';
    case PERIODS_MANAGE         = 'school.periods.manage';

    case CYCLES_VIEW            = 'school.cycles.view';
    case CYCLES_MANAGE          = 'school.cycles.manage';

    case GRADE_LEVELS_VIEW      = 'school.grade_levels.view';
    case GRADE_LEVELS_MANAGE    = 'school.grade_levels.manage';

    case SPECIALIZATIONS_VIEW   = 'school.specializations.view';
    case SPECIALIZATIONS_MANAGE = 'school.specializations.manage';

    case CLASSES_VIEW           = 'school.classes.view';
    case CLASSES_MANAGE         = 'school.classes.manage';

    case SUBJECTS_VIEW          = 'school.subjects.view';
    case SUBJECTS_MANAGE        = 'school.subjects.manage';

    case CURRICULA_VIEW         = 'school.curricula.view';
    case CURRICULA_MANAGE       = 'school.curricula.manage';

    // ── Infrastructure ────────────────────────────────────────────────────────
    case ROOMS_VIEW             = 'school.rooms.view';
    case ROOMS_MANAGE           = 'school.rooms.manage';

    // ── Staff & Teachers ─────────────────────────────────────────────────────
    case STAFF_VIEW             = 'school.staff.view';
    case STAFF_MANAGE           = 'school.staff.manage';

    case TEACHERS_VIEW          = 'school.teachers.view';
    case TEACHERS_MANAGE        = 'school.teachers.manage';

    case COURSE_ASSIGNMENTS_VIEW   = 'school.course_assignments.view';
    case COURSE_ASSIGNMENTS_MANAGE = 'school.course_assignments.manage';

    // ── Students, Guardians & Enrollments ─────────────────────────────────────
    case STUDENTS_VIEW          = 'school.students.view';
    case STUDENTS_MANAGE        = 'school.students.manage';

    case GUARDIANS_VIEW         = 'school.guardians.view';
    case GUARDIANS_MANAGE       = 'school.guardians.manage';

    case ENROLLMENTS_VIEW       = 'school.enrollments.view';
    case ENROLLMENTS_MANAGE     = 'school.enrollments.manage';
    case ENROLLMENTS_VALIDATE   = 'school.enrollments.validate';

    // ── Timetable ─────────────────────────────────────────────────────────────
    case TIMETABLE_VIEW         = 'school.timetable.view';
    case TIMETABLE_MANAGE       = 'school.timetable.manage';

    // ── Attendance ────────────────────────────────────────────────────────────
    case ATTENDANCE_VIEW        = 'school.attendance.view';
    case ATTENDANCE_ENTER       = 'school.attendance.enter';
    case ATTENDANCE_JUSTIFY     = 'school.attendance.justify';

    // ── Assessments & Grades ──────────────────────────────────────────────────
    case ASSESSMENTS_VIEW       = 'school.assessments.view';
    case ASSESSMENTS_MANAGE     = 'school.assessments.manage';

    case GRADES_VIEW            = 'school.grades.view';
    case GRADES_ENTER           = 'school.grades.enter';
    case GRADES_VALIDATE        = 'school.grades.validate';

    // ── Report Cards ──────────────────────────────────────────────────────────
    case REPORT_CARDS_VIEW      = 'school.report_cards.view';
    case REPORT_CARDS_GENERATE  = 'school.report_cards.generate';
    case REPORT_CARDS_PUBLISH   = 'school.report_cards.publish';

    // ── Finances ──────────────────────────────────────────────────────────────
    case FEES_VIEW              = 'school.fees.view';
    case FEES_MANAGE            = 'school.fees.manage';

    case PAYMENTS_VIEW          = 'school.payments.view';
    case PAYMENTS_ENTER         = 'school.payments.enter';

    case SCHOLARSHIPS_VIEW      = 'school.scholarships.view';
    case SCHOLARSHIPS_MANAGE    = 'school.scholarships.manage';

    case ACCOUNTING_VIEW        = 'school.accounting.view';
    case ACCOUNTING_MANAGE      = 'school.accounting.manage';

    // ── Communication ─────────────────────────────────────────────────────────
    case ANNOUNCEMENTS_VIEW     = 'school.announcements.view';
    case ANNOUNCEMENTS_MANAGE   = 'school.announcements.manage';

    case CALENDAR_VIEW          = 'school.calendar.view';
    case CALENDAR_MANAGE        = 'school.calendar.manage';

    case MESSAGING_VIEW         = 'school.messaging.view';
    case MESSAGING_SEND         = 'school.messaging.send';

    // ── Discipline ────────────────────────────────────────────────────────────
    case SANCTIONS_VIEW         = 'school.sanctions.view';
    case SANCTIONS_MANAGE       = 'school.sanctions.manage';

    case CLASS_COUNCILS_VIEW    = 'school.class_councils.view';
    case CLASS_COUNCILS_MANAGE  = 'school.class_councils.manage';

    // ── Teaching Resources & Homework ─────────────────────────────────────────
    case RESOURCES_VIEW         = 'school.resources.view';
    case RESOURCES_MANAGE       = 'school.resources.manage';

    case HOMEWORKS_VIEW         = 'school.homeworks.view';
    case HOMEWORKS_MANAGE       = 'school.homeworks.manage';
    case HOMEWORKS_CORRECT      = 'school.homeworks.correct';

    // ── Certificates ──────────────────────────────────────────────────────────
    case CERTIFICATES_VIEW      = 'school.certificates.view';
    case CERTIFICATES_GENERATE  = 'school.certificates.generate';

    // ── System Administration ─────────────────────────────────────────────────
    case SETTINGS_VIEW          = 'school.settings.view';
    case SETTINGS_MANAGE        = 'school.settings.manage';

    case IMPORTS_MANAGE         = 'school.imports.manage';

    case USERS_VIEW             = 'school.users.view';
    case USERS_MANAGE           = 'school.users.manage';

    // ── Student portal ────────────────────────────────────────────────────────
    case PORTAL_STUDENT_GRADES      = 'school.portal.student.grades';
    case PORTAL_STUDENT_REPORT_CARDS = 'school.portal.student.report_cards';
    case PORTAL_STUDENT_TIMETABLE   = 'school.portal.student.timetable';
    case PORTAL_STUDENT_ATTENDANCE  = 'school.portal.student.attendance';
    case PORTAL_STUDENT_FEES        = 'school.portal.student.fees';
    case PORTAL_STUDENT_HOMEWORKS   = 'school.portal.student.homeworks';
    case PORTAL_STUDENT_RESOURCES   = 'school.portal.student.resources';

    // ── Parent portal ─────────────────────────────────────────────────────────
    case PORTAL_PARENT_CHILDREN     = 'school.portal.parent.children';
    case PORTAL_PARENT_REPORT_CARDS = 'school.portal.parent.report_cards';
    case PORTAL_PARENT_PAYMENTS     = 'school.portal.parent.payments';
    case PORTAL_PARENT_JUSTIFY      = 'school.portal.parent.justify';
    case PORTAL_PARENT_MESSAGING    = 'school.portal.parent.messaging';
    case PORTAL_PARENT_GRADES       = 'school.portal.parent.grades';

    // ─────────────────────────────────────────────────────────────────────────

    /** Return all permission values as a flat array. */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    /** Permissions grouped by module for display. */
    public static function grouped(): array
    {
        return [
            'Academic Structure' => [
                self::SCHOOL_YEARS_VIEW, self::SCHOOL_YEARS_MANAGE,
                self::PERIODS_VIEW, self::PERIODS_MANAGE,
                self::CYCLES_VIEW, self::CYCLES_MANAGE,
                self::GRADE_LEVELS_VIEW, self::GRADE_LEVELS_MANAGE,
                self::SPECIALIZATIONS_VIEW, self::SPECIALIZATIONS_MANAGE,
                self::CLASSES_VIEW, self::CLASSES_MANAGE,
                self::SUBJECTS_VIEW, self::SUBJECTS_MANAGE,
                self::CURRICULA_VIEW, self::CURRICULA_MANAGE,
                self::ROOMS_VIEW, self::ROOMS_MANAGE,
            ],
            'Staff & Teachers' => [
                self::STAFF_VIEW, self::STAFF_MANAGE,
                self::TEACHERS_VIEW, self::TEACHERS_MANAGE,
                self::COURSE_ASSIGNMENTS_VIEW, self::COURSE_ASSIGNMENTS_MANAGE,
            ],
            'Students & Enrollments' => [
                self::STUDENTS_VIEW, self::STUDENTS_MANAGE,
                self::GUARDIANS_VIEW, self::GUARDIANS_MANAGE,
                self::ENROLLMENTS_VIEW, self::ENROLLMENTS_MANAGE, self::ENROLLMENTS_VALIDATE,
            ],
            'Timetable' => [
                self::TIMETABLE_VIEW, self::TIMETABLE_MANAGE,
            ],
            'Attendance' => [
                self::ATTENDANCE_VIEW, self::ATTENDANCE_ENTER, self::ATTENDANCE_JUSTIFY,
            ],
            'Assessments & Grades' => [
                self::ASSESSMENTS_VIEW, self::ASSESSMENTS_MANAGE,
                self::GRADES_VIEW, self::GRADES_ENTER, self::GRADES_VALIDATE,
            ],
            'Report Cards' => [
                self::REPORT_CARDS_VIEW, self::REPORT_CARDS_GENERATE, self::REPORT_CARDS_PUBLISH,
            ],
            'Finances' => [
                self::FEES_VIEW, self::FEES_MANAGE,
                self::PAYMENTS_VIEW, self::PAYMENTS_ENTER,
                self::SCHOLARSHIPS_VIEW, self::SCHOLARSHIPS_MANAGE,
                self::ACCOUNTING_VIEW, self::ACCOUNTING_MANAGE,
            ],
            'Communication' => [
                self::ANNOUNCEMENTS_VIEW, self::ANNOUNCEMENTS_MANAGE,
                self::CALENDAR_VIEW, self::CALENDAR_MANAGE,
                self::MESSAGING_VIEW, self::MESSAGING_SEND,
            ],
            'Discipline' => [
                self::SANCTIONS_VIEW, self::SANCTIONS_MANAGE,
                self::CLASS_COUNCILS_VIEW, self::CLASS_COUNCILS_MANAGE,
            ],
            'Resources & Homeworks' => [
                self::RESOURCES_VIEW, self::RESOURCES_MANAGE,
                self::HOMEWORKS_VIEW, self::HOMEWORKS_MANAGE, self::HOMEWORKS_CORRECT,
            ],
            'Administration' => [
                self::CERTIFICATES_VIEW, self::CERTIFICATES_GENERATE,
                self::SETTINGS_VIEW, self::SETTINGS_MANAGE,
                self::IMPORTS_MANAGE,
                self::USERS_VIEW, self::USERS_MANAGE,
            ],
            'Student Portal' => [
                self::PORTAL_STUDENT_GRADES, self::PORTAL_STUDENT_REPORT_CARDS,
                self::PORTAL_STUDENT_TIMETABLE, self::PORTAL_STUDENT_ATTENDANCE,
                self::PORTAL_STUDENT_FEES, self::PORTAL_STUDENT_HOMEWORKS,
                self::PORTAL_STUDENT_RESOURCES,
            ],
            'Parent Portal' => [
                self::PORTAL_PARENT_CHILDREN, self::PORTAL_PARENT_REPORT_CARDS,
                self::PORTAL_PARENT_PAYMENTS, self::PORTAL_PARENT_JUSTIFY,
                self::PORTAL_PARENT_MESSAGING, self::PORTAL_PARENT_GRADES,
            ],
        ];
    }
}
