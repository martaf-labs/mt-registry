<?php

namespace Mt\MtSchoolCore\Enums;

enum PeriodType: string
{
    case TERM     = 'term';
    case SEMESTER = 'semester';
    case SEQUENCE = 'sequence';
    case ANNUAL   = 'annual';
    case OTHER    = 'other';

    public function label(): string
    {
        return __('mtschool::structure.period_type_' . $this->value);
    }

    /** A sequence is a child of a term/semester */
    public function isChild(): bool
    {
        return $this === self::SEQUENCE;
    }

    /** Can contain child sequences */
    public function isParent(): bool
    {
        return in_array($this, [self::TERM, self::SEMESTER]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
