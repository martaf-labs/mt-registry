<?php

namespace Mt\MtSchoolCore\Enums;

enum CycleType: string
{
    // Modèle Afrique francophone : le secondaire est scindé en 2 cycles distincts —
    // Collège (1er cycle, 6e→3e, BEPC) et Lycée (2nd cycle, 2nde→Tle, BAC).
    case PRESCHOOL = 'preschool';  // Maternelle / préscolaire
    case PRIMARY   = 'primary';    // Primaire (CP1→CM2, CEP)
    case COLLEGE   = 'college';    // Collège / secondaire 1er cycle (6e→3e, BEPC)
    case LYCEE     = 'lycee';      // Lycée / secondaire 2nd cycle (2nde→Tle, BAC)
    case HIGHER    = 'higher';     // Supérieur (LMD)

    public function label(): string
    {
        return __('mtschool::structure.cycle_type_' . $this->value);
    }

    public function badge(): string
    {
        return match ($this) {
            self::PRESCHOOL => 'pink',
            self::PRIMARY   => 'green',
            self::COLLEGE   => 'blue',
            self::LYCEE     => 'indigo',
            self::HIGHER    => 'purple',
        };
    }

    /** Does this cycle use the LMD (Bologna) system? */
    public function isLmd(): bool
    {
        return $this === self::HIGHER;
    }

    /** Filières / séries : lycée (L, S, ES…) et supérieur — PAS le collège (tronc commun). */
    public function hasSpecializations(): bool
    {
        return in_array($this, [self::LYCEE, self::HIGHER]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
