<?php

namespace Mt\MtSchoolCore\Enums;

/**
 * Types de champs personnalisés (EAV). Mappés sur les types de champs du
 * framework de formulaires mt-views (schema-driven).
 */
enum CustomFieldType: string
{
    case Text        = 'text';
    case Textarea    = 'textarea';
    case Number      = 'number';
    case Date        = 'date';
    case Email       = 'email';
    case Phone       = 'phone';
    case Toggle      = 'toggle';
    case Select      = 'select';
    case Multiselect = 'multiselect';

    /** Libellé humain traduit. */
    public function label(): string
    {
        return __('mtschool::custom_fields.type_' . $this->value);
    }

    /** Ce type nécessite une liste d'options. */
    public function hasOptions(): bool
    {
        return in_array($this, [self::Select, self::Multiselect], true);
    }

    /** La valeur est stockée en JSON (tableau) plutôt qu'en scalaire. */
    public function isMultiValue(): bool
    {
        return $this === self::Multiselect;
    }

    /** Type équivalent côté framework de formulaires mt-views. */
    public function formType(): string
    {
        return match ($this) {
            self::Phone       => 'text',
            self::Multiselect => 'select', // multiple=true géré à part
            default           => $this->value,
        };
    }

    /** Normalise une valeur brute (depuis la base) vers son type PHP. */
    public function cast(mixed $raw): mixed
    {
        if ($raw === null || $raw === '') {
            return $this->isMultiValue() ? [] : null;
        }

        return match ($this) {
            self::Number      => is_numeric($raw) ? $raw + 0 : null,
            self::Toggle      => filter_var($raw, FILTER_VALIDATE_BOOLEAN),
            self::Multiselect => is_array($raw) ? $raw : (json_decode($raw, true) ?: []),
            default           => (string) $raw,
        };
    }

    /** Sérialise une valeur PHP pour stockage (colonne TEXT). */
    public function serialize(mixed $value): ?string
    {
        if ($value === null || $value === '' || $value === []) {
            return null;
        }

        if ($this->isMultiValue()) {
            return json_encode(array_values((array) $value));
        }

        if ($this === self::Toggle) {
            return $value ? '1' : '0';
        }

        return (string) $value;
    }

    /** Règles de validation Laravel de base pour ce type. */
    public function validationRules(bool $required): array
    {
        $rules = [$required ? 'required' : 'nullable'];

        $rules[] = match ($this) {
            self::Number      => 'numeric',
            self::Date        => 'date',
            self::Email       => 'email',
            self::Toggle      => 'boolean',
            self::Multiselect => 'array',
            default           => 'string',
        };

        return $rules;
    }

    /** Liste pour un select (value => label). */
    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn (self $t) => [$t->value => $t->label()])
            ->all();
    }
}
