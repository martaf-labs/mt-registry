<?php

namespace Mt\MtSchoolCore\Enums;

enum Mention: string
{
    case EXCELLENT    = 'Excellent';
    case VERY_GOOD    = 'Very Good';
    case GOOD         = 'Good';
    case SATISFACTORY = 'Satisfactory';
    case PASSING      = 'Passing';
    case FAILING      = 'Failing';

    public function label(): string
    {
        return __('mtschool::academics.mention_' . strtolower(str_replace(' ', '_', $this->name)));
    }

    public function badge(): string
    {
        return match ($this) {
            self::EXCELLENT    => 'success',
            self::VERY_GOOD    => 'primary',
            self::GOOD         => 'info',
            self::SATISFACTORY => 'warning',
            self::PASSING      => 'warning',
            self::FAILING      => 'danger',
        };
    }

    public function minScore(): float
    {
        return match ($this) {
            self::EXCELLENT    => 18.0,
            self::VERY_GOOD    => 16.0,
            self::GOOD         => 14.0,
            self::SATISFACTORY => 12.0,
            self::PASSING      => 10.0,
            self::FAILING      => 0.0,
        };
    }

    public static function fromAverage(float $average): self
    {
        return match (true) {
            $average >= 18 => self::EXCELLENT,
            $average >= 16 => self::VERY_GOOD,
            $average >= 14 => self::GOOD,
            $average >= 12 => self::SATISFACTORY,
            $average >= 10 => self::PASSING,
            default        => self::FAILING,
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
