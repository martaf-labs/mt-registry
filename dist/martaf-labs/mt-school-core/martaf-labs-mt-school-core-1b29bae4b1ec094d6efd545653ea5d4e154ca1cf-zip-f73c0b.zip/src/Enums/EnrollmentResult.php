<?php

namespace Mt\MtSchoolCore\Enums;

enum EnrollmentResult: string
{
    case ADMITTED    = 'admitted';
    case RETAINED    = 'retained';
    case PROMOTED    = 'promoted';
    case EXPELLED    = 'expelled';
    case WITHDRAWN   = 'withdrawn';
    case TRANSFERRED = 'transferred';

    public function label(): string
    {
        return __('mtschool::students.enrollment_result_' . $this->value);
    }

    public function badge(): string
    {
        return match ($this) {
            self::ADMITTED    => 'success',
            self::RETAINED    => 'warning',
            self::PROMOTED    => 'info',
            self::EXPELLED    => 'danger',
            self::WITHDRAWN   => 'secondary',
            self::TRANSFERRED => 'primary',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
