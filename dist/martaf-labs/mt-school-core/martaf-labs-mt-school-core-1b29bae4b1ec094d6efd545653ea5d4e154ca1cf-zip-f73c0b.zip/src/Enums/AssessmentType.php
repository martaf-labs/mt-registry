<?php

namespace Mt\MtSchoolCore\Enums;

enum AssessmentType: string
{
    case TEST        = 'test';
    case EXAM        = 'exam';
    case QUIZ        = 'quiz';
    case LAB         = 'lab';
    case ORAL        = 'oral';
    case PROJECT     = 'project';
    case HOMEWORK    = 'homework';
    case OTHER       = 'other';

    public function label(): string
    {
        return __('mtschool::academics.assessment_type_' . $this->value);
    }

    public function abbreviation(): string
    {
        return match ($this) {
            self::TEST     => 'TS',
            self::EXAM     => 'EX',
            self::QUIZ     => 'QZ',
            self::LAB      => 'LAB',
            self::ORAL     => 'OR',
            self::PROJECT  => 'PJ',
            self::HOMEWORK => 'HW',
            self::OTHER    => 'OT',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::TEST     => 'primary',
            self::EXAM     => 'danger',
            self::QUIZ     => 'warning',
            self::LAB      => 'success',
            self::ORAL     => 'info',
            self::PROJECT  => 'purple',
            self::HOMEWORK => 'secondary',
            self::OTHER    => 'secondary',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
