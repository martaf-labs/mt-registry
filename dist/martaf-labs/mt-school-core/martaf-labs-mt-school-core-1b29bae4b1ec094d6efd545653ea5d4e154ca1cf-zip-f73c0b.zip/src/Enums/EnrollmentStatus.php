<?php

namespace Mt\MtSchoolCore\Enums;

enum EnrollmentStatus: string
{
    case PENDING     = 'pending';
    case VALIDATED   = 'validated';
    case REJECTED    = 'rejected';
    case CANCELLED   = 'cancelled';
    case TRANSFERRED = 'transferred';

    public function label(): string
    {
        return __('mtschool::students.enrollment_status_' . $this->value);
    }

    public function badge(): string
    {
        return match ($this) {
            self::PENDING     => 'warning',
            self::VALIDATED   => 'success',
            self::REJECTED    => 'danger',
            self::CANCELLED   => 'secondary',
            self::TRANSFERRED => 'info',
        };
    }

    public function color(): string
    {
        return match ($this) {
            self::PENDING     => '#f59e0b',
            self::VALIDATED   => '#10b981',
            self::REJECTED    => '#ef4444',
            self::CANCELLED   => '#6b7280',
            self::TRANSFERRED => '#3b82f6',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
