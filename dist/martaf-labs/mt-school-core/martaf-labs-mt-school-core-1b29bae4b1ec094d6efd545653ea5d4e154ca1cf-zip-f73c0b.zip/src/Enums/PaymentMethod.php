<?php

namespace Mt\MtSchoolCore\Enums;

enum PaymentMethod: string
{
    case CASH         = 'cash';
    case BANK_TRANSFER = 'bank_transfer';
    case CHECK        = 'check';
    case MOBILE_MONEY = 'mobile_money';
    case CARD         = 'card';
    case OTHER        = 'other';

    public function label(): string
    {
        // Traduisible : réutilise les clés method_* de lang/{fr,en,ar}/finances.php
        // (sinon « Cash » anglais en dur fuyait dans les portails parent/élève).
        return __('mtschool::finances.method_' . $this->value);
    }

    public function icon(): string
    {
        return match ($this) {
            self::CASH          => 'fa-money-bill',
            self::BANK_TRANSFER => 'fa-university',
            self::CHECK         => 'fa-file-invoice',
            self::MOBILE_MONEY  => 'fa-mobile-alt',
            self::CARD          => 'fa-credit-card',
            self::OTHER         => 'fa-ellipsis-h',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
