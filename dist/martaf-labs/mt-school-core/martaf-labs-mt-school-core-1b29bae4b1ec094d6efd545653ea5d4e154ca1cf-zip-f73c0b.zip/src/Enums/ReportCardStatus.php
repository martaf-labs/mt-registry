<?php

namespace Mt\MtSchoolCore\Enums;

enum ReportCardStatus: string
{
    case DRAFT     = 'draft';
    case GENERATED = 'generated';
    case VALIDATED = 'validated';
    case PUBLISHED = 'published';
    case ARCHIVED  = 'archived';

    public function label(): string
    {
        return match ($this) {
            self::DRAFT     => 'Draft',
            self::GENERATED => 'Generated',
            self::VALIDATED => 'Validated',
            self::PUBLISHED => 'Published',
            self::ARCHIVED  => 'Archived',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::DRAFT     => 'secondary',
            self::GENERATED => 'info',
            self::VALIDATED => 'primary',
            self::PUBLISHED => 'success',
            self::ARCHIVED  => 'dark',
        };
    }

    public function isPublishable(): bool
    {
        return $this === self::VALIDATED;
    }

    public function isVisible(): bool
    {
        return $this === self::PUBLISHED;
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
