<?php

namespace Mt\MtSchoolCore\Enums;

enum DayOfWeek: int
{
    case MONDAY    = 1;
    case TUESDAY   = 2;
    case WEDNESDAY = 3;
    case THURSDAY  = 4;
    case FRIDAY    = 5;
    case SATURDAY  = 6;
    case SUNDAY    = 7;

    public function label(): string
    {
        return match ($this) {
            self::MONDAY    => 'Monday',
            self::TUESDAY   => 'Tuesday',
            self::WEDNESDAY => 'Wednesday',
            self::THURSDAY  => 'Thursday',
            self::FRIDAY    => 'Friday',
            self::SATURDAY  => 'Saturday',
            self::SUNDAY    => 'Sunday',
        };
    }

    public function abbreviation(): string
    {
        return match ($this) {
            self::MONDAY    => 'Mon',
            self::TUESDAY   => 'Tue',
            self::WEDNESDAY => 'Wed',
            self::THURSDAY  => 'Thu',
            self::FRIDAY    => 'Fri',
            self::SATURDAY  => 'Sat',
            self::SUNDAY    => 'Sun',
        };
    }

    public function isWeekend(): bool
    {
        return in_array($this, [self::SATURDAY, self::SUNDAY]);
    }

    public static function workdays(): array
    {
        return [self::MONDAY, self::TUESDAY, self::WEDNESDAY, self::THURSDAY, self::FRIDAY];
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
