<?php

namespace Mt\MtSchoolCore\Traits;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Schema;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * À ajouter sur tout modèle rattaché à une année scolaire.
 *
 *   - applique le global scope (filtrage auto par année active)
 *   - remplit automatiquement `school_year_id` à la création (année active)
 *   - expose la relation schoolYear()
 *
 * Pour un modèle indirect (sans colonne school_year_id), définir en plus :
 *   public function getSchoolYearRelationChain(): array { return ['enrollment']; }
 */
trait BelongsToSchoolYear
{
    public static function bootBelongsToSchoolYear(): void
    {
        static::addGlobalScope(new SchoolYearScope);

        static::creating(function ($model) {
            if (empty($model->school_year_id)
                && Schema::hasColumn($model->getTable(), 'school_year_id')) {
                $model->school_year_id = activeSchoolYearId();
            }
        });
    }

    public function schoolYear(): BelongsTo
    {
        return $this->belongsTo(SchoolYear::class, 'school_year_id');
    }
}
