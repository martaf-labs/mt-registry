<?php

namespace Mt\MtSchoolCore\Traits;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Schema;
use Mt\MtSchoolCore\Models\CustomField;
use Mt\MtSchoolCore\Models\CustomFieldValue;

/**
 * À poser sur tout modèle d'entité qui doit accepter des champs personnalisés
 * définis PAR ÉCOLE (EAV). Cf. CustomField / CustomFieldValue.
 *
 *   - `customFieldEntityType()` : clé logique ('student'…), résolue depuis
 *     config('mt-school-core.custom_fields.entities') par défaut. Surchargeable
 *     via la propriété statique `$customFieldEntityType`.
 *   - les définitions et valeurs restent TENANT (SchoolScope sur CustomField*).
 *
 * Au delete de l'entité, ses valeurs sont nettoyées (les clés EAV ne sont pas
 * des FK SQL vers l'entité).
 */
trait HasCustomFields
{
    /** Override possible : `protected static string $customFieldEntityType = 'student';` */

    public static function bootHasCustomFields(): void
    {
        static::deleting(function ($model) {
            // Évite d'orpheliner des valeurs (entity_id n'est pas une FK SQL).
            $model->customFieldValues()->delete();
        });
    }

    /** Clé logique de l'entité (ex. 'student'). */
    public function customFieldEntityType(): string
    {
        if (isset(static::$customFieldEntityType)) {
            return static::$customFieldEntityType;
        }

        $map = config('mt-school-core.custom_fields.entities', []);
        foreach ($map as $key => $def) {
            if (($def['model'] ?? null) === static::class) {
                return $key;
            }
        }

        // Repli : nom de classe en snake (refactor-safe via config recommandé).
        return \Illuminate\Support\Str::snake(class_basename(static::class));
    }

    // ── Relations ───────────────────────────────────────────────────────────────

    public function customFieldValues(): HasMany
    {
        return $this->hasMany(CustomFieldValue::class, 'entity_id')
            ->where('custom_field_values.entity_type', $this->customFieldEntityType());
    }

    // ── Définitions (schéma de l'école) ──────────────────────────────────────────

    /** Champs actifs définis par l'école courante pour ce type d'entité. */
    public function customFieldDefinitions(): Collection
    {
        return CustomField::query()
            ->forEntity($this->customFieldEntityType())
            ->active()
            ->orderBy('position')
            ->get();
    }

    // ── Lecture ──────────────────────────────────────────────────────────────────

    /** Valeurs typées indexées par clé de champ : ['matricule_interne' => '…', …]. */
    public function customFieldData(): array
    {
        if (! $this->exists) {
            return [];
        }

        $values = $this->customFieldValues()->with('field')->get()
            ->keyBy(fn (CustomFieldValue $v) => $v->field?->key);

        $out = [];
        foreach ($this->customFieldDefinitions() as $field) {
            $raw = $values->get($field->key)?->value;
            $out[$field->key] = $field->type->cast($raw);
        }

        return $out;
    }

    /** Valeur typée d'un champ par sa clé. */
    public function customField(string $key): mixed
    {
        $field = CustomField::query()
            ->forEntity($this->customFieldEntityType())
            ->where('key', $key)
            ->first();

        if (! $field) {
            return null;
        }

        $value = $this->customFieldValues()
            ->where('custom_field_id', $field->id)
            ->first();

        return $field->type->cast($value?->value);
    }

    // ── Écriture ─────────────────────────────────────────────────────────────────

    /**
     * Persiste un lot de valeurs (['key' => valeur, …]). Upsert par champ.
     * Les clés inconnues (non définies par l'école) sont ignorées.
     */
    public function saveCustomFields(array $data): void
    {
        if (empty($data)) {
            return;
        }

        $fields = $this->customFieldDefinitions()->keyBy('key');
        $entityType = $this->customFieldEntityType();

        foreach ($data as $key => $value) {
            $field = $fields->get($key);
            if (! $field) {
                continue;
            }

            $serialized = $field->type->serialize($value);

            if ($serialized === null) {
                // Valeur vide → suppression DURE : un soft-delete laisserait un fantôme
                // qui, à la ré-saisie, ferait échouer l'INSERT sur l'unique
                // (custom_field_id, entity_id) → crash SQL 1062.
                CustomFieldValue::where('custom_field_id', $field->id)
                    ->where('entity_id', $this->getKey())
                    ->forceDelete();
                continue;
            }

            // Réactive un éventuel enregistrement soft-deleted (au lieu d'un INSERT qui
            // heurterait l'unique) ; sinon en crée un.
            $existing = CustomFieldValue::withTrashed()
                ->where('custom_field_id', $field->id)
                ->where('entity_id', $this->getKey())
                ->first();

            if ($existing) {
                $existing->forceFill([
                    'entity_type' => $entityType, 'value' => $serialized, 'deleted_at' => null,
                ])->save();
            } else {
                CustomFieldValue::create([
                    'custom_field_id' => $field->id, 'entity_id' => $this->getKey(),
                    'entity_type' => $entityType, 'value' => $serialized,
                ]);
            }
        }
    }
}
