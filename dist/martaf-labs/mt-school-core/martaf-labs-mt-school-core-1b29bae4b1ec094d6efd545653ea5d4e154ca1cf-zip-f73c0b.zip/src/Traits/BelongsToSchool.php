<?php

namespace Mt\MtSchoolCore\Traits;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Schema;
use Mt\MtSchoolCore\Models\School;
use Mt\MtSchoolCore\Scopes\SchoolScope;

/**
 * À ajouter sur TOUT modèle métier appartenant à une école (le tenant).
 *
 *   - applique le global scope (filtrage auto par école courante)
 *   - remplit automatiquement `school_id` à la création (école courante)
 *   - expose la relation school()
 *
 * S'empile AU-DESSUS de BelongsToSchoolYear : Tenant (école) → Année → données.
 *
 * Pour un modèle indirect (sans colonne school_id), définir en plus :
 *   public function getSchoolRelationChain(): array { return ['enrollment']; }
 */
trait BelongsToSchool
{
    public static function bootBelongsToSchool(): void
    {
        static::addGlobalScope(new SchoolScope);

        static::creating(function ($model) {
            if (empty($model->school_id)
                && Schema::hasColumn($model->getTable(), 'school_id')) {
                $model->school_id = currentSchoolId();
            }
        });
    }

    public function school(): BelongsTo
    {
        return $this->belongsTo(School::class, 'school_id');
    }
}
