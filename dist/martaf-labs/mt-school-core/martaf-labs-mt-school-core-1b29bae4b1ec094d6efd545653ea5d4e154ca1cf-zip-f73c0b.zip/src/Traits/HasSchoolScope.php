<?php

namespace Mt\MtSchoolCore\Traits;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

/**
 * Scope automatique par school_id.
 *
 * À utiliser sur tous les modèles qui ont une colonne school_id.
 * Le super_admin voit tout ; les autres rôles sont filtrés sur leur école.
 */
trait HasSchoolScope
{
    public static function bootHasSchoolScope(): void
    {
        static::addGlobalScope('school', function (Builder $query) {
            $user = Auth::user();

            if (!$user) {
                return;
            }

            // Le super_admin accède à toutes les écoles
            if ($user->hasRole('super_admin')) {
                return;
            }

            // Tous les autres rôles sont scopés à leur school_id
            if ($schoolId = $user->school_id) {
                $query->where(static::qualifyColumn('school_id'), $schoolId);
            }
        });
    }

    /** Retourne l'école courante de l'utilisateur connecté. */
    public static function forSchool(int $schoolId): Builder
    {
        return static::withoutGlobalScope('school')
            ->where('school_id', $schoolId);
    }

    /** Retire le scope école pour une requête admin cross-tenant. */
    public static function allSchools(): Builder
    {
        return static::withoutGlobalScope('school');
    }
}
