<?php

use Mt\MtSchoolCore\Models\School;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Support\SchoolResolver;
use Mt\MtSchoolCore\Support\SchoolYearResolver;

// ──────────────────────────────────────────────────────────────────────────────
// CONFIG
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('mtschool_config')) {
    function mtschool_config(string $key, mixed $default = null): mixed
    {
        return config("mtschool.{$key}", $default);
    }
}

if (!function_exists('school_info')) {
    function school_info(string $key, string $default = ''): string
    {
        return config("mtschool.institution.{$key}", $default);
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// SCHOOL YEAR
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('activeSchoolYear')) {
    function activeSchoolYear(): ?SchoolYear
    {
        return app(SchoolYearResolver::class)->current();
    }
}

if (!function_exists('activeSchoolYearId')) {
    function activeSchoolYearId(): ?int
    {
        return app(SchoolYearResolver::class)->currentId();
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// SCHOOL (TENANT)
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('currentSchool')) {
    function currentSchool(): ?School
    {
        return app(SchoolResolver::class)->current();
    }
}

if (!function_exists('currentSchoolId')) {
    function currentSchoolId(): ?int
    {
        return app(SchoolResolver::class)->currentId();
    }
}

if (!function_exists('moduleEnabled')) {
    /**
     * Un module est-il actif pour l'école courante ?
     *
     * Avec un abonnement actif → on respecte les modules du plan (gating réel).
     * Sans abonnement (dev, console, avant achat) → repli sur la config `.env`
     * (`mt-school-core.<code>.enabled`, défaut true) pour ne pas bloquer le dev.
     */
    function moduleEnabled(string $code): bool
    {
        $school = currentSchool();

        // Une école existe → STRICT : modules du plan de son abonnement ACTIF
        // (abonnement expiré ou absent → seulement les modules de base via hasModule()).
        if ($school) {
            return $school->hasModule($code);
        }

        // Hors tenant (console, avant connexion) → repli config dev pour ne pas tout bloquer.
        return (bool) config("mt-school-core.{$code}.enabled", true);
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// MODULES
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('moduleActive')) {
    function moduleActive(string $module): bool
    {
        return config("mtschool.{$module}.enabled", true);
    }
}

if (!function_exists('multilingualActive')) {
    function multilingualActive(): bool
    {
        return config('mtschool.multilingual.enabled', false);
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// GRADING
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('passingGrade')) {
    function passingGrade(): float
    {
        return (float) config('mtschool.grading.passing_grade', 10);
    }
}

if (!function_exists('maximumGrade')) {
    function maximumGrade(): float
    {
        return (float) config('mtschool.grading.max_grade', 20);
    }
}

if (!function_exists('isPassing')) {
    function isPassing(float $average): bool
    {
        return $average >= passingGrade();
    }
}

if (!function_exists('formatGrade')) {
    function formatGrade(?float $grade, ?int $decimals = null): string
    {
        if ($grade === null) return '—';
        $dec = $decimals ?? (int) config('mtschool.grading.decimal_places', 2);
        return number_format($grade, $dec, '.', '');
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// CURRENCY & AMOUNTS
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('schoolCurrency')) {
    function schoolCurrency(): string
    {
        return config('mtschool.institution.currency', 'XAF');
    }
}

if (!function_exists('formatAmount')) {
    function formatAmount(float $amount, ?string $currency = null): string
    {
        $currency = $currency ?? schoolCurrency();
        $formatted = number_format($amount, 0, ',', ' ');
        return "{$formatted} {$currency}";
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// MULTILINGUAL
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('school_locale')) {
    function school_locale(): string
    {
        return session('mt_locale', config('mtschool.multilingual.default', app()->getLocale()));
    }
}

if (!function_exists('school_languages')) {
    /**
     * Langues d'enseignement de l'école courante (setting `teaching_languages`),
     * dans l'ORDRE défini au setup (la 1re = langue principale). Repli ['fr'].
     * Source de vérité pour les imports/exports multilingues (jamais la config en dur).
     *
     * @return array<int,string> ex. ['ar','fr','en']
     */
    function school_languages(): array
    {
        try {
            $langs = \Mt\MtSchoolCore\Models\Setting::getJson('teaching_languages', []);
        } catch (\Throwable) {
            $langs = [];
        }
        return (! empty($langs) && is_array($langs)) ? array_values($langs) : ['fr'];
    }
}

if (!function_exists('school_primary_language')) {
    /** Langue PRINCIPALE de l'école (1re de teaching_languages). Repli 'fr'. */
    function school_primary_language(): string
    {
        return school_languages()[0] ?? 'fr';
    }
}

if (!function_exists('school_trans')) {
    function school_trans(string $key, array $replace = [], ?string $locale = null): string
    {
        return (string) trans("mtschool::{$key}", $replace, $locale ?? school_locale());
    }
}

if (!function_exists('school_label')) {
    /**
     * Return the translated value from a multilingual JSON field.
     * Usage: school_label($schoolYear->label) → "Year 2024-2025"
     *
     * @param array|string|null $label  JSON field: ['fr'=>'...','en'=>'...','ar'=>'...']
     */
    function school_label(array|string|null $label, ?string $locale = null): string
    {
        if (empty($label)) return '';
        if (is_string($label)) {
            $decoded = json_decode($label, true);
            if (!is_array($decoded)) return $label;
            $label = $decoded;
        }
        $locale  = $locale ?? school_locale();
        $default = config('mtschool.multilingual.default', 'fr');
        return $label[$locale] ?? $label[$default] ?? reset($label) ?? '';
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// DYNAMIC SETTINGS
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('school_param')) {
    function school_param(string $key, mixed $default = null): mixed
    {
        return \Mt\MtSchoolCore\Models\SchoolSetting::get($key, $default);
    }
}
