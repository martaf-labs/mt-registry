<?php

namespace Mt\MtSchoolCore\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Support\Facades\Schema;

/**
 * Filtre automatiquement toute requête par l'année scolaire active.
 *
 * L'année scolaire est le socle du système : on ne filtre jamais à la main.
 * Trois cas gérés :
 *   1. Colonne directe `school_year_id`
 *   2. Chaîne de relations (modèles indirects) via getSchoolYearRelationChain()
 *      ex. Grade → enrollment → school_year_id  ⇒  ['enrollment']
 *
 * Désactivation ponctuelle : Model::withoutGlobalScope(SchoolYearScope::class)
 */
class SchoolYearScope implements Scope
{
    public function apply(Builder $builder, Model $model): void
    {
        $yearId = activeSchoolYearId();

        // Aucune année active (ex. tout premier setup) → pas de filtre
        if (! $yearId) {
            return;
        }

        $table = $model->getTable();

        // Cas 1 : colonne directe
        if (Schema::hasColumn($table, 'school_year_id')) {
            $builder->where($table . '.school_year_id', $yearId);
            return;
        }

        // Cas 2 : chaîne de relations (modèle indirect)
        if (method_exists($model, 'getSchoolYearRelationChain')) {
            $chain = $model->getSchoolYearRelationChain();
            if (! empty($chain)) {
                $builder->whereHas($chain[0], fn ($q) => $this->applyChain($q, array_slice($chain, 1), $yearId));
            }
        }
    }

    protected function applyChain(Builder $query, array $chain, int $yearId): void
    {
        if (empty($chain)) {
            $query->where('school_year_id', $yearId);
            return;
        }

        $query->whereHas($chain[0], fn ($q) => $this->applyChain($q, array_slice($chain, 1), $yearId));
    }
}
