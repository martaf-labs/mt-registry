<?php

namespace Mt\MtSchoolCore\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Support\Facades\Schema;
use Mt\MtSchoolCore\Support\SchoolResolver;

/**
 * Filtre automatiquement toute requête par l'ÉCOLE courante (le tenant).
 *
 * C'est le cran d'isolation au-dessus de l'année. Hiérarchie : École → Année → données.
 *
 * Cas gérés :
 *   1. Colonne directe `school_id`
 *   2. Chaîne de relations via getSchoolRelationChain()  (modèles indirects)
 *
 * Garde anti-fuite (base partagée) :
 *   - école courante résolue            → on filtre par elle ;
 *   - pas d'école MAIS user authentifié → résultat VIDE (jamais toutes les écoles) ;
 *   - pas d'école et pas d'auth (console/seed/job) → pas de filtre (contexte de confiance).
 *
 * Désactivation explicite : Model::withoutGlobalScope(SchoolScope::class)
 */
class SchoolScope implements Scope
{
    public function apply(Builder $builder, Model $model): void
    {
        $resolver = app(SchoolResolver::class);
        $schoolId = $resolver->currentId();
        $table    = $model->getTable();

        if ($schoolId) {
            $this->filter($builder, $model, $table, $schoolId);
            return;
        }

        // Pas d'école courante : un user connecté ne doit JAMAIS voir d'autres tenants.
        if ($resolver->hasAuthenticatedUser()) {
            $builder->whereRaw('1 = 0');
            return;
        }

        // Console / seed / job non authentifié → contexte de confiance, pas de filtre.
    }

    protected function filter(Builder $builder, Model $model, string $table, int $schoolId): void
    {
        // Cas 1 : colonne directe
        if (Schema::hasColumn($table, 'school_id')) {
            $builder->where($table . '.school_id', $schoolId);
            return;
        }

        // Cas 2 : chaîne de relations (modèle indirect)
        if (method_exists($model, 'getSchoolRelationChain')) {
            $chain = $model->getSchoolRelationChain();
            if (! empty($chain)) {
                $builder->whereHas($chain[0], fn ($q) => $this->applyChain($q, array_slice($chain, 1), $schoolId));
            }
        }
    }

    protected function applyChain(Builder $query, array $chain, int $schoolId): void
    {
        if (empty($chain)) {
            $query->where('school_id', $schoolId);
            return;
        }

        $query->whereHas($chain[0], fn ($q) => $this->applyChain($q, array_slice($chain, 1), $schoolId));
    }
}
