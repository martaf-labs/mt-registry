<?php

namespace Mt\MtSchoolCore\Support;

use Illuminate\Support\Facades\Auth;
use Mt\MtSchoolCore\Models\School;

/**
 * Résout l'école courante (= le TENANT), par requête.
 *
 * Priorité :
 *   1. session('current_school_id')            — fixée par le middleware tenant / l'onboarding
 *   2. auth()->user()->school_id               — l'école du user connecté (cas normal)
 *   3. [TRANSITOIRE] première école active     — uniquement tant que le multi-tenant
 *      n'est pas déployé (flag `mt-school-core.tenant.transitional_single_school`).
 *      À RETIRER avant d'ouvrir le SaaS à plusieurs écoles (sinon fuite de données).
 *
 * L'école courante n'est JAMAIS un singleton « première active » en production.
 */
class SchoolResolver
{
    protected ?School $current = null;
    protected bool $resolved = false;

    public function current(): ?School
    {
        if ($this->resolved) {
            return $this->current;
        }
        $this->resolved = true;

        // 1. Utilisateur authentifié → SON école est l'AUTORITÉ ABSOLUE (source de vérité
        //    `users.school_id`). Y COMPRIS si elle est NULL : un user sans école n'a AUCUN
        //    tenant → aucune donnée. On NE retombe PAS sur la session ni le singleton, sinon
        //    un user authentifié mais sans école (ex. inscription libre) serait scopé vers
        //    une AUTRE école (session périmée / première active) = FUITE CROSS-TENANT.
        if (Auth::check()) {
            $userSchoolId = Auth::user()?->school_id;

            return $this->current = $userSchoolId
                ? School::withoutGlobalScopes()->find($userSchoolId)
                : null;
        }

        // 2. Aucun utilisateur authentifié (onboarding avant rattachement, contexte public).
        $sessionId = session('current_school_id');
        if ($sessionId) {
            return $this->current = School::withoutGlobalScopes()->find($sessionId);
        }

        // 3. Repli TRANSITOIRE (dev mono-école) — à désactiver au déploiement.
        if (config('mt-school-core.tenant.transitional_single_school', true)) {
            return $this->current = School::withoutGlobalScopes()->where('active', true)->first();
        }

        return $this->current = null;
    }

    public function currentId(): ?int
    {
        return $this->current()?->id;
    }

    /** Y a-t-il un utilisateur authentifié (contexte tenant à isoler) ? */
    public function hasAuthenticatedUser(): bool
    {
        return Auth::check();
    }

    /** Fixe l'école courante (session) — onboarding, changement de tenant. */
    public function setCurrent(int $schoolId): self
    {
        session(['current_school_id' => $schoolId]);
        return $this->refresh();
    }

    public function refresh(): self
    {
        $this->current  = null;
        $this->resolved = false;
        return $this;
    }
}
