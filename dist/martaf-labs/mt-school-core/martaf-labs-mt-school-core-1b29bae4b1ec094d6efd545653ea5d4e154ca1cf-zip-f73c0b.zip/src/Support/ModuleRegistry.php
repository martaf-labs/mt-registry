<?php

namespace Mt\MtSchoolCore\Support;

use Mt\MtSchoolCore\Models\Module;
use Mt\MtSchoolCore\Models\Plan;

/**
 * Source de vérité des modules et plans tarifaires (v0, ajustable).
 *
 * Les MODULES sont déclarés ici (chaque module = une aire fonctionnelle).
 * Les PLANS et leur composition par défaut aussi — mais une fois en base, le
 * super-admin plateforme peut réassigner les modules aux plans (pivot éditable).
 *
 * `seed()` est idempotent : upsert par `code`, sans casser les associations
 * personnalisées existantes (il n'attache que les manquantes du défaut).
 */
class ModuleRegistry
{
    /** Modules disponibles. `is_core` = inclus dans tous les plans. */
    public static function modules(): array
    {
        return [
            // ── Base (is_core) : gestion minimale d'une école ──
            ['code' => 'structure',     'is_core' => true, 'group' => 'Gestion',        'order' => 1,
             'name' => ['fr' => 'Structure & socle',        'en' => 'Structure',          'ar' => 'الهيكل']],
            ['code' => 'students',      'is_core' => true, 'group' => 'Scolarité',      'order' => 2,
             'name' => ['fr' => 'Inscriptions & élèves',    'en' => 'Enrolment & students','ar' => 'التسجيل والطلاب']],
            ['code' => 'grades',        'is_core' => true, 'group' => 'Scolarité',      'order' => 3,
             'name' => ['fr' => 'Évaluations & notes',      'en' => 'Assessment & grades','ar' => 'التقييم والدرجات']],
            ['code' => 'staff',         'is_core' => true, 'group' => 'Gestion',        'order' => 4,
             'name' => ['fr' => 'Personnel',                'en' => 'Staff',              'ar' => 'الموظفون']],
            ['code' => 'communication', 'is_core' => true, 'group' => 'Communication',  'order' => 5,
             'name' => ['fr' => 'Communication',            'en' => 'Communication',      'ar' => 'التواصل']],

            // ── Optionnels (payants) ──
            ['code' => 'attendance', 'is_core' => false, 'group' => 'Vie scolaire', 'order' => 10,
             'name' => ['fr' => 'Présences & vie scolaire', 'en' => 'Attendance',  'ar' => 'الحضور']],
            ['code' => 'finance',    'is_core' => false, 'group' => 'Finances',     'order' => 11,
             'name' => ['fr' => 'Finances & comptabilité',  'en' => 'Finance',     'ar' => 'المالية']],
            ['code' => 'timetable',  'is_core' => false, 'group' => 'Scolarité',    'order' => 12,
             'name' => ['fr' => 'Emploi du temps',          'en' => 'Timetable',   'ar' => 'الجدول الزمني']],
            ['code' => 'pedagogy',   'is_core' => false, 'group' => 'Pédagogie',    'order' => 13,
             'name' => ['fr' => 'Pédagogie avancée',        'en' => 'Pedagogy',    'ar' => 'علم أصول التدريس']],
            ['code' => 'messaging',  'is_core' => false, 'group' => 'Communication','order' => 14,
             'name' => ['fr' => 'Messagerie & calendrier',  'en' => 'Messaging',   'ar' => 'المراسلة']],
            ['code' => 'imports',    'is_core' => false, 'group' => 'Outils',       'order' => 15,
             'name' => ['fr' => 'Import / Export',          'en' => 'Import/Export','ar' => 'استيراد/تصدير']],
            ['code' => 'custom_fields', 'is_core' => false, 'group' => 'Outils',    'order' => 16,
             'name' => ['fr' => 'Champs personnalisés',     'en' => 'Custom fields','ar' => 'حقول مخصصة']],
        ];
    }

    /** Plans par défaut. `modules` = codes des modules OPTIONNELS inclus (core implicites). */
    public static function plans(): array
    {
        return [
            ['code' => 'essentiel', 'price' => 50000,  'max_students' => 150,  'order' => 1,
             'name' => ['fr' => 'Essentiel', 'en' => 'Essential', 'ar' => 'أساسي'],
             'description' => ['fr' => 'Gestion minimale : inscriptions, notes, personnel.'],
             'modules' => []],

            ['code' => 'standard',  'price' => 150000, 'max_students' => 500,  'order' => 2,
             'name' => ['fr' => 'Standard', 'en' => 'Standard', 'ar' => 'قياسي'],
             'description' => ['fr' => 'Essentiel + présences, finances et emploi du temps.'],
             'modules' => ['attendance', 'finance', 'timetable']],

            ['code' => 'premium',   'price' => 300000, 'max_students' => null, 'order' => 3,
             'name' => ['fr' => 'Premium', 'en' => 'Premium', 'ar' => 'متميز'],
             'description' => ['fr' => 'Tous les modules, élèves illimités.'],
             'modules' => ['attendance', 'finance', 'timetable', 'pedagogy', 'messaging', 'imports', 'custom_fields']],
        ];
    }

    /** Upsert idempotent des modules + plans + associations par défaut. */
    public static function seed(): void
    {
        foreach (static::modules() as $m) {
            Module::updateOrCreate(
                ['code' => $m['code']],
                [
                    'name'    => $m['name'],
                    'group'   => $m['group'],
                    'is_core' => $m['is_core'],
                    'order'   => $m['order'],
                    'active'  => true,
                ]
            );
        }

        foreach (static::plans() as $p) {
            $plan = Plan::updateOrCreate(
                ['code' => $p['code']],
                [
                    'name'         => $p['name'],
                    'description'  => $p['description'] ?? null,
                    'price'        => $p['price'],
                    'currency'     => 'XAF',
                    'max_students' => $p['max_students'],
                    'is_public'    => true,
                    'active'       => true,
                    'order'        => $p['order'],
                ]
            );

            // Attache les modules optionnels par défaut sans détacher les ajouts manuels.
            $moduleIds = Module::whereIn('code', $p['modules'])->pluck('id')->all();
            $plan->modules()->syncWithoutDetaching($moduleIds);
        }
    }
}
