<?php

namespace Mt\MtSchoolCore\Support;

/**
 * Gate de gating du menu mt-views par module d'abonnement.
 * Branché via config('mt-views.module_gate') dans le service provider.
 */
class SchoolModuleGate
{
    public function enabled(string $code): bool
    {
        return moduleEnabled($code);
    }
}
