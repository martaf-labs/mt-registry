<?php

namespace Mt\MtSchoolCore\Support;

use Mt\MtSchoolCore\Models\SchoolYear;

/**
 * Résout l'année scolaire « active » (= socle du système), par requête.
 *
 * Priorité : session('school_year_id') (permet de consulter une année passée)
 *            puis l'année marquée is_active en base.
 */
class SchoolYearResolver
{
    protected ?SchoolYear $current = null;
    protected bool $resolved = false;

    public function current(): ?SchoolYear
    {
        if ($this->resolved) {
            return $this->current;
        }
        $this->resolved = true;

        $sessionId = session('school_year_id');

        $this->current = $sessionId
            ? SchoolYear::find($sessionId)
            : null;

        // Fallback : année marquée active en base
        $this->current ??= SchoolYear::where('is_active', true)->first();

        return $this->current;
    }

    public function currentId(): ?int
    {
        return $this->current()?->id;
    }

    public function currentLabel(): string
    {
        return $this->current()?->code ?? '';
    }

    /** Change l'année consultée (stockée en session). */
    public function setCurrent(int $schoolYearId): self
    {
        session(['school_year_id' => $schoolYearId]);
        return $this->refresh();
    }

    /** Invalide le cache (après activation d'une nouvelle année). */
    public function refresh(): self
    {
        $this->current  = null;
        $this->resolved = false;
        return $this;
    }
}
