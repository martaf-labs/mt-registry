<?php

namespace Mt\MtSchoolCore\Support;

use Mt\MtSchoolCore\Models\School;

/**
 * Fournit le brand (nom + logo) à mt-views pour l'école courante.
 * Branché via config('mt-views.brand_resolver') dans le service provider.
 *
 * Nom = sigle (short_name) si fourni, sinon nom complet (tronqué côté CSS).
 */
class SchoolBrandResolver
{
    /**
     * La marque d'ÉCOLE n'existe que pour un utilisateur CONNECTÉ (son tenant).
     * Pages publiques (login, pricing, checkout…) = marque de la PLATEFORME :
     * on renvoie null → mt_brand_name() retombe sur mt-views.app_name.
     * Sinon, une session périmée (current_school_id) faisait brander la page de
     * connexion — partagée par toutes les écoles — au sigle d'une école particulière.
     */
    protected function currentSchoolForBrand(): ?School
    {
        return auth()->check() ? School::current() : null;
    }

    public function name(): ?string
    {
        $school = $this->currentSchoolForBrand();

        return $school?->short_name ?: $school?->name;
    }

    public function logoUrl(): ?string
    {
        return $this->currentSchoolForBrand()?->logoUrl();
    }
}
