<?php

namespace Mt\MtSchoolCore\Support;

use Barryvdh\DomPDF\Facade\Pdf;

/**
 * Rendu PDF localisé : DomPDF ne « façonne » pas l'arabe (lettres détachées + ordre LTR).
 * Pour les locales RTL, on met en forme (glyphes contextuels + ordre visuel) le texte via
 * ar-php `utf8Glyphs`, mais UNIQUEMENT les nœuds texte (le balisage HTML reste intact).
 *
 * No-op pour fr/en (aucune régression) et si la lib ar-php est absente (repli silencieux).
 */
trait RendersLocalizedPdf
{
    /** Locales à façonner (droite-à-gauche). */
    protected array $rtlLocales = ['ar', 'fa', 'ur', 'ps', 'ku', 'dv', 'he'];

    protected function renderPdf(string $view, array $data, string $paper = 'a4', string $orientation = 'portrait')
    {
        $html = view($view, $data)->render();
        $html = $this->shapeRtlHtml($html);

        return Pdf::loadHTML($html)->setPaper($paper, $orientation);
    }

    /** Met en forme les nœuds texte arabes d'un HTML ; renvoie le HTML inchangé sinon. */
    protected function shapeRtlHtml(string $html): string
    {
        if (! in_array(app()->getLocale(), $this->rtlLocales, true)
            || ! class_exists(\ArPHP\I18N\Arabic::class)) {
            return $html;
        }

        $arabic = new \ArPHP\I18N\Arabic();

        // Ne façonne que le texte ENTRE deux balises (jamais les tags ni les attributs),
        // et seulement s'il contient de l'arabe → latin/chiffres/balises préservés.
        return preg_replace_callback(
            '/>([^<]+)</u',
            function (array $m) use ($arabic): string {
                if (! preg_match('/[\x{0600}-\x{06FF}]/u', $m[1])) {
                    return $m[0];
                }
                // max_chars élevé → pas de retour à la ligne forcé (le flux HTML gère l'habillage).
                return '>' . $arabic->utf8Glyphs($m[1], 2000) . '<';
            },
            $html,
        ) ?? $html;
    }
}
