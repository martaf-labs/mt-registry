<?php

namespace Mt\MtSchoolCore\Contracts;

use Mt\MtSchoolCore\DTOs\PaymentResult;

/**
 * Passerelle de paiement. Une seule implémentation factice pour l'instant
 * (FakeGateway) ; remplaçable par Stripe/Mobile Money sans toucher au reste.
 */
interface PaymentGatewayContract
{
    public function name(): string;

    /**
     * Tente de débiter $amount. $context peut porter plan, school_id, email…
     */
    public function charge(float $amount, string $currency, array $context = []): PaymentResult;
}
