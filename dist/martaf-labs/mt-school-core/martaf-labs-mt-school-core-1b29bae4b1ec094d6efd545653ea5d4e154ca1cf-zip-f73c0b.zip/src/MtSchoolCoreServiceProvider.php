<?php

namespace Mt\MtSchoolCore;

use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Gate;
use Mt\MtSchoolCore\Models\User as SchoolUser;
use Mt\MtFoundation\MtServiceProvider;
use Livewire\Livewire;
use Mt\MtSchoolCore\Events\EnrollmentValidated;
use Mt\MtSchoolCore\Events\GradesEntered;
use Mt\MtSchoolCore\Events\ReportCardPublished;
use Mt\MtSchoolCore\Events\PaymentReceived;
use Mt\MtSchoolCore\Events\AbsenceRecorded;
use Mt\MtSchoolCore\Listeners\RecalculateClassroomEnrollment;
use Mt\MtSchoolCore\Listeners\NotifyParentAbsence;
use Mt\MtSchoolCore\Listeners\NotifyReportCardAvailable;
use Mt\MtSchoolCore\Listeners\NotifyPaymentConfirmed;
use Mt\MtSchoolCore\Services\ReferenceSchoolService;
use Mt\MtSchoolCore\Services\ReportCardService;
use Mt\MtSchoolCore\Services\ReportCardComputer;
use Mt\MtSchoolCore\Services\AverageService;
use Mt\MtSchoolCore\Support\SchoolResolver;
use Mt\MtSchoolCore\Support\SchoolYearResolver;

class MtSchoolCoreServiceProvider extends MtServiceProvider
{

    // =========================================================================
    // REGISTER
    // =========================================================================

    public function register(): void
    {
        $this->mergeConfigFrom(
            $this->basePath . '/config/mt-school-core.php',
            'mt-school-core'
        );

        // Fournit le modèle Media concret au package mt-media tant que l'app
        // n'a pas surchargé (via config publiée ou MT_MEDIA_MODEL).
        if (config('mt-media.model') === '\App\Models\Media') {
            config(['mt-media.model' => \Mt\MtSchoolCore\Models\Media::class]);
        }

        $this->app->singleton(SchoolYearResolver::class, fn() => new SchoolYearResolver());
        $this->app->singleton(SchoolResolver::class, fn() => new SchoolResolver());

        // Passerelle de paiement (factice par défaut, remplaçable par config).
        $this->app->bind(\Mt\MtSchoolCore\Contracts\PaymentGatewayContract::class, function () {
            $gateway = config('mt-school-core.payments.gateway', 'fake');

            return match ($gateway) {
                default => new \Mt\MtSchoolCore\Payments\FakeGateway(),
            };
        });

        $this->app->singleton(ReferenceSchoolService::class, fn() => new ReferenceSchoolService());

        $this->app->singleton(AverageService::class, fn() => new AverageService());

        $this->app->singleton(ReportCardService::class, fn($app) => new ReportCardService(
            $app->make(ReportCardComputer::class)
        ));

        $this->app->alias(SchoolYearResolver::class, 'mt-school.year');
        $this->app->alias(SchoolResolver::class, 'mt-school.tenant');
        $this->app->alias(AverageService::class,     'mt-school.averages');
        $this->app->alias(ReportCardService::class,  'mt-school.report-cards');
    }

    // =========================================================================
    // BOOT
    // =========================================================================

    public function boot(): void
    {
        $this->loadHelpers();

        // Points d'extension mt-views (générique) → fournis par mt-school :
        //  - brand de la sidebar = sigle/nom + logo de l'école
        //  - gating du menu par module d'abonnement
        config([
            'mt-views.brand_resolver'         => \Mt\MtSchoolCore\Support\SchoolBrandResolver::class,
            'mt-views.module_gate'            => \Mt\MtSchoolCore\Support\SchoolModuleGate::class,
            'mt-views.permission_gate'        => \Mt\MtSchoolCore\Support\SchoolPermissionGate::class,
            'mt-views.notifications_resolver' => \Mt\MtSchoolCore\Support\NotificationBadgeResolver::class,
        ]);

        // Les langues d'enseignement sont PAR ÉCOLE : configurées par requête dans
        // le middleware ResolveTenant (après résolution du tenant), pas au boot.
        $this->loadPackageMigrations();
        $this->loadPackageViews('mtschool');
        $this->loadPackageTranslations('mtschool');
        $this->loadRoutes();
        $this->registerBladeComponents();
        $this->registerBladeDirectives();
        $this->registerLivewireComponents();
        $this->registerAuthorization();
        $this->registerEvents();
        $this->registerMorphMap();
        $this->registerPublishing();
    }

    /**
     * RBAC : résout toutes les abilities « school.* » via le rôle scolaire du user.
     * Ainsi `@can('school.fees.manage')`, `$user->can(...)`, `authorize(...)` et le
     * middleware `can:` fonctionnent nativement, sans définir 70 Gates un par un.
     * super_admin passe tout ; teacher/student/parent n'ont aucune permission admin.
     */
    protected function registerAuthorization(): void
    {
        Gate::before(function ($user, string $ability) {
            if (! str_starts_with($ability, 'school.')) {
                return null; // hors domaine RBAC → résolution normale
            }

            return $user instanceof SchoolUser ? $user->hasPermission($ability) : null;
        });
    }

    protected function loadRoutes(): void
    {
        $routesPath = $this->basePath . '/routes/web.php';
        if (file_exists($routesPath)) {
            $this->loadRoutesFrom($routesPath);
        }
    }

    protected function loadHelpers(): void
    {
        $helper = $this->basePath . '/src/Helpers/helpers.php';
        if (file_exists($helper)) {
            require_once $helper;
        }
    }

    // =========================================================================
    // BLADE COMPONENTS
    // =========================================================================

    protected function registerBladeComponents(): void
    {
        $viewsPath = $this->basePath . '/resources/views';
        if (is_dir($viewsPath . '/components')) {
            Blade::anonymousComponentPath($viewsPath . '/components', 'mtschool');
        }
    }

    // =========================================================================
    // BLADE DIRECTIVES
    // =========================================================================

    protected function registerBladeDirectives(): void
    {
        Blade::directive('mtschoolAssets', function () {
            $css = asset('vendor/mt/school/css/mtschool.css');
            $js  = asset('vendor/mt/school/js/mtschool.js');
            return "<link rel='stylesheet' href='{$css}'><script defer src='{$js}'></script>";
        });

        Blade::directive('mtschoolReportCardAssets', function () {
            $css = asset('vendor/mt/school/css/report-card.css');
            return "<link rel='stylesheet' href='{$css}' media='print'>";
        });

        Blade::directive('activeSchoolYear', function () {
            return "<?php echo e(app('mt-school.year')->currentLabel()); ?>";
        });

        Blade::directive('school', function (string $expression) {
            return "<?php echo e(config('mt-school-core.school.' . {$expression})); ?>";
        });

        Blade::if('multilingualEnabled', function () {
            return config('mt-school-core.multilingual.enabled', false);
        });

        // Gating par tenant : modules du plan de l'école courante (repli config en dev).
        Blade::if('moduleEnabled', function (string $module) {
            return moduleEnabled($module);
        });
    }

    // =========================================================================
    // LIVEWIRE COMPONENTS
    // =========================================================================

    protected function registerLivewireComponents(): void
    {
        $components = [
            // ── Structure / Settings ──────────────────────────────────────────
            'mtschool.admin.school-years.index'       => \Mt\MtSchoolCore\Livewire\Admin\SchoolYears\SchoolYearsIndexComponent::class,
            'mtschool.admin.school-years.form'        => \Mt\MtSchoolCore\Livewire\Admin\SchoolYears\SchoolYearsFormComponent::class,
            'mtschool.admin.rollover.new-year'        => \Mt\MtSchoolCore\Livewire\Admin\Rollover\SchoolYearRolloverManager::class,
            'mtschool.admin.periods.index'            => \Mt\MtSchoolCore\Livewire\Admin\Periods\PeriodsIndexComponent::class,
            'mtschool.admin.periods.form'             => \Mt\MtSchoolCore\Livewire\Admin\Periods\PeriodsFormComponent::class,
            'mtschool.admin.cycles.index'             => \Mt\MtSchoolCore\Livewire\Admin\Cycles\CyclesIndexComponent::class,
            'mtschool.admin.cycles.form'              => \Mt\MtSchoolCore\Livewire\Admin\Cycles\CyclesFormComponent::class,
            'mtschool.admin.grade-levels.index'       => \Mt\MtSchoolCore\Livewire\Admin\GradeLevels\GradeLevelsIndexComponent::class,
            'mtschool.admin.grade-levels.form'        => \Mt\MtSchoolCore\Livewire\Admin\GradeLevels\GradeLevelsFormComponent::class,
            'mtschool.admin.specializations.index'    => \Mt\MtSchoolCore\Livewire\Admin\Specializations\SpecializationsIndexComponent::class,
            'mtschool.admin.specializations.form'     => \Mt\MtSchoolCore\Livewire\Admin\Specializations\SpecializationsFormComponent::class,
            'mtschool.admin.rooms.index'              => \Mt\MtSchoolCore\Livewire\Admin\Rooms\RoomsIndexComponent::class,
            'mtschool.admin.rooms.form'               => \Mt\MtSchoolCore\Livewire\Admin\Rooms\RoomsFormComponent::class,
            'mtschool.admin.classrooms.index'         => \Mt\MtSchoolCore\Livewire\Admin\Classrooms\ClassroomsIndexComponent::class,
            'mtschool.admin.classrooms.form'          => \Mt\MtSchoolCore\Livewire\Admin\Classrooms\ClassroomsFormComponent::class,
            'mtschool.admin.classrooms.show'          => \Mt\MtSchoolCore\Livewire\Admin\Classrooms\ClassroomsIndexComponent::class,
            'mtschool.admin.subjects.index'           => \Mt\MtSchoolCore\Livewire\Admin\Subjects\SubjectsIndexComponent::class,
            'mtschool.admin.subjects.form'            => \Mt\MtSchoolCore\Livewire\Admin\Subjects\SubjectsFormComponent::class,
            'mtschool.admin.curricula.index'          => \Mt\MtSchoolCore\Livewire\Admin\Curricula\CurriculaIndexComponent::class,
            'mtschool.admin.curricula.form'           => \Mt\MtSchoolCore\Livewire\Admin\Curricula\CurriculaFormComponent::class,
            'mtschool.admin.curricula.manager'        => \Mt\MtSchoolCore\Livewire\Admin\Curricula\CurriculumManager::class,
            // ── Staff / Teachers ─────────────────────────────────────────────
            'mtschool.admin.staff.index'              => \Mt\MtSchoolCore\Livewire\Admin\Staff\StaffIndexComponent::class,
            'mtschool.admin.staff.profile'            => \Mt\MtSchoolCore\Livewire\Admin\Staff\StaffProfileComponent::class,
            'mtschool.admin.teachers.index'           => \Mt\MtSchoolCore\Livewire\Admin\Teachers\TeachersIndexComponent::class,
            'mtschool.admin.teachers.form'            => \Mt\MtSchoolCore\Livewire\Admin\Teachers\TeachersFormComponent::class,
            'mtschool.admin.assignments.index'        => \Mt\MtSchoolCore\Livewire\Admin\Assignments\AssignmentsIndexComponent::class,
            'mtschool.admin.assignments.manager'      => \Mt\MtSchoolCore\Livewire\Admin\Assignments\CourseAssignmentManager::class,
            // ── Students / Guardians / Enrollments ───────────────────────────
            'mtschool.admin.students.index'           => \Mt\MtSchoolCore\Livewire\Admin\Students\StudentsIndexComponent::class,
            'mtschool.admin.students.form'            => \Mt\MtSchoolCore\Livewire\Admin\Students\StudentsFormComponent::class,
            'mtschool.admin.students.profile'         => \Mt\MtSchoolCore\Livewire\Admin\Students\StudentsProfileComponent::class,
            'mtschool.admin.students.edit'            => \Mt\MtSchoolCore\Livewire\Admin\Students\StudentsEditFormComponent::class,
            'mtschool.admin.guardians.index'          => \Mt\MtSchoolCore\Livewire\Admin\Guardians\GuardiansIndexComponent::class,
            'mtschool.admin.guardians.form'           => \Mt\MtSchoolCore\Livewire\Admin\Guardians\GuardiansFormComponent::class,
            'mtschool.admin.guardians.profile'        => \Mt\MtSchoolCore\Livewire\Admin\Guardians\GuardiansProfileComponent::class,
            'mtschool.admin.enrollments.index'        => \Mt\MtSchoolCore\Livewire\Admin\Enrollments\EnrollmentsIndexComponent::class,
            // ── Timetable ────────────────────────────────────────────────────
            'mtschool.admin.timetable.grid'           => \Mt\MtSchoolCore\Livewire\Admin\Timetable\TimetableGridManager::class,
            // ── Assessments / Grades ─────────────────────────────────────────
            'mtschool.admin.assessments.index'        => \Mt\MtSchoolCore\Livewire\Admin\Assessments\AssessmentsIndexComponent::class,
            'mtschool.admin.assessments.form'         => \Mt\MtSchoolCore\Livewire\Admin\Assessments\AssessmentsFormComponent::class,
            'mtschool.admin.assessments.grades'       => \Mt\MtSchoolCore\Livewire\Admin\Assessments\GradeEntryManager::class,
            'mtschool.admin.results.manager'          => \Mt\MtSchoolCore\Livewire\Admin\Results\ResultsIndexComponent::class,
            // ── Report Cards ─────────────────────────────────────────────────
            'mtschool.admin.report-cards.show'        => \Mt\MtSchoolCore\Livewire\Admin\Results\ReportCardView::class,
            // ── Attendance ───────────────────────────────────────────────────
            'mtschool.admin.attendance.manager'       => \Mt\MtSchoolCore\Livewire\Admin\Attendance\AttendanceManager::class,
            'mtschool.admin.attendance.justifications'=> \Mt\MtSchoolCore\Livewire\Admin\Attendance\JustificationsIndexComponent::class,
            // ── Finances ─────────────────────────────────────────────────────
            'mtschool.admin.fees.index'               => \Mt\MtSchoolCore\Livewire\Admin\Fees\FeeTypesIndexComponent::class,
            'mtschool.admin.fees.form'                => \Mt\MtSchoolCore\Livewire\Admin\Fees\FeeTypesFormComponent::class,
            'mtschool.admin.fees.schedule'            => \Mt\MtSchoolCore\Livewire\Admin\Fees\FeeScheduleIndexComponent::class,
            'mtschool.admin.fees.schedule-form'       => \Mt\MtSchoolCore\Livewire\Admin\Fees\FeeSchedulesFormComponent::class,
            'mtschool.admin.payments.manager'         => \Mt\MtSchoolCore\Livewire\Admin\Payments\PaymentsIndexComponent::class,
            'mtschool.admin.payments.student'         => \Mt\MtSchoolCore\Livewire\Admin\Payments\StudentFeeManager::class,
            'mtschool.admin.scholarships.index'       => \Mt\MtSchoolCore\Livewire\Admin\Scholarships\ScholarshipsIndexComponent::class,
            // ── Communication ────────────────────────────────────────────────
            'mtschool.admin.announcements.index'      => \Mt\MtSchoolCore\Livewire\Admin\Announcements\AnnouncementsIndexComponent::class,
            'mtschool.admin.announcements.form'       => \Mt\MtSchoolCore\Livewire\Admin\Announcements\AnnouncementsFormComponent::class,
            // ── Discipline ───────────────────────────────────────────────────
            'mtschool.admin.sanctions.index'          => \Mt\MtSchoolCore\Livewire\Admin\Sanctions\SanctionsIndexComponent::class,
            'mtschool.admin.sanctions.form'           => \Mt\MtSchoolCore\Livewire\Admin\Sanctions\SanctionsFormComponent::class,
            // ── Certificates / Settings ──────────────────────────────────────
            'mtschool.admin.settings.index'           => \Mt\MtSchoolCore\Livewire\Admin\Settings\SettingsManager::class,
            'mtschool.admin.school.form'              => \Mt\MtSchoolCore\Livewire\Admin\School\SchoolFormComponent::class,
            // ── Équipe (RBAC : comptes back-office + rôles) ───────────────────
            'mtschool.admin.team.manager'             => \Mt\MtSchoolCore\Livewire\Admin\Team\TeamManager::class,
            // ── Public : parcours d'achat ────────────────────────────────────
            'mtschool.public.pricing'                 => \Mt\MtSchoolCore\Livewire\Public\Pricing::class,
            'mtschool.public.checkout'                => \Mt\MtSchoolCore\Livewire\Public\Checkout::class,
            'mtschool.billing.renew'                  => \Mt\MtSchoolCore\Livewire\Billing\RenewComponent::class,
            'mtschool.admin.imports.index'            => \Mt\MtSchoolCore\Livewire\Admin\Imports\ImportCenter::class,
            // ── Setup wizard ─────────────────────────────────────────────────
            'mtschool.setup.wizard'                   => \Mt\MtSchoolCore\Livewire\Setup\SetupWizardComponent::class,
            // ── Dashboard ────────────────────────────────────────────────────
            'mtschool.dashboard'                      => \Mt\MtSchoolCore\Livewire\Dashboard::class,
            // ── Teacher portal ───────────────────────────────────────────────
            'mtschool.teacher.home'                   => \Mt\MtSchoolCore\Livewire\Teacher\TeacherHome::class,
            'mtschool.teacher.gradebook'              => \Mt\MtSchoolCore\Livewire\Teacher\TeacherGradebook::class,
            'mtschool.teacher.homeworks'              => \Mt\MtSchoolCore\Livewire\Teacher\TeacherHomework::class,
            'mtschool.teacher.homework-submissions'   => \Mt\MtSchoolCore\Livewire\Teacher\TeacherHomeworkSubmissions::class,
            'mtschool.teacher.resources'              => \Mt\MtSchoolCore\Livewire\Teacher\TeacherResources::class,
            // ── Student portal ───────────────────────────────────────────────
            'mtschool.student.home'                   => \Mt\MtSchoolCore\Livewire\Student\StudentHome::class,
            'mtschool.student.timetable'              => \Mt\MtSchoolCore\Livewire\Student\StudentTimetable::class,
            'mtschool.student.my-grades'              => \Mt\MtSchoolCore\Livewire\Student\MyGrades::class,
            'mtschool.student.my-report-cards'        => \Mt\MtSchoolCore\Livewire\Student\MyReportCards::class,
            'mtschool.student.my-homeworks'           => \Mt\MtSchoolCore\Livewire\Student\StudentHomework::class,
            'mtschool.student.my-resources'           => \Mt\MtSchoolCore\Livewire\Student\StudentResources::class,
            'mtschool.student.my-attendance'          => \Mt\MtSchoolCore\Livewire\Student\MyAttendance::class,
            'mtschool.student.my-fees'                => \Mt\MtSchoolCore\Livewire\Student\MyFees::class,
            // ── Parent portal ────────────────────────────────────────────────
            'mtschool.parent.home'                    => \Mt\MtSchoolCore\Livewire\ParentPortal\ParentHome::class,
            'mtschool.parent.homework'                => \Mt\MtSchoolCore\Livewire\ParentPortal\ParentHomework::class,
            'mtschool.parent.announcements'           => \Mt\MtSchoolCore\Livewire\Shared\PortalAnnouncements::class,
            'mtschool.student.announcements'          => \Mt\MtSchoolCore\Livewire\Shared\PortalAnnouncements::class,
            'mtschool.teacher.announcements'          => \Mt\MtSchoolCore\Livewire\Shared\PortalAnnouncements::class,
            'mtschool.parent.follow-up'               => \Mt\MtSchoolCore\Livewire\ParentPortal\FollowUp::class,
            'mtschool.parent.report-cards'            => \Mt\MtSchoolCore\Livewire\ParentPortal\ReportCards::class,
            'mtschool.parent.payments'                => \Mt\MtSchoolCore\Livewire\ParentPortal\Payments::class,
            'mtschool.parent.justify'                 => \Mt\MtSchoolCore\Livewire\ParentPortal\Justify::class,
            // ── Certificats ──────────────────────────────────────────────────
            'mtschool.admin.certificates.manager'     => \Mt\MtSchoolCore\Livewire\Admin\Certificates\CertificateManager::class,
            // ── Champs personnalisés (EAV) ───────────────────────────────────
            'mtschool.admin.custom-fields.manager'    => \Mt\MtSchoolCore\Livewire\Admin\CustomFields\CustomFieldManager::class,
            // ── Supervision pédagogie + conseils de classe ───────────────────
            'mtschool.admin.pedagogy.homeworks'       => \Mt\MtSchoolCore\Livewire\Admin\Pedagogy\HomeworkSupervision::class,
            'mtschool.admin.pedagogy.resources'       => \Mt\MtSchoolCore\Livewire\Admin\Pedagogy\ResourceSupervision::class,
            'mtschool.admin.councils.manager'         => \Mt\MtSchoolCore\Livewire\Admin\Councils\ClassCouncilManager::class,
            // ── Shared ───────────────────────────────────────────────────────
            'mtschool.shared.notifications'           => \Mt\MtSchoolCore\Livewire\Shared\Notifications::class,
            'mtschool.shared.calendar'                => \Mt\MtSchoolCore\Livewire\Calendar\CalendarManager::class,
            'mtschool.shared.messaging'               => \Mt\MtSchoolCore\Livewire\Messaging\MessagingCenter::class,
        ];

        foreach ($components as $alias => $class) {
            if (class_exists($class)) {
                Livewire::component($alias, $class);
            }
        }
    }

    // =========================================================================
    // EVENTS & LISTENERS
    // =========================================================================

    protected function registerEvents(): void
    {
        Event::listen(EnrollmentValidated::class, RecalculateClassroomEnrollment::class);
        Event::listen(AbsenceRecorded::class,     NotifyParentAbsence::class);
        Event::listen(ReportCardPublished::class, NotifyReportCardAvailable::class);
        Event::listen(PaymentReceived::class,     NotifyPaymentConfirmed::class);
    }

    // =========================================================================
    // MORPH MAP
    // =========================================================================

    protected function registerMorphMap(): void
    {
        Relation::morphMap([
            'user'         => \Mt\MtSchoolCore\Models\User::class,
            'student'      => \Mt\MtSchoolCore\Models\Student::class,
            'guardian'     => \Mt\MtSchoolCore\Models\Guardian::class,
            'staff'        => \Mt\MtSchoolCore\Models\StaffMember::class,
            'teacher'      => \Mt\MtSchoolCore\Models\Teacher::class,
            'enrollment'   => \Mt\MtSchoolCore\Models\Enrollment::class,
            'report_card'  => \Mt\MtSchoolCore\Models\ReportCard::class,
            'payment'      => \Mt\MtSchoolCore\Models\Payment::class,
            'assessment'   => \Mt\MtSchoolCore\Models\Assessment::class,
            'homework'     => \Mt\MtSchoolCore\Models\Homework::class,
            'announcement' => \Mt\MtSchoolCore\Models\Announcement::class,
            'classroom'    => \Mt\MtSchoolCore\Models\Classroom::class,
            'room'         => \Mt\MtSchoolCore\Models\Room::class,
        ], false);
    }

    // =========================================================================
    // PUBLISHING
    // =========================================================================

    protected function registerPublishing(): void
    {
        if (! $this->app->runningInConsole()) {
            return;
        }

        $viewsPath  = $this->basePath . '/resources/views';
        $langPath   = $this->basePath . '/lang';
        $configFile = $this->basePath . '/config/mt-school-core.php';
        $publicPath = $this->basePath . '/public/assets';

        $this->publishes([$viewsPath  => resource_path('views/vendor/mt/school')],              'mt-school-core-views');
        $this->publishes([$langPath   => $this->app->langPath('vendor/mt/school')],             'mt-school-core-lang');
        $this->publishes([$configFile => config_path('mt-school-core.php')],                    'mt-school-core-config');
        $this->publishes([$this->basePath . '/database/migrations' => database_path('migrations')], 'mt-school-core-migrations');

        if (is_dir($publicPath)) {
            $this->publishes([$publicPath => public_path('vendor/mt/school')],                  'mt-school-core-assets');
        }
    }
}
