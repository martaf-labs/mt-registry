<?php

namespace Mt\MtSchoolCore\Payments;

use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Mt\MtSchoolCore\Contracts\PaymentGatewayContract;
use Mt\MtSchoolCore\DTOs\PaymentResult;

/**
 * Passerelle FACTICE : valide toujours le paiement. Pour le développement.
 * À remplacer (config `mt-school-core.payments.gateway`) au déploiement réel.
 */
class FakeGateway implements PaymentGatewayContract
{
    public function name(): string
    {
        return 'fake';
    }

    public function charge(float $amount, string $currency, array $context = []): PaymentResult
    {
        return new PaymentResult(
            success: true,
            gateway: $this->name(),
            reference: 'FAKE-' . strtoupper(Str::random(12)),
            paidAt: Carbon::now(),
            raw: ['amount' => $amount, 'currency' => $currency, 'context' => $context],
        );
    }
}
