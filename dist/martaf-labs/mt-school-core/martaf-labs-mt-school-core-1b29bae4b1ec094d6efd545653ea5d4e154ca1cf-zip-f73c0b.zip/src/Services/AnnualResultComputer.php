<?php

namespace Mt\MtSchoolCore\Services;

use Illuminate\Support\Facades\DB;
use Mt\MtSchoolCore\Enums\EnrollmentResult;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\Setting;
use Mt\MtSchoolCore\Models\SubjectAverage;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Calcule le RÉSULTAT ANNUEL d'une classe : moyenne annuelle (moyenne des périodes
 * pondérée par Period.weight), rang annuel, et décision passage/redoublement
 * (admis si moyenne >= note de passage) — persistés sur l'Enrollment.
 *
 * C'est le chaînon qui alimente la promotion de fin d'année (SchoolYearRolloverService).
 * Lecture hors SchoolYearScope (on peut clôturer une année qui n'est plus active) ;
 * SchoolScope tenant conservé.
 */
class AnnualResultComputer
{
    /**
     * Calcule le résultat annuel de TOUTES les classes d'une année (pour la clôture /
     * l'assistant Nouvelle année). Renvoie un récapitulatif agrégé.
     */
    public function computeForYear(int $yearId): array
    {
        $summary = ['classes' => 0, 'computed' => 0, 'promoted' => 0, 'retained' => 0];

        $classIds = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->where('school_year_id', $yearId)
            ->where('status', 'validated')
            ->distinct()->pluck('class_id')->filter();

        foreach ($classIds as $classId) {
            $r = $this->compute((int) $classId, $yearId);
            $summary['classes']++;
            $summary['computed'] += $r['computed'];
            $summary['promoted'] += $r['promoted'];
            $summary['retained'] += $r['retained'];
        }

        return $summary;
    }

    public function compute(int $classId, int $yearId): array
    {
        return DB::transaction(function () use ($classId, $yearId) {
            // Note de passage PAR ÉCOLE (Setting) avec repli sur la config globale.
            $passing = (float) Setting::get('passing_score', config('mt-school-core.grading.passing_score', 10));

            $classroom = Classroom::withoutGlobalScope(SchoolYearScope::class)->findOrFail($classId);

            // Matières ÉLIMINATOIRES de la maquette [subject_id => note éliminatoire].
            $eliminating = $this->eliminatingSubjects($classroom, $yearId);

            $enrollments = Enrollment::withoutGlobalScope(SchoolYearScope::class)
                ->where('class_id', $classId)
                ->where('status', 'validated')
                ->get();

            // Périodes racines de l'année (poids) — trimestres/semestres.
            $periods = Period::withoutGlobalScope(SchoolYearScope::class)
                ->where('school_year_id', $yearId)
                ->whereNull('parent_id')
                ->get()->keyBy('id');

            // 1) Moyenne annuelle par élève (pondérée par le poids de chaque période).
            $averages = []; // enrollment_id => annual average
            foreach ($enrollments as $enr) {
                $pas = PeriodAverage::whereIn('period_id', $periods->keys())
                    ->where('enrollment_id', $enr->id)->get();
                if ($pas->isEmpty()) {
                    continue; // aucune moyenne de période → pas de résultat annuel
                }

                [$sumW, $sumWA] = [0.0, 0.0];
                foreach ($pas as $pa) {
                    $w = (float) ($periods[$pa->period_id]->weight ?? 1);
                    $sumWA += (float) $pa->overall_average * $w;
                    $sumW  += $w;
                }
                if ($sumW <= 0) {
                    continue;
                }

                $enr->annual_average = round($sumWA / $sumW, 2);
                $averages[$enr->id]  = (float) $enr->annual_average;
            }

            // 2) Rang annuel (desc, ex-aequo) + décision passage/redoublement.
            //    Une note sous le seuil dans une matière ÉLIMINATOIRE → redoublement,
            //    même si la moyenne générale atteint la note de passage.
            arsort($averages);
            [$rank, $i, $prev]  = [0, 0, null];
            [$promoted, $retained, $eliminatedCount] = [0, 0, 0];
            foreach ($averages as $enrId => $avg) {
                $i++;
                if ($prev === null || $avg != $prev) {
                    $rank = $i;
                    $prev = $avg;
                }
                $enr = $enrollments->firstWhere('id', $enrId);
                $enr->annual_rank = $rank;

                $eliminated = $this->isEliminated($enr->id, $periods->keys(), $eliminating);
                $isPromoted = $avg >= $passing && ! $eliminated;

                $enr->result = ($isPromoted ? EnrollmentResult::PROMOTED : EnrollmentResult::RETAINED)->value;
                $enr->save();

                $isPromoted ? $promoted++ : $retained++;
                if ($eliminated) {
                    $eliminatedCount++;
                }
            }

            $count = count($averages);

            return [
                'computed'      => $count,
                'promoted'      => $promoted,
                'retained'      => $retained,
                'eliminated'    => $eliminatedCount,
                'class_average' => $count ? round(array_sum($averages) / $count, 2) : null,
            ];
        });
    }

    /** Matières éliminatoires de la maquette du niveau : [subject_id => note éliminatoire]. */
    protected function eliminatingSubjects(Classroom $classroom, int $yearId): array
    {
        $curriculum = Curriculum::withoutGlobalScope(SchoolYearScope::class)
            ->where('grade_level_id', $classroom->grade_level_id)
            ->where('specialization_id', $classroom->specialization_id)
            ->where('school_year_id', $yearId)
            ->with('subjects')->first();

        if (! $curriculum) {
            return [];
        }

        $out = [];
        foreach ($curriculum->subjects as $subject) {
            if (filter_var($subject->pivot->is_eliminating, FILTER_VALIDATE_BOOLEAN)
                && $subject->pivot->eliminating_grade !== null) {
                $out[$subject->id] = (float) $subject->pivot->eliminating_grade;
            }
        }

        return $out;
    }

    /** L'élève est-il éliminé : moyenne annuelle d'une matière éliminatoire < son seuil ? */
    protected function isEliminated(int $enrollmentId, $periodIds, array $eliminating): bool
    {
        if (empty($eliminating)) {
            return false;
        }

        foreach ($eliminating as $subjectId => $threshold) {
            $avgs = SubjectAverage::whereIn('period_id', $periodIds)
                ->where('enrollment_id', $enrollmentId)
                ->where('subject_id', $subjectId)
                ->pluck('average');

            if ($avgs->isNotEmpty() && (float) $avgs->avg() < $threshold) {
                return true;
            }
        }

        return false;
    }
}
