<?php

namespace Mt\MtSchoolCore\Services;

use Illuminate\Support\Facades\DB;
use Mt\MtSchoolCore\Enums\AttendanceStatus;
use Mt\MtSchoolCore\Enums\Mention;
use Mt\MtSchoolCore\Models\Assessment;
use Mt\MtSchoolCore\Models\Attendance;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Grade;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\SubjectAverage;

/**
 * Calcul des moyennes, coefficients et rangs pour une classe + période.
 *
 * Chaîne francophone :
 *   moyenne matière = Σ(note/20 × coef_évaluation) / Σ(coef_évaluation)
 *   moyenne générale = Σ(moyenne_matière × coef_matière[maquette]) / Σ(coef_matière)
 *
 * Idempotent : updateOrCreate sur (enrollment, period, subject) / (enrollment, period).
 */
class ReportCardComputer
{
    public function compute(int $classId, int $periodId): array
    {
        return DB::transaction(function () use ($classId, $periodId) {
            $classroom   = Classroom::with('gradeLevel')->findOrFail($classId);
            $enrollments = Enrollment::where('class_id', $classId)->validated()->get();
            $enrollIds   = $enrollments->pluck('id');

            // Coefficients matières depuis la MAQUETTE du niveau de la classe.
            $curriculum = $this->subjectCoefficients($classroom);
            $coefMap    = $curriculum['coef'];
            $excluded   = $curriculum['excluded']; // matières on_report_card=false → hors bulletin

            // Purge des matières « hors bulletin » : on supprime leurs SubjectAverage
            // éventuels pour qu'elles ne comptent NI dans l'affichage NI dans la moyenne
            // générale (idempotent même après bascule du flag on_report_card).
            if (! empty($excluded)) {
                SubjectAverage::where('period_id', $periodId)
                    ->whereIn('enrollment_id', $enrollIds)
                    ->whereIn('subject_id', array_keys($excluded))
                    ->delete();
            }

            // Évaluations de la (classe, période), groupées par matière.
            $assessments = Assessment::where('class_id', $classId)
                ->where('period_id', $periodId)->get();
            $bySubject     = $assessments->groupBy('subject_id');
            $assessmentIds = $assessments->pluck('id');

            // Notes indexées par enrollment_id (puis on cherche par assessment_id).
            $gradesByEnroll = Grade::whereIn('assessment_id', $assessmentIds)
                ->whereIn('enrollment_id', $enrollIds)
                ->get()->groupBy('enrollment_id');

            // 1) Moyenne par matière pour chaque élève.
            foreach ($enrollments as $e) {
                $studentGrades = $gradesByEnroll->get($e->id) ?? collect();

                foreach ($bySubject as $subjectId => $subjectAssessments) {
                    if (isset($excluded[$subjectId])) {
                        continue; // matière hors bulletin (on_report_card=false)
                    }

                    [$sumWeighted, $sumCoef] = [0.0, 0.0];

                    foreach ($subjectAssessments as $a) {
                        $g = $studentGrades->firstWhere('assessment_id', $a->id);
                        if (! $g || $g->final_score === null) {
                            continue; // non saisi ou absence justifiée → exclu
                        }
                        $w = (float) ($a->coefficient ?: 1);
                        $sumWeighted += ((float) $g->score_normalised) * $w;
                        $sumCoef     += $w;
                    }

                    if ($sumCoef <= 0) {
                        continue; // aucune note pour cette matière
                    }

                    $avg  = round($sumWeighted / $sumCoef, 2);
                    $coef = (float) ($coefMap[$subjectId] ?? 1);

                    SubjectAverage::updateOrCreate(
                        ['enrollment_id' => $e->id, 'period_id' => $periodId, 'subject_id' => $subjectId],
                        [
                            'average'          => $avg,
                            'coefficient'      => $coef,
                            'weighted_average' => round($avg * $coef, 2),
                        ]
                    );
                }
            }

            // 2) Rangs par matière + statistiques de classe.
            foreach ($bySubject->keys() as $subjectId) {
                $sas = SubjectAverage::where('period_id', $periodId)
                    ->where('subject_id', $subjectId)
                    ->whereIn('enrollment_id', $enrollIds)
                    ->orderByDesc('average')->get();

                if ($sas->isEmpty()) {
                    continue;
                }

                $stats = [
                    'class_average'   => round($sas->avg('average'), 2),
                    'class_max_score' => (float) $sas->max('average'),
                    'class_min_score' => (float) $sas->min('average'),
                ];
                $this->applyRanks($sas, 'average', $stats);
            }

            // 3) Moyenne générale par élève (+ compteurs d'assiduité de la période).
            $period = Period::find($periodId);

            foreach ($enrollments as $e) {
                $sas = SubjectAverage::where('enrollment_id', $e->id)
                    ->where('period_id', $periodId)->get();

                $totalCoef = (float) $sas->sum('coefficient');
                if ($totalCoef <= 0) {
                    continue;
                }
                $totalPoints = (float) $sas->sum('weighted_average');
                $overall     = round($totalPoints / $totalCoef, 2);

                PeriodAverage::updateOrCreate(
                    ['enrollment_id' => $e->id, 'period_id' => $periodId],
                    array_merge([
                        'overall_average'    => $overall,
                        'total_points'       => round($totalPoints, 2),
                        'total_coefficients' => $totalCoef,
                        'mention'            => Mention::fromAverage($overall)->value,
                    ], $this->attendanceCounts($e->id, $period))
                );
            }

            // 4) Rang général + statistiques de classe.
            $pas = PeriodAverage::where('period_id', $periodId)
                ->whereIn('enrollment_id', $enrollIds)
                ->orderByDesc('overall_average')->get();

            $computed = $pas->count();
            if ($computed > 0) {
                $stats = [
                    'class_size'        => $computed,
                    'class_average'     => round($pas->avg('overall_average'), 2),
                    'class_max_average' => (float) $pas->max('overall_average'),
                    'class_min_average' => (float) $pas->min('overall_average'),
                ];
                $this->applyRanks($pas, 'overall_average', $stats);
            }

            return [
                'students'      => $enrollments->count(),
                'computed'      => $computed,
                'subjects'      => $bySubject->count(),
                'class_average' => $computed > 0 ? round($pas->avg('overall_average'), 2) : null,
            ];
        });
    }

    /** Compteurs d'assiduité d'un élève sur la plage de dates de la période. */
    protected function attendanceCounts(int $enrollmentId, ?Period $period): array
    {
        $zero = ['justified_absences' => 0, 'unjustified_absences' => 0, 'tardiness_count' => 0];

        if (! $period || ! $period->start_date || ! $period->end_date) {
            return $zero; // pas de plage de dates → on ne touche pas (compteurs à 0)
        }

        $atts = Attendance::where('enrollment_id', $enrollmentId)
            ->whereBetween('date', [$period->start_date, $period->end_date])->get();

        return [
            'justified_absences'   => $atts->filter(fn ($a) => $a->status === AttendanceStatus::ABSENT && $a->is_justified)->count(),
            'unjustified_absences' => $atts->filter(fn ($a) => $a->status === AttendanceStatus::ABSENT && ! $a->is_justified)->count(),
            'tardiness_count'      => $atts->filter(fn ($a) => $a->status === AttendanceStatus::LATE)->count(),
        ];
    }

    /**
     * Depuis la maquette (niveau + filière) de la classe :
     *   - 'coef'     : [subject_id => coefficient]
     *   - 'excluded' : [subject_id => true] pour les matières on_report_card=false
     *                  (hors bulletin : ni affichées, ni comptées dans la moyenne).
     */
    protected function subjectCoefficients(Classroom $classroom): array
    {
        $curriculum = Curriculum::where('grade_level_id', $classroom->grade_level_id)
            ->where('specialization_id', $classroom->specialization_id)
            ->with('subjects')->first();

        if (! $curriculum) {
            return ['coef' => [], 'excluded' => []];
        }

        $coef     = [];
        $excluded = [];
        foreach ($curriculum->subjects as $s) {
            $coef[$s->id] = (float) ($s->pivot->coefficient ?? 1);
            // on_report_card explicitement faux → matière hors bulletin.
            if ($s->pivot->on_report_card !== null
                && ! filter_var($s->pivot->on_report_card, FILTER_VALIDATE_BOOLEAN)) {
                $excluded[$s->id] = true;
            }
        }
        return ['coef' => $coef, 'excluded' => $excluded];
    }

    /** Applique les rangs ex-aequo (1,1,3…) + stats communes à une collection triée desc. */
    protected function applyRanks($collection, string $field, array $commonStats): void
    {
        $rank = 0;
        $prev = null;
        $i    = 0;

        foreach ($collection as $row) {
            $i++;
            if ($prev === null || (float) $row->{$field} != (float) $prev) {
                $rank = $i;
                $prev = $row->{$field};
            }
            $row->update(array_merge($commonStats, ['rank' => $rank]));
        }
    }
}
