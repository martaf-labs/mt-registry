<?php

namespace Mt\MtSchoolCore\Services;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Mt\MtSchoolCore\Contracts\PaymentGatewayContract;
use Mt\MtSchoolCore\Enums\RoleSchool;
use Mt\MtSchoolCore\Models\Plan;
use Mt\MtSchoolCore\Models\School;
use Mt\MtSchoolCore\Models\Subscription;
use Mt\MtSchoolCore\Models\User;

/**
 * Orchestration de l'achat d'un abonnement :
 *   école (shell) → compte SUPER_ADMIN → paiement → abonnement.
 *
 * L'école est créée minimale ici (le tenant existe dès l'achat) puis configurée
 * dans le setup wizard. Le compte créé devient super-admin de cette école.
 */
class SubscriptionPurchaseService
{
    public function __construct(protected PaymentGatewayContract $gateway) {}

    /**
     * @param  array{name:string,email:string,password:string,school_name?:string}  $account
     * @return array{school:School,user:User,subscription:Subscription}
     */
    public function purchase(Plan $plan, array $account): array
    {
        return DB::transaction(function () use ($plan, $account) {
            // 1. École (tenant) — détails complétés au setup.
            $school = School::create([
                'name'   => ['fr' => $account['school_name'] ?? 'Mon établissement'],
                'active' => true,
            ]);

            // 2. Compte super-admin de cette école.
            $user = User::create([
                'name'        => $account['name'],
                'email'       => $account['email'],
                'password'    => Hash::make($account['password']),
                'school_id'   => $school->id,
                'school_role' => RoleSchool::SUPER_ADMIN,
            ]);

            // 3. Paiement (factice pour l'instant).
            $amount  = (float) $plan->price;
            $payment = $this->gateway->charge($amount, $plan->currency, [
                'plan'      => $plan->code,
                'school_id' => $school->id,
                'email'     => $account['email'],
            ]);

            // 4. Abonnement.
            $subscription = Subscription::create([
                'school_id'         => $school->id,
                'plan_id'           => $plan->id,
                'status'            => $payment->success ? 'active' : 'pending',
                'starts_at'         => Carbon::today(),
                'ends_at'           => $this->computeEndDate($plan),
                'max_students'      => $plan->max_students,
                'amount'            => $amount,
                'currency'          => $plan->currency,
                'payment_status'    => $payment->success ? 'paid' : 'unpaid',
                'payment_gateway'   => $payment->gateway,
                'payment_reference' => $payment->reference,
                'paid_at'           => $payment->success ? $payment->paidAt : null,
            ]);

            return compact('school', 'user', 'subscription');
        });
    }

    /**
     * Renouvelle / réactive l'abonnement d'une école EXISTANTE (pas de nouveau
     * compte ni école). Crée un nouvel abonnement actif sur le plan choisi.
     */
    public function renew(School $school, Plan $plan): Subscription
    {
        return DB::transaction(function () use ($school, $plan) {
            $amount  = (float) $plan->price;
            $payment = $this->gateway->charge($amount, $plan->currency, [
                'plan'      => $plan->code,
                'school_id' => $school->id,
                'renewal'   => true,
            ]);

            return Subscription::create([
                'school_id'         => $school->id,
                'plan_id'           => $plan->id,
                'status'            => $payment->success ? 'active' : 'pending',
                'starts_at'         => Carbon::today(),
                'ends_at'           => $this->computeEndDate($plan),
                'max_students'      => $plan->max_students,
                'amount'            => $amount,
                'currency'          => $plan->currency,
                'payment_status'    => $payment->success ? 'paid' : 'unpaid',
                'payment_gateway'   => $payment->gateway,
                'payment_reference' => $payment->reference,
                'paid_at'           => $payment->success ? $payment->paidAt : null,
            ]);
        });
    }

    protected function computeEndDate(Plan $plan): Carbon
    {
        return match ($plan->billing_period) {
            'monthly' => Carbon::today()->addMonth(),
            'term'    => Carbon::today()->addMonths(4),
            default   => Carbon::today()->addYear(),
        };
    }
}
