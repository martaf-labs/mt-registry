<?php

namespace Mt\MtSchoolCore\Services;

use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\FeeSchedule;
use Mt\MtSchoolCore\Models\Payment;
use Mt\MtSchoolCore\Models\PaymentInstallment;
use Mt\MtSchoolCore\Models\SchoolFee;
use Mt\MtSchoolCore\Models\Scholarship;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Facturation & encaissement.
 *  - generateForClassroom/Enrollment : crée les SchoolFee dus à partir de la grille (FeeSchedule).
 *  - recordPayment : encaisse un montant et l'alloue aux frais impayés (statuts mis à jour).
 */
class FeeService
{
    use \Mt\MtSchoolCore\Support\RendersLocalizedPdf;

    public function __construct(protected ReferenceSchoolService $references) {}

    public function generateForClassroom(int $classId): int
    {
        $enrollments = Enrollment::where('class_id', $classId)->validated()->with('classroom')->get();

        $created = 0;
        foreach ($enrollments as $e) {
            $created += $this->generateForEnrollment($e);
        }
        return $created;
    }

    /** Crée/actualise les SchoolFee d'un élève depuis la grille de sa classe. */
    public function generateForEnrollment(Enrollment $enrollment): int
    {
        $class = $enrollment->classroom;
        if (! $class) {
            return 0;
        }

        $query = FeeSchedule::where('grade_level_id', $class->grade_level_id)->where('active', true);
        $class->specialization_id
            ? $query->where('specialization_id', $class->specialization_id)
            : $query->whereNull('specialization_id');

        $year    = activeSchoolYearId() ?? (int) date('Y');
        $created = 0;

        return DB::transaction(function () use ($query, $enrollment, $year, &$created) {
            foreach ($query->get() as $sch) {
                $gross = (float) $sch->amount;
                $fee   = SchoolFee::where('enrollment_id', $enrollment->id)
                    ->where('fee_type_id', $sch->fee_type_id)->first();

                if ($fee) {
                    // Met à jour le barème sans écraser ce qui est déjà payé.
                    $discount = (float) $fee->discount;
                    $net      = max(0, $gross - $discount);
                    $fee->update([
                        'gross_amount'     => $gross,
                        'net_amount'       => $net,
                        'remaining_amount' => max(0, $net - (float) $fee->amount_paid),
                        'status'           => $this->statusFor($net, (float) $fee->amount_paid),
                    ]);
                } else {
                    SchoolFee::create([
                        'reference'        => $this->references->schoolFee($year),
                        'enrollment_id'    => $enrollment->id,
                        'fee_type_id'      => $sch->fee_type_id,
                        'gross_amount'     => $gross,
                        'discount'         => 0,
                        'net_amount'       => $gross,
                        'amount_paid'      => 0,
                        'remaining_amount' => $gross,
                        'currency'         => $sch->currency ?? 'XAF',
                        'status'           => 'pending',
                    ]);
                    $created++;
                }
            }
            return $created;
        });
    }

    /** Encaisse $amount pour un élève, alloué aux frais impayés (plus anciens d'abord). */
    public function recordPayment(Enrollment $enrollment, float $amount, string $method, ?string $date = null): float
    {
        if ($amount <= 0) {
            return 0;
        }

        $year = activeSchoolYearId() ?? (int) date('Y');
        $date = $date ?: now()->format('Y-m-d');

        $result = DB::transaction(function () use ($enrollment, $amount, $method, $date, $year) {
            $fees = $enrollment->schoolFees()
                ->whereIn('status', ['pending', 'partial'])
                ->orderBy('id')->get();

            $left     = $amount;
            $currency = '';
            foreach ($fees as $fee) {
                if ($left <= 0) {
                    break;
                }
                $due = (float) $fee->remaining_amount;
                if ($due <= 0) {
                    continue;
                }
                $pay      = min($left, $due);
                $currency = $currency ?: (string) $fee->currency;

                Payment::create([
                    'reference'      => $this->references->payment($year),
                    'school_fee_id'  => $fee->id,
                    'amount'         => $pay,
                    'currency'       => $fee->currency,
                    'payment_date'   => $date,
                    'payment_method' => $method,
                    'status'         => 'confirmed',
                    'collected_by'   => auth()->id(),
                ]);

                $fee->amount_paid      = (float) $fee->amount_paid + $pay;
                $fee->remaining_amount = max(0, (float) $fee->net_amount - $fee->amount_paid);
                $fee->status           = $this->statusFor((float) $fee->net_amount, $fee->amount_paid);
                $fee->save();

                $left -= $pay;
            }

            return ['allocated' => $amount - $left, 'currency' => $currency];
        });

        // Notifie les tuteurs de l'encaissement (hors transaction : la notif ne doit
        // pas bloquer l'encaissement si elle échoue).
        if ($result['allocated'] > 0) {
            app(NotificationService::class)->notifyPayment($enrollment, (float) $result['allocated'], $result['currency']);
        }

        return $result['allocated']; // montant réellement alloué
    }

    protected function statusFor(float $net, float $paid): string
    {
        if ($net <= 0)     return 'paid';    // rien à payer (remise totale / bourse 100 %)
        if ($paid <= 0)    return 'pending';
        if ($paid >= $net) return 'paid';
        return 'partial';
    }

    /** Recalcule net / reste / statut d'un frais depuis brut, remise et payé. */
    protected function recomputeFee(SchoolFee $fee): void
    {
        $net = max(0, (float) $fee->gross_amount - (float) $fee->discount);
        $fee->net_amount       = $net;
        $fee->remaining_amount = max(0, $net - (float) $fee->amount_paid);
        $fee->status           = $this->statusFor($net, (float) $fee->amount_paid);
        $fee->save();
    }

    /**
     * Accorde une bourse à un élève et applique la remise sur ses frais.
     * $data : label, mode ('percent'|'amount'), value, fee_type_id (null = tous les frais).
     * La remise REMPLACE la remise existante sur les frais concernés (v1).
     */
    public function grantScholarship(Enrollment $enrollment, array $data): Scholarship
    {
        return DB::transaction(function () use ($enrollment, $data) {
            $mode    = $data['mode'] ?? 'percent';
            $value   = (float) ($data['value'] ?? 0);
            $typeId  = $data['fee_type_id'] ?? null;
            $year    = activeSchoolYearId() ?? (int) date('Y');

            // `type` = CATÉGORIE (schéma : merit|social|government|other), pas le mode de calcul
            // (le mode se déduit de amount pour le fixe / coverage_rate pour le pourcentage).
            $category = in_array($data['type'] ?? null, ['merit', 'social', 'government', 'other'], true)
                ? $data['type'] : 'other';

            $scholarship = Scholarship::create([
                'reference'     => 'BRS-' . strtoupper(substr(uniqid(), -6)),
                'enrollment_id' => $enrollment->id,
                'label'         => ['fr' => $data['label'] ?? 'Bourse'],
                'type'          => $category,
                'amount'        => $mode === 'amount' ? $value : 0,
                'coverage_rate' => $mode === 'percent' ? $value : 0,
                'coverage'      => $typeId ? 'partial' : 'global',
                'status'        => 'active',
                'award_date'    => now()->format('Y-m-d'),
            ]);

            $fees = $enrollment->schoolFees()
                ->when($typeId, fn ($q) => $q->where('fee_type_id', $typeId))
                ->get();

            if ($mode === 'percent') {
                foreach ($fees as $fee) {
                    $fee->discount = round((float) $fee->gross_amount * $value / 100, 2);
                    $this->recomputeFee($fee);
                }
            } else { // montant fixe
                if ($typeId) {
                    foreach ($fees as $fee) {
                        $fee->discount = min($value, (float) $fee->gross_amount);
                        $this->recomputeFee($fee);
                    }
                } else {
                    // Réparti proportionnellement au brut. Le DERNIER frais absorbe le reliquat
                    // d'arrondi pour que la somme des remises = le montant accordé (au centime).
                    $totalGross = (float) $fees->sum('gross_amount');
                    if ($totalGross > 0) {
                        $fees   = $fees->values();
                        $lastIx = $fees->count() - 1;
                        $left   = $value;
                        foreach ($fees as $ix => $fee) {
                            $share = $ix === $lastIx
                                ? $left
                                : round($value * (float) $fee->gross_amount / $totalGross, 2);
                            $fee->discount = min(round($share, 2), (float) $fee->gross_amount);
                            $left -= (float) $fee->discount;
                            $this->recomputeFee($fee);
                        }
                    }
                }
            }

            return $scholarship;
        });
    }

    /**
     * Ajuste un frais d'un élève : remise manuelle ou exonération totale.
     * Exonéré → net 0, reste 0, statut 'exempt'.
     */
    public function adjustFee(SchoolFee $fee, ?float $discount, bool $isExempt, ?string $reason = null): void
    {
        $fee->is_exempt = $isExempt;

        if ($isExempt) {
            $fee->exemption_reason = $reason ? ['fr' => $reason] : null;
            $fee->discount         = (float) $fee->gross_amount;
            $fee->net_amount       = 0;
            $fee->remaining_amount = 0;
            $fee->status           = 'exempt';
            $fee->save();
        } else {
            $fee->exemption_reason = null;
            $fee->discount = max(0, min((float) ($discount ?? 0), (float) $fee->gross_amount));
            $this->recomputeFee($fee);
        }
    }

    /**
     * Échelonne un frais en N versements datés (PaymentInstallment). Remplace l'échéancier
     * existant. Le suivi de couverture se déduit de `amount_paid` du frais (cumulatif).
     */
    public function generateInstallments(SchoolFee $fee, int $count, string $firstDueDate, int $intervalMonths = 1): int
    {
        if ($count < 1) {
            return 0;
        }

        return DB::transaction(function () use ($fee, $count, $firstDueDate, $intervalMonths) {
            $fee->installments()->delete();

            $net  = (float) $fee->net_amount;
            $base = floor(($net / $count) / 100) * 100; // arrondi à la centaine
            if ($base <= 0) {
                // Frais trop petit pour un arrondi à la centaine (sinon versements à 0) →
                // arrondi au centime, le dernier versement absorbe le reliquat.
                $base = floor(($net / $count) * 100) / 100;
            }
            $first = \Carbon\Carbon::parse($firstDueDate);

            for ($i = 0; $i < $count; $i++) {
                $amount = $i === $count - 1 ? round($net - $base * ($count - 1), 2) : $base;
                PaymentInstallment::create([
                    'school_fee_id'    => $fee->id,
                    'label'            => ['fr' => 'Versement ' . ($i + 1)],
                    'order'            => $i + 1,
                    'amount'           => $amount,
                    'amount_paid'      => 0,
                    'remaining_amount' => $amount,
                    'due_date'         => $first->copy()->addMonths($i * $intervalMonths)->format('Y-m-d'),
                    'status'           => 'pending',
                ]);
            }

            return $count;
        });
    }

    /** Relevé financier (frais + paiements) d'un élève, en PDF. */
    public function statementPdf(int $enrollmentId)
    {
        // Réimpression possible d'un relevé d'une année PASSÉE (hors année active) :
        // on neutralise le SchoolYearScope, le SchoolScope (tenant) reste appliqué.
        $enrollment = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->with(['student', 'classroom'])->findOrFail($enrollmentId);

        $fees = SchoolFee::where('enrollment_id', $enrollmentId)->with('feeType')->get();

        $payments = Payment::whereIn('school_fee_id', $fees->pluck('id'))
            ->orderBy('payment_date')->get();

        $schoolName = function_exists('mt_brand_name') ? (mt_brand_name() ?? '') : '';
        // Année AFFICHÉE = celle de l'inscription (pas l'année active) → relevé d'une
        // année passée cohérent.
        $year       = $enrollment->schoolYear?->label ?? SchoolYear::where('is_active', true)->first()?->label;
        $locale     = app()->getLocale();
        $schoolYear = is_array($year) ? ($year[$locale] ?? $year['fr'] ?? reset($year) ?: '') : (string) ($year ?? '');

        return $this->renderPdf('mtschool::pdf.fee-statement', compact(
            'enrollment', 'fees', 'payments', 'schoolName', 'schoolYear'
        ));
    }
}

