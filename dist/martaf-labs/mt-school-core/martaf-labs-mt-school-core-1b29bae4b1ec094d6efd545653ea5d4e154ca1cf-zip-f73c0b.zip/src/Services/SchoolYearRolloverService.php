<?php

namespace Mt\MtSchoolCore\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Mt\MtSchoolCore\Enums\EnrollmentResult;
use Mt\MtSchoolCore\Enums\EnrollmentStatus;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\FeeSchedule;
use Mt\MtSchoolCore\Models\FeeType;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\SchoolFee;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Assistant « Nouvelle année scolaire ».
 *
 * Résout le blocage multi-année n°1 : à la bascule, tout ce qui est year-scoped
 * (classes, maquettes+coefficients, grilles de frais, périodes, affectations)
 * disparaît et devait être ressaisi. Ce service :
 *   - CLONE la structure d'une année vers une autre (idempotent) ;
 *   - PROMEUT en masse les élèves au niveau suivant (redoublant / sortant / transféré),
 *     en chaînant les inscriptions via previous_enrollment_id.
 *
 * Toutes les LECTURES de l'année source neutralisent le SchoolYearScope (la source
 * n'est pas forcément l'année active) ; le SchoolScope tenant reste TOUJOURS appliqué.
 * Toutes les CRÉATIONS fixent school_year_id = année cible explicitement.
 */
class SchoolYearRolloverService
{
    /** Query d'un modèle year-scoped, bornée à une année précise, sans le scope année. */
    private function forYear(string $modelClass, int $yearId)
    {
        return $modelClass::withoutGlobalScope(SchoolYearScope::class)
            ->where('school_year_id', $yearId);
    }

    /**
     * Niveau supérieur d'un niveau donné : niveau suivant du même cycle (par ordre),
     * sinon premier niveau du cycle suivant, sinon null (fin de scolarité).
     */
    public function nextGradeLevel(GradeLevel $level): ?GradeLevel
    {
        $next = GradeLevel::where('cycle_id', $level->cycle_id)
            ->where('order', '>', $level->order)
            ->where('active', true)
            ->orderBy('order')->first();
        if ($next) {
            return $next;
        }

        $cycle = Cycle::find($level->cycle_id);
        if (! $cycle) {
            return null;
        }
        $nextCycle = Cycle::where('order', '>', $cycle->order)
            ->where('active', true)->orderBy('order')->first();
        if (! $nextCycle) {
            return null;
        }
        return GradeLevel::where('cycle_id', $nextCycle->id)
            ->where('active', true)->orderBy('order')->first();
    }

    // =====================================================================
    // CLONAGE DE STRUCTURE
    // =====================================================================

    /**
     * Clone la structure de $from vers $to. Idempotent (n'écrase rien d'existant).
     *
     * @param array $opts ['classes'=>bool, 'curricula'=>bool, 'fees'=>bool,
     *                     'periods'=>bool, 'assignments'=>bool] (tous true par défaut)
     * @return array Compteurs des éléments créés + map des classes.
     */
    public function cloneStructure(SchoolYear $from, SchoolYear $to, array $opts = []): array
    {
        $do = fn (string $k) => $opts[$k] ?? true;

        return DB::transaction(function () use ($from, $to, $do) {
            $counts   = ['classes' => 0, 'curricula' => 0, 'fees' => 0, 'periods' => 0, 'assignments' => 0];
            $classMap = []; // old_class_id => new Classroom

            // 1) Classes
            if ($do('classes')) {
                foreach ($this->forYear(Classroom::class, $from->id)->get() as $old) {
                    $new = $this->forYear(Classroom::class, $to->id)->where('code', $old->code)->first();
                    if (! $new) {
                        $new = Classroom::create([
                            'school_year_id'      => $to->id,
                            'grade_level_id'      => $old->grade_level_id,
                            'specialization_id'   => $old->specialization_id,
                            'room_id'             => $old->room_id,
                            'homeroom_teacher_id' => $old->homeroom_teacher_id,
                            'label'               => $old->getRawOriginal('label'),
                            'code'                => $old->code,
                            'abbreviation'        => $old->abbreviation,
                            'max_capacity'        => $old->max_capacity,
                            'current_enrollment'  => 0,
                            'teaching_language'   => $old->teaching_language,
                            'active'              => $old->active,
                        ]);
                        $counts['classes']++;
                    }
                    $classMap[$old->id] = $new;
                }
            }

            // 2) Maquettes + coefficients (pivot curriculum_subject)
            if ($do('curricula')) {
                foreach ($this->forYear(Curriculum::class, $from->id)->with('subjects')->get() as $old) {
                    $new = $this->forYear(Curriculum::class, $to->id)
                        ->where('grade_level_id', $old->grade_level_id)
                        ->where('specialization_id', $old->specialization_id)
                        ->first();
                    if (! $new) {
                        $new = Curriculum::create([
                            'school_year_id'     => $to->id,
                            'grade_level_id'     => $old->grade_level_id,
                            'specialization_id'  => $old->specialization_id,
                            'code'               => $old->code,
                            'label'              => $old->getRawOriginal('label'),
                            'description'        => $old->getRawOriginal('description'),
                            'active'             => $old->active,
                        ]);
                        foreach ($old->subjects as $s) {
                            $new->subjects()->attach($s->id, [
                                'coefficient'      => $s->pivot->coefficient,
                                'weekly_hours'     => $s->pivot->weekly_hours,
                                'order'            => $s->pivot->order,
                                'on_report_card'   => $s->pivot->on_report_card,
                                'is_eliminating'   => $s->pivot->is_eliminating,
                                'eliminating_grade'=> $s->pivot->eliminating_grade,
                            ]);
                        }
                        $counts['curricula']++;
                    }
                }
            }

            // 3) Grilles de frais
            if ($do('fees')) {
                foreach ($this->forYear(FeeSchedule::class, $from->id)->get() as $old) {
                    $exists = $this->forYear(FeeSchedule::class, $to->id)
                        ->where('fee_type_id', $old->fee_type_id)
                        ->where('grade_level_id', $old->grade_level_id)
                        ->where('specialization_id', $old->specialization_id)
                        ->exists();
                    if (! $exists) {
                        FeeSchedule::create([
                            'school_year_id'    => $to->id,
                            'fee_type_id'       => $old->fee_type_id,
                            'grade_level_id'    => $old->grade_level_id,
                            'specialization_id' => $old->specialization_id,
                            'amount'            => $old->amount,
                            'currency'          => $old->currency,
                            'active'            => $old->active,
                            'description'       => $old->getRawOriginal('description'),
                        ]);
                        $counts['fees']++;
                    }
                }
            }

            // 4) Périodes (calées sur l'année cible) — seulement si l'année cible n'en a pas encore.
            if ($do('periods') && ! $this->forYear(Period::class, $to->id)->exists()) {
                $yearOffset = (int) Carbon::parse($to->start_date)->year - (int) Carbon::parse($from->start_date)->year;
                foreach ($this->forYear(Period::class, $from->id)->whereNull('parent_id')->orderBy('order')->get() as $old) {
                    Period::create([
                        'school_year_id' => $to->id,
                        'parent_id'      => null,
                        'type'           => $old->type->value,
                        'code'           => $old->code,
                        'label'          => $old->getRawOriginal('label'),
                        'order'          => $old->order,
                        'weight'         => $old->weight,
                        'start_date'     => $this->shiftYears($old->start_date, $yearOffset),
                        'end_date'       => $this->shiftYears($old->end_date, $yearOffset),
                        'is_active'      => $old->order === 1,
                        'is_closed'      => false,
                    ]);
                    $counts['periods']++;
                }
            }

            // 5) Affectations (matière + enseignant) — nécessite la map des classes.
            if ($do('assignments') && ! empty($classMap)) {
                foreach ($this->forYear(CourseAssignment::class, $from->id)->get() as $old) {
                    $newClass = $classMap[$old->class_id] ?? null;
                    if (! $newClass) {
                        continue;
                    }
                    $exists = $this->forYear(CourseAssignment::class, $to->id)
                        ->where('class_id', $newClass->id)
                        ->where('subject_id', $old->subject_id)
                        ->exists();
                    if (! $exists) {
                        CourseAssignment::create([
                            'school_year_id' => $to->id,
                            'teacher_id'     => $old->teacher_id,
                            'class_id'       => $newClass->id,
                            'subject_id'     => $old->subject_id,
                            'weekly_hours'   => $old->weekly_hours,
                            'coefficient'    => $old->coefficient,
                            'active'         => $old->active,
                        ]);
                        $counts['assignments']++;
                    }
                }
            }

            return $counts + ['class_map' => $classMap];
        });
    }

    // =====================================================================
    // PROMOTION DES ÉLÈVES
    // =====================================================================

    /**
     * Construit le plan de promotion proposé (pour revue par l'admin) : pour chaque
     * inscription validée de $from, l'action suggérée + la classe cible proposée dans $to.
     *
     * @return array[] [enrollment_id, student, from_class, action, target_level, target_class_id, target_class]
     */
    public function promotionPlan(SchoolYear $from, SchoolYear $to): array
    {
        $plan = [];
        $enrollments = $this->forYear(Enrollment::class, $from->id)
            ->where('status', EnrollmentStatus::VALIDATED->value)
            ->with('student')->get();

        foreach ($enrollments as $enr) {
            $fromClass = Classroom::withoutGlobalScope(SchoolYearScope::class)->find($enr->class_id);
            $level     = $fromClass ? GradeLevel::find($fromClass->grade_level_id) : null;
            $nextLevel = $level ? $this->nextGradeLevel($level) : null;

            // Décision PAR DÉFAUT = résultat annuel calculé (AnnualResultComputer).
            // Un élève « retained » redouble (reste au même niveau) ; sinon il monte
            // au niveau suivant (ou sort de l'école si aucun niveau supérieur).
            if ($enr->result === EnrollmentResult::RETAINED) {
                $action      = 'retain';
                $targetLevel = $level;
            } else {
                $action      = $nextLevel ? 'promote' : 'graduate';
                $targetLevel = $nextLevel ?? $level;
            }

            $targetClass = ($targetLevel && $action !== 'graduate')
                ? $this->resolveTargetClass($to, $targetLevel->id, $fromClass) : null;

            // Aucune classe existante pour ce niveau → une sera créée à la promotion.
            $targetNew  = false;
            $targetCode = $targetClass?->code;
            if (! $targetClass && $targetLevel && $action !== 'graduate') {
                $targetCode = $this->proposedTargetCode($targetLevel, $fromClass);
                $targetNew  = true;
            }

            $plan[] = [
                'enrollment_id'    => $enr->id,
                'student'          => $enr->student?->full_name ?? $enr->student?->last_name ?? '—',
                'from_class'       => $fromClass?->code,
                'action'           => $action,
                'annual_average'   => $enr->annual_average,
                'annual_result'    => $enr->result?->value,
                'target_level'     => $targetLevel?->code,
                'target_class_id'  => $targetClass?->id,
                'target_class'     => $targetCode,
                'target_class_new' => $targetNew,
            ];
        }
        return $plan;
    }

    /**
     * Exécute la promotion. $decisions : [enrollment_id => ['action'=>..., 'class_id'=>?]].
     * Actions : promote | retain | graduate | transfer (défaut : promote).
     *
     * @return array Compteurs.
     */
    public function promote(SchoolYear $from, SchoolYear $to, array $decisions = [], array $opts = []): array
    {
        return DB::transaction(function () use ($from, $to, $decisions, $opts) {
            $createClasses = $opts['create_classes'] ?? true;
            $counts   = ['promoted' => 0, 'retained' => 0, 'graduated' => 0, 'transferred' => 0, 'created_classes' => 0, 'skipped' => 0];
            $touched  = []; // classes cibles à recalculer
            $userId   = (int) auth()->id();

            $enrollments = $this->forYear(Enrollment::class, $from->id)
                ->where('status', EnrollmentStatus::VALIDATED->value)->get();

            $seq = $this->forYear(Enrollment::class, $to->id)->count();

            foreach ($enrollments as $old) {
                // déjà promu (idempotence) ?
                $already = $this->forYear(Enrollment::class, $to->id)
                    ->where('student_id', $old->student_id)->exists();
                if ($already) {
                    $counts['skipped']++;
                    continue;
                }

                $decision = $decisions[$old->id] ?? [];
                $action   = $decision['action'] ?? 'promote';

                $fromClass = Classroom::withoutGlobalScope(SchoolYearScope::class)->find($old->class_id);
                $level     = $fromClass ? GradeLevel::find($fromClass->grade_level_id) : null;

                // Résultat de fin d'année sur l'ANCIENNE inscription.
                $result = match ($action) {
                    'retain'    => EnrollmentResult::RETAINED,
                    'transfer'  => EnrollmentResult::TRANSFERRED,
                    'graduate'  => EnrollmentResult::ADMITTED,
                    default     => EnrollmentResult::PROMOTED,
                };
                $old->update(['result' => $result->value]);

                if (in_array($action, ['graduate', 'transfer'], true)) {
                    $counts[$action === 'graduate' ? 'graduated' : 'transferred']++;
                    continue;
                }

                // Niveau + classe cible.
                $targetLevel = $action === 'retain' ? $level : ($level ? $this->nextGradeLevel($level) : null);
                if (! $targetLevel) { // pas de niveau supérieur → diplômé malgré tout
                    $old->update(['result' => EnrollmentResult::ADMITTED->value]);
                    $counts['graduated']++;
                    continue;
                }

                $targetClass = ! empty($decision['class_id'])
                    ? Classroom::withoutGlobalScope(SchoolYearScope::class)->find($decision['class_id'])
                    : $this->resolveTargetClass($to, $targetLevel->id, $fromClass);

                // Pas de classe pour ce niveau dans l'année cible (tête de cohorte montant
                // vers un niveau absent l'an dernier) → on la crée (idempotent).
                if (! $targetClass && $createClasses) {
                    $targetClass = $this->createTargetClass($to, $targetLevel, $fromClass);
                    if ($targetClass->wasRecentlyCreated) {
                        $counts['created_classes']++;
                    }
                }

                if (! $targetClass) {
                    $counts['skipped']++;
                    continue;
                }

                $new = Enrollment::create([
                    'school_year_id'        => $to->id,
                    'reference'             => 'ENR-' . $to->code . '-' . str_pad((string) (++$seq), 4, '0', STR_PAD_LEFT),
                    'student_id'            => $old->student_id,
                    'class_id'              => $targetClass->id,
                    'status'                => EnrollmentStatus::VALIDATED->value,
                    'enrollment_date'       => $to->start_date,
                    'validation_date'       => now(),
                    'validated_by'          => $userId,
                    'previous_enrollment_id'=> $old->id,
                    'is_repeating'          => $action === 'retain',
                ]);

                $touched[$targetClass->id] = $targetClass;
                $counts[$action === 'retain' ? 'retained' : 'promoted']++;
            }

            // Recalcule les effectifs des classes cibles (hors scope année : l'année cible
            // n'est pas forcément active → la relation scopée compterait 0).
            foreach ($touched as $class) {
                $class->current_enrollment = Enrollment::withoutGlobalScope(SchoolYearScope::class)
                    ->where('class_id', $class->id)
                    ->where('status', EnrollmentStatus::VALIDATED->value)->count();
                $class->saveQuietly();
            }

            return $counts;
        });
    }

    /**
     * Reporte le RELIQUAT de frais de l'année source vers l'année cible : pour chaque
     * élève promu qui devait encore de l'argent, crée un frais « Reliquat année précédente »
     * sur sa nouvelle inscription (la dette suit l'élève au lieu de disparaître à la bascule).
     * Idempotent (ne recrée pas un reliquat déjà posé). SchoolFee est rattaché à l'année via
     * son enrollment (pas de school_year_id propre).
     *
     * @return array{carried:int, total:float}
     */
    public function carryForwardBalances(SchoolYear $from, SchoolYear $to): array
    {
        return DB::transaction(function () use ($from, $to) {
            $loc     = config('mt-school-core.multilingual.default', 'fr');
            $feeType = FeeType::firstOrCreate(
                ['code' => 'CARRYOVER'],
                ['label' => [$loc => 'Reliquat année précédente'], 'characteristic' => 'mandatory', 'active' => true],
            );
            $refs   = app(ReferenceSchoolService::class);
            $toYear = $to->start_date ? Carbon::parse($to->start_date)->year : (int) date('Y');

            $counts = ['carried' => 0, 'total' => 0.0];

            $oldEnrollments = $this->forYear(Enrollment::class, $from->id)
                ->where('status', EnrollmentStatus::VALIDATED->value)->get();

            foreach ($oldEnrollments as $old) {
                $outstanding = (float) SchoolFee::where('enrollment_id', $old->id)->sum('remaining_amount');
                if ($outstanding <= 0) {
                    continue;
                }

                $new = $this->forYear(Enrollment::class, $to->id)
                    ->where('student_id', $old->student_id)->first();
                if (! $new) {
                    continue; // pas encore promu → rien à reporter
                }

                // Idempotent : un reliquat déjà posé sur la nouvelle inscription ?
                if (SchoolFee::where('enrollment_id', $new->id)->where('fee_type_id', $feeType->id)->exists()) {
                    continue;
                }

                $currency = SchoolFee::where('enrollment_id', $old->id)->value('currency') ?: 'XAF';

                SchoolFee::create([
                    'reference'        => $refs->schoolFee($toYear),
                    'enrollment_id'    => $new->id,
                    'fee_type_id'      => $feeType->id,
                    'gross_amount'     => $outstanding,
                    'discount'         => 0,
                    'net_amount'       => $outstanding,
                    'amount_paid'      => 0,
                    'remaining_amount' => $outstanding,
                    'currency'         => $currency,
                    'status'           => 'pending',
                ]);

                $counts['carried']++;
                $counts['total'] += $outstanding;
            }

            return $counts;
        });
    }

    /** Choisit la classe cible d'un niveau dans $to : même section (…-A) si possible, sinon la 1re. */
    private function resolveTargetClass(SchoolYear $to, int $gradeLevelId, ?Classroom $originClass): ?Classroom
    {
        $classes = $this->forYear(Classroom::class, $to->id)
            ->where('grade_level_id', $gradeLevelId)->where('active', true)->get();
        if ($classes->isEmpty()) {
            return null;
        }
        if ($originClass && str_contains($originClass->code, '-')) {
            $suffix = $this->sectionSuffix($originClass);
            $match  = $classes->first(fn ($c) => str_ends_with($c->code, '-' . $suffix));
            if ($match) {
                return $match;
            }
        }
        return $classes->first();
    }

    /** Suffixe de section d'une classe (« A » pour « CE1-A »), « A » par défaut. */
    private function sectionSuffix(?Classroom $class): string
    {
        return ($class && str_contains($class->code, '-'))
            ? substr(strrchr($class->code, '-'), 1)
            : 'A';
    }

    /** Code proposé pour la classe cible d'un niveau : « CE2-A ». */
    private function proposedTargetCode(GradeLevel $level, ?Classroom $origin): string
    {
        return $level->code . '-' . $this->sectionSuffix($origin);
    }

    /**
     * Crée (ou réutilise) la classe cible d'un niveau dans $to, calquée sur la classe
     * d'origine (section, capacité, filière). Idempotent (par code).
     */
    private function createTargetClass(SchoolYear $to, GradeLevel $level, ?Classroom $origin): Classroom
    {
        $code     = $this->proposedTargetCode($level, $origin);
        $existing = $this->forYear(Classroom::class, $to->id)->where('code', $code)->first();
        if ($existing) {
            return $existing;
        }

        $loc = config('mt-school-core.multilingual.default', 'fr');

        return Classroom::create([
            'school_year_id'     => $to->id,
            'grade_level_id'     => $level->id,
            'specialization_id'  => $origin?->specialization_id,
            'code'               => $code,
            'label'              => [$loc => $level->code . ' ' . $this->sectionSuffix($origin)],
            'max_capacity'       => $origin?->max_capacity ?? 40,
            'current_enrollment' => 0,
            'active'             => true,
        ]);
    }

    private function shiftYears($date, int $years): ?string
    {
        if (! $date) {
            return null;
        }
        return Carbon::parse($date)->addYears($years)->toDateString();
    }
}
