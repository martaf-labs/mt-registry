<?php

namespace Mt\MtSchoolCore\Services;

use Barryvdh\DomPDF\Facade\Pdf;
use Mt\MtSchoolCore\Enums\ReportCardStatus;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Models\ReportCard;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Models\SubjectAverage;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Handles report card generation and publication.
 */
class ReportCardService
{
    use \Mt\MtSchoolCore\Support\RendersLocalizedPdf;

    // Calcul via ReportCardComputer (source de vérité : moyennes par matière + coefficient
    // de la MAQUETTE + rangs ex-aequo). L'ancien AverageService était incorrect (ignorait
    // le coef matière) — ne plus l'utiliser.
    public function __construct(protected ReportCardComputer $computer) {}

    /**
     * Generate report cards for all validated students in a classroom for a period.
     */
    public function generateForClassroom(int $classId, int $periodId): int
    {
        $this->computer->compute($classId, $periodId);

        $enrollments = Enrollment::where('class_id', $classId)
            ->where('status', 'validated')
            ->get();

        $count = 0;
        foreach ($enrollments as $enrollment) {
            $this->generateForEnrollment($enrollment, $periodId);
            $count++;
        }

        return $count;
    }

    /**
     * Generate a report card for a single enrollment in a given period.
     */
    public function generateForEnrollment(Enrollment $enrollment, int $periodId): ReportCard
    {
        $periodAverage = $enrollment->periodAverageFor($periodId);

        return ReportCard::updateOrCreate(
            ['enrollment_id' => $enrollment->id, 'period_id' => $periodId],
            [
                'period_average_id' => $periodAverage?->id,
                'status'            => ReportCardStatus::GENERATED->value,
                'generated_at'      => now(),
                'principal_name'    => config('mtschool.school.principal', ''),
            ]
        );
    }

    /**
     * Publish all validated report cards for a classroom and period.
     */
    public function publishForClassroom(int $classId, int $periodId): int
    {
        $cards = ReportCard::whereHas(
            'enrollment', fn($q) => $q->where('class_id', $classId)
        )
        ->where('period_id', $periodId)
        ->where('status', ReportCardStatus::VALIDATED->value)
        ->get();

        $notifier = app(NotificationService::class);
        foreach ($cards as $rc) {
            $rc->publish();
            // Notifie l'élève + ses tuteurs que le bulletin est disponible.
            $notifier->notifyReportCardPublished($rc);
        }

        return $cards->count();
    }

    // ── PDF ───────────────────────────────────────────────────────────────────

    /** PDF d'un seul bulletin. */
    public function pdfForEnrollment(int $enrollmentId, int $periodId)
    {
        // Réimpression possible d'un bulletin d'une année PASSÉE (hors année active) :
        // on neutralise le SchoolYearScope, le SchoolScope (tenant) reste appliqué.
        $enrollment = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->with('student', 'classroom')->findOrFail($enrollmentId);
        return $this->buildPdf([$enrollment], $periodId);
    }

    /** PDF de tous les bulletins d'une classe (un par page), triés par rang. */
    public function pdfForClassroom(int $classId, int $periodId)
    {
        $enrollments = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->where('class_id', $classId)->validated()
            ->with('student', 'classroom')->get();

        // Tri par rang du PeriodAverage (sinon par nom).
        $ranks = PeriodAverage::where('period_id', $periodId)
            ->whereIn('enrollment_id', $enrollments->pluck('id'))
            ->pluck('rank', 'enrollment_id');

        $enrollments = $enrollments->sortBy(
            fn ($e) => $ranks[$e->id] ?? 9999
        )->values();

        return $this->buildPdf($enrollments, $periodId);
    }

    // ── PDF ANNUEL (synthèse des périodes + moyenne/rang/décision annuels) ──────

    /** PDF du bulletin ANNUEL d'un seul élève. */
    public function annualPdfForEnrollment(int $enrollmentId, int $yearId)
    {
        $enrollment = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->with('student', 'classroom')->findOrFail($enrollmentId);
        return $this->buildAnnualPdf([$enrollment], $yearId);
    }

    /** PDF des bulletins annuels d'une classe (un par page), triés par rang annuel. */
    public function annualPdfForClassroom(int $classId, int $yearId)
    {
        $enrollments = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->where('class_id', $classId)->where('status', 'validated')
            ->with('student', 'classroom')->get()
            ->sortBy(fn ($e) => $e->annual_rank ?? 9999)->values();

        return $this->buildAnnualPdf($enrollments, $yearId);
    }

    /**
     * Construit le bulletin annuel : pour chaque matière, la moyenne de chaque période +
     * la moyenne annuelle de la matière (pondérée par le poids de période) ; puis la
     * synthèse (moyenne/rang annuels + décision passage/redoublement).
     * Les moyennes annuelles/rangs/décisions viennent de AnnualResultComputer.
     */
    protected function buildAnnualPdf($enrollments, int $yearId)
    {
        $periods = Period::withoutGlobalScope(SchoolYearScope::class)
            ->where('school_year_id', $yearId)->whereNull('parent_id')
            ->orderBy('order')->get();
        $periodIds = $periods->pluck('id');

        $enrollments = collect($enrollments);
        $classSize   = $enrollments->count();

        $cards = [];
        foreach ($enrollments as $e) {
            $sas = SubjectAverage::where('enrollment_id', $e->id)
                ->whereIn('period_id', $periodIds)->with('subject')->get();

            // Regroupe par matière : moyennes de chaque période.
            $bySubject = [];
            foreach ($sas as $sa) {
                $sid = $sa->subject_id;
                if (! isset($bySubject[$sid])) {
                    $bySubject[$sid] = ['subject' => $sa->subject, 'coef' => (float) $sa->coefficient, 'periods' => []];
                }
                $bySubject[$sid]['periods'][$sa->period_id] = (float) $sa->average;
            }

            // Moyenne annuelle par matière (pondérée par le poids de chaque période présente).
            $rows = [];
            foreach ($bySubject as $d) {
                [$sumW, $sumWA] = [0.0, 0.0];
                foreach ($periods as $p) {
                    if (isset($d['periods'][$p->id])) {
                        $w = (float) ($p->weight ?? 1);
                        $sumWA += $d['periods'][$p->id] * $w;
                        $sumW  += $w;
                    }
                }
                $rows[] = [
                    'subject' => $d['subject'],
                    'coef'    => $d['coef'],
                    'periods' => $d['periods'],
                    'annual'  => $sumW > 0 ? round($sumWA / $sumW, 2) : null,
                ];
            }
            usort($rows, fn ($a, $b) => strcmp((string) ($a['subject']?->code), (string) ($b['subject']?->code)));

            $cards[] = [
                'enrollment'     => $e,
                'rows'           => $rows,
                'annual_average' => $e->annual_average,
                'annual_rank'    => $e->annual_rank,
                'result'         => $e->result, // EnrollmentResult|null
                'class_size'     => $classSize,
            ];
        }

        $schoolName = function_exists('mt_brand_name') ? (mt_brand_name() ?? '') : '';
        $year       = SchoolYear::find($yearId)?->label; // SchoolScope (tenant) conservé
        $locale     = app()->getLocale();
        $schoolYear = is_array($year) ? ($year[$locale] ?? $year['fr'] ?? reset($year) ?: '') : (string) ($year ?? '');

        return $this->renderPdf('mtschool::pdf.annual-report-card', compact('cards', 'periods', 'schoolName', 'schoolYear'));
    }

    /** Construit le PDF (vue `mtschool::pdf.report-card`) pour une liste d'inscriptions. */
    protected function buildPdf($enrollments, int $periodId)
    {
        $period = Period::withoutGlobalScope(SchoolYearScope::class)->findOrFail($periodId);

        $cards = [];
        foreach ($enrollments as $e) {
            $subjects = SubjectAverage::where('enrollment_id', $e->id)
                ->where('period_id', $periodId)->with('subject')->get()
                ->sortBy(fn ($sa) => $sa->subject?->code)->values();

            $cards[] = [
                'enrollment'    => $e,
                'period'        => $period,
                'subjects'      => $subjects,
                'periodAverage' => PeriodAverage::where('enrollment_id', $e->id)
                    ->where('period_id', $periodId)->first(),
            ];
        }

        $schoolName = function_exists('mt_brand_name') ? (mt_brand_name() ?? '') : '';
        // Année AFFICHÉE = celle de la période du bulletin (et non l'année ACTIVE) →
        // une réimpression d'un bulletin d'une année passée montre la bonne année.
        $year       = $period->schoolYear?->label ?? SchoolYear::where('is_active', true)->first()?->label;
        $locale     = app()->getLocale();
        $schoolYear = is_array($year) ? ($year[$locale] ?? $year['fr'] ?? reset($year) ?: '') : (string) ($year ?? '');

        return $this->renderPdf('mtschool::pdf.report-card', compact('cards', 'schoolName', 'schoolYear'));
    }
}
