<?php

namespace Mt\MtSchoolCore\Services;

use Carbon\Carbon;
use Mt\MtSchoolCore\Enums\PeriodType;
use Mt\MtSchoolCore\Models\Period;
use Mt\MtSchoolCore\Models\SchoolYear;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Génère automatiquement le découpage de l'année en périodes
 * (trimestres / semestres) à partir des dates de l'année scolaire.
 *
 * Résout le manque constaté en simulation : une année fraîchement créée
 * n'a aucune période → impossible de noter/éditer un bulletin tant que
 * l'admin n'a pas saisi les trimestres à la main.
 */
class PeriodTemplateService
{
    /** template => [nombre de périodes, type, préfixe code, clé de libellé] */
    private const TEMPLATES = [
        'trimester' => ['count' => 3, 'type' => PeriodType::TERM,     'prefix' => 'T', 'label_key' => 'mtschool::structure.period_term_label'],
        'semester'  => ['count' => 2, 'type' => PeriodType::SEMESTER, 'prefix' => 'S', 'label_key' => 'mtschool::structure.period_semester_label'],
    ];

    /** Options prêtes pour un champ select de formulaire ([valeur => libellé]). */
    public static function options(): array
    {
        return [
            'none'      => __('mtschool::structure.period_template_none'),
            'trimester' => __('mtschool::structure.period_template_trimester'),
            'semester'  => __('mtschool::structure.period_template_semester'),
        ];
    }

    public static function isTemplate(?string $template): bool
    {
        return isset(self::TEMPLATES[$template]);
    }

    /**
     * Crée les périodes d'un modèle donné pour l'année.
     * Idempotent (firstOrCreate sur school_year_id + code) et sûr :
     * ne fait rien si l'année a déjà des périodes.
     *
     * @return int Nombre de périodes réellement créées.
     */
    public function generate(SchoolYear $year, string $template): int
    {
        $tpl = self::TEMPLATES[$template] ?? null;
        if (! $tpl) {
            return 0;
        }

        // On cible une année précise (souvent PAS l'année active : nouvelle année
        // pas encore basculée) → il faut neutraliser le SchoolYearScope, qui filtre
        // sinon sur l'année active et fausse à la fois le contrôle d'existence et le
        // firstOrCreate (2e appel = violation d'unicité au lieu d'un no-op).
        $query = fn () => Period::withoutGlobalScope(SchoolYearScope::class)
            ->where('school_year_id', $year->id);

        // Ne pas écraser un découpage déjà en place.
        if ($query()->exists()) {
            return 0;
        }

        $start = $year->start_date ? Carbon::parse($year->start_date) : null;
        $end   = $year->end_date ? Carbon::parse($year->end_date) : null;
        if (! $start || ! $end || $end->lessThanOrEqualTo($start)) {
            return 0;
        }

        $count     = $tpl['count'];
        $totalDays = $start->diffInDays($end);
        $span      = intdiv($totalDays, $count);
        $locale    = config('mt-school-core.multilingual.default', 'fr');

        $created = 0;
        for ($i = 1; $i <= $count; $i++) {
            $pStart = $start->copy()->addDays($span * ($i - 1));
            $pEnd   = $i === $count
                ? $end->copy()
                : $start->copy()->addDays($span * $i)->subDay();

            $period = $query()->firstOrCreate(
                ['school_year_id' => $year->id, 'code' => $tpl['prefix'] . $i],
                [
                    'type'       => $tpl['type']->value,
                    'label'      => [$locale => __($tpl['label_key'], ['n' => $i], $locale)],
                    'start_date' => $pStart->toDateString(),
                    'end_date'   => $pEnd->toDateString(),
                    'order'      => $i,
                    'weight'     => 1,
                    'is_active'  => $i === 1,
                    'is_closed'  => false,
                ]
            );

            if ($period->wasRecentlyCreated) {
                $created++;
            }
        }

        return $created;
    }
}
