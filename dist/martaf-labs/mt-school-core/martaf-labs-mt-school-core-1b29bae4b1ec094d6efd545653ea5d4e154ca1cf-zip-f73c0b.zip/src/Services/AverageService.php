<?php

namespace Mt\MtSchoolCore\Services;

use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\SubjectAverage;
use Mt\MtSchoolCore\Models\PeriodAverage;
use Mt\MtSchoolCore\Enums\Mention;

/**
 * @deprecated Calcul INCORRECT (ignore le coefficient matière de la maquette et ne calcule
 * pas les SubjectAverage). Utiliser Services\ReportCardComputer à la place.
 *
 * Computes subject and period averages for a classroom.
 */
class AverageService
{
    /**
     * Compute and persist averages for all validated enrollments in a classroom for a period.
     */
    public function computeForClassroom(int $classId, int $periodId): void
    {
        $enrollments = Enrollment::where('class_id', $classId)
            ->where('status', 'validated')
            ->get();

        foreach ($enrollments as $enrollment) {
            $this->computeForEnrollment($enrollment, $periodId);
        }

        $this->computeRanks($classId, $periodId);
    }

    /**
     * Compute and persist the period average for a single enrollment.
     */
    public function computeForEnrollment(Enrollment $enrollment, int $periodId): ?PeriodAverage
    {
        $grades = $enrollment->grades()
            ->whereHas('assessment', fn($q) =>
                $q->where('period_id', $periodId)->where('status', 'validated')
            )
            ->with('assessment')
            ->get();

        if ($grades->isEmpty()) return null;

        $totalPoints       = 0;
        $totalCoefficients = 0;

        foreach ($grades as $grade) {
            if ($grade->is_absent && !$grade->justified_absence) {
                $score = 0;
            } elseif ($grade->final_score === null) {
                continue;
            } else {
                $score = (float) $grade->score_normalised; // normalised to /20
            }

            $coef               = (float) $grade->assessment->coefficient;
            $totalPoints       += $score * $coef;
            $totalCoefficients += $coef;
        }

        if ($totalCoefficients == 0) return null;

        $average = round($totalPoints / $totalCoefficients, 2);

        return PeriodAverage::updateOrCreate(
            ['enrollment_id' => $enrollment->id, 'period_id' => $periodId],
            [
                'overall_average'    => $average,
                'total_points'       => $totalPoints,
                'total_coefficients' => $totalCoefficients,
                'mention'            => Mention::fromAverage($average)->value,
            ]
        );
    }

    /**
     * Compute and persist ranks for a classroom in a period.
     */
    public function computeRanks(int $classId, int $periodId): void
    {
        $averages = PeriodAverage::whereHas(
            'enrollment', fn($q) => $q->where('class_id', $classId)
        )
        ->where('period_id', $periodId)
        ->orderByDesc('overall_average')
        ->get();

        $classSize = $averages->count();
        $rank      = 1;

        foreach ($averages as $avg) {
            $avg->update(['rank' => $rank, 'class_size' => $classSize]);
            $rank++;
        }
    }
}
