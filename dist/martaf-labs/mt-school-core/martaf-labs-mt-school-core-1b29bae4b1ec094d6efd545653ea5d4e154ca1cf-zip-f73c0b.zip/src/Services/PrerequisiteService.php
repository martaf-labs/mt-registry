<?php

namespace Mt\MtSchoolCore\Services;

use Mt\MtSchoolCore\Models\Assessment;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\CourseAssignment;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\FeeSchedule;
use Mt\MtSchoolCore\Models\FeeType;
use Mt\MtSchoolCore\Models\Grade;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\Subject;
use Mt\MtSchoolCore\Models\Teacher;

/**
 * INTERDÉPENDANCE DES MODULES — source de vérité unique de la chaîne de prérequis :
 *
 *   Classes ─┐
 *   Matières ┼→ Affectations → Évaluations → Notes → Moyennes/Bulletins
 *   Profs   ─┘
 *   Classes → Inscriptions → Frais (types → grille → paiements) / Certificats / Bourses
 *   Affectations → Emploi du temps
 *
 * Un écran ne doit pas présenter un formulaire inutilisable : quand ses prérequis
 * manquent, il affiche un panneau « avant de continuer » avec le chemin à suivre
 * (cf. vue partagée mtschool::livewire.shared.prerequisites). La navigation reste
 * LIBRE — on guide l'action, on ne masque pas les menus.
 *
 * Tout est school-scopé automatiquement (SchoolScope sur les modèles).
 */
class PrerequisiteService
{
    /**
     * Les briques vérifiables. Chaque brique : met (bool paresseux), message, CTA.
     * `route` = clé logique de config/routes.php (résolue par mt_get_route).
     */
    protected function checks(): array
    {
        return [
            'classes' => [
                'met'       => fn () => Classroom::query()->exists(),
                'message'   => 'prereq_classes',
                'cta_label' => 'prereq_classes_cta',
                'route'     => 'classrooms',
            ],
            'subjects' => [
                'met'       => fn () => Subject::query()->exists(),
                'message'   => 'prereq_subjects',
                'cta_label' => 'prereq_subjects_cta',
                'route'     => 'subjects',
            ],
            'teachers' => [
                'met'       => fn () => Teacher::query()->exists(),
                'message'   => 'prereq_teachers',
                'cta_label' => 'prereq_teachers_cta',
                'route'     => 'staff_teachers',
            ],
            'assignments' => [
                'met'       => fn () => CourseAssignment::query()->exists(),
                'message'   => 'prereq_assignments',
                'cta_label' => 'prereq_assignments_cta',
                'route'     => 'staff_assignments',
            ],
            'students' => [
                'met'       => fn () => Student::query()->exists(),
                'message'   => 'prereq_students',
                'cta_label' => 'prereq_students_cta',
                'route'     => 'students_index',
            ],
            'enrollments' => [
                'met'       => fn () => Enrollment::query()->exists(),
                'message'   => 'prereq_enrollments',
                'cta_label' => 'prereq_enrollments_cta',
                'route'     => 'students_enrollments',
            ],
            'fee_types' => [
                'met'       => fn () => FeeType::query()->exists(),
                'message'   => 'prereq_fee_types',
                'cta_label' => 'prereq_fee_types_cta',
                'route'     => 'finances_fees',
            ],
            'fee_schedule' => [
                'met'       => fn () => FeeSchedule::query()->exists(),
                'message'   => 'prereq_fee_schedule',
                'cta_label' => 'prereq_fee_schedule_cta',
                'route'     => 'finances_fees_schedule',
            ],
            'assessments' => [
                'met'       => fn () => Assessment::query()->exists(),
                'message'   => 'prereq_assessments',
                'cta_label' => 'prereq_assessments_cta',
                'route'     => 'academics_assessments',
            ],
            'grades' => [
                'met'       => fn () => Grade::query()->exists(),
                'message'   => 'prereq_grades',
                'cta_label' => 'prereq_grades_cta',
                'route'     => 'academics_assessments',
            ],
        ];
    }

    /** Prérequis par ÉCRAN. Ordre = ordre logique de résolution. */
    protected function screens(): array
    {
        return [
            'enrollments'  => ['classes'],
            'assignments'  => ['classes', 'subjects', 'teachers'],
            'timetable'    => ['assignments'],
            'assessments'  => ['assignments'],
            'grade_entry'  => ['assessments', 'enrollments'],
            'results'      => ['enrollments', 'grades'],
            'fee_schedule' => ['fee_types'],
            'payments'     => ['enrollments', 'fee_schedule'],
            'scholarships' => ['enrollments'],
            'certificates' => ['enrollments'],
            'class_councils' => ['classes', 'enrollments'],
        ];
    }

    /**
     * Prérequis NON satisfaits d'un écran, prêts pour l'affichage :
     * [['message' => …, 'url' => …, 'cta' => …], …]. Vide = écran utilisable.
     */
    public function missingFor(string $screen): array
    {
        $checks  = $this->checks();
        $missing = [];

        foreach ($this->screens()[$screen] ?? [] as $key) {
            $check = $checks[$key] ?? null;
            if (! $check || ($check['met'])()) {
                continue;
            }
            $missing[] = [
                'key'     => $key,
                'message' => __('mtschool::prerequisites.' . $check['message']),
                'cta'     => __('mtschool::prerequisites.' . $check['cta_label']),
                'url'     => mt_get_route($check['route']),
            ];
        }

        return $missing;
    }

    /**
     * Checklist de démarrage (dashboard) : chaque étape avec son état.
     * Ordre = parcours de mise en route recommandé.
     */
    public function checklist(): array
    {
        $order  = ['classes', 'subjects', 'teachers', 'assignments', 'students', 'enrollments', 'fee_types', 'fee_schedule', 'assessments'];
        $checks = $this->checks();
        $items  = [];

        foreach ($order as $key) {
            $check   = $checks[$key];
            $items[] = [
                'key'   => $key,
                'label' => __('mtschool::prerequisites.step_' . $key),
                'met'   => ($check['met'])(),
                'url'   => mt_get_route($check['route']),
            ];
        }

        return $items;
    }
}
