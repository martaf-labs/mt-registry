<?php

namespace Mt\MtSchoolCore\Services;

use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\SchoolCertificate;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Délivrance des CERTIFICATS officiels (scolarité, fréquentation, réussite, radiation).
 *
 * `issue()` crée l'enregistrement (référencé, statut « issued », traçant l'émetteur) ;
 * `pdf()` rend le document. Lectures hors SchoolYearScope (on peut délivrer un certificat
 * pour une année passée) ; SchoolScope (tenant) conservé.
 */
class CertificateService
{
    use \Mt\MtSchoolCore\Support\RendersLocalizedPdf;

    /** Types supportés (le libellé/corps vient de lang `documents.cert_{title,body}_<type>`). */
    public const TYPES = ['enrollment', 'attendance', 'success', 'leaving'];

    public function __construct(protected ReferenceSchoolService $references) {}

    public function issue(int $enrollmentId, string $type): SchoolCertificate
    {
        $type = in_array($type, self::TYPES, true) ? $type : 'enrollment';

        $enrollment = Enrollment::withoutGlobalScope(SchoolYearScope::class)->findOrFail($enrollmentId);
        $year       = $enrollment->schoolYear?->start_date
            ? Carbon::parse($enrollment->schoolYear->start_date)->year
            : (int) date('Y');
        $loc        = config('mt-school-core.multilingual.default', 'fr');

        return SchoolCertificate::create([
            'reference'    => $this->references->certificate($year),
            'enrollment_id'=> $enrollment->id,
            'type'         => $type,
            'title'        => [$loc => __('mtschool::documents.cert_title_' . $type)],
            'language'     => $loc,
            'status'       => 'issued',
            'requested_by' => auth()->id(),
            'requested_at' => now(),
            'issued_by'    => auth()->id(),
            'issued_at'    => now(),
            'copies_count' => 1,
            'valid_until'  => now()->addMonths(3),
        ]);
    }

    /** PDF d'un certificat (délivré). */
    public function pdf(int $certificateId)
    {
        $cert       = SchoolCertificate::findOrFail($certificateId); // SchoolScope → tenant-safe
        $enrollment = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->with('student', 'classroom')->findOrFail($cert->enrollment_id);

        $data       = $this->documentData($cert, $enrollment);
        $schoolName = function_exists('mt_brand_name') ? (mt_brand_name() ?? '') : '';

        return $this->renderPdf('mtschool::pdf.certificate', compact('cert', 'data', 'schoolName'));
    }

    /** Données prêtes pour le corps du certificat (nom, dates, classe, année, corps traduit). */
    protected function documentData(SchoolCertificate $cert, Enrollment $enrollment): array
    {
        $loc     = app()->getLocale();
        $lv      = fn ($v) => is_array($v) ? ($v[$loc] ?? $v['fr'] ?? reset($v) ?: '') : (string) ($v ?? '');
        $student = $enrollment->student;

        $class = $lv($enrollment->classroom?->label);
        $year  = $lv($enrollment->schoolYear?->label);
        $name  = $student?->full_name_reverse ?? $student?->full_name ?? '—';
        $dob   = $student?->birth_date ? Carbon::parse($student->birth_date)->format('d/m/Y') : '—';
        $place = $student?->birth_place ?: '—';
        $ref   = $student?->reference ?: '—';

        $body = __('mtschool::documents.cert_body_' . $cert->type, [
            'student'    => $name,
            'dob'        => $dob,
            'birthplace' => $place,
            'ref'        => $ref,
            'class'      => $class ?: '—',
            'year'       => $year ?: '—',
            'date'       => $cert->issued_at?->format('d/m/Y') ?? now()->format('d/m/Y'),
        ]);

        return [
            'title'   => $lv($cert->title),
            'body'    => $body,
            'student' => $name,
            'class'   => $class,
            'year'    => $year,
            'ref'     => $cert->reference,
            'issued'  => $cert->issued_at?->format('d/m/Y') ?? now()->format('d/m/Y'),
        ];
    }
}
