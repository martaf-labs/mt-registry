<?php

namespace Mt\MtSchoolCore\Services;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Mt\MtSchoolCore\Enums\RoleSchool;
use Mt\MtSchoolCore\Models\Guardian;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\Teacher;
use Mt\MtSchoolCore\Models\User;

/**
 * Provision de comptes portail : crée le `User` (login) lié à un profil métier
 * (enseignant / tuteur / élève) via le morph `userable` + le `school_role`.
 *
 * Résout la lacune n°1 des portails : sans cet écran/service, seul le seeder crée des
 * comptes → les portails Teacher/Student/Parent sont inatteignables en production.
 *
 * Idempotent : un profil déjà lié à un User n'en recrée pas un second.
 */
class PortalAccountService
{
    /** Profil → [alias morph (userable_type), rôle portail]. */
    private function meta(Model $profile): ?array
    {
        return match (true) {
            $profile instanceof Teacher  => ['teacher',  RoleSchool::TEACHER],
            $profile instanceof Guardian => ['guardian', RoleSchool::PARENT],
            $profile instanceof Student  => ['student',  RoleSchool::STUDENT],
            default                      => null,
        };
    }

    public function isProvisionable(Model $profile): bool
    {
        return $this->meta($profile) !== null;
    }

    /** Compte portail déjà lié à ce profil (ou null). */
    public function accountFor(Model $profile): ?User
    {
        $meta = $this->meta($profile);
        if (! $meta) {
            return null;
        }

        return User::where('userable_type', $meta[0])
            ->where('userable_id', $profile->getKey())
            ->first();
    }

    /**
     * Provisionne (ou retourne) le compte portail d'un profil.
     *
     * @return array{user: User, created: bool, password: ?string}
     */
    public function provision(Model $profile, ?string $email = null, ?string $password = null): array
    {
        $meta = $this->meta($profile);
        if (! $meta) {
            throw new \InvalidArgumentException('Profil non provisionnable : ' . $profile::class);
        }
        [$type, $role] = $meta;

        // Déjà un compte → on ne recrée pas (idempotent).
        if ($existing = $this->accountFor($profile)) {
            return ['user' => $existing, 'created' => false, 'password' => null];
        }

        $email = $email ?: $profile->email;
        if (! $email) {
            throw new \RuntimeException(__('mtschool::portal.provision_no_email'));
        }
        if (User::where('email', $email)->exists()) {
            throw new \RuntimeException(__('mtschool::portal.provision_email_taken', ['email' => $email]));
        }

        $plain = $password ?: Str::password(10, symbols: false);

        $user = User::create([
            'name'          => (string) ($profile->full_name ?: $email),
            'email'         => $email,
            'password'      => Hash::make($plain),
            'school_id'     => $profile->school_id ?? currentSchoolId(),
            'school_role'   => $role->value,
            'userable_type' => $type,
            'userable_id'   => $profile->getKey(),
            'is_active'     => true,
        ]);

        // Marque le profil comme ayant un compte (si la colonne existe) → stats fiables.
        if (Schema::hasColumn($profile->getTable(), 'has_user_account')) {
            $profile->forceFill(['has_user_account' => true])->saveQuietly();
        }

        return ['user' => $user, 'created' => true, 'password' => $plain];
    }

    /**
     * Provisionne EN MASSE les comptes des tuteurs sans compte (école courante).
     * Login = e-mail du tuteur, sinon identifiant généré depuis le téléphone. Renvoie les
     * identifiants créés (à exporter/distribuer — les mots de passe temporaires ne sont
     * visibles qu'ici). Idempotent : un tuteur déjà provisionné est ignoré.
     *
     * @return array{credentials: array<int, array{guardian:string, login:string, password:string}>, skipped:int}
     */
    public function bulkProvisionGuardians(): array
    {
        $credentials = [];
        $skipped     = 0;

        Guardian::query()->orderBy('id')->chunk(200, function ($guardians) use (&$credentials, &$skipped) {
            foreach ($guardians as $guardian) {
                if ($this->accountFor($guardian)) {
                    continue; // déjà un compte
                }

                $login = $guardian->email
                    ?: (Str::slug((string) ($guardian->phone ?: 'tuteur-' . $guardian->id)) . '@parent.local');

                try {
                    $result = $this->provision($guardian, $login);
                    if ($result['created']) {
                        $credentials[] = [
                            'guardian' => (string) ($guardian->full_name ?? $guardian->last_name),
                            'login'    => $result['user']->email,
                            'password' => (string) $result['password'],
                        ];
                    }
                } catch (\Throwable $e) {
                    $skipped++; // e-mail déjà pris, etc. → on n'interrompt pas le lot
                }
            }
        });

        return ['credentials' => $credentials, 'skipped' => $skipped];
    }

    /**
     * Provisionne EN MASSE les comptes des élèves sans compte (école courante).
     * Login = e-mail de l'élève, sinon identifiant généré depuis le matricule. Idempotent.
     *
     * @return array{credentials: array<int, array{student:string, login:string, password:string}>, skipped:int}
     */
    public function bulkProvisionStudents(): array
    {
        $credentials = [];
        $skipped     = 0;

        Student::query()->orderBy('id')->chunk(200, function ($students) use (&$credentials, &$skipped) {
            foreach ($students as $student) {
                if ($this->accountFor($student)) {
                    continue;
                }

                $login = $student->email
                    ?: (Str::slug((string) ($student->reference ?: 'eleve-' . $student->id))
                        . '@el' . ($student->school_id ?? currentSchoolId()) . '.local');

                try {
                    $result = $this->provision($student, $login);
                    if ($result['created']) {
                        $credentials[] = [
                            'student'  => (string) ($student->full_name ?? $student->last_name),
                            'login'    => $result['user']->email,
                            'password' => (string) $result['password'],
                        ];
                    }
                } catch (\Throwable $e) {
                    $skipped++;
                }
            }
        });

        return ['credentials' => $credentials, 'skipped' => $skipped];
    }
}
