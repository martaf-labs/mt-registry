<?php

namespace Mt\MtSchoolCore\Services;

use Illuminate\Support\Facades\DB;
use Mt\MtSchoolCore\Models\Classroom;
use Mt\MtSchoolCore\Models\Curriculum;
use Mt\MtSchoolCore\Models\Cycle;
use Mt\MtSchoolCore\Models\GradeLevel;
use Mt\MtSchoolCore\Models\Subject;

/**
 * Pré-remplissage de données TYPES au démarrage (jour-2 après achat) : matières
 * standard du cycle, une classe par niveau, et une maquette (curriculum) par niveau
 * reliant les matières avec des coefficients par défaut.
 *
 * Idempotent (firstOrCreate / attach conditionnel) → relançable sans doublon. Tout est
 * créé pour l'école courante et l'année ACTIVE (school_id / school_year_id auto-remplis).
 * L'admin ajuste ensuite (coefficients, classes supplémentaires, matières).
 */
class ReferenceDataService
{
    /**
     * Matières de référence par type de cycle : [code, libellé fr, groupe, coefficient].
     * Codes uniques PAR ÉCOLE (contrainte subjects_school_id_code_unique).
     */
    public const SUBJECTS = [
        'preschool' => [
            ['LANG', 'Langage', 'literary', 1],
            ['EVEIL', 'Éveil', 'scientific', 1],
            ['GRAPH', 'Graphisme', 'artistic', 1],
            ['MOTRI', 'Motricité', 'physical', 1],
            ['VIVRE', 'Vivre ensemble', 'other', 1],
        ],
        'primary' => [
            ['FR', 'Français', 'literary', 4],
            ['MATH', 'Mathématiques', 'scientific', 4],
            ['EVSC', 'Éveil scientifique', 'scientific', 2],
            ['HG', 'Histoire-Géographie', 'literary', 2],
            ['EC', 'Éducation civique', 'other', 1],
            ['ANG', 'Anglais', 'literary', 2],
            ['EPS', 'Éducation physique et sportive', 'physical', 1],
            ['ART', 'Éducation artistique', 'artistic', 1],
        ],
        // Collège (6e→3e) : tronc commun du 1er cycle du secondaire.
        'college' => [
            ['FR', 'Français', 'literary', 4],
            ['MATH', 'Mathématiques', 'scientific', 4],
            ['ANG', 'Anglais', 'literary', 3],
            ['SVT', 'Sciences de la Vie et de la Terre', 'scientific', 3],
            ['PC', 'Physique-Chimie', 'scientific', 3],
            ['HG', 'Histoire-Géographie', 'literary', 3],
            ['EMC', 'Éducation civique et morale', 'other', 1],
            ['INFO', 'Informatique', 'technical', 1],
            ['EPS', 'Éducation physique et sportive', 'physical', 1],
        ],
        // Lycée (2nde→Tle) : + Philosophie (2nd cycle du secondaire).
        'lycee' => [
            ['FR', 'Français', 'literary', 4],
            ['MATH', 'Mathématiques', 'scientific', 4],
            ['ANG', 'Anglais', 'literary', 3],
            ['SVT', 'Sciences de la Vie et de la Terre', 'scientific', 3],
            ['PC', 'Physique-Chimie', 'scientific', 3],
            ['HG', 'Histoire-Géographie', 'literary', 3],
            ['PHILO', 'Philosophie', 'literary', 2],
            ['INFO', 'Informatique', 'technical', 1],
            ['EPS', 'Éducation physique et sportive', 'physical', 1],
        ],
        'higher' => [],
    ];

    /**
     * @return array{subjects:int, classes:int, curricula:int, links:int}
     */
    public function prefill(int $cycleId): array
    {
        return DB::transaction(function () use ($cycleId) {
            $cycle = Cycle::findOrFail($cycleId); // SchoolScope → tenant-safe
            $type  = $cycle->type instanceof \BackedEnum ? $cycle->type->value : (string) $cycle->type;
            $loc   = config('mt-school-core.multilingual.default', 'fr');

            $counts = ['subjects' => 0, 'classes' => 0, 'curricula' => 0, 'links' => 0];

            // 1) Matières standard du cycle (par école, idempotent).
            $subjectCoef = []; // subject_id => coefficient
            foreach (self::SUBJECTS[$type] ?? [] as [$code, $label, $group, $coef]) {
                $subject = Subject::firstOrCreate(
                    ['code' => $code],
                    [
                        'label'   => [$loc => $label],
                        'group'   => $group,
                        'is_core' => in_array($group, ['literary', 'scientific'], true),
                        'active'  => true,
                    ],
                );
                if ($subject->wasRecentlyCreated) {
                    $counts['subjects']++;
                }
                $subjectCoef[$subject->id] = $coef;
            }

            // 2) Une classe + une maquette par niveau du cycle (année active).
            $levels = GradeLevel::where('cycle_id', $cycleId)->orderBy('order')->get();
            foreach ($levels as $level) {
                $levelLabel = is_array($level->label)
                    ? ($level->label[$loc] ?? reset($level->label) ?: $level->code)
                    : ($level->label ?: $level->code);

                $class = Classroom::firstOrCreate(
                    ['code' => $level->code], // school_year_id + school_id via scopes/traits
                    [
                        'grade_level_id' => $level->id,
                        'label'          => [$loc => $levelLabel],
                        'max_capacity'   => 60,
                        'active'         => true,
                    ],
                );
                if ($class->wasRecentlyCreated) {
                    $counts['classes']++;
                }

                $curriculum = Curriculum::firstOrCreate(
                    ['grade_level_id' => $level->id, 'code' => 'CURR-' . $level->code],
                    [
                        'label'  => [$loc => 'Maquette ' . $levelLabel],
                        'active' => true,
                    ],
                );
                if ($curriculum->wasRecentlyCreated) {
                    $counts['curricula']++;
                }

                // Relie les matières (coef par défaut, ordre) — sans re-attacher.
                $order = 1;
                foreach ($subjectCoef as $subjectId => $coef) {
                    if (! $curriculum->subjects()->where('subjects.id', $subjectId)->exists()) {
                        $curriculum->subjects()->attach($subjectId, [
                            'coefficient'    => $coef,
                            'order'          => $order,
                            'on_report_card' => true,
                        ]);
                        $counts['links']++;
                    }
                    $order++;
                }
            }

            return $counts;
        });
    }
}
