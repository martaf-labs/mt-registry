<?php

namespace Mt\MtSchoolCore\Services;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Mail;
use Mt\MtSchoolCore\Mail\SchoolNotificationMail;
use Mt\MtSchoolCore\Models\Announcement;
use Mt\MtSchoolCore\Models\DisciplinarySanction;
use Mt\MtSchoolCore\Models\Enrollment;
use Mt\MtSchoolCore\Models\ReportCard;
use Mt\MtSchoolCore\Models\SchoolNotification;
use Mt\MtSchoolCore\Models\Setting;
use Mt\MtSchoolCore\Models\Student;
use Mt\MtSchoolCore\Models\User;
use Mt\MtSchoolCore\Scopes\SchoolYearScope;

/**
 * Notifications in-app : crée des SchoolNotification pour des utilisateurs.
 *
 * ⚠️ User n'a PAS de SchoolScope (récursion auth) → TOUJOURS filtrer school_id à la main
 * quand on cible des destinataires (sinon fuite cross-tenant).
 */
class NotificationService
{
    /**
     * Crée une notification pour chaque user donné.
     *
     * @param  iterable      $userIds
     * @param  string|array  $title  string (locale par défaut) ou tableau {locale:…}
     * @param  string|array  $body
     */
    public function notify(
        iterable $userIds,
        string|array $title,
        string|array $body = '',
        string $type = 'info',
        ?string $url = null,
        ?Model $subject = null,
    ): int {
        $loc   = config('mt-school-core.multilingual.default', 'fr');
        $title = is_array($title) ? $title : [$loc => $title];
        $body  = is_array($body) ? $body : ($body !== '' ? [$loc => $body] : null);

        $ids = [];
        foreach (collect($userIds)->filter()->unique() as $uid) {
            SchoolNotification::create([
                'user_id'         => (int) $uid,
                'title'           => $title,
                'body'            => $body,
                'type'            => $type,
                'notifiable_type' => $subject?->getMorphClass(),
                'notifiable_id'   => $subject?->getKey(),
                'url'             => $url,
                'is_read'         => false,
            ]);
            $ids[] = (int) $uid;
        }

        // Miroir e-mail (opt-in) — n'impacte JAMAIS la notification in-app en cas d'échec.
        $this->emailUsers($ids, $title, $body, $url);

        return count($ids);
    }

    /**
     * Envoie l'e-mail de la notification aux destinataires qui ont une adresse — seulement
     * si `notifications.email_enabled`. Chaque envoi est isolé (un échec n'arrête ni les
     * autres e-mails ni la notification in-app).
     */
    protected function emailUsers(array $userIds, array $title, ?array $body, ?string $url): void
    {
        // Réglage PAR ÉCOLE (Setting) avec repli sur la config globale.
        if (empty($userIds) || ! Setting::getBool('notify_email', (bool) config('mt-school-core.notifications.email_enabled'))) {
            return;
        }

        $loc     = config('mt-school-core.multilingual.default', 'fr');
        $subject = (string) ($title[$loc] ?? reset($title) ?: '');
        $text    = $body ? (string) ($body[$loc] ?? reset($body) ?: '') : '';
        $brand   = function_exists('mt_brand_name')
            ? (string) (mt_brand_name() ?? config('mt-views.app_name', config('app.name', '')))
            : (string) config('app.name', '');

        $recipients = User::whereIn('id', $userIds)
            ->whereNotNull('email')->where('email', '!=', '')
            ->pluck('email');

        foreach ($recipients as $email) {
            try {
                Mail::to($email)->send(new SchoolNotificationMail($subject, $text, $url, $brand));
            } catch (\Throwable $e) {
                report($e); // ne casse jamais la notif in-app
            }
        }
    }

    /**
     * Notifie les destinataires d'une annonce publiée (par audience_type). Idempotent :
     * ne renotifie pas une annonce déjà notifiée.
     */
    public function notifyAnnouncement(Announcement $announcement): int
    {
        if ($announcement->status !== 'published') {
            return 0;
        }

        $already = SchoolNotification::where('notifiable_type', $announcement->getMorphClass())
            ->where('notifiable_id', $announcement->id)->exists();
        if ($already) {
            return 0;
        }

        $userIds = $this->recipientsFor($announcement);

        $title = json_decode((string) $announcement->getRawOriginal('title'), true)
            ?: [config('mt-school-core.multilingual.default', 'fr') => 'Annonce'];
        $body  = json_decode((string) $announcement->getRawOriginal('content'), true) ?: '';

        return $this->notify($userIds, $title, $body, 'announcement', null, $announcement);
    }

    // ── Sources métier (réutilisent notify()) ─────────────────────────────────

    /**
     * Notifie l'entourage d'un élève (son compte + ceux de ses tuteurs) que son
     * bulletin est publié. Idempotent par bulletin.
     */
    public function notifyReportCardPublished(ReportCard $rc): int
    {
        if (SchoolNotification::where('notifiable_type', $rc->getMorphClass())
            ->where('notifiable_id', $rc->id)->exists()) {
            return 0;
        }

        // enrollment via SchoolYearScope → null hors année active ; on neutralise le
        // scope année (SchoolScope tenant conservé) pour rester robuste toute année.
        $student = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->find($rc->enrollment_id)?->student;
        if (! $student) {
            return 0;
        }

        $loc = config('mt-school-core.multilingual.default', 'fr');

        return $this->notify(
            $this->usersForStudent($student),
            [$loc => __('mtschool::portal.notif_report_card_title')],
            [$loc => __('mtschool::portal.notif_report_card_body')],
            'report_card', null, $rc,
        );
    }

    /** Notifie les tuteurs d'un élève qu'une sanction a été émise. Idempotent par sanction. */
    public function notifySanction(DisciplinarySanction $sanction): int
    {
        if (SchoolNotification::where('notifiable_type', $sanction->getMorphClass())
            ->where('notifiable_id', $sanction->id)->exists()) {
            return 0;
        }

        $student = Enrollment::withoutGlobalScope(SchoolYearScope::class)
            ->find($sanction->enrollment_id)?->student;
        if (! $student) {
            return 0;
        }

        $loc  = config('mt-school-core.multilingual.default', 'fr');
        $type = is_array($sanction->label) ? ($sanction->label[$loc] ?? reset($sanction->label)) : (string) $sanction->label;

        return $this->notify(
            $this->guardianUsers($student),
            [$loc => __('mtschool::portal.notif_sanction_title')],
            [$loc => __('mtschool::portal.notif_sanction_body', ['type' => $type ?: '—'])],
            'sanction', null, $sanction,
        );
    }

    /**
     * Notifie les tuteurs d'un élève qu'un paiement a été encaissé (reçu).
     * PAS d'idempotence par sujet : chaque encaissement est un événement distinct.
     */
    public function notifyPayment(Enrollment $enrollment, float $amount, string $currency = ''): int
    {
        $student = $enrollment->student;
        if (! $student || $amount <= 0) {
            return 0;
        }

        $loc       = config('mt-school-core.multilingual.default', 'fr');
        $amountStr = number_format($amount, 0, ',', ' ') . ($currency ? ' ' . $currency : '');

        return $this->notify(
            $this->guardianUsers($student),
            [$loc => __('mtschool::portal.notif_payment_title')],
            [$loc => __('mtschool::portal.notif_payment_body', ['amount' => $amountStr])],
            'payment', null, $enrollment,
        );
    }

    /** Absence signalée → prévient les tuteurs (in-app + e-mail selon préférence école). */
    public function notifyAbsence(\Mt\MtSchoolCore\Models\Attendance $attendance): int
    {
        $enrollment = $attendance->enrollment;
        $student    = $enrollment?->student;
        if (! $student) {
            return 0;
        }

        $loc  = config('mt-school-core.multilingual.default', 'fr');
        $date = $attendance->date instanceof \DateTimeInterface
            ? $attendance->date->format('d/m/Y')
            : (string) $attendance->date;

        return $this->notify(
            $this->guardianUsers($student),
            [$loc => __('mtschool::portal.notif_absence_title')],
            [$loc => __('mtschool::portal.notif_absence_body', ['date' => $date])],
            'absence', null, $enrollment,
        );
    }

    /** Comptes de l'élève + de ses tuteurs (school-filtrés — anti-fuite tenant). */
    protected function usersForStudent(Student $student): Collection
    {
        $ids = collect();

        $own = $student->user; // MorphOne userable
        if ($own && (int) $own->school_id === (int) $student->school_id) {
            $ids->push($own->id);
        }

        return $ids->merge($this->guardianUsers($student))->filter()->unique()->values();
    }

    /** Comptes utilisateurs des tuteurs d'un élève (school-filtrés). */
    protected function guardianUsers(Student $student): Collection
    {
        $guardians = $student->guardians;
        if ($guardians->isEmpty()) {
            return collect();
        }

        return User::where('school_id', $student->school_id)
            ->where('userable_type', $guardians->first()->getMorphClass())
            ->whereIn('userable_id', $guardians->pluck('id'))
            ->where('is_active', true)
            ->pluck('id');
    }

    /** Ids des users d'une école ciblés par l'audience d'une annonce. */
    protected function recipientsFor(Announcement $announcement): Collection
    {
        $roles = match ($announcement->audience_type) {
            'parents'  => ['parent'],
            'students' => ['student'],
            'teachers' => ['teacher'],
            default    => ['parent', 'student', 'teacher'], // 'all'
        };

        // User NON school-scoped → filtrer school_id explicitement (anti-fuite tenant).
        return User::where('school_id', $announcement->school_id)
            ->whereIn('school_role', $roles)
            ->where('is_active', true)
            ->pluck('id');
    }
}
