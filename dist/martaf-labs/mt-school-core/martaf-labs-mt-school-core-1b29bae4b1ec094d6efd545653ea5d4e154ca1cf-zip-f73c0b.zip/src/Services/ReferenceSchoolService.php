<?php

namespace Mt\MtSchoolCore\Services;

/**
 * Generates unique references for each entity.
 * Format: PREFIX-YEAR-SEQUENCE (e.g. ENR-2024-00001)
 *
 * ⚠️ La séquence est ALÉATOIRE (pas incrémentale) : sans contrôle d'unicité,
 * random_int(1, 99999) finit mathématiquement par collisionner dès que la table
 * se remplit (contrainte unique school_id+reference → SQLSTATE 23000 en pleine
 * saisie). generate() vérifie donc l'existence dans la table cible (requête
 * school-scopée par le modèle) et retire au besoin.
 */
class ReferenceSchoolService
{
    /** Modèle porteur de la colonne `reference` pour chaque préfixe. */
    protected array $models = [
        'ENR' => \Mt\MtSchoolCore\Models\Enrollment::class,
        'RPT' => \Mt\MtSchoolCore\Models\ReportCard::class,
        'PAY' => \Mt\MtSchoolCore\Models\Payment::class,
        'FEE' => \Mt\MtSchoolCore\Models\SchoolFee::class,
        'CRT' => \Mt\MtSchoolCore\Models\SchoolCertificate::class,
        'STU' => \Mt\MtSchoolCore\Models\Student::class,
        'STF' => \Mt\MtSchoolCore\Models\StaffMember::class,
    ];

    public function enrollment(int $year): string   { return $this->generate('ENR', $year); }
    public function reportCard(int $year): string   { return $this->generate('RPT', $year); }
    public function payment(int $year): string      { return $this->generate('PAY', $year); }
    public function schoolFee(int $year): string    { return $this->generate('FEE', $year); }
    public function certificate(int $year): string  { return $this->generate('CRT', $year); }
    public function student(): string               { return $this->generate('STU', (int) date('Y')); }
    public function staff(): string                 { return $this->generate('STF', (int) date('Y')); }

    protected function generate(string $prefix, int $year): string
    {
        $model = $this->models[$prefix] ?? null;

        for ($try = 0; $try < 25; $try++) {
            $sequence  = str_pad(random_int(1, 99999), 5, '0', STR_PAD_LEFT);
            $reference = "{$prefix}-{$year}-{$sequence}";

            if (! $model || $this->referenceIsFree($model, $reference)) {
                return $reference;
            }
        }

        // Espace quasi saturé (ou malchance extrême) : suffixe élargi, unique en pratique.
        return "{$prefix}-{$year}-" . strtoupper(substr(uniqid('', true), -8));
    }

    /**
     * La référence est-elle libre dans la table cible ? Inclut les lignes
     * soft-deleted (la contrainte unique school_id+reference les voit toujours).
     */
    protected function referenceIsFree(string $model, string $reference): bool
    {
        $query = in_array(\Illuminate\Database\Eloquent\SoftDeletes::class, class_uses_recursive($model), true)
            ? $model::withTrashed()
            : $model::query();

        return $query->where('reference', $reference)->doesntExist();
    }
}
