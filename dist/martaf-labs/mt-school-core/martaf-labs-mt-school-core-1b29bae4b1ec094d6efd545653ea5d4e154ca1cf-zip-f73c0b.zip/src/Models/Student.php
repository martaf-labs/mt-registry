<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtMedia\Traits\HasMedia;

/**
 * @property int              $id
 * @property string           $reference
 * @property string           $last_name
 * @property string           $first_name
 * @property string|null      $gender     'M'|'F'
 * @property \Carbon\Carbon|null $birth_date
 * @property string|null      $photo
 * @property bool             $active
 */
class Student extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtSchoolCore\Traits\HasCustomFields;
    use HasMedia;

    protected $table = 'students';

    protected $fillable = [
        'reference', 'last_name', 'first_name', 'gender',
        'birth_date', 'birth_place', 'nationality', 'birth_certificate_number',
        'photo', 'email', 'phone', 'address',
        'blood_type', 'allergies', 'medical_notes',
        'previous_school', 'previous_class', 'previous_year',
        'native_language', 'has_user_account', 'active',
        'notes', 'metadata',
    ];

    protected $casts = [
        'birth_date'      => 'date',
        'has_user_account' => 'boolean',
        'active'          => 'boolean',
        'metadata'        => 'array',
    ];

    protected array $translatables = [
        'last_name', 'first_name', 'birth_place', 'nationality',
        'address', 'allergies', 'medical_notes', 'previous_school', 'notes',
    ];

    protected static array $searchableColumns = ['last_name', 'first_name', 'reference', 'email', 'phone'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)  { return $query->where('active', true); }
    public function scopeMale($query)    { return $query->where('gender', 'M'); }
    public function scopeFemale($query)  { return $query->where('gender', 'F'); }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    public function getFullNameReverseAttribute(): string
    {
        return trim("{$this->last_name} {$this->first_name}");
    }

    public function getAgeAttribute(): ?int
    {
        return $this->birth_date?->age;
    }

    public function getInitialsAttribute(): string
    {
        return mb_strtoupper(
            mb_substr($this->first_name ?? '', 0, 1) .
            mb_substr($this->last_name ?? '', 0, 1)
        );
    }

    public function getGenderLabelAttribute(): string
    {
        return match ($this->gender) {
            'M' => 'Male',
            'F' => 'Female',
            default => 'Not specified',
        };
    }

    public function fullName(): string { return $this->full_name; }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function enrollmentFor(?int $yearId = null): ?Enrollment
    {
        $yearId ??= SchoolYear::current()?->id;
        if (!$yearId) return null;
        return $this->enrollments()->where('school_year_id', $yearId)->first();
    }

    public function currentClassroom(): ?Classroom
    {
        return $this->enrollmentFor()?->classroom;
    }

    public function isEnrolledThisYear(): bool
    {
        return $this->enrollmentFor() !== null;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function enrollments(): HasMany
    {
        return $this->hasMany(Enrollment::class);
    }

    public function currentEnrollment(): HasOne
    {
        return $this->hasOne(Enrollment::class)
            ->whereHas('schoolYear', fn($q) => $q->where('is_active', true));
    }

    public function guardians(): BelongsToMany
    {
        return $this->belongsToMany(
            Guardian::class,
            'student_guardian',
            'student_id',
            'guardian_id'
        )->withPivot([
            'relationship',
            'is_primary_contact',
            'can_pickup',
            'portal_access',
        ])->withTimestamps();
    }

    public function primaryContact(): BelongsToMany
    {
        return $this->guardians()->wherePivot('is_primary_contact', true);
    }

    public function user(): MorphOne
    {
        return $this->morphOne(config('auth.providers.users.model'), 'userable');
    }
}
