<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * ConversationParticipant
 */
class ConversationParticipant extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'conversation_participants';

    protected $fillable = [
        'conversation_id', 'user_id', 'last_seen_at', 'is_admin', 'is_muted',
    ];

    protected $casts = [
        'last_seen_at' => 'datetime',
        'is_admin'     => 'boolean',
        'is_muted'     => 'boolean',
    ];

    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
}
