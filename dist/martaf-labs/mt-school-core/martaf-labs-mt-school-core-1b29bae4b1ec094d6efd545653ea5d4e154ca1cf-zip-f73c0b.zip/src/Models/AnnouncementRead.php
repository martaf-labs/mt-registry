<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * AnnouncementRead — tracks which users have read each announcement.
 */
class AnnouncementRead extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'announcement_reads';
    public $timestamps = false;

    protected $fillable = ['announcement_id', 'user_id', 'read_at'];
    protected $casts    = ['read_at' => 'datetime'];

    public function announcement(): BelongsTo { return $this->belongsTo(Announcement::class); }
}
