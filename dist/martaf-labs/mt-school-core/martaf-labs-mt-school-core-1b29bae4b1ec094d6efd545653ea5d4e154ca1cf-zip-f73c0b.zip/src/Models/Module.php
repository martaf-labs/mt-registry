<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Mt\MtFoundation\Traits\HasTranslatableCasts;

/**
 * Module activable du SaaS. Référentiel GLOBAL (plateforme) — pas de tenant.
 *
 * `is_core` = inclus dans tous les plans (gestion minimale d'une école).
 */
class Module extends Model
{
    use HasTranslatableCasts;

    protected $table = 'modules';

    protected array $translatables = ['name', 'description'];

    protected $fillable = ['code', 'name', 'description', 'group', 'is_core', 'order', 'active'];

    protected $casts = [
        'is_core' => 'boolean',
        'active'  => 'boolean',
        'order'   => 'integer',
    ];

    public function plans(): BelongsToMany
    {
        return $this->belongsToMany(Plan::class, 'plan_module');
    }

    public function scopeCore($q)   { return $q->where('is_core', true); }
    public function scopeActive($q) { return $q->where('active', true); }
}
