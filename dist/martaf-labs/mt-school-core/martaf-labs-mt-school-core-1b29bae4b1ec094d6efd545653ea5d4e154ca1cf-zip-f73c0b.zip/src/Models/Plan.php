<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Traits\HasTranslatableCasts;

/**
 * Plan tarifaire. Référentiel GLOBAL (plateforme) — pas de tenant.
 *
 * Les modules optionnels d'un plan sont en base (pivot `plan_module`, éditable).
 * Les modules `is_core` sont toujours inclus, en plus de ceux du plan.
 */
class Plan extends Model
{
    use HasTranslatableCasts;

    protected $table = 'plans';

    protected array $translatables = ['name', 'description'];

    protected $fillable = [
        'code', 'name', 'description', 'price', 'currency',
        'billing_period', 'max_students', 'is_public', 'active', 'order',
    ];

    protected $casts = [
        'price'        => 'decimal:2',
        'max_students' => 'integer',
        'is_public'    => 'boolean',
        'active'       => 'boolean',
        'order'        => 'integer',
    ];

    public function modules(): BelongsToMany
    {
        return $this->belongsToMany(Module::class, 'plan_module');
    }

    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    public function scopePublic($q) { return $q->where('is_public', true); }
    public function scopeActive($q) { return $q->where('active', true); }

    /** Codes des modules effectifs du plan : tous les `is_core` + ceux du plan. */
    public function moduleCodes(): array
    {
        $core = Module::core()->active()->pluck('code')->all();
        $own  = $this->modules()->where('active', true)->pluck('code')->all();

        return array_values(array_unique([...$core, ...$own]));
    }
}
