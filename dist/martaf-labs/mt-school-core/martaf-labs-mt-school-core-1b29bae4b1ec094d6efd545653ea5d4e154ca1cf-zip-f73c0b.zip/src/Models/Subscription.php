<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;

/**
 * Abonnement d'une école.
 *
 * Tenant via `school_id` + relation `school()`, mais SANS SchoolScope global :
 * c'est un concern billing/plateforme, accédé via `currentSchool()->...` ou
 * en contexte super-admin plateforme. `school_id` est nullable car l'achat
 * peut précéder la création de l'école (parcours : plan → paiement → compte → setup).
 */
class Subscription extends Model
{
    protected $table = 'subscriptions';

    protected $fillable = [
        'school_id', 'plan_id', 'status', 'starts_at', 'ends_at',
        'max_students', 'auto_renew', 'amount', 'currency',
        'payment_status', 'payment_gateway', 'payment_reference', 'paid_at', 'metadata',
    ];

    protected $casts = [
        'starts_at'    => 'date',
        'ends_at'      => 'date',
        'paid_at'      => 'datetime',
        'auto_renew'   => 'boolean',
        'amount'       => 'decimal:2',
        'max_students' => 'integer',
        'metadata'     => 'array',
    ];

    public function school(): BelongsTo { return $this->belongsTo(School::class); }
    public function plan(): BelongsTo   { return $this->belongsTo(Plan::class); }

    /** Abonnements valides (actifs et non expirés). */
    public function scopeActive(Builder $q): Builder
    {
        return $q->where('status', 'active')
            ->where(fn ($q) => $q->whereNull('ends_at')->orWhereDate('ends_at', '>=', Carbon::today()));
    }

    public function isActive(): bool
    {
        return $this->status === 'active'
            && (is_null($this->ends_at) || $this->ends_at->gte(Carbon::today()));
    }

    public function isPaid(): bool { return $this->payment_status === 'paid'; }

    /** Codes des modules ouverts par cet abonnement (core + plan). */
    public function moduleCodes(): array
    {
        return $this->plan?->moduleCodes() ?? [];
    }
}
