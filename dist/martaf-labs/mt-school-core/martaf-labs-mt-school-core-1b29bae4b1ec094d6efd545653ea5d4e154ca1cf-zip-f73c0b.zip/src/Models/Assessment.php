<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\AssessmentStatus;
use Mt\MtSchoolCore\Enums\AssessmentType;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * @property int              $id
 * @property int              $school_year_id
 * @property int              $period_id
 * @property int              $class_id
 * @property int              $subject_id
 * @property int|null         $teacher_id
 * @property array            $label
 * @property AssessmentType   $type
 * @property float            $max_score
 * @property float            $coefficient
 * @property float            $weight         % weight in the period
 * @property AssessmentStatus $status
 * @property bool             $published
 */
class Assessment extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'assessments';

    protected $fillable = [
        'school_year_id', 'period_id', 'class_id', 'subject_id', 'teacher_id',
        'label', 'code', 'type', 'max_score', 'coefficient', 'weight',
        'assessment_date', 'entry_deadline', 'status', 'published',
        'instructions', 'metadata',
    ];

    protected $casts = [
        'max_score'       => 'decimal:2',
        'coefficient'     => 'decimal:2',
        'weight'          => 'decimal:2',
        'assessment_date' => 'date',
        'entry_deadline'  => 'date',
        'published'       => 'boolean',
        'metadata'        => 'array',
        'label'           => 'array',
        'type'            => AssessmentType::class,
        'status'          => AssessmentStatus::class,
    ];

    protected array $translatables = ['label'];
    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePublished($query)                    { return $query->where('published', true); }
    public function scopeValidated($query)                    { return $query->where('status', AssessmentStatus::VALIDATED->value); }
    public function scopeForPeriod($query, int $periodId)     { return $query->where('period_id', $periodId); }
    public function scopeForClass($query, int $classId)       { return $query->where('class_id', $classId); }
    public function scopeForSubject($query, int $subjectId)   { return $query->where('subject_id', $subjectId); }
    public function scopeForYear($query, int $yearId)         { return $query->where('school_year_id', $yearId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isEntered(): bool   { return $this->status?->isEntered() ?? false; }
    public function isValidated(): bool { return $this->status === AssessmentStatus::VALIDATED; }
    public function isPublished(): bool { return $this->published; }

    public function classAverage(): ?float
    {
        $avg = $this->grades()
            ->whereNotNull('final_score')
            ->where('is_absent', false)
            ->avg('final_score');

        if ($avg === null) return null;

        return $this->max_score != 20
            ? round(($avg * 20) / $this->max_score, 2)
            : round($avg, 2);
    }

    public function maxScore(): ?float
    {
        return $this->grades()->whereNotNull('final_score')->where('is_absent', false)->max('final_score');
    }

    public function minScore(): ?float
    {
        return $this->grades()->whereNotNull('final_score')->where('is_absent', false)->min('final_score');
    }

    public function enteredGradesCount(): int
    {
        return $this->grades()->whereNotNull('final_score')->count();
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
    public function period(): BelongsTo     { return $this->belongsTo(Period::class); }
    public function classroom(): BelongsTo  { return $this->belongsTo(Classroom::class, 'class_id'); }
    public function subject(): BelongsTo    { return $this->belongsTo(Subject::class); }
    public function teacher(): BelongsTo    { return $this->belongsTo(Teacher::class); }

    public function grades(): HasMany
    {
        return $this->hasMany(Grade::class);
    }
}
