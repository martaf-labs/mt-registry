<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * Message — a message in an internal conversation.
 */
class Message extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'messages';

    protected $fillable = [
        'conversation_id', 'sender_id', 'parent_id',
        'content', 'content_type', 'attachments', 'status',
    ];

    protected $casts = [
        'attachments' => 'array',
    ];

    public function scopeVisible($query)  { return $query->where('status', '!=', 'deleted'); }

    public function isRead(): bool   { return $this->status === 'read'; }
    public function isSent(): bool   { return $this->status === 'sent'; }

    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
    public function replyTo(): BelongsTo      { return $this->belongsTo(Message::class, 'parent_id'); }
    public function replies(): HasMany        { return $this->hasMany(Message::class, 'parent_id'); }
}
