<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

class HolidayPeriod extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'holiday_periods';

    protected $fillable = [
        'school_year_id', 'label', 'type',
        'start_date', 'end_date', 'scope',
        'classes_suspended', 'absences_neutralized',
        'color', 'active', 'description',
    ];

    protected $casts = [
        'start_date'           => 'date',
        'end_date'             => 'date',
        'classes_suspended'    => 'boolean',
        'absences_neutralized' => 'boolean',
        'active'               => 'boolean',
        'label'                => 'array',
    ];

    protected array $translatables = ['label', 'description'];

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
}
