<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\SubjectGroup;

class Subject extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'subjects';

    protected $fillable = [
        'label', 'code', 'abbreviation', 'group',
        'color', 'icon', 'active', 'is_core', 'description',
    ];

    protected $casts = [
        'active'  => 'boolean',
        'is_core' => 'boolean',
        'label'   => 'array',
        'group'   => SubjectGroup::class,
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code', 'abbreviation'];

    public function scopeActive($query)   { return $query->where('active', true); }
    public function scopeCore($query)     { return $query->where('is_core', true); }

    public function teachers(): BelongsToMany
    {
        return $this->belongsToMany(Teacher::class, 'teacher_subject');
    }

    public function curricula(): BelongsToMany
    {
        return $this->belongsToMany(Curriculum::class, 'curriculum_subject')
            ->withPivot(['coefficient', 'weekly_hours', 'order', 'is_eliminating', 'on_report_card']);
    }

    public function assessments(): HasMany    { return $this->hasMany(Assessment::class); }
    public function courseAssignments(): HasMany { return $this->hasMany(CourseAssignment::class); }
}
