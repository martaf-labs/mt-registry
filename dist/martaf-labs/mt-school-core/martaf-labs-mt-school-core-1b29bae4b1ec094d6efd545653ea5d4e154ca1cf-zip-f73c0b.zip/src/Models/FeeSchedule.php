<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * FeeSchedule — amount per fee type per year per grade level / specialization.
 */
class FeeSchedule extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'fee_schedules';

    protected array $translatables = ['description'];

    protected $fillable = [
        'school_year_id', 'fee_type_id', 'grade_level_id', 'specialization_id',
        'amount', 'currency', 'active', 'description',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'active' => 'boolean',
    ];

    public function scopeActive($query)          { return $query->where('active', true); }
    public function scopeForYear($query, int $id) { return $query->where('school_year_id', $id); }

    public function schoolYear(): BelongsTo    { return $this->belongsTo(SchoolYear::class); }
    public function feeType(): BelongsTo       { return $this->belongsTo(FeeType::class); }
    public function gradeLevel(): BelongsTo    { return $this->belongsTo(GradeLevel::class); }
    public function specialization(): BelongsTo{ return $this->belongsTo(Specialization::class); }
}
