<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

class Building extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'buildings';

    protected $fillable = ['label', 'code', 'description', 'active'];

    protected $casts = [
        'active' => 'boolean',
        'label'  => 'array',
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code'];

    public function scopeActive($query) { return $query->where('active', true); }

    public function rooms(): HasMany
    {
        return $this->hasMany(Room::class);
    }
}
