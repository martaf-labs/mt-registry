<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * CalendarEvent — shared institution agenda.
 */
class CalendarEvent extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'calendar_events';

    protected $fillable = [
        'title', 'description', 'type', 'school_year_id',
        'audience_type', 'audience_ids',
        'starts_at', 'ends_at', 'all_day', 'recurring', 'recurrence_config',
        'location', 'room_id', 'color', 'icon', 'published', 'notification_sent', 'metadata',
    ];

    protected $casts = [
        'starts_at'         => 'datetime',
        'ends_at'           => 'datetime',
        'all_day'           => 'boolean',
        'recurring'         => 'boolean',
        'recurrence_config' => 'array',
        'audience_ids'      => 'array',
        'published'         => 'boolean',
        'notification_sent' => 'boolean',
        'metadata'          => 'array',
        'title'             => 'array',
        'description'       => 'array',
    ];

    protected array $translatables = ['title', 'description', 'location'];

    public function scopePublished($query)          { return $query->where('published', true); }
    public function scopeUpcoming($query)           { return $query->where('starts_at', '>=', now()); }
    public function scopeOfType($query, string $t)  { return $query->where('type', $t); }

    public function isPast(): bool { return $this->starts_at->isPast(); }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
    public function room(): BelongsTo       { return $this->belongsTo(Room::class); }
}
