<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * @property int         $id
 * @property int         $school_year_id
 * @property int         $grade_level_id
 * @property int|null    $specialization_id
 * @property int|null    $room_id
 * @property int|null    $homeroom_teacher_id
 * @property array       $label
 * @property string      $code
 * @property string|null $abbreviation
 * @property int         $max_capacity
 * @property int         $current_enrollment
 * @property bool        $active
 */
class Classroom extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'classes';

    protected $fillable = [
        'school_year_id', 'grade_level_id', 'specialization_id', 'room_id',
        'homeroom_teacher_id', 'label', 'code', 'abbreviation',
        'max_capacity', 'current_enrollment', 'teaching_language',
        'active', 'notes', 'metadata',
    ];

    protected $casts = [
        'active'             => 'boolean',
        'max_capacity'       => 'integer',
        'current_enrollment' => 'integer',
        'metadata'           => 'array',
        'label'              => 'array',
    ];

    protected array $translatables = ['label', 'notes'];
    protected static array $searchableColumns = ['code', 'abbreviation'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)                        { return $query->where('active', true); }
    public function scopeForYear($query, int $yearId)          { return $query->where('school_year_id', $yearId); }
    public function scopeForGradeLevel($query, int $levelId)   { return $query->where('grade_level_id', $levelId); }
    public function scopeForSpecialization($query, int $specId){ return $query->where('specialization_id', $specId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isFull(): bool
    {
        return $this->current_enrollment >= $this->max_capacity;
    }

    public function availableSpots(): int
    {
        return max(0, $this->max_capacity - $this->current_enrollment);
    }

    public function fillRate(): float
    {
        if ($this->max_capacity === 0) return 0;
        return round(($this->current_enrollment / $this->max_capacity) * 100, 1);
    }

    public function recalculateEnrollment(): self
    {
        $this->current_enrollment = $this->enrollments()
            ->where('status', 'validated')
            ->count();
        $this->saveQuietly();
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function schoolYear(): BelongsTo
    {
        return $this->belongsTo(SchoolYear::class);
    }

    public function gradeLevel(): BelongsTo
    {
        return $this->belongsTo(GradeLevel::class);
    }

    public function specialization(): BelongsTo
    {
        return $this->belongsTo(Specialization::class);
    }

    public function room(): BelongsTo
    {
        return $this->belongsTo(Room::class);
    }

    public function enrollments(): HasMany
    {
        return $this->hasMany(Enrollment::class, 'class_id');
    }

    public function validatedEnrollments(): HasMany
    {
        return $this->hasMany(Enrollment::class, 'class_id')->where('status', 'validated');
    }

    public function assessments(): HasMany
    {
        return $this->hasMany(Assessment::class, 'class_id');
    }

    public function courseAssignments(): HasMany
    {
        return $this->hasMany(CourseAssignment::class, 'class_id');
    }

    public function timetables(): HasMany
    {
        return $this->hasMany(Timetable::class, 'class_id');
    }

    public function studyGroups(): HasMany
    {
        return $this->hasMany(StudyGroup::class, 'class_id');
    }

    public function classCouncils(): HasMany
    {
        return $this->hasMany(ClassCouncil::class, 'class_id');
    }

    public function homeworks(): HasMany
    {
        return $this->hasMany(Homework::class, 'class_id');
    }

    public function teachingResources(): HasMany
    {
        return $this->hasMany(TeachingResource::class, 'class_id');
    }
}
