<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

class Room extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'rooms';

    protected $fillable = [
        'building_id', 'label', 'code', 'type',
        'capacity', 'active', 'description', 'equipment',
    ];

    protected $casts = [
        'active'    => 'boolean',
        'capacity'  => 'integer',
        'equipment' => 'array',
        'label'     => 'array',
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code'];

    public function scopeActive($query) { return $query->where('active', true); }

    public function building(): BelongsTo  { return $this->belongsTo(Building::class); }
    public function classes(): HasMany     { return $this->hasMany(Classroom::class); }
    public function timeSlots(): HasMany   { return $this->hasMany(TimeSlot::class); }
}
