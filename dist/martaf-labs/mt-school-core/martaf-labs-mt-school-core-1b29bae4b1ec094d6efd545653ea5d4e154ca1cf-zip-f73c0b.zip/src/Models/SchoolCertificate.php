<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * SchoolCertificate — official document issued to a student by the institution.
 */
class SchoolCertificate extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'school_certificates';

    protected $fillable = [
        'reference', 'enrollment_id', 'type', 'title', 'reason', 'reason_details',
        'recipient', 'language', 'pdf_file', 'signature_hash', 'qr_code',
        'status', 'requested_by', 'requested_at', 'issued_by', 'issued_at',
        'copies_count', 'valid_until', 'notes', 'metadata',
    ];

    protected $casts = [
        'title'        => 'array',
        'requested_at' => 'datetime',
        'issued_at'    => 'datetime',
        'valid_until'  => 'date',
        'copies_count' => 'integer',
        'metadata'     => 'array',
    ];

    protected array $translatables = ['title', 'reason_details', 'recipient', 'notes'];

    public function scopeIssued($query)    { return $query->where('status', 'issued'); }
    public function scopePending($query)   { return $query->whereIn('status', ['requested', 'processing']); }

    public function isIssued(): bool { return $this->status === 'issued'; }
    public function isValid(): bool  { return !$this->valid_until || $this->valid_until->isFuture(); }

    public function issue(int $userId): self
    {
        $this->update([
            'status'    => 'issued',
            'issued_by' => $userId,
            'issued_at' => now(),
        ]);
        return $this;
    }

    public function enrollment(): BelongsTo { return $this->belongsTo(Enrollment::class); }
}
