<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * Announcement
 * Broadcast message to a group (all, a class, parents, etc.)
 *
 * PAS de BelongsToSchoolYear : une annonce est de la COMMUNICATION. Le SchoolYearScope
 * la faisait disparaître de l'index et du portail parent à chaque bascule d'année (et
 * bloquait sa ré-édition en 404). school_year_id reste en base (nullable) en métadonnée.
 */
class Announcement extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;

    protected $table = 'announcements';

    protected $fillable = [
        'title', 'content', 'author_id', 'audience_type', 'audience_ids',
        'school_year_id', 'status', 'importance',
        'published_at', 'expires_at', 'email_notification', 'sms_notification',
        'views_count', 'attachments', 'metadata',
    ];

    protected $casts = [
        'audience_ids'      => 'array',
        'published_at'      => 'datetime',
        'expires_at'        => 'datetime',
        'email_notification' => 'boolean',
        'sms_notification'  => 'boolean',
        'attachments'       => 'array',
        'metadata'          => 'array',
        'title'             => 'array',
        'content'           => 'array',
    ];

    protected array $translatables = ['title', 'content'];

    public function scopePublished($query)   { return $query->where('status', 'published'); }
    public function scopeUrgent($query)      { return $query->where('importance', 'urgent'); }
    public function scopeNotExpired($query)  { return $query->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now())); }

    public function scopeForAudience($query, string $type)
    {
        return $query->where(fn($q) => $q->where('audience_type', 'all')->orWhere('audience_type', $type));
    }

    public function isPublished(): bool { return $this->status === 'published'; }
    public function isExpired(): bool   { return $this->expires_at && $this->expires_at->isPast(); }
    public function isUrgent(): bool    { return $this->importance === 'urgent'; }
    public function incrementViews(): void { $this->increment('views_count'); }

    public function schoolYear(): BelongsTo   { return $this->belongsTo(SchoolYear::class); }
    public function reads(): HasMany          { return $this->hasMany(AnnouncementRead::class); }
}
