<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

class StudyGroup extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'study_groups';

    protected $fillable = [
        'class_id', 'subject_id', 'label', 'code',
        'type', 'max_capacity', 'current_size', 'active', 'notes',
    ];

    protected $casts = [
        'active'       => 'boolean',
        'max_capacity' => 'integer',
        'current_size' => 'integer',
        'label'        => 'array',
    ];

    protected array $translatables = ['label', 'notes'];

    public function scopeActive($query) { return $query->where('active', true); }

    public function classroom(): BelongsTo { return $this->belongsTo(Classroom::class, 'class_id'); }
    public function subject(): BelongsTo   { return $this->belongsTo(Subject::class); }

    public function enrollments(): BelongsToMany
    {
        return $this->belongsToMany(Enrollment::class, 'study_group_enrollment');
    }

    public function timeSlots(): HasMany { return $this->hasMany(TimeSlot::class); }
}
