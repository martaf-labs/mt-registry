<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\HasOne;
use Mt\MtAuth\Models\BaseUser;
use Mt\MtSchoolCore\Enums\RoleSchool;

/**
 * School User model — ready to use in any app that installs mt-school-core.
 *
 * Configure in the host app:
 *   config/auth.php       → providers.users.model = Mt\MtSchoolCore\Models\User::class
 *   config/mt-auth.php    → developpeur_model     = Mt\MtSchoolCore\Models\Developpeur::class
 *
 * @property int|null    $school_id
 * @property RoleSchool  $school_role
 * @property bool        $is_active
 * @property string|null $avatar
 * @property string|null $phone
 * @property string|null $locale
 */
class User extends BaseUser
{
    // HasSchoolScope intentionnellement absent : ce scope filtre par school_id
    // mais Auth::retrieveByCredentials() s'exécute avant toute session —
    // appliquer le scope ici provoquerait une récursion (Spatie charge User)
    // et bloquerait la connexion.

    protected $fillable = [
        'userable_type', 'userable_id',
        'name', 'email', 'password', 'role', 'last_seen',
        'school_id', 'school_role', 'is_active', 'avatar', 'phone', 'locale',
    ];

    protected $hidden = [
        'password', 'remember_token',
        'two_factor_secret', 'two_factor_recovery_codes',
    ];

    protected function casts(): array
    {
        return [
            ...parent::casts(),
            'is_active'   => 'boolean',
            'school_role' => RoleSchool::class,
        ];
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function studentProfile(): HasOne
    {
        return $this->hasOne(Student::class, 'user_id');
    }

    public function teacherProfile(): HasOne
    {
        return $this->hasOne(Teacher::class, 'user_id');
    }

    public function staffProfile(): HasOne
    {
        return $this->hasOne(StaffMember::class, 'user_id');
    }

    public function guardianProfile(): HasOne
    {
        return $this->hasOne(Guardian::class, 'user_id');
    }

    // ── Role helpers ──────────────────────────────────────────────────────────

    public function isPrincipal(): bool     { return $this->school_role === RoleSchool::PRINCIPAL; }
    public function isVicePrincipal(): bool { return $this->school_role === RoleSchool::VICE_PRINCIPAL; }
    public function isTeacher(): bool       { return $this->school_role === RoleSchool::TEACHER; }
    public function isStudent(): bool       { return $this->school_role === RoleSchool::STUDENT; }
    public function isParent(): bool        { return $this->school_role === RoleSchool::PARENT; }
    public function isAccountant(): bool    { return $this->school_role === RoleSchool::ACCOUNTANT; }
    public function isStaff(): bool         { return $this->school_role === RoleSchool::STAFF; }
    public function isSuperAdmin(): bool    { return $this->school_role === RoleSchool::SUPER_ADMIN; }

    // ── Permissions (RBAC) ────────────────────────────────────────────────────

    /**
     * L'utilisateur possède-t-il l'ability donnée ?
     * Résolu par le rôle scolaire (cf. RoleSchool::permissions()).
     * Le Gate::before du package fait pointer $user->can('school.*') ici.
     */
    public function hasPermission(string $ability): bool
    {
        return $this->school_role instanceof RoleSchool
            && $this->school_role->allows($ability);
    }

    // ── Display helpers ───────────────────────────────────────────────────────

    public function displayName(): string
    {
        return $this->name ?: str($this->email)->before('@')->toString();
    }

    public function avatarUrl(): string
    {
        if ($this->avatar) {
            return asset('storage/' . $this->avatar);
        }

        return 'https://ui-avatars.com/api/?name=' . urlencode($this->initials())
            . '&background=random&color=fff&bold=true';
    }

    public function schoolProfile(): Student|Teacher|StaffMember|Guardian|null
    {
        return match ($this->school_role) {
            RoleSchool::STUDENT => $this->studentProfile,
            RoleSchool::TEACHER => $this->teacherProfile,
            RoleSchool::PARENT  => $this->guardianProfile,
            default             => $this->staffProfile,
        };
    }
}
