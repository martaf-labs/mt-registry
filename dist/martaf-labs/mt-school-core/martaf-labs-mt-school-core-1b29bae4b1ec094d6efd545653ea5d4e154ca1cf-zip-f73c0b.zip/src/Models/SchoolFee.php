<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\FeeStatus;

/**
 * SchoolFee — what a student owes for a given enrollment and fee type.
 */
class SchoolFee extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'school_fees';

    protected array $translatables = ['exemption_reason', 'notes'];

    protected $fillable = [
        'reference', 'enrollment_id', 'fee_type_id',
        'gross_amount', 'discount', 'net_amount',
        'amount_paid', 'remaining_amount', 'currency',
        'status', 'is_exempt', 'exemption_reason', 'notes', 'metadata',
    ];

    protected $casts = [
        'gross_amount'     => 'decimal:2',
        'discount'         => 'decimal:2',
        'net_amount'       => 'decimal:2',
        'amount_paid'      => 'decimal:2',
        'remaining_amount' => 'decimal:2',
        'is_exempt'        => 'boolean',
        'metadata'         => 'array',
        'status'           => FeeStatus::class,
    ];

    public function scopePending($query)  { return $query->where('status', FeeStatus::PENDING->value); }
    public function scopePaid($query)     { return $query->where('status', FeeStatus::PAID->value); }

    public function isPaid(): bool    { return $this->status === FeeStatus::PAID; }
    public function isPending(): bool { return $this->status?->isActive() ?? false; }

    public function enrollment(): BelongsTo    { return $this->belongsTo(Enrollment::class); }
    public function feeType(): BelongsTo       { return $this->belongsTo(FeeType::class); }
    public function installments(): HasMany    { return $this->hasMany(PaymentInstallment::class, 'school_fee_id'); }
    public function payments(): HasMany        { return $this->hasMany(Payment::class, 'school_fee_id'); }
}
