<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Traits\TracksUser;
use Mt\MtSchoolCore\Enums\AttendanceStatus;

/**
 * @property int              $id
 * @property int              $enrollment_id
 * @property int|null         $time_slot_id
 * @property \Carbon\Carbon   $date
 * @property string           $mode        'time_slot'|'half_day'|'full_day'
 * @property AttendanceStatus $status
 * @property int              $lateness_minutes
 * @property bool             $is_justified
 */
class Attendance extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    use TracksUser;

    protected array $translatables = ['notes'];

    protected $table = 'attendances';

    protected $fillable = [
        'enrollment_id', 'time_slot_id', 'subject_id', 'teacher_id',
        'date', 'mode', 'day_period', 'status', 'lateness_minutes',
        'justification_id', 'is_justified', 'recorded_by', 'notes',
    ];

    protected $casts = [
        'date'          => 'date',
        'is_justified'  => 'boolean',
        'status'        => AttendanceStatus::class,
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePresent($query)    { return $query->where('status', AttendanceStatus::PRESENT->value); }
    public function scopeAbsent($query)     { return $query->where('status', AttendanceStatus::ABSENT->value); }
    public function scopeLate($query)       { return $query->where('status', AttendanceStatus::LATE->value); }
    public function scopeJustified($query)  { return $query->where('is_justified', true); }
    public function scopeUnjustified($query){ return $query->where('is_justified', false)->where('status', AttendanceStatus::ABSENT->value); }

    public function scopeForDate($query, $date)           { return $query->where('date', $date); }
    public function scopeForDateRange($query, $from, $to) { return $query->whereBetween('date', [$from, $to]); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isPresent(): bool   { return $this->status === AttendanceStatus::PRESENT; }
    public function isAbsent(): bool    { return $this->status === AttendanceStatus::ABSENT; }
    public function isLate(): bool      { return $this->status === AttendanceStatus::LATE; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function enrollment(): BelongsTo      { return $this->belongsTo(Enrollment::class); }
    public function timeSlot(): BelongsTo        { return $this->belongsTo(TimeSlot::class); }
    public function subject(): BelongsTo         { return $this->belongsTo(Subject::class); }
    public function teacher(): BelongsTo         { return $this->belongsTo(Teacher::class); }
    public function justification(): BelongsTo   { return $this->belongsTo(AbsenceJustification::class, 'justification_id'); }
}
