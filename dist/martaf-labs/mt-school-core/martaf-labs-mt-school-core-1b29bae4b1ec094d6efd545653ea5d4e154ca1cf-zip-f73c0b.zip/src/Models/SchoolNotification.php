<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * SchoolNotification — in-app notification for a user.
 */
class SchoolNotification extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts; // title/body traduisibles → aplatis à la locale

    protected $table = 'school_notifications';

    protected $fillable = [
        'user_id', 'title', 'body', 'type', 'category',
        'notifiable_type', 'notifiable_id', 'url', 'is_read', 'read_at',
    ];

    protected $casts = [
        'title'   => 'array',
        'body'    => 'array',
        'is_read' => 'boolean',
        'read_at' => 'datetime',
    ];

    protected array $translatables = ['title', 'body'];

    public function scopeUnread($query)           { return $query->where('is_read', false); }
    public function scopeOfType($query, string $t){ return $query->where('type', $t); }

    public function markAsRead(): self
    {
        $this->update(['is_read' => true, 'read_at' => now()]);
        return $this;
    }

    public function isRead(): bool { return $this->is_read; }
}
