<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

class CourseAssignment extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'course_assignments';

    protected array $translatables = ['notes'];

    protected $fillable = [
        'school_year_id', 'teacher_id', 'class_id', 'subject_id',
        'weekly_hours', 'coefficient', 'active',
        'start_date', 'end_date', 'notes',
    ];

    protected $casts = [
        'weekly_hours' => 'decimal:2',
        'coefficient'  => 'decimal:2',
        'active'       => 'boolean',
        'start_date'   => 'date',
        'end_date'     => 'date',
    ];

    public function scopeActive($query)          { return $query->where('active', true); }
    public function scopeForYear($query, int $id) { return $query->where('school_year_id', $id); }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
    public function teacher(): BelongsTo    { return $this->belongsTo(Teacher::class); }
    public function classroom(): BelongsTo  { return $this->belongsTo(Classroom::class, 'class_id'); }
    public function subject(): BelongsTo    { return $this->belongsTo(Subject::class); }
    public function timeSlots(): HasMany    { return $this->hasMany(TimeSlot::class); }
}
