<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * Conversation — internal messaging thread between users.
 *
 * PAS de BelongsToSchoolYear : une conversation est de la COMMUNICATION, pas une
 * donnée académique annuelle. Sinon le SchoolYearScope la rend invisible dès la
 * bascule d'année et son propre auteur ne peut plus la rouvrir (403). school_year_id
 * reste en base (nullable) comme métadonnée facultative.
 */
class Conversation extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;

    protected $table = 'conversations';

    protected $fillable = [
        'subject', 'type', 'school_year_id', 'last_message_at', 'messages_count',
    ];

    protected $casts = [
        'subject'         => 'array',
        'last_message_at' => 'datetime',
        'messages_count'  => 'integer',
    ];

    protected array $translatables = ['subject'];

    public function scopePrivate($query) { return $query->where('type', 'private'); }
    public function scopeGroup($query)   { return $query->where('type', 'group'); }

    public function schoolYear(): BelongsTo  { return $this->belongsTo(SchoolYear::class); }
    public function participants(): HasMany  { return $this->hasMany(ConversationParticipant::class); }
    public function messages(): HasMany      { return $this->hasMany(Message::class)->orderBy('created_at'); }
    public function latestMessage(): HasMany { return $this->hasMany(Message::class)->latest()->limit(1); }
}
