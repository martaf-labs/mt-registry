<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * CouncilParticipant — participant in a class council with role and signature.
 */
class CouncilParticipant extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'council_participants';

    protected $fillable = [
        'class_council_id', 'user_id', 'council_role', 'present', 'has_signed',
    ];

    protected $casts = [
        'present'    => 'boolean',
        'has_signed' => 'boolean',
    ];

    public function classCouncil(): BelongsTo
    {
        return $this->belongsTo(ClassCouncil::class, 'class_council_id');
    }
}
