<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Journal d'audit d'un import / provisioning : type, fichier, compteurs, auteur, date.
 * Cloisonné par école (BelongsToSchool remplit school_id à la création).
 */
class ImportLog extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;

    protected $table = 'import_logs';

    protected $fillable = [
        'user_id', 'type', 'filename', 'total', 'imported', 'skipped', 'details',
    ];

    protected $casts = [
        'total'    => 'integer',
        'imported' => 'integer',
        'skipped'  => 'integer',
        'details'  => 'array',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(config('auth.providers.users.model'), 'user_id');
    }
}
