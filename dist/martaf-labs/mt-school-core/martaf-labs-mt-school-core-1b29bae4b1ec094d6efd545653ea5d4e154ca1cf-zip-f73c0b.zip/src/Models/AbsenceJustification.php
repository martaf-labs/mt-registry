<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Traits\TracksUser;

class AbsenceJustification extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    use TracksUser;

    protected $table = 'absence_justifications';

    protected array $translatables = ['reason_details', 'rejection_reason'];

    protected $fillable = [
        'enrollment_id', 'start_date', 'end_date',
        'reason', 'reason_details', 'document', 'status',
        'processed_by', 'processed_at', 'rejection_reason',
        'submitter_type', 'submitter_id',
    ];

    protected $casts = [
        'start_date'   => 'date',
        'end_date'     => 'date',
        'processed_at' => 'datetime',
    ];

    public function enrollment(): BelongsTo  { return $this->belongsTo(Enrollment::class); }
    public function attendances(): HasMany   { return $this->hasMany(Attendance::class, 'justification_id'); }
}
