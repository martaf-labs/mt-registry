<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\CycleType;

/**
 * @property int      $id
 * @property array    $label
 * @property string   $code   'PRESCHOOL'|'PRIMARY'|'MIDDLE'|'HIGH'|'HIGHER'
 * @property CycleType $type
 * @property int      $order
 * @property string   $color
 * @property bool     $active
 */
class Cycle extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'cycles';

    protected $fillable = [
        'label', 'code', 'type', 'order', 'color', 'icon', 'description', 'active',
    ];

    protected $casts = [
        'active' => 'boolean',
        'label'  => 'array',
        'type'   => CycleType::class,
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)             { return $query->where('active', true); }
    public function scopeOfType($query, CycleType $type) { return $query->where('type', $type->value); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isPreschool(): bool       { return $this->type === CycleType::PRESCHOOL; }
    public function isPrimary(): bool         { return $this->type === CycleType::PRIMARY; }
    public function isSecondary(): bool       { return $this->type === CycleType::SECONDARY; }
    public function isHigher(): bool          { return $this->type === CycleType::HIGHER; }
    public function isLmd(): bool             { return $this->type?->isLmd() ?? false; }
    public function hasSpecializations(): bool { return $this->type?->hasSpecializations() ?? false; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function gradeLevels(): HasMany
    {
        return $this->hasMany(GradeLevel::class)->orderBy('order');
    }

    public function activeGradeLevels(): HasMany
    {
        return $this->hasMany(GradeLevel::class)->where('active', true)->orderBy('order');
    }
}
