<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * Valeur d'un champ personnalisé pour une entité donnée. TENANT (school_id).
 * Une seule valeur par (custom_field_id, entity_id).
 *
 * @property int    $id
 * @property int    $school_id
 * @property int    $custom_field_id
 * @property string $entity_type
 * @property int    $entity_id
 * @property string|null $value      brut (scalaire ou JSON) — utiliser ->typedValue
 */
class CustomFieldValue extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;

    protected $table = 'custom_field_values';

    protected $fillable = [
        'custom_field_id', 'entity_type', 'entity_id', 'value',
    ];

    public function field(): BelongsTo
    {
        return $this->belongsTo(CustomField::class, 'custom_field_id');
    }

    /** Valeur typée selon le type du champ (cast via l'enum). */
    public function getTypedValueAttribute(): mixed
    {
        return $this->field?->type->cast($this->value);
    }
}
