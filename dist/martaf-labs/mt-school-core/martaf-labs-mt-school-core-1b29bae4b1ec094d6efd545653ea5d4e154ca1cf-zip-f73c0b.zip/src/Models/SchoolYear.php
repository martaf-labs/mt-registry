<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * @property int         $id
 * @property array       $label
 * @property string      $code        e.g. '2024-2025'
 * @property \Carbon\Carbon $start_date
 * @property \Carbon\Carbon $end_date
 * @property bool        $is_active
 * @property bool        $is_closed
 * @property array|null  $metadata
 */
class SchoolYear extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'school_years';

    protected $fillable = [
        'label', 'code', 'start_date', 'end_date',
        'is_active', 'is_closed', 'description', 'metadata',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date'   => 'date',
        'is_active'  => 'boolean',
        'is_closed'  => 'boolean',
        'metadata'   => 'array',
        'label'      => 'array',
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)    { return $query->where('is_active', true); }
    public function scopeOpen($query)      { return $query->where('is_closed', false); }
    public function scopeClosed($query)    { return $query->where('is_closed', true); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public static function current(): ?self
    {
        return static::where('is_active', true)->first();
    }

    public function activate(): self
    {
        static::query()->update(['is_active' => false]);
        $this->update(['is_active' => true]);
        return $this;
    }

    public function close(): self
    {
        $this->update(['is_closed' => true, 'is_active' => false]);
        return $this;
    }

    public function isActive(): bool  { return $this->is_active; }
    public function isClosed(): bool  { return $this->is_closed; }
    public function isOpen(): bool    { return !$this->is_closed; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function periods(): HasMany
    {
        return $this->hasMany(Period::class)->orderBy('order');
    }

    public function mainPeriods(): HasMany
    {
        return $this->hasMany(Period::class)->whereNull('parent_id')->orderBy('order');
    }

    public function classes(): HasMany           { return $this->hasMany(Classroom::class); }
    public function enrollments(): HasMany       { return $this->hasMany(Enrollment::class); }
    public function curricula(): HasMany         { return $this->hasMany(Curriculum::class); }
    public function assessments(): HasMany       { return $this->hasMany(Assessment::class); }
    public function timetables(): HasMany        { return $this->hasMany(Timetable::class); }
    public function courseAssignments(): HasMany { return $this->hasMany(CourseAssignment::class); }
    public function feeSchedules(): HasMany      { return $this->hasMany(FeeSchedule::class); }
    public function announcements(): HasMany     { return $this->hasMany(Announcement::class); }
    public function calendarEvents(): HasMany    { return $this->hasMany(CalendarEvent::class); }
    public function holidayPeriods(): HasMany    { return $this->hasMany(HolidayPeriod::class); }
    public function settings(): HasMany          { return $this->hasMany(SchoolSetting::class); }
    public function classCouncils(): HasMany     { return $this->hasMany(ClassCouncil::class); }
}
