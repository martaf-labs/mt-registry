<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * HomeworkSubmission — a student's submission for a homework assignment.
 */
class HomeworkSubmission extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    protected $table = 'homework_submissions';

    protected array $translatables = ['comment', 'correction'];

    protected $fillable = [
        'homework_id', 'enrollment_id', 'file', 'comment',
        'submitted_at', 'is_late', 'score', 'correction', 'correction_file', 'corrected_at', 'status',
    ];

    protected $casts = [
        'submitted_at'  => 'datetime',
        'corrected_at'  => 'datetime',
        'is_late'       => 'boolean',
        'score'         => 'decimal:2',
    ];

    public function scopeCorrected($query)  { return $query->where('status', 'corrected'); }
    public function scopeLate($query)       { return $query->where('is_late', true); }

    public function isCorrected(): bool { return $this->status === 'corrected'; }

    public function homework(): BelongsTo  { return $this->belongsTo(Homework::class); }
    public function enrollment(): BelongsTo{ return $this->belongsTo(Enrollment::class); }
}
