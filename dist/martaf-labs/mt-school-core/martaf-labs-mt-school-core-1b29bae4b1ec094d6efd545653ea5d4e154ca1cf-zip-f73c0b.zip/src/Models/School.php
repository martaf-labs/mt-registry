<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtMedia\Traits\HasMedia;

/**
 * Logo / seal / signature / header_image sont des médias polymorphes (mt-media),
 * accessibles via mediaOfType('logo'), image(), etc.
 *
 * @property int         $id
 * @property string      $name
 * @property string|null $short_name
 * @property string|null $phone
 * @property string|null $phone_secondary
 * @property string|null $email
 * @property string|null $website
 * @property string|null $address
 * @property string|null $city
 * @property string|null $state
 * @property string      $country
 * @property string|null $postal_code
 * @property string|null $registration_number
 * @property string|null $ministry_code
 * @property string      $type
 * @property string      $education_level
 * @property int|null    $founded_year
 * @property string      $timezone
 * @property string      $currency
 * @property string      $locale
 * @property string|null $description
 * @property string|null $footer_text
 * @property bool        $active
 * @property array|null  $metadata
 */
class School extends MtBaseModel
{
    use SoftDeletes;
    use HasMedia;

    protected $table = 'schools';

    protected $fillable = [
        'name', 'short_name',
        'phone', 'phone_secondary', 'email', 'website',
        'address', 'city', 'state', 'country', 'postal_code',
        'registration_number', 'ministry_code',
        'type', 'education_level', 'founded_year',
        'timezone', 'currency', 'locale',
        'description', 'footer_text',
        'active', 'metadata',
    ];

    protected $casts = [
        'active'       => 'boolean',
        'founded_year' => 'integer',
        'metadata'     => 'array',
    ];

    protected array $translatables = ['name', 'short_name', 'address', 'description', 'footer_text'];

    /**
     * L'école courante = le TENANT (école du user connecté), via SchoolResolver.
     * N'est PAS un singleton « première active » en production (cf. CLAUDE.md).
     */
    public static function current(): ?self
    {
        return app(\Mt\MtSchoolCore\Support\SchoolResolver::class)->current();
    }

    /** URL du média de marque demandé (logo|seal|signature|header_image), ou null. */
    public function brandUrl(string $type = 'logo'): ?string
    {
        return $this->mediaOfType($type)->first()?->media_url;
    }

    public function logoUrl(): ?string
    {
        return $this->brandUrl('logo');
    }

    // =========================================================================
    // Abonnement & modules
    // =========================================================================

    public function subscriptions(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    /** Abonnement valide le plus récent, ou null. */
    public function activeSubscription(): ?Subscription
    {
        return $this->subscriptions()->active()->latest('starts_at')->first();
    }

    /** Codes des modules ouverts à cette école (core + plan de l'abonnement actif). */
    public function enabledModuleCodes(): array
    {
        $sub = $this->activeSubscription();

        if ($sub) {
            return $sub->moduleCodes();
        }

        // Pas d'abonnement actif → seulement les modules de base (core).
        return Module::core()->active()->pluck('code')->all();
    }

    public function hasModule(string $code): bool
    {
        return in_array($code, $this->enabledModuleCodes(), true);
    }
}
