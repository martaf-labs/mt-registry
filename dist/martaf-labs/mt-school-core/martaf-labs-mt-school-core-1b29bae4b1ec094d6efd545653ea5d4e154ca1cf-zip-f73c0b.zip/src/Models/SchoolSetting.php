<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Traits\TracksUser;

/**
 * SchoolSetting — dynamic key/value configuration per group per school year.
 */
class SchoolSetting extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use TracksUser;

    protected $table = 'school_settings';

    protected $fillable = [
        'key', 'value', 'group', 'value_type', 'label', 'description',
        'is_editable', 'school_year_id',
    ];

    protected $casts = [
        'label'       => 'array',
        'is_editable' => 'boolean',
    ];

    protected array $translatables = ['label', 'description'];

    public function getCastedValueAttribute(): mixed
    {
        return match ($this->value_type) {
            'integer' => (int) $this->value,
            'decimal' => (float) $this->value,
            'boolean' => filter_var($this->value, FILTER_VALIDATE_BOOLEAN),
            'json', 'array' => json_decode($this->value, true),
            default   => $this->value,
        };
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $setting = static::where('key', $key)->first();
        return $setting ? $setting->casted_value : $default;
    }

    public static function set(string $key, mixed $value, ?string $group = 'general'): void
    {
        static::updateOrCreate(
            ['key' => $key],
            [
                'value' => is_array($value) ? json_encode($value) : (string) $value,
                'group' => $group,
            ]
        );
    }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
}
