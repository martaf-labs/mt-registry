<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtMedia\Traits\HasMedia;

class Guardian extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtSchoolCore\Traits\HasCustomFields;
    use HasMedia;

    protected $table = 'guardians';

    protected $fillable = [
        'reference', 'last_name', 'first_name', 'gender', 'title',
        'occupation', 'workplace', 'email', 'phone', 'work_phone', 'address',
        'id_card_number', 'has_user_account', 'active', 'notes', 'metadata',
    ];

    protected $casts = [
        'has_user_account' => 'boolean',
        'active'           => 'boolean',
        'metadata'         => 'array',
    ];

    protected array $translatables = [
        'last_name', 'first_name', 'occupation', 'workplace', 'address', 'notes',
    ];

    protected static array $searchableColumns = ['last_name', 'first_name', 'email', 'phone'];

    public function scopeActive($query) { return $query->where('active', true); }

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    public function fullName(): string { return $this->full_name; }

    public function students(): BelongsToMany
    {
        return $this->belongsToMany(
            Student::class,
            'student_guardian',
            'guardian_id',
            'student_id'
        )->withPivot([
            'relationship',
            'is_primary_contact',
            'can_pickup',
            'portal_access',
        ])->withTimestamps();
    }

    public function user(): MorphOne
    {
        return $this->morphOne(config('auth.providers.users.model'), 'userable');
    }
}
