<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\DayOfWeek;
use Mt\MtSchoolCore\Enums\TimeSlotType;

class TimeSlot extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'time_slots';

    protected array $translatables = ['notes'];

    protected $fillable = [
        'timetable_id', 'course_assignment_id', 'subject_id',
        'teacher_id', 'room_id', 'study_group_id',
        'day_of_week', 'start_time', 'end_time',
        'type', 'recurrence', 'active', 'notes',
    ];

    protected $casts = [
        'active'      => 'boolean',
        'day_of_week' => DayOfWeek::class,
        'type'        => TimeSlotType::class,
    ];

    public function scopeActive($query)             { return $query->where('active', true); }
    public function scopeForDay($query, int $day)   { return $query->where('day_of_week', $day); }

    public function timetable(): BelongsTo        { return $this->belongsTo(Timetable::class); }
    public function courseAssignment(): BelongsTo { return $this->belongsTo(CourseAssignment::class); }
    public function subject(): BelongsTo          { return $this->belongsTo(Subject::class); }
    public function teacher(): BelongsTo          { return $this->belongsTo(Teacher::class); }
    public function room(): BelongsTo             { return $this->belongsTo(Room::class); }
    public function studyGroup(): BelongsTo       { return $this->belongsTo(StudyGroup::class); }
    public function exceptions(): HasMany         { return $this->hasMany(ScheduleException::class); }
    public function attendances(): HasMany        { return $this->hasMany(Attendance::class); }
}
