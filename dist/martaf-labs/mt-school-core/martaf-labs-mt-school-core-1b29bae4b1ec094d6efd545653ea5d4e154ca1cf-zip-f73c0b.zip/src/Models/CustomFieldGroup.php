<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * Regroupement d'affichage de champs personnalisés (« Informations médicales »…),
 * propre à une école et à un type d'entité. TENANT (school_id).
 *
 * @property int    $id
 * @property int    $school_id
 * @property string $entity_type
 * @property int    $position
 */
class CustomFieldGroup extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;

    protected $table = 'custom_field_groups';

    protected $fillable = [
        'entity_type', 'name', 'description', 'position',
    ];

    protected $casts = [
        'position' => 'integer',
    ];

    protected array $translatables = ['name', 'description'];

    public function fields(): HasMany
    {
        return $this->hasMany(CustomField::class, 'group_id')->orderBy('position');
    }

    public function scopeForEntity($query, string $entityType)
    {
        return $query->where('entity_type', $entityType)->orderBy('position');
    }
}
