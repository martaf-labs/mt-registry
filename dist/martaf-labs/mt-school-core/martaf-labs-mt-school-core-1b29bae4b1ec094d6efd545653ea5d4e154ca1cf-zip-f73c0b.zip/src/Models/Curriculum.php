<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

class Curriculum extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'curricula';

    protected $fillable = [
        'school_year_id', 'grade_level_id', 'specialization_id',
        'label', 'code', 'active', 'description', 'metadata',
    ];

    protected $casts = [
        'active'   => 'boolean',
        'label'    => 'array',
        'metadata' => 'array',
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code'];

    public function scopeActive($query) { return $query->where('active', true); }

    public function schoolYear(): BelongsTo      { return $this->belongsTo(SchoolYear::class); }
    public function gradeLevel(): BelongsTo      { return $this->belongsTo(GradeLevel::class); }
    public function specialization(): BelongsTo  { return $this->belongsTo(Specialization::class); }

    public function subjects(): BelongsToMany
    {
        return $this->belongsToMany(Subject::class, 'curriculum_subject')
            ->withPivot(['coefficient', 'weekly_hours', 'order', 'is_eliminating', 'eliminating_grade', 'on_report_card']);
    }
}
