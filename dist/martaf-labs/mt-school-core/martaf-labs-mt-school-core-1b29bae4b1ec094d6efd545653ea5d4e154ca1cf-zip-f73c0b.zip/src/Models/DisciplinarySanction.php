<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\SanctionType;

/**
 * DisciplinarySanction — disciplinary record for a student.
 */
class DisciplinarySanction extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'disciplinary_sanctions';

    protected $fillable = [
        'reference', 'enrollment_id', 'type', 'label', 'reason',
        'sanction_date', 'end_date', 'issued_by', 'status',
        'parent_notified', 'parent_notified_at', 'follow_up', 'metadata',
    ];

    protected $casts = [
        'label'               => 'array',
        'sanction_date'       => 'date',
        'end_date'            => 'date',
        'parent_notified'     => 'boolean',
        'parent_notified_at'  => 'datetime',
        'metadata'            => 'array',
        'type'                => SanctionType::class,
    ];

    protected array $translatables = ['label', 'reason', 'follow_up'];

    public function scopeActive($query)  { return $query->where('status', 'active'); }
    public function scopeSevere($query)
    {
        return $query->whereIn('type', [
            SanctionType::TEMP_SUSPENSION->value,
            SanctionType::EXPULSION->value,
        ]);
    }

    public function isActive(): bool   { return $this->status === 'active'; }
    public function isSevere(): bool   { return $this->type?->isSevere() ?? false; }

    public function notifyParent(): self
    {
        $this->update([
            'parent_notified'    => true,
            'parent_notified_at' => now(),
        ]);
        return $this;
    }

    public function lift(): self
    {
        $this->update(['status' => 'lifted']);
        return $this;
    }

    public function enrollment(): BelongsTo { return $this->belongsTo(Enrollment::class); }
}
