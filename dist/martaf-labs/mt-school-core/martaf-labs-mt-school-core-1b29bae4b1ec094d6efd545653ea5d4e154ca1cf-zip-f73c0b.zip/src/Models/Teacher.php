<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Mt\MtFoundation\Traits\LogActivityAction;
use Mt\MtFoundation\Traits\TracksUser;

/**
 * Pedagogical extension of StaffMember — one-to-one via staff_id.
 *
 * @property int         $id
 * @property int         $staff_id
 * @property int|null    $primary_subject_id
 * @property string|null $degree
 * @property string|null $specialty
 * @property float|null  $contract_hours
 */
class Teacher extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use TracksUser, LogActivityAction;

    protected $table = 'teachers';

    protected $fillable = [
        'staff_id', 'primary_subject_id',
        'degree', 'specialty', 'contract_hours',
    ];

    protected $casts = [
        'contract_hours' => 'decimal:2',
    ];

    protected array $translatables = ['specialty'];

    // ── Delegated accessors ───────────────────────────────────────────────────

    public function getFullNameAttribute(): string  { return $this->staff?->full_name ?? ''; }
    public function getLastNameAttribute(): string  { return $this->staff?->last_name ?? ''; }
    public function getFirstNameAttribute(): string { return $this->staff?->first_name ?? ''; }
    public function getEmailAttribute(): ?string    { return $this->staff?->email; }
    public function getPhoneAttribute(): ?string    { return $this->staff?->phone; }
    public function getActiveAttribute(): bool      { return $this->staff?->active ?? false; }
    public function getReferenceAttribute(): ?string{ return $this->staff?->reference; }

    public function fullName(): string { return $this->full_name; }

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive(Builder $query): Builder
    {
        return $query->whereHas('staff', fn($q) => $q->where('active', true));
    }

    public function scopeForSubject(Builder $query, int $subjectId): Builder
    {
        return $query->whereHas('subjects', fn($q) => $q->where('subjects.id', $subjectId));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function classesForYear(int $yearId)
    {
        return $this->courseAssignments()
            ->where('school_year_id', $yearId)
            ->where('active', true)
            ->with('classroom')
            ->get()
            ->pluck('classroom')
            ->unique('id')
            ->values();
    }

    public function assignedHoursForYear(int $yearId): float
    {
        return (float) $this->courseAssignments()
            ->where('school_year_id', $yearId)
            ->sum('weekly_hours');
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function staff(): BelongsTo
    {
        return $this->belongsTo(StaffMember::class, 'staff_id');
    }

    public function primarySubject(): BelongsTo
    {
        return $this->belongsTo(Subject::class, 'primary_subject_id');
    }

    public function subjects(): BelongsToMany
    {
        return $this->belongsToMany(Subject::class, 'teacher_subject');
    }

    public function courseAssignments(): HasMany
    {
        return $this->hasMany(CourseAssignment::class);
    }

    public function assessments(): HasMany
    {
        return $this->hasMany(Assessment::class);
    }

    public function timeSlots(): HasMany
    {
        return $this->hasMany(TimeSlot::class);
    }
}
