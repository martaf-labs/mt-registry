<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\PeriodType;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * @property int        $id
 * @property int        $school_year_id
 * @property int|null   $parent_id
 * @property array      $label
 * @property string     $code
 * @property PeriodType $type
 * @property int        $order
 * @property bool       $is_active
 * @property bool       $is_closed
 * @property float      $weight
 */
class Period extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'periods';

    protected $fillable = [
        'school_year_id', 'parent_id', 'label', 'code', 'type',
        'order', 'start_date', 'end_date', 'is_active', 'is_closed', 'weight',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date'   => 'date',
        'is_active'  => 'boolean',
        'is_closed'  => 'boolean',
        'weight'     => 'decimal:2',
        'type'       => PeriodType::class,
        'label'      => 'array',
    ];

    protected array $translatables = ['label'];
    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)    { return $query->where('is_active', true); }
    public function scopeOpen($query)      { return $query->where('is_closed', false); }
    public function scopeRoots($query)     { return $query->whereNull('parent_id'); }
    public function scopeTerms($query)     { return $query->where('type', PeriodType::TERM->value); }
    public function scopeSemesters($query) { return $query->where('type', PeriodType::SEMESTER->value); }
    public function scopeSequences($query) { return $query->where('type', PeriodType::SEQUENCE->value); }

    public function scopeForYear($query, int $yearId)
    {
        return $query->where('school_year_id', $yearId);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public static function currentPeriod(): ?self
    {
        return static::where('is_active', true)->orderBy('order')->first();
    }

    public function isTerm(): bool     { return $this->type === PeriodType::TERM; }
    public function isSequence(): bool { return $this->type === PeriodType::SEQUENCE; }
    public function isSemester(): bool { return $this->type === PeriodType::SEMESTER; }
    public function isRoot(): bool     { return is_null($this->parent_id); }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function schoolYear(): BelongsTo
    {
        return $this->belongsTo(SchoolYear::class);
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Period::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Period::class, 'parent_id')->orderBy('order');
    }

    public function assessments(): HasMany     { return $this->hasMany(Assessment::class); }
    public function subjectAverages(): HasMany { return $this->hasMany(SubjectAverage::class); }
    public function periodAverages(): HasMany  { return $this->hasMany(PeriodAverage::class); }
    public function reportCards(): HasMany     { return $this->hasMany(ReportCard::class); }
    public function classCouncils(): HasMany   { return $this->hasMany(ClassCouncil::class); }
    public function homeworks(): HasMany       { return $this->hasMany(Homework::class); }
}
