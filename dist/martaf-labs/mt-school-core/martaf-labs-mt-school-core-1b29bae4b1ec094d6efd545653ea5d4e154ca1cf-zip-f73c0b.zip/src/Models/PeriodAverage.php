<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Traits\TracksUser;
use Mt\MtSchoolCore\Enums\Mention;

class PeriodAverage extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    use TracksUser;

    protected $table = 'period_averages';

    protected array $translatables = ['council_notes'];

    protected $fillable = [
        'enrollment_id', 'period_id',
        'overall_average', 'total_points', 'total_coefficients',
        'rank', 'class_size', 'class_average', 'class_max_average', 'class_min_average',
        'mention', 'overall_assessment', 'council_decision', 'council_notes',
        'justified_absences', 'unjustified_absences', 'tardiness_count',
        'is_validated', 'validated_by', 'validated_at',
    ];

    protected $casts = [
        'overall_average'    => 'decimal:2',
        'total_points'       => 'decimal:2',
        'total_coefficients' => 'decimal:2',
        'class_average'      => 'decimal:2',
        'class_max_average'  => 'decimal:2',
        'class_min_average'  => 'decimal:2',
        'overall_assessment' => 'array',
        'is_validated'       => 'boolean',
        'validated_at'       => 'datetime',
        'mention'            => Mention::class,
    ];

    public function enrollment(): BelongsTo { return $this->belongsTo(Enrollment::class); }
    public function period(): BelongsTo     { return $this->belongsTo(Period::class); }
    public function reportCard(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(ReportCard::class, 'period_average_id');
    }
}
