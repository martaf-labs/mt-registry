<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * TeachingResource — document, file, or link shared by a teacher with students.
 */
class TeachingResource extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'teaching_resources';

    protected $fillable = [
        'school_year_id', 'subject_id', 'class_id', 'grade_level_id', 'teacher_id',
        'title', 'description', 'type', 'file', 'external_url', 'mime_type', 'file_size',
        'audience', 'published', 'downloads', 'views', 'tags', 'metadata',
    ];

    protected $casts = [
        'description' => 'array',
        'tags'        => 'array',
        'metadata'    => 'array',
        'published'   => 'boolean',
        'title'       => 'array',
    ];

    protected array $translatables = ['title', 'description'];

    public function scopePublished($query)           { return $query->where('published', true); }
    public function scopeOfType($query, string $t)   { return $query->where('type', $t); }

    public function incrementDownloads(): void { $this->increment('downloads'); }
    public function incrementViews(): void     { $this->increment('views'); }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
    public function subject(): BelongsTo    { return $this->belongsTo(Subject::class); }
    public function classroom(): BelongsTo  { return $this->belongsTo(Classroom::class, 'class_id'); }
    public function gradeLevel(): BelongsTo { return $this->belongsTo(GradeLevel::class); }
    public function teacher(): BelongsTo    { return $this->belongsTo(Teacher::class); }
}
