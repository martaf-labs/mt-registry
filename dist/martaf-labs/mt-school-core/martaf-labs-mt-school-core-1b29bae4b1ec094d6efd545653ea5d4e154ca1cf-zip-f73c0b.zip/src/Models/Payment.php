<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\PaymentMethod;

/**
 * Payment — an actual payment made by a family.
 */
class Payment extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'payments';

    protected array $translatables = ['notes'];

    protected $fillable = [
        'reference', 'school_fee_id', 'installment_id',
        'amount', 'currency', 'payment_date', 'payment_method',
        'transaction_number', 'status', 'receipt_file', 'receipt_sent',
        'collected_by', 'notes', 'metadata',
    ];

    protected $casts = [
        'amount'         => 'decimal:2',
        'payment_date'   => 'date',
        'receipt_sent'   => 'boolean',
        'metadata'       => 'array',
        'payment_method' => PaymentMethod::class,
    ];

    public function scopeConfirmed($query) { return $query->where('status', 'confirmed'); }
    public function scopePending($query)   { return $query->where('status', 'pending'); }
    public function isConfirmed(): bool    { return $this->status === 'confirmed'; }

    public function schoolFee(): BelongsTo   { return $this->belongsTo(SchoolFee::class); }
    public function installment(): BelongsTo { return $this->belongsTo(PaymentInstallment::class); }
}
