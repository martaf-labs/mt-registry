<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

class Specialization extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'specializations';

    protected $fillable = [
        'label', 'code', 'abbreviation', 'color', 'active', 'description',
    ];

    protected $casts = [
        'active' => 'boolean',
        'label'  => 'array',
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code', 'abbreviation'];

    public function scopeActive($query) { return $query->where('active', true); }

    public function gradeLevels(): BelongsToMany
    {
        return $this->belongsToMany(GradeLevel::class, 'grade_level_specialization');
    }

    public function classes(): HasMany   { return $this->hasMany(Classroom::class); }
    public function curricula(): HasMany { return $this->hasMany(Curriculum::class); }
}
