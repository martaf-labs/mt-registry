<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\CustomFieldType;

/**
 * Définition d'un champ personnalisé, propre à une école et à un type d'entité.
 * TENANT (school_id). `key` est unique par (école, entity_type).
 *
 * @property int                  $id
 * @property int                  $school_id
 * @property int|null             $group_id
 * @property string               $entity_type
 * @property string               $key
 * @property CustomFieldType      $type
 * @property array|null           $options
 * @property bool                 $required
 * @property bool                 $active
 * @property int                  $position
 */
class CustomField extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;

    protected $table = 'custom_fields';

    protected $fillable = [
        'group_id', 'entity_type', 'key', 'label', 'help',
        'type', 'options', 'required', 'default', 'position', 'active',
    ];

    protected $casts = [
        'type'     => CustomFieldType::class,
        'options'  => 'array',
        'default'  => 'array',
        'required' => 'boolean',
        'active'   => 'boolean',
        'position' => 'integer',
    ];

    protected array $translatables = ['label', 'help'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeForEntity($query, string $entityType)
    {
        return $query->where('entity_type', $entityType);
    }

    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function group(): BelongsTo
    {
        return $this->belongsTo(CustomFieldGroup::class, 'group_id');
    }

    public function values(): HasMany
    {
        return $this->hasMany(CustomFieldValue::class, 'custom_field_id');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Schéma de champ pour le framework de formulaires mt-views. */
    public function toFormField(): array
    {
        $field = [
            'name'     => 'custom_fields.' . $this->key,
            'label'    => $this->label,
            'type'     => $this->type->formType(),
            'required' => (bool) $this->required,
            'hint'     => $this->help,
        ];

        if ($this->type->hasOptions()) {
            $field['options'] = collect($this->options ?? [])
                ->mapWithKeys(fn ($o) => [$o['value'] => $o['label'] ?? $o['value']])
                ->all();
        }

        if ($this->type->isMultiValue()) {
            $field['multiple'] = true;
        }

        return $field;
    }

    /** Règles de validation pour ce champ. */
    public function validationRules(): array
    {
        return $this->type->validationRules((bool) $this->required);
    }
}
