<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Traits\TracksUser;

/**
 * DataOperation — audit trail for batch import / export operations.
 */
class DataOperation extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use TracksUser;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    protected $table = 'data_operations';

    protected array $translatables = ['notes'];

    protected $fillable = [
        'operation', 'entity', 'format', 'file', 'status',
        'total_rows', 'rows_ok', 'rows_error', 'rows_skipped',
        'error_report', 'school_year_id', 'started_at', 'finished_at', 'notes',
    ];

    protected $casts = [
        'error_report' => 'array',
        'started_at'   => 'datetime',
        'finished_at'  => 'datetime',
    ];

    public function scopeImports($query)    { return $query->where('operation', 'import'); }
    public function scopeExports($query)    { return $query->where('operation', 'export'); }
    public function scopeCompleted($query)  { return $query->where('status', 'completed'); }
    public function scopeFailed($query)     { return $query->where('status', 'failed'); }

    public function isCompleted(): bool { return $this->status === 'completed'; }
    public function hasFailed(): bool   { return $this->status === 'failed'; }

    public function successRate(): float
    {
        if (!$this->total_rows) return 0;
        return round(($this->rows_ok / $this->total_rows) * 100, 1);
    }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
}
