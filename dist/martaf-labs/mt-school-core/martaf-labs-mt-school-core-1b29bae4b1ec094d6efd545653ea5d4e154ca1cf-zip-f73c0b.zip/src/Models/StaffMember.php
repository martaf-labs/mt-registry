<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\ContractStatus;
use Mt\MtSchoolCore\Enums\StaffType;

/**
 * @property int              $id
 * @property string           $reference
 * @property string           $last_name
 * @property string           $first_name
 * @property string|null      $gender
 * @property string|null      $title
 * @property StaffType        $type
 * @property ContractStatus|null $contract_status
 * @property bool             $active
 */
class StaffMember extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtSchoolCore\Traits\HasCustomFields;
    use \Mt\MtMedia\Traits\HasMedia; // photo (média vedette) + galerie, comme élève/tuteur

    protected $table = 'staff';

    protected $fillable = [
        'reference', 'last_name', 'first_name', 'gender', 'title',
        'birth_date', 'birth_place', 'nationality', 'id_card_number',
        'type', 'position', 'grade', 'contract_status',
        'hire_date', 'contract_end_date',
        'email', 'phone', 'emergency_phone', 'address',
        'has_user_account', 'active', 'notes', 'metadata',
    ];

    protected $casts = [
        'birth_date'        => 'date',
        'hire_date'         => 'date',
        'contract_end_date' => 'date',
        'has_user_account'  => 'boolean',
        'active'            => 'boolean',
        'metadata'          => 'array',
        'type'              => StaffType::class,
        'contract_status'   => ContractStatus::class,
    ];

    protected array $translatables = ['last_name', 'first_name', 'birth_place', 'nationality', 'address', 'notes'];

    protected static array $searchableColumns = ['last_name', 'first_name', 'reference', 'email', 'phone'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)                   { return $query->where('active', true); }
    public function scopeOfType($query, StaffType $t)     { return $query->where('type', $t->value); }
    public function scopeTeachers($query)                 { return $query->where('type', StaffType::TEACHER->value); }
    public function scopeManagement($query)               { return $query->where('type', StaffType::MANAGEMENT->value); }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    public function getFullNameReverseAttribute(): string
    {
        return trim("{$this->last_name} {$this->first_name}");
    }

    public function getAgeAttribute(): ?int
    {
        return $this->birth_date?->age;
    }

    public function getInitialsAttribute(): string
    {
        return mb_strtoupper(
            mb_substr($this->first_name ?? '', 0, 1) .
            mb_substr($this->last_name ?? '', 0, 1)
        );
    }

    public function fullName(): string { return $this->full_name; }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isTeacher(): bool      { return $this->type === StaffType::TEACHER; }
    public function isManagement(): bool   { return $this->type === StaffType::MANAGEMENT; }
    public function isAdministrative(): bool { return $this->type === StaffType::ADMINISTRATIVE; }

    public function hasActiveContract(): bool
    {
        if (!$this->active) return false;
        if (!$this->contract_end_date) return true;
        return $this->contract_end_date->isFuture();
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function teacher(): HasOne
    {
        return $this->hasOne(Teacher::class, 'staff_id');
    }

    public function user(): MorphOne
    {
        return $this->morphOne(config('auth.providers.users.model'), 'userable');
    }
}
