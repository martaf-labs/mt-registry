<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * ClassCouncil — formal meeting of a class's teachers at the end of a period.
 * Produces minutes and validates results (outcomes, orientations).
 */
class ClassCouncil extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'class_councils';

    protected $fillable = [
        'school_year_id', 'class_id', 'period_id', 'title',
        'council_date', 'location', 'status', 'president_id',
        'minutes_content', 'minutes_file', 'validated_at', 'validated_by',
        'notes', 'metadata',
    ];

    protected $casts = [
        'title'        => 'array',
        'council_date' => 'datetime',
        'validated_at' => 'datetime',
        'metadata'     => 'array',
    ];

    protected array $translatables = ['title', 'location', 'minutes_content', 'notes'];

    public function scopeHeld($query)      { return $query->whereIn('status', ['held', 'minutes_drafted', 'validated']); }
    public function scopeValidated($query) { return $query->where('status', 'validated'); }

    public function isHeld(): bool      { return in_array($this->status, ['held', 'minutes_drafted', 'validated']); }
    public function isValidated(): bool { return $this->status === 'validated'; }

    public function validate(int $userId): self
    {
        $this->update([
            'status'       => 'validated',
            'validated_at' => now(),
            'validated_by' => $userId,
        ]);
        return $this;
    }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
    public function classroom(): BelongsTo  { return $this->belongsTo(Classroom::class, 'class_id'); }
    public function period(): BelongsTo     { return $this->belongsTo(Period::class); }
    public function participants(): HasMany { return $this->hasMany(CouncilParticipant::class, 'class_council_id'); }
}
