<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Traits\TracksUser;

class SubjectAverage extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    use TracksUser;

    protected $table = 'subject_averages';

    protected array $translatables = ['appreciation'];

    protected $fillable = [
        'enrollment_id', 'period_id', 'subject_id',
        'average', 'coefficient', 'weighted_average',
        'rank', 'class_average', 'class_max_score', 'class_min_score',
        'appreciation', 'is_eliminating', 'is_manual', 'is_validated',
    ];

    protected $casts = [
        'average'          => 'decimal:2',
        'coefficient'      => 'decimal:2',
        'weighted_average' => 'decimal:2',
        'class_average'    => 'decimal:2',
        'class_max_score'  => 'decimal:2',
        'class_min_score'  => 'decimal:2',
        'is_eliminating'   => 'boolean',
        'is_manual'        => 'boolean',
        'is_validated'     => 'boolean',
    ];

    public function enrollment(): BelongsTo { return $this->belongsTo(Enrollment::class); }
    public function period(): BelongsTo     { return $this->belongsTo(Period::class); }
    public function subject(): BelongsTo    { return $this->belongsTo(Subject::class); }
}
