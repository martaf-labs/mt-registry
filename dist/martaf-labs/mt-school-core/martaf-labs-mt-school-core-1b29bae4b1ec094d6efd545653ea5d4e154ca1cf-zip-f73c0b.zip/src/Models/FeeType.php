<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * FeeType — defines a type of school fee (tuition, registration, etc.)
 */
class FeeType extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'fee_types';

    protected $fillable = ['label', 'code', 'characteristic', 'active', 'order', 'description'];

    protected $casts = [
        'active' => 'boolean',
        'label'  => 'array',
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code'];

    public function scopeActive($query)    { return $query->where('active', true); }
    public function scopeMandatory($query) { return $query->where('characteristic', 'mandatory'); }

    public function feeSchedules(): HasMany { return $this->hasMany(FeeSchedule::class); }
    public function schoolFees(): HasMany   { return $this->hasMany(SchoolFee::class); }
}
