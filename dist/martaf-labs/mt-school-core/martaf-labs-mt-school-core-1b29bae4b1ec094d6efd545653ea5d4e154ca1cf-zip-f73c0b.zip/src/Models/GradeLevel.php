<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;

class GradeLevel extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'grade_levels';

    protected $fillable = [
        'cycle_id', 'label', 'code', 'abbreviation',
        'order', 'active', 'description', 'metadata',
    ];

    protected $casts = [
        'active'   => 'boolean',
        'label'    => 'array',
        'metadata' => 'array',
    ];

    protected array $translatables = ['label', 'description'];
    protected static array $searchableColumns = ['code', 'abbreviation'];

    public function scopeActive($query) { return $query->where('active', true); }

    public function cycle(): BelongsTo
    {
        return $this->belongsTo(Cycle::class);
    }

    public function specializations(): BelongsToMany
    {
        return $this->belongsToMany(Specialization::class, 'grade_level_specialization');
    }

    public function classes(): HasMany    { return $this->hasMany(Classroom::class); }
    public function curricula(): HasMany  { return $this->hasMany(Curriculum::class); }
}
