<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Traits\TracksUser;

class ScheduleException extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use TracksUser;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    protected $table = 'schedule_exceptions';

    protected array $translatables = ['reason'];

    protected $fillable = [
        'time_slot_id', 'exception_date', 'type',
        'new_time_slot_id', 'new_date', 'new_start_time', 'new_end_time', 'new_room_id',
        'reason',
    ];

    protected $casts = [
        'exception_date' => 'date',
        'new_date'       => 'date',
        'reason'         => 'array',
    ];

    public function timeSlot(): BelongsTo    { return $this->belongsTo(TimeSlot::class); }
    public function newTimeSlot(): BelongsTo { return $this->belongsTo(TimeSlot::class, 'new_time_slot_id'); }
    public function newRoom(): BelongsTo     { return $this->belongsTo(Room::class, 'new_room_id'); }
}
