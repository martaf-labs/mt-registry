<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

class Timetable extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'timetables';

    protected $fillable = [
        'school_year_id', 'class_id', 'label', 'code',
        'status', 'valid_from', 'valid_until', 'is_active', 'notes',
    ];

    protected $casts = [
        'is_active'  => 'boolean',
        'valid_from' => 'date',
        'valid_until' => 'date',
        'label'      => 'array',
    ];

    protected array $translatables = ['label', 'notes'];

    public function scopeActive($query)   { return $query->where('is_active', true); }
    public function scopePublished($query){ return $query->where('status', 'published'); }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
    public function classroom(): BelongsTo  { return $this->belongsTo(Classroom::class, 'class_id'); }
    public function timeSlots(): HasMany    { return $this->hasMany(TimeSlot::class); }
}
