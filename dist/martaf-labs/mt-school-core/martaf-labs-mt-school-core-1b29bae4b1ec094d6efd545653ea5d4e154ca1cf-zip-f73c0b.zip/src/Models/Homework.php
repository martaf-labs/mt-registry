<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * Homework — assignment with a deadline and student submissions.
 */
class Homework extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use BelongsToSchoolYear;

    protected $table = 'homeworks';

    protected $fillable = [
        'school_year_id', 'class_id', 'subject_id', 'teacher_id', 'period_id', 'assessment_id',
        'title', 'instructions', 'assigned_date', 'submission_deadline',
        'is_graded', 'max_score', 'coefficient', 'status', 'resources', 'metadata',
    ];

    protected $casts = [
        'title'               => 'array',
        'instructions'        => 'array',
        'assigned_date'       => 'date',
        'submission_deadline' => 'datetime',
        'is_graded'           => 'boolean',
        'max_score'           => 'decimal:2',
        'coefficient'         => 'decimal:2',
        'resources'           => 'array',
        'metadata'            => 'array',
    ];

    protected array $translatables = ['title', 'instructions'];

    public function scopePublished($query)  { return $query->where('status', 'published'); }
    public function scopeOpen($query)       { return $query->where('status', 'published')->where('submission_deadline', '>', now()); }
    public function scopeExpired($query)    { return $query->where('submission_deadline', '<', now()); }

    public function isExpired(): bool { return $this->submission_deadline->isPast(); }
    public function isGraded(): bool  { return $this->is_graded; }

    public function schoolYear(): BelongsTo { return $this->belongsTo(SchoolYear::class); }
    public function classroom(): BelongsTo  { return $this->belongsTo(Classroom::class, 'class_id'); }
    public function subject(): BelongsTo    { return $this->belongsTo(Subject::class); }
    public function teacher(): BelongsTo    { return $this->belongsTo(Teacher::class); }
    public function period(): BelongsTo     { return $this->belongsTo(Period::class); }
    public function assessment(): BelongsTo { return $this->belongsTo(Assessment::class); }
    public function submissions(): HasMany  { return $this->hasMany(HomeworkSubmission::class); }
}
