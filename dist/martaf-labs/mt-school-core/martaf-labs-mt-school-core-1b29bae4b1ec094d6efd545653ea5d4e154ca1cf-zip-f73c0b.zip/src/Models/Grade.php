<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Traits\TracksUser;

/**
 * Grade scored by a student (enrollment) on an assessment.
 * final_score = score + bonus - penalty (auto-computed on saving).
 *
 * @property int        $id
 * @property int        $assessment_id
 * @property int        $enrollment_id
 * @property float|null $score
 * @property float      $bonus
 * @property float      $penalty
 * @property float|null $final_score
 * @property bool       $is_absent
 * @property bool       $justified_absence
 * @property bool       $is_missing
 * @property bool       $is_validated
 */
class Grade extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use \Mt\MtFoundation\Traits\HasTranslatableCasts;

    use TracksUser;

    protected $table = 'grades';

    protected array $translatables = ['appreciation', 'notes'];

    protected $fillable = [
        'assessment_id', 'enrollment_id',
        'score', 'bonus', 'penalty', 'final_score',
        'is_absent', 'justified_absence', 'is_missing',
        'appreciation', 'rank',
        'is_validated', 'validated_by', 'validated_at',
        'notes',
    ];

    protected $casts = [
        'score'             => 'decimal:2',
        'bonus'             => 'decimal:2',
        'penalty'           => 'decimal:2',
        'final_score'       => 'decimal:2',
        'is_absent'         => 'boolean',
        'justified_absence' => 'boolean',
        'is_missing'        => 'boolean',
        'is_validated'      => 'boolean',
        'validated_at'      => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();

        static::saving(function (self $grade) {
            if ($grade->score !== null && !$grade->is_absent) {
                $max = $grade->assessment?->max_score ?? 20;
                $grade->final_score = round(
                    max(0, min((float) $max, (float) $grade->score + (float) $grade->bonus - (float) $grade->penalty)),
                    2
                );
            } elseif ($grade->is_absent) {
                $grade->final_score = $grade->justified_absence ? null : 0;
            }
        });
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    /** Final score normalised to /20 for homogeneous averaging. */
    public function getScoreNormalisedAttribute(): ?float
    {
        $max = $this->assessment?->max_score ?? 20;
        if ($this->final_score === null || (float) $max == 0) return null;
        return round(((float) $this->final_score * 20) / (float) $max, 2);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isValidated(): bool { return $this->is_validated; }
    public function isAbsent(): bool    { return $this->is_absent; }
    public function isMissing(): bool   { return $this->is_missing; }
    public function isEntered(): bool   { return $this->score !== null || $this->is_absent; }

    public function validate(int $userId): self
    {
        $this->update(['is_validated' => true, 'validated_by' => $userId, 'validated_at' => now()]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function assessment(): BelongsTo  { return $this->belongsTo(Assessment::class); }
    public function enrollment(): BelongsTo  { return $this->belongsTo(Enrollment::class); }
}
