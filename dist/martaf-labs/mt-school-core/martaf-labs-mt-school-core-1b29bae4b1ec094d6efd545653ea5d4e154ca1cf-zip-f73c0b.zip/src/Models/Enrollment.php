<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtMedia\Traits\HasMedia;
use Mt\MtSchoolCore\Enums\EnrollmentResult;
use Mt\MtSchoolCore\Enums\EnrollmentStatus;
use Mt\MtSchoolCore\Traits\BelongsToSchoolYear;

/**
 * Central node of the package.
 * Links a Student, a Classroom, and a SchoolYear.
 * All grades, attendance, report cards, and fees attach to it.
 *
 * @property int                    $id
 * @property string                 $reference   'ENR-2024-00001'
 * @property int                    $school_year_id
 * @property int                    $student_id
 * @property int                    $class_id
 * @property EnrollmentStatus       $status
 * @property EnrollmentResult|null  $result
 * @property float|null             $annual_average
 * @property int|null               $annual_rank
 * @property bool                   $is_repeating
 * @property bool                   $has_scholarship
 */
class Enrollment extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    use HasMedia;
    use BelongsToSchoolYear;

    protected $table = 'enrollments';

    protected $fillable = [
        'reference', 'school_year_id', 'student_id', 'class_id',
        'previous_enrollment_id',
        'status', 'enrollment_date', 'validation_date', 'validated_by',
        'result', 'annual_average', 'annual_rank',
        'source_school', 'destination_school',
        'exam_seat_number', 'has_scholarship', 'is_repeating', 'is_transferred',
        'rejection_reason', 'notes', 'documents', 'metadata',
    ];

    protected $casts = [
        'enrollment_date'  => 'date',
        'validation_date'  => 'date',
        'has_scholarship'  => 'boolean',
        'is_repeating'     => 'boolean',
        'is_transferred'   => 'boolean',
        'annual_average'   => 'decimal:2',
        'documents'        => 'array',
        'metadata'         => 'array',
        'status'           => EnrollmentStatus::class,
        'result'           => EnrollmentResult::class,
    ];

    protected array $translatables = ['rejection_reason', 'notes'];

    protected static array $searchableColumns = ['reference'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeValidated($query)
    {
        return $query->where('status', EnrollmentStatus::VALIDATED->value);
    }

    public function scopePending($query)
    {
        return $query->where('status', EnrollmentStatus::PENDING->value);
    }

    public function scopeForYear($query, int $yearId)
    {
        return $query->where('school_year_id', $yearId);
    }

    public function scopeForClass($query, int $classId)
    {
        return $query->where('class_id', $classId);
    }

    public function scopeForStudent($query, int $studentId)
    {
        return $query->where('student_id', $studentId);
    }

    public function scopeRepeating($query)    { return $query->where('is_repeating', true); }
    public function scopeScholarship($query)  { return $query->where('has_scholarship', true); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isValidated(): bool { return $this->status === EnrollmentStatus::VALIDATED; }
    public function isPending(): bool   { return $this->status === EnrollmentStatus::PENDING; }
    public function isRejected(): bool  { return $this->status === EnrollmentStatus::REJECTED; }
    public function isAdmitted(): bool  { return $this->result === EnrollmentResult::ADMITTED; }

    public function validate(int $userId): self
    {
        $this->update([
            'status'          => EnrollmentStatus::VALIDATED,
            'validation_date' => now(),
            'validated_by'    => $userId,
        ]);
        $this->classroom->recalculateEnrollment();
        return $this;
    }

    public function reject(string $reason, int $userId): self
    {
        $this->update([
            'status'           => EnrollmentStatus::REJECTED,
            'rejection_reason' => $reason,
            'validated_by'     => $userId,
        ]);
        return $this;
    }

    public function reportCardFor(int $periodId): ?ReportCard
    {
        return $this->reportCards()->where('period_id', $periodId)->first();
    }

    public function periodAverageFor(int $periodId): ?PeriodAverage
    {
        return $this->periodAverages()->where('period_id', $periodId)->first();
    }

    public function outstandingBalance(): float
    {
        return (float) $this->schoolFees()->sum('remaining_amount');
    }

    public function isUpToDate(): bool
    {
        return $this->outstandingBalance() <= 0;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function schoolYear(): BelongsTo
    {
        return $this->belongsTo(SchoolYear::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    public function classroom(): BelongsTo
    {
        return $this->belongsTo(Classroom::class, 'class_id');
    }

    public function previousEnrollment(): BelongsTo
    {
        return $this->belongsTo(Enrollment::class, 'previous_enrollment_id');
    }

    public function grades(): HasMany          { return $this->hasMany(Grade::class); }
    public function subjectAverages(): HasMany { return $this->hasMany(SubjectAverage::class); }
    public function periodAverages(): HasMany  { return $this->hasMany(PeriodAverage::class); }
    public function reportCards(): HasMany     { return $this->hasMany(ReportCard::class); }
    public function attendances(): HasMany     { return $this->hasMany(Attendance::class); }
    public function absences(): HasMany        { return $this->hasMany(Attendance::class)->where('status', 'absent'); }
    public function absenceJustifications(): HasMany { return $this->hasMany(AbsenceJustification::class); }
    public function schoolFees(): HasMany      { return $this->hasMany(SchoolFee::class); }
    public function scholarships(): HasMany    { return $this->hasMany(Scholarship::class); }
    public function sanctions(): HasMany       { return $this->hasMany(DisciplinarySanction::class); }
    public function homeworkSubmissions(): HasMany { return $this->hasMany(HomeworkSubmission::class); }
    public function certificates(): HasMany    { return $this->hasMany(SchoolCertificate::class); }
}
