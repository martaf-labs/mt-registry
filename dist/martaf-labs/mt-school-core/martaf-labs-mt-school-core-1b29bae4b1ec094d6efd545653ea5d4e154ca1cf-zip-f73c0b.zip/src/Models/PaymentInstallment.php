<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * PaymentInstallment — a planned payment tranche for a school fee.
 */
class PaymentInstallment extends Model
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'payment_installments';

    protected $fillable = [
        'school_fee_id', 'label', 'order',
        'amount', 'due_date', 'status', 'amount_paid', 'remaining_amount',
    ];

    protected $casts = [
        'label'            => 'array',
        'amount'           => 'decimal:2',
        'amount_paid'      => 'decimal:2',
        'remaining_amount' => 'decimal:2',
        'due_date'         => 'date',
    ];

    protected array $translatables = ['label'];

    public function scopePaid($query)    { return $query->where('status', 'paid'); }
    public function scopeOverdue($query) { return $query->where('status', 'pending')->where('due_date', '<', now()); }

    public function isPaid(): bool    { return $this->status === 'paid'; }
    public function isOverdue(): bool { return $this->status !== 'paid' && $this->due_date->isPast(); }

    public function schoolFee(): BelongsTo { return $this->belongsTo(SchoolFee::class); }
    public function payments(): HasMany    { return $this->hasMany(Payment::class, 'installment_id'); }
}
