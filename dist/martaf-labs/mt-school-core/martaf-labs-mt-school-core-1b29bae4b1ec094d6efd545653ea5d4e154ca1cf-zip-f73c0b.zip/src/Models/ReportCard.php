<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtSchoolCore\Enums\ReportCardStatus;

/**
 * @property int              $id
 * @property string           $reference
 * @property int              $enrollment_id
 * @property int              $period_id
 * @property int|null         $period_average_id
 * @property ReportCardStatus $status
 * @property string|null      $pdf_file
 * @property bool             $visible_on_portal
 * @property string           $layout
 */
class ReportCard extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'report_cards';

    protected array $translatables = ['form_teacher_name', 'principal_name', 'notes'];

    protected $fillable = [
        'reference', 'enrollment_id', 'period_id', 'period_average_id',
        'status', 'pdf_file',
        'principal_name', 'form_teacher_name', 'signature_hash',
        'generated_at', 'validated_at', 'published_at',
        'visible_on_portal', 'layout', 'metadata', 'notes',
    ];

    protected $casts = [
        'generated_at'    => 'datetime',
        'validated_at'    => 'datetime',
        'published_at'    => 'datetime',
        'visible_on_portal' => 'boolean',
        'metadata'        => 'array',
        'status'          => ReportCardStatus::class,
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePublished($query)       { return $query->where('status', ReportCardStatus::PUBLISHED->value); }
    public function scopeVisibleOnPortal($query) { return $query->where('visible_on_portal', true); }
    public function scopeValidated($query)
    {
        return $query->whereIn('status', [ReportCardStatus::VALIDATED->value, ReportCardStatus::PUBLISHED->value]);
    }
    public function scopeForPeriod($query, int $periodId) { return $query->where('period_id', $periodId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isGenerated(): bool
    {
        return in_array($this->status, [ReportCardStatus::GENERATED, ReportCardStatus::VALIDATED, ReportCardStatus::PUBLISHED]);
    }

    public function isValidated(): bool
    {
        return in_array($this->status, [ReportCardStatus::VALIDATED, ReportCardStatus::PUBLISHED]);
    }

    public function isPublished(): bool { return $this->status === ReportCardStatus::PUBLISHED; }

    public function publish(): self
    {
        $this->update([
            'status'           => ReportCardStatus::PUBLISHED,
            'published_at'     => now(),
            'visible_on_portal' => true,
        ]);
        return $this;
    }

    public function validate(): self
    {
        $this->update([
            'status'       => ReportCardStatus::VALIDATED,
            'validated_at' => now(),
        ]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function enrollment(): BelongsTo
    {
        return $this->belongsTo(Enrollment::class);
    }

    public function period(): BelongsTo
    {
        return $this->belongsTo(Period::class);
    }

    public function periodAverage(): BelongsTo
    {
        return $this->belongsTo(PeriodAverage::class, 'period_average_id');
    }
}
