<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtFoundation\Models\MtBaseModel;

/**
 * Scholarship — financial aid attributed to a student for a year.
 */
class Scholarship extends MtBaseModel
{
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;
    protected $table = 'scholarships';

    protected $fillable = [
        'reference', 'enrollment_id', 'label', 'type',
        'amount', 'currency', 'coverage', 'coverage_rate',
        'award_date', 'end_date', 'status',
        'organization', 'conditions', 'notes',
    ];

    protected $casts = [
        'label'         => 'array',
        'amount'        => 'decimal:2',
        'coverage_rate' => 'decimal:2',
        'award_date'    => 'date',
        'end_date'      => 'date',
    ];

    protected array $translatables = ['label', 'conditions', 'notes', 'organization'];

    public function scopeActive($query)  { return $query->where('status', 'active'); }
    public function scopeMerit($query)   { return $query->where('type', 'merit'); }

    public function isActive(): bool  { return $this->status === 'active'; }
    public function isExpired(): bool { return $this->end_date && $this->end_date->isPast(); }

    public function enrollment(): BelongsTo { return $this->belongsTo(Enrollment::class); }
}
