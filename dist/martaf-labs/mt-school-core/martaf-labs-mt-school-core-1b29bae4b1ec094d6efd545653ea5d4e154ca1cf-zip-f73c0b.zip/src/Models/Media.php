<?php

namespace Mt\MtSchoolCore\Models;

use Mt\MtMedia\Models\BaseMedia;

/**
 * Modèle Media concret de l'application scolaire.
 * Polymorphe : rattaché à Student, Guardian, Enrollment, etc.
 * Référencé via config('mt-media.model').
 */
class Media extends BaseMedia
{
    //
}
