<?php

namespace Mt\MtSchoolCore\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    // Tenant : chaque réglage (setup, langues d'enseignement…) appartient à une école.
    use \Mt\MtSchoolCore\Traits\BelongsToSchool;

    protected $table = 'school_settings';

    protected $fillable = ['key', 'value', 'school_id'];

    // ── Static API ────────────────────────────────────────────────────────────

    public static function get(string $key, mixed $default = null): mixed
    {
        $setting = static::where('key', $key)->first();
        return $setting?->value ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        static::updateOrCreate(
            ['key' => $key],
            ['value' => is_array($value) ? json_encode($value) : (string) $value]
        );
    }

    public static function getJson(string $key, mixed $default = null): mixed
    {
        $raw = static::get($key);
        if (is_null($raw)) return $default;
        $decoded = json_decode($raw, true);
        return json_last_error() === JSON_ERROR_NONE ? $decoded : $default;
    }

    public static function getBool(string $key, bool $default = false): bool
    {
        $val = static::get($key);
        if (is_null($val)) return $default;
        return in_array(strtolower((string) $val), ['1', 'true', 'yes', 'on'], true);
    }

    public static function isSetupComplete(): bool
    {
        return static::getBool('setup_completed');
    }
}
