<?php

namespace Mt\MtSchoolCore\Models;

use Mt\MtAuth\Models\BaseDeveloppeur;

class Developpeur extends BaseDeveloppeur
{
    //
}
