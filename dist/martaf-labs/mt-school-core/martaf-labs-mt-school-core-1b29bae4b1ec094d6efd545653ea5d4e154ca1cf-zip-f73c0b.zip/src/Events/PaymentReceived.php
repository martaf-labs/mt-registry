<?php

namespace Mt\MtSchoolCore\Events;

use Mt\MtSchoolCore\Models\Payment;

class PaymentReceived
{
    public function __construct(public readonly Payment $payment) {}
}
