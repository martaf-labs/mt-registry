<?php

namespace Mt\MtSchoolCore\Events;

use Mt\MtSchoolCore\Models\Attendance;

class AbsenceRecorded
{
    public function __construct(public readonly Attendance $attendance) {}
}
