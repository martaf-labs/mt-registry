<?php

namespace Mt\MtSchoolCore\Events;

use Mt\MtSchoolCore\Models\Assessment;

class GradesEntered
{
    public function __construct(public readonly Assessment $assessment) {}
}
