<?php

namespace Mt\MtSchoolCore\Events;

use Mt\MtSchoolCore\Models\ReportCard;

class ReportCardPublished
{
    public function __construct(public readonly ReportCard $reportCard) {}
}
