<?php

namespace Mt\MtSchoolCore\Events;

use Mt\MtSchoolCore\Models\Enrollment;

class EnrollmentValidated
{
    public function __construct(public readonly Enrollment $enrollment) {}
}
