<?php

namespace Mt\MtSchoolCore\DTOs;

use DateTimeInterface;

/**
 * Résultat d'une tentative de paiement, indépendant du fournisseur.
 */
class PaymentResult
{
    public function __construct(
        public bool $success,
        public string $gateway,
        public ?string $reference = null,
        public ?DateTimeInterface $paidAt = null,
        public array $raw = [],
    ) {}
}
