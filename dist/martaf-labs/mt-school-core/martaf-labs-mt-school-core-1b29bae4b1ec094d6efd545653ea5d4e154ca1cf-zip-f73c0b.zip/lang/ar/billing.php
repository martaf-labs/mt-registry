<?php

/*
| مجال الفوترة (شراء / تجديد الاشتراك، التسعير).
| Namespace mtschool::billing.*
*/

return [
    // ── عناوين الصفحات (Livewire ->title()) ──
    'renew_title'    => 'تجديد الاشتراك',
    'checkout_title' => 'إتمام اشتراكك',
    'pricing_title'  => 'باقاتنا',

    // ── التجديد (RenewComponent + renew.blade) ──
    'renew_reactivated' => 'تمّت إعادة تفعيل الاشتراك. مرحباً بعودتك!',
    'expired_heading'   => 'انتهى الاشتراك',
    'expired_intro'     => 'تمّ تعليق وصول :name. بياناتك محفوظة — جدّد لإعادة تفعيل المؤسسة.',
    'your_plan'         => 'باقتك',
    'per_month'         => 'شهر',
    'per_term'          => 'فصل',
    'per_year'          => 'سنة',
    'max_students'      => ':count تلميذ كحدّ أقصى',
    'unlimited_students'=> 'عدد تلاميذ غير محدود',
    'renew_button'      => 'تجديد — :amount :currency',
    'processing'        => 'جارٍ المعالجة…',
    'simulated_payment' => 'دفع محاكى (وضع التطوير).',
    'no_plan_to_renew'  => 'لا توجد باقة لإعادة تجديدها.',
    'see_plans'         => 'عرض الباقات',
    'logout'            => 'تسجيل الخروج',

    // ── إتمام الطلب (Checkout + checkout.blade) ──
    'checkout_subtitle'   => 'أنشئ حساب المسؤول الخاص بك.',
    'plan_label'          => 'باقة :name',
    'your_name'           => 'اسمك',
    'school_name_optional'=> 'اسم المؤسسة (اختياري)',
    'school_name_ph'      => 'يمكنك تحديده لاحقاً',
    'email'               => 'البريد الإلكتروني',
    'password'            => 'كلمة المرور',
    'password_confirm'    => 'تأكيد كلمة المرور',
    'pay_button'          => 'ادفع :amount :currency (محاكاة)',
    'simulated_payment_long' => 'دفع محاكى (وضع التطوير). لا يُخصم أي مبلغ.',
    'email_unique'        => 'يوجد حساب مسجّل بهذا البريد الإلكتروني بالفعل.',
    'password_confirmed'  => 'تأكيد كلمة المرور غير مطابق.',

    // ── التسعير (Pricing + pricing.blade) ──
    'pricing_heading'  => 'اختر باقتك',
    'pricing_subtitle' => 'أدر مؤسستك من الروضة إلى الثانوي. غيّر باقتك في أي وقت.',
    'choose_plan'      => 'اختر :name',
    'already_account'  => 'لديك حساب بالفعل؟',
    'login'            => 'تسجيل الدخول',
];
