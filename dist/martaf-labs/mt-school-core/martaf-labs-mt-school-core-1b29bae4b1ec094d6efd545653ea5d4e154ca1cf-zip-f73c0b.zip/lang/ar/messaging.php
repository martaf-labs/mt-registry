<?php

return [
    'title'            => 'المراسلة',
    'subtitle'         => 'مراسلاتك مع المؤسسة.',
    'new_message'      => 'رسالة جديدة',
    'no_conversations' => 'لا توجد محادثة.',
    'select_prompt'    => 'اختر محادثة أو ابدأ محادثة جديدة.',
    'write_placeholder'=> 'اكتب رسالة…',
    'recipient'        => 'المستلم',
    'choose'           => '— اختر —',
    'message'          => 'الرسالة',
];
