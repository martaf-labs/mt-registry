<?php

return [
    // رسائل « متطلب ناقص » (PrerequisiteService)
    'prereq_classes'      => 'لا يوجد أي قسم بعد. أنشئوا الأقسام أولًا (الهيكلة ← الأقسام).',
    'prereq_classes_cta'  => 'إنشاء الأقسام',
    'prereq_subjects'     => 'لا توجد أي مادة بعد. أنشئوا المواد أولًا (الهيكلة ← المواد).',
    'prereq_subjects_cta' => 'إنشاء المواد',
    'prereq_teachers'     => 'لا يوجد أي أستاذ مسجَّل. أضيفوا الأساتذة أولًا (الموظفون ← الأساتذة).',
    'prereq_teachers_cta' => 'إضافة الأساتذة',
    'prereq_assignments'     => 'لا يوجد أي إسناد أستاذ↔قسم↔مادة. قوموا بالإسنادات أولًا (الموظفون ← الإسنادات).',
    'prereq_assignments_cta' => 'إجراء الإسنادات',
    'prereq_students'     => 'لا يوجد أي تلميذ مسجَّل. أضيفوا أو استوردوا التلاميذ أولًا.',
    'prereq_students_cta' => 'إضافة التلاميذ',
    'prereq_enrollments'     => 'لا يوجد أي تلميذ مسجَّل في السنة النشطة. سجِّلوا التلاميذ أولًا.',
    'prereq_enrollments_cta' => 'تسجيل التلاميذ',
    'prereq_fee_types'     => 'لم يُحدَّد أي نوع رسوم. أنشئوا أنواع الرسوم أولًا (المالية ← أنواع الرسوم).',
    'prereq_fee_types_cta' => 'إنشاء أنواع الرسوم',
    'prereq_fee_schedule'     => 'شبكة الرسوم فارغة. حدِّدوا المبالغ حسب المستوى أولًا (المالية ← شبكة الرسوم).',
    'prereq_fee_schedule_cta' => 'ملء الشبكة',
    'prereq_assessments'     => 'لا يوجد أي تقييم للسنة النشطة. أنشئوا التقييمات أولًا.',
    'prereq_assessments_cta' => 'إنشاء التقييمات',
    'prereq_grades'     => 'لم تُدخَل أي نقطة بعد. أدخلوا نقاط التقييمات أولًا.',
    'prereq_grades_cta' => 'إدخال النقاط',

    // قائمة الانطلاق (لوحة القيادة)
    'checklist_title'   => 'تجهيز مدرستكم',
    'step_classes'      => 'إنشاء الأقسام',
    'step_subjects'     => 'إنشاء المواد',
    'step_teachers'     => 'إضافة الأساتذة',
    'step_assignments'  => 'إسناد الأساتذة إلى الأقسام',
    'step_students'     => 'إضافة أو استيراد التلاميذ',
    'step_enrollments'  => 'تسجيل التلاميذ',
    'step_fee_types'    => 'تحديد أنواع الرسوم',
    'step_fee_schedule' => 'ملء شبكة الرسوم',
    'step_assessments'  => 'إنشاء أولى التقييمات',
];
