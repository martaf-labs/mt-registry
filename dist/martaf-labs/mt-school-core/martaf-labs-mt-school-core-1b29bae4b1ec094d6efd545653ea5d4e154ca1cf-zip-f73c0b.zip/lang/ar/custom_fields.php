<?php

/*
| مجال الحقول المخصصة. Namespace mtschool::custom_fields.*
*/

return [
    'title'        => 'الحقول المخصصة',
    'subtitle'     => 'حدّد حقولك الخاصة على بطاقات مؤسستك. تُدخَل القيم بعد ذلك في كل نموذج.',
    'review_guide' => 'مراجعة الدليل',
    'new_group'    => 'مجموعة جديدة',
    'new_field'    => 'حقل جديد',

    'field_count'         => ':n حقل (حقول)',
    'confirm_delete_group'=> 'حذف هذه المجموعة؟ ستبقى حقولها (بدون مجموعة).',
    'ungrouped_fields'    => 'حقول بدون مجموعة',
    'no_custom_fields'    => 'لا يوجد حقل مخصص لهذا الكيان.',
    'create_first_field'  => 'إنشاء الحقل الأول',
    'no_fields_here'      => 'لا يوجد حقل هنا.',

    'inactive'       => 'غير نشط',
    'required'       => 'إلزامي',
    'option_count'   => ':n خيار (خيارات)',
    'confirm_delete_field' => 'حذف هذا الحقل؟ ستُفقد القيم المُدخلة مسبقًا.',

    'edit_field'     => 'تعديل الحقل',
    'new_field_modal'=> 'حقل جديد',
    'label_field'    => 'التسمية',
    'technical_key'  => 'المفتاح (تقني)',
    'key_help'       => 'اتركه فارغًا لتوليده من التسمية.',
    'type'           => 'النوع',
    'group'          => 'المجموعة',
    'no_group'       => '— بدون مجموعة —',
    'options'        => 'الخيارات',
    'add'            => 'إضافة',
    'option_label_ph'=> 'تسمية الخيار',
    'option_value_ph'=> 'القيمة (تلقائي)',
    'no_options'     => 'لا يوجد خيار. انقر على «إضافة».',
    'help_optional'  => 'مساعدة (اختياري)',
    'required_toggle'=> 'إلزامي',
    'active_toggle'  => 'نشط',

    'edit_group'     => 'تعديل المجموعة',
    'new_group_modal'=> 'مجموعة جديدة',
    'group_name'     => 'اسم المجموعة',
    'description_optional' => 'الوصف (اختياري)',

    'field_updated'  => 'تم تعديل الحقل.',
    'field_added'    => 'تمت إضافة الحقل.',
    'field_deleted'  => 'تم حذف الحقل.',
    'group_updated'  => 'تم تعديل المجموعة.',
    'group_added'    => 'تمت إضافة المجموعة.',
    'group_deleted'  => 'تم حذف المجموعة. تبقى حقولها (بدون مجموعة).',
    'key_regex_error'=> 'يجب أن يبدأ المفتاح بحرف ولا يحتوي إلا على أحرف صغيرة وأرقام و«_».',
    'key_unique_error'=> 'هذا المفتاح مستخدم بالفعل لهذا النوع من الكيانات.',
    'options_required_error' => 'أضف خيارًا واحدًا على الأقل لهذا النوع من الحقول.',

    'type_text'        => 'نص قصير',
    'type_textarea'    => 'نص طويل',
    'type_number'      => 'رقم',
    'type_date'        => 'تاريخ',
    'type_email'       => 'بريد إلكتروني',
    'type_phone'       => 'هاتف',
    'type_toggle'      => 'نعم / لا',
    'type_select'      => 'قائمة منسدلة',
    'type_multiselect' => 'اختيار متعدد',

    // الكيانات
    'entity_student'  => 'التلاميذ',
    'entity_guardian' => 'أولياء الأمور',
    'entity_staff'    => 'الموظفون',
];
