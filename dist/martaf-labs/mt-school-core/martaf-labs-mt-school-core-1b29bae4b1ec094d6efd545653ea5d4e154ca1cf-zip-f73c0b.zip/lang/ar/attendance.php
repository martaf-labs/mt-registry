<?php

/*
| مجال الحضور / الحياة المدرسية. Namespace mtschool::attendance.*
*/

return [
    'title'         => 'النداء / الحضور',
    'subtitle'      => 'حدّد حالة كل تلميذ. يُسجَّل فورًا.',

    'classroom'     => 'الفصل',
    'date'          => 'التاريخ',
    'day_period'    => 'نصف اليوم',
    'period_full'   => 'اليوم كاملاً',
    'period_morning'=> 'الصباح',
    'period_afternoon' => 'المساء',

    'present_count' => ':n حاضر (حاضرون)',
    'absent_count'  => ':n غائب (غائبون)',
    'late_count'    => ':n متأخر (متأخرون)',
    'stat_present'  => 'الحاضرون',
    'stat_absent'   => 'الغائبون',
    'stat_late'     => 'المتأخرون',
    'mark_all_present' => 'تحديد الكل حاضر',
    'all_present_msg'  => 'تم تحديد الجميع حاضرين.',

    'no_students'   => 'لا يوجد تلميذ مسجَّل في هذا الفصل.',
    'justified'     => 'مبرر',
    'to_justify'    => 'يحتاج تبريرًا',
    'status_present'=> 'حاضر',
    'status_absent' => 'غائب',
    'status_late'   => 'متأخر',
];
