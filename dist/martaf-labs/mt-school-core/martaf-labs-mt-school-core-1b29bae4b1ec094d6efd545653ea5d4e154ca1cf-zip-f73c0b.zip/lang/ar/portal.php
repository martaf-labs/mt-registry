<?php

/*
| بوابات ولي الأمر / التلميذ / المعلّم (باستثناء البيداغوجيا).
| Namespace: mtschool::  →  __('mtschool::portal.my_children')
*/

return [
    // عناوين الصفحات
    'my_children'      => 'أبنائي',
    'announcements'    => 'الإعلانات',
    'my_space'         => 'فضائي',
    'my_grades'              => 'نقاطي',
    'my_grades_subtitle'    => 'معدلاتك ونقاطك حسب المادة، فترة بفترة.',
    'my_report_cards'       => 'كشوفي',
    'my_attendance'         => 'حضوري',
    'my_attendance_subtitle'=> 'مواظبتك: الحضور والغياب والتأخر.',
    'my_fees'               => 'رسومي',
    'my_fees_subtitle'      => 'تفاصيل رسومك ومدفوعاتك وآجال الاستحقاق.',
    'my_report_cards_subtitle' => 'كشوف درجاتك المنشورة.',
    'open'                  => 'فتح',
    'email_footer'          => 'تتلقى هذا البريد لأن لديك حسابًا على الفضاء الرقمي للمؤسسة.',
    'my_courses'       => 'دروسي',
    'gradebook_title'  => 'التقييمات والدرجات',

    // بوابة ولي الأمر — الرئيسية
    'children_subtitle' => 'تابع مسار أبنائك الدراسي: النتائج وكشوف الدرجات والوضعية المالية.',
    'no_children'       => 'لا يوجد ابن مرتبط بحسابك.',
    'not_enrolled_year' => 'غير مسجَّل هذه السنة',
    'average'           => 'المعدّل',
    'no_average_yet'    => 'لا يوجد معدّل بعد',
    'remaining_to_pay'  => 'المتبقّي للدفع',
    'up_to_date'        => 'مسدَّد بالكامل',
    'report_card'       => 'كشف الدرجات',
    'financial_status'  => 'الوضعية المالية',

    // شاشة المالية (بوابة ولي الأمر)
    'fees_title'          => 'الرسوم الدراسية',
    'fees_subtitle'       => 'تفاصيل الرسوم والمدفوعات وآجال الاستحقاق لأبنائك.',
    'total_billed'        => 'مفوتر',
    'total_paid'          => 'مدفوع',
    'fee_type'            => 'نوع الرسم',
    'status'              => 'الحالة',
    'fee_status_paid'     => 'مسدَّد',
    'fee_status_partial'  => 'جزئي',
    'fee_status_pending'  => 'غير مسدَّد',
    'fee_status_exempt'   => 'معفى',
    'installments'        => 'جدول الأقساط',
    'installment_paid'    => 'مدفوع',
    'installment_overdue' => 'متأخر',
    'installment_pending' => 'قادم',
    'payment_history'     => 'سجل المدفوعات',
    'method'              => 'الطريقة',
    'amount'              => 'المبلغ',
    'reference'           => 'المرجع',
    'no_fees'             => 'لا توجد رسوم لهذه السنة.',
    'download_statement'  => 'كشف PDF',

    // شاشة المتابعة (بوابة ولي الأمر): المواظبة + العقوبات
    'followup_title'      => 'المتابعة الدراسية',
    'followup_subtitle'   => 'مواظبة وانضباط أبنائك.',
    'att_present'         => 'الحضور',
    'att_absent'          => 'الغيابات',
    'att_late'            => 'التأخرات',
    'att_unjustified'     => 'غير مبررة',
    'recent_events'       => 'آخر الغيابات / التأخرات',
    'justified'           => 'مبرر',
    'unjustified'         => 'غير مبرر',
    'no_attendance'       => 'لا توجد غيابات أو تأخرات مسجلة.',
    'sanctions'           => 'العقوبات',

    // شاشة الكشوف (بوابة ولي الأمر)
    'report_cards_title'    => 'الكشوف',
    'report_cards_subtitle' => 'كشوف درجات أبنائك المنشورة.',
    'published_on'          => 'نُشر في',
    'download'              => 'تنزيل',
    'no_report_cards'       => 'لا يوجد كشف منشور حتى الآن.',
    'annual_report_card'    => 'الكشف السنوي',
    'annual_average'        => 'المعدل السنوي',

    // تبريرات الغياب (بوابة ولي الأمر + الإدارة)
    'justify_title'         => 'تبرير غياب',
    'justify_subtitle'      => 'قدّم مبررًا لغياب ابنك/ابنتك.',
    'child'                 => 'الابن/الابنة',
    'choose_child'          => 'اختر ابنًا',
    'from_date'             => 'من',
    'to_date'               => 'إلى',
    'reason'                => 'السبب',
    'reason_illness'        => 'مرض',
    'reason_medical'        => 'موعد طبي',
    'reason_family'         => 'سبب عائلي',
    'reason_travel'         => 'سفر',
    'reason_other'          => 'أخرى',
    'details'               => 'تفاصيل',
    'details_placeholder'   => 'تفاصيل إضافية…',
    'document'              => 'مستند',
    'optional'              => 'اختياري',
    'uploading'             => 'جارٍ الرفع…',
    'submit_justification'  => 'إرسال المبرر',
    'justify_submitted'     => 'تم إرسال مبررك. ستراجعه المؤسسة.',
    'my_justifications'     => 'مبرراتي',
    'justif_pending'        => 'قيد الانتظار',
    'justif_approved'       => 'مقبول',
    'justif_rejected'       => 'مرفوض',
    'rejection_reason'      => 'سبب الرفض',
    'justify_admin_title'   => 'تبريرات الغياب',
    'justify_admin_subtitle'=> 'عالج المبررات المقدّمة من الأولياء.',
    'no_justifications'     => 'لا توجد مبررات.',
    'view_document'         => 'عرض المستند',
    'rejection_placeholder' => 'اشرح سبب الرفض…',
    'confirm_reject'        => 'تأكيد الرفض',
    'reject'                => 'رفض',
    'approve'               => 'قبول',
    'justif_approved_ok'    => 'تمت الموافقة على المبرر، وتم اعتبار الغيابات مبررة.',
    'justif_rejected_ok'    => 'تم رفض المبرر.',

    // بوابة ولي الأمر — الإعلانات
    'announcements_subtitle' => 'المعلومات التي تنشرها المؤسسة.',
    'no_announcements'       => 'لا توجد إعلانات في الوقت الحالي.',
    'importance_urgent'      => 'عاجل',
    'importance_important'   => 'مهم',

    // بوابة التلميذ — الرئيسية
    'no_active_enrollment' => 'لا يوجد تسجيل نشط هذه السنة.',
    'rank'                 => 'الرتبة',
    'my_report_card'       => 'كشف درجاتي',
    'my_timetable'         => 'جدول حصصي',
    'results'              => 'النتائج',
    'col_subject'          => 'المادة',
    'col_avg'              => 'المعدّل',
    'col_rank'             => 'الرتبة',
    'col_class_avg'        => 'معدّل القسم',

    // بوابة المعلّم — الرئيسية
    'courses_subtitle'  => 'أقسامك وموادّك. أدخِل درجات تقييماتك.',
    'no_courses'        => 'لا يوجد درس مُسنَد إليك في الوقت الحالي.',

    // بوابة المعلّم — سجل الدرجات
    'new_assessment'      => 'تقييم جديد',
    'no_assessments'      => 'لا يوجد تقييم. أنشئ تقييمًا لإدخال الدرجات.',
    'entries'             => 'مُدخَلة',
    'assessment_label'    => 'العنوان',
    'assessment_label_ph' => 'فرض 1',
    'period'              => 'الفترة',
    'date'                => 'التاريخ',
    'max_score'           => 'الدرجة القصوى',
    'coefficient'         => 'المعامل',
    'assessment_created'  => 'تم إنشاء التقييم.',

    // سمات التحقق (سجل الدرجات)
    'attr_label'  => 'العنوان',
    'attr_period' => 'الفترة',

    // إنشاء حسابات البوابة
    'create_account'        => 'إنشاء وصول للبوابة',
    'create_parent_account' => 'إنشاء وصول لولي الأمر',
    'create_student_account' => 'إنشاء وصول للتلميذ',
    'no_guardian'           => 'هذا التلميذ ليس له ولي أمر ببريد إلكتروني.',
    'account_created'       => 'تم إنشاء الوصول — المعرّف: :email · كلمة مرور مؤقتة: :password (بلّغها الآن).',
    'account_exists'        => 'هذا المستخدم لديه بالفعل وصول للبوابة (:email).',
    'provision_no_email'    => 'غير ممكن: هذا الملف لا يملك عنوان بريد إلكتروني.',
    'provision_email_taken' => 'العنوان :email مستخدم بالفعل من حساب آخر.',

    // مركز الإشعارات
    'notifications_title'   => 'الإشعارات',
    'notifications_unread'  => ':count غير مقروء',
    'mark_all_read'         => 'تحديد الكل كمقروء',
    'mark_read'             => 'تحديد كمقروء',
    'no_notifications'      => 'لا توجد إشعارات.',

    // إشعارات النظام (مصادر متعلقة بالعمل)
    'notif_report_card_title' => 'الكشف متاح',
    'notif_report_card_body'  => 'تم نشر كشف درجات ابنك/ابنتك وهو متاح للاطلاع.',
    'notif_sanction_title'    => 'عقوبة تأديبية',
    'notif_sanction_body'     => 'تم إصدار عقوبة: :type.',
    'notif_payment_title'     => 'تم استلام الدفعة',
    'notif_payment_body'      => 'تم تسجيل دفعة بقيمة :amount. شكرًا لكم.',
    'notif_absence_title'     => 'إشعار غياب',
    'notif_absence_body'      => 'سُجِّل غياب ابنكم بتاريخ :date.',
];
