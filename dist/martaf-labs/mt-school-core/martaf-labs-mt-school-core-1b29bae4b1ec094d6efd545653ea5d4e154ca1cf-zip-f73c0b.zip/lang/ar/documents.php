<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| النطاق: documents (قوالب الطباعة PDF — dompdf)
| Namespace: mtschool::  →  __('mtschool::documents.report_card_title')
| يجب أن تطابق المفاتيح تمامًا fr/documents.php و en/documents.php.
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // مشترك بين المستندين
    'student'   => 'التلميذ',
    'classroom' => 'القسم',
    'reference' => 'رقم التسجيل',

    // كشف الدرجات
    'report_card_title'   => 'كشف الدرجات',
    'annual_report_card_title' => 'الكشف السنوي',
    'annual_average'      => 'المعدل السنوي',
    'annual_rank'         => 'الرتبة السنوية',
    'decision'            => 'القرار',
    'no_data'             => 'لا توجد بيانات',
    'class_size'          => 'عدد التلاميذ',
    'subject'             => 'المادة',
    'average_short'       => 'المعدل',
    'coefficient_short'   => 'المعامل',
    'weighted_short'      => 'المعدل×م',
    'rank'                => 'الرتبة',
    'class_average_short' => 'معدل القسم',
    'overall_average'     => 'المعدل العام',
    'mention'             => 'الملاحظة',
    'class_average'       => 'معدل القسم',
    'highest'             => 'أعلى معدل',
    'lowest'              => 'أدنى معدل',
    'council_assessment'  => 'التقدير العام للمجلس',
    'distinction'         => 'التميّز',
    'main_teacher'        => 'الأستاذ الرئيسي',
    'head_of_school'      => 'مدير المؤسسة',

    // الكشف المالي
    'fee_statement_title' => 'كشف مالي',
    'edited_on'           => 'حُرّر في',
    'fees'                => 'الرسوم',
    'gross'               => 'الإجمالي',
    'discount'            => 'الخصم',
    'net'                 => 'الصافي',
    'paid'                => 'المدفوع',
    'remaining'           => 'الباقي',
    'no_fees'             => 'لا توجد رسوم. أنشئ الرسوم أولًا.',
    'total_due'           => 'إجمالي المستحق',
    'collected'           => 'المحصّل',
    'remaining_to_pay'    => 'الباقي للدفع',
    'payments'            => 'المدفوعات',
    'date'                => 'التاريخ',
    'payment_reference'   => 'المرجع',
    'method'              => 'الوسيلة',
    'amount'              => 'المبلغ',

    // وسائل الدفع
    'method_cash'          => 'نقدًا',
    'method_mobile_money'  => 'الدفع عبر الهاتف',
    'method_bank_transfer' => 'تحويل بنكي',
    'method_check'         => 'شيك',
    'method_card'          => 'بطاقة',
    'method_other'         => 'أخرى',

    // حالات الرسوم
    'status_paid'      => 'مسدّد',
    'status_partial'   => 'جزئي',
    'status_pending'   => 'غير مدفوع',
    'status_exempt'    => 'معفى',
    'status_cancelled' => 'ملغى',
    'col_type'   => 'النوع',
    'col_status' => 'الحالة',
    'total'      => 'الإجمالي',

    // الشهادات
    'school_year'           => 'السنة الدراسية',
    'certificates_title'    => 'الشهادات',
    'certificates_subtitle' => 'أصدر ونزّل الشهادات الرسمية للتلاميذ.',
    'cert_type'             => 'النوع',
    'cert_title_enrollment' => 'شهادة مدرسية',
    'cert_title_attendance' => 'شهادة حضور',
    'cert_title_success'    => 'شهادة نجاح',
    'cert_title_leaving'    => 'شهادة فصل',
    'cert_body_enrollment'  => 'أنا الموقّع أدناه، مدير المؤسسة، أشهد أن التلميذ :student، المولود في :dob بـ :birthplace (رقم :ref)، مسجّل بانتظام في قسم :class برسم السنة الدراسية :year بمؤسستنا. سُلّمت هذه الشهادة قصد الإدلاء بها عند الحاجة.',
    'cert_body_attendance'  => 'أنا الموقّع أدناه، مدير المؤسسة، أشهد أن التلميذ :student، المولود في :dob بـ :birthplace، واظب بانتظام على الحضور بمؤسستنا في قسم :class خلال السنة الدراسية :year. سُلّمت هذه الشهادة قصد الإدلاء بها عند الحاجة.',
    'cert_body_success'     => 'أنا الموقّع أدناه، مدير المؤسسة، أشهد أن التلميذ :student، المولود في :dob بـ :birthplace، قد استوفى شروط نهاية السنة في قسم :class برسم السنة الدراسية :year. سُلّمت هذه الشهادة قصد الإدلاء بها عند الحاجة.',
    'cert_body_leaving'     => 'أنا الموقّع أدناه، مدير المؤسسة، أشهد أن التلميذ :student، المولود في :dob بـ :birthplace، المسجّل في قسم :class خلال السنة الدراسية :year، قد شُطب من سجلات مؤسستنا بتاريخ :date. سُلّمت هذه الشهادة قصد الإدلاء بها عند الحاجة.',
    'cert_reference'        => 'المرجع',
    'cert_done_on'          => 'حُرّر في :date',
    'cert_footer'           => 'وثيقة رسمية صادرة عن المؤسسة.',
    'cert_choose_student'   => 'اختر تلميذًا',
    'cert_type_label'       => 'نوع الشهادة',
    'cert_issue'            => 'إصدار',
    'cert_issued_ok'        => 'تم إصدار الشهادة بنجاح.',
    'cert_issued_list'      => 'الشهادات الصادرة',
    'cert_none'             => 'لا توجد شهادات صادرة.',
    'cert_issued_on'        => 'صدرت في',
    'cert_student_required' => 'اختر تلميذًا.',
];
