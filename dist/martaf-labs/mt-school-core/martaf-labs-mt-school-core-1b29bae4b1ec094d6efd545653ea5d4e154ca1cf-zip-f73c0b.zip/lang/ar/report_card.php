<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| بطاقة النتائج (report_card) — عبارات واجهة شاشة كشف النقاط.
| النطاق: mtschool::  →  __('mtschool::report_card.title')
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // العنوان / الترويسة
    'title'                => 'كشف النقاط',
    'report_card'          => 'كشف النقاط',
    'print'                => 'طباعة',

    // هوية التلميذ
    'student'              => 'التلميذ',
    'classroom'            => 'القسم',
    'reference'            => 'رقم التسجيل',
    'class_size'           => 'عدد التلاميذ',

    // أعمدة جدول المواد
    'col_subject'          => 'المادة',
    'col_average'          => 'المعدل',
    'col_coefficient'      => 'المعامل',
    'col_weighted'         => 'المعدل×م',
    'col_rank'             => 'الرتبة',
    'col_class_average'    => 'معدل القسم',
    'appreciation_placeholder' => 'الملاحظة…',
    'no_averages'          => 'لا توجد معدلات. احسب المعدلات أولاً.',
    'total'                => 'المجموع',

    // الخلاصة
    'overall_average'      => 'المعدل العام',
    'rank'                 => 'الرتبة',
    'mention'              => 'الميزة',
    'class_average'        => 'معدل القسم',
    'class_max'            => 'أعلى معدل',
    'class_min'            => 'أدنى معدل',

    // المواظبة
    'justified_absences'   => 'غياب مبرر',
    'unjustified_absences' => 'غياب غير مبرر',
    'tardiness'            => 'التأخرات',

    // التقييم العام للمجلس
    'council_assessment'   => 'التقييم العام للمجلس',
    'general_placeholder'  => 'تقييم عام (العمل، السلوك، النصائح…)',
    'distinction'          => 'التمييز',
    'save_appreciation'    => 'حفظ التقييم',
    'appreciation_saved'   => 'تم حفظ التقييم.',
    'subject_appreciation_saved' => 'تم حفظ تقييم المادة.',

    // تمييزات المجلس
    'distinction_none'     => '— لا شيء —',
    'distinction_congratulations' => 'تهاني',
    'distinction_encouragements'  => 'تشجيعات',
    'distinction_honor_roll'      => 'لوحة الشرف',
    'distinction_work_warning'    => 'إنذار بالعمل',
    'distinction_reprimand'       => 'توبيخ',
];
