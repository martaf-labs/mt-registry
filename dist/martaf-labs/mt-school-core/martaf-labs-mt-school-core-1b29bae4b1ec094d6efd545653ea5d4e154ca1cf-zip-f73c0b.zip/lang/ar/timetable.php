<?php

/*
| مجال جدول الحصص. Namespace mtschool::timetable.*
*/

return [
    'title'      => 'جدول الحصص',
    'my_title'   => 'جدول حصصي',
    'subtitle'   => 'انقر على خانة لوضع حصة فيها (من إسنادات الفصل).',
    'no_assignments'   => 'لا يوجد إسناد لهذا الفصل.',
    'assign_teachers'  => 'أسنِد معلمين',
    'first'            => 'أولاً.',

    'course_modal_title' => 'الحصة',
    'course_field'      => 'الحصة (الإسناد)',
    'empty_free_cell'   => '— فارغة (تحرير الخانة) —',
    'room_optional'     => 'القاعة (اختياري)',
    'none'              => '— لا شيء —',
    'no_teacher'        => 'بدون معلم',
    'timetable_updated' => 'تم تحديث جدول الحصص.',

    'day_1' => 'الإثنين',
    'day_2' => 'الثلاثاء',
    'day_3' => 'الأربعاء',
    'day_4' => 'الخميس',
    'day_5' => 'الجمعة',
    'day_6' => 'السبت',
    'day_7' => 'الأحد',
    'conflict_teacher' => 'تعارض: هذا الأستاذ مشغول بالفعل في هذه الحصة (القسم :class).',
    'conflict_room'    => 'تعارض: هذه القاعة مشغولة بالفعل في هذه الحصة (القسم :class).',
];
