<?php

return [
    'title'          => 'استيراد / تصدير',
    'subtitle'       => 'صدّر بياناتك أو استورد التلاميذ دفعة واحدة.',

    // التصدير
    'export_section' => 'تصدير (CSV)',
    'export_hint'    => 'نزّل بياناتك بصيغة CSV (متوافقة مع Excel).',
    'students'       => 'التلاميذ',
    'results'        => 'النتائج',
    'fees'           => 'الرسوم',

    // الاستيراد
    'import_section' => 'استيراد التلاميذ (CSV)',
    'columns_hint'   => 'الأعمدة المتوقعة:',
    'columns_note'   => '(الجنس = M/F، تاريخ الميلاد = YYYY-MM-DD، الفصل = رمز الفصل).',
    'available_codes'=> 'رموز الفصول المتاحة:',
    'download_template' => 'تنزيل النموذج',
    'col_matricule'  => 'الرقم',
    'col_guardian'   => 'ولي الأمر',
    // الوصول إلى البوابة (تزويد جماعي)
    'provision_section'  => 'الوصول إلى البوابة',
    'provision_hint'     => 'ينشئ حسابات دخول لأولياء الأمور (بدون حساب) ويُنزّل قائمة المعرفات وكلمات المرور المؤقتة للتوزيع.',
    'provision_parents'  => 'إنشاء وصول أولياء الأمور',
    'provision_students' => 'إنشاء وصول التلاميذ',
    'provision_confirm'  => 'إنشاء حسابات دخول لجميع أولياء الأمور بدون حساب؟',
    'provision_confirm_students' => 'إنشاء حسابات دخول لجميع التلاميذ بدون حساب؟',
    'parents_none'       => 'لا يوجد ولي أمر جديد للتزويد (الجميع لديهم حسابات).',
    'students_none'      => 'لا يوجد تلميذ جديد للتزويد (الجميع لديهم حسابات).',
    'no_errors'          => 'لا توجد أسطر خاطئة للتصدير.',
    'download_errors'    => 'تصدير :n خطأ',
    'col_errors'         => 'الأخطاء',
    'access_login'       => 'المعرّف',
    'access_password'    => 'كلمة المرور المؤقتة',
    // استيراد الموظفين
    'staff_section'      => 'استيراد الموظفين',
    'staff_hint'         => 'ملف CSV بالأعمدة:',
    'import_staff'       => 'استيراد الموظفين',
    'staff_confirm'      => 'استيراد الموظفين من هذا الملف؟',
    'staff_report'       => 'تم استيراد :imported عضو(أعضاء)، منهم :teachers مدرّس؛ :skipped سطر متجاهَل.',
    // استيراد المواد
    'subjects_section'   => 'استيراد المواد',
    'import_subjects'    => 'استيراد المواد',
    'subjects_report'    => 'تم استيراد :imported مادة؛ :skipped متجاهَلة (رمز ناقص أو موجود).',
    // استيراد الإسنادات
    'assign_section'     => 'استيراد الإسنادات (مدرّس ← قسم ← مادة)',
    'assign_hint'        => 'ملف CSV، السنة النشطة. يُعرَّف المدرّس ببريد بطاقته؛ القسم والمادة بالرمز. الأعمدة:',
    'import_assignments' => 'استيراد الإسنادات',
    'assign_report'      => 'تم إنشاء :imported إسناد؛ :skipped متجاهَل (المدرّس/القسم/المادة غير موجود أو مُسنَد سابقًا).',
    // سجل الاستيراد (التدقيق)
    'history_section'    => 'سجل الاستيراد',
    'history_date'       => 'التاريخ',
    'history_type'       => 'النوع',
    'history_result'     => 'النتيجة',
    'history_by'         => 'بواسطة',
    'history_skipped'    => 'متجاهَل',
    'type_students'      => 'التلاميذ',
    'type_staff'         => 'الموظفون',
    'type_subjects'      => 'المواد',
    'type_assignments'   => 'الإسنادات',
    'type_access_parents'  => 'وصول الأولياء',
    'type_access_students' => 'وصول التلاميذ',
    'reading'        => 'جارٍ قراءة الملف…',
    'valid_of'       => ':valid صالح(ة) / :total سطر (أسطر)',
    'change_file'    => 'تغيير الملف',

    // أعمدة المعاينة
    'col_line'       => '#',
    'col_lastname'   => 'اللقب',
    'col_firstname'  => 'الاسم',
    'col_gender'     => 'الجنس',
    'col_birth'      => 'تاريخ الميلاد',
    'col_class'      => 'الفصل',
    'col_status'     => 'الحالة',
    'status_ok'      => 'صحيح',
    'import_confirm' => 'استيراد الأسطر الصالحة؟',
    'import_n'       => 'استيراد :n تلميذ (تلاميذ)',

    // الرسائل
    'no_valid_rows'  => 'لا يوجد سطر صالح للاستيراد.',
    'imported'       => 'تم استيراد وتسجيل :count تلميذ (تلاميذ).',
    'import_report'  => ':imported مستورد، :duplicates مكرر متجاهَل، :invalid سطر غير صالح، :guardians ولي أمر مرتبط.',

    // أخطاء الأسطر
    'err_lastname'   => 'اللقب مفقود',
    'err_firstname'  => 'الاسم مفقود',
    'err_gender'     => 'الجنس (M/F)',
    'err_date'       => 'تاريخ غير صالح',
    'err_class'      => 'فصل غير معروف',
    'csv_drop' => 'أفلت ملف CSV هنا',
    'csv_hint' => 'صيغة CSV — الفاصل ؛ أو ،',
];
