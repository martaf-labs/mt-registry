<?php

/*
| مجال لوحة القيادة (المدير). Namespace mtschool::dashboard.*
*/

return [
    'title'            => 'لوحة القيادة',
    'subtitle_year'    => 'السنة الدراسية :year',
    'subtitle_default' => 'نظرة عامة على المؤسسة',

    // إجراءات سريعة
    'new_student'      => 'تلميذ جديد',
    'enrollments'      => 'التسجيلات',

    // بطاقات الإحصاءات
    'enrolled'         => 'التلاميذ المسجلون',
    'collection_rate'  => 'التحصيل',
    'school_average'   => 'المعدل العام للمؤسسة',
    'attendance'       => 'المواظبة',
    'teachers'         => 'المعلمون',
    'classes'          => 'الفصول',
    'collected'        => 'المحصَّل',
    'remaining'        => 'المتبقي',
    'period'           => 'الفترة',
    'unjustified_abs'  => 'غيابات غير مبررة',

    // الواجهات
    'enrollment_by_level' => 'التسجيلات حسب المستوى',
    'students_dataset'    => 'التلاميذ',
    'your_plan'           => 'باقتك',
    'collection_by_level' => 'التحصيل حسب المستوى',
    'class_ranking'       => 'ترتيب الفصول',
    'students_count'      => ':n تلميذ (تلاميذ)',

    // واجهة « باقتك »
    'plan_valid_until'  => 'صالحة حتى',
    'plan_quota'        => 'حصة التلاميذ',
    'plan_unlimited'    => 'غير محدود',
    'plan_modules'      => 'الوحدات النشطة',

    // ── الشريط 1 · قوائم الإجراءات ─────────────────────────────────────────
    'pending_enrollments_title' => 'تسجيلات للتصديق',
    'pending_count'             => ':n ملف(ات) قيد الانتظار',
    'badge_pending'             => 'قيد الانتظار',
    'process_enrollment'        => 'معالجة',
    'pending_justifications'    => 'مبررات الغياب',
    'justifications_count'      => ':n للمعالجة',
    'justif_attachment'         => 'مرفق',
    'reportcards_title'         => 'كشوف الفترة',
    'reportcards_published'     => 'منشورة',
    'reportcards_to_publish'    => 'للنشر',
    'reportcards_to_validate'   => 'للتصديق',
    'installments_title'        => 'أقساط الرسوم',
    'overdue_amount'            => 'متأخرة',
    'due_soon_30d'              => 'مستحقة (30 يوم)',
    'installments_count'        => ':n قسط',

    // ── الشريط 2 · الاتجاهات ───────────────────────────────────────────────
    'collection_trend'          => 'اتجاه التحصيلات (12 شهراً)',
    'collected_dataset'         => 'محصّل',
    'average_trend_title'       => 'تطور معدل المؤسسة',
    'average_trend_dataset'     => 'المعدل',
    'absence_trend'             => 'الغيابات والتأخرات (14 يوماً)',
    'absences_dataset'          => 'غيابات',
    'late_dataset'              => 'تأخرات',

    // ── الشريط 3 · البنية والتوزيع ─────────────────────────────────────────
    'class_fill_rate_title'     => 'امتلاء الأقسام',
    'overcrowded'               => ':n٪ · مكتظ',
    'grade_distribution_title'  => 'توزيع المعدلات',
    'grade_band_below10'        => 'أقل من 10',
    'grade_band_10_12'          => '10 إلى 12',
    'grade_band_12_14'          => '12 إلى 14',
    'grade_band_14_16'          => '14 إلى 16',
    'grade_band_16_plus'        => '16 فأكثر',
    'gender_split_title'        => 'إناث / ذكور',
    'girls'                     => 'إناث',
    'boys'                      => 'ذكور',
    'parity_index'              => ':n٪ إناث',

    // ── الشريط 4 · الاستهداف ───────────────────────────────────────────────
    'classes_to_chase'          => 'أقسام للمتابعة',
    'overdue_installments_count' => ':n قسط متأخر',
    'weakest_subjects_title'    => 'أضعف المواد',
    'top_absentees'             => 'الأكثر غياباً',
    'absences_short'            => ':n غياب',

    // ── الشريط 5 · حياة المؤسسة ────────────────────────────────────────────
    'activity_feed'             => 'النشاط الأخير',
    'activity_new_enrollment'   => 'تسجيل جديد: :name',
    'activity_payment_received' => 'استلام دفعة :amount',
    'activity_announcement'     => 'إعلان: :title',
    'upcoming_events'           => 'الأحداث القادمة',
    'event_all_day'             => 'طوال اليوم',
    'class_councils'            => 'مجالس الأقسام',
    'council_planned'           => 'مخطط',
    'council_to_validate'       => 'محضر للتصديق',
    'recent_sanctions'          => 'العقوبات الأخيرة',
    'parent_not_notified'       => 'الولي غير مُبلَّغ',
];
