<?php

/*
| سلاسل الواجهة المشتركة (الأفعال، الحالات، التسميات المتكررة).
| Namespace: mtschool::  →  __('mtschool::common.save')
*/

return [
    // الإجراءات
    'save'        => 'حفظ',
    'all'         => 'الكل',
    'cancel'      => 'إلغاء',
    'delete'      => 'حذف',
    'edit'        => 'تعديل',
    'create'      => 'إنشاء',
    'add'         => 'إضافة',
    'new_m'       => 'جديد',
    'new_f'       => 'جديدة',
    'send'        => 'إرسال',
    'publish'     => 'نشر',
    'unpublish'   => 'إلغاء النشر',
    'back'        => 'رجوع',
    'download'    => 'تنزيل',
    'open'        => 'فتح',
    'analyze'     => 'تحليل',
    'import'      => 'استيراد',
    'export'      => 'تصدير',

    // الحالات
    'published'   => 'منشور',
    'published_f' => 'منشورة',
    'draft'       => 'مسودة',
    'active'      => 'نشط',

    'active_m'    => 'نشط',
    'active_f'    => 'نشطة',
    'inactive_m'  => 'غير نشط',
    'inactive_f'  => 'غير نشطة',
    'status'      => 'الحالة',
    'total'       => 'الإجمالي',
    'yes'         => 'نعم',
    'no'          => 'لا',
    'code'        => 'الرمز',
    'label'       => 'التسمية',
    'description' => 'الوصف',
    'order'       => 'الترتيب',
    'color'       => 'اللون',
    'icon'        => 'الأيقونة',
    'type'        => 'النوع',

    // رسائل التحقق (التواريخ)
    'date_start_required' => 'تاريخ البداية إلزامي.',
    'date_end_required'   => 'تاريخ النهاية إلزامي.',
    'date_end_after'      => 'يجب أن يكون تاريخ النهاية بعد تاريخ البداية.',

    // متفرقات
    'loading'     => 'جارٍ التحميل…',
    'none'        => 'لا شيء',
    'search'      => 'بحث',
    'confirm_delete' => 'تأكيد الحذف؟',
    'students'    => 'تلميذ (تلاميذ)',
    'view'        => 'عرض',
    'action'      => 'إجراء',
    'actions'     => 'إجراءات',
];
