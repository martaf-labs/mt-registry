<?php

/*
|--------------------------------------------------------------------------
| مجالس الأقسام (شاشة الإدارة ClassCouncilManager)
|--------------------------------------------------------------------------
*/

return [
    'title'      => 'مجالس الأقسام',
    'subtitle'   => 'خطّط المجالس، حرّر المحضر وصادق على القرارات.',
    'plan'       => 'تخطيط مجلس',
    'plan_submit' => 'تخطيط',
    'period'     => 'الفترة',
    'all_periods' => 'كل الفترات',
    'date'       => 'التاريخ والساعة',
    'location'   => 'المكان',
    'location_ph' => 'قاعة الأساتذة…',
    'participants' => 'المشاركون',
    'none'       => 'لا مجلس قسم بعد.',
    'manage'     => 'إدارة المجلس',
    'created'    => 'تم تخطيط المجلس.',
    'deleted'    => 'تم حذف المجلس.',
    'delete_confirm' => 'حذف هذا المجلس ومشاركيه؟',
    'already_exists' => 'يوجد مجلس لهذا القسم وهذه الفترة.',
    'auto_title' => 'مجلس القسم :class — :period',

    // الحالات
    'status_planned'          => 'مخطط',
    'status_held'             => 'منعقد',
    'status_minutes_drafted'  => 'المحضر محرر',
    'status_validated'        => 'مصادق عليه',
    'status_planned_plural'   => 'المخططة',
    'status_held_plural'      => 'المنعقدة',
    'status_validated_plural' => 'المصادق عليها',

    // دورة الحياة
    'mark_held'        => 'وضع كمنعقد',
    'validate'         => 'المصادقة على المجلس',
    'validate_confirm' => 'المصادقة النهائية على هذا المجلس؟ لن يعود بالإمكان تعديل المحضر والمشاركين.',
    'validated_msg'    => 'تمت المصادقة على المجلس.',

    // المحضر
    'minutes'       => 'المحضر',
    'minutes_ph'    => 'القرارات، الملاحظات، التوجيهات…',
    'save_minutes'  => 'حفظ المحضر',
    'minutes_saved' => 'تم حفظ المحضر.',
    'no_minutes'    => 'لا محضر.',

    // المشاركون
    'no_participants' => 'لا مشارك بعد.',
    'add_participant' => 'إضافة مشارك',
    'role'            => 'الدور',
    'role_president'  => 'الرئيس',
    'role_secretary'  => 'الكاتب',
    'role_member'     => 'عضو',
    'present'         => 'حاضر',
    'signed'          => 'موقّع',
];
