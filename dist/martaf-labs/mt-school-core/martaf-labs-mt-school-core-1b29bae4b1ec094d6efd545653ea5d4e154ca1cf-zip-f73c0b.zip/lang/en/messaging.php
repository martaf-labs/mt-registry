<?php

return [
    'title'            => 'Messaging',
    'subtitle'         => 'Your conversations with the school.',
    'new_message'      => 'New message',
    'no_conversations' => 'No conversation.',
    'select_prompt'    => 'Select a conversation or start a new one.',
    'write_placeholder'=> 'Write a message…',
    'recipient'        => 'Recipient',
    'choose'           => '— Choose —',
    'message'          => 'Message',
];
