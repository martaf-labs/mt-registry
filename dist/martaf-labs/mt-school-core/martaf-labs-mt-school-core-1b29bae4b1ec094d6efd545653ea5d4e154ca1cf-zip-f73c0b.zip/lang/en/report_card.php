<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| Report card (report_card) — interface labels for the report card screen.
| Namespace: mtschool::  →  __('mtschool::report_card.title')
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // Title / header
    'title'                => 'Report card',
    'report_card'          => 'Report card',
    'print'                => 'Print',

    // Student identity
    'student'              => 'Student',
    'classroom'            => 'Class',
    'reference'            => 'ID number',
    'class_size'           => 'Class size',

    // Subject table columns
    'col_subject'          => 'Subject',
    'col_average'          => 'Avg.',
    'col_coefficient'      => 'Coef.',
    'col_weighted'         => 'Avg×C',
    'col_rank'             => 'Rank',
    'col_class_average'    => 'Class avg.',
    'appreciation_placeholder' => 'Assessment…',
    'no_averages'          => 'No averages. Compute the averages first.',
    'total'                => 'Total',

    // Summary
    'overall_average'      => 'Overall average',
    'rank'                 => 'Rank',
    'mention'              => 'Distinction',
    'class_average'        => 'Class avg.',
    'class_max'            => 'Highest',
    'class_min'            => 'Lowest',

    // Attendance
    'justified_absences'   => 'Justified abs.',
    'unjustified_absences' => 'Unjustified abs.',
    'tardiness'            => 'Late arrivals',

    // Council general assessment
    'council_assessment'   => 'General assessment of the council',
    'general_placeholder'  => 'General assessment (work, behaviour, advice…)',
    'distinction'          => 'Distinction',
    'save_appreciation'    => 'Save assessment',
    'appreciation_saved'   => 'Assessment saved.',
    'subject_appreciation_saved' => 'Subject assessment saved.',

    // Council distinctions
    'distinction_none'     => '— None —',
    'distinction_congratulations' => 'Congratulations',
    'distinction_encouragements'  => 'Encouragements',
    'distinction_honor_roll'      => 'Honor roll',
    'distinction_work_warning'    => 'Work warning',
    'distinction_reprimand'       => 'Reprimand',
];
