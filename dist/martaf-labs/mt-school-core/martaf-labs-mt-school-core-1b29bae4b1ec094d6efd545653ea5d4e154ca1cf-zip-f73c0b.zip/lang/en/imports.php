<?php

return [
    'title'          => 'Import / Export',
    'subtitle'       => 'Export your data or import students in bulk.',

    // Exports
    'export_section' => 'Export (CSV)',
    'export_hint'    => 'Download your data as CSV (Excel-compatible).',
    'students'       => 'Students',
    'results'        => 'Results',
    'fees'           => 'Fees',

    // Import
    'import_section' => 'Import students (CSV)',
    'columns_hint'   => 'Expected columns:',
    'columns_note'   => '(gender = M/F, birth = YYYY-MM-DD, class = class code).',
    'available_codes'=> 'Available class codes:',
    'download_template' => 'Download template',
    'col_matricule'  => 'ID',
    'col_guardian'   => 'Guardian',
    // Portal access (bulk provisioning)
    'provision_section'  => 'Portal access',
    'provision_hint'     => 'Generates login accounts for parents (guardians without an account) and downloads the list of logins + temporary passwords to hand out.',
    'provision_parents'  => 'Generate parent access',
    'provision_students' => 'Generate student access',
    'provision_confirm'  => 'Generate login accounts for all guardians without one?',
    'provision_confirm_students' => 'Generate login accounts for all students without one?',
    'parents_none'       => 'No new guardian to provision (all already have an account).',
    'students_none'      => 'No new student to provision (all already have an account).',
    'no_errors'          => 'No error rows to export.',
    'download_errors'    => 'Export :n error(s)',
    'col_errors'         => 'Errors',
    'access_login'       => 'Login',
    'access_password'    => 'Temporary password',
    // Staff import
    'staff_section'      => 'Staff import',
    'staff_hint'         => 'CSV file with columns:',
    'import_staff'       => 'Import staff',
    'staff_confirm'      => 'Import staff from this file?',
    'staff_report'       => ':imported member(s) imported, incl. :teachers teacher(s); :skipped row(s) skipped.',
    // Subjects import
    'subjects_section'   => 'Subjects import',
    'import_subjects'    => 'Import subjects',
    'subjects_report'    => ':imported subject(s) imported; :skipped skipped (missing code or already exists).',
    // Assignments import
    'assign_section'     => 'Assignments import (teacher → class → subject)',
    'assign_hint'        => 'CSV file, active year. Teacher matched by their staff email; class and subject by code. Columns:',
    'import_assignments' => 'Import assignments',
    'assign_report'      => ':imported assignment(s) created; :skipped skipped (teacher/class/subject not found or already assigned).',
    // Import history / audit log
    'history_section'    => 'Import history',
    'history_date'       => 'Date',
    'history_type'       => 'Type',
    'history_result'     => 'Result',
    'history_by'         => 'By',
    'history_skipped'    => 'skipped',
    'type_students'      => 'Students',
    'type_staff'         => 'Staff',
    'type_subjects'      => 'Subjects',
    'type_assignments'   => 'Assignments',
    'type_access_parents'  => 'Parent access',
    'type_access_students' => 'Student access',
    'reading'        => 'Reading file…',
    'valid_of'       => ':valid valid / :total row(s)',
    'change_file'    => 'Change file',

    // Preview columns
    'col_line'       => '#',
    'col_lastname'   => 'Last name',
    'col_firstname'  => 'First name',
    'col_gender'     => 'Gender',
    'col_birth'      => 'Birth',
    'col_class'      => 'Class',
    'col_status'     => 'Status',
    'status_ok'      => 'OK',
    'import_confirm' => 'Import valid rows?',
    'import_n'       => 'Import :n student(s)',

    // Messages
    'no_valid_rows'  => 'No valid row to import.',
    'imported'       => ':count student(s) imported and enrolled.',
    'import_report'  => ':imported imported, :duplicates duplicate(s) skipped, :invalid invalid row(s), :guardians guardian(s) linked.',

    // Row errors
    'err_lastname'   => 'missing last name',
    'err_firstname'  => 'missing first name',
    'err_gender'     => 'gender (M/F)',
    'err_date'       => 'invalid date',
    'err_class'      => 'unknown class',
    'csv_drop' => 'Drop your CSV file here',
    'csv_hint' => 'CSV format — ; or , separator',
];
