<?php

return [
    'title'         => 'Team & access',
    'subtitle'      => 'Create back-office accounts and assign each a role. The role determines what the person sees and can edit (finances, students, structure…).',

    'add'           => 'Add member',
    'add_title'     => 'New member',
    'edit_title'    => 'Edit member',

    'name'          => 'Full name',
    'email'         => 'Email (login)',
    'phone'         => 'Phone',
    'role'          => 'Role',
    'role_choose'   => 'Choose a role…',
    'role_hint'     => 'Vice-Principal: academics & results. Accountant: finances (+ read-only students). Staff: students, enrollments & day-to-day. Principal: full access.',
    'password'      => 'Password',
    'password_edit' => 'New password (leave blank to keep current)',

    'active'        => 'Active',
    'inactive'      => 'Disabled',
    'status'        => 'Status',
    'actions'       => 'Actions',

    'save'          => 'Save',
    'cancel'        => 'Cancel',
    'edit'          => 'Edit',
    'deactivate'    => 'Disable',
    'activate'      => 'Re-enable',

    'you'           => 'you',
    'owner'         => 'Owner',

    'created'       => 'Member created. They can now sign in with their email.',
    'updated'       => 'Member updated.',
];
