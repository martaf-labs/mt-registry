<?php

return [
    // "Missing prerequisite" messages (PrerequisiteService)
    'prereq_classes'      => 'No class exists yet. Create your classes first (Structure → Classes).',
    'prereq_classes_cta'  => 'Create classes',
    'prereq_subjects'     => 'No subject exists yet. Create your subjects first (Structure → Subjects).',
    'prereq_subjects_cta' => 'Create subjects',
    'prereq_teachers'     => 'No teacher is registered. Add your teachers first (Staff → Teachers).',
    'prereq_teachers_cta' => 'Add teachers',
    'prereq_assignments'     => 'No teacher↔class↔subject assignment exists. Make your assignments first (Staff → Assignments).',
    'prereq_assignments_cta' => 'Make assignments',
    'prereq_students'     => 'No student is registered. Add or import your students first.',
    'prereq_students_cta' => 'Add students',
    'prereq_enrollments'     => 'No student is enrolled for the active year. Enroll your students first.',
    'prereq_enrollments_cta' => 'Enroll students',
    'prereq_fee_types'     => 'No fee type is defined. Create your fee types first (Finances → Fee types).',
    'prereq_fee_types_cta' => 'Create fee types',
    'prereq_fee_schedule'     => 'The fee schedule is empty. Set the amounts per level first (Finances → Fee schedule).',
    'prereq_fee_schedule_cta' => 'Fill the schedule',
    'prereq_assessments'     => 'No assessment exists for the active year. Create your assessments first.',
    'prereq_assessments_cta' => 'Create assessments',
    'prereq_grades'     => 'No grade has been entered yet. Enter assessment grades first.',
    'prereq_grades_cta' => 'Enter grades',

    // Onboarding checklist (dashboard widget)
    'checklist_title'   => 'Getting your school ready',
    'step_classes'      => 'Create classes',
    'step_subjects'     => 'Create subjects',
    'step_teachers'     => 'Add teachers',
    'step_assignments'  => 'Assign teachers to classes',
    'step_students'     => 'Add or import students',
    'step_enrollments'  => 'Enroll students',
    'step_fee_types'    => 'Define fee types',
    'step_fee_schedule' => 'Fill the fee schedule',
    'step_assessments'  => 'Create the first assessments',
];
