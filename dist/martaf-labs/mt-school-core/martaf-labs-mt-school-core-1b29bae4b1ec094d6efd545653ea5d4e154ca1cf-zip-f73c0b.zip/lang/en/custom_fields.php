<?php

/*
| CUSTOM FIELDS domain (EAV, CustomFieldManager). Namespace mtschool::custom_fields.*
*/

return [
    'title'        => 'Custom fields',
    'subtitle'     => 'Define your own fields on your school records. Values are then entered in each form.',
    'review_guide' => 'Review the guide',
    'new_group'    => 'New group',
    'new_field'    => 'New field',

    'field_count'         => ':n field(s)',
    'confirm_delete_group'=> 'Delete this group? Its fields will be kept (ungrouped).',
    'ungrouped_fields'    => 'Ungrouped fields',
    'no_custom_fields'    => 'No custom field for this entity.',
    'create_first_field'  => 'Create the first field',
    'no_fields_here'      => 'No field here.',

    // Field (badges)
    'inactive'       => 'inactive',
    'required'       => 'required',
    'option_count'   => ':n option(s)',
    'confirm_delete_field' => 'Delete this field? Values already entered will be lost.',

    // Field modal
    'edit_field'     => 'Edit field',
    'new_field_modal'=> 'New field',
    'label_field'    => 'Label',
    'technical_key'  => 'Key (technical)',
    'key_help'       => 'Leave empty to generate it from the label.',
    'type'           => 'Type',
    'group'          => 'Group',
    'no_group'       => '— No group —',
    'options'        => 'Options',
    'add'            => 'Add',
    'option_label_ph'=> 'Option label',
    'option_value_ph'=> 'value (auto)',
    'no_options'     => 'No option. Click "Add".',
    'help_optional'  => 'Help (optional)',
    'required_toggle'=> 'Required',
    'active_toggle'  => 'Active',

    // Group modal
    'edit_group'     => 'Edit group',
    'new_group_modal'=> 'New group',
    'group_name'     => 'Group name',
    'description_optional' => 'Description (optional)',

    // Messages
    'field_updated'  => 'Field updated.',
    'field_added'    => 'Field added.',
    'field_deleted'  => 'Field deleted.',
    'group_updated'  => 'Group updated.',
    'group_added'    => 'Group added.',
    'group_deleted'  => 'Group deleted. Its fields remain (ungrouped).',
    'key_regex_error'=> 'The key must start with a letter and contain only lowercase letters, digits and "_".',
    'key_unique_error'=> 'This key is already used for this entity type.',
    'options_required_error' => 'Add at least one option for this field type.',

    // Field types (CustomFieldType enum)
    'type_text'        => 'Short text',
    'type_textarea'    => 'Long text',
    'type_number'      => 'Number',
    'type_date'        => 'Date',
    'type_email'       => 'Email',
    'type_phone'       => 'Phone',
    'type_toggle'      => 'Yes / No',
    'type_select'      => 'Dropdown list',
    'type_multiselect' => 'Multiple choice',

    // Entities (custom_fields.entities config — labels resolved at usage site)
    'entity_student'  => 'Students',
    'entity_guardian' => 'Parents / guardians',
    'entity_staff'    => 'Staff',
];
