<?php

/*
| BILLING domain (subscription purchase / renewal, pricing).
| Namespace mtschool::billing.*
*/

return [
    // ── Page titles (Livewire ->title()) ──
    'renew_title'    => 'Renew subscription',
    'checkout_title' => 'Complete your subscription',
    'pricing_title'  => 'Our plans',

    // ── Renewal (RenewComponent + renew.blade) ──
    'renew_reactivated' => 'Subscription reactivated. Welcome back!',
    'expired_heading'   => 'Subscription expired',
    'expired_intro'     => 'Access for :name is suspended. Your data is preserved — renew to reactivate the school.',
    'your_plan'         => 'Your plan',
    'per_month'         => 'month',
    'per_term'          => 'term',
    'per_year'          => 'year',
    'max_students'      => ':count students max',
    'unlimited_students'=> 'Unlimited students',
    'renew_button'      => 'Renew — :amount :currency',
    'processing'        => 'Processing…',
    'simulated_payment' => 'Simulated payment (development mode).',
    'no_plan_to_renew'  => 'No plan to renew.',
    'see_plans'         => 'View plans',
    'logout'            => 'Log out',

    // ── Checkout (Checkout + checkout.blade) ──
    'checkout_subtitle'   => 'Create your administrator account.',
    'plan_label'          => ':name plan',
    'your_name'           => 'Your name',
    'school_name_optional'=> 'School name (optional)',
    'school_name_ph'      => 'You can specify it later',
    'email'               => 'Email',
    'password'            => 'Password',
    'password_confirm'    => 'Confirm password',
    'pay_button'          => 'Pay :amount :currency (simulation)',
    'simulated_payment_long' => 'Simulated payment (development mode). No amount is charged.',
    'email_unique'        => 'An account already exists with this email.',
    'password_confirmed'  => 'The password confirmation does not match.',

    // ── Pricing (Pricing + pricing.blade) ──
    'pricing_heading'  => 'Choose your plan',
    'pricing_subtitle' => 'Manage your school, from preschool to secondary. Change plans anytime.',
    'choose_plan'      => 'Choose :name',
    'already_account'  => 'Already have an account?',
    'login'            => 'Log in',
];
