<?php

/*
| ATTENDANCE / SCHOOL LIFE domain (AttendanceManager). Namespace mtschool::attendance.*
*/

return [
    'title'         => 'Roll call / attendance',
    'subtitle'      => 'Mark each student\'s status. Saved instantly.',

    'classroom'     => 'Class',
    'date'          => 'Date',
    'day_period'    => 'Half-day',
    'period_full'   => 'Full day',
    'period_morning'=> 'Morning',
    'period_afternoon' => 'Afternoon',

    'present_count' => ':n present',
    'absent_count'  => ':n absent',
    'late_count'    => ':n late',
    'stat_present'  => 'Present',
    'stat_absent'   => 'Absent',
    'stat_late'     => 'Late',
    'mark_all_present' => 'Mark all present',
    'all_present_msg'  => 'All marked present.',

    'no_students'   => 'No student enrolled in this class.',
    'justified'     => 'justified',
    'to_justify'    => 'to justify',
    'status_present'=> 'Present',
    'status_absent' => 'Absent',
    'status_late'   => 'Late',
];
