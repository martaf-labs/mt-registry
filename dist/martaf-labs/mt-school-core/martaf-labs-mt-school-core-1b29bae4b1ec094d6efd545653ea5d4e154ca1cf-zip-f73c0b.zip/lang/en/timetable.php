<?php

/*
| TIMETABLE domain (TimetableGridManager + portals). Namespace mtschool::timetable.*
*/

return [
    'title'      => 'Timetable',
    'my_title'   => 'My timetable',
    'subtitle'   => "Click a cell to place a course there (from the class's assignments).",
    'no_assignments'   => 'No assignment for this class.',
    'assign_teachers'  => 'Assign teachers',
    'first'            => 'first.',

    'course_modal_title' => 'Course',
    'course_field'      => 'Course (assignment)',
    'empty_free_cell'   => '— Empty (free the cell) —',
    'room_optional'     => 'Room (optional)',
    'none'              => '— None —',
    'no_teacher'        => 'no teacher',
    'timetable_updated' => 'Timetable updated.',

    // Days (day_of_week 1..5)
    'day_1' => 'Monday',
    'day_2' => 'Tuesday',
    'day_3' => 'Wednesday',
    'day_4' => 'Thursday',
    'day_5' => 'Friday',
    'day_6' => 'Saturday',
    'day_7' => 'Sunday',
    'conflict_teacher' => 'Conflict: this teacher is already booked in this slot (class :class).',
    'conflict_room'    => 'Conflict: this room is already booked in this slot (class :class).',
];
