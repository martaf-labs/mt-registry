<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| Domain: documents (PDF print templates — dompdf)
| Namespace: mtschool::  →  __('mtschool::documents.report_card_title')
| Keys MUST match fr/documents.php and ar/documents.php exactly.
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // Common to both documents
    'student'   => 'Student',
    'classroom' => 'Class',
    'reference' => 'ID No.',

    // Report card
    'report_card_title'   => 'Report card',
    'annual_report_card_title' => 'Annual report card',
    'annual_average'      => 'Annual average',
    'annual_rank'         => 'Annual rank',
    'decision'            => 'Decision',
    'no_data'             => 'No data',
    'class_size'          => 'Class size',
    'subject'             => 'Subject',
    'average_short'       => 'Avg.',
    'coefficient_short'   => 'Coef.',
    'weighted_short'      => 'Avg×C',
    'rank'                => 'Rank',
    'class_average_short' => 'Cl. avg.',
    'overall_average'     => 'Overall average',
    'mention'             => 'Honours',
    'class_average'       => 'Class avg.',
    'highest'             => 'Highest',
    'lowest'              => 'Lowest',
    'council_assessment'  => 'General assessment of the board',
    'distinction'         => 'Distinction',
    'main_teacher'        => 'Form teacher',
    'head_of_school'      => 'Head of school',

    // Fee statement
    'fee_statement_title' => 'Financial statement',
    'edited_on'           => 'Issued on',
    'fees'                => 'Fees',
    'gross'               => 'Gross',
    'discount'            => 'Discount',
    'net'                 => 'Net',
    'paid'                => 'Paid',
    'remaining'           => 'Balance',
    'no_fees'             => 'No fees. Generate the fees first.',
    'total_due'           => 'Total due',
    'collected'           => 'Collected',
    'remaining_to_pay'    => 'Balance due',
    'payments'            => 'Payments',
    'date'                => 'Date',
    'payment_reference'   => 'Reference',
    'method'              => 'Method',
    'amount'              => 'Amount',

    // Payment methods
    'method_cash'          => 'Cash',
    'method_mobile_money'  => 'Mobile money',
    'method_bank_transfer' => 'Bank transfer',
    'method_check'         => 'Cheque',
    'method_card'          => 'Card',
    'method_other'         => 'Other',

    // Fee statuses
    'status_paid'      => 'Paid',
    'status_partial'   => 'Partial',
    'status_pending'   => 'Unpaid',
    'status_exempt'    => 'Exempt',
    'status_cancelled' => 'Cancelled',
    'col_type'   => 'Type',
    'col_status' => 'Status',
    'total'      => 'Total',

    // Certificates
    'school_year'           => 'School year',
    'certificates_title'    => 'Certificates',
    'certificates_subtitle' => 'Issue and download students\' official certificates.',
    'cert_type'             => 'Type',
    'cert_title_enrollment' => 'Enrollment certificate',
    'cert_title_attendance' => 'Attendance certificate',
    'cert_title_success'    => 'Certificate of achievement',
    'cert_title_leaving'    => 'Leaving certificate',
    'cert_body_enrollment'  => 'I, the undersigned Head of School, hereby certify that the student :student, born on :dob in :birthplace (ID :ref), is duly enrolled in class :class for the :year school year at our institution. This certificate is issued to serve as needed.',
    'cert_body_attendance'  => 'I, the undersigned Head of School, hereby certify that the student :student, born on :dob in :birthplace, regularly attended our institution in class :class during the :year school year. This certificate is issued to serve as needed.',
    'cert_body_success'     => 'I, the undersigned Head of School, hereby attest that the student :student, born on :dob in :birthplace, has met the end-of-year requirements in class :class for the :year school year. This certificate is issued to serve as needed.',
    'cert_body_leaving'     => 'I, the undersigned Head of School, hereby certify that the student :student, born on :dob in :birthplace, enrolled in class :class during the :year school year, has been removed from our institution\'s register as of :date. This certificate is issued to serve as needed.',
    'cert_reference'        => 'Reference',
    'cert_done_on'          => 'Done on :date',
    'cert_footer'           => 'Official document issued by the institution.',
    'cert_choose_student'   => 'Choose a student',
    'cert_type_label'       => 'Certificate type',
    'cert_issue'            => 'Issue',
    'cert_issued_ok'        => 'Certificate issued successfully.',
    'cert_issued_list'      => 'Issued certificates',
    'cert_none'             => 'No certificate issued.',
    'cert_issued_on'        => 'Issued on',
    'cert_student_required' => 'Select a student.',
];
