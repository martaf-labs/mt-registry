<?php

/*
| STUDENTS & TEACHERS domain. Namespace mtschool::students.*
*/

return [
    // ── Titles ──
    'students'      => 'Students',
    'teachers'      => 'Teachers',

    // ── Students: columns ──
    'col_student'      => 'Student',
    'boy'              => 'Boy',
    'girl'             => 'Girl',
    'col_classroom'    => 'Classroom',
    'birth_place'      => 'Birth place',
    'enrollment_col'   => 'Enrollment',
    'not_enrolled'     => 'Not enrolled',
    // Enrollment management (EnrollmentManager)
    'enrollments_title'    => 'Enrollments',
    'enrollments_subtitle' => 'Validate or reject enrollments; validating updates the class headcount.',
    'enrollments_none'     => 'No enrollment.',
    'enrollment_pending'   => 'Pending',
    'enrollment_validated' => 'Validated',
    'enrollment_validate'  => 'Validate',
    'enrollment_reject'    => 'Reject',
    'enrollment_reject_reason' => 'Rejection reason…',
    'enrollment_validated_ok'  => 'Enrollment validated, headcount updated.',
    'enrollment_rejected_ok'   => 'Enrollment rejected.',

    // ── Students: stats ──
    'stat_total_students' => 'Total students',
    'stat_enrolled_year'  => 'Enrolled :year',
    'stat_pending'        => 'Pending',

    // ── Teachers: columns ──
    'col_teacher'        => 'Teacher',
    'primary_subject'    => 'Primary subject',
    'qualified_subjects' => 'Qualified subjects',
    'subject_count'      => ':n subject(s)',
    'contract_hours'     => 'Contract hours',
    'hours_suffix'       => ':n h',

    // ── Teachers: stats ──
    'stat_teachers' => 'Teachers',

    // ── Teacher form ──
    'last_name'          => 'Last name',
    'first_name'         => 'First name',
    'title_civility'     => 'Title',
    'gender'             => 'Gender',
    'gender_m'           => 'Male',
    'gender_f'           => 'Female',
    'hire_date'          => 'Hire date',
    'email'              => 'Email',
    'phone'              => 'Phone',
    'weekly_hours'       => 'Hours/week (contract)',
    'degree'             => 'Degree',
    'specialty'          => 'Specialty',
    'teacher_active'     => 'Active teacher',
    'teacher_model_name'   => 'a teacher',
    'teacher_model_plural' => 'teachers',
    'teacher_singular'     => 'Teacher',
    'nationality'          => 'Nationality',
    'birth_date'          => 'Birth date',

    // Guardians
    'guardians'              => 'Guardians',
    'guardian_model_name'    => 'a guardian',
    'guardian_model_plural'  => 'guardians',
    'col_guardian'           => 'Guardian',

    // ── Student profile (base-show) ──
    'tab_profile'        => 'Profile',
    'tab_schooling'      => 'Schooling',
    'tab_finances'       => 'Finances',
    'identity'           => 'Identity',
    'contact_info'       => 'Contact details',
    'current_enrollment' => 'Current enrollment',
    'enrollment_date'    => 'Enrollment date',
    'enrollment_history' => 'Enrollment history',
    'no_enrollments'     => 'No enrollments.',
    'relationship'       => 'Relationship',
    'primary_contact'    => 'Primary contact',
    'no_guardians'       => 'No guardians recorded.',
    'manage_images'      => 'Manage images',
    'view_profile'       => 'View profile',

    'civility'               => 'Title',
    'guardian_photo'         => 'Guardian photo',
    'occupation'             => 'Occupation',
    'workplace'              => 'Workplace',
    'work_phone'             => 'Work phone',
    'address'                => 'Address',
    'children'               => 'Children',
    'tab_children'           => 'Children',
    'portal_account'         => 'Portal account',
    'portal_account_active'  => 'Active account',
    'portal_account_none'    => 'No account',
    'stat_total_guardians'   => 'Total guardians',
    'stat_guardian_accounts' => 'Portal accounts',
    'student_model_name'     => 'a student',

    'last_name_required' => 'The last name is required.',
    'first_name_required'=> 'The first name is required.',
    'email_unique'       => 'This email is already used by a staff member.',

    // ── EnrollmentStatus (enum) ──
    'enrollment_status_pending'     => 'Pending',
    'enrollment_status_validated'   => 'Validated',
    'enrollment_status_rejected'    => 'Rejected',
    'enrollment_status_cancelled'   => 'Cancelled',
    'enrollment_status_transferred' => 'Transferred',

    // ── EnrollmentResult (enum) ──
    'enrollment_result_admitted'    => 'Admitted',
    'enrollment_result_retained'    => 'Retained',
    'enrollment_result_promoted'    => 'Promoted',
    'enrollment_result_expelled'    => 'Expelled',
    'enrollment_result_withdrawn'   => 'Withdrawn',
    'enrollment_result_transferred' => 'Transferred',

    // Staff (cross-cutting “All staff” view)
    'col_staff_member'          => 'Staff member',
    'staff_type'                => 'Category',
    'staff_role'                => 'Role',
    'stat_staff'                => 'Staff',
    'staff_type_teacher'        => 'Teacher',
    'staff_type_administrative' => 'Administrative',
    'staff_type_technical'      => 'Technical',
    'staff_type_management'     => 'Management',

    // ── Staff profile (base-profile) ──
    'staff_photo'        => 'Member photo',
    'tab_contract'       => 'Contract',
    'position'           => 'Position',
    'grade'              => 'Grade',
    'contract_status'    => 'Contract type',
    'contract_end_date'  => 'Contract end',
    'id_card_number'     => 'ID card number',
    'emergency_phone'    => 'Emergency phone',
    'staff_account'      => 'User account',
    'account_active'     => 'Active account',
    'account_none'       => 'No account',
];
