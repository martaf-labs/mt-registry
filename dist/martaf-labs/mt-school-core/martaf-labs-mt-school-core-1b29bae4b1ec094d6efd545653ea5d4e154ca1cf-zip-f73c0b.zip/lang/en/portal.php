<?php

/*
| Parent / student / teacher portals (excluding pedagogy).
| Namespace: mtschool::  →  __('mtschool::portal.my_children')
*/

return [
    // Page titles
    'my_children'      => 'My children',
    'announcements'    => 'Announcements',
    'my_space'         => 'My space',
    'my_grades'              => 'My grades',
    'my_grades_subtitle'    => 'Your averages and subject grades, period by period.',
    'my_report_cards'       => 'My report cards',
    'my_attendance'         => 'My attendance',
    'my_attendance_subtitle'=> 'Your attendance: presences, absences and lateness.',
    'my_fees'               => 'My fees',
    'my_fees_subtitle'      => 'Your fee breakdown, payments and due dates.',
    'my_report_cards_subtitle' => 'Your published report cards.',
    'open'                  => 'Open',
    'email_footer'          => 'You are receiving this email because you have an account on the school\'s digital space.',
    'my_courses'       => 'My courses',
    'gradebook_title'  => 'Assessments & grades',

    // Parent portal — home
    'children_subtitle' => 'Follow your children\'s education: results, report cards and financial status.',
    'no_children'       => 'No child linked to your account.',
    'not_enrolled_year' => 'Not enrolled this year',
    'average'           => 'Average',
    'no_average_yet'    => 'No average yet',
    'remaining_to_pay'  => 'Remaining to pay',
    'up_to_date'        => 'Up to date',
    'report_card'       => 'Report card',
    'financial_status'  => 'Financial status',

    // Finance screen (parent portal)
    'fees_title'          => 'Tuition fees',
    'fees_subtitle'       => 'Your children\'s fee breakdown, payments and due dates.',
    'total_billed'        => 'Billed',
    'total_paid'          => 'Paid',
    'fee_type'            => 'Fee type',
    'status'              => 'Status',
    'fee_status_paid'     => 'Paid',
    'fee_status_partial'  => 'Partial',
    'fee_status_pending'  => 'Unpaid',
    'fee_status_exempt'   => 'Exempt',
    'installments'        => 'Payment schedule',
    'installment_paid'    => 'Paid',
    'installment_overdue' => 'Overdue',
    'installment_pending' => 'Upcoming',
    'payment_history'     => 'Payment history',
    'method'              => 'Method',
    'amount'              => 'Amount',
    'reference'           => 'Reference',
    'no_fees'             => 'No fees for this year.',
    'download_statement'  => 'PDF statement',

    // Follow-up screen (parent portal): attendance + sanctions
    'followup_title'      => 'Academic follow-up',
    'followup_subtitle'   => 'Your children\'s attendance and discipline.',
    'att_present'         => 'Present',
    'att_absent'          => 'Absences',
    'att_late'            => 'Late',
    'att_unjustified'     => 'Unjustified',
    'recent_events'       => 'Recent absences / lateness',
    'justified'           => 'Justified',
    'unjustified'         => 'Unjustified',
    'no_attendance'       => 'No absences or lateness recorded.',
    'sanctions'           => 'Sanctions',

    // Report cards screen (parent portal)
    'report_cards_title'    => 'Report cards',
    'report_cards_subtitle' => 'Your children\'s published report cards.',
    'published_on'          => 'Published on',
    'download'              => 'Download',
    'no_report_cards'       => 'No report card published yet.',
    'annual_report_card'    => 'Annual report card',
    'annual_average'        => 'Annual average',

    // Absence justifications (parent portal + admin)
    'justify_title'         => 'Justify an absence',
    'justify_subtitle'      => 'Submit a justification for your child\'s absence.',
    'child'                 => 'Child',
    'choose_child'          => 'Choose a child',
    'from_date'             => 'From',
    'to_date'               => 'To',
    'reason'                => 'Reason',
    'reason_illness'        => 'Illness',
    'reason_medical'        => 'Medical appointment',
    'reason_family'         => 'Family reason',
    'reason_travel'         => 'Travel',
    'reason_other'          => 'Other',
    'details'               => 'Details',
    'details_placeholder'   => 'Any details…',
    'document'              => 'Document',
    'optional'              => 'optional',
    'uploading'             => 'Uploading…',
    'submit_justification'  => 'Submit justification',
    'justify_submitted'     => 'Your justification has been submitted. It will be reviewed by the school.',
    'my_justifications'     => 'My justifications',
    'justif_pending'        => 'Pending',
    'justif_approved'       => 'Approved',
    'justif_rejected'       => 'Rejected',
    'rejection_reason'      => 'Rejection reason',
    'justify_admin_title'   => 'Absence justifications',
    'justify_admin_subtitle'=> 'Process justifications submitted by parents.',
    'no_justifications'     => 'No justifications.',
    'view_document'         => 'View document',
    'rejection_placeholder' => 'Explain the reason for rejection…',
    'confirm_reject'        => 'Confirm rejection',
    'reject'                => 'Reject',
    'approve'               => 'Approve',
    'justif_approved_ok'    => 'Justification approved, absences marked justified.',
    'justif_rejected_ok'    => 'Justification rejected.',

    // Parent portal — announcements
    'announcements_subtitle' => 'Information shared by the school.',
    'no_announcements'       => 'No announcements for now.',
    'importance_urgent'      => 'Urgent',
    'importance_important'   => 'Important',

    // Student portal — home
    'no_active_enrollment' => 'No active enrollment this year.',
    'rank'                 => 'Rank',
    'my_report_card'       => 'My report card',
    'my_timetable'         => 'My timetable',
    'results'              => 'Results',
    'col_subject'          => 'Subject',
    'col_avg'              => 'Avg.',
    'col_rank'             => 'Rank',
    'col_class_avg'        => 'Class avg.',

    // Teacher portal — home
    'courses_subtitle'  => 'Your classes and subjects. Enter the grades for your assessments.',
    'no_courses'        => 'No course is assigned to you for now.',

    // Teacher portal — gradebook
    'new_assessment'      => 'New assessment',
    'no_assessments'      => 'No assessment. Create one to enter grades.',
    'entries'             => 'entered',
    'assessment_label'    => 'Title',
    'assessment_label_ph' => 'Test 1',
    'period'              => 'Period',
    'date'                => 'Date',
    'max_score'           => 'Max score',
    'coefficient'         => 'Coefficient',
    'assessment_created'  => 'Assessment created.',

    // Validation attributes (gradebook)
    'attr_label'  => 'title',
    'attr_period' => 'period',

    // Portal account provisioning
    'create_account'        => 'Create portal access',
    'create_parent_account' => 'Create parent access',
    'create_student_account' => 'Create student access',
    'no_guardian'           => 'This student has no guardian with an email.',
    'account_created'       => 'Access created — login: :email · temporary password: :password (share it now).',
    'account_exists'        => 'This user already has portal access (:email).',
    'provision_no_email'    => 'Cannot: this profile has no email address.',
    'provision_email_taken' => 'The address :email is already used by another account.',

    // Notification center
    'notifications_title'   => 'Notifications',
    'notifications_unread'  => ':count unread',
    'mark_all_read'         => 'Mark all as read',
    'mark_read'             => 'Mark as read',
    'no_notifications'      => 'No notifications.',

    // System notifications (business sources)
    'notif_report_card_title' => 'Report card available',
    'notif_report_card_body'  => 'Your child\'s report card is published and available.',
    'notif_sanction_title'    => 'Disciplinary sanction',
    'notif_sanction_body'     => 'A sanction has been issued: :type.',
    'notif_payment_title'     => 'Payment received',
    'notif_payment_body'      => 'A payment of :amount has been recorded. Thank you.',
    'notif_absence_title'     => 'Absence reported',
    'notif_absence_body'      => 'Your child was marked absent on :date.',
];
