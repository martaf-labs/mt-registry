<?php

/*
| ENROLLMENT domain (StudentEnrollmentForm multi-step wizard).
| Namespace mtschool::enrollment.*
*/

return [
    // ── Classroom cascade ──
    'cycle'              => 'School cycle',
    'cycle_help'         => 'Only cycles with open classes are shown.',
    'level_available'    => ':n level(s) available',
    'level'              => 'Level',
    'class_count'        => ':n class(es)',
    'classroom'          => 'Class',
    'full'               => 'Full',
    'spots_available'    => ':n spot(s) available',

    // ── Existing / new student ──
    'existing_student'      => 'Already registered student (re-enrollment)',
    'existing_student_help' => 'Leave empty to create a new student in the next step.',
    'last_name'              => 'Last name',
    'first_names'            => 'First name(s)',
    'sex'                    => 'Sex',
    'sex_m'                  => 'Male',
    'sex_f'                  => 'Female',
    'birth_date'             => 'Date of birth',
    'birth_place'            => 'Place of birth',
    'nationality'            => 'Nationality',
    'birth_cert_number'      => 'Birth certificate no.',
    'repeating'              => 'Repeating',
    'repeating_label'        => 'Repeating student',
    'transferred'            => 'Transferred',
    'transferred_label'      => 'Coming from another school',
    'previous_school'        => 'Previous school',
    'previous_class'         => 'Previous class',
    'previous_year'          => 'Previous year',
    'internal_notes'         => 'Internal notes',

    // ── Existing / new guardian ──
    'existing_guardian'      => 'Already registered guardian',
    'existing_guardian_help' => 'Leave empty to create a new guardian.',
    'relationship'           => 'Relationship',
    'guardian_title'         => 'Title',
    'phone'                  => 'Phone',
    'email'                  => 'Email',
    'occupation'             => 'Occupation',
    'address'                => 'Address',
    'primary_contact'        => 'Primary contact',
    'pickup'                 => 'Pickup',
    'pickup_label'           => 'Authorized to pick up',
    'portal'                 => 'Portal',
    'portal_label'           => 'Parent portal access',

    // ── Documents ──
    'student_photo'      => "Student's photo",
    'birth_certificate'  => 'Birth certificate (PDF or image)',
    'previous_report_card' => "Previous year's report card",
    'other_document_opt' => 'Other document (optional)',

    // ── Enrollment ──
    'enrollment_date'    => 'Enrollment date',
    'notes'              => 'Notes',

    // ── Validation messages ──
    'select_cycle'         => 'Select a cycle.',
    'select_level'         => 'Select a level.',
    'select_class'         => 'Select a class.',
    'last_name_required'   => 'The last name is required.',
    'first_name_required'  => 'The first name is required.',
    'sex_required'         => 'The sex is required.',
    'birth_date_required'  => 'The date of birth is required.',
    'birth_date_before'    => 'The date of birth must be in the past.',
    'birth_date_after'     => 'Invalid age (> 30 years).',
    'birth_place_required' => 'The place of birth is required.',
    'nationality_required' => 'The nationality is required.',
    'relationship_required'=> 'Indicate the relationship.',
    'guardian_last_name_required'  => "The guardian's last name is required.",
    'guardian_first_name_required' => "The guardian's first name is required.",
    'guardian_phone_required'      => 'The phone number is required.',

    // ── Relationship (enum) ──
    'relationship_father'      => 'Father',
    'relationship_mother'      => 'Mother',
    'relationship_guardian'    => 'Legal guardian',
    'relationship_grandparent' => 'Grandparent',
    'relationship_sibling'     => 'Sibling',
    'relationship_aunt_uncle'  => 'Aunt / Uncle',
    'relationship_other'       => 'Other',

    // ── Wizard steps (titles + descriptions) ──
    'step_cycle_title'        => 'Cycle',
    'step_cycle_desc'         => "Student's school cycle",
    'step_level_title'        => 'Level',
    'step_level_desc'         => 'Level within the cycle',
    'step_class_title'        => 'Class',
    'step_class_desc'         => 'Assigned class',
    'step_student_title'      => 'Student',
    'step_student_desc'       => 'Re-enroll an existing student',
    'step_new_student_title'  => 'New student',
    'step_new_student_desc'   => 'Student information',
    'step_guardian_title'     => 'Guardian',
    'step_guardian_desc'      => 'Existing guardian + relationship',
    'step_new_guardian_title' => 'New guardian',
    'step_new_guardian_desc'  => 'Guardian information',
    'step_documents_title'    => 'Documents',
    'step_documents_desc'     => 'Attachments (optional)',
    'step_finalize_title'     => 'Enrollment',
    'step_finalize_desc'      => 'Finalize (created as pending)',

    // ── Form wrapper (nav/model/errors) ──
    'model_name'          => 'an enrollment',
    'model_name_plural'   => 'enrollments',
    'nav_students'        => 'Students',
    'nav_enroll'          => 'Enroll',
    'nav_edit'            => 'Edit',
    'no_open_class_error' => 'No open class for the active year. Create at least one class before enrolling a student.',
];
