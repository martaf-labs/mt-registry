<?php

/*
| DASHBOARD domain (principal). Namespace mtschool::dashboard.*
*/

return [
    'title'            => 'Dashboard',
    'subtitle_year'    => 'School year :year',
    'subtitle_default' => 'Overview of the school',

    // Quick actions
    'new_student'      => 'New student',
    'enrollments'      => 'Enrolments',

    // Stat cards
    'enrolled'         => 'Enrolled students',
    'collection_rate'  => 'Collection',
    'school_average'   => 'School average',
    'attendance'       => 'Attendance',
    'teachers'         => 'Teachers',
    'classes'          => 'Classes',
    'collected'        => 'Collected',
    'remaining'        => 'Remaining',
    'period'           => 'Term',
    'unjustified_abs'  => 'Unjustified abs.',

    // Widgets
    'enrollment_by_level' => 'Enrolment by level',
    'students_dataset'    => 'Students',
    'your_plan'           => 'Your plan',
    'collection_by_level' => 'Collection by level',
    'class_ranking'       => 'Class ranking',
    'students_count'      => ':n student(s)',

    // "Your plan" widget
    'plan_valid_until'  => 'Valid until',
    'plan_quota'        => 'Student quota',
    'plan_unlimited'    => 'Unlimited',
    'plan_modules'      => 'Active modules',

    // ── Band 1 · Action queues ─────────────────────────────────────────────
    'pending_enrollments_title' => 'Enrollments to validate',
    'pending_count'             => ':n file(s) pending',
    'badge_pending'             => 'Pending',
    'process_enrollment'        => 'Process',
    'pending_justifications'    => 'Absence justifications',
    'justifications_count'      => ':n to review',
    'justif_attachment'         => 'Doc',
    'reportcards_title'         => 'Period report cards',
    'reportcards_published'     => 'Published',
    'reportcards_to_publish'    => 'To publish',
    'reportcards_to_validate'   => 'To validate',
    'installments_title'        => 'Fee installments',
    'overdue_amount'            => 'Overdue',
    'due_soon_30d'              => 'Due (30 d)',
    'installments_count'        => ':n installment(s)',

    // ── Band 2 · Trends ────────────────────────────────────────────────────
    'collection_trend'          => 'Collection trend (12 months)',
    'collected_dataset'         => 'Collected',
    'average_trend_title'       => 'School average trend',
    'average_trend_dataset'     => 'Average',
    'absence_trend'             => 'Absences & lateness (14 days)',
    'absences_dataset'          => 'Absences',
    'late_dataset'              => 'Lateness',

    // ── Band 3 · Structure & distribution ──────────────────────────────────
    'class_fill_rate_title'     => 'Class fill rate',
    'overcrowded'               => ':n% · overcrowded',
    'grade_distribution_title'  => 'Grade distribution',
    'grade_band_below10'        => 'Below 10',
    'grade_band_10_12'          => '10 to 12',
    'grade_band_12_14'          => '12 to 14',
    'grade_band_14_16'          => '14 to 16',
    'grade_band_16_plus'        => '16 and above',
    'gender_split_title'        => 'Girls / boys',
    'girls'                     => 'Girls',
    'boys'                      => 'Boys',
    'parity_index'              => ':n% girls',

    // ── Band 4 · Targeting ─────────────────────────────────────────────────
    'classes_to_chase'          => 'Classes to chase',
    'overdue_installments_count' => ':n overdue installment(s)',
    'weakest_subjects_title'    => 'Weakest subjects',
    'top_absentees'             => 'Most-absent students',
    'absences_short'            => ':n abs.',

    // ── Band 5 · School life ───────────────────────────────────────────────
    'activity_feed'             => 'Recent activity',
    'activity_new_enrollment'   => 'New enrollment: :name',
    'activity_payment_received' => 'Payment of :amount received',
    'activity_announcement'     => 'Announcement: :title',
    'upcoming_events'           => 'Upcoming events',
    'event_all_day'             => 'All day',
    'class_councils'            => 'Class councils',
    'council_planned'           => 'Planned',
    'council_to_validate'       => 'Minutes to validate',
    'recent_sanctions'          => 'Recent sanctions',
    'parent_not_notified'       => 'Parent not notified',
];
