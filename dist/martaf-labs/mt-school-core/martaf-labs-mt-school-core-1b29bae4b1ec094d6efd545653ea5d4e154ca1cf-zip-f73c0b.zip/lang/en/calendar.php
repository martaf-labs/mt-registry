<?php

return [
    'title'        => 'Calendar',
    'subtitle'     => 'Upcoming school events.',
    'new_event'    => 'New event',
    'no_events'    => 'No upcoming event.',
    'all_day'      => 'All day',

    // Event types
    'type_event'   => 'Event',
    'type_meeting' => 'Meeting',
    'type_exam'    => 'Exam',
    'type_holiday' => 'Holiday',
    'type_other'   => 'Other',

    // Modal
    'title_field'  => 'Title',
    'title_ph'     => 'Parent-teacher meeting',
    'type'         => 'Type',
    'start'        => 'Start',
    'end'          => 'End',
    'location'     => 'Location',
    'location_ph'  => 'Multipurpose room',

    // Messages
    'event_added'   => 'Event added to the calendar.',
    'event_deleted' => 'Event deleted.',
];
