<?php

return [
    'title'                 => 'Settings',
    'subtitle'              => 'Your school\'s preferences (applied across the whole school).',

    // Notifications
    'notifications_section' => 'Notifications',
    'notify_email'          => 'Also send notifications by email',
    'notify_email_hint'     => 'In addition to in-app notifications, sends an email to parents/students/staff (requires a configured mail server).',

    // Grading
    'grading_section'       => 'Grading',
    'grading_hint'          => 'Scale used for averages, honours and promotion decisions.',
    'passing_score'         => 'Passing score',
    'max_score'             => 'Maximum score',

    'saved'                 => 'Settings saved.',
];
