<?php

/*
| Shared UI strings (verbs, statuses, recurring labels).
| Namespace: mtschool::  →  __('mtschool::common.save')
*/

return [
    // Actions
    'save'        => 'Save',
    'all'         => 'All',
    'cancel'      => 'Cancel',
    'delete'      => 'Delete',
    'edit'        => 'Edit',
    'create'      => 'Create',
    'add'         => 'Add',
    'new_m'       => 'New',
    'new_f'       => 'New',
    'send'        => 'Send',
    'publish'     => 'Publish',
    'unpublish'   => 'Unpublish',
    'back'        => 'Back',
    'download'    => 'Download',
    'open'        => 'Open',
    'analyze'     => 'Analyze',
    'import'      => 'Import',
    'export'      => 'Export',

    // Statuses
    'published'   => 'Published',
    'published_f' => 'Published',
    'draft'       => 'Draft',
    'active'      => 'Active',

    // Statuses (gender-neutral in English, both keys map to the same word)
    'active_m'    => 'Active',
    'active_f'    => 'Active',
    'inactive_m'  => 'Inactive',
    'inactive_f'  => 'Inactive',
    'status'      => 'Status',
    'total'       => 'Total',
    'yes'         => 'Yes',
    'no'          => 'No',
    'code'        => 'Code',
    'label'       => 'Label',
    'description' => 'Description',
    'order'       => 'Order',
    'color'       => 'Color',
    'icon'        => 'Icon',
    'type'        => 'Type',

    // Validation messages (dates)
    'date_start_required' => 'The start date is required.',
    'date_end_required'   => 'The end date is required.',
    'date_end_after'      => 'The end date must be after the start date.',

    // Misc
    'loading'     => 'Loading…',
    'none'        => 'None',
    'search'      => 'Search',
    'confirm_delete' => 'Confirm deletion?',
    'students'    => 'student(s)',
    'view'        => 'View',
    'action'      => 'Action',
    'actions'     => 'Actions',
];
