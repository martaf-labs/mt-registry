<?php

/*
| Initial configuration wizard. Namespace mtschool::setup.*
*/

return [
    'title' => 'Initial configuration',

    // Header
    'header_subtitle' => "Let's configure your school in a few simple steps",

    // Progress bar
    'step_of' => 'Step :current of :total',

    // Steps (title + description)
    'step1_title'       => 'Welcome',
    'step1_description'  => "Let's configure your school in a few steps.",
    'step2_title'       => 'School',
    'step2_description'  => 'Enter the name of your institution.',
    'step3_title'       => 'School year',
    'step3_description'  => 'Set the first active school year.',
    'step4_title'       => 'Languages',
    'step4_description'  => 'Choose the languages of instruction.',
    'step5_title'       => 'Cycle',
    'step5_description'  => 'Choose the type of school cycle.',
    'step6_title'       => 'Levels',
    'step6_description'  => 'Select the levels to create.',

    // ── Step 1: Welcome ──
    'welcome_intro_before' => 'Welcome to',
    'welcome_intro_after'  => '! Before accessing the application, we will configure the basic elements of your institution.',
    'feature_school_year'  => 'Active school year',
    'feature_languages'    => 'Languages of instruction',
    'feature_cycle'        => 'School cycle',
    'feature_first_level'  => 'First level',
    'welcome_note_before'  => 'This information is',
    'welcome_note_bold'    => 'required',
    'welcome_note_after'   => 'for the application to work properly. You can complete or edit it later.',

    // ── Step 2: School ──
    'school_intro_before'  => 'Enter the name of your institution. You can add the logo and other information later under',
    'school_intro_bold'    => 'Settings → Institution',
    'school_intro_after'   => '.',
    'school_full_name'     => 'Full name of the institution',
    'school_name_placeholder'  => 'Name (:lang)',
    'school_short_name'    => 'Acronym / short name (optional)',
    'school_short_placeholder' => 'Acronym (:lang)',

    // ── Step 3: School year ──
    'school_year'          => 'School year',
    'school_year_prefix'   => 'School year',
    'start_date'           => 'Start date',
    'end_date'             => 'End date',
    'year_note_before'     => 'The code and label are generated automatically. The dates can be adjusted if needed. This year will be set as',
    'year_note_bold'       => 'active',
    'year_note_after'      => '.',

    // ── Step 4: Languages ──
    'languages_note'       => 'The selected languages will drive the subjects, report cards and reports.',

    // ── Step 5: Cycle ──
    'levels_proposed'      => ':count levels proposed',
    'cycle_note_before'    => 'You can create other cycles from',
    'cycle_note_bold'      => 'Structure → Cycles',
    'cycle_note_after'     => '.',

    // ── Step 6: Levels ──
    'levels_selected'      => ':count level(s) selected.',
    'prefill_title'        => 'Prefill with reference data',
    'prefill_hint'         => 'Creates the cycle\'s standard subjects, one class and one curriculum (with coefficients) per level. You can adjust everything afterwards.',
    'levels_note_before'   => 'You can add more from',
    'levels_note_bold'     => 'Structure → Levels',
    'levels_note_after'    => '.',

    // ── Navigation ──
    'previous'             => 'Previous',
    'start'               => 'Get started',
    'next'                => 'Next',
    'complete'            => 'Finish configuration',

    // Footer
    'footer' => 'MT School — Required configuration',

    // ── Validation messages ──
    'sc_name_required'    => 'The name of the institution is required.',
    'sc_name_fr_required' => 'The name in French is required.',
    'sy_start_year_required' => 'Please select a school year.',
    'sy_start_date_required' => 'The start date is required.',
    'sy_end_date_required'   => 'The end date is required.',
    'sy_end_date_after'      => 'The end date must be after the start date.',
    'teaching_languages_required' => 'Select at least one language.',
    'teaching_languages_min'      => 'Select at least one language.',
    'cycle_type_required' => 'Please select a cycle type.',
    'cycle_type_in'       => 'Invalid cycle type.',
    'grade_levels_required' => 'Select at least one level.',
    'grade_levels_min'      => 'Select at least one level.',

    // Automatic school year (setup)
    'sy_auto_hint'       => 'Determined automatically from today\'s date — adjust the start and end dates if needed.',
    'sy_next_years_hint' => 'Subsequent years are created from Structure → New year (student promotion and balance carry-over).',

    'sy_start_in_year'   => 'The start date must be within :year.',
    'sy_end_in_year'     => 'The end date must be no later than :year.',
    'sy_max_duration'    => 'The school year cannot exceed 12 months.',

    // Multi-cycle (school complex)
    'cycles_multi_hint'  => 'Select every cycle your institution offers — a school complex can combine several (preschool + primary + secondary…).',
    'levels_per_cycle'   => 'The ":cycle" cycle must keep at least one level (or uncheck it at the previous step).',

    'cycles_limited_note' => 'Cycles not listed here will be offered soon.',

    'completing_hint' => 'Setting up your school (levels, classes, subjects, curricula)… This can take a few minutes — please keep this page open.',
];
