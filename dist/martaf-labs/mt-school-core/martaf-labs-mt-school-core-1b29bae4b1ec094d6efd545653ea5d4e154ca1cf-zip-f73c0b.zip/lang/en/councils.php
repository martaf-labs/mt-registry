<?php

/*
|--------------------------------------------------------------------------
| Class councils (admin screen ClassCouncilManager)
|--------------------------------------------------------------------------
*/

return [
    'title'      => 'Class councils',
    'subtitle'   => 'Plan councils, draft the minutes and validate decisions.',
    'plan'       => 'Plan a council',
    'plan_submit' => 'Plan',
    'period'     => 'Period',
    'all_periods' => 'All periods',
    'date'       => 'Date and time',
    'location'   => 'Location',
    'location_ph' => 'Teachers\' room…',
    'participants' => 'Participants',
    'none'       => 'No class council yet.',
    'manage'     => 'Manage the council',
    'created'    => 'Council planned.',
    'deleted'    => 'Council deleted.',
    'delete_confirm' => 'Delete this council and its participants?',
    'already_exists' => 'A council already exists for this class and period.',
    'auto_title' => 'Class council :class — :period',

    // Statuses
    'status_planned'          => 'Planned',
    'status_held'             => 'Held',
    'status_minutes_drafted'  => 'Minutes drafted',
    'status_validated'        => 'Validated',
    'status_planned_plural'   => 'Planned',
    'status_held_plural'      => 'Held',
    'status_validated_plural' => 'Validated',

    // Lifecycle
    'mark_held'        => 'Mark as held',
    'validate'         => 'Validate the council',
    'validate_confirm' => 'Permanently validate this council? Minutes and participants will no longer be editable.',
    'validated_msg'    => 'Council validated.',

    // Minutes
    'minutes'       => 'Minutes',
    'minutes_ph'    => 'Decisions, observations, orientations…',
    'save_minutes'  => 'Save minutes',
    'minutes_saved' => 'Minutes saved.',
    'no_minutes'    => 'No minutes.',

    // Participants
    'no_participants' => 'No participant yet.',
    'add_participant' => 'Add a participant',
    'role'            => 'Role',
    'role_president'  => 'President',
    'role_secretary'  => 'Secretary',
    'role_member'     => 'Member',
    'present'         => 'Present',
    'signed'          => 'Signed',
];
