<?php

return [
    // Messages « prérequis manquant » (PrerequisiteService)
    'prereq_classes'      => "Aucune classe n'existe encore. Créez d'abord vos classes (Structure → Classes).",
    'prereq_classes_cta'  => 'Créer les classes',
    'prereq_subjects'     => "Aucune matière n'existe encore. Créez d'abord vos matières (Structure → Matières).",
    'prereq_subjects_cta' => 'Créer les matières',
    'prereq_teachers'     => "Aucun enseignant n'est enregistré. Ajoutez d'abord vos enseignants (Personnel → Enseignants).",
    'prereq_teachers_cta' => 'Ajouter les enseignants',
    'prereq_assignments'     => "Aucune affectation enseignant↔classe↔matière n'existe. Faites d'abord vos affectations (Personnel → Attributions).",
    'prereq_assignments_cta' => 'Faire les affectations',
    'prereq_students'     => "Aucun élève n'est enregistré. Ajoutez ou importez d'abord vos élèves.",
    'prereq_students_cta' => 'Ajouter les élèves',
    'prereq_enrollments'     => "Aucun élève n'est inscrit pour l'année active. Inscrivez d'abord vos élèves.",
    'prereq_enrollments_cta' => 'Inscrire les élèves',
    'prereq_fee_types'     => "Aucun type de frais n'est défini. Créez d'abord vos types de frais (Finances → Types de frais).",
    'prereq_fee_types_cta' => 'Créer les types de frais',
    'prereq_fee_schedule'     => "La grille tarifaire est vide. Définissez d'abord les montants par niveau (Finances → Grille tarifaire).",
    'prereq_fee_schedule_cta' => 'Remplir la grille',
    'prereq_assessments'     => "Aucune évaluation n'existe pour l'année active. Créez d'abord vos évaluations.",
    'prereq_assessments_cta' => 'Créer les évaluations',
    'prereq_grades'     => "Aucune note n'a encore été saisie. Saisissez d'abord les notes des évaluations.",
    'prereq_grades_cta' => 'Saisir les notes',

    // Checklist de démarrage (widget dashboard)
    'checklist_title'   => 'Mise en route de votre école',
    'step_classes'      => 'Créer les classes',
    'step_subjects'     => 'Créer les matières',
    'step_teachers'     => 'Ajouter les enseignants',
    'step_assignments'  => 'Affecter les enseignants aux classes',
    'step_students'     => 'Ajouter ou importer les élèves',
    'step_enrollments'  => 'Inscrire les élèves',
    'step_fee_types'    => 'Définir les types de frais',
    'step_fee_schedule' => 'Remplir la grille tarifaire',
    'step_assessments'  => 'Créer les premières évaluations',
];
