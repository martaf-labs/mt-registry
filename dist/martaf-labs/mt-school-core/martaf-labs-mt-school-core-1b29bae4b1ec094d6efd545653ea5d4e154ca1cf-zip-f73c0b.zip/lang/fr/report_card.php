<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| Bulletin de notes (report_card) — libellés d'interface de l'écran bulletin.
| Namespace : mtschool::  →  __('mtschool::report_card.title')
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // Titre / en-tête
    'title'                => 'Bulletin',
    'report_card'          => 'Bulletin de notes',
    'print'                => 'Imprimer',

    // Identité élève
    'student'              => 'Élève',
    'classroom'            => 'Classe',
    'reference'            => 'Matricule',
    'class_size'           => 'Effectif',

    // Colonnes du tableau des matières
    'col_subject'          => 'Matière',
    'col_average'          => 'Moy.',
    'col_coefficient'      => 'Coef.',
    'col_weighted'         => 'Moy×C',
    'col_rank'             => 'Rang',
    'col_class_average'    => 'Moy. cl.',
    'appreciation_placeholder' => 'Appréciation…',
    'no_averages'          => 'Aucune moyenne. Calculez les moyennes d’abord.',
    'total'                => 'Total',

    // Synthèse
    'overall_average'      => 'Moyenne générale',
    'rank'                 => 'Rang',
    'mention'              => 'Mention',
    'class_average'        => 'Moy. classe',
    'class_max'            => 'Plus forte',
    'class_min'            => 'Plus faible',

    // Assiduité
    'justified_absences'   => 'Abs. justifiées',
    'unjustified_absences' => 'Abs. injustifiées',
    'tardiness'            => 'Retards',

    // Appréciation générale du conseil
    'council_assessment'   => 'Appréciation générale du conseil',
    'general_placeholder'  => 'Appréciation générale (travail, comportement, conseils…)',
    'distinction'          => 'Distinction',
    'save_appreciation'    => 'Enregistrer l’appréciation',
    'appreciation_saved'   => 'Appréciation enregistrée.',
    'subject_appreciation_saved' => 'Appréciation matière enregistrée.',

    // Distinctions du conseil
    'distinction_none'     => '— Aucune —',
    'distinction_congratulations' => 'Félicitations',
    'distinction_encouragements'  => 'Encouragements',
    'distinction_honor_roll'      => 'Tableau d’honneur',
    'distinction_work_warning'    => 'Avertissement travail',
    'distinction_reprimand'       => 'Blâme',
];
