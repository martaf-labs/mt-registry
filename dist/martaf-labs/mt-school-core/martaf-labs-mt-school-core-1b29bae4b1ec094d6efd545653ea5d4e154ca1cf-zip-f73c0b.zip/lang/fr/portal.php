<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| Portails parent / élève / enseignant (hors pédagogie).
| Namespace : mtschool::  →  __('mtschool::portal.my_children')
| fr = référence. Ne pas traduire les données (matières, noms, moyennes…).
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // Titres de page
    'my_children'      => 'Mes enfants',
    'announcements'    => 'Annonces',
    'my_space'         => 'Mon espace',
    'my_grades'              => 'Mes notes',
    'my_grades_subtitle'    => 'Vos moyennes et notes par matière, période par période.',
    'my_report_cards'       => 'Mes bulletins',
    'my_attendance'         => 'Mes présences',
    'my_attendance_subtitle'=> 'Votre assiduité : présences, absences et retards.',
    'my_fees'               => 'Mes frais',
    'my_fees_subtitle'      => 'Le détail de vos frais, paiements et échéances.',
    'my_report_cards_subtitle' => 'Vos bulletins publiés.',
    'open'                  => 'Ouvrir',
    'email_footer'          => 'Vous recevez cet e-mail car vous avez un compte sur l\'espace numérique de l\'établissement.',
    'my_courses'       => 'Mes cours',
    'gradebook_title'  => 'Évaluations & notes',

    // Portail parent — accueil
    'children_subtitle' => 'Suivez la scolarité de vos enfants : résultats, bulletins et situation financière.',
    'no_children'       => 'Aucun enfant rattaché à votre compte.',
    'not_enrolled_year' => 'Non inscrit cette année',
    'average'           => 'Moyenne',
    'no_average_yet'    => 'Pas encore de moyenne',
    'remaining_to_pay'  => 'Reste à payer',
    'up_to_date'        => 'À jour',
    'report_card'       => 'Bulletin',
    'financial_status'  => 'Situation financière',

    // Écran finances (portail parent)
    'fees_title'          => 'Frais de scolarité',
    'fees_subtitle'       => 'Le détail des frais, paiements et échéances de vos enfants.',
    'total_billed'        => 'Facturé',
    'total_paid'          => 'Payé',
    'fee_type'            => 'Type de frais',
    'status'              => 'Statut',
    'fee_status_paid'     => 'Soldé',
    'fee_status_partial'  => 'Partiel',
    'fee_status_pending'  => 'Impayé',
    'fee_status_exempt'   => 'Exonéré',
    'installments'        => 'Échéancier',
    'installment_paid'    => 'Payée',
    'installment_overdue' => 'En retard',
    'installment_pending' => 'À venir',
    'payment_history'     => 'Historique des paiements',
    'method'              => 'Mode',
    'amount'              => 'Montant',
    'reference'           => 'Référence',
    'no_fees'             => 'Aucun frais pour cette année.',
    'download_statement'  => 'Relevé PDF',

    // Écran suivi (portail parent) : assiduité + sanctions
    'followup_title'      => 'Suivi scolaire',
    'followup_subtitle'   => 'L\'assiduité et la discipline de vos enfants.',
    'att_present'         => 'Présences',
    'att_absent'          => 'Absences',
    'att_late'            => 'Retards',
    'att_unjustified'     => 'Non justifiées',
    'recent_events'       => 'Dernières absences / retards',
    'justified'           => 'Justifiée',
    'unjustified'         => 'Non justifiée',
    'no_attendance'       => 'Aucune absence ni retard enregistré.',
    'sanctions'           => 'Sanctions',

    // Écran bulletins (portail parent)
    'report_cards_title'    => 'Bulletins',
    'report_cards_subtitle' => 'Les bulletins publiés de vos enfants.',
    'published_on'          => 'Publié le',
    'download'              => 'Télécharger',
    'no_report_cards'       => 'Aucun bulletin publié pour l\'instant.',
    'annual_report_card'    => 'Bulletin annuel',
    'annual_average'        => 'Moyenne annuelle',

    // Justificatifs d'absence (portail parent + admin)
    'justify_title'         => 'Justifier une absence',
    'justify_subtitle'      => 'Déposez un justificatif pour une absence de votre enfant.',
    'child'                 => 'Enfant',
    'choose_child'          => 'Choisir un enfant',
    'from_date'             => 'Du',
    'to_date'               => 'Au',
    'reason'                => 'Motif',
    'reason_illness'        => 'Maladie',
    'reason_medical'        => 'Rendez-vous médical',
    'reason_family'         => 'Raison familiale',
    'reason_travel'         => 'Voyage',
    'reason_other'          => 'Autre',
    'details'               => 'Précisions',
    'details_placeholder'   => 'Détails éventuels…',
    'document'              => 'Document',
    'optional'              => 'facultatif',
    'uploading'             => 'Envoi…',
    'submit_justification'  => 'Envoyer le justificatif',
    'justify_submitted'     => 'Votre justificatif a été envoyé. Il sera examiné par l\'établissement.',
    'my_justifications'     => 'Mes justificatifs',
    'justif_pending'        => 'En attente',
    'justif_approved'       => 'Approuvé',
    'justif_rejected'       => 'Refusé',
    'rejection_reason'      => 'Motif du refus',
    'justify_admin_title'   => 'Justificatifs d\'absence',
    'justify_admin_subtitle'=> 'Traitez les justificatifs déposés par les parents.',
    'no_justifications'     => 'Aucun justificatif.',
    'view_document'         => 'Voir le document',
    'rejection_placeholder' => 'Expliquez le motif du refus…',
    'confirm_reject'        => 'Confirmer le refus',
    'reject'                => 'Refuser',
    'approve'               => 'Approuver',
    'justif_approved_ok'    => 'Justificatif approuvé, absences marquées justifiées.',
    'justif_rejected_ok'    => 'Justificatif refusé.',

    // Portail parent — annonces
    'announcements_subtitle' => 'Les informations communiquées par l\'établissement.',
    'no_announcements'       => 'Aucune annonce pour le moment.',
    'importance_urgent'      => 'Urgent',
    'importance_important'   => 'Important',

    // Portail élève — accueil
    'no_active_enrollment' => 'Aucune inscription active cette année.',
    'rank'                 => 'Rang',
    'my_report_card'       => 'Mon bulletin',
    'my_timetable'         => 'Mon emploi du temps',
    'results'              => 'Résultats',
    'col_subject'          => 'Matière',
    'col_avg'              => 'Moy.',
    'col_rank'             => 'Rang',
    'col_class_avg'        => 'Moy. cl.',

    // Portail enseignant — accueil
    'courses_subtitle'  => 'Vos classes et matières. Saisissez les notes de vos évaluations.',
    'no_courses'        => 'Aucun cours ne vous est affecté pour le moment.',

    // Portail enseignant — carnet de notes
    'new_assessment'      => 'Nouvelle évaluation',
    'no_assessments'      => 'Aucune évaluation. Créez-en une pour saisir les notes.',
    'entries'             => 'saisies',
    'assessment_label'    => 'Intitulé',
    'assessment_label_ph' => 'Devoir 1',
    'period'              => 'Période',
    'date'                => 'Date',
    'max_score'           => 'Note max',
    'coefficient'         => 'Coefficient',
    'assessment_created'  => 'Évaluation créée.',

    // Attributs de validation (carnet de notes)
    'attr_label'  => 'intitulé',
    'attr_period' => 'période',

    // Provision de comptes portail
    'create_account'        => 'Créer un accès portail',
    'create_parent_account' => 'Créer un accès parent',
    'create_student_account' => 'Créer un accès élève',
    'no_guardian'           => 'Cet élève n\'a pas de tuteur avec e-mail.',
    'account_created'       => 'Accès créé — identifiant : :email · mot de passe provisoire : :password (à communiquer maintenant).',
    'account_exists'        => 'Cet utilisateur a déjà un accès portail (:email).',
    'provision_no_email'    => 'Impossible : ce profil n\'a pas d\'adresse e-mail.',
    'provision_email_taken' => 'L\'adresse :email est déjà utilisée par un autre compte.',

    // Centre de notifications
    'notifications_title'   => 'Notifications',
    'notifications_unread'  => ':count non lue(s)',
    'mark_all_read'         => 'Tout marquer comme lu',
    'mark_read'             => 'Marquer comme lu',
    'no_notifications'      => 'Aucune notification.',

    // Notifications système (sources métier)
    'notif_report_card_title' => 'Bulletin disponible',
    'notif_report_card_body'  => 'Le bulletin de votre enfant est publié et consultable.',
    'notif_sanction_title'    => 'Sanction disciplinaire',
    'notif_sanction_body'     => 'Une sanction a été émise : :type.',
    'notif_payment_title'     => 'Paiement reçu',
    'notif_payment_body'      => 'Un paiement de :amount a bien été enregistré. Merci.',
    'notif_absence_title'     => 'Absence signalée',
    'notif_absence_body'      => 'Votre enfant a été noté absent le :date.',
];
