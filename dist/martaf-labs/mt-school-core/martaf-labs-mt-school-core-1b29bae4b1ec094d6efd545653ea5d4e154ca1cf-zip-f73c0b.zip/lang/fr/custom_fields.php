<?php

/*
| Domaine CHAMPS PERSONNALISÉS (EAV, CustomFieldManager). Namespace mtschool::custom_fields.*
*/

return [
    'title'        => 'Champs personnalisés',
    'subtitle'     => 'Définissez vos propres champs sur les fiches de votre école. Les valeurs se saisissent ensuite dans chaque formulaire.',
    'review_guide' => 'Revoir le guide',
    'new_group'    => 'Nouveau groupe',
    'new_field'    => 'Nouveau champ',

    'field_count'         => ':n champ(s)',
    'confirm_delete_group'=> 'Supprimer ce groupe ? Ses champs seront conservés (sans groupe).',
    'ungrouped_fields'    => 'Champs sans groupe',
    'no_custom_fields'    => 'Aucun champ personnalisé pour cette entité.',
    'create_first_field'  => 'Créer le premier champ',
    'no_fields_here'      => 'Aucun champ ici.',

    // Champ (badges)
    'inactive'       => 'inactif',
    'required'       => 'requis',
    'option_count'   => ':n option(s)',
    'confirm_delete_field' => 'Supprimer ce champ ? Les valeurs déjà saisies seront perdues.',

    // Modale champ
    'edit_field'     => 'Modifier le champ',
    'new_field_modal'=> 'Nouveau champ',
    'label_field'    => 'Libellé',
    'technical_key'  => 'Clé (technique)',
    'key_help'       => 'Laisser vide pour la générer depuis le libellé.',
    'type'           => 'Type',
    'group'          => 'Groupe',
    'no_group'       => '— Sans groupe —',
    'options'        => 'Options',
    'add'            => 'Ajouter',
    'option_label_ph'=> "Libellé de l'option",
    'option_value_ph'=> 'valeur (auto)',
    'no_options'     => 'Aucune option. Cliquez sur « Ajouter ».',
    'help_optional'  => 'Aide (facultatif)',
    'required_toggle'=> 'Obligatoire',
    'active_toggle'  => 'Actif',

    // Modale groupe
    'edit_group'     => 'Modifier le groupe',
    'new_group_modal'=> 'Nouveau groupe',
    'group_name'     => 'Nom du groupe',
    'description_optional' => 'Description (facultatif)',

    // Messages
    'field_updated'  => 'Champ modifié.',
    'field_added'    => 'Champ ajouté.',
    'field_deleted'  => 'Champ supprimé.',
    'group_updated'  => 'Groupe modifié.',
    'group_added'    => 'Groupe ajouté.',
    'group_deleted'  => 'Groupe supprimé. Ses champs restent (sans groupe).',
    'key_regex_error'=> 'La clé doit commencer par une lettre et ne contenir que minuscules, chiffres et « _ ».',
    'key_unique_error'=> "Cette clé est déjà utilisée pour ce type d'entité.",
    'options_required_error' => 'Ajoutez au moins une option pour ce type de champ.',

    // Types de champ (enum CustomFieldType)
    'type_text'        => 'Texte court',
    'type_textarea'    => 'Texte long',
    'type_number'      => 'Nombre',
    'type_date'        => 'Date',
    'type_email'       => 'E-mail',
    'type_phone'       => 'Téléphone',
    'type_toggle'      => 'Oui / Non',
    'type_select'      => 'Liste déroulante',
    'type_multiselect' => 'Choix multiples',

    // Entités (config custom_fields.entities — labels résolus au point d'usage)
    'entity_student'  => 'Élèves',
    'entity_guardian' => 'Parents / tuteurs',
    'entity_staff'    => 'Personnel',
];
