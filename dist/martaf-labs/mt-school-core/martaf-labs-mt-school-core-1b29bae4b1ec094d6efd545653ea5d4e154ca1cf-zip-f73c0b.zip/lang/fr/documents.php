<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| Domaine : documents (modèles d'impression PDF — dompdf)
| Namespace : mtschool::  →  __('mtschool::documents.report_card_title')
| fr = référence. Les fichiers en/ et ar/ DOIVENT avoir EXACTEMENT les mêmes clés.
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // Communs aux deux documents
    'student'   => 'Élève',
    'classroom' => 'Classe',
    'reference' => 'Matricule',

    // Bulletin de notes
    'report_card_title'   => 'Bulletin de notes',
    'annual_report_card_title' => 'Bulletin annuel',
    'annual_average'      => 'Moyenne annuelle',
    'annual_rank'         => 'Rang annuel',
    'decision'            => 'Décision',
    'no_data'             => 'Aucune donnée',
    'class_size'          => 'Effectif',
    'subject'             => 'Matière',
    'average_short'       => 'Moy.',
    'coefficient_short'   => 'Coef.',
    'weighted_short'      => 'Moy×C',
    'rank'                => 'Rang',
    'class_average_short' => 'Moy. cl.',
    'overall_average'     => 'Moyenne générale',
    'mention'             => 'Mention',
    'class_average'       => 'Moy. classe',
    'highest'             => 'Plus forte',
    'lowest'              => 'Plus faible',
    'council_assessment'  => 'Appréciation générale du conseil',
    'distinction'         => 'Distinction',
    'main_teacher'        => 'Le professeur principal',
    'head_of_school'      => "Le chef d'établissement",

    // Relevé financier
    'fee_statement_title' => 'Relevé financier',
    'edited_on'           => 'Édité le',
    'fees'                => 'Frais',
    'gross'               => 'Brut',
    'discount'            => 'Remise',
    'net'                 => 'Net',
    'paid'                => 'Payé',
    'remaining'           => 'Reste',
    'no_fees'             => "Aucun frais. Générez les frais d'abord.",
    'total_due'           => 'Total dû',
    'collected'           => 'Encaissé',
    'remaining_to_pay'    => 'Reste à payer',
    'payments'            => 'Paiements',
    'date'                => 'Date',
    'payment_reference'   => 'Référence',
    'method'              => 'Mode',
    'amount'              => 'Montant',

    // Modes de paiement
    'method_cash'          => 'Espèces',
    'method_mobile_money'  => 'Mobile money',
    'method_bank_transfer' => 'Virement',
    'method_check'         => 'Chèque',
    'method_card'          => 'Carte',
    'method_other'         => 'Autre',

    // Statuts de frais
    'status_paid'      => 'Soldé',
    'status_partial'   => 'Partiel',
    'status_pending'   => 'Impayé',
    'status_exempt'    => 'Exonéré',
    'status_cancelled' => 'Annulé',
    'col_type'   => 'Type',
    'col_status' => 'Statut',
    'total'      => 'Total',

    // Certificats
    'school_year'           => 'Année scolaire',
    'certificates_title'    => 'Certificats',
    'certificates_subtitle' => 'Délivrez et téléchargez les certificats officiels des élèves.',
    'cert_type'             => 'Type',
    'cert_title_enrollment' => 'Certificat de scolarité',
    'cert_title_attendance' => 'Certificat de fréquentation',
    'cert_title_success'    => 'Attestation de réussite',
    'cert_title_leaving'    => 'Certificat de radiation',
    'cert_body_enrollment'  => "Je soussigné(e), Chef d'établissement, certifie que l'élève :student, né(e) le :dob à :birthplace (matricule :ref), est régulièrement inscrit(e) en classe de :class au titre de l'année scolaire :year dans notre établissement. Le présent certificat est délivré pour servir et valoir ce que de droit.",
    'cert_body_attendance'  => "Je soussigné(e), Chef d'établissement, certifie que l'élève :student, né(e) le :dob à :birthplace, a régulièrement fréquenté notre établissement en classe de :class durant l'année scolaire :year. Le présent certificat est délivré pour servir et valoir ce que de droit.",
    'cert_body_success'     => "Je soussigné(e), Chef d'établissement, atteste que l'élève :student, né(e) le :dob à :birthplace, a satisfait aux conditions de fin d'année en classe de :class au titre de l'année scolaire :year. La présente attestation est délivrée pour servir et valoir ce que de droit.",
    'cert_body_leaving'     => "Je soussigné(e), Chef d'établissement, certifie que l'élève :student, né(e) le :dob à :birthplace, inscrit(e) en classe de :class durant l'année scolaire :year, a été rayé(e) des effectifs de notre établissement à la date du :date. Le présent certificat est délivré pour servir et valoir ce que de droit.",
    'cert_reference'        => 'Référence',
    'cert_done_on'          => 'Fait le :date',
    'cert_footer'           => "Document officiel délivré par l'établissement.",
    'cert_choose_student'   => 'Choisir un élève',
    'cert_type_label'       => 'Type de certificat',
    'cert_issue'            => 'Délivrer',
    'cert_issued_ok'        => 'Certificat délivré avec succès.',
    'cert_issued_list'      => 'Certificats délivrés',
    'cert_none'             => 'Aucun certificat délivré.',
    'cert_issued_on'        => 'Délivré le',
    'cert_student_required' => 'Sélectionnez un élève.',
];
