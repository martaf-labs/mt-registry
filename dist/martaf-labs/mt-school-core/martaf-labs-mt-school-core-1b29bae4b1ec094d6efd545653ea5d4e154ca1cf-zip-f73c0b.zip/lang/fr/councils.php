<?php

/*
|--------------------------------------------------------------------------
| Conseils de classe (écran admin ClassCouncilManager)
|--------------------------------------------------------------------------
*/

return [
    'title'      => 'Conseils de classe',
    'subtitle'   => 'Planifiez les conseils, tenez le procès-verbal et validez les décisions.',
    'plan'       => 'Planifier un conseil',
    'plan_submit' => 'Planifier',
    'period'     => 'Période',
    'all_periods' => 'Toutes les périodes',
    'date'       => 'Date et heure',
    'location'   => 'Lieu',
    'location_ph' => 'Salle des professeurs…',
    'participants' => 'Participants',
    'none'       => 'Aucun conseil de classe pour le moment.',
    'manage'     => 'Gérer le conseil',
    'created'    => 'Conseil planifié.',
    'deleted'    => 'Conseil supprimé.',
    'delete_confirm' => 'Supprimer ce conseil et ses participants ?',
    'already_exists' => 'Un conseil existe déjà pour cette classe et cette période.',
    'auto_title' => 'Conseil de classe :class — :period',

    // Statuts
    'status_planned'          => 'Planifié',
    'status_held'             => 'Tenu',
    'status_minutes_drafted'  => 'PV rédigé',
    'status_validated'        => 'Validé',
    'status_planned_plural'   => 'Planifiés',
    'status_held_plural'      => 'Tenus',
    'status_validated_plural' => 'Validés',

    // Cycle de vie
    'mark_held'        => 'Marquer comme tenu',
    'validate'         => 'Valider le conseil',
    'validate_confirm' => 'Valider définitivement ce conseil ? Le PV et les participants ne seront plus modifiables.',
    'validated_msg'    => 'Conseil validé.',

    // Procès-verbal
    'minutes'       => 'Procès-verbal',
    'minutes_ph'    => 'Décisions, observations, orientations…',
    'save_minutes'  => 'Enregistrer le PV',
    'minutes_saved' => 'Procès-verbal enregistré.',
    'no_minutes'    => 'Aucun procès-verbal.',

    // Participants
    'no_participants' => 'Aucun participant pour le moment.',
    'add_participant' => 'Ajouter un participant',
    'role'            => 'Rôle',
    'role_president'  => 'Président',
    'role_secretary'  => 'Secrétaire',
    'role_member'     => 'Membre',
    'present'         => 'Présent',
    'signed'          => 'Signé',
];
