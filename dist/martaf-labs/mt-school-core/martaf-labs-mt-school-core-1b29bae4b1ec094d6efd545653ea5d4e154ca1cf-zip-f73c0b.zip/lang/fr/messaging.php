<?php

return [
    'title'            => 'Messagerie',
    'subtitle'         => "Vos échanges avec l'établissement.",
    'new_message'      => 'Nouveau message',
    'no_conversations' => 'Aucune conversation.',
    'select_prompt'    => 'Sélectionnez une conversation ou démarrez-en une nouvelle.',
    'write_placeholder'=> 'Écrire un message…',
    'recipient'        => 'Destinataire',
    'choose'           => '— Choisir —',
    'message'          => 'Message',
];
