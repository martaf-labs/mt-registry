<?php

/*
| Assistant de configuration initiale (wizard). Namespace mtschool::setup.*
| fr = référence.
*/

return [
    'title' => 'Configuration initiale',

    // En-tête
    'header_subtitle' => 'Configurons votre école en quelques étapes simples',

    // Barre de progression
    'step_of' => 'Étape :current sur :total',

    // Étapes (titre + description)
    'step1_title'       => 'Bienvenue',
    'step1_description'  => 'Configurons votre école en quelques étapes.',
    'step2_title'       => 'École',
    'step2_description'  => "Renseignez le nom de votre établissement.",
    'step3_title'       => 'Année scolaire',
    'step3_description'  => 'Définissez la première année scolaire active.',
    'step4_title'       => "Langues",
    'step4_description'  => "Choisissez les langues d'enseignement.",
    'step5_title'       => 'Cycle',
    'step5_description'  => 'Choisissez le type de cycle scolaire.',
    'step6_title'       => 'Niveaux',
    'step6_description'  => 'Sélectionnez les niveaux à créer.',

    // ── Étape 1 : Bienvenue ──
    'welcome_intro_before' => 'Bienvenue dans',
    'welcome_intro_after'  => "! Avant d'accéder à l'application, nous allons configurer les éléments de base de votre établissement.",
    'feature_school_year'  => 'Année scolaire active',
    'feature_languages'    => "Langues d'enseignement",
    'feature_cycle'        => 'Cycle scolaire',
    'feature_first_level'  => 'Premier niveau',
    'welcome_note_before'  => 'Ces informations sont',
    'welcome_note_bold'    => 'obligatoires',
    'welcome_note_after'   => "pour que l'application fonctionne correctement. Vous pourrez les compléter ou les modifier ultérieurement.",

    // ── Étape 2 : École ──
    'school_intro_before'  => "Donnez le nom de votre établissement. Vous pourrez ajouter le logo et les autres informations plus tard dans",
    'school_intro_bold'    => 'Paramètres → Établissement',
    'school_intro_after'   => '.',
    'school_full_name'     => "Nom complet de l'établissement",
    'school_name_placeholder'  => 'Nom (:lang)',
    'school_short_name'    => 'Sigle / nom court (optionnel)',
    'school_short_placeholder' => 'Sigle (:lang)',

    // ── Étape 3 : Année scolaire ──
    'school_year'          => 'Année scolaire',
    'school_year_prefix'   => 'Année scolaire',
    'start_date'           => 'Date de début',
    'end_date'             => 'Date de fin',
    'year_note_before'     => 'Le code et le libellé sont générés automatiquement. Les dates peuvent être ajustées si nécessaire. Cette année sera définie comme',
    'year_note_bold'       => 'active',
    'year_note_after'      => '.',

    // ── Étape 4 : Langues ──
    'languages_note'       => 'Les langues sélectionnées conditionneront les matières, les bulletins et les rapports.',

    // ── Étape 5 : Cycle ──
    'levels_proposed'      => ':count niveaux proposés',
    'cycle_note_before'    => "Vous pourrez créer d'autres cycles depuis",
    'cycle_note_bold'      => 'Structure → Cycles',
    'cycle_note_after'     => '.',

    // ── Étape 6 : Niveaux ──
    'levels_selected'      => ':count niveau(x) sélectionné(s).',
    'prefill_title'        => 'Pré-remplir avec des données types',
    'prefill_hint'         => 'Crée les matières standard du cycle, une classe et une maquette (avec coefficients) par niveau. Vous pourrez tout ajuster ensuite.',
    'levels_note_before'   => "Vous pourrez en ajouter d'autres depuis",
    'levels_note_bold'     => 'Structure → Niveaux',
    'levels_note_after'    => '.',

    // ── Navigation ──
    'previous'             => 'Précédent',
    'start'               => 'Commencer',
    'next'                => 'Suivant',
    'complete'            => 'Terminer la configuration',

    // Footer
    'footer' => 'MT School — Configuration obligatoire',

    // ── Messages de validation ──
    'sc_name_required'    => "Le nom de l'établissement est obligatoire.",
    'sc_name_fr_required' => 'Le nom en français est obligatoire.',
    'sy_start_year_required' => 'Veuillez sélectionner une année scolaire.',
    'sy_start_date_required' => 'La date de début est requise.',
    'sy_end_date_required'   => 'La date de fin est requise.',
    'sy_end_date_after'      => 'La date de fin doit être après la date de début.',
    'teaching_languages_required' => 'Sélectionnez au moins une langue.',
    'teaching_languages_min'      => 'Sélectionnez au moins une langue.',
    'cycle_type_required' => 'Veuillez sélectionner un type de cycle.',
    'cycle_type_in'       => 'Type de cycle invalide.',
    'grade_levels_required' => 'Sélectionnez au moins un niveau.',
    'grade_levels_min'      => 'Sélectionnez au moins un niveau.',

    // Année scolaire automatique (setup)
    'sy_auto_hint'       => "Déterminée automatiquement selon la date du jour — ajustez au besoin les dates de début et de fin.",
    'sy_next_years_hint' => 'Les années suivantes se créeront depuis Structure → Nouvelle année (promotion des élèves et report des soldes).',

    'sy_start_in_year'   => "La date de début doit être dans l'année :year.",
    'sy_end_in_year'     => 'La date de fin doit être au plus tard dans l\'année :year.',
    'sy_max_duration'    => "L'année scolaire ne peut pas dépasser 12 mois.",

    // Multi-cycles (complexe scolaire)
    'cycles_multi_hint'  => 'Cochez tous les cycles de votre établissement — un complexe scolaire peut en combiner plusieurs (maternelle + primaire + secondaire…).',
    'levels_per_cycle'   => 'Le cycle « :cycle » doit garder au moins un niveau (ou décochez-le à l\'étape précédente).',

    'cycles_limited_note' => 'Les cycles absents de cette liste seront proposés prochainement.',

    'completing_hint' => 'Création de votre école en cours (niveaux, classes, matières, maquettes)… Cela peut prendre quelques minutes — ne fermez pas la page.',
];
