<?php

/*
| Domaine ÉLÈVES & ENSEIGNANTS (Structure/Personnel/Scolarité).
| Namespace mtschool::students.*
*/

return [
    // ── Titres ──
    'students'      => 'Élèves',
    'teachers'      => 'Enseignants',

    // ── Élèves : colonnes ──
    'col_student'      => 'Élève',
    'boy'              => 'Garçon',
    'girl'             => 'Fille',
    'col_classroom'    => 'Classe',
    'birth_place'      => 'Lieu de naissance',
    'enrollment_col'   => 'Inscription',
    'not_enrolled'     => 'Non inscrit',
    // Gestion des inscriptions (EnrollmentManager)
    'enrollments_title'    => 'Inscriptions',
    'enrollments_subtitle' => 'Validez ou refusez les inscriptions ; la validation met à jour l\'effectif de la classe.',
    'enrollments_none'     => 'Aucune inscription.',
    'enrollment_pending'   => 'En attente',
    'enrollment_validated' => 'Validées',
    'enrollment_validate'  => 'Valider',
    'enrollment_reject'    => 'Refuser',
    'enrollment_reject_reason' => 'Motif du refus…',
    'enrollment_validated_ok'  => 'Inscription validée, effectif mis à jour.',
    'enrollment_rejected_ok'   => 'Inscription refusée.',

    // ── Élèves : stats ──
    'stat_total_students' => 'Total élèves',
    'stat_enrolled_year'  => 'Inscrits :year',
    'stat_pending'        => 'En attente',

    // ── Enseignants : colonnes ──
    'col_teacher'        => 'Enseignant',
    'primary_subject'    => 'Matière principale',
    'qualified_subjects' => 'Matières qualifiées',
    'subject_count'      => ':n matière(s)',
    'contract_hours'     => 'Heures contrat',
    'hours_suffix'       => ':n h',

    // ── Enseignants : stats ──
    'stat_teachers' => 'Enseignants',

    // ── Formulaire enseignant ──
    'last_name'          => 'Nom',
    'first_name'         => 'Prénom',
    'title_civility'     => 'Civilité',
    'gender'             => 'Genre',
    'gender_m'           => 'Masculin',
    'gender_f'           => 'Féminin',
    'hire_date'          => "Date d'embauche",
    'email'              => 'E-mail',
    'phone'              => 'Téléphone',
    'weekly_hours'       => 'Heures/semaine (contrat)',
    'degree'             => 'Diplôme',
    'specialty'          => 'Spécialité',
    'teacher_active'     => 'Enseignant actif',
    'teacher_model_name'   => 'un enseignant',
    'teacher_model_plural' => 'les enseignants',
    'teacher_singular'     => 'Enseignant',
    'nationality'          => 'Nationalité',
    'birth_date'          => 'Date de naissance',

    // Tuteurs
    'guardians'              => 'Tuteurs',
    'guardian_model_name'    => 'un tuteur',
    'guardian_model_plural'  => 'les tuteurs',
    'col_guardian'           => 'Tuteur',

    // ── Fiche élève (base-show) ──
    'tab_profile'        => 'Profil',
    'tab_schooling'      => 'Scolarité',
    'tab_finances'       => 'Finances',
    'identity'           => 'Identité',
    'contact_info'       => 'Coordonnées',
    'current_enrollment' => 'Inscription en cours',
    'enrollment_date'    => "Date d'inscription",
    'enrollment_history' => 'Historique des inscriptions',
    'no_enrollments'     => 'Aucune inscription.',
    'relationship'       => 'Lien de parenté',
    'primary_contact'    => 'Contact principal',
    'no_guardians'       => 'Aucun tuteur enregistré.',
    'manage_images'      => 'Gérer les images',
    'view_profile'       => 'Voir la fiche',

    'civility'               => 'Civilité',
    'guardian_photo'         => 'Photo du tuteur',
    'occupation'             => 'Profession',
    'workplace'              => 'Lieu de travail',
    'work_phone'             => 'Téléphone professionnel',
    'address'                => 'Adresse',
    'children'               => 'Enfants',
    'tab_children'           => 'Enfants',
    'portal_account'         => 'Compte portail',
    'portal_account_active'  => 'Compte actif',
    'portal_account_none'    => 'Aucun compte',
    'stat_total_guardians'   => 'Total tuteurs',
    'stat_guardian_accounts' => 'Comptes portail',
    'student_model_name'     => 'un élève',

    'last_name_required' => 'Le nom est obligatoire.',
    'first_name_required'=> 'Le prénom est obligatoire.',
    'email_unique'       => 'Cet e-mail est déjà utilisé par un membre du personnel.',

    // ── EnrollmentStatus (enum) ──
    'enrollment_status_pending'     => 'En attente',
    'enrollment_status_validated'   => 'Validée',
    'enrollment_status_rejected'    => 'Rejetée',
    'enrollment_status_cancelled'   => 'Annulée',
    'enrollment_status_transferred' => 'Transférée',

    // ── EnrollmentResult (enum) ──
    'enrollment_result_admitted'    => 'Admis',
    'enrollment_result_retained'    => 'Redoublant',
    'enrollment_result_promoted'    => 'Promu',
    'enrollment_result_expelled'    => 'Exclu',
    'enrollment_result_withdrawn'   => 'Retiré',
    'enrollment_result_transferred' => 'Transféré',

    // Personnel (vue transversale « Tout le staff »)
    'col_staff_member'          => 'Membre du personnel',
    'staff_type'                => 'Catégorie',
    'staff_role'                => 'Fonction',
    'stat_staff'                => 'Personnel',
    'staff_type_teacher'        => 'Enseignant',
    'staff_type_administrative' => 'Administratif',
    'staff_type_technical'      => 'Technique',
    'staff_type_management'     => 'Direction',

    // ── Fiche personnel (base-profile) ──
    'staff_photo'        => 'Photo du membre',
    'tab_contract'       => 'Contrat',
    'position'           => 'Poste',
    'grade'              => 'Grade',
    'contract_status'    => 'Type de contrat',
    'contract_end_date'  => 'Fin de contrat',
    'id_card_number'     => "N° pièce d'identité",
    'emergency_phone'    => "Téléphone d'urgence",
    'staff_account'      => 'Compte utilisateur',
    'account_active'     => 'Compte actif',
    'account_none'       => 'Aucun compte',
];
