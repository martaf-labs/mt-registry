<?php

/*
| Domaine INSCRIPTION (assistant multi-étapes StudentEnrollmentForm).
| Namespace mtschool::enrollment.*
*/

return [
    // ── Cascade classe ──
    'cycle'              => 'Cycle scolaire',
    'cycle_help'         => 'Seuls les cycles ayant des classes ouvertes sont affichés.',
    'level_available'    => ':n niveau(x) disponible(s)',
    'level'              => 'Niveau',
    'class_count'        => ':n classe(s)',
    'classroom'          => 'Classe',
    'full'               => 'Complète',
    'spots_available'    => ':n place(s) disponible(s)',

    // ── Élève existant / nouveau ──
    'existing_student'      => 'Élève déjà enregistré (ré-inscription)',
    'existing_student_help' => "Laissez vide pour créer un nouvel élève à l'étape suivante.",
    'last_name'              => 'Nom',
    'first_names'            => 'Prénom(s)',
    'sex'                    => 'Sexe',
    'sex_m'                  => 'Masculin',
    'sex_f'                  => 'Féminin',
    'birth_date'             => 'Date de naissance',
    'birth_place'            => 'Lieu de naissance',
    'nationality'            => 'Nationalité',
    'birth_cert_number'      => 'N° acte de naissance',
    'repeating'              => 'Redoublant',
    'repeating_label'        => 'Élève redoublant',
    'transferred'            => 'Transféré',
    'transferred_label'      => "Vient d'un autre établissement",
    'previous_school'        => 'École précédente',
    'previous_class'         => 'Classe précédente',
    'previous_year'          => 'Année précédente',
    'internal_notes'         => 'Notes internes',

    // ── Tuteur existant / nouveau ──
    'existing_guardian'      => 'Tuteur déjà enregistré',
    'existing_guardian_help' => 'Laissez vide pour créer un nouveau tuteur.',
    'relationship'           => 'Lien de parenté',
    'guardian_title'         => 'Titre',
    'phone'                  => 'Téléphone',
    'email'                  => 'Email',
    'occupation'             => 'Profession',
    'address'                => 'Adresse',
    'primary_contact'        => 'Contact principal',
    'pickup'                 => 'Récupération',
    'pickup_label'           => 'Autorisé à récupérer',
    'portal'                 => 'Portail',
    'portal_label'           => 'Accès portail parent',

    // ── Documents ──
    'student_photo'      => "Photo de l'élève",
    'birth_certificate'  => 'Acte de naissance (PDF ou image)',
    'previous_report_card' => "Bulletin de l'année précédente",
    'other_document_opt' => 'Autre document (facultatif)',

    // ── Inscription ──
    'enrollment_date'    => "Date d'inscription",
    'notes'              => 'Notes',

    // ── Messages de validation ──
    'select_cycle'         => 'Sélectionnez un cycle.',
    'select_level'         => 'Sélectionnez un niveau.',
    'select_class'         => 'Sélectionnez une classe.',
    'last_name_required'   => 'Le nom est obligatoire.',
    'first_name_required'  => 'Le prénom est obligatoire.',
    'sex_required'         => 'Le sexe est obligatoire.',
    'birth_date_required'  => 'La date de naissance est obligatoire.',
    'birth_date_before'    => 'La date de naissance doit être dans le passé.',
    'birth_date_after'     => 'Âge invalide (> 30 ans).',
    'birth_place_required' => 'Le lieu de naissance est obligatoire.',
    'nationality_required' => 'La nationalité est obligatoire.',
    'relationship_required'=> 'Indiquez le lien de parenté.',
    'guardian_last_name_required'  => 'Le nom du tuteur est obligatoire.',
    'guardian_first_name_required' => 'Le prénom du tuteur est obligatoire.',
    'guardian_phone_required'      => 'Le téléphone est obligatoire.',

    // ── Relationship (enum) ──
    'relationship_father'      => 'Père',
    'relationship_mother'      => 'Mère',
    'relationship_guardian'    => 'Tuteur légal',
    'relationship_grandparent' => 'Grand-parent',
    'relationship_sibling'     => 'Frère / Sœur',
    'relationship_aunt_uncle'  => 'Tante / Oncle',
    'relationship_other'       => 'Autre',

    // ── Étapes du wizard (titres + descriptions) ──
    'step_cycle_title'        => 'Cycle',
    'step_cycle_desc'         => "Cycle scolaire de l'élève",
    'step_level_title'        => 'Niveau',
    'step_level_desc'         => 'Niveau dans le cycle',
    'step_class_title'        => 'Classe',
    'step_class_desc'         => "Classe d'affectation",
    'step_student_title'      => 'Élève',
    'step_student_desc'       => 'Ré-inscrire un élève existant',
    'step_new_student_title'  => 'Nouvel élève',
    'step_new_student_desc'   => "Informations de l'élève",
    'step_guardian_title'     => 'Tuteur',
    'step_guardian_desc'      => 'Tuteur existant + lien',
    'step_new_guardian_title' => 'Nouveau tuteur',
    'step_new_guardian_desc'  => 'Informations du tuteur',
    'step_documents_title'    => 'Documents',
    'step_documents_desc'     => 'Pièces jointes (facultatives)',
    'step_finalize_title'     => 'Inscription',
    'step_finalize_desc'      => 'Finaliser (créée en attente)',

    // ── Wrapper Form (nav/model/erreurs) ──
    'model_name'          => 'une inscription',
    'model_name_plural'   => 'les inscriptions',
    'nav_students'        => 'Élèves',
    'nav_enroll'          => 'Inscrire',
    'nav_edit'            => 'Modifier',
    'no_open_class_error' => "Aucune classe ouverte pour l'année active. Créez au moins une classe avant d'inscrire un élève.",
];
