<?php

/*
| Domaine EMPLOI DU TEMPS (TimetableGridManager + portails). Namespace mtschool::timetable.*
*/

return [
    'title'      => 'Emploi du temps',
    'my_title'   => 'Mon emploi du temps',
    'subtitle'   => 'Cliquez sur une case pour y placer un cours (issu des affectations de la classe).',
    'no_assignments'   => 'Aucune affectation pour cette classe.',
    'assign_teachers'  => 'Affectez des enseignants',
    'first'            => "d'abord.",

    'course_modal_title' => 'Cours',
    'course_field'      => 'Cours (affectation)',
    'empty_free_cell'   => '— Vide (libérer la case) —',
    'room_optional'     => 'Salle (facultatif)',
    'none'              => '— Aucune —',
    'no_teacher'        => 'sans prof',
    'timetable_updated' => 'Emploi du temps mis à jour.',

    // Jours (day_of_week 1..5)
    'day_1' => 'Lundi',
    'day_2' => 'Mardi',
    'day_3' => 'Mercredi',
    'day_4' => 'Jeudi',
    'day_5' => 'Vendredi',
    'day_6' => 'Samedi',
    'day_7' => 'Dimanche',
    'conflict_teacher' => 'Conflit : cet enseignant est déjà occupé sur ce créneau (classe :class).',
    'conflict_room'    => 'Conflit : cette salle est déjà occupée sur ce créneau (classe :class).',
];
