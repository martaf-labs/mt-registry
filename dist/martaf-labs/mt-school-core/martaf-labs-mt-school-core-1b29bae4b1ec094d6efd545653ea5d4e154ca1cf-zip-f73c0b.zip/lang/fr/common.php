<?php

/*
|──────────────────────────────────────────────────────────────────────────────
| Chaînes d'interface PARTAGÉES (verbes, statuts, libellés récurrents).
| Namespace : mtschool::  →  __('mtschool::common.save')
|
| Convention : les libellés spécifiques à un écran vont dans un fichier de
| DOMAINE (pedagogy.php, messaging.php, …). Ici : uniquement le vocabulaire
| réutilisé partout. Remplir langue par langue (fr = référence).
|──────────────────────────────────────────────────────────────────────────────
*/

return [
    // Actions
    'all'         => 'Tous',
    'save'        => 'Enregistrer',
    'cancel'      => 'Annuler',
    'delete'      => 'Supprimer',
    'edit'        => 'Modifier',
    'create'      => 'Créer',
    'add'         => 'Ajouter',
    'new_m'       => 'Nouveau',
    'new_f'       => 'Nouvelle',
    'send'        => 'Envoyer',
    'publish'     => 'Publier',
    'unpublish'   => 'Dépublier',
    'back'        => 'Retour',
    'download'    => 'Télécharger',
    'open'        => 'Ouvrir',
    'analyze'     => 'Analyser',
    'import'      => 'Importer',
    'export'      => 'Exporter',

    // Statuts
    'published'   => 'Publié',
    'published_f' => 'Publiée',
    'draft'       => 'Brouillon',
    'active'      => 'Actif',

    // Statuts (genre) — utilisés dans les tableaux admin (accord grammatical)
    'active_m'    => 'Actif',
    'active_f'    => 'Active',
    'inactive_m'  => 'Inactif',
    'inactive_f'  => 'Inactive',
    'status'      => 'Statut',
    'total'       => 'Total',
    'yes'         => 'Oui',
    'no'          => 'Non',
    'code'        => 'Code',
    'label'       => 'Libellé',
    'description' => 'Description',
    'order'       => 'Ordre',
    'color'       => 'Couleur',
    'icon'        => 'Icône',
    'type'        => 'Type',

    // Messages de validation (dates)
    'date_start_required' => 'La date de début est obligatoire.',
    'date_end_required'   => 'La date de fin est obligatoire.',
    'date_end_after'      => 'La date de fin doit être postérieure à la date de début.',

    // Divers
    'loading'     => 'Chargement…',
    'none'        => 'Aucun',
    'search'      => 'Rechercher',
    'confirm_delete' => 'Confirmer la suppression ?',
    'students'    => 'élève(s)',
    'view'        => 'Voir',
    'action'      => 'Action',
    'actions'     => 'Actions',
];
