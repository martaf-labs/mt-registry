<?php

/*
| Domaine PRÉSENCES / VIE SCOLAIRE (AttendanceManager). Namespace mtschool::attendance.*
*/

return [
    'title'         => 'Appel / présences',
    'subtitle'      => "Marquez le statut de chaque élève. L'enregistrement est immédiat.",

    'classroom'     => 'Classe',
    'date'          => 'Date',
    'day_period'    => 'Demi-journée',
    'period_full'   => 'Journée',
    'period_morning'=> 'Matin',
    'period_afternoon' => 'Après-midi',

    'present_count' => ':n présents',
    'absent_count'  => ':n absents',
    'late_count'    => ':n retards',
    'stat_present'  => 'Présents',
    'stat_absent'   => 'Absents',
    'stat_late'     => 'Retards',
    'mark_all_present' => 'Tout présent',
    'all_present_msg'  => 'Tous présents.',

    'no_students'   => 'Aucun élève inscrit dans cette classe.',
    'justified'     => 'justifiée',
    'to_justify'    => 'à justifier',
    'status_present'=> 'Présent',
    'status_absent' => 'Absent',
    'status_late'   => 'Retard',
];
