<?php

return [
    'title'          => 'Import / Export',
    'subtitle'       => 'Exportez vos données ou importez des élèves en masse.',

    // Exports
    'export_section' => 'Exporter (CSV)',
    'export_hint'    => 'Téléchargez vos données au format CSV (compatible Excel).',
    'students'       => 'Élèves',
    'results'        => 'Résultats',
    'fees'           => 'Frais',

    // Import
    'import_section' => 'Importer des élèves (CSV)',
    'columns_hint'   => 'Colonnes attendues :',
    'columns_note'   => '(genre = M/F, naissance = AAAA-MM-JJ, classe = code de la classe).',
    'available_codes'=> 'Codes de classe disponibles :',
    'download_template' => 'Télécharger le modèle',
    'col_matricule'  => 'Matricule',
    'col_guardian'   => 'Tuteur',
    // Accès portail (provisioning en masse)
    'provision_section'  => 'Accès portail',
    'provision_hint'     => 'Génère les comptes de connexion des parents (tuteurs sans compte) et télécharge la liste des identifiants + mots de passe temporaires à distribuer.',
    'provision_parents'  => 'Générer les accès parents',
    'provision_students' => 'Générer les accès élèves',
    'provision_confirm'  => 'Générer les comptes de connexion pour tous les tuteurs sans compte ?',
    'provision_confirm_students' => 'Générer les comptes de connexion pour tous les élèves sans compte ?',
    'parents_none'       => 'Aucun nouveau tuteur à provisionner (tous ont déjà un compte).',
    'students_none'      => 'Aucun nouvel élève à provisionner (tous ont déjà un compte).',
    'no_errors'          => 'Aucune ligne en erreur à exporter.',
    'download_errors'    => 'Exporter les :n erreur(s)',
    'col_errors'         => 'Erreurs',
    'access_login'       => 'Identifiant',
    'access_password'    => 'Mot de passe temporaire',
    // Import du personnel
    'staff_section'      => 'Import du personnel',
    'staff_hint'         => 'Fichier CSV avec les colonnes :',
    'import_staff'       => 'Importer le personnel',
    'staff_confirm'      => 'Importer le personnel depuis ce fichier ?',
    'staff_report'       => ':imported membre(s) importé(s), dont :teachers enseignant(s) ; :skipped ligne(s) ignorée(s).',
    // Import matières
    'subjects_section'   => 'Import des matières',
    'import_subjects'    => 'Importer les matières',
    'subjects_report'    => ':imported matière(s) importée(s) ; :skipped ignorée(s) (code manquant ou déjà existant).',
    // Import affectations
    'assign_section'     => 'Import des affectations (enseignant → classe → matière)',
    'assign_hint'        => 'Fichier CSV, année active. L\'enseignant est reconnu par l\'e-mail de sa fiche personnel ; classe et matière par leur code. Colonnes :',
    'import_assignments' => 'Importer les affectations',
    'assign_report'      => ':imported affectation(s) créée(s) ; :skipped ignorée(s) (prof/classe/matière introuvable ou déjà affecté).',
    // Historique / journal des imports
    'history_section'    => 'Historique des imports',
    'history_date'       => 'Date',
    'history_type'       => 'Type',
    'history_result'     => 'Résultat',
    'history_by'         => 'Par',
    'history_skipped'    => 'ignorée(s)',
    'type_students'      => 'Élèves',
    'type_staff'         => 'Personnel',
    'type_subjects'      => 'Matières',
    'type_assignments'   => 'Affectations',
    'type_access_parents'  => 'Accès parents',
    'type_access_students' => 'Accès élèves',
    'reading'        => 'Lecture du fichier…',
    'valid_of'       => ':valid valide(s) / :total ligne(s)',
    'change_file'    => 'Changer de fichier',

    // Colonnes de l'aperçu
    'col_line'       => '#',
    'col_lastname'   => 'Nom',
    'col_firstname'  => 'Prénom',
    'col_gender'     => 'Genre',
    'col_birth'      => 'Naissance',
    'col_class'      => 'Classe',
    'col_status'     => 'État',
    'status_ok'      => 'OK',
    'import_confirm' => 'Importer les lignes valides ?',
    'import_n'       => 'Importer :n élève(s)',

    // Messages
    'no_valid_rows'  => 'Aucune ligne valide à importer.',
    'imported'       => ':count élève(s) importé(s) et inscrit(s).',
    'import_report'  => ':imported importé(s), :duplicates doublon(s) ignoré(s), :invalid ligne(s) invalide(s), :guardians tuteur(s) lié(s).',

    // Erreurs de ligne
    'err_lastname'   => 'nom manquant',
    'err_firstname'  => 'prénom manquant',
    'err_gender'     => 'genre (M/F)',
    'err_date'       => 'date invalide',
    'err_class'      => 'classe inconnue',
    'csv_drop' => 'Glissez votre fichier CSV ici',
    'csv_hint' => 'Format CSV — séparateur ; ou ,',
];
