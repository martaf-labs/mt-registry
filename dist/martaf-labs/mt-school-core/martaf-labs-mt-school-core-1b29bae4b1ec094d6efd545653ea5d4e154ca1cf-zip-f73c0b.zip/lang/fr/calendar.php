<?php

return [
    'title'        => 'Calendrier',
    'subtitle'     => "Les événements à venir de l'établissement.",
    'new_event'    => 'Nouvel événement',
    'no_events'    => 'Aucun événement à venir.',
    'all_day'      => 'Toute la journée',

    // Types d'événement
    'type_event'   => 'Événement',
    'type_meeting' => 'Réunion',
    'type_exam'    => 'Examen',
    'type_holiday' => 'Congé',
    'type_other'   => 'Autre',

    // Modale
    'title_field'  => 'Intitulé',
    'title_ph'     => 'Réunion parents-professeurs',
    'type'         => 'Type',
    'start'        => 'Début',
    'end'          => 'Fin',
    'location'     => 'Lieu',
    'location_ph'  => 'Salle polyvalente',

    // Messages
    'event_added'   => 'Événement ajouté au calendrier.',
    'event_deleted' => 'Événement supprimé.',
];
