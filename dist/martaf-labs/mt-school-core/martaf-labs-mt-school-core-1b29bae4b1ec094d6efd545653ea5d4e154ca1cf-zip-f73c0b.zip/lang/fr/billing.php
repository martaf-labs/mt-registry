<?php

/*
| Domaine BILLING (achat / renouvellement d'abonnement, tarification).
| Namespace mtschool::billing.*
*/

return [
    // ── Titres de page (Livewire ->title()) ──
    'renew_title'    => "Renouveler l'abonnement",
    'checkout_title' => 'Finaliser votre abonnement',
    'pricing_title'  => 'Nos formules',

    // ── Renouvellement (RenewComponent + renew.blade) ──
    'renew_reactivated' => 'Abonnement réactivé. Bienvenue !',
    'expired_heading'   => 'Abonnement expiré',
    'expired_intro'     => "L'accès de :name est suspendu. Vos données sont conservées — renouvelez pour réactiver l'établissement.",
    'your_plan'         => 'Votre formule',
    'per_month'         => 'mois',
    'per_term'          => 'trimestre',
    'per_year'          => 'an',
    'max_students'      => ':count élèves max',
    'unlimited_students'=> 'Élèves illimités',
    'renew_button'      => 'Renouveler — :amount :currency',
    'processing'        => 'Traitement…',
    'simulated_payment' => 'Paiement simulé (mode développement).',
    'no_plan_to_renew'  => 'Aucune formule à reconduire.',
    'see_plans'         => 'Voir les formules',
    'logout'            => 'Se déconnecter',

    // ── Checkout (Checkout + checkout.blade) ──
    'checkout_subtitle'   => 'Créez votre compte administrateur.',
    'plan_label'          => 'Formule :name',
    'your_name'           => 'Votre nom',
    'school_name_optional'=> "Nom de l'établissement (optionnel)",
    'school_name_ph'      => 'Vous pourrez le préciser plus tard',
    'email'               => 'Email',
    'password'            => 'Mot de passe',
    'password_confirm'    => 'Confirmer le mot de passe',
    'pay_button'          => 'Payer :amount :currency (simulation)',
    'simulated_payment_long' => "Paiement simulé (mode développement). Aucune somme n'est débitée.",
    'email_unique'        => 'Un compte existe déjà avec cet email.',
    'password_confirmed'  => 'La confirmation du mot de passe ne correspond pas.',

    // ── Tarification (Pricing + pricing.blade) ──
    'pricing_heading'  => 'Choisissez votre formule',
    'pricing_subtitle' => 'Gérez votre établissement, de la maternelle au secondaire. Changez de plan à tout moment.',
    'choose_plan'      => 'Choisir :name',
    'already_account'  => 'Déjà un compte ?',
    'login'            => 'Se connecter',
];
