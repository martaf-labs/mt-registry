<?php

/*
| Domaine TABLEAU DE BORD (directeur). Namespace mtschool::dashboard.*
*/

return [
    'title'            => 'Tableau de bord',
    'subtitle_year'    => 'Année scolaire :year',
    'subtitle_default' => "Aperçu général de l'établissement",

    // Actions rapides
    'new_student'      => 'Nouvel élève',
    'enrollments'      => 'Inscriptions',

    // Cartes de stats
    'enrolled'         => 'Élèves inscrits',
    'collection_rate'  => 'Recouvrement',
    'school_average'   => 'Moyenne établissement',
    'attendance'       => 'Assiduité',
    'teachers'         => 'Enseignants',
    'classes'          => 'Classes',
    'collected'        => 'Encaissé',
    'remaining'        => 'Reste',
    'period'           => 'Période',
    'unjustified_abs'  => 'Abs. injustifiées',

    // Widgets
    'enrollment_by_level' => 'Effectifs par niveau',
    'students_dataset'    => 'Élèves',
    'your_plan'           => 'Votre formule',
    'collection_by_level' => 'Recouvrement par niveau',
    'class_ranking'       => 'Palmarès des classes',
    'students_count'      => ':n élève(s)',

    // Widget « Votre formule »
    'plan_valid_until'  => "Valable jusqu'au",
    'plan_quota'        => 'Quota élèves',
    'plan_unlimited'    => 'Illimité',
    'plan_modules'      => 'Modules actifs',

    // ── Bande 1 · Files d'action ──────────────────────────────────────────
    'pending_enrollments_title' => 'Inscriptions à valider',
    'pending_count'             => ':n dossier(s) en attente',
    'badge_pending'             => 'En attente',
    'process_enrollment'        => 'Traiter',
    'pending_justifications'    => "Justificatifs d'absence",
    'justifications_count'      => ':n à traiter',
    'justif_attachment'         => 'PJ',
    'reportcards_title'         => 'Bulletins de la période',
    'reportcards_published'     => 'Publiés',
    'reportcards_to_publish'    => 'À publier',
    'reportcards_to_validate'   => 'À valider',
    'installments_title'        => 'Échéances de frais',
    'overdue_amount'            => 'En retard',
    'due_soon_30d'              => 'À venir (30 j)',
    'installments_count'        => ':n échéance(s)',

    // ── Bande 2 · Tendances ────────────────────────────────────────────────
    'collection_trend'          => 'Tendance des encaissements (12 mois)',
    'collected_dataset'         => 'Encaissé',
    'average_trend_title'       => 'Évolution de la moyenne établissement',
    'average_trend_dataset'     => 'Moyenne',
    'absence_trend'             => 'Absences & retards (14 jours)',
    'absences_dataset'          => 'Absences',
    'late_dataset'              => 'Retards',

    // ── Bande 3 · Structure & distribution ─────────────────────────────────
    'class_fill_rate_title'     => 'Remplissage des classes',
    'overcrowded'               => ':n % · surchargée',
    'grade_distribution_title'  => 'Répartition des moyennes',
    'grade_band_below10'        => 'Moins de 10',
    'grade_band_10_12'          => '10 à 12',
    'grade_band_12_14'          => '12 à 14',
    'grade_band_14_16'          => '14 à 16',
    'grade_band_16_plus'        => '16 et plus',
    'gender_split_title'        => 'Filles / garçons',
    'girls'                     => 'Filles',
    'boys'                      => 'Garçons',
    'parity_index'              => ':n % de filles',

    // ── Bande 4 · Ciblage ──────────────────────────────────────────────────
    'classes_to_chase'          => 'Classes à relancer',
    'overdue_installments_count' => ':n échéance(s) échue(s)',
    'weakest_subjects_title'    => 'Matières les plus faibles',
    'top_absentees'             => 'Élèves les plus absents',
    'absences_short'            => ':n abs.',

    // ── Bande 5 · Vie de l'établissement ───────────────────────────────────
    'activity_feed'             => "Activité récente",
    'activity_new_enrollment'   => 'Nouvelle inscription : :name',
    'activity_payment_received' => 'Paiement de :amount reçu',
    'activity_announcement'     => 'Annonce : :title',
    'upcoming_events'           => "Prochains événements",
    'event_all_day'             => 'Journée',
    'class_councils'            => 'Conseils de classe',
    'council_planned'           => 'Planifié',
    'council_to_validate'       => 'PV à valider',
    'recent_sanctions'          => 'Sanctions récentes',
    'parent_not_notified'       => 'Parent non prévenu',
];
