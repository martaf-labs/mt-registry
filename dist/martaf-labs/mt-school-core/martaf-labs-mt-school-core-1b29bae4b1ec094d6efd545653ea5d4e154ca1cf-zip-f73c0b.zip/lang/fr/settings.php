<?php

return [
    'title'                 => 'Paramètres',
    'subtitle'              => 'Préférences de votre établissement (appliquées à toute l\'école).',

    // Notifications
    'notifications_section' => 'Notifications',
    'notify_email'          => 'Envoyer aussi les notifications par e-mail',
    'notify_email_hint'     => 'En plus des notifications dans l\'application, envoie un e-mail aux parents/élèves/personnel (nécessite un serveur d\'envoi configuré).',

    // Notation
    'grading_section'       => 'Notation',
    'grading_hint'          => 'Barème utilisé pour les moyennes, mentions et décisions de passage.',
    'passing_score'         => 'Note de passage',
    'max_score'             => 'Note maximale',

    'saved'                 => 'Paramètres enregistrés.',
];
