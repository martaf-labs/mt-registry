<?php

return [
    'title'         => 'Équipe & accès',
    'subtitle'      => 'Créez des comptes back-office et attribuez à chacun un rôle. Le rôle détermine ce que la personne voit et peut modifier (finances, scolarité, structure…).',

    'add'           => 'Ajouter un membre',
    'add_title'     => 'Nouveau membre',
    'edit_title'    => 'Modifier le membre',

    'name'          => 'Nom complet',
    'email'         => 'E-mail (identifiant de connexion)',
    'phone'         => 'Téléphone',
    'role'          => 'Rôle',
    'role_choose'   => 'Choisir un rôle…',
    'role_hint'     => 'Censeur : scolarité & résultats. Comptable : finances (+ élèves en lecture). Personnel : élèves, inscriptions & scolarité courante. Directeur : accès complet.',
    'password'      => 'Mot de passe',
    'password_edit' => 'Nouveau mot de passe (laisser vide pour ne pas changer)',

    'active'        => 'Actif',
    'inactive'      => 'Désactivé',
    'status'        => 'Statut',
    'actions'       => 'Actions',

    'save'          => 'Enregistrer',
    'cancel'        => 'Annuler',
    'edit'          => 'Modifier',
    'deactivate'    => 'Désactiver',
    'activate'      => 'Réactiver',

    'you'           => 'vous',
    'owner'         => 'Propriétaire',

    'created'       => 'Membre créé. Il peut désormais se connecter avec son e-mail.',
    'updated'       => 'Membre mis à jour.',
];
