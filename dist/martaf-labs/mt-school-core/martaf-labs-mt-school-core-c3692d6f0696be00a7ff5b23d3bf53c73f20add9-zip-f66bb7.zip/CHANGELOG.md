git init
git add .
git commit -m "Initial commit - mt-school"
git remote add origin https://github.com/martaf-labs/mt-school.git
git branch -M main    
git push -u origin main