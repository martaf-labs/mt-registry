<?php

use Illuminate\Support\Facades\Route;

/*
|─────────────────────────────────────────────────────────────────────────────
| Routes mt-school
|─────────────────────────────────────────────────────────────────────────────
|
| Ces routes sont chargées automatiquement par MtSchoolServiceProvider.
| Toutes les routes sont préfixées par la config 'mtschool.route_prefix'
| (défaut : 'school') et protégées par 'auth'.
|
| Pour désactiver les routes du package et définir les vôtres :
|   Dans votre AppServiceProvider : MtSchoolServiceProvider::ignoreRoutes()
|
*/

$prefix     = config('mtschool.route_prefix', 'school');
$middleware = config('mtschool.middleware', ['web', 'auth']);

Route::prefix($prefix)
    ->middleware($middleware)
    ->name('mtschool.')
    ->group(function () {

        // ── Dashboard ─────────────────────────────────────────────────────────
        Route::get('/', fn() => view('mtschool::dashboard'))->name('dashboard');

        // ── Années scolaires ──────────────────────────────────────────────────
        Route::get('/annees',          fn() => view('mtschool::admin.annees.index'))->name('annees.index');
        Route::get('/annees/create',   fn() => view('mtschool::admin.annees.form'))->name('annees.create');
        Route::get('/annees/{id}',     fn($id) => view('mtschool::admin.annees.form', ['anneeId' => $id]))->name('annees.edit');

        // ── Structure académique ───────────────────────────────────────────────
        Route::get('/cycles',          fn() => view('mtschool::admin.cycles.index'))->name('cycles.index');
        Route::get('/niveaux',         fn() => view('mtschool::admin.niveaux.index'))->name('niveaux.index');
        Route::get('/filieres',        fn() => view('mtschool::admin.filieres.index'))->name('filieres.index');

        // ── Classes ───────────────────────────────────────────────────────────
        Route::get('/classes',         fn() => view('mtschool::admin.classes.index'))->name('classes.index');
        Route::get('/classes/create',  fn() => view('mtschool::admin.classes.form'))->name('classes.create');
        Route::get('/classes/{id}',    fn($id) => view('mtschool::admin.classes.show', ['classeId' => $id]))->name('classes.show');

        // ── Élèves ────────────────────────────────────────────────────────────
        Route::get('/eleves',          fn() => view('mtschool::admin.eleves.index'))->name('eleves.index');
        Route::get('/eleves/create',   fn() => view('mtschool::admin.eleves.form'))->name('eleves.create');
        Route::get('/eleves/{id}',     fn($id) => view('mtschool::admin.eleves.show', ['eleveId' => $id]))->name('eleves.show');

        // ── Inscriptions ──────────────────────────────────────────────────────
        Route::get('/inscriptions',        fn() => view('mtschool::admin.inscriptions.index'))->name('inscriptions.index');
        Route::get('/inscriptions/create', fn() => view('mtschool::admin.inscriptions.form'))->name('inscriptions.create');
        Route::get('/inscriptions/{id}',   fn($id) => view('mtschool::admin.inscriptions.show', ['inscriptionId' => $id]))->name('inscriptions.show');

        // ── Personnel ─────────────────────────────────────────────────────────
        Route::get('/personnels',         fn() => view('mtschool::admin.personnels.index'))->name('personnels.index');
        Route::get('/personnels/create',  fn() => view('mtschool::admin.personnels.form'))->name('personnels.create');
        Route::get('/personnels/{id}',    fn($id) => view('mtschool::admin.personnels.show', ['personnelId' => $id]))->name('personnels.show');

        // ── Évaluations & Notes ───────────────────────────────────────────────
        Route::get('/evaluations',        fn() => view('mtschool::admin.evaluations.index'))->name('evaluations.index');
        Route::get('/evaluations/create', fn() => view('mtschool::admin.evaluations.form'))->name('evaluations.create');
        Route::get('/notes/saisie',       fn() => view('mtschool::admin.notes.saisie'))->name('notes.saisie');

        // ── Bulletins ─────────────────────────────────────────────────────────
        Route::get('/bulletins',          fn() => view('mtschool::admin.bulletins.index'))->name('bulletins.index');
        Route::get('/bulletins/{id}',     fn($id) => view('mtschool::admin.bulletins.show', ['bulletinId' => $id]))->name('bulletins.show');

        // ── Présences ─────────────────────────────────────────────────────────
        Route::get('/presences',          fn() => view('mtschool::admin.presences.index'))->name('presences.index');
        Route::get('/presences/saisie',   fn() => view('mtschool::admin.presences.saisie'))->name('presences.saisie');

        // ── Finances ──────────────────────────────────────────────────────────
        Route::get('/frais',              fn() => view('mtschool::admin.frais.index'))->name('frais.index');
        Route::get('/paiements',          fn() => view('mtschool::admin.paiements.index'))->name('paiements.index');
        Route::get('/paiements/create',   fn() => view('mtschool::admin.paiements.form'))->name('paiements.create');

        // ── Communication ─────────────────────────────────────────────────────
        Route::get('/annonces',           fn() => view('mtschool::admin.annonces.index'))->name('annonces.index');
        Route::get('/agenda',             fn() => view('mtschool::admin.agenda.index'))->name('agenda.index');
        Route::get('/messagerie',         fn() => view('mtschool::admin.messagerie.index'))->name('messagerie.index');

        // ── Paramètres ────────────────────────────────────────────────────────
        Route::get('/parametres',         fn() => view('mtschool::admin.parametres.index'))->name('parametres.index');
        Route::get('/imports',            fn() => view('mtschool::admin.imports.index'))->name('imports.index');
    });
