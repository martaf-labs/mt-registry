<?php

/**_________________________________________________________________________________________
|                                                                                          |
|  Configuration du package MtSchool                                                       |
|  Gestion scolaire : de la maternelle au supérieur.                                       |
|  Toutes les valeurs peuvent être surchargées via les variables d'environnement (.env).   |
|__________________________________________________________________________________________|
*/

return [

    /*
    |--------------------------------------------------------------------------
    | Informations de l'établissement
    |--------------------------------------------------------------------------
    */
    'etablissement' => [
        'nom'       => env('SCHOOL_NOM', 'Mon École'),
        'sigle'     => env('SCHOOL_SIGLE', 'ME'),
        'devise'    => env('SCHOOL_DEVISE', 'XAF'), // ISO 4217 : XAF, EUR, USD…
        'logo'      => env('SCHOOL_LOGO', null),
        'adresse'   => env('SCHOOL_ADRESSE', null),
        'telephone' => env('SCHOOL_TEL', null),
        'email'     => env('SCHOOL_EMAIL', null),
        'site_web'  => env('SCHOOL_SITE', null),
        'pays'      => env('SCHOOL_PAYS', 'CM'), // ISO 3166-1 alpha-2
    ],

    /*
    |--------------------------------------------------------------------------
    | Système multilingue (optionnel)
    | Repose sur Mt\MtViews\Helpers\MtLocale et spatie/laravel-translatable
    |--------------------------------------------------------------------------
    */
    'multilingual' => [
        'enabled'  => env('SCHOOL_MULTILINGUAL', false),
        'locales'  => explode(',', env('SCHOOL_LOCALES', 'fr')), // ['fr','en','ar']
        'default'  => env('SCHOOL_DEFAULT_LOCALE', 'fr'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Cycle scolaire (détermine la logique des niveaux et bulletins)
    | Valeurs : 'classique' | 'lmd' | 'mixte'
    | - classique : maternelle → primaire → collège → lycée
    | - lmd       : Licence → Master → Doctorat (supérieur)
    | - mixte     : les deux
    |--------------------------------------------------------------------------
    */
    'cycle' => env('SCHOOL_CYCLE', 'classique'),

    /*
    |--------------------------------------------------------------------------
    | Paramètres de notation
    |--------------------------------------------------------------------------
    */
    'notation' => [
        'note_max'         => env('SCHOOL_NOTE_MAX', 20),
        'note_passage'     => env('SCHOOL_NOTE_PASSAGE', 10),
        'arrondi_decimales' => env('SCHOOL_ARRONDI', 2),
        // Système de notation : 'numerique' | 'lettre' | 'appréciation'
        'systeme'          => env('SCHOOL_SYSTEME_NOTATION', 'numerique'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Bulletins
    |--------------------------------------------------------------------------
    */
    'bulletin' => [
        // Nombre de séquences/périodes par trimestre
        'sequences_par_trimestre' => env('SCHOOL_SEQUENCES', 2),
        // Nombre de trimestres
        'trimestres'              => env('SCHOOL_TRIMESTRES', 3),
        // Afficher les appréciations
        'appreciation'            => env('SCHOOL_APPRECIATION', true),
        // Afficher le rang
        'rang'                    => env('SCHOOL_RANG', true),
        // Afficher l'effectif de la classe
        'effectif'                => env('SCHOOL_EFFECTIF', true),
        // Layout du bulletin : 'standard' | 'detaille' | 'compact'
        'layout'                  => env('SCHOOL_BULLETIN_LAYOUT', 'standard'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Inscriptions / Réinscriptions
    |--------------------------------------------------------------------------
    */
    'inscription' => [
        // Autoriser la réinscription en ligne
        'en_ligne'        => env('SCHOOL_INSCRIPTION_LIGNE', false),
        // Frais d'inscription requis avant validation
        'paiement_requis' => env('SCHOOL_INSCRIPTION_PAIEMENT', false),
        // Documents requis
        'documents'       => env('SCHOOL_INSCRIPTION_DOCS', true),
    ],

    /*
    |--------------------------------------------------------------------------
    | Présences / Absences
    |--------------------------------------------------------------------------
    */
    'presences' => [
        'enabled'             => env('SCHOOL_PRESENCES', true),
        // Seuil d'absentéisme en % pour déclencher une alerte
        'seuil_alerte'        => env('SCHOOL_ABSENCE_SEUIL', 20),
        // Notifier les parents par email
        'notifier_parents'    => env('SCHOOL_NOTIFIER_PARENTS', false),
    ],

    /*
    |--------------------------------------------------------------------------
    | Emplois du temps
    |--------------------------------------------------------------------------
    */
    'emploi_du_temps' => [
        'enabled'        => env('SCHOOL_EDT', true),
        // Durée d'un créneau en minutes
        'duree_creneau'  => env('SCHOOL_EDT_CRENEAU', 55),
        // Premier jour de la semaine (1=Lun, 7=Dim)
        'premier_jour'   => env('SCHOOL_EDT_PREMIER_JOUR', 1),
        // Jours d'école actifs (tableau d'entiers ISO)
        'jours_actifs'   => [1, 2, 3, 4, 5], // Lundi → Vendredi
    ],

    /*
    |--------------------------------------------------------------------------
    | Finances / Paiements
    |--------------------------------------------------------------------------
    */
    'finances' => [
        'enabled'          => env('SCHOOL_FINANCES', true),
        // Passerelles de paiement activées
        'passerelles'      => explode(',', env('SCHOOL_PASSERELLES', 'espece')),
        // Générer les reçus automatiquement
        'recus_auto'       => env('SCHOOL_RECUS_AUTO', true),
        // Activer les bourses
        'bourses'          => env('SCHOOL_BOURSES', false),
    ],

    /*
    |--------------------------------------------------------------------------
    | Communication (messagerie interne, annonces)
    |--------------------------------------------------------------------------
    */
    'communication' => [
        'messagerie'     => env('SCHOOL_MESSAGERIE', true),
        'annonces'       => env('SCHOOL_ANNONCES', true),
        'sms'            => env('SCHOOL_SMS', false),
        'email_notif'    => env('SCHOOL_EMAIL_NOTIF', true),
    ],

    /*
    |--------------------------------------------------------------------------
    | Rôles disponibles dans l'application
    | (s'appuient sur Spatie Permission via mt-views)
    |--------------------------------------------------------------------------
    */
    'roles' => [
        'super_admin'   => 'super_admin',
        'directeur'     => 'directeur',
        'censeur'       => 'censeur',
        'comptable'     => 'comptable',
        'enseignant'    => 'enseignant',
        'eleve'         => 'eleve',
        'parent'        => 'parent',
        'personnel'     => 'personnel',
    ],

    /*
    |--------------------------------------------------------------------------
    | Middleware à appliquer aux routes du package
    |--------------------------------------------------------------------------
    */
    'middleware' => ['web', 'auth'],

];
