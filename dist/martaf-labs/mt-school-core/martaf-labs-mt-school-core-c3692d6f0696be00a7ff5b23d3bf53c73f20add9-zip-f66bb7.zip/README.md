# 🏫 mt-school

**Package Laravel privé — Gestion scolaire complète**
De la maternelle au supérieur · Laravel 12 · Livewire 3 · Multilingue optionnel

> Partie de l'écosystème **mt/\*** — requiert `mt/mt-views` comme fondation.

---

## Sommaire

- [Présentation](#présentation)
- [Prérequis & Dépendances](#prérequis--dépendances)
- [Installation](#installation)
- [Configuration](#configuration)
- [Architecture générale](#architecture-générale)
- [Base de données — 60 tables](#base-de-données--60-tables)
- [Modèles Eloquent](#modèles-eloquent)
- [Enums](#enums)
- [ServiceProvider](#serviceprovider)
- [Système multilingue](#système-multilingue)
- [Composants Livewire](#composants-livewire)
- [Composants Blade](#composants-blade)
- [Directives Blade](#directives-blade)
- [Helpers](#helpers)
- [Events & Listeners](#events--listeners)
- [Services](#services)
- [Morph Map](#morph-map)
- [Publication des assets](#publication-des-assets)
- [Roadmap](#roadmap)

---

## Présentation

`mt-school` est un package Laravel qui centralise toute la logique métier pour les applications de gestion scolaire, de la maternelle au supérieur.

### Ce qu'il couvre

| Domaine | Fonctionnalités |
|---------|----------------|
| **Structure** | Cycles, niveaux, filières, classes, salles, bâtiments |
| **Calendrier** | Années scolaires, périodes (trimestres/séquences/semestres), congés |
| **Personnel** | Enseignants, administratifs, direction, feuilles de service |
| **Apprenants** | Élèves, parents/tuteurs, inscriptions annuelles |
| **Pédagogie** | Matières, programmes, emplois du temps, ressources, devoirs |
| **Évaluation** | Évaluations, notes, moyennes, bulletins, conseils de classe |
| **Présences** | Saisie présences, absences, justifications, alertes parents |
| **Finances** | Frais scolaires, barèmes, échéances, paiements, bourses |
| **Communication** | Annonces, messagerie interne, agenda partagé |
| **Discipline** | Sanctions, conseils de classe, PV |
| **Documents** | Certificats de scolarité, attestations, relevés |
| **Système** | Paramètres, notifications, imports/exports batch |
| **Modules opt.** | Cantine, stock matériel |

### Principe fondamental — L'année scolaire est centrale

```
AnneeScolaire
    ├── Periode (Trimestre 1)
    │     └── Periode (Séquence 1, Séquence 2)
    ├── Classe (6e A)
    │     └── Inscription (Élève X → 6e A → 2024-2025)  ← NŒUD CENTRAL
    │           ├── Notes
    │           ├── Presences
    │           ├── Bulletins
    │           └── FraisScolaires
    └── Programme (Tle S 2024-2025)
          └── Matiere + coefficient
```

> ⭐ **`Inscription`** est le nœud central : il lie un `Eleve`, une `Classe` et une `AnneeScolaire`.
> Toutes les notes, présences, bulletins et frais s'y attachent.

---

## Prérequis & Dépendances

```json
{
    "php": "^8.1",
    "laravel/framework": "^12.0",
    "mt/mt-views": "*",
    "livewire/livewire": "^3.0",
    "spatie/laravel-permission": "^6.0"
}
```

`mt/mt-views` fournit :
- `MtBaseModel` — base avec SoftDeletes, TracksUser, HasReference, LogActivityAction, HasMultilingualFormatter
- `BaseUser` — utilisateur avec pattern morphable `userable`
- `Blueprint::macro('tracksUser')` — colonnes `created_by`, `updated_by`, `deleted_by`
- `MtLocale` — gestion du multilinguisme (`fr`, `en`, `ar`)

---

## Installation

### 1. Ajouter le dépôt dans `composer.json`

```json
{
    "repositories": [
        {
            "type": "path",
            "url": "../packages/mt-school"
        }
    ],
    "require": {
        "mt/school": "*"
    }
}
```

### 2. Installer

```bash
composer require mt/school
```

### 3. Publier la configuration

```bash
php artisan vendor:publish --tag=mtschool-config
```

### 4. Lancer les migrations

```bash
php artisan migrate
```

### 5. Publier les assets

```bash
php artisan vendor:publish --tag=mtschool-assets
```

### Tout publier en une commande

```bash
php artisan vendor:publish --tag=mtschool
```

---

## Configuration

```php
// config/mtschool.php

return [

    'etablissement' => [
        'nom'    => env('SCHOOL_NOM', 'Mon École'),
        'devise' => env('SCHOOL_DEVISE', 'XAF'),
        'pays'   => env('SCHOOL_PAYS', 'CM'),
    ],

    'multilingual' => [
        'enabled' => env('SCHOOL_MULTILINGUAL', false),
        'locales' => ['fr', 'en', 'ar'],
        'default' => 'fr',
    ],

    'cycle' => env('SCHOOL_CYCLE', 'classique'), // 'classique' | 'lmd' | 'mixte'

    'notation' => [
        'note_max'     => 20,
        'note_passage' => 10,
    ],

    'bulletin' => [
        'sequences_par_trimestre' => 2,
        'trimestres'              => 3,
        'appreciation'            => true,
        'rang'                    => true,
        'layout'                  => 'standard',
    ],

    'finances' => [
        'enabled'    => true,
        'passerelles'=> ['espece', 'mobile_money'],
        'bourses'    => false,
    ],

    'presences' => [
        'enabled'          => true,
        'seuil_alerte'     => 20,
        'notifier_parents' => false,
    ],
];
```

### Variables `.env`

```dotenv
SCHOOL_NOM="Lycée Bilingue de la Réussite"
SCHOOL_SIGLE=LBR
SCHOOL_DEVISE=XAF
SCHOOL_PAYS=CM
SCHOOL_MULTILINGUAL=true
SCHOOL_LOCALES=fr,en
SCHOOL_CYCLE=classique
SCHOOL_NOTE_MAX=20
SCHOOL_NOTE_PASSAGE=10
```

---

## Architecture générale

```
mt-school/
├── config/
│   └── mtschool.php
├── database/
│   └── migrations/
│       ├── mt_school_2026_00_01_000000_create_all_tables.php  ← consolidée (60 tables)
│       └── ...                                                 ← 21 fichiers individuels
├── lang/
│   ├── fr/ ├── en/ └── ar/
├── public/assets/
│   ├── css/  mtschool.css · bulletin.css
│   └── js/   mtschool.js
├── resources/views/
│   ├── components/     ← Composants Blade anonymes <x-mtschool::...>
│   └── livewire/       ← Vues Livewire par portail
│       ├── admin/
│       ├── enseignant/
│       ├── eleve/
│       ├── parent/
│       └── shared/
├── routes/web.php
└── src/
    ├── MtSchoolServiceProvider.php
    ├── Contracts/
    ├── Enums/          (19 enums)
    ├── Events/
    ├── Helpers/helpers.php
    ├── Listeners/
    ├── Livewire/
    ├── Models/         (35 fichiers · 45+ classes)
    ├── Services/
    └── Support/
```

---

## Base de données — 60 tables

### Vue d'ensemble par domaine

| # | Domaine | Tables |
|---|---------|--------|
| 1 | **Calendrier scolaire** | `annees_scolaires`, `periodes`, `periodes_conges` |
| 2 | **Structure académique** | `cycles`, `niveaux`, `filieres`, `niveau_filiere` |
| 3 | **Infrastructure** | `batiments`, `salles` |
| 4 | **Classes & Groupes** | `classes`, `groupes_td`, `groupe_td_inscription` |
| 5 | **Programmes & Matières** | `matieres`, `programmes`, `programme_matiere` |
| 6 | **Personnel** | `personnels`, `enseignants`, `enseignant_matiere`, `attributions_cours` |
| 7 | **Emploi du temps** | `emplois_du_temps`, `creneaux`, `exceptions_edt` |
| 8 | **Élèves & Familles** | `eleves`, `parents_tuteurs`, `eleve_parent` |
| 9 | **Inscriptions** ⭐ | `inscriptions` |
| 10 | **Évaluation** | `evaluations`, `notes` |
| 11 | **Résultats** | `moyennes_matieres`, `moyennes_periodes`, `bulletins` |
| 12 | **Présences** | `presences`, `justifications_absence` |
| 13 | **Finances** | `types_frais`, `baremes_frais`, `frais_scolaires`, `echeances`, `paiements`, `bourses` |
| 14 | **Communication** | `annonces`, `annonce_lectures`, `conversations`, `conversation_participants`, `messages`, `evenements_agenda` |
| 15 | **Discipline** | `sanctions`, `conseils_classe`, `conseil_participants` |
| 16 | **Pédagogie numérique** | `ressources_pedagogiques`, `devoirs_maison`, `soumissions_devoirs` |
| 17 | **Documents officiels** | `certificats_scolarite` |
| 18 | **Système** | `parametres_school`, `notifications_school`, `imports_exports` |
| 19 | **Modules optionnels** | `menus_cantine`, `inscriptions_cantine`, `reservations_repas`, `stock_materiel`, `mouvements_stock` |

### Ordre de création strict (dépendances FK)

```
01. annees_scolaires          ← RACINE ABSOLUE
02. periodes                  → annees_scolaires (+ auto-ref parent_id)
03. cycles
04. niveaux                   → cycles
05. filieres
06. niveau_filiere            [pivot]
07. batiments
08. salles                    → batiments
09. classes                   → annees_scolaires, niveaux, filieres, salles
10. matieres
11. programmes                → annees_scolaires, niveaux, filieres
12. programme_matiere         [pivot enrichi : coefficient, volume_horaire, est_eliminatoire]
13. personnels
14. enseignants               → personnels, matieres
15. enseignant_matiere        [pivot]
16. attributions_cours        → annees_scolaires, enseignants, classes, matieres
17. emplois_du_temps          → annees_scolaires, classes
18. creneaux                  → emplois_du_temps, attributions_cours, matieres, salles
19. exceptions_edt            → creneaux, salles
20. eleves
21. parents_tuteurs
22. eleve_parent              [pivot enrichi : lien_parente, est_contact_principal]
23. inscriptions ⭐           → annees_scolaires, eleves, classes
24. evaluations               → annees_scolaires, periodes, classes, matieres
25. notes                     → evaluations, inscriptions
26. moyennes_matieres         → inscriptions, periodes, matieres
27. moyennes_periodes         → inscriptions, periodes
28. bulletins                 → inscriptions, periodes, moyennes_periodes
29. presences                 → inscriptions, creneaux
30. justifications_absence    → inscriptions
    ↑ FK circulaire ajoutée après création des deux tables
31–36. [finances]
37–42. [communication]
43–45. [discipline]
46–51. [pédagogie & système]
52–60. [documents, groupes, conges, modules optionnels]
```

---

## Modèles Eloquent

### Conventions communes

```php
// Tous les modèles principaux étendent MtBaseModel
class Inscription extends MtBaseModel
{
    // Champs traduits JSON
    protected array $translatables = ['libelle'];

    // Enums typés dans les casts
    protected $casts = [
        'statut' => StatutInscription::class,
    ];

    // Colonnes indexées pour la recherche globale
    protected static array $searchableColumns = ['reference'];
}

// Modèles légers (pivots enrichis, tables sans SoftDelete)
class Note extends Model
{
    use TracksUser; // seulement created_by, updated_by, deleted_by
}
```

### Exemples d'utilisation

```php
// Année scolaire active
$annee = AnneeScolaire::courante();

// Inscrire un élève
$inscription = Inscription::create([
    'annee_scolaire_id' => $annee->id,
    'eleve_id'          => $eleve->id,
    'classe_id'         => $classe->id,
    'statut'            => StatutInscription::EN_ATTENTE,
]);

// Valider l'inscription (recalcule l'effectif de la classe)
$inscription->valider(auth()->id());

// Classe actuelle d'un élève
$classe = $eleve->classeActuelle();

// Saisir une note
Note::updateOrCreate(
    ['evaluation_id' => $eval->id, 'inscription_id' => $inscription->id],
    ['note' => 15.5, 'appreciation' => 'Bon travail']
);

// Bulletin publié
$bulletin->publier(); // statut → 'publie', visible_portail → true

// Paramètre dynamique
ParametreSchool::get('note_passage', 10);
ParametreSchool::set('pied_page_bulletin_fr', 'Cachet et Signature du Directeur');

// Mention depuis une moyenne
$mention = Mention::fromMoyenne(14.75); // → Mention::BIEN
```

---

## Enums

19 enums PHP 8.1+ couvrant tous les statuts, types et rôles.
Chaque enum expose `label()`, `badge()`, `options()`.

```php
use Mt\School\Enums\Mention;
use Mt\School\Enums\StatutInscription;
use Mt\School\Enums\RoleSchool;

// Mention depuis une moyenne
Mention::fromMoyenne(16.5)->label();  // "Très Bien"
Mention::fromMoyenne(16.5)->badge();  // "primary"

// Liste pour un <select>
StatutInscription::options();
// ['en_attente' => 'En attente', 'validee' => 'Validée', ...]

// Vérifier les permissions d'un rôle
RoleSchool::ENSEIGNANT->peutGererNotes();   // true
RoleSchool::PARENT->peutVoirFinances();     // false
RoleSchool::COMPTABLE->peutVoirFinances();  // true
```

| Enum | Valeurs principales |
|------|-------------------|
| `StatutInscription` | `en_attente` · `validee` · `rejetee` · `annulee` · `transferee` |
| `ResultatInscription` | `admis` · `redouble` · `oriente` · `exclu` · `abandonne` |
| `TypeCycle` | `prescolaire` · `primaire` · `secondaire` · `superieur` |
| `TypePeriode` | `trimestre` · `semestre` · `sequence` · `annuel` |
| `StatutEvaluation` | `planifiee` · `en_cours` · `corrigee` · `saisie` · `validee` |
| `TypeEvaluation` | `devoir` · `examen` · `controle` · `tp` · `oral` · `projet` |
| `Mention` | `Excellent` · `Très Bien` · `Bien` · `Assez Bien` · `Passable` · `Insuffisant` |
| `StatutBulletin` | `brouillon` · `genere` · `valide` · `publie` · `archive` |
| `StatutPresence` | `present` · `absent` · `retard` · `exclusion` |
| `TypePersonnel` | `enseignant` · `administratif` · `technique` · `direction` |
| `StatutContrat` | `titulaire` · `vacataire` · `contractuel` · `stagiaire` |
| `StatutFrais` | `en_attente` · `partiel` · `solde` · `exonere` · `annule` |
| `ModePaiement` | `espece` · `virement` · `cheque` · `mobile_money` · `carte` |
| `RoleSchool` | `super_admin` · `directeur` · `censeur` · `comptable` · `enseignant` · `eleve` · `parent` |
| `TypeSanction` | `avertissement` · `blame` · `exclusion_temp` · `exclusion_def` |
| `LienParente` | `pere` · `mere` · `tuteur` · `grand_parent` · `frere_soeur` |
| `JourSemaine` | `1=Lundi` … `7=Dimanche` |
| `TypeCreneau` | `cours` · `td` · `tp` · `examen` · `permanence` · `pause` |
| `GroupeDisciplinaire` | `litteraire` · `scientifique` · `technique` · `sportif` · `artistique` |

---

## ServiceProvider

`MtSchoolServiceProvider` s'auto-découvre via `composer.json`.

```
register()
  ├── mergeConfigFrom(mtschool.php)
  ├── singleton(AnneeScolaireResolver)  → alias 'mt-school.annee'
  ├── singleton(ReferenceSchoolService)
  ├── singleton(MoyenneService)         → alias 'mt-school.moyennes'
  └── singleton(BulletinService)        → alias 'mt-school.bulletins'

boot()
  ├── loadHelpers()               src/Helpers/helpers.php
  ├── loadMigrations()            database/migrations/
  ├── loadViews()                 namespace 'mtschool'
  ├── loadTranslations()          namespace 'mtschool'
  ├── registerBladeComponents()   <x-mtschool::*>
  ├── registerBladeDirectives()   @mtschoolAssets · @school() · @moduleEnabled()
  ├── registerLivewireComponents() mtschool.admin.* · mtschool.eleve.* · ...
  ├── registerEvents()            InscriptionValidee · BulletinPublie · ...
  ├── registerMorphMap()          eleve · parent_tuteur · personnel · ...
  └── registerPublishing()        vendor:publish --tag=mtschool*
```

---

## Système multilingue

Optionnel. Activé via `SCHOOL_MULTILINGUAL=true`.

### Champs traduits JSON

```php
// Tous les libellés sensibles sont JSON multilingue
// {"fr":"Sixième A","en":"Year 7A","ar":"السادسة أ"}

$classe->libelle;   // "Sixième A" si locale active = fr
                    // "Year 7A"   si locale active = en
```

### Directive conditionnelle

```blade
@multilingualEnabled
    <livewire:mtschool.shared.locale-switcher />
@endmultilingualEnabled
```

### Fichiers de traduction

```
lang/
├── fr/mtschool.php   __('mtschool::messages.inscription_validee')
├── en/mtschool.php
└── ar/mtschool.php
```

---

## Composants Livewire

90+ composants organisés en 5 portails. Préfixe : `mtschool.`

### Administration

```blade
<livewire:mtschool.admin.eleves.index />
<livewire:mtschool.admin.inscriptions.form />
<livewire:mtschool.admin.notes.saisie :classe="$classe" :evaluation="$eval" />
<livewire:mtschool.admin.bulletins.generateur :classe="$classe" :periode="$periode" />
<livewire:mtschool.admin.presences.saisie :classe="$classe" />
<livewire:mtschool.admin.paiements.form :inscription="$inscription" />
<livewire:mtschool.admin.edt.grille :classe="$classe" />
```

### Portail Enseignant

```blade
<livewire:mtschool.enseignant.mes-classes />
<livewire:mtschool.enseignant.saisie-notes :evaluation="$evaluation" />
<livewire:mtschool.enseignant.presences :classe="$classe" />
<livewire:mtschool.enseignant.edt />
```

### Portail Élève

```blade
<livewire:mtschool.eleve.mes-notes />
<livewire:mtschool.eleve.mes-bulletins />
<livewire:mtschool.eleve.mon-edt />
<livewire:mtschool.eleve.mes-absences />
<livewire:mtschool.eleve.mes-frais />
```

### Portail Parent

```blade
<livewire:mtschool.parent.mes-enfants />
<livewire:mtschool.parent.bulletins />
<livewire:mtschool.parent.paiements />
<livewire:mtschool.parent.justifier />
```

### Dashboards

```blade
<livewire:mtschool.dashboard.admin />
<livewire:mtschool.dashboard.enseignant />
<livewire:mtschool.dashboard.eleve />
<livewire:mtschool.dashboard.parent />
```

---

## Composants Blade

Composants anonymes `<x-mtschool::...>` :

```blade
<x-mtschool::badge-statut :statut="$inscription->statut" />
<x-mtschool::card-eleve :eleve="$eleve" />
<x-mtschool::card-bulletin :bulletin="$bulletin" />
<x-mtschool::mention :mention="$moyennePeriode->mention" />
<x-mtschool::indicateur-frais :frais="$fraisScolaire" />
<x-mtschool::grille-edt :emploiDuTemps="$edt" />
```

---

## Directives Blade

```blade
{{-- CSS + JS du package --}}
@mtschoolAssets

{{-- CSS impression bulletins --}}
@mtschoolBulletinAssets

{{-- Libellé de l'année active --}}
@anneeActive  {{-- → "2024-2025" --}}

{{-- Paramètre établissement --}}
@school('nom')   {{-- → "Lycée Bilingue de la Réussite" --}}

{{-- Bloc conditionnel par module --}}
@moduleEnabled('finances')
    <livewire:mtschool.admin.paiements.index />
@endmoduleEnabled

{{-- Bloc conditionnel multilinguisme --}}
@multilingualEnabled
    <livewire:mtschool.shared.locale-switcher />
@endmultilingualEnabled
```

---

## Helpers

```php
mtschool_config('notation.note_passage')  // → 10
annee_scolaire_active()                   // → AnneeScolaire|null
periode_active()                          // → Periode|null
format_note(14.5)                         // → "14,50 / 20"
mention_from_moyenne(15.75)               // → "Bien"
module_active('finances')                 // → bool
school_nom()                              // → "Lycée Bilingue de la Réussite"
school_devise()                           // → "XAF"
generer_reference('INS')                  // → "INS-2024-00001"
```

---

## Events & Listeners

| Event | Déclenché quand | Listener par défaut |
|-------|----------------|-------------------|
| `InscriptionValidee` | Inscription validée | `RecalculerEffectifClasse` |
| `AbsenceEnregistree` | Absence saisie | `NotifierParentAbsence` |
| `BulletinPublie` | Bulletin publié | `NotifierBulletinDisponible` |
| `PaiementRecu` | Paiement confirmé | `NotifierPaiementConfirme` |
| `NotesSaisies` | Notes saisies | *(extensible)* |

### Écouter dans l'application hôte

```php
// AppServiceProvider::boot()
use Mt\School\Events\BulletinPublie;

Event::listen(BulletinPublie::class, function ($event) {
    // $event->bulletin  $event->inscription  $event->eleve
    Mail::to($event->eleve->parentsTuteurs->first()->email)
        ->send(new BulletinDisponibleMail($event->bulletin));
});
```

---

## Services

```php
// MoyenneService
$service = app('mt-school.moyennes');
$service->calculerPourClasse($classe, $periode);
$service->calculerPourInscription($inscription, $periode);
$service->calculerRangs($classe, $periode);

// BulletinService
$service = app('mt-school.bulletins');
$service->genererPourClasse($classe, $periode);
$service->genererPourInscription($inscription, $periode);
$service->publier($bulletin);

// ReferenceSchoolService
$service = app(\Mt\School\Services\ReferenceSchoolService::class);
$service->generer('INS', $annee->code);  // "INS-2024-00001"
$service->generer('PAY');                // "PAY-2024-00001"

// AnneeScolaireResolver
$resolver = app('mt-school.annee');
$resolver->courante();    // AnneeScolaire|null
$resolver->labelActif();  // "2024-2025"
```

---

## Morph Map

```php
// En base de données :
//   userable_type = 'eleve'          (au lieu de 'Mt\School\Models\Eleve')
//   notifiable_type = 'bulletin'     (au lieu de 'Mt\School\Models\Bulletin')

Relation::morphMap([
    'eleve'         => Eleve::class,
    'parent_tuteur' => ParentTuteur::class,
    'personnel'     => Personnel::class,
    'enseignant'    => Enseignant::class,
    'inscription'   => Inscription::class,
    'bulletin'      => Bulletin::class,
    'paiement'      => Paiement::class,
    'evaluation'    => Evaluation::class,
    'devoir_maison' => DevoirMaison::class,
    'annonce'       => Annonce::class,
    'classe'        => Classe::class,
    'salle'         => Salle::class,
]);
```

> Merge non-enforced (`false`) — ne remplace pas les morphMaps de l'application hôte.

---

## Publication des assets

```bash
php artisan vendor:publish --tag=mtschool-views       # Vues
php artisan vendor:publish --tag=mtschool-lang         # Traductions
php artisan vendor:publish --tag=mtschool-config       # Configuration
php artisan vendor:publish --tag=mtschool-assets       # CSS / JS
php artisan vendor:publish --tag=mtschool-migrations   # Migrations
php artisan vendor:publish --tag=mtschool              # Tout
```

```blade
{{-- Dans layouts/app.blade.php --}}
<head>
    @mtschoolAssets
</head>
```

---

## Roadmap

### v0.1 — Fondations ✅
- [x] 60 tables — migrations complètes + fichier consolidé
- [x] 35 fichiers modèles · 45+ classes Eloquent
- [x] 19 Enums PHP 8.1+
- [x] ServiceProvider complet (Livewire 3, Blade, Assets, Events, MorphMap)
- [x] Multilinguisme optionnel (fr / en / ar)
- [x] Helpers, Services, Contracts

### v0.2 — Interface Admin
- [ ] Composants Livewire Admin (CRUD complet)
- [ ] Saisie notes en tableau
- [ ] Générateur bulletins

### v0.3 — Portails
- [ ] Portail Enseignant
- [ ] Portail Élève & Parent
- [ ] Composants Blade anonymes

### v0.4 — Documents & Exports
- [ ] PDF bulletins (DomPDF / Browsershot)
- [ ] QR Code vérification certificats
- [ ] Export Excel (notes, paiements, élèves)

### v0.5 — Imports batch
- [ ] Import élèves CSV/Excel
- [ ] Import notes depuis Excel
- [ ] Rapport d'erreurs

### v1.0 — Production
- [ ] Tests Feature complets
- [ ] Documentation API interne
- [ ] Seeders de démonstration

### v2.0 — Supérieur (LMD)
- [ ] Gestion UE / ECTS / crédits
- [ ] Délibérations
- [ ] PV de jury
- [ ] Relevés de notes LMD

---

## Auteur

**Djoukeng Brice Marcello**
Package privé — Écosystème `mt/*`
Laravel 12 · Livewire 3 · PHP 8.1+

---

*mt-school v0.1.0-dev — Mai 2026*
