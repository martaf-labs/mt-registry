<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : menus_cantine | inscriptions_cantine | stock_materiel | mouvements_stock
 * ──────────────────────────────────────────────────────────────────────────────────
 *
 * Ces modules sont OPTIONNELS — activables via config('mtschool.modules').
 * Les tables sont créées uniquement si le module est activé,
 * mais la migration elle-même est toujours chargée par le ServiceProvider.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * MODULE RESTAURATION (cantine)
 * ─────────────────────────────
 * MENU_CANTINE : planning des repas par jour/semaine, avec prix.
 *   Multilingue pour les noms de plats si établissement multilingue.
 *
 * INSCRIPTION_CANTINE : abonnement d'un élève au service de restauration.
 *   Lié à l'inscription scolaire (= élève + année).
 *   Peut être journalier, hebdomadaire ou annuel.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * MODULE STOCK MATÉRIEL
 * ─────────────────────
 * STOCK_MATERIEL : inventaire du matériel de l'établissement.
 *   Mobilier, matériel informatique, livres, fournitures, équipements sportifs…
 *
 * MOUVEMENT_STOCK : entrées/sorties/affectations du matériel.
 *   Traçabilité complète : qui a pris quoi, quand, rendu quand.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ══════════════════════════════════════════════════════════════════════
        // MODULE RESTAURATION
        // ══════════════════════════════════════════════════════════════════════

        if (!Schema::hasTable('menus_cantine')) {
            Schema::create('menus_cantine', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->cascadeOnDelete();

                // Libellé multilingue du repas
                $table->json('libelle');           // {'fr':'Poulet rôti + Riz','en':'Roast chicken + Rice'}
                $table->json('description')->nullable();

                $table->date('date');
                // 'petit_dejeuner' | 'dejeuner' | 'gouter' | 'diner'
                $table->string('type_repas')->default('dejeuner');

                $table->decimal('prix', 10, 2)->default(0);
                $table->string('devise', 3)->default('XAF');

                // Nombre de repas disponibles (0 = illimité)
                $table->unsignedInteger('capacite')->default(0);
                $table->unsignedInteger('reservations_count')->default(0);

                // Informations nutritionnelles / allergènes
                $table->json('allergenes')->nullable();    // ['gluten','lactose',…]
                $table->json('valeurs_nutritives')->nullable();

                $table->boolean('actif')->default(true);

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['annee_scolaire_id', 'date', 'type_repas'], 'menu_unique');
            });
        }

        if (!Schema::hasTable('inscriptions_cantine')) {
            Schema::create('inscriptions_cantine', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique();

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();

                // Type d'abonnement : 'annuel' | 'trimestriel' | 'mensuel' | 'hebdomadaire' | 'journalier'
                $table->string('type_abonnement')->default('mensuel');

                // Jours de repas souhaités (si pas tous les jours)
                // Ex : [1, 2, 3, 4, 5] = Lun-Ven
                $table->json('jours_actifs')->nullable();

                $table->string('type_repas')->default('dejeuner');

                $table->decimal('montant', 10, 2)->default(0);
                $table->string('devise', 3)->default('XAF');

                $table->date('date_debut');
                $table->date('date_fin')->nullable();

                // 'actif' | 'suspendu' | 'resilie' | 'expire'
                $table->string('statut')->default('actif')->index();

                // Régime alimentaire particulier
                $table->string('regime')->nullable(); // 'normal' | 'vegetarien' | 'sans_gluten' | 'halal'

                $table->text('observations')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // Réservations de repas (optionnel — si menu journalier avec réservation)
        if (!Schema::hasTable('reservations_repas')) {
            Schema::create('reservations_repas', function (Blueprint $table) {
                $table->id();

                $table->foreignId('inscription_cantine_id')->constrained('inscriptions_cantine')->cascadeOnDelete();
                $table->foreignId('menu_cantine_id')->constrained('menus_cantine')->cascadeOnDelete();

                $table->date('date');
                // 'reservee' | 'consommee' | 'absente' | 'annulee'
                $table->string('statut')->default('reservee');

                $table->decimal('prix_paye', 10, 2)->nullable();
                $table->timestamp('pointe_at')->nullable();

                $table->timestamps();
                $table->unique(['inscription_cantine_id', 'menu_cantine_id', 'date'], 'reservation_unique');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // MODULE STOCK MATÉRIEL
        // ══════════════════════════════════════════════════════════════════════

        if (!Schema::hasTable('stock_materiel')) {
            Schema::create('stock_materiel', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique(); // MAT-00001

                // Libellé multilingue
                $table->json('libelle');           // {'fr':'Ordinateur portable','en':'Laptop'}
                $table->json('description')->nullable();

                // Catégorie : 'informatique' | 'mobilier' | 'livre' | 'fourniture'
                //             | 'sport' | 'science' | 'audiovisuel' | 'autre'
                $table->string('categorie')->default('autre')->index();

                $table->string('marque')->nullable();
                $table->string('modele')->nullable();
                $table->string('numero_serie')->nullable()->unique();

                // Stock
                $table->unsignedInteger('quantite_totale')->default(1);
                $table->unsignedInteger('quantite_disponible')->default(1);
                $table->unsignedInteger('quantite_affectee')->default(0);
                $table->unsignedInteger('quantite_hors_service')->default(0);

                // Localisation par défaut
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();

                $table->decimal('valeur_unitaire', 12, 2)->nullable();
                $table->string('devise', 3)->default('XAF');

                $table->date('date_acquisition')->nullable();
                $table->date('date_fin_garantie')->nullable();

                // 'bon' | 'use' | 'a_reparer' | 'hors_service'
                $table->string('etat')->default('bon');

                $table->boolean('actif')->default(true);
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('mouvements_stock')) {
            Schema::create('mouvements_stock', function (Blueprint $table) {
                $table->id();

                $table->foreignId('stock_materiel_id')->constrained('stock_materiel')->cascadeOnDelete();

                // Type : 'entree' | 'sortie' | 'affectation' | 'retour' | 'perte' | 'reparation'
                $table->string('type')->default('sortie')->index();

                $table->unsignedInteger('quantite')->default(1);

                $table->date('date_mouvement');
                $table->date('date_retour_prevue')->nullable();
                $table->date('date_retour_effective')->nullable();

                // Bénéficiaire (polymorphe : personnel, enseignant, classe, salle…)
                $table->string('beneficiaire_type')->nullable();
                $table->unsignedBigInteger('beneficiaire_id')->nullable();
                $table->index(['beneficiaire_type', 'beneficiaire_id']);

                // Salle de destination
                $table->foreignId('salle_destination_id')->nullable()->constrained('salles')->nullOnDelete();

                // 'en_cours' | 'retourne' | 'perdu' | 'hors_service'
                $table->string('statut')->default('en_cours');

                $table->text('motif')->nullable();
                $table->text('observations')->nullable();

                // Signataires
                $table->unsignedBigInteger('remis_par')->nullable();
                $table->unsignedBigInteger('recu_par')->nullable();

                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('mouvements_stock');
        Schema::dropIfExists('stock_materiel');
        Schema::dropIfExists('reservations_repas');
        Schema::dropIfExists('inscriptions_cantine');
        Schema::dropIfExists('menus_cantine');
    }
};
