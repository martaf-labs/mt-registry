<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : sanctions | conseils_classe
 * ──────────────────────────────────────
 *
 * SANCTION : mesure disciplinaire prise à l'encontre d'un élève.
 *   Ex : avertissement, renvoi temporaire, exclusion définitive, punition…
 *   Consignée et archivée dans le dossier de l'élève.
 *
 * CONSEIL_CLASSE : réunion formelle des enseignants d'une classe
 *   à la fin d'une période. Produit des décisions (résultats validés).
 *   Lie la moyenne_periode à un PV officiel.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Sanctions disciplinaires ──────────────────────────────────────────
        if (!Schema::hasTable('sanctions')) {
            Schema::create('sanctions', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique();

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();

                // Type : 'avertissement' | 'blame' | 'exclusion_temp' | 'exclusion_def'
                //        | 'punition' | 'convocation_parent' | 'autre'
                $table->string('type')->default('avertissement');

                // Libellé multilingue
                $table->json('libelle')->nullable();
                $table->text('motif');

                $table->date('date_sanction');
                $table->date('date_fin')->nullable();    // Pour les exclusions temporaires

                // Prononcée par
                $table->unsignedBigInteger('prononcee_par')->nullable();

                // 'en_cours' | 'levee' | 'archive'
                $table->string('statut')->default('en_cours');

                // Parent informé
                $table->boolean('parent_informe')->default(false);
                $table->timestamp('parent_informe_at')->nullable();

                $table->text('suite_donnee')->nullable(); // Ex : "Admission après entretien"
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Conseils de classe ────────────────────────────────────────────────
        if (!Schema::hasTable('conseils_classe')) {
            Schema::create('conseils_classe', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();

                // Libellé multilingue du PV
                $table->json('titre')->nullable();

                $table->dateTime('date_conseil');
                $table->string('lieu')->nullable();

                // 'planifie' | 'tenu' | 'pv_redige' | 'valide'
                $table->string('statut')->default('planifie');

                // Président de séance (généralement le directeur/censeur)
                $table->unsignedBigInteger('president_id')->nullable();

                // PV en JSON ou fichier
                $table->longText('pv_contenu')->nullable();
                $table->string('pv_fichier')->nullable();

                $table->timestamp('valide_at')->nullable();
                $table->unsignedBigInteger('valide_par')->nullable();

                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['classe_id', 'periode_id'], 'conseil_unique');
            });
        }

        // ── Participants aux conseils ──────────────────────────────────────────
        if (!Schema::hasTable('conseil_participants')) {
            Schema::create('conseil_participants', function (Blueprint $table) {
                $table->id();
                $table->foreignId('conseil_classe_id')->constrained('conseils_classe')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id');
                $table->string('role_conseil')->nullable(); // 'president' | 'secretaire' | 'membre'
                $table->boolean('present')->default(true);
                $table->boolean('a_signe')->default(false);
                $table->timestamps();
                $table->unique(['conseil_classe_id', 'user_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('conseil_participants');
        Schema::dropIfExists('conseils_classe');
        Schema::dropIfExists('sanctions');
    }
};
