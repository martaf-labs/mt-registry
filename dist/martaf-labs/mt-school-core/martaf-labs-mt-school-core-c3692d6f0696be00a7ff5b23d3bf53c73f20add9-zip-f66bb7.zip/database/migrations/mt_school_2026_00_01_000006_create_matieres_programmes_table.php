<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : matieres | programmes | programme_matiere
 * ────────────────────────────────────────────────────
 *
 * MATIERE : une discipline enseignée (Mathématiques, Français, SVT…)
 *   Multilingue. Indépendante de l'année scolaire.
 *
 * PROGRAMME : ensemble de matières attribuées à un niveau/filière pour
 *   une année scolaire précise, avec les coefficients.
 *   Ex : "Programme Terminale S 2024-2025"
 *
 * PROGRAMME_MATIERE (pivot) : lien entre programme et matière, avec :
 *   - coefficient
 *   - volume horaire hebdomadaire
 *   - est-elle éliminatoire ?
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Matières ─────────────────────────────────────────────────────────
        if (!Schema::hasTable('matieres')) {
            Schema::create('matieres', function (Blueprint $table) {
                $table->id();

                // Multilingue : {'fr':'Mathématiques','en':'Mathematics','ar':'الرياضيات'}
                $table->json('libelle');
                $table->string('code')->unique();         // 'MATH','FR','PHYS','INFO'
                $table->string('abreviation')->nullable(); // 'Maths', 'Fr.'

                // Groupe disciplinaire (pour l'affichage bulletin)
                // 'litteraire' | 'scientifique' | 'technique' | 'sportif' | 'artistique' | 'autre'
                $table->string('groupe')->default('autre');

                $table->string('couleur')->default('#6366f1');
                $table->string('icone')->nullable();
                $table->boolean('actif')->default(true);
                $table->boolean('est_principale')->default(false); // Matière fondamentale
                $table->text('description')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Programmes ───────────────────────────────────────────────────────
        if (!Schema::hasTable('programmes')) {
            Schema::create('programmes', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('niveau_id')->constrained('niveaux')->restrictOnDelete();
                $table->foreignId('filiere_id')->nullable()->constrained('filieres')->nullOnDelete();

                // Libellé multilingue
                $table->json('libelle');            // {'fr':'Programme Tle S 2024-2025'}
                $table->string('code');             // 'PROG-TLE-S-2024'
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['annee_scolaire_id', 'niveau_id', 'filiere_id', 'code'], 'prog_unique');
            });
        }

        // ── Table pivot : programme_matiere ───────────────────────────────────
        if (!Schema::hasTable('programme_matiere')) {
            Schema::create('programme_matiere', function (Blueprint $table) {
                $table->id();

                $table->foreignId('programme_id')->constrained('programmes')->cascadeOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();

                $table->decimal('coefficient', 5, 2)->default(1.00);
                $table->decimal('volume_horaire_semaine', 5, 2)->nullable(); // heures/semaine
                $table->unsignedInteger('ordre')->default(1); // Ordre sur le bulletin

                // Si note < note_eliminatoire → bulletin éliminé
                $table->boolean('est_eliminatoire')->default(false);
                $table->decimal('note_eliminatoire', 5, 2)->nullable();

                // Afficher sur le bulletin
                $table->boolean('sur_bulletin')->default(true);

                $table->timestamps();

                $table->unique(['programme_id', 'matiere_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('programme_matiere');
        Schema::dropIfExists('programmes');
        Schema::dropIfExists('matieres');
    }
};
