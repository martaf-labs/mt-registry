<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : eleves | parents_tuteurs | eleve_parent
 * ──────────────────────────────────────────────────
 *
 * ELEVE : profil permanent de l'apprenant.
 *   ⚠️  L'élève existe indépendamment des années scolaires.
 *       Son lien avec une classe/année est géré dans `inscriptions`.
 *   Morphable via users (userable_type = 'Mt\School\Models\Eleve')
 *
 * PARENT_TUTEUR : responsable légal d'un ou plusieurs élèves.
 *   Peut avoir un compte utilisateur (pour le portail parents).
 *
 * ELEVE_PARENT (pivot) : un élève peut avoir plusieurs tuteurs (père, mère…)
 *   avec leur lien de parenté et s'il est le contact principal.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Élèves ────────────────────────────────────────────────────────────
        if (!Schema::hasTable('eleves')) {
            Schema::create('eleves', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique(); // Matricule auto-généré

                // État civil
                $table->string('nom');
                $table->string('prenom');
                // 'M' | 'F'
                $table->string('sexe')->nullable();
                $table->date('date_naissance')->nullable();
                $table->string('lieu_naissance')->nullable();
                $table->string('nationalite')->nullable();
                $table->string('numero_extrait')->nullable(); // Extrait de naissance

                // Photo de profil (gérée via HasImages de mt-views)
                $table->string('photo')->nullable();

                // Contact direct de l'élève (surtout pour le supérieur)
                $table->string('email')->nullable();
                $table->string('telephone')->nullable();
                $table->string('adresse')->nullable();

                // Informations médicales
                $table->string('groupe_sanguin')->nullable(); // 'A+','O-'…
                $table->text('allergies')->nullable();
                $table->text('infos_medicales')->nullable();

                // Scolarité précédente
                $table->string('ecole_precedente')->nullable();
                $table->string('classe_precedente')->nullable();
                $table->string('annee_precedente')->nullable();

                // Langue maternelle (utile pour les écoles multilingues)
                $table->string('langue_maternelle')->nullable();

                // Compte utilisateur
                $table->boolean('a_compte_utilisateur')->default(false);

                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Parents / Tuteurs ─────────────────────────────────────────────────
        if (!Schema::hasTable('parents_tuteurs')) {
            Schema::create('parents_tuteurs', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique();

                $table->string('nom');
                $table->string('prenom');
                $table->string('sexe')->nullable();
                $table->string('civilite')->nullable(); // 'M.' | 'Mme' | 'Dr'…

                $table->string('profession')->nullable();
                $table->string('lieu_travail')->nullable();

                // Contact
                $table->string('email')->nullable();
                $table->string('telephone')->nullable()->index();
                $table->string('telephone_travail')->nullable();
                $table->string('adresse')->nullable();

                $table->string('numero_cni')->nullable();

                // Compte utilisateur pour le portail parents
                $table->boolean('a_compte_utilisateur')->default(false);

                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Table pivot : eleve_parent ─────────────────────────────────────────
        if (!Schema::hasTable('eleve_parent')) {
            Schema::create('eleve_parent', function (Blueprint $table) {
                $table->id();

                $table->foreignId('eleve_id')->constrained('eleves')->cascadeOnDelete();
                $table->foreignId('parent_tuteur_id')->constrained('parents_tuteurs')->cascadeOnDelete();

                // Lien de parenté : 'pere' | 'mere' | 'tuteur' | 'grand_parent' | 'autre'
                $table->string('lien_parente')->default('tuteur');

                // Contact principal pour l'école
                $table->boolean('est_contact_principal')->default(false);

                // Autorisations
                $table->boolean('peut_recuperer')->default(true);   // Peut récupérer l'enfant
                $table->boolean('acces_portail')->default(false);    // Accès au portail numérique

                $table->timestamps();

                $table->unique(['eleve_id', 'parent_tuteur_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('eleve_parent');
        Schema::dropIfExists('parents_tuteurs');
        Schema::dropIfExists('eleves');
    }
};
