<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : personnels | enseignants | attributions_cours
 * ────────────────────────────────────────────────────────
 *
 * PERSONNEL : toute personne employée par l'établissement.
 *   Morphable via users (userable_type = 'Mt\School\Models\Personnel')
 *   Champs communs : état civil, contact, contrat, poste…
 *
 * ENSEIGNANT (extends Personnel) :
 *   Spécialisation avec matières enseignées, grade, statut pédagogique.
 *   Un enseignant est lié à users via le pattern morphable de BaseUser.
 *
 * ATTRIBUTION_COURS :
 *   Lien enseignant ↔ classe ↔ matière pour une année scolaire.
 *   C'est la "feuille de service" d'un enseignant.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Personnels ────────────────────────────────────────────────────────
        if (!Schema::hasTable('personnels')) {
            Schema::create('personnels', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // Matricule interne auto-généré

                // État civil (multilingue pour nom/prénom si besoin)
                $table->string('nom');
                $table->string('prenom');
                // nom_complet est un accesseur calculé dans le modèle (non stocké en base)

                // 'M' | 'F' | 'autre'
                $table->string('sexe')->nullable();
                // 'M.' | 'Mme' | 'Dr' | 'Pr' | 'autre'
                $table->string('civilite')->nullable();

                $table->date('date_naissance')->nullable();
                $table->string('lieu_naissance')->nullable();
                $table->string('nationalite')->nullable();
                $table->string('numero_cni')->nullable();

                // Type de personnel : 'enseignant' | 'administratif' | 'technique' | 'direction'
                $table->string('type')->default('administratif')->index();

                // Contrat & Poste
                $table->string('poste')->nullable(); // 'Professeur' | 'Comptable' | 'Censeur'…
                $table->string('grade')->nullable();
                // 'titulaire' | 'vacataire' | 'contractuel' | 'stagiaire' | 'benevole'
                $table->string('statut_contrat')->nullable();
                $table->date('date_embauche')->nullable();
                $table->date('date_fin_contrat')->nullable();

                // Contact
                $table->string('email')->nullable();
                $table->string('telephone')->nullable();
                $table->string('telephone_urgence')->nullable();
                $table->string('adresse')->nullable();

                // Compte utilisateur (pattern morphable de mt-views)
                // Le compte est créé séparément via User::userable
                $table->boolean('a_compte_utilisateur')->default(false);

                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Enseignants ───────────────────────────────────────────────────────
        // Extension de personnel pour les champs pédagogiques spécifiques
        if (!Schema::hasTable('enseignants')) {
            Schema::create('enseignants', function (Blueprint $table) {
                $table->id();

                // Relation 1-1 avec personnel
                $table->foreignId('personnel_id')->unique()->constrained('personnels')->cascadeOnDelete();

                // Spécialité principale
                $table->foreignId('matiere_principale_id')->nullable()->constrained('matieres')->nullOnDelete();

                // Diplôme le plus élevé
                $table->string('diplome')->nullable();
                $table->string('specialite')->nullable(); // Ex : 'Mathématiques pures'

                // Volume d'heures hebdomadaires prévu au contrat
                $table->decimal('volume_horaire_contrat', 5, 2)->nullable();

                $table->timestamps();
            });
        }

        // ── Table pivot : enseignant_matiere ──────────────────────────────────
        // Les matières qu'un enseignant est habilité à enseigner
        if (!Schema::hasTable('enseignant_matiere')) {
            Schema::create('enseignant_matiere', function (Blueprint $table) {
                $table->id();
                $table->foreignId('enseignant_id')->constrained('enseignants')->cascadeOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['enseignant_id', 'matiere_id']);
            });
        }

        // ── Attributions de cours ─────────────────────────────────────────────
        // Feuille de service : qui enseigne quoi, dans quelle classe, cette année
        if (!Schema::hasTable('attributions_cours')) {
            Schema::create('attributions_cours', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('enseignant_id')->constrained('enseignants')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->cascadeOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();

                $table->decimal('volume_horaire_semaine', 5, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->nullable(); // Surcharge locale si différent du programme

                $table->boolean('actif')->default(true);
                $table->date('date_debut')->nullable();
                $table->date('date_fin')->nullable();
                $table->text('observations')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['annee_scolaire_id', 'enseignant_id', 'classe_id', 'matiere_id'], 'attr_cours_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('attributions_cours');
        Schema::dropIfExists('enseignant_matiere');
        Schema::dropIfExists('enseignants');
        Schema::dropIfExists('personnels');
    }
};
