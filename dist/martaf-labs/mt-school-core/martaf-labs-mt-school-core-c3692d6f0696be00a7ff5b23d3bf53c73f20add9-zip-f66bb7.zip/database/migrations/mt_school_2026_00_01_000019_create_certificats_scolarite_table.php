<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Table : certificats_scolarite
 * ──────────────────────────────
 * Documents officiels délivrés à un élève par l'établissement.
 *
 * Types de documents :
 *   - Certificat de scolarité         (preuve d'inscription en cours)
 *   - Attestation de fréquentation    (pour les allocations, bourses externes)
 *   - Relevé de notes officiel        (historique des résultats)
 *   - Diplôme / Attestation de fin    (fin de cycle)
 *   - Attestation de transfert        (pour changement d'établissement)
 *   - Reçu d'inscription              (preuve administrative)
 *
 * Chaque document est :
 *   - lié à une inscription (= élève + année)
 *   - numéroté de façon unique (référence officielle)
 *   - signé numériquement (hash)
 *   - traçable (qui a demandé, qui a délivré, quand)
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('certificats_scolarite')) {
            Schema::create('certificats_scolarite', function (Blueprint $table) {
                $table->id();

                // Numéro officiel (ex : CERT-2024-000123)
                $table->string('reference')->unique();

                $table->foreignId('inscription_id')->constrained('inscriptions')->restrictOnDelete();

                // Type de document
                // 'certificat_scolarite' | 'attestation_frequentation' | 'releve_notes'
                // 'diplome' | 'attestation_transfert' | 'recu_inscription' | 'autre'
                $table->string('type')->default('certificat_scolarite')->index();

                // Libellé multilingue (titre du document)
                $table->json('titre');  // {'fr':'Certificat de scolarité','en':'School Certificate'}

                // Motif de la demande
                $table->string('motif')->nullable(); // 'bourses','allocations','visa','autre'
                $table->text('motif_detail')->nullable();

                // Destinataire (organisme, ambassade, employeur parent…)
                $table->string('destinataire')->nullable();

                // Langue de délivrance (utile si multilingue activé)
                $table->string('langue')->default('fr'); // 'fr'|'en'|'ar'

                // Fichier PDF généré
                $table->string('fichier_pdf')->nullable();

                // Signature numérique pour authenticité
                $table->string('signature_hash')->nullable();
                $table->string('qr_code')->nullable(); // URL de vérification

                // Statut : 'demande' | 'en_cours' | 'delivre' | 'annule'
                $table->string('statut')->default('demande')->index();

                // Qui a demandé (user : parent, admin, élève…)
                $table->unsignedBigInteger('demande_par')->nullable();
                $table->timestamp('demande_at')->nullable();

                // Qui a validé et délivré
                $table->unsignedBigInteger('delivre_par')->nullable();
                $table->timestamp('delivre_at')->nullable();

                // Nombre d'exemplaires demandés
                $table->unsignedSmallInteger('nb_exemplaires')->default(1);

                // Date de validité du document (ex: certif valable 3 mois)
                $table->date('valide_jusqu_au')->nullable();

                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('certificats_scolarite');
    }
};
