<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : presences | justifications_absence
 * ─────────────────────────────────────────────
 *
 * PRESENCE : enregistrement de la présence/absence d'un élève
 *   à un créneau précis (ou à une journée entière si pas d'EDT).
 *   Trois modes de saisie :
 *     - Par créneau (si emploi du temps actif)
 *     - Par demi-journée (matin / après-midi)
 *     - Par journée complète
 *
 * JUSTIFICATION_ABSENCE : document/raison fourni par le parent
 *   pour justifier une ou plusieurs absences.
 *   Peut regrouper plusieurs jours consécutifs.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Présences ─────────────────────────────────────────────────────────
        if (!Schema::hasTable('presences')) {
            Schema::create('presences', function (Blueprint $table) {
                $table->id();

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();

                // Optionnel : lié à un créneau précis
                $table->foreignId('creneau_id')->nullable()->constrained('creneaux')->nullOnDelete();
                $table->foreignId('matiere_id')->nullable()->constrained('matieres')->nullOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();

                $table->date('date');

                // Mode : 'creneau' | 'demi_journee' | 'journee'
                $table->string('mode')->default('journee');

                // Période : 'matin' | 'apres_midi' | 'journee_complete' | null (pour créneau)
                $table->string('periode_journee')->nullable();

                // 'present' | 'absent' | 'retard' | 'exclusion'
                $table->string('statut')->default('present')->index();

                // Retard en minutes
                $table->unsignedInteger('retard_minutes')->default(0);

                // Justification liée
                $table->foreignId('justification_id')->nullable(); // FK ajoutée après

                $table->boolean('est_justifiee')->default(false);

                // Saisi par (l'enseignant ou l'admin)
                $table->unsignedBigInteger('saisi_par')->nullable();

                $table->text('observations')->nullable();

                $table->tracksUser();
                $table->timestamps();

                $table->index(['inscription_id', 'date']);
                $table->index(['date', 'statut']);
            });
        }

        // ── Justifications d'absence ──────────────────────────────────────────
        if (!Schema::hasTable('justifications_absence')) {
            Schema::create('justifications_absence', function (Blueprint $table) {
                $table->id();

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();

                $table->date('date_debut');
                $table->date('date_fin');

                // Motif : 'maladie' | 'deuil' | 'evenement_famille' | 'voyage' | 'autre'
                $table->string('motif')->default('autre');
                $table->text('motif_detail')->nullable();

                // Document justificatif (certificat médical, etc.)
                $table->string('document')->nullable();

                // 'en_attente' | 'acceptee' | 'rejetee'
                $table->string('statut')->default('en_attente');

                $table->unsignedBigInteger('traitee_par')->nullable();
                $table->timestamp('traitee_at')->nullable();
                $table->text('motif_rejet')->nullable();

                // Soumis par (parent ou élève lui-même)
                $table->string('soumis_par_type')->nullable(); // 'parent_tuteur' | 'eleve' | 'admin'
                $table->unsignedBigInteger('soumis_par_id')->nullable();

                $table->tracksUser();
                $table->timestamps();
            });
        }

        // Ajout FK circulaire (presences → justifications_absence)
        Schema::table('presences', function (Blueprint $table) {
            $table->foreign('justification_id')
                ->references('id')
                ->on('justifications_absence')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('presences', function (Blueprint $table) {
            $table->dropForeign(['justification_id']);
        });
        Schema::dropIfExists('justifications_absence');
        Schema::dropIfExists('presences');
    }
};
