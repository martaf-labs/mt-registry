<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : cycles | niveaux | filieres
 * ───────────────────────────────────────
 *
 * CYCLE : regroupe les niveaux d'enseignement
 *   Ex : Maternelle | Primaire | Collège | Lycée | Supérieur
 *
 * NIVEAU : niveau scolaire au sein d'un cycle
 *   Ex : CP | CE1 | 6e | 3e | Terminale | L1 | M1
 *   Multilingue : {'fr':'Sixième','en':'Year 7','ar':'…'}
 *
 * FILIERE : spécialisation associée à un niveau (optionnelle)
 *   Ex : Scientifique | Littéraire | Technique | Informatique
 *   Nécessaire à partir du lycée / supérieur.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Cycles ───────────────────────────────────────────────────────────
        if (!Schema::hasTable('cycles')) {
            Schema::create('cycles', function (Blueprint $table) {
                $table->id();

                // Multilingue
                $table->json('libelle');           // {'fr':'Primaire','en':'Primary','ar':'…'}
                $table->string('code')->unique();  // Ex : 'MATERNEL','PRIMAIRE','COLLEGE','LYCEE','SUPERIEUR'

                // Type de cycle (pour la logique métier)
                // 'prescolaire' | 'primaire' | 'secondaire' | 'superieur'
                $table->string('type')->default('primaire');

                $table->integer('ordre')->default(1);
                $table->string('couleur')->default('#3b82f6'); // Couleur UI
                $table->string('icone')->nullable();
                $table->text('description')->nullable();
                $table->boolean('actif')->default(true);

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Niveaux ───────────────────────────────────────────────────────────
        if (!Schema::hasTable('niveaux')) {
            Schema::create('niveaux', function (Blueprint $table) {
                $table->id();

                $table->foreignId('cycle_id')->constrained('cycles')->restrictOnDelete();

                // Libellé officiel multilingue
                $table->json('libelle');           // {'fr':'Sixième','en':'Year 7','ar':'السادسة'}
                $table->string('code')->unique();  // Ex : 'SIX','CM2','TLE-S','L1-INFO'
                $table->string('abreviation')->nullable(); // '6e', 'CM2', 'Tle'

                // Ordre dans le cycle (1 = le plus bas)
                $table->integer('ordre')->default(1);

                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->json('meta_data')->nullable(); // ex: seuil_redoublement, age_min, age_max

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Filières ──────────────────────────────────────────────────────────
        if (!Schema::hasTable('filieres')) {
            Schema::create('filieres', function (Blueprint $table) {
                $table->id();

                // Libellé multilingue
                $table->json('libelle');            // {'fr':'Scientifique','en':'Science','ar':'…'}
                $table->string('code')->unique();   // Ex : 'SCI','LITT','TECH','INFO','GESTION'
                $table->string('abreviation')->nullable(); // 'Sc.', 'Lit.'

                $table->string('couleur')->default('#10b981');
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Table pivot : niveaux_filieres ────────────────────────────────────
        // Un niveau peut proposer plusieurs filières et vice-versa
        if (!Schema::hasTable('niveau_filiere')) {
            Schema::create('niveau_filiere', function (Blueprint $table) {
                $table->id();
                $table->foreignId('niveau_id')->constrained('niveaux')->cascadeOnDelete();
                $table->foreignId('filiere_id')->constrained('filieres')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['niveau_id', 'filiere_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('niveau_filiere');
        Schema::dropIfExists('filieres');
        Schema::dropIfExists('niveaux');
        Schema::dropIfExists('cycles');
    }
};
