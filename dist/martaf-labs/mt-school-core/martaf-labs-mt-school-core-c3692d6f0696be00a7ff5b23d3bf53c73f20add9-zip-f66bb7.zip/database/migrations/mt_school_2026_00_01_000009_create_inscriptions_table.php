<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Table : inscriptions
 * ─────────────────────
 * NŒUD CENTRAL du domaine scolaire.
 * Matérialise le lien entre un élève, une classe et une année scolaire.
 *
 * Un élève n'appartient pas directement à une classe :
 * il y est INSCRIT pour une année donnée.
 *
 * Historique complet :
 *   - Élève inscrit en 6e A (2023-2024) → id=1
 *   - Réinscrit en 5e B (2024-2025)     → id=2
 *   Les deux lignes sont conservées.
 *
 * Statuts possibles :
 *   'en_attente' | 'validee' | 'rejetee' | 'annulee' | 'transferee'
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('inscriptions')) {
            Schema::create('inscriptions', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique(); // INS-2024-00001

                // ── Relations clés ────────────────────────────────────────────
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('eleve_id')->constrained('eleves')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();

                // Inscription précédente (pour tracer la progression)
                $table->foreignId('inscription_precedente_id')
                    ->nullable()
                    ->constrained('inscriptions')
                    ->nullOnDelete();

                // ── Statut ────────────────────────────────────────────────────
                // 'en_attente' | 'validee' | 'rejetee' | 'annulee' | 'transferee'
                $table->string('statut')->default('en_attente')->index();

                $table->date('date_inscription')->nullable();
                $table->date('date_validation')->nullable();
                $table->unsignedBigInteger('valide_par')->nullable(); // user_id

                // ── Résultat de l'année (rempli à la clôture) ─────────────────
                // 'admis' | 'redouble' | 'oriente' | 'exclu' | 'abandonne' | 'transfere'
                $table->string('resultat')->nullable()->index();
                $table->decimal('moyenne_annuelle', 6, 2)->nullable();
                $table->unsignedInteger('rang_annuel')->nullable();

                // ── Transfert ─────────────────────────────────────────────────
                $table->string('etablissement_origine')->nullable(); // Vient d'un autre établ.
                $table->string('etablissement_destination')->nullable(); // Transféré vers

                // ── Informations complémentaires ──────────────────────────────
                $table->string('numero_table')->nullable(); // Numéro de table examen
                $table->boolean('est_boursier')->default(false);
                $table->boolean('est_redoublant')->default(false);
                $table->boolean('est_transfere')->default(false);

                $table->text('motif_rejet')->nullable();
                $table->text('observations')->nullable();
                $table->json('documents')->nullable(); // liste des docs fournis
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                // Un élève ne peut être inscrit qu'une seule fois par année scolaire
                $table->unique(['annee_scolaire_id', 'eleve_id'], 'inscription_unique_par_an');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('inscriptions');
    }
};
