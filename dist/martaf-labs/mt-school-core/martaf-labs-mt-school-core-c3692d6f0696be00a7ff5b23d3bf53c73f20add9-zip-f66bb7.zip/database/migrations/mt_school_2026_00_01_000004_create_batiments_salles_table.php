<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : batiments | salles
 * ────────────────────────────
 * Infrastructure physique de l'établissement.
 * Utilisée par l'emploi du temps et les classes.
 *
 * BATIMENT : un bloc ou immeuble
 * SALLE    : une salle de cours, labo, amphithéâtre…
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('batiments')) {
            Schema::create('batiments', function (Blueprint $table) {
                $table->id();

                $table->json('libelle');           // {'fr':'Bâtiment A','en':'Building A'}
                $table->string('code')->unique();  // 'BAT-A'
                $table->text('description')->nullable();
                $table->boolean('actif')->default(true);

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('salles')) {
            Schema::create('salles', function (Blueprint $table) {
                $table->id();

                $table->foreignId('batiment_id')->nullable()->constrained('batiments')->nullOnDelete();

                $table->json('libelle');            // {'fr':'Salle 101','en':'Room 101'}
                $table->string('code')->unique();   // 'S101', 'LABO-SVT', 'AMPHI-A'

                // Type : 'classe' | 'laboratoire' | 'amphi' | 'informatique' | 'sport' | 'autre'
                $table->string('type')->default('classe');

                $table->unsignedInteger('capacite')->default(40);
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->json('equipements')->nullable(); // ['projecteur','tableau_blanc',…]

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('salles');
        Schema::dropIfExists('batiments');
    }
};
