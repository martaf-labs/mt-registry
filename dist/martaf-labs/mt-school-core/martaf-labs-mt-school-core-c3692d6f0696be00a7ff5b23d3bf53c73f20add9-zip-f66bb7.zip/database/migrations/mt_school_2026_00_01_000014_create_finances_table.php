<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : types_frais | frais_scolaires | echeances | paiements | bourses
 * ─────────────────────────────────────────────────────────────────────────
 *
 * TYPE_FRAIS : catégorie de frais (Scolarité, Inscription, Cantine…)
 *
 * FRAIS_SCOLAIRE : montant dû par un élève inscrit pour une année.
 *   Calculé automatiquement à l'inscription selon le niveau/classe.
 *   Peut être personnalisé (remise, exonération partielle).
 *
 * ECHEANCE : découpage du frais total en plusieurs versements.
 *   Ex : 30% à l'inscription, 35% au 1er trim, 35% au 2e trim.
 *
 * PAIEMENT : versement effectif réalisé par la famille.
 *   Lié à une ou plusieurs échéances.
 *
 * BOURSE : aide financière attribuée à un élève pour une année.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Types de frais ────────────────────────────────────────────────────
        if (!Schema::hasTable('types_frais')) {
            Schema::create('types_frais', function (Blueprint $table) {
                $table->id();

                $table->json('libelle');            // {'fr':'Frais de scolarité','en':'Tuition fees'}
                $table->string('code')->unique();   // 'SCOLARITE','INSCRIPTION','CANTINE','TRANSPORT'

                // 'obligatoire' | 'optionnel' | 'conditionnel'
                $table->string('caracteristique')->default('obligatoire');

                $table->boolean('actif')->default(true);
                $table->integer('ordre')->default(1);
                $table->text('description')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Barèmes de frais (par niveau/filière/année) ───────────────────────
        // Définit le montant de référence avant personnalisation
        if (!Schema::hasTable('baremes_frais')) {
            Schema::create('baremes_frais', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('type_frais_id')->constrained('types_frais')->restrictOnDelete();
                $table->foreignId('niveau_id')->nullable()->constrained('niveaux')->nullOnDelete();
                $table->foreignId('filiere_id')->nullable()->constrained('filieres')->nullOnDelete();

                $table->decimal('montant', 12, 2);
                $table->string('devise', 3)->default('XAF');

                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();

                $table->tracksUser();
                $table->timestamps();

                $table->unique(['annee_scolaire_id', 'type_frais_id', 'niveau_id', 'filiere_id'], 'bareme_unique');
            });
        }

        // ── Frais scolaires (par inscription) ─────────────────────────────────
        if (!Schema::hasTable('frais_scolaires')) {
            Schema::create('frais_scolaires', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique(); // FRS-2024-00001

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('type_frais_id')->constrained('types_frais')->restrictOnDelete();

                $table->decimal('montant_brut', 12, 2);          // Montant du barème
                $table->decimal('remise', 12, 2)->default(0);     // Remise accordée
                $table->decimal('montant_net', 12, 2);            // Montant final dû
                $table->decimal('montant_paye', 12, 2)->default(0); // Déjà réglé
                $table->decimal('montant_restant', 12, 2);        // Solde dû (calculé)

                $table->string('devise', 3)->default('XAF');

                // 'en_attente' | 'partiel' | 'solde' | 'exonere' | 'annule'
                $table->string('statut')->default('en_attente')->index();

                $table->boolean('est_exonere')->default(false);
                $table->text('motif_exoneration')->nullable();

                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['inscription_id', 'type_frais_id']);
            });
        }

        // ── Échéances de paiement ─────────────────────────────────────────────
        if (!Schema::hasTable('echeances')) {
            Schema::create('echeances', function (Blueprint $table) {
                $table->id();

                $table->foreignId('frais_scolaire_id')->constrained('frais_scolaires')->cascadeOnDelete();

                // Libellé multilingue : {'fr':'1er versement','en':'1st payment'}
                $table->json('libelle')->nullable();

                $table->integer('ordre')->default(1);
                $table->decimal('montant', 12, 2);
                $table->date('date_echeance');

                // 'en_attente' | 'en_retard' | 'partiel' | 'solde'
                $table->string('statut')->default('en_attente')->index();

                $table->decimal('montant_paye', 12, 2)->default(0);
                $table->decimal('montant_restant', 12, 2);

                $table->timestamps();
            });
        }

        // ── Paiements ─────────────────────────────────────────────────────────
        if (!Schema::hasTable('paiements')) {
            Schema::create('paiements', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique(); // PAY-2024-00001

                $table->foreignId('frais_scolaire_id')->constrained('frais_scolaires')->cascadeOnDelete();
                $table->foreignId('echeance_id')->nullable()->constrained('echeances')->nullOnDelete();

                $table->decimal('montant', 12, 2);
                $table->string('devise', 3)->default('XAF');

                $table->date('date_paiement');

                // Mode de paiement : 'espece' | 'virement' | 'cheque' | 'mobile_money' | 'carte' | 'autre'
                $table->string('mode_paiement')->default('espece');

                // Numéro de transaction (mobile money, virement…)
                $table->string('numero_transaction')->nullable();

                // 'en_attente' | 'confirme' | 'rejete' | 'rembourse'
                $table->string('statut')->default('confirme')->index();

                // Reçu généré
                $table->string('fichier_recu')->nullable();
                $table->boolean('recu_envoye')->default(false);

                // Caissier qui a enregistré
                $table->unsignedBigInteger('encaisse_par')->nullable();

                $table->text('notes')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Bourses ───────────────────────────────────────────────────────────
        if (!Schema::hasTable('bourses')) {
            Schema::create('bourses', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique();

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();

                // Libellé multilingue
                $table->json('libelle');            // {'fr':'Bourse d\'excellence'}
                $table->string('type')->default('autre'); // 'excellence' | 'sociale' | 'etat' | 'autre'

                $table->decimal('montant', 12, 2);
                $table->string('devise', 3)->default('XAF');

                // Couverture : 'totale' | 'partielle'
                $table->string('couverture')->default('partielle');
                $table->decimal('taux_couverture', 5, 2)->nullable(); // % de prise en charge

                $table->date('date_attribution');
                $table->date('date_fin')->nullable();

                // 'en_attente' | 'active' | 'suspendue' | 'retiree'
                $table->string('statut')->default('en_attente');

                $table->string('organisme')->nullable(); // Organisme attribueur
                $table->text('conditions')->nullable();
                $table->text('observations')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('bourses');
        Schema::dropIfExists('paiements');
        Schema::dropIfExists('echeances');
        Schema::dropIfExists('frais_scolaires');
        Schema::dropIfExists('baremes_frais');
        Schema::dropIfExists('types_frais');
    }
};
