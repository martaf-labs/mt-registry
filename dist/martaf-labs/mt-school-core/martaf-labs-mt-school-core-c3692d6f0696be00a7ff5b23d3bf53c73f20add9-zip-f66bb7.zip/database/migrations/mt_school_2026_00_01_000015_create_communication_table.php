<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : annonces | messages | conversations | evenements_agenda
 * ──────────────────────────────────────────────────────────────────
 *
 * ANNONCE : message diffusé par la direction/enseignants vers
 *   des groupes (tous, une classe, un niveau, les parents…).
 *   Multilingue si l'option est activée.
 *
 * CONVERSATION + MESSAGE : messagerie interne entre utilisateurs.
 *   Modèle thread : une conversation regroupe plusieurs messages.
 *
 * EVENEMENT_AGENDA : calendrier partagé de l'établissement.
 *   Ex : Conseils de classe, examens, vacances, sorties…
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Annonces ──────────────────────────────────────────────────────────
        if (!Schema::hasTable('annonces')) {
            Schema::create('annonces', function (Blueprint $table) {
                $table->id();

                // Titre et contenu multilingues
                $table->json('titre');             // {'fr':'Réunion parents','en':'Parent meeting'}
                $table->json('contenu');

                // Auteur (user)
                $table->unsignedBigInteger('auteur_id')->index();

                // Audience cible (morphable)
                // 'tous' | 'eleves' | 'parents' | 'enseignants' | 'personnel' | 'classe' | 'niveau'
                $table->string('audience_type')->default('tous');
                $table->json('audience_ids')->nullable(); // IDs des classes/niveaux ciblés

                // Année scolaire (optionnel mais recommandé)
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();

                // 'brouillon' | 'publiee' | 'archivee'
                $table->string('statut')->default('brouillon')->index();

                // Importance : 'normale' | 'importante' | 'urgente'
                $table->string('importance')->default('normale');

                $table->timestamp('publiee_at')->nullable();
                $table->timestamp('expire_at')->nullable();       // Date d'expiration
                $table->boolean('notification_email')->default(false);
                $table->boolean('notification_sms')->default(false);

                $table->unsignedInteger('vues_count')->default(0);

                // Pièces jointes
                $table->json('pieces_jointes')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Lectures d'annonces ───────────────────────────────────────────────
        if (!Schema::hasTable('annonce_lectures')) {
            Schema::create('annonce_lectures', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annonce_id')->constrained('annonces')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id')->index();
                $table->timestamp('lu_at')->useCurrent();
                $table->unique(['annonce_id', 'user_id']);
            });
        }

        // ── Conversations (messagerie interne) ────────────────────────────────
        if (!Schema::hasTable('conversations')) {
            Schema::create('conversations', function (Blueprint $table) {
                $table->id();

                $table->json('sujet')->nullable(); // {'fr':'Question sur les notes'}

                // 'prive' (2 participants) | 'groupe'
                $table->string('type')->default('prive');

                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();

                $table->timestamp('dernier_message_at')->nullable()->index();
                $table->unsignedInteger('messages_count')->default(0);

                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ── Participants à une conversation ───────────────────────────────────
        if (!Schema::hasTable('conversation_participants')) {
            Schema::create('conversation_participants', function (Blueprint $table) {
                $table->id();
                $table->foreignId('conversation_id')->constrained('conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id')->index();
                $table->timestamp('dernier_vu_at')->nullable();
                $table->boolean('est_admin')->default(false); // Admin du groupe
                $table->boolean('est_mute')->default(false);
                $table->timestamps();
                $table->unique(['conversation_id', 'user_id']);
            });
        }

        // ── Messages ──────────────────────────────────────────────────────────
        if (!Schema::hasTable('messages')) {
            Schema::create('messages', function (Blueprint $table) {
                $table->id();

                $table->foreignId('conversation_id')->constrained('conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('expediteur_id')->index();

                // Réponse à un message précédent
                $table->foreignId('parent_id')->nullable()->constrained('messages')->nullOnDelete();

                $table->text('contenu');
                $table->string('type_contenu')->default('texte'); // 'texte' | 'image' | 'fichier'
                $table->json('pieces_jointes')->nullable();

                // 'envoye' | 'lu' | 'supprime'
                $table->string('statut')->default('envoye');

                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ── Agenda / Événements ───────────────────────────────────────────────
        if (!Schema::hasTable('evenements_agenda')) {
            Schema::create('evenements_agenda', function (Blueprint $table) {
                $table->id();

                $table->json('titre');             // {'fr':'Conseil de classe Trim 1'}
                $table->json('description')->nullable();

                // Type : 'conseil_classe' | 'examen' | 'vacances' | 'reunion' | 'sortie' | 'ferie' | 'autre'
                $table->string('type')->default('autre');

                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();

                // Audience ciblée
                $table->string('audience_type')->default('tous');
                $table->json('audience_ids')->nullable();

                $table->dateTime('debut_at');
                $table->dateTime('fin_at')->nullable();
                $table->boolean('journee_entiere')->default(false);
                $table->boolean('recurrent')->default(false);
                $table->json('recurrence_config')->nullable(); // {freq:'weekly', jours:[1,3,5]}

                $table->string('lieu')->nullable();
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();

                $table->string('couleur')->default('#3b82f6');
                $table->string('icone')->nullable();

                $table->boolean('publie')->default(true);
                $table->boolean('notification_envoye')->default(false);

                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('evenements_agenda');
        Schema::dropIfExists('messages');
        Schema::dropIfExists('conversation_participants');
        Schema::dropIfExists('conversations');
        Schema::dropIfExists('annonce_lectures');
        Schema::dropIfExists('annonces');
    }
};
