<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : moyennes_matieres | moyennes_periodes | bulletins
 * ────────────────────────────────────────────────────────────
 *
 * MOYENNE_MATIERE : moyenne d'un élève dans une matière pour une période.
 *   Calculée automatiquement à partir des notes.
 *   Stockée pour la performance et l'historique.
 *
 * MOYENNE_PERIODE : moyenne générale d'un élève pour une période complète.
 *   Inclut rang, effectif classe, mention, appréciation globale.
 *
 * BULLETIN : document officiel généré pour une période.
 *   Regroupe toutes les moyennes_matieres + moyenne_periode.
 *   Peut être imprimé / publié sur le portail parents.
 *   Statuts : 'brouillon' | 'genere' | 'valide' | 'publie' | 'archive'
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Moyennes par matière (par période) ───────────────────────────────
        if (!Schema::hasTable('moyennes_matieres')) {
            Schema::create('moyennes_matieres', function (Blueprint $table) {
                $table->id();

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();

                $table->decimal('moyenne', 6, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->default(1.00);

                // Moyenne * coefficient (poids réel dans la période)
                $table->decimal('moyenne_ponderee', 8, 2)->nullable();

                // Rang dans la classe pour cette matière cette période
                $table->unsignedInteger('rang')->nullable();

                // Statistiques de la classe (dénormalisées pour la perf)
                $table->decimal('moyenne_classe', 6, 2)->nullable();
                $table->decimal('note_max_classe', 6, 2)->nullable();
                $table->decimal('note_min_classe', 6, 2)->nullable();

                // Appréciation de l'enseignant sur la période
                $table->string('appreciation')->nullable();

                // Note éliminatoire → bulletin bloqué
                $table->boolean('est_eliminatoire')->default(false);

                // Calculée automatiquement ou saisie manuellement
                $table->boolean('est_manuelle')->default(false);

                $table->boolean('validee')->default(false);

                $table->tracksUser();
                $table->timestamps();

                $table->unique(['inscription_id', 'periode_id', 'matiere_id'], 'moy_mat_unique');
            });
        }

        // ── Moyennes générales par période ───────────────────────────────────
        if (!Schema::hasTable('moyennes_periodes')) {
            Schema::create('moyennes_periodes', function (Blueprint $table) {
                $table->id();

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();

                $table->decimal('moyenne_generale', 6, 2)->nullable();
                $table->decimal('total_points', 8, 2)->nullable();      // Somme notes*coef
                $table->decimal('total_coefficients', 8, 2)->nullable(); // Somme coefficients

                // Rang et effectif
                $table->unsignedInteger('rang')->nullable();
                $table->unsignedInteger('effectif_classe')->nullable();

                // Statistiques classe
                $table->decimal('moyenne_classe', 6, 2)->nullable();
                $table->decimal('moyenne_max_classe', 6, 2)->nullable();
                $table->decimal('moyenne_min_classe', 6, 2)->nullable();

                // Mention : 'Excellent' | 'Très Bien' | 'Bien' | 'Assez Bien' | 'Passable' | 'Insuffisant'
                $table->string('mention')->nullable();

                // Appréciation globale (multilingue)
                $table->json('appreciation_globale')->nullable();

                // Décision du conseil de classe
                // 'passage_autorise' | 'passage_conditionnel' | 'redoublement' | 'orientation'
                $table->string('decision_conseil')->nullable();
                $table->text('observation_conseil')->nullable();

                // Nombre d'absences sur la période
                $table->unsignedInteger('absences_justifiees')->default(0);
                $table->unsignedInteger('absences_injustifiees')->default(0);
                $table->unsignedInteger('retards')->default(0);

                $table->boolean('validee')->default(false);
                $table->unsignedBigInteger('validee_par')->nullable();
                $table->timestamp('validee_at')->nullable();

                $table->tracksUser();
                $table->timestamps();

                $table->unique(['inscription_id', 'periode_id'], 'moy_periode_unique');
            });
        }

        // ── Bulletins ─────────────────────────────────────────────────────────
        if (!Schema::hasTable('bulletins')) {
            Schema::create('bulletins', function (Blueprint $table) {
                $table->id();

                $table->string('reference')->nullable()->unique(); // BUL-2024-001-SEQ1

                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->foreignId('moyenne_periode_id')->nullable()->constrained('moyennes_periodes')->nullOnDelete();

                // 'brouillon' | 'genere' | 'valide' | 'publie' | 'archive'
                $table->string('statut')->default('brouillon')->index();

                // Fichier PDF généré
                $table->string('fichier_pdf')->nullable();

                // Signataires
                $table->string('nom_directeur')->nullable();
                $table->string('nom_professeur_principal')->nullable();

                // Cachet / Signature numérique
                $table->string('signature_hash')->nullable();

                // Dates clés
                $table->timestamp('genere_at')->nullable();
                $table->timestamp('valide_at')->nullable();
                $table->timestamp('publie_at')->nullable();

                // Publié sur le portail parents
                $table->boolean('visible_portail')->default(false);

                // Layout d'impression (si plusieurs templates)
                // 'standard' | 'detaille' | 'compact'
                $table->string('layout')->default('standard');

                $table->json('meta_data')->nullable(); // données snapshot au moment génération
                $table->text('observations')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['inscription_id', 'periode_id'], 'bulletin_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('bulletins');
        Schema::dropIfExists('moyennes_periodes');
        Schema::dropIfExists('moyennes_matieres');
    }
};
