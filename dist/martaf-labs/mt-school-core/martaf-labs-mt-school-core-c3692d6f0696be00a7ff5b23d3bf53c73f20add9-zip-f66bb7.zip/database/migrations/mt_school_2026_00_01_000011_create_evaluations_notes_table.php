<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : evaluations | notes
 * ──────────────────────────────
 *
 * EVALUATION : un devoir, examen, contrôle, TP noté…
 *   Appartient à : classe, matière, période, année scolaire.
 *   Créée par un enseignant.
 *
 * NOTE : la note obtenue par un élève (inscription) à une évaluation.
 *   Toujours reliée à l'inscription (= élève + année scolaire).
 *   Contient la note brute, les points bonus/malus, la note finale.
 *
 * Architecture :
 *   Evaluation (ex: DS1 Maths 6eA Seq1)
 *     └─ Note (élève X → 14/20)
 *     └─ Note (élève Y → 11/20)
 *     └─ …
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Évaluations ───────────────────────────────────────────────────────
        if (!Schema::hasTable('evaluations')) {
            Schema::create('evaluations', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();

                // Libellé multilingue
                $table->json('libelle');        // {'fr':'Devoir Surveillé N°1','en':'Test 1'}
                $table->string('code')->nullable(); // 'DS1-MATH-6A-SEQ1'

                // Type : 'devoir' | 'examen' | 'controle' | 'tp' | 'oral' | 'projet' | 'autre'
                $table->string('type')->default('devoir');

                $table->decimal('note_sur', 5, 2)->default(20.00); // Note sur X (ex: 20, 100)
                $table->decimal('coefficient', 5, 2)->default(1.00);

                // Pondération sur la période (ex: l'examen vaut 40%)
                $table->decimal('ponderation', 5, 2)->default(100.00);

                $table->date('date_evaluation')->nullable();
                $table->date('date_saisie_limite')->nullable(); // Deadline saisie notes

                // 'planifiee' | 'en_cours' | 'corrigee' | 'saisie' | 'validee'
                $table->string('statut')->default('planifiee')->index();

                // Afficher aux élèves/parents
                $table->boolean('publiee')->default(false);

                $table->text('consignes')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Notes ─────────────────────────────────────────────────────────────
        if (!Schema::hasTable('notes')) {
            Schema::create('notes', function (Blueprint $table) {
                $table->id();

                $table->foreignId('evaluation_id')->constrained('evaluations')->cascadeOnDelete();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();

                // Note brute saisie
                $table->decimal('note', 6, 2)->nullable();

                // Ajustements
                $table->decimal('bonus', 5, 2)->default(0);
                $table->decimal('malus', 5, 2)->default(0);

                // Note finale = note + bonus - malus (calculée)
                $table->decimal('note_finale', 6, 2)->nullable();

                // Absent à l'évaluation
                $table->boolean('est_absent')->default(false);
                // Absence justifiée (note neutralisée selon config)
                $table->boolean('absence_justifiee')->default(false);
                // Note manquante (non encore saisie)
                $table->boolean('est_manquante')->default(false);

                // Appréciation texte de l'enseignant
                $table->string('appreciation')->nullable();

                // Rang dans la classe pour cette évaluation
                $table->unsignedInteger('rang')->nullable();

                // Saisie validée par un responsable
                $table->boolean('validee')->default(false);
                $table->unsignedBigInteger('validee_par')->nullable();
                $table->timestamp('validee_at')->nullable();

                $table->text('observations')->nullable();

                $table->tracksUser();
                $table->timestamps();

                $table->unique(['evaluation_id', 'inscription_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('notes');
        Schema::dropIfExists('evaluations');
    }
};
