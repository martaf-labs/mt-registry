<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : emplois_du_temps | creneaux
 * ──────────────────────────────────────
 *
 * EMPLOI_DU_TEMPS : grille hebdomadaire d'une classe pour une année scolaire.
 *   Un EDT est publié ou brouillon, et peut être versionné.
 *
 * CRENEAU : une séance de cours dans la grille.
 *   Lié à : classe, matière, enseignant, salle, jour, heure.
 *
 * Gestion des exceptions (jours fériés, cours annulés) via `exceptions_edt`.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Emplois du temps ─────────────────────────────────────────────────
        if (!Schema::hasTable('emplois_du_temps')) {
            Schema::create('emplois_du_temps', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->cascadeOnDelete();

                // Libellé multilingue
                $table->json('libelle')->nullable(); // {'fr':'EDT Tle A S1 2024'}
                $table->string('code')->nullable();

                // 'brouillon' | 'publie' | 'archive'
                $table->string('statut')->default('brouillon');

                $table->date('date_debut_validite')->nullable();
                $table->date('date_fin_validite')->nullable();

                $table->boolean('est_actif')->default(true);
                $table->text('observations')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Créneaux ─────────────────────────────────────────────────────────
        if (!Schema::hasTable('creneaux')) {
            Schema::create('creneaux', function (Blueprint $table) {
                $table->id();

                $table->foreignId('emploi_du_temps_id')->constrained('emplois_du_temps')->cascadeOnDelete();
                $table->foreignId('attribution_cours_id')->nullable()->constrained('attributions_cours')->nullOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();

                // Jour de la semaine (1=Lun, 2=Mar … 7=Dim — ISO 8601)
                $table->unsignedTinyInteger('jour_semaine');

                $table->time('heure_debut');
                $table->time('heure_fin');

                // Type : 'cours' | 'td' | 'tp' | 'examen' | 'permanence' | 'pause' | 'autre'
                $table->string('type')->default('cours');

                // Récurrence (hebdomadaire par défaut, mais peut être bi-hebdomadaire)
                // 'toutes_semaines' | 'semaines_paires' | 'semaines_impaires'
                $table->string('recurrence')->default('toutes_semaines');

                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();

                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Exceptions EDT ───────────────────────────────────────────────────
        // Cours annulé, déplacé, jour férié, etc.
        if (!Schema::hasTable('exceptions_edt')) {
            Schema::create('exceptions_edt', function (Blueprint $table) {
                $table->id();

                $table->foreignId('creneau_id')->constrained('creneaux')->cascadeOnDelete();

                $table->date('date_exception');

                // 'annule' | 'reporte' | 'remplace'
                $table->string('type')->default('annule');

                // Si reporté ou remplacé → nouveau créneau
                $table->foreignId('nouveau_creneau_id')->nullable()->constrained('creneaux')->nullOnDelete();
                $table->date('nouvelle_date')->nullable();
                $table->time('nouvelle_heure_debut')->nullable();
                $table->time('nouvelle_heure_fin')->nullable();
                $table->foreignId('nouvelle_salle_id')->nullable()->constrained('salles')->nullOnDelete();

                // Libellé multilingue du motif
                $table->json('motif')->nullable(); // {'fr':'Jour férié','en':'Public holiday'}

                $table->tracksUser();
                $table->timestamps();

                $table->unique(['creneau_id', 'date_exception']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('exceptions_edt');
        Schema::dropIfExists('creneaux');
        Schema::dropIfExists('emplois_du_temps');
    }
};
