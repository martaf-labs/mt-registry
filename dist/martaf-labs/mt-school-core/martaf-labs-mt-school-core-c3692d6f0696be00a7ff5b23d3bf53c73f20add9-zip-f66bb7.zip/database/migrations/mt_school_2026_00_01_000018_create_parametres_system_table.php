<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : parametres_school | notifications_school | imports_exports
 * ─────────────────────────────────────────────────────────────────────
 *
 * PARAMETRE_SCHOOL : configuration dynamique par clé/valeur.
 *   Permet de stocker des réglages métier sans toucher au code.
 *   Ex : mention_passage=10, appreciation_15=Bien, pied_page_bulletin=…
 *
 * NOTIFICATION_SCHOOL : file de notifications in-app.
 *   Distincte de la table notifications de Laravel pour garder la logique métier.
 *
 * IMPORT_EXPORT : traçabilité des imports/exports de données.
 *   Ex : import élèves depuis CSV, export bulletins en PDF batch…
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Paramètres système ────────────────────────────────────────────────
        if (!Schema::hasTable('parametres_school')) {
            Schema::create('parametres_school', function (Blueprint $table) {
                $table->id();

                // Clé unique (ex: 'note_passage', 'pied_page_bulletin_fr', 'logo_url')
                $table->string('cle')->unique();

                // Valeur (texte, JSON, nombre…)
                $table->text('valeur')->nullable();

                // Groupe logique (pour affichage en interface)
                // 'general' | 'notation' | 'bulletin' | 'inscription' | 'finances' | 'communication'
                $table->string('groupe')->default('general')->index();

                // Type de valeur pour le cast
                // 'string' | 'integer' | 'decimal' | 'boolean' | 'json' | 'array' | 'date'
                $table->string('type_valeur')->default('string');

                // Libellé multilingue de ce paramètre (pour l'interface admin)
                $table->json('libelle')->nullable();
                $table->text('description')->nullable();

                // Modifiable via l'interface ou lecture seule
                $table->boolean('modifiable')->default(true);

                // Lié à une année scolaire (null = global)
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();

                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Notifications in-app ──────────────────────────────────────────────
        if (!Schema::hasTable('notifications_school')) {
            Schema::create('notifications_school', function (Blueprint $table) {
                $table->id();

                $table->unsignedBigInteger('user_id')->index();

                // Titre et corps multilingues
                $table->json('titre');
                $table->json('corps')->nullable();

                // Type : 'info' | 'succes' | 'alerte' | 'erreur'
                $table->string('type')->default('info');

                // Catégorie métier
                // 'note' | 'bulletin' | 'absence' | 'paiement' | 'annonce' | 'devoir' | 'autre'
                $table->string('categorie')->default('autre');

                // Entité source (polymorphe)
                $table->string('notifiable_type')->nullable();
                $table->unsignedBigInteger('notifiable_id')->nullable();
                $table->index(['notifiable_type', 'notifiable_id']);

                // Lien de redirection
                $table->string('url')->nullable();

                $table->boolean('lue')->default(false)->index();
                $table->timestamp('lue_at')->nullable();

                $table->timestamps();
            });
        }

        // ── Imports / Exports ─────────────────────────────────────────────────
        if (!Schema::hasTable('imports_exports')) {
            Schema::create('imports_exports', function (Blueprint $table) {
                $table->id();

                // 'import' | 'export'
                $table->string('operation')->default('import');

                // Entité concernée : 'eleves' | 'enseignants' | 'notes' | 'bulletins' | 'paiements'…
                $table->string('entite');

                // Format : 'csv' | 'xlsx' | 'pdf' | 'json' | 'zip'
                $table->string('format')->default('csv');

                // Fichier source (import) ou généré (export)
                $table->string('fichier')->nullable();

                // 'en_attente' | 'en_cours' | 'termine' | 'echec' | 'partiel'
                $table->string('statut')->default('en_attente');

                // Statistiques du traitement
                $table->unsignedInteger('total_lignes')->default(0);
                $table->unsignedInteger('lignes_ok')->default(0);
                $table->unsignedInteger('lignes_erreur')->default(0);
                $table->unsignedInteger('lignes_ignorees')->default(0);

                // Rapport d'erreurs (JSON)
                $table->json('rapport_erreurs')->nullable();

                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();

                $table->timestamp('debut_at')->nullable();
                $table->timestamp('fin_at')->nullable();

                $table->text('notes')->nullable();

                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('imports_exports');
        Schema::dropIfExists('notifications_school');
        Schema::dropIfExists('parametres_school');
    }
};
