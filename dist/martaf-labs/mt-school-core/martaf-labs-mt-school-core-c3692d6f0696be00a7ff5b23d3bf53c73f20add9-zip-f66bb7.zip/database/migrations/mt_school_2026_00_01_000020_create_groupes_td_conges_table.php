<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : groupes_td | groupe_td_inscription | periodes_conges
 * ───────────────────────────────────────────────────────────────
 *
 * GROUPE_TD : sous-groupe d'une classe pour les TD/TP (surtout supérieur).
 *   Une classe de L1 peut être divisée en Groupe A, B, C pour les TP d'info.
 *   Les créneaux EDT peuvent cibler un groupe_td précis (et non toute la classe).
 *
 * GROUPE_TD_INSCRIPTION (pivot) : appartenance d'un inscrit à un groupe.
 *   Un élève ne peut appartenir qu'à un seul groupe par matière/classe.
 *
 * PERIODE_CONGES : calendrier officiel des vacances et jours fériés.
 *   Lié à l'année scolaire. Utilisé par :
 *     - L'emploi du temps (génération des créneaux actifs)
 *     - Les présences (absences neutralisées)
 *     - L'agenda (affichage)
 *     - Le bulletin (calcul des jours de classe effectifs)
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Groupes TD / TP ───────────────────────────────────────────────────
        if (!Schema::hasTable('groupes_td')) {
            Schema::create('groupes_td', function (Blueprint $table) {
                $table->id();

                $table->foreignId('classe_id')->constrained('classes')->cascadeOnDelete();
                $table->foreignId('matiere_id')->nullable()->constrained('matieres')->nullOnDelete();

                // Libellé multilingue : {'fr':'Groupe A','en':'Group A'}
                $table->json('libelle');
                $table->string('code');          // 'GRP-A', 'TD1', 'TP-INFO-B'

                // Type : 'td' | 'tp' | 'oral' | 'autre'
                $table->string('type')->default('td');

                $table->unsignedInteger('effectif_max')->default(25);
                $table->unsignedInteger('effectif_actuel')->default(0);

                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['classe_id', 'matiere_id', 'code'], 'groupe_td_unique');
            });
        }

        // ── Appartenance aux groupes TD ───────────────────────────────────────
        if (!Schema::hasTable('groupe_td_inscription')) {
            Schema::create('groupe_td_inscription', function (Blueprint $table) {
                $table->id();
                $table->foreignId('groupe_td_id')->constrained('groupes_td')->cascadeOnDelete();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->timestamps();
                // Un élève = un seul groupe par matière/classe (géré applicativement)
                $table->unique(['groupe_td_id', 'inscription_id']);
            });
        }

        // Ajouter la colonne groupe_td_id sur creneaux (nullable — rétrocompatible)
        if (Schema::hasTable('creneaux') && !Schema::hasColumn('creneaux', 'groupe_td_id')) {
            Schema::table('creneaux', function (Blueprint $table) {
                $table->foreignId('groupe_td_id')
                    ->nullable()
                    ->after('salle_id')
                    ->constrained('groupes_td')
                    ->nullOnDelete();
            });
        }

        // ── Périodes de congés / Calendrier académique ────────────────────────
        if (!Schema::hasTable('periodes_conges')) {
            Schema::create('periodes_conges', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->cascadeOnDelete();

                // Libellé multilingue : {'fr':'Vacances de Noël','en':'Christmas break','ar':'…'}
                $table->json('libelle');

                // Type : 'vacances' | 'ferie' | 'examen' | 'evenement' | 'autre'
                $table->string('type')->default('vacances')->index();

                $table->date('date_debut');
                $table->date('date_fin');

                // Portée : 'etablissement' | 'national' | 'regional'
                $table->string('portee')->default('etablissement');

                // Cours suspendus pendant cette période
                $table->boolean('cours_suspendus')->default(true);

                // Absences neutralisées (non comptabilisées)
                $table->boolean('absences_neutralisees')->default(true);

                // Couleur pour l'affichage agenda
                $table->string('couleur')->default('#f59e0b');

                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        // Retirer la colonne groupe_td_id des creneaux
        if (Schema::hasTable('creneaux') && Schema::hasColumn('creneaux', 'groupe_td_id')) {
            Schema::table('creneaux', function (Blueprint $table) {
                $table->dropForeign(['groupe_td_id']);
                $table->dropColumn('groupe_td_id');
            });
        }

        Schema::dropIfExists('periodes_conges');
        Schema::dropIfExists('groupe_td_inscription');
        Schema::dropIfExists('groupes_td');
    }
};
