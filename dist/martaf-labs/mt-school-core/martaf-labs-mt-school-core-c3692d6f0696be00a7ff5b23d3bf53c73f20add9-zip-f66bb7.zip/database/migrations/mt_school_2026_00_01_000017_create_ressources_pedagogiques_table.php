<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tables : ressources_pedagogiques | cours_en_ligne | devoirs_maison
 * ────────────────────────────────────────────────────────────────────
 *
 * RESSOURCE_PEDAGOGIQUE : document, fichier, lien partagé par un enseignant.
 *   Ex : fiches de cours, exercices, corrigés, vidéos, liens…
 *   Organisé par matière / classe / niveau.
 *
 * COURS_EN_LIGNE : contenu de cours structuré (chapitres, leçons).
 *   Pour les établissements qui proposent du e-learning ou du blended learning.
 *
 * DEVOIR_MAISON : travail à rendre, avec date limite et soumissions élèves.
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Ressources pédagogiques ───────────────────────────────────────────
        if (!Schema::hasTable('ressources_pedagogiques')) {
            Schema::create('ressources_pedagogiques', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();
                $table->foreignId('matiere_id')->nullable()->constrained('matieres')->nullOnDelete();
                $table->foreignId('classe_id')->nullable()->constrained('classes')->nullOnDelete();
                $table->foreignId('niveau_id')->nullable()->constrained('niveaux')->nullOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();

                // Titre multilingue
                $table->json('titre');
                $table->json('description')->nullable();

                // Type : 'document' | 'video' | 'audio' | 'lien' | 'image' | 'exercice' | 'corrige' | 'autre'
                $table->string('type')->default('document');

                // Fichier ou lien externe
                $table->string('fichier')->nullable();
                $table->string('url_externe')->nullable();

                $table->string('mime_type')->nullable();
                $table->unsignedBigInteger('taille_fichier')->nullable(); // en octets

                // Audience : 'classe' | 'niveau' | 'enseignants' | 'tous'
                $table->string('audience')->default('classe');

                $table->boolean('publie')->default(false);
                $table->unsignedInteger('telechargements')->default(0);
                $table->unsignedInteger('vues')->default(0);

                $table->json('tags')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Devoirs maison ────────────────────────────────────────────────────
        if (!Schema::hasTable('devoirs_maison')) {
            Schema::create('devoirs_maison', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();
                $table->foreignId('periode_id')->nullable()->constrained('periodes')->nullOnDelete();

                // Lié à une évaluation (si le DM est noté)
                $table->foreignId('evaluation_id')->nullable()->constrained('evaluations')->nullOnDelete();

                // Titre et instructions multilingues
                $table->json('titre');
                $table->json('instructions')->nullable();

                $table->date('date_attribution');
                $table->dateTime('date_limite_remise');

                $table->boolean('est_note')->default(false);
                $table->decimal('note_sur', 5, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->default(1.00);

                // 'brouillon' | 'publie' | 'cloture'
                $table->string('statut')->default('publie');

                $table->json('ressources')->nullable(); // fichiers joints à l'énoncé
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ── Soumissions de devoirs ────────────────────────────────────────────
        if (!Schema::hasTable('soumissions_devoirs')) {
            Schema::create('soumissions_devoirs', function (Blueprint $table) {
                $table->id();

                $table->foreignId('devoir_maison_id')->constrained('devoirs_maison')->cascadeOnDelete();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();

                // Fichier soumis
                $table->string('fichier')->nullable();
                $table->text('commentaire')->nullable();

                $table->timestamp('soumis_at')->nullable();
                $table->boolean('en_retard')->default(false);

                // Correction
                $table->decimal('note', 6, 2)->nullable();
                $table->text('correction')->nullable();
                $table->string('fichier_correction')->nullable();
                $table->timestamp('corrige_at')->nullable();

                // 'soumis' | 'corrige' | 'rendu'
                $table->string('statut')->default('soumis');

                $table->timestamps();

                $table->unique(['devoir_maison_id', 'inscription_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('soumissions_devoirs');
        Schema::dropIfExists('devoirs_maison');
        Schema::dropIfExists('ressources_pedagogiques');
    }
};
