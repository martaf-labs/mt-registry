<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Table : annees_scolaires
 * ─────────────────────────
 * Table CENTRALE du package. Toutes les entités actives (classes, inscriptions,
 * notes, bulletins, frais, emplois du temps…) sont reliées à une année scolaire.
 *
 * Ex : "2024-2025", "2025-2026"
 * Le champ `est_active` désigne l'année en cours (une seule à la fois).
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('annees_scolaires')) {
            Schema::create('annees_scolaires', function (Blueprint $table) {
                $table->id();

                // Ex : "2024-2025" — libellé multilingue JSON
                $table->json('libelle');              // {'fr':'Année 2024-2025','en':'Year 2024-2025','ar':'…'}
                $table->string('code')->unique();     // Ex : "2024-2025"

                $table->date('date_debut');
                $table->date('date_fin');

                // Une seule année peut être "active" (l'année scolaire en cours)
                $table->boolean('est_active')->default(false)->index();

                // Clôturée = aucune modification possible (bulletins archivés)
                $table->boolean('est_cloturee')->default(false);

                $table->text('description')->nullable();
                $table->json('meta_data')->nullable(); // config spécifique à l'année

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('annees_scolaires');
    }
};
