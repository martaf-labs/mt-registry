<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Table : periodes
 * ─────────────────
 * Représente une subdivision de l'année scolaire :
 *   - Trimestre (Trim 1, Trim 2, Trim 3)
 *   - Séquence (Seq 1…6)
 *   - Semestre (Sem 1, Sem 2) — pour le supérieur
 *
 * Les notes et bulletins sont toujours rattachés à une période.
 * Les séquences sont regroupées en trimestres via `parent_id`.
 *
 * Exemple d'arborescence :
 *   Trimestre 1  ← parent_id = null
 *     └─ Séquence 1  ← parent_id = id(Trimestre 1)
 *     └─ Séquence 2  ← parent_id = id(Trimestre 1)
 *   Trimestre 2
 *     └─ Séquence 3
 *     └─ Séquence 4
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('periodes')) {
            Schema::create('periodes', function (Blueprint $table) {
                $table->id();

                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->cascadeOnDelete();

                // Référence hiérarchique (séquence → trimestre)
                $table->foreignId('parent_id')->nullable()->constrained('periodes')->nullOnDelete();

                // Libellé multilingue : {'fr':'Trimestre 1','en':'Term 1','ar':'…'}
                $table->json('libelle');
                $table->string('code');           // Ex : 'T1', 'S1', 'SEQ1'

                // Type : 'trimestre' | 'semestre' | 'sequence' | 'annuel' | 'autre'
                $table->string('type')->default('trimestre');

                $table->integer('ordre')->default(1); // Ordre d'affichage
                $table->date('date_debut')->nullable();
                $table->date('date_fin')->nullable();

                $table->boolean('est_active')->default(false)->index();
                $table->boolean('est_cloturee')->default(false);

                // Pondération pour le calcul de la moyenne annuelle (%)
                $table->decimal('poids', 5, 2)->default(100.00);

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                $table->unique(['annee_scolaire_id', 'code']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('periodes');
    }
};
