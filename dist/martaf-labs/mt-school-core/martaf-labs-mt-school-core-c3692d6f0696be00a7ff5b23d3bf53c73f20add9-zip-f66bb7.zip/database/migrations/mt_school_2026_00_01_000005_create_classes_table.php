<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Table : classes
 * ────────────────
 * Une classe = un groupe d'élèves d'un même niveau, dans une année scolaire.
 *
 * Exemples :
 *   - 6e A | 2024-2025
 *   - Terminale S1 | 2024-2025
 *   - L1 Informatique Groupe A | 2024-2025
 *
 * Relation avec l'année scolaire : CENTRALE
 * → La même "Sixième A" doit être recréée chaque année scolaire.
 *   Les classes passées sont conservées (soft delete) pour l'historique.
 *
 * Un `professeur_principal_id` peut être nommé (enseignant responsable de la classe).
 */
return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('classes')) {
            Schema::create('classes', function (Blueprint $table) {
                $table->id();

                // ── Relations structurantes ──────────────────────────────────
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('niveau_id')->constrained('niveaux')->restrictOnDelete();
                $table->foreignId('filiere_id')->nullable()->constrained('filieres')->nullOnDelete();
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();

                // Prof principal (référence à users — pas de FK stricte pour la flexibilité)
                $table->unsignedBigInteger('professeur_principal_id')->nullable()->index();

                // ── Identité ─────────────────────────────────────────────────
                // Libellé multilingue : {'fr':'Sixième A','en':'Year 7A','ar':'…'}
                $table->json('libelle');
                $table->string('code')->index();  // Ex : '6A','TLE-S1','L1-INFO-A'
                $table->string('abreviation')->nullable(); // '6e A'

                // ── Paramètres ───────────────────────────────────────────────
                $table->unsignedInteger('effectif_max')->default(60);
                $table->unsignedInteger('effectif_actuel')->default(0); // Calculé et mis à jour

                // Langue d'enseignement principale si multilingue
                $table->string('langue_enseignement')->nullable(); // 'fr','en','ar'

                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();

                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();

                // Une classe (code) est unique par année scolaire
                $table->unique(['annee_scolaire_id', 'code']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('classes');
    }
};
