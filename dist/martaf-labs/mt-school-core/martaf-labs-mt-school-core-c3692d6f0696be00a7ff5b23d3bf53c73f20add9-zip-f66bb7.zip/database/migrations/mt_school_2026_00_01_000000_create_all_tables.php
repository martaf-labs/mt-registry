<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * ══════════════════════════════════════════════════════════════════════════════
 *  MIGRATION CONSOLIDÉE — mt-school
 *  Toutes les tables dans l'ordre strict des dépendances FK.
 *
 *  Ordre de création :
 *   01. annees_scolaires          (racine absolue)
 *   02. periodes                  (→ annees_scolaires, auto-ref)
 *   03. cycles
 *   04. niveaux                   (→ cycles)
 *   05. filieres
 *   06. niveau_filiere            (→ niveaux, filieres)
 *   07. batiments
 *   08. salles                    (→ batiments)
 *   09. classes                   (→ annees_scolaires, niveaux, filieres, salles)
 *   10. matieres
 *   11. programmes                (→ annees_scolaires, niveaux, filieres)
 *   12. programme_matiere         (→ programmes, matieres)
 *   13. personnels
 *   14. enseignants               (→ personnels, matieres)
 *   15. enseignant_matiere        (→ enseignants, matieres)
 *   16. attributions_cours        (→ annees_scolaires, enseignants, classes, matieres)
 *   17. emplois_du_temps          (→ annees_scolaires, classes)
 *   18. creneaux                  (→ emplois_du_temps, attributions_cours, matieres, enseignants, salles)
 *   19. exceptions_edt            (→ creneaux, salles)
 *   20. eleves
 *   21. parents_tuteurs
 *   22. eleve_parent              (→ eleves, parents_tuteurs)
 *   23. inscriptions              (→ annees_scolaires, eleves, classes, auto-ref)
 *   24. evaluations               (→ annees_scolaires, periodes, classes, matieres, enseignants)
 *   25. notes                     (→ evaluations, inscriptions)
 *   26. moyennes_matieres         (→ inscriptions, periodes, matieres)
 *   27. moyennes_periodes         (→ inscriptions, periodes)
 *   28. bulletins                 (→ inscriptions, periodes, moyennes_periodes)
 *   29. presences                 (→ inscriptions, creneaux, matieres, enseignants)
 *   30. justifications_absence    (→ inscriptions)
 *   31. FK circulaire presences → justifications_absence
 *   32. types_frais
 *   33. baremes_frais             (→ annees_scolaires, types_frais, niveaux, filieres)
 *   34. frais_scolaires           (→ inscriptions, types_frais)
 *   35. echeances                 (→ frais_scolaires)
 *   36. paiements                 (→ frais_scolaires, echeances)
 *   37. bourses                   (→ inscriptions)
 *   38. annonces                  (→ annees_scolaires)
 *   39. annonce_lectures          (→ annonces)
 *   40. conversations             (→ annees_scolaires)
 *   41. conversation_participants (→ conversations)
 *   42. messages                  (→ conversations, auto-ref)
 *   43. evenements_agenda         (→ annees_scolaires, salles)
 *   44. sanctions                 (→ inscriptions)
 *   45. conseils_classe           (→ annees_scolaires, classes, periodes)
 *   46. conseil_participants      (→ conseils_classe)
 *   47. ressources_pedagogiques   (→ annees_scolaires, matieres, classes, niveaux, enseignants)
 *   48. devoirs_maison            (→ annees_scolaires, classes, matieres, enseignants, periodes, evaluations)
 *   49. soumissions_devoirs       (→ devoirs_maison, inscriptions)
 *   50. parametres_school         (→ annees_scolaires)
 *   51. notifications_school
 *   52. imports_exports           (→ annees_scolaires)
 *   53. certificats_scolarite     (→ inscriptions)
 *   54. groupes_td                (→ classes, matieres)
 *   55. groupe_td_inscription     (→ groupes_td, inscriptions)
 *   56. periodes_conges           (→ annees_scolaires)
 *   57. menus_cantine             (→ annees_scolaires)             [optionnel]
 *   58. inscriptions_cantine      (→ inscriptions)                 [optionnel]
 *   59. reservations_repas        (→ inscriptions_cantine, menus)  [optionnel]
 *   60. stock_materiel            (→ salles)                       [optionnel]
 *   61. mouvements_stock          (→ stock_materiel, salles)       [optionnel]
 * ══════════════════════════════════════════════════════════════════════════════
 */
return new class extends Migration
{
    public function up(): void
    {
        // ══════════════════════════════════════════════════════════════════════
        // 01. ANNÉES SCOLAIRES — table racine absolue
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('annees_scolaires')) {
            Schema::create('annees_scolaires', function (Blueprint $table) {
                $table->id();
                $table->json('libelle');              // {'fr':'Année 2024-2025','en':'Year 2024-2025','ar':'…'}
                $table->string('code')->unique();     // '2024-2025'
                $table->date('date_debut');
                $table->date('date_fin');
                $table->boolean('est_active')->default(false)->index();
                $table->boolean('est_cloturee')->default(false);
                $table->text('description')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 02. PÉRIODES — trimestres, semestres, séquences (hiérarchique)
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('periodes')) {
            Schema::create('periodes', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->cascadeOnDelete();
                $table->foreignId('parent_id')->nullable()->constrained('periodes')->nullOnDelete();
                $table->json('libelle');              // {'fr':'Trimestre 1','en':'Term 1','ar':'…'}
                $table->string('code');               // 'T1', 'SEQ1', 'S1'
                $table->string('type')->default('trimestre'); // 'trimestre'|'semestre'|'sequence'|'annuel'
                $table->integer('ordre')->default(1);
                $table->date('date_debut')->nullable();
                $table->date('date_fin')->nullable();
                $table->boolean('est_active')->default(false)->index();
                $table->boolean('est_cloturee')->default(false);
                $table->decimal('poids', 5, 2)->default(100.00); // Pondération annuelle (%)
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['annee_scolaire_id', 'code']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 03. CYCLES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('cycles')) {
            Schema::create('cycles', function (Blueprint $table) {
                $table->id();
                $table->json('libelle');              // {'fr':'Primaire','en':'Primary'}
                $table->string('code')->unique();     // 'MATERNEL'|'PRIMAIRE'|'COLLEGE'|'LYCEE'|'SUPERIEUR'
                $table->string('type')->default('primaire'); // 'prescolaire'|'primaire'|'secondaire'|'superieur'
                $table->integer('ordre')->default(1);
                $table->string('couleur')->default('#3b82f6');
                $table->string('icone')->nullable();
                $table->text('description')->nullable();
                $table->boolean('actif')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 04. NIVEAUX — niveaux scolaires au sein d'un cycle
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('niveaux')) {
            Schema::create('niveaux', function (Blueprint $table) {
                $table->id();
                $table->foreignId('cycle_id')->constrained('cycles')->restrictOnDelete();
                $table->json('libelle');              // {'fr':'Sixième','en':'Year 7','ar':'السادسة'}
                $table->string('code')->unique();     // 'SIX','CM2','TLE','L1-INFO'
                $table->string('abreviation')->nullable(); // '6e', 'Tle'
                $table->integer('ordre')->default(1);
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->json('meta_data')->nullable(); // {age_min, age_max, seuil_redoublement}
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 05. FILIÈRES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('filieres')) {
            Schema::create('filieres', function (Blueprint $table) {
                $table->id();
                $table->json('libelle');              // {'fr':'Scientifique','en':'Science'}
                $table->string('code')->unique();     // 'SCI'|'LITT'|'TECH'|'INFO'|'GESTION'
                $table->string('abreviation')->nullable();
                $table->string('couleur')->default('#10b981');
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 06. NIVEAU_FILIERE — pivot : un niveau peut avoir plusieurs filières
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('niveau_filiere')) {
            Schema::create('niveau_filiere', function (Blueprint $table) {
                $table->id();
                $table->foreignId('niveau_id')->constrained('niveaux')->cascadeOnDelete();
                $table->foreignId('filiere_id')->constrained('filieres')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['niveau_id', 'filiere_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 07. BÂTIMENTS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('batiments')) {
            Schema::create('batiments', function (Blueprint $table) {
                $table->id();
                $table->json('libelle');              // {'fr':'Bâtiment A','en':'Building A'}
                $table->string('code')->unique();     // 'BAT-A'
                $table->text('description')->nullable();
                $table->boolean('actif')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 08. SALLES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('salles')) {
            Schema::create('salles', function (Blueprint $table) {
                $table->id();
                $table->foreignId('batiment_id')->nullable()->constrained('batiments')->nullOnDelete();
                $table->json('libelle');              // {'fr':'Salle 101','en':'Room 101'}
                $table->string('code')->unique();     // 'S101', 'LABO-SVT', 'AMPHI-A'
                $table->string('type')->default('classe'); // 'classe'|'laboratoire'|'amphi'|'informatique'|'sport'
                $table->unsignedInteger('capacite')->default(40);
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->json('equipements')->nullable(); // ['projecteur','tableau_blanc']
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 09. CLASSES — groupe d'élèves par niveau/année
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('classes')) {
            Schema::create('classes', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('niveau_id')->constrained('niveaux')->restrictOnDelete();
                $table->foreignId('filiere_id')->nullable()->constrained('filieres')->nullOnDelete();
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();
                $table->unsignedBigInteger('professeur_principal_id')->nullable()->index();
                $table->json('libelle');              // {'fr':'Sixième A','en':'Year 7A'}
                $table->string('code')->index();      // '6A', 'TLE-S1', 'L1-INFO-A'
                $table->string('abreviation')->nullable();
                $table->unsignedInteger('effectif_max')->default(60);
                $table->unsignedInteger('effectif_actuel')->default(0);
                $table->string('langue_enseignement')->nullable(); // 'fr'|'en'|'ar'
                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['annee_scolaire_id', 'code']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 10. MATIÈRES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('matieres')) {
            Schema::create('matieres', function (Blueprint $table) {
                $table->id();
                $table->json('libelle');              // {'fr':'Mathématiques','en':'Mathematics','ar':'الرياضيات'}
                $table->string('code')->unique();     // 'MATH','FR','PHYS','INFO'
                $table->string('abreviation')->nullable();
                // 'litteraire'|'scientifique'|'technique'|'sportif'|'artistique'|'autre'
                $table->string('groupe')->default('autre');
                $table->string('couleur')->default('#6366f1');
                $table->string('icone')->nullable();
                $table->boolean('actif')->default(true);
                $table->boolean('est_principale')->default(false);
                $table->text('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 11. PROGRAMMES — ensemble de matières par niveau/filière/année
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('programmes')) {
            Schema::create('programmes', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('niveau_id')->constrained('niveaux')->restrictOnDelete();
                $table->foreignId('filiere_id')->nullable()->constrained('filieres')->nullOnDelete();
                $table->json('libelle');              // {'fr':'Programme Tle S 2024-2025'}
                $table->string('code');               // 'PROG-TLE-S-2024'
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['annee_scolaire_id', 'niveau_id', 'filiere_id', 'code'], 'prog_unique');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 12. PROGRAMME_MATIERE — pivot avec coefficient et volume horaire
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('programme_matiere')) {
            Schema::create('programme_matiere', function (Blueprint $table) {
                $table->id();
                $table->foreignId('programme_id')->constrained('programmes')->cascadeOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->decimal('coefficient', 5, 2)->default(1.00);
                $table->decimal('volume_horaire_semaine', 5, 2)->nullable();
                $table->unsignedInteger('ordre')->default(1);
                $table->boolean('est_eliminatoire')->default(false);
                $table->decimal('note_eliminatoire', 5, 2)->nullable();
                $table->boolean('sur_bulletin')->default(true);
                $table->timestamps();
                $table->unique(['programme_id', 'matiere_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 13. PERSONNELS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('personnels')) {
            Schema::create('personnels', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // Matricule interne
                $table->string('nom');
                $table->string('prenom');
                // nom_complet est un accesseur calculé dans le modèle (non stocké en base)
                $table->string('sexe')->nullable();       // 'M'|'F'|'autre'
                $table->string('civilite')->nullable();   // 'M.'|'Mme'|'Dr'|'Pr'
                $table->date('date_naissance')->nullable();
                $table->string('lieu_naissance')->nullable();
                $table->string('nationalite')->nullable();
                $table->string('numero_cni')->nullable();
                // 'enseignant'|'administratif'|'technique'|'direction'
                $table->string('type')->default('administratif')->index();
                $table->string('poste')->nullable();
                $table->string('grade')->nullable();
                // 'titulaire'|'vacataire'|'contractuel'|'stagiaire'|'benevole'
                $table->string('statut_contrat')->nullable();
                $table->date('date_embauche')->nullable();
                $table->date('date_fin_contrat')->nullable();
                $table->string('email')->nullable();
                $table->string('telephone')->nullable();
                $table->string('telephone_urgence')->nullable();
                $table->string('adresse')->nullable();
                $table->boolean('a_compte_utilisateur')->default(false);
                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 14. ENSEIGNANTS — extension pédagogique d'un personnel
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('enseignants')) {
            Schema::create('enseignants', function (Blueprint $table) {
                $table->id();
                $table->foreignId('personnel_id')->unique()->constrained('personnels')->cascadeOnDelete();
                $table->foreignId('matiere_principale_id')->nullable()->constrained('matieres')->nullOnDelete();
                $table->string('diplome')->nullable();
                $table->string('specialite')->nullable();
                $table->decimal('volume_horaire_contrat', 5, 2)->nullable();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 15. ENSEIGNANT_MATIERE — matières habilitées
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('enseignant_matiere')) {
            Schema::create('enseignant_matiere', function (Blueprint $table) {
                $table->id();
                $table->foreignId('enseignant_id')->constrained('enseignants')->cascadeOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['enseignant_id', 'matiere_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 16. ATTRIBUTIONS DE COURS — feuille de service
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('attributions_cours')) {
            Schema::create('attributions_cours', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('enseignant_id')->constrained('enseignants')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->cascadeOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->decimal('volume_horaire_semaine', 5, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->nullable();
                $table->boolean('actif')->default(true);
                $table->date('date_debut')->nullable();
                $table->date('date_fin')->nullable();
                $table->text('observations')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(
                    ['annee_scolaire_id', 'enseignant_id', 'classe_id', 'matiere_id'],
                    'attr_cours_unique'
                );
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 17. EMPLOIS DU TEMPS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('emplois_du_temps')) {
            Schema::create('emplois_du_temps', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->cascadeOnDelete();
                $table->json('libelle')->nullable();
                $table->string('code')->nullable();
                // 'brouillon'|'publie'|'archive'
                $table->string('statut')->default('brouillon');
                $table->date('date_debut_validite')->nullable();
                $table->date('date_fin_validite')->nullable();
                $table->boolean('est_actif')->default(true);
                $table->text('observations')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 18. CRÉNEAUX — séances de cours dans la grille
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('creneaux')) {
            Schema::create('creneaux', function (Blueprint $table) {
                $table->id();
                $table->foreignId('emploi_du_temps_id')->constrained('emplois_du_temps')->cascadeOnDelete();
                $table->foreignId('attribution_cours_id')->nullable()->constrained('attributions_cours')->nullOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();
                $table->unsignedTinyInteger('jour_semaine'); // 1=Lun … 7=Dim (ISO 8601)
                $table->time('heure_debut');
                $table->time('heure_fin');
                // 'cours'|'td'|'tp'|'examen'|'permanence'|'pause'|'autre'
                $table->string('type')->default('cours');
                // 'toutes_semaines'|'semaines_paires'|'semaines_impaires'
                $table->string('recurrence')->default('toutes_semaines');
                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 19. EXCEPTIONS EDT — cours annulés, déplacés, jours fériés
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('exceptions_edt')) {
            Schema::create('exceptions_edt', function (Blueprint $table) {
                $table->id();
                $table->foreignId('creneau_id')->constrained('creneaux')->cascadeOnDelete();
                $table->date('date_exception');
                // 'annule'|'reporte'|'remplace'
                $table->string('type')->default('annule');
                $table->foreignId('nouveau_creneau_id')->nullable()->constrained('creneaux')->nullOnDelete();
                $table->date('nouvelle_date')->nullable();
                $table->time('nouvelle_heure_debut')->nullable();
                $table->time('nouvelle_heure_fin')->nullable();
                $table->foreignId('nouvelle_salle_id')->nullable()->constrained('salles')->nullOnDelete();
                $table->json('motif')->nullable(); // {'fr':'Jour férié','en':'Public holiday'}
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['creneau_id', 'date_exception']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 20. ÉLÈVES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('eleves')) {
            Schema::create('eleves', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // Matricule auto-généré
                $table->string('nom');
                $table->string('prenom');
                $table->string('sexe')->nullable();           // 'M'|'F'
                $table->date('date_naissance')->nullable();
                $table->string('lieu_naissance')->nullable();
                $table->string('nationalite')->nullable();
                $table->string('numero_extrait')->nullable(); // Extrait de naissance
                $table->string('photo')->nullable();
                $table->string('email')->nullable();
                $table->string('telephone')->nullable();
                $table->string('adresse')->nullable();
                $table->string('groupe_sanguin')->nullable();  // 'A+'|'O-'…
                $table->text('allergies')->nullable();
                $table->text('infos_medicales')->nullable();
                $table->string('ecole_precedente')->nullable();
                $table->string('classe_precedente')->nullable();
                $table->string('annee_precedente')->nullable();
                $table->string('langue_maternelle')->nullable();
                $table->boolean('a_compte_utilisateur')->default(false);
                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 21. PARENTS / TUTEURS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('parents_tuteurs')) {
            Schema::create('parents_tuteurs', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->string('nom');
                $table->string('prenom');
                $table->string('sexe')->nullable();
                $table->string('civilite')->nullable();
                $table->string('profession')->nullable();
                $table->string('lieu_travail')->nullable();
                $table->string('email')->nullable();
                $table->string('telephone')->nullable()->index();
                $table->string('telephone_travail')->nullable();
                $table->string('adresse')->nullable();
                $table->string('numero_cni')->nullable();
                $table->boolean('a_compte_utilisateur')->default(false);
                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 22. ÉLÈVE_PARENT — pivot avec lien de parenté
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('eleve_parent')) {
            Schema::create('eleve_parent', function (Blueprint $table) {
                $table->id();
                $table->foreignId('eleve_id')->constrained('eleves')->cascadeOnDelete();
                $table->foreignId('parent_tuteur_id')->constrained('parents_tuteurs')->cascadeOnDelete();
                // 'pere'|'mere'|'tuteur'|'grand_parent'|'autre'
                $table->string('lien_parente')->default('tuteur');
                $table->boolean('est_contact_principal')->default(false);
                $table->boolean('peut_recuperer')->default(true);
                $table->boolean('acces_portail')->default(false);
                $table->timestamps();
                $table->unique(['eleve_id', 'parent_tuteur_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 23. INSCRIPTIONS — nœud central (élève × classe × année)
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('inscriptions')) {
            Schema::create('inscriptions', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // INS-2024-00001
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('eleve_id')->constrained('eleves')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('inscription_precedente_id')
                    ->nullable()->constrained('inscriptions')->nullOnDelete();
                // 'en_attente'|'validee'|'rejetee'|'annulee'|'transferee'
                $table->string('statut')->default('en_attente')->index();
                $table->date('date_inscription')->nullable();
                $table->date('date_validation')->nullable();
                $table->unsignedBigInteger('valide_par')->nullable();
                // 'admis'|'redouble'|'oriente'|'exclu'|'abandonne'|'transfere'
                $table->string('resultat')->nullable()->index();
                $table->decimal('moyenne_annuelle', 6, 2)->nullable();
                $table->unsignedInteger('rang_annuel')->nullable();
                $table->string('etablissement_origine')->nullable();
                $table->string('etablissement_destination')->nullable();
                $table->string('numero_table')->nullable();
                $table->boolean('est_boursier')->default(false);
                $table->boolean('est_redoublant')->default(false);
                $table->boolean('est_transfere')->default(false);
                $table->text('motif_rejet')->nullable();
                $table->text('observations')->nullable();
                $table->json('documents')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['annee_scolaire_id', 'eleve_id'], 'inscription_unique_par_an');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 24. ÉVALUATIONS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('evaluations')) {
            Schema::create('evaluations', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();
                $table->json('libelle');               // {'fr':'Devoir Surveillé N°1','en':'Test 1'}
                $table->string('code')->nullable();    // 'DS1-MATH-6A-SEQ1'
                // 'devoir'|'examen'|'controle'|'tp'|'oral'|'projet'|'autre'
                $table->string('type')->default('devoir');
                $table->decimal('note_sur', 5, 2)->default(20.00);
                $table->decimal('coefficient', 5, 2)->default(1.00);
                $table->decimal('ponderation', 5, 2)->default(100.00); // % du poids dans la période
                $table->date('date_evaluation')->nullable();
                $table->date('date_saisie_limite')->nullable();
                // 'planifiee'|'en_cours'|'corrigee'|'saisie'|'validee'
                $table->string('statut')->default('planifiee')->index();
                $table->boolean('publiee')->default(false);
                $table->text('consignes')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 25. NOTES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('notes')) {
            Schema::create('notes', function (Blueprint $table) {
                $table->id();
                $table->foreignId('evaluation_id')->constrained('evaluations')->cascadeOnDelete();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->decimal('note', 6, 2)->nullable();
                $table->decimal('bonus', 5, 2)->default(0);
                $table->decimal('malus', 5, 2)->default(0);
                $table->decimal('note_finale', 6, 2)->nullable(); // note + bonus - malus
                $table->boolean('est_absent')->default(false);
                $table->boolean('absence_justifiee')->default(false);
                $table->boolean('est_manquante')->default(false);
                $table->string('appreciation')->nullable();
                $table->unsignedInteger('rang')->nullable();
                $table->boolean('validee')->default(false);
                $table->unsignedBigInteger('validee_par')->nullable();
                $table->timestamp('validee_at')->nullable();
                $table->text('observations')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['evaluation_id', 'inscription_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 26. MOYENNES PAR MATIÈRE (par période)
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('moyennes_matieres')) {
            Schema::create('moyennes_matieres', function (Blueprint $table) {
                $table->id();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->decimal('moyenne', 6, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->default(1.00);
                $table->decimal('moyenne_ponderee', 8, 2)->nullable(); // moyenne × coefficient
                $table->unsignedInteger('rang')->nullable();
                $table->decimal('moyenne_classe', 6, 2)->nullable();
                $table->decimal('note_max_classe', 6, 2)->nullable();
                $table->decimal('note_min_classe', 6, 2)->nullable();
                $table->string('appreciation')->nullable();
                $table->boolean('est_eliminatoire')->default(false);
                $table->boolean('est_manuelle')->default(false);
                $table->boolean('validee')->default(false);
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['inscription_id', 'periode_id', 'matiere_id'], 'moy_mat_unique');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 27. MOYENNES GÉNÉRALES PAR PÉRIODE
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('moyennes_periodes')) {
            Schema::create('moyennes_periodes', function (Blueprint $table) {
                $table->id();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->decimal('moyenne_generale', 6, 2)->nullable();
                $table->decimal('total_points', 8, 2)->nullable();
                $table->decimal('total_coefficients', 8, 2)->nullable();
                $table->unsignedInteger('rang')->nullable();
                $table->unsignedInteger('effectif_classe')->nullable();
                $table->decimal('moyenne_classe', 6, 2)->nullable();
                $table->decimal('moyenne_max_classe', 6, 2)->nullable();
                $table->decimal('moyenne_min_classe', 6, 2)->nullable();
                // 'Excellent'|'Très Bien'|'Bien'|'Assez Bien'|'Passable'|'Insuffisant'
                $table->string('mention')->nullable();
                $table->json('appreciation_globale')->nullable(); // multilingue
                // 'passage_autorise'|'passage_conditionnel'|'redoublement'|'orientation'
                $table->string('decision_conseil')->nullable();
                $table->text('observation_conseil')->nullable();
                $table->unsignedInteger('absences_justifiees')->default(0);
                $table->unsignedInteger('absences_injustifiees')->default(0);
                $table->unsignedInteger('retards')->default(0);
                $table->boolean('validee')->default(false);
                $table->unsignedBigInteger('validee_par')->nullable();
                $table->timestamp('validee_at')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['inscription_id', 'periode_id'], 'moy_periode_unique');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 28. BULLETINS — document officiel par élève par période
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('bulletins')) {
            Schema::create('bulletins', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // BUL-2024-001-SEQ1
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->foreignId('moyenne_periode_id')->nullable()->constrained('moyennes_periodes')->nullOnDelete();
                // 'brouillon'|'genere'|'valide'|'publie'|'archive'
                $table->string('statut')->default('brouillon')->index();
                $table->string('fichier_pdf')->nullable();
                $table->string('nom_directeur')->nullable();
                $table->string('nom_professeur_principal')->nullable();
                $table->string('signature_hash')->nullable();
                $table->timestamp('genere_at')->nullable();
                $table->timestamp('valide_at')->nullable();
                $table->timestamp('publie_at')->nullable();
                $table->boolean('visible_portail')->default(false);
                // 'standard'|'detaille'|'compact'
                $table->string('layout')->default('standard');
                $table->json('meta_data')->nullable(); // snapshot données au moment de la génération
                $table->text('observations')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['inscription_id', 'periode_id'], 'bulletin_unique');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 29. PRÉSENCES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('presences')) {
            Schema::create('presences', function (Blueprint $table) {
                $table->id();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('creneau_id')->nullable()->constrained('creneaux')->nullOnDelete();
                $table->foreignId('matiere_id')->nullable()->constrained('matieres')->nullOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();
                $table->date('date');
                // 'creneau'|'demi_journee'|'journee'
                $table->string('mode')->default('journee');
                // 'matin'|'apres_midi'|'journee_complete' — null si mode=creneau
                $table->string('periode_journee')->nullable();
                // 'present'|'absent'|'retard'|'exclusion'
                $table->string('statut')->default('present')->index();
                $table->unsignedInteger('retard_minutes')->default(0);
                $table->unsignedBigInteger('justification_id')->nullable(); // FK ajoutée après
                $table->boolean('est_justifiee')->default(false);
                $table->unsignedBigInteger('saisi_par')->nullable();
                $table->text('observations')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->index(['inscription_id', 'date']);
                $table->index(['date', 'statut']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 30. JUSTIFICATIONS D'ABSENCE
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('justifications_absence')) {
            Schema::create('justifications_absence', function (Blueprint $table) {
                $table->id();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->date('date_debut');
                $table->date('date_fin');
                // 'maladie'|'deuil'|'evenement_famille'|'voyage'|'autre'
                $table->string('motif')->default('autre');
                $table->text('motif_detail')->nullable();
                $table->string('document')->nullable();
                // 'en_attente'|'acceptee'|'rejetee'
                $table->string('statut')->default('en_attente');
                $table->unsignedBigInteger('traitee_par')->nullable();
                $table->timestamp('traitee_at')->nullable();
                $table->text('motif_rejet')->nullable();
                $table->string('soumis_par_type')->nullable(); // 'parent_tuteur'|'eleve'|'admin'
                $table->unsignedBigInteger('soumis_par_id')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 31. FK CIRCULAIRE : presences → justifications_absence
        // ══════════════════════════════════════════════════════════════════════
        Schema::table('presences', function (Blueprint $table) {
            $table->foreign('justification_id')
                ->references('id')
                ->on('justifications_absence')
                ->nullOnDelete();
        });

        // ══════════════════════════════════════════════════════════════════════
        // 32. TYPES DE FRAIS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('types_frais')) {
            Schema::create('types_frais', function (Blueprint $table) {
                $table->id();
                $table->json('libelle');               // {'fr':'Frais de scolarité','en':'Tuition fees'}
                $table->string('code')->unique();      // 'SCOLARITE'|'INSCRIPTION'|'CANTINE'|'TRANSPORT'
                // 'obligatoire'|'optionnel'|'conditionnel'
                $table->string('caracteristique')->default('obligatoire');
                $table->boolean('actif')->default(true);
                $table->integer('ordre')->default(1);
                $table->text('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 33. BARÈMES DE FRAIS — montants de référence par niveau/filière/année
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('baremes_frais')) {
            Schema::create('baremes_frais', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('type_frais_id')->constrained('types_frais')->restrictOnDelete();
                $table->foreignId('niveau_id')->nullable()->constrained('niveaux')->nullOnDelete();
                $table->foreignId('filiere_id')->nullable()->constrained('filieres')->nullOnDelete();
                $table->decimal('montant', 12, 2);
                $table->string('devise', 3)->default('XAF');
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(
                    ['annee_scolaire_id', 'type_frais_id', 'niveau_id', 'filiere_id'],
                    'bareme_unique'
                );
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 34. FRAIS SCOLAIRES — frais individualisés par inscription
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('frais_scolaires')) {
            Schema::create('frais_scolaires', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // FRS-2024-00001
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->foreignId('type_frais_id')->constrained('types_frais')->restrictOnDelete();
                $table->decimal('montant_brut', 12, 2);
                $table->decimal('remise', 12, 2)->default(0);
                $table->decimal('montant_net', 12, 2);
                $table->decimal('montant_paye', 12, 2)->default(0);
                $table->decimal('montant_restant', 12, 2);
                $table->string('devise', 3)->default('XAF');
                // 'en_attente'|'partiel'|'solde'|'exonere'|'annule'
                $table->string('statut')->default('en_attente')->index();
                $table->boolean('est_exonere')->default(false);
                $table->text('motif_exoneration')->nullable();
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['inscription_id', 'type_frais_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 35. ÉCHÉANCES DE PAIEMENT
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('echeances')) {
            Schema::create('echeances', function (Blueprint $table) {
                $table->id();
                $table->foreignId('frais_scolaire_id')->constrained('frais_scolaires')->cascadeOnDelete();
                $table->json('libelle')->nullable(); // {'fr':'1er versement','en':'1st payment'}
                $table->integer('ordre')->default(1);
                $table->decimal('montant', 12, 2);
                $table->date('date_echeance');
                // 'en_attente'|'en_retard'|'partiel'|'solde'
                $table->string('statut')->default('en_attente')->index();
                $table->decimal('montant_paye', 12, 2)->default(0);
                $table->decimal('montant_restant', 12, 2);
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 36. PAIEMENTS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('paiements')) {
            Schema::create('paiements', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique(); // PAY-2024-00001
                $table->foreignId('frais_scolaire_id')->constrained('frais_scolaires')->cascadeOnDelete();
                $table->foreignId('echeance_id')->nullable()->constrained('echeances')->nullOnDelete();
                $table->decimal('montant', 12, 2);
                $table->string('devise', 3)->default('XAF');
                $table->date('date_paiement');
                // 'espece'|'virement'|'cheque'|'mobile_money'|'carte'|'autre'
                $table->string('mode_paiement')->default('espece');
                $table->string('numero_transaction')->nullable();
                // 'en_attente'|'confirme'|'rejete'|'rembourse'
                $table->string('statut')->default('confirme')->index();
                $table->string('fichier_recu')->nullable();
                $table->boolean('recu_envoye')->default(false);
                $table->unsignedBigInteger('encaisse_par')->nullable();
                $table->text('notes')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 37. BOURSES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('bourses')) {
            Schema::create('bourses', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->json('libelle');              // {'fr':'Bourse d\'excellence'}
                // 'excellence'|'sociale'|'etat'|'autre'
                $table->string('type')->default('autre');
                $table->decimal('montant', 12, 2);
                $table->string('devise', 3)->default('XAF');
                // 'totale'|'partielle'
                $table->string('couverture')->default('partielle');
                $table->decimal('taux_couverture', 5, 2)->nullable();
                $table->date('date_attribution');
                $table->date('date_fin')->nullable();
                // 'en_attente'|'active'|'suspendue'|'retiree'
                $table->string('statut')->default('en_attente');
                $table->string('organisme')->nullable();
                $table->text('conditions')->nullable();
                $table->text('observations')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 38. ANNONCES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('annonces')) {
            Schema::create('annonces', function (Blueprint $table) {
                $table->id();
                $table->json('titre');                // {'fr':'Réunion parents','en':'Parent meeting'}
                $table->json('contenu');
                $table->unsignedBigInteger('auteur_id')->index();
                // 'tous'|'eleves'|'parents'|'enseignants'|'personnel'|'classe'|'niveau'
                $table->string('audience_type')->default('tous');
                $table->json('audience_ids')->nullable();
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();
                // 'brouillon'|'publiee'|'archivee'
                $table->string('statut')->default('brouillon')->index();
                // 'normale'|'importante'|'urgente'
                $table->string('importance')->default('normale');
                $table->timestamp('publiee_at')->nullable();
                $table->timestamp('expire_at')->nullable();
                $table->boolean('notification_email')->default(false);
                $table->boolean('notification_sms')->default(false);
                $table->unsignedInteger('vues_count')->default(0);
                $table->json('pieces_jointes')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 39. ANNONCE_LECTURES — suivi des lectures par utilisateur
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('annonce_lectures')) {
            Schema::create('annonce_lectures', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annonce_id')->constrained('annonces')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id')->index();
                $table->timestamp('lu_at')->useCurrent();
                $table->unique(['annonce_id', 'user_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 40. CONVERSATIONS — messagerie interne
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('conversations')) {
            Schema::create('conversations', function (Blueprint $table) {
                $table->id();
                $table->json('sujet')->nullable();
                // 'prive'|'groupe'
                $table->string('type')->default('prive');
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();
                $table->timestamp('dernier_message_at')->nullable()->index();
                $table->unsignedInteger('messages_count')->default(0);
                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 41. CONVERSATION_PARTICIPANTS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('conversation_participants')) {
            Schema::create('conversation_participants', function (Blueprint $table) {
                $table->id();
                $table->foreignId('conversation_id')->constrained('conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id')->index();
                $table->timestamp('dernier_vu_at')->nullable();
                $table->boolean('est_admin')->default(false);
                $table->boolean('est_mute')->default(false);
                $table->timestamps();
                $table->unique(['conversation_id', 'user_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 42. MESSAGES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('messages')) {
            Schema::create('messages', function (Blueprint $table) {
                $table->id();
                $table->foreignId('conversation_id')->constrained('conversations')->cascadeOnDelete();
                $table->unsignedBigInteger('expediteur_id')->index();
                $table->foreignId('parent_id')->nullable()->constrained('messages')->nullOnDelete();
                $table->text('contenu');
                // 'texte'|'image'|'fichier'
                $table->string('type_contenu')->default('texte');
                $table->json('pieces_jointes')->nullable();
                // 'envoye'|'lu'|'supprime'
                $table->string('statut')->default('envoye');
                $table->softDeletes();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 43. ÉVÉNEMENTS AGENDA
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('evenements_agenda')) {
            Schema::create('evenements_agenda', function (Blueprint $table) {
                $table->id();
                $table->json('titre');
                $table->json('description')->nullable();
                // 'conseil_classe'|'examen'|'vacances'|'reunion'|'sortie'|'ferie'|'autre'
                $table->string('type')->default('autre');
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();
                $table->string('audience_type')->default('tous');
                $table->json('audience_ids')->nullable();
                $table->dateTime('debut_at');
                $table->dateTime('fin_at')->nullable();
                $table->boolean('journee_entiere')->default(false);
                $table->boolean('recurrent')->default(false);
                $table->json('recurrence_config')->nullable();
                $table->string('lieu')->nullable();
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();
                $table->string('couleur')->default('#3b82f6');
                $table->string('icone')->nullable();
                $table->boolean('publie')->default(true);
                $table->boolean('notification_envoye')->default(false);
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 44. SANCTIONS DISCIPLINAIRES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('sanctions')) {
            Schema::create('sanctions', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                // 'avertissement'|'blame'|'exclusion_temp'|'exclusion_def'|'punition'|'convocation_parent'
                $table->string('type')->default('avertissement');
                $table->json('libelle')->nullable();
                $table->text('motif');
                $table->date('date_sanction');
                $table->date('date_fin')->nullable();
                $table->unsignedBigInteger('prononcee_par')->nullable();
                // 'en_cours'|'levee'|'archive'
                $table->string('statut')->default('en_cours');
                $table->boolean('parent_informe')->default(false);
                $table->timestamp('parent_informe_at')->nullable();
                $table->text('suite_donnee')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 45. CONSEILS DE CLASSE
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('conseils_classe')) {
            Schema::create('conseils_classe', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('periode_id')->constrained('periodes')->restrictOnDelete();
                $table->json('titre')->nullable();
                $table->dateTime('date_conseil');
                $table->string('lieu')->nullable();
                // 'planifie'|'tenu'|'pv_redige'|'valide'
                $table->string('statut')->default('planifie');
                $table->unsignedBigInteger('president_id')->nullable();
                $table->longText('pv_contenu')->nullable();
                $table->string('pv_fichier')->nullable();
                $table->timestamp('valide_at')->nullable();
                $table->unsignedBigInteger('valide_par')->nullable();
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['classe_id', 'periode_id'], 'conseil_unique');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 46. CONSEIL_PARTICIPANTS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('conseil_participants')) {
            Schema::create('conseil_participants', function (Blueprint $table) {
                $table->id();
                $table->foreignId('conseil_classe_id')->constrained('conseils_classe')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id');
                // 'president'|'secretaire'|'membre'
                $table->string('role_conseil')->nullable();
                $table->boolean('present')->default(true);
                $table->boolean('a_signe')->default(false);
                $table->timestamps();
                $table->unique(['conseil_classe_id', 'user_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 47. RESSOURCES PÉDAGOGIQUES
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('ressources_pedagogiques')) {
            Schema::create('ressources_pedagogiques', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();
                $table->foreignId('matiere_id')->nullable()->constrained('matieres')->nullOnDelete();
                $table->foreignId('classe_id')->nullable()->constrained('classes')->nullOnDelete();
                $table->foreignId('niveau_id')->nullable()->constrained('niveaux')->nullOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();
                $table->json('titre');
                $table->json('description')->nullable();
                // 'document'|'video'|'audio'|'lien'|'image'|'exercice'|'corrige'|'autre'
                $table->string('type')->default('document');
                $table->string('fichier')->nullable();
                $table->string('url_externe')->nullable();
                $table->string('mime_type')->nullable();
                $table->unsignedBigInteger('taille_fichier')->nullable();
                // 'classe'|'niveau'|'enseignants'|'tous'
                $table->string('audience')->default('classe');
                $table->boolean('publie')->default(false);
                $table->unsignedInteger('telechargements')->default(0);
                $table->unsignedInteger('vues')->default(0);
                $table->json('tags')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 48. DEVOIRS MAISON
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('devoirs_maison')) {
            Schema::create('devoirs_maison', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->restrictOnDelete();
                $table->foreignId('classe_id')->constrained('classes')->restrictOnDelete();
                $table->foreignId('matiere_id')->constrained('matieres')->restrictOnDelete();
                $table->foreignId('enseignant_id')->nullable()->constrained('enseignants')->nullOnDelete();
                $table->foreignId('periode_id')->nullable()->constrained('periodes')->nullOnDelete();
                $table->foreignId('evaluation_id')->nullable()->constrained('evaluations')->nullOnDelete();
                $table->json('titre');
                $table->json('instructions')->nullable();
                $table->date('date_attribution');
                $table->dateTime('date_limite_remise');
                $table->boolean('est_note')->default(false);
                $table->decimal('note_sur', 5, 2)->nullable();
                $table->decimal('coefficient', 5, 2)->default(1.00);
                // 'brouillon'|'publie'|'cloture'
                $table->string('statut')->default('publie');
                $table->json('ressources')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 49. SOUMISSIONS DE DEVOIRS
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('soumissions_devoirs')) {
            Schema::create('soumissions_devoirs', function (Blueprint $table) {
                $table->id();
                $table->foreignId('devoir_maison_id')->constrained('devoirs_maison')->cascadeOnDelete();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->string('fichier')->nullable();
                $table->text('commentaire')->nullable();
                $table->timestamp('soumis_at')->nullable();
                $table->boolean('en_retard')->default(false);
                $table->decimal('note', 6, 2)->nullable();
                $table->text('correction')->nullable();
                $table->string('fichier_correction')->nullable();
                $table->timestamp('corrige_at')->nullable();
                // 'soumis'|'corrige'|'rendu'
                $table->string('statut')->default('soumis');
                $table->timestamps();
                $table->unique(['devoir_maison_id', 'inscription_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 50. PARAMÈTRES SYSTÈME
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('parametres_school')) {
            Schema::create('parametres_school', function (Blueprint $table) {
                $table->id();
                $table->string('cle')->unique();
                $table->text('valeur')->nullable();
                // 'general'|'notation'|'bulletin'|'inscription'|'finances'|'communication'
                $table->string('groupe')->default('general')->index();
                // 'string'|'integer'|'decimal'|'boolean'|'json'|'array'|'date'
                $table->string('type_valeur')->default('string');
                $table->json('libelle')->nullable();
                $table->text('description')->nullable();
                $table->boolean('modifiable')->default(true);
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 51. NOTIFICATIONS IN-APP
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('notifications_school')) {
            Schema::create('notifications_school', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id')->index();
                $table->json('titre');
                $table->json('corps')->nullable();
                // 'info'|'succes'|'alerte'|'erreur'
                $table->string('type')->default('info');
                // 'note'|'bulletin'|'absence'|'paiement'|'annonce'|'devoir'|'autre'
                $table->string('categorie')->default('autre');
                $table->string('notifiable_type')->nullable();
                $table->unsignedBigInteger('notifiable_id')->nullable();
                $table->index(['notifiable_type', 'notifiable_id']);
                $table->string('url')->nullable();
                $table->boolean('lue')->default(false)->index();
                $table->timestamp('lue_at')->nullable();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 52. IMPORTS / EXPORTS — traçabilité des opérations batch
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('imports_exports')) {
            Schema::create('imports_exports', function (Blueprint $table) {
                $table->id();
                // 'import'|'export'
                $table->string('operation')->default('import');
                // 'eleves'|'enseignants'|'notes'|'bulletins'|'paiements'…
                $table->string('entite');
                // 'csv'|'xlsx'|'pdf'|'json'|'zip'
                $table->string('format')->default('csv');
                $table->string('fichier')->nullable();
                // 'en_attente'|'en_cours'|'termine'|'echec'|'partiel'
                $table->string('statut')->default('en_attente');
                $table->unsignedInteger('total_lignes')->default(0);
                $table->unsignedInteger('lignes_ok')->default(0);
                $table->unsignedInteger('lignes_erreur')->default(0);
                $table->unsignedInteger('lignes_ignorees')->default(0);
                $table->json('rapport_erreurs')->nullable();
                $table->foreignId('annee_scolaire_id')->nullable()->constrained('annees_scolaires')->nullOnDelete();
                $table->timestamp('debut_at')->nullable();
                $table->timestamp('fin_at')->nullable();
                $table->text('notes')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 53. CERTIFICATS DE SCOLARITÉ — documents officiels délivrés
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('certificats_scolarite')) {
            Schema::create('certificats_scolarite', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->unique();
                $table->foreignId('inscription_id')->constrained('inscriptions')->restrictOnDelete();
                // 'certificat_scolarite'|'attestation_frequentation'|'releve_notes'
                // 'diplome'|'attestation_transfert'|'recu_inscription'|'autre'
                $table->string('type')->default('certificat_scolarite')->index();
                $table->json('titre');  // {'fr':'Certificat de scolarité','en':'School Certificate'}
                $table->string('motif')->nullable();
                $table->text('motif_detail')->nullable();
                $table->string('destinataire')->nullable();
                $table->string('langue')->default('fr');
                $table->string('fichier_pdf')->nullable();
                $table->string('signature_hash')->nullable();
                $table->string('qr_code')->nullable();
                // 'demande'|'en_cours'|'delivre'|'annule'
                $table->string('statut')->default('demande')->index();
                $table->unsignedBigInteger('demande_par')->nullable();
                $table->timestamp('demande_at')->nullable();
                $table->unsignedBigInteger('delivre_par')->nullable();
                $table->timestamp('delivre_at')->nullable();
                $table->unsignedSmallInteger('nb_exemplaires')->default(1);
                $table->date('valide_jusqu_au')->nullable();
                $table->text('observations')->nullable();
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 54. GROUPES TD/TP — sous-groupes de classe (surtout supérieur)
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('groupes_td')) {
            Schema::create('groupes_td', function (Blueprint $table) {
                $table->id();
                $table->foreignId('classe_id')->constrained('classes')->cascadeOnDelete();
                $table->foreignId('matiere_id')->nullable()->constrained('matieres')->nullOnDelete();
                $table->json('libelle');           // {'fr':'Groupe A','en':'Group A'}
                $table->string('code');
                // 'td'|'tp'|'oral'|'autre'
                $table->string('type')->default('td');
                $table->unsignedInteger('effectif_max')->default(25);
                $table->unsignedInteger('effectif_actuel')->default(0);
                $table->boolean('actif')->default(true);
                $table->text('observations')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['classe_id', 'matiere_id', 'code'], 'groupe_td_unique');
            });
        }

        // Rattacher le groupe_td aux créneaux
        if (Schema::hasTable('creneaux') && !Schema::hasColumn('creneaux', 'groupe_td_id')) {
            Schema::table('creneaux', function (Blueprint $table) {
                $table->foreignId('groupe_td_id')
                    ->nullable()->after('salle_id')
                    ->constrained('groupes_td')->nullOnDelete();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 55. GROUPE_TD_INSCRIPTION — appartenance d'un élève à un groupe
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('groupe_td_inscription')) {
            Schema::create('groupe_td_inscription', function (Blueprint $table) {
                $table->id();
                $table->foreignId('groupe_td_id')->constrained('groupes_td')->cascadeOnDelete();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['groupe_td_id', 'inscription_id']);
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 56. PÉRIODES DE CONGÉS — calendrier vacances/jours fériés
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('periodes_conges')) {
            Schema::create('periodes_conges', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->cascadeOnDelete();
                $table->json('libelle');           // {'fr':'Vacances de Noël','en':'Christmas break'}
                // 'vacances'|'ferie'|'examen'|'evenement'|'autre'
                $table->string('type')->default('vacances')->index();
                $table->date('date_debut');
                $table->date('date_fin');
                // 'etablissement'|'national'|'regional'
                $table->string('portee')->default('etablissement');
                $table->boolean('cours_suspendus')->default(true);
                $table->boolean('absences_neutralisees')->default(true);
                $table->string('couleur')->default('#f59e0b');
                $table->boolean('actif')->default(true);
                $table->text('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 57–59. MODULE RESTAURATION (optionnel)
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('menus_cantine')) {
            Schema::create('menus_cantine', function (Blueprint $table) {
                $table->id();
                $table->foreignId('annee_scolaire_id')->constrained('annees_scolaires')->cascadeOnDelete();
                $table->json('libelle');
                $table->json('description')->nullable();
                $table->date('date');
                // 'petit_dejeuner'|'dejeuner'|'gouter'|'diner'
                $table->string('type_repas')->default('dejeuner');
                $table->decimal('prix', 10, 2)->default(0);
                $table->string('devise', 3)->default('XAF');
                $table->unsignedInteger('capacite')->default(0);
                $table->unsignedInteger('reservations_count')->default(0);
                $table->json('allergenes')->nullable();
                $table->json('valeurs_nutritives')->nullable();
                $table->boolean('actif')->default(true);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
                $table->unique(['annee_scolaire_id', 'date', 'type_repas'], 'menu_unique');
            });
        }

        if (!Schema::hasTable('inscriptions_cantine')) {
            Schema::create('inscriptions_cantine', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->foreignId('inscription_id')->constrained('inscriptions')->cascadeOnDelete();
                // 'annuel'|'trimestriel'|'mensuel'|'hebdomadaire'|'journalier'
                $table->string('type_abonnement')->default('mensuel');
                $table->json('jours_actifs')->nullable();  // [1,2,3,4,5] = Lun-Ven
                $table->string('type_repas')->default('dejeuner');
                $table->decimal('montant', 10, 2)->default(0);
                $table->string('devise', 3)->default('XAF');
                $table->date('date_debut');
                $table->date('date_fin')->nullable();
                // 'actif'|'suspendu'|'resilie'|'expire'
                $table->string('statut')->default('actif')->index();
                $table->string('regime')->nullable(); // 'normal'|'vegetarien'|'sans_gluten'|'halal'
                $table->text('observations')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('reservations_repas')) {
            Schema::create('reservations_repas', function (Blueprint $table) {
                $table->id();
                $table->foreignId('inscription_cantine_id')->constrained('inscriptions_cantine')->cascadeOnDelete();
                $table->foreignId('menu_cantine_id')->constrained('menus_cantine')->cascadeOnDelete();
                $table->date('date');
                // 'reservee'|'consommee'|'absente'|'annulee'
                $table->string('statut')->default('reservee');
                $table->decimal('prix_paye', 10, 2)->nullable();
                $table->timestamp('pointe_at')->nullable();
                $table->timestamps();
                $table->unique(['inscription_cantine_id', 'menu_cantine_id', 'date'], 'reservation_unique');
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 60–61. MODULE STOCK MATÉRIEL (optionnel)
        // ══════════════════════════════════════════════════════════════════════
        if (!Schema::hasTable('stock_materiel')) {
            Schema::create('stock_materiel', function (Blueprint $table) {
                $table->id();
                $table->string('reference')->nullable()->unique();
                $table->json('libelle');
                $table->json('description')->nullable();
                // 'informatique'|'mobilier'|'livre'|'fourniture'|'sport'|'science'|'audiovisuel'|'autre'
                $table->string('categorie')->default('autre')->index();
                $table->string('marque')->nullable();
                $table->string('modele')->nullable();
                $table->string('numero_serie')->nullable()->unique();
                $table->unsignedInteger('quantite_totale')->default(1);
                $table->unsignedInteger('quantite_disponible')->default(1);
                $table->unsignedInteger('quantite_affectee')->default(0);
                $table->unsignedInteger('quantite_hors_service')->default(0);
                $table->foreignId('salle_id')->nullable()->constrained('salles')->nullOnDelete();
                $table->decimal('valeur_unitaire', 12, 2)->nullable();
                $table->string('devise', 3)->default('XAF');
                $table->date('date_acquisition')->nullable();
                $table->date('date_fin_garantie')->nullable();
                // 'bon'|'use'|'a_reparer'|'hors_service'
                $table->string('etat')->default('bon');
                $table->boolean('actif')->default(true);
                $table->json('meta_data')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('mouvements_stock')) {
            Schema::create('mouvements_stock', function (Blueprint $table) {
                $table->id();
                $table->foreignId('stock_materiel_id')->constrained('stock_materiel')->cascadeOnDelete();
                // 'entree'|'sortie'|'affectation'|'retour'|'perte'|'reparation'
                $table->string('type')->default('sortie')->index();
                $table->unsignedInteger('quantite')->default(1);
                $table->date('date_mouvement');
                $table->date('date_retour_prevue')->nullable();
                $table->date('date_retour_effective')->nullable();
                $table->string('beneficiaire_type')->nullable();
                $table->unsignedBigInteger('beneficiaire_id')->nullable();
                $table->index(['beneficiaire_type', 'beneficiaire_id']);
                $table->foreignId('salle_destination_id')->nullable()->constrained('salles')->nullOnDelete();
                // 'en_cours'|'retourne'|'perdu'|'hors_service'
                $table->string('statut')->default('en_cours');
                $table->text('motif')->nullable();
                $table->text('observations')->nullable();
                $table->unsignedBigInteger('remis_par')->nullable();
                $table->unsignedBigInteger('recu_par')->nullable();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  ROLLBACK — ordre inverse strict des FK
    // ══════════════════════════════════════════════════════════════════════════
    public function down(): void
    {
        // Supprimer d'abord la FK circulaire
        Schema::table('presences', function (Blueprint $table) {
            $table->dropForeign(['justification_id']);
        });

        $tables = [
            'mouvements_stock',
            'stock_materiel',
            'reservations_repas',
            'inscriptions_cantine',
            'menus_cantine',
            'periodes_conges',
            'groupe_td_inscription',
            'certificats_scolarite',
            'imports_exports',
            'notifications_school',
            'parametres_school',
            'soumissions_devoirs',
            'devoirs_maison',
            'ressources_pedagogiques',
            'conseil_participants',
            'conseils_classe',
            'sanctions',
            'evenements_agenda',
            'messages',
            'conversation_participants',
            'conversations',
            'annonce_lectures',
            'annonces',
            'bourses',
            'paiements',
            'echeances',
            'frais_scolaires',
            'baremes_frais',
            'types_frais',
            'justifications_absence',
            'presences',
            'bulletins',
            'moyennes_periodes',
            'moyennes_matieres',
            'notes',
            'evaluations',
            'inscriptions',
            'eleve_parent',
            'parents_tuteurs',
            'eleves',
            'exceptions_edt',
            'creneaux',
            'emplois_du_temps',
            'attributions_cours',
            'enseignant_matiere',
            'enseignants',
            'personnels',
            'programme_matiere',
            'programmes',
            'matieres',
            'classes',
            'salles',
            'batiments',
            'niveau_filiere',
            'filieres',
            'niveaux',
            'cycles',
            'periodes',
            'annees_scolaires',
        ];

        foreach ($tables as $table) {
            Schema::dropIfExists($table);
        }

        // Retirer la colonne groupe_td_id des creneaux
        if (Schema::hasTable('creneaux') && Schema::hasColumn('creneaux', 'groupe_td_id')) {
            Schema::table('creneaux', function (Blueprint $table) {
                $table->dropForeign(['groupe_td_id']);
                $table->dropColumn('groupe_td_id');
            });
        }

        Schema::dropIfExists('groupes_td');
    }
};
