<?php namespace Mt\School\Listeners;
use Mt\School\Events\BulletinPublie;
class NotifierBulletinDisponible {
    public function handle(BulletinPublie $event): void {
        // TODO: notifier élève et parent que le bulletin est disponible
    }
}
