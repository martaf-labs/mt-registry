<?php namespace Mt\School\Listeners;
use Mt\School\Events\AbsenceEnregistree;
class NotifierParentAbsence {
    public function handle(AbsenceEnregistree $event): void {
        if (!config('mtschool.presences.notifier_parents')) return;
        // TODO: envoyer notification aux parents
    }
}
