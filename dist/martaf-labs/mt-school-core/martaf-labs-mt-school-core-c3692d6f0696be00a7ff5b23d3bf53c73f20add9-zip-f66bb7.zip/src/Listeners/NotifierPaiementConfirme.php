<?php namespace Mt\School\Listeners;
use Mt\School\Events\PaiementRecu;
class NotifierPaiementConfirme {
    public function handle(PaiementRecu $event): void {
        // TODO: envoyer reçu par email/SMS si configuré
    }
}
