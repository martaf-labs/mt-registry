<?php namespace Mt\School\Listeners;
use Mt\School\Events\InscriptionValidee;
class RecalculerEffectifClasse {
    public function handle(InscriptionValidee $event): void {
        $event->inscription->classe->recalculerEffectif();
    }
}
