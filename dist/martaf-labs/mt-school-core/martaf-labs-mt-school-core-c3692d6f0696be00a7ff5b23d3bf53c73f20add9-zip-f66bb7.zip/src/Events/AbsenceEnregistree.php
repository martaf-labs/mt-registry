<?php namespace Mt\School\Events;
use Mt\School\Models\Presence;
class AbsenceEnregistree { public function __construct(public readonly Presence $presence) {} }
