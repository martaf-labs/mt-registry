<?php namespace Mt\School\Events;
use Mt\School\Models\Paiement;
class PaiementRecu { public function __construct(public readonly Paiement $paiement) {} }
