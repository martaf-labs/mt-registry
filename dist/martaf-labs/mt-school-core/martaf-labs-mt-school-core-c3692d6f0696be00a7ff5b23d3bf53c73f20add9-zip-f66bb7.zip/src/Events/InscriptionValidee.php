<?php namespace Mt\School\Events;
use Mt\School\Models\Inscription;

class InscriptionValidee
{
    public function __construct(public readonly Inscription $inscription) {}
}
