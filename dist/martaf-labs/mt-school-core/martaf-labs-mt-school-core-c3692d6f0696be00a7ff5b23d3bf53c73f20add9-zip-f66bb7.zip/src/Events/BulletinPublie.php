<?php namespace Mt\School\Events;
use Mt\School\Models\Bulletin;
class BulletinPublie { public function __construct(public readonly Bulletin $bulletin) {} }
