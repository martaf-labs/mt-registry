<?php namespace Mt\School\Events;
use Mt\School\Models\Evaluation;
class NotesSaisies { public function __construct(public readonly Evaluation $evaluation) {} }
