<?php

use Mt\School\Models\AnneeScolaire;
use Mt\School\Support\AnneeScolaireResolver;

// ──────────────────────────────────────────────────────────────────────────────
// CONFIG
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('mtschool_config')) {
    /**
     * Récupère une valeur de configuration du package.
     * Usage : mtschool_config('notation.note_max') → 20
     */
    function mtschool_config(string $key, mixed $defaut = null): mixed
    {
        return config("mtschool.{$key}", $defaut);
    }
}

if (!function_exists('school_info')) {
    /**
     * Informations de l'établissement.
     * Usage : school_info('nom') → "Lycée Bilingue de X"
     */
    function school_info(string $key, string $defaut = ''): string
    {
        return config("mtschool.etablissement.{$key}", $defaut);
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// ANNÉE SCOLAIRE
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('annee_active')) {
    /**
     * Retourne l'année scolaire active.
     * Usage : annee_active() → AnneeScolaire|null
     */
    function annee_active(): ?AnneeScolaire
    {
        return app(AnneeScolaireResolver::class)->courante();
    }
}

if (!function_exists('annee_active_id')) {
    /**
     * Retourne l'ID de l'année scolaire active.
     * Usage : annee_active_id() → int|null
     */
    function annee_active_id(): ?int
    {
        return app(AnneeScolaireResolver::class)->idCourant();
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// MODULES
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('module_actif')) {
    /**
     * Vérifie si un module du package est activé.
     * Usage : module_actif('finances') → bool
     */
    function module_actif(string $module): bool
    {
        return config("mtschool.{$module}.enabled", true);
    }
}

if (!function_exists('multilingual_actif')) {
    /**
     * Vérifie si le mode multilingue est activé.
     */
    function multilingual_actif(): bool
    {
        return config('mtschool.multilingual.enabled', false);
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// NOTATION
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('note_passage')) {
    /**
     * Note de passage configurée.
     * Usage : note_passage() → 10
     */
    function note_passage(): float
    {
        return (float) config('mtschool.notation.note_passage', 10);
    }
}

if (!function_exists('note_max')) {
    /**
     * Note maximale configurée.
     * Usage : note_max() → 20
     */
    function note_max(): float
    {
        return (float) config('mtschool.notation.note_max', 20);
    }
}

if (!function_exists('est_admis')) {
    /**
     * Vérifie si une moyenne est au-dessus de la note de passage.
     * Usage : est_admis(11.5) → true
     */
    function est_admis(float $moyenne): bool
    {
        return $moyenne >= note_passage();
    }
}

if (!function_exists('formater_note')) {
    /**
     * Formate une note selon les décimales configurées.
     * Usage : formater_note(14.666) → "14.67"
     */
    function formater_note(?float $note, ?int $decimales = null): string
    {
        if ($note === null) return '—';
        $dec = $decimales ?? (int) config('mtschool.notation.arrondi_decimales', 2);
        return number_format($note, $dec, '.', '');
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// DEVISE & MONTANTS
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('school_devise')) {
    /**
     * Devise de l'établissement.
     * Usage : school_devise() → "XAF"
     */
    function school_devise(): string
    {
        return config('mtschool.etablissement.devise', 'XAF');
    }
}

if (!function_exists('formater_montant')) {
    /**
     * Formate un montant avec la devise.
     * Usage : formater_montant(50000) → "50 000 XAF"
     */
    function formater_montant(float $montant, ?string $devise = null): string
    {
        $devise  = $devise ?? school_devise();
        $formate = number_format($montant, 0, ',', ' ');
        return "{$formate} {$devise}";
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// MULTILINGUISME
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('school_locale')) {
    /**
     * Locale active pour le package (fr, en, ar…).
     */
    function school_locale(): string
    {
        return session('mt_locale', config('mtschool.multilingual.default', app()->getLocale()));
    }
}

if (!function_exists('school_trans')) {
    /**
     * Traduit une clé du package.
     * Usage : school_trans('messages.inscription_validee')
     */
    function school_trans(string $key, array $replace = [], ?string $locale = null): string
    {
        return (string) trans("mtschool::{$key}", $replace, $locale ?? school_locale());
    }
}

if (!function_exists('school_label')) {
    /**
     * Retourne le libellé traduit d'un champ JSON multilingue.
     * Usage : school_label($annee->libelle) → "Année 2024-2025"
     *
     * @param array|string|null $libelle  Le champ JSON : ['fr'=>'...','en'=>'...']
     * @param string|null       $locale   Locale cible (null = locale active)
     */
    function school_label(array|string|null $libelle, ?string $locale = null): string
    {
        if (empty($libelle)) return '';
        if (is_string($libelle)) {
            $decoded = json_decode($libelle, true);
            if (!is_array($decoded)) return $libelle;
            $libelle = $decoded;
        }
        $locale  = $locale ?? school_locale();
        $defaut  = config('mtschool.multilingual.default', 'fr');
        return $libelle[$locale] ?? $libelle[$defaut] ?? reset($libelle) ?? '';
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// PARAMÈTRES DYNAMIQUES
// ──────────────────────────────────────────────────────────────────────────────

if (!function_exists('school_param')) {
    /**
     * Récupère un paramètre dynamique stocké en base (ParametreSchool).
     * Usage : school_param('note_passage', 10)
     */
    function school_param(string $cle, mixed $defaut = null): mixed
    {
        return \Mt\School\Models\ParametreSchool::get($cle, $defaut);
    }
}
