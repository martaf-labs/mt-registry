<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Mt\MtViews\Traits\TracksUser;
use Mt\School\Enums\Mention;

/**
 * Modèle MoyennePeriode
 * Moyenne générale d'un élève sur une période complète.
 * Contient le rang, la mention, la décision du conseil de classe.
 *
 * @property int          $id
 * @property int          $inscription_id
 * @property int          $periode_id
 * @property float|null   $moyenne_generale
 * @property int|null     $rang
 * @property int|null     $effectif_classe
 * @property Mention|null $mention
 * @property string|null  $decision_conseil
 * @property bool         $validee
 */
class MoyennePeriode extends Model
{
    use TracksUser;

    protected $table = 'moyennes_periodes';

    protected $fillable = [
        'inscription_id', 'periode_id',
        'moyenne_generale', 'total_points', 'total_coefficients',
        'rang', 'effectif_classe',
        'moyenne_classe', 'moyenne_max_classe', 'moyenne_min_classe',
        'mention', 'appreciation_globale',
        'decision_conseil', 'observation_conseil',
        'absences_justifiees', 'absences_injustifiees', 'retards',
        'validee', 'validee_par', 'validee_at',
    ];

    protected $casts = [
        'moyenne_generale'      => 'decimal:2',
        'total_points'          => 'decimal:2',
        'total_coefficients'    => 'decimal:2',
        'moyenne_classe'        => 'decimal:2',
        'moyenne_max_classe'    => 'decimal:2',
        'moyenne_min_classe'    => 'decimal:2',
        'appreciation_globale'  => 'array',
        'absences_justifiees'   => 'integer',
        'absences_injustifiees' => 'integer',
        'retards'               => 'integer',
        'validee'               => 'boolean',
        'validee_at'            => 'datetime',
        'mention'               => Mention::class,
    ];

    protected array $translatables = ['appreciation_globale'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeValidees($query)                  { return $query->where('validee', true); }
    public function scopeDePeriode($query, int $periodeId) { return $query->where('periode_id', $periodeId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function calculerMention(): self
    {
        if ($this->moyenne_generale !== null) {
            $this->mention = Mention::fromMoyenne((float) $this->moyenne_generale);
        }
        return $this;
    }

    public function estAdmis(): bool
    {
        return ($this->moyenne_generale ?? 0) >= config('mtschool.notation.note_passage', 10);
    }

    public function valider(int $userId): self
    {
        $this->update([
            'validee'     => true,
            'validee_par' => $userId,
            'validee_at'  => now(),
        ]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscription(): BelongsTo { return $this->belongsTo(Inscription::class); }
    public function periode(): BelongsTo     { return $this->belongsTo(Periode::class); }

    public function bulletin(): HasOne
    {
        return $this->hasOne(Bulletin::class, 'moyenne_periode_id');
    }
}
