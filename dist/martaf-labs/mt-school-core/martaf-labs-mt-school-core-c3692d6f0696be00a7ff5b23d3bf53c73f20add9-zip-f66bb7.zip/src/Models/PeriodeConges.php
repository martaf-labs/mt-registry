<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle PeriodeConges
 * Calendrier des vacances et jours fériés d'une année scolaire.
 * Utilisé par l'EDT, les présences et le bulletin.
 *
 * @property int         $id
 * @property int         $annee_scolaire_id
 * @property array       $libelle
 * @property string      $type     'vacances'|'ferie'|'examen'|'evenement'|'autre'
 * @property \Carbon\Carbon $date_debut
 * @property \Carbon\Carbon $date_fin
 * @property string      $portee   'etablissement'|'national'|'regional'
 * @property bool        $cours_suspendus
 * @property bool        $absences_neutralisees
 * @property bool        $actif
 */
class PeriodeConges extends MtBaseModel
{
    protected $table = 'periodes_conges';

    protected $fillable = [
        'annee_scolaire_id', 'libelle', 'type',
        'date_debut', 'date_fin', 'portee',
        'cours_suspendus', 'absences_neutralisees',
        'couleur', 'actif', 'description',
    ];

    protected $casts = [
        'date_debut'             => 'date',
        'date_fin'               => 'date',
        'cours_suspendus'        => 'boolean',
        'absences_neutralisees'  => 'boolean',
        'actif'                  => 'boolean',
    ];

    protected array $translatables = ['libelle'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActives($query)             { return $query->where('actif', true); }
    public function scopeVacances($query)            { return $query->where('type', 'vacances'); }
    public function scopeFeries($query)              { return $query->where('type', 'ferie'); }
    public function scopeDeAnnee($query, int $id)   { return $query->where('annee_scolaire_id', $id); }

    public function scopeEnCours($query)
    {
        return $query->where('date_debut', '<=', now())
                     ->where('date_fin', '>=', now());
    }

    public function scopeCouvrant($query, \Carbon\Carbon $date)
    {
        return $query->where('date_debut', '<=', $date)
                     ->where('date_fin', '>=', $date);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function dureeJours(): int
    {
        return (int) $this->date_debut->diffInDays($this->date_fin) + 1;
    }

    public function couvre(\Carbon\Carbon $date): bool
    {
        return $date->between($this->date_debut, $this->date_fin);
    }

    public function estEnCours(): bool
    {
        return $this->couvre(now());
    }

    /** Vérifie si une date donnée est un jour de congé. */
    public static function estConge(\Carbon\Carbon $date, int $anneeId): bool
    {
        return static::deAnnee($anneeId)
            ->actives()
            ->couvrant($date)
            ->exists();
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo
    {
        return $this->belongsTo(AnneeScolaire::class);
    }
}
