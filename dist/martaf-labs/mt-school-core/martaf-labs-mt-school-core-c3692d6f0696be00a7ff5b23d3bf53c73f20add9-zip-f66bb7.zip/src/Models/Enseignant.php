<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Mt\MtViews\Traits\LogActivityAction;
use Mt\MtViews\Traits\TracksUser;

/**
 * Modèle Enseignant
 * Extension pédagogique d'un Personnel — relation 1-1 via personnel_id.
 *
 * @property int         $id
 * @property int         $personnel_id
 * @property int|null    $matiere_principale_id
 * @property string|null $diplome
 * @property string|null $specialite
 * @property float|null  $volume_horaire_contrat
 */
class Enseignant extends Model
{
    use TracksUser, LogActivityAction;

    protected $table = 'enseignants';

    protected $fillable = [
        'personnel_id', 'matiere_principale_id',
        'diplome', 'specialite', 'volume_horaire_contrat',
    ];

    protected $casts = [
        'volume_horaire_contrat' => 'decimal:2',
    ];

    protected static array $searchableColumns = [];

    // ── Accesseurs délégués au Personnel ─────────────────────────────────────

    public function getNomCompletAttribute(): string  { return $this->personnel?->nomComplet ?? ''; }
    public function getNomAttribute(): string         { return $this->personnel?->nom ?? ''; }
    public function getPrenomAttribute(): string      { return $this->personnel?->prenom ?? ''; }
    public function getEmailAttribute(): ?string      { return $this->personnel?->email; }
    public function getTelephoneAttribute(): ?string  { return $this->personnel?->telephone; }
    public function getActifAttribute(): bool         { return $this->personnel?->actif ?? false; }
    public function getReferenceAttribute(): ?string  { return $this->personnel?->reference; }

    public function fullName(): string { return $this->nomComplet; }

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs(Builder $query): Builder
    {
        return $query->whereHas('personnel', fn($q) => $q->where('actif', true));
    }

    public function scopeDeMatiere(Builder $query, int $matiereId): Builder
    {
        return $query->whereHas('matieres', fn($q) => $q->where('matieres.id', $matiereId));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Charge les classes enseignées cette année. */
    public function classesDe(int $anneeId)
    {
        return $this->attributionsCours()
            ->where('annee_scolaire_id', $anneeId)
            ->where('actif', true)
            ->with('classe')
            ->get()
            ->pluck('classe')
            ->unique('id')
            ->values();
    }

    /** Volume d'heures affecté cette année. */
    public function volumeAffecteDe(int $anneeId): float
    {
        return (float) $this->attributionsCours()
            ->where('annee_scolaire_id', $anneeId)
            ->sum('volume_horaire_semaine');
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function personnel(): BelongsTo
    {
        return $this->belongsTo(Personnel::class);
    }

    public function matierePrincipale(): BelongsTo
    {
        return $this->belongsTo(Matiere::class, 'matiere_principale_id');
    }

    public function matieres(): BelongsToMany
    {
        return $this->belongsToMany(Matiere::class, 'enseignant_matiere');
    }

    public function attributionsCours(): HasMany
    {
        return $this->hasMany(AttributionCours::class);
    }

    public function evaluations(): HasMany
    {
        return $this->hasMany(Evaluation::class);
    }

    public function creneaux(): HasMany
    {
        return $this->hasMany(Creneau::class);
    }
}
