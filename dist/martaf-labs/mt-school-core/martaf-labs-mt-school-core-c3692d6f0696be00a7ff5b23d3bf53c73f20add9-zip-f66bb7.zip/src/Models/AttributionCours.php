<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle AttributionCours — Feuille de service d'un enseignant.
 * Qui enseigne quelle matière, dans quelle classe, cette année.
 *
 * @property int      $id
 * @property int      $annee_scolaire_id
 * @property int      $enseignant_id
 * @property int      $classe_id
 * @property int      $matiere_id
 * @property float|null $volume_horaire_semaine
 * @property float|null $coefficient
 * @property bool     $actif
 */
class AttributionCours extends MtBaseModel
{
    protected $table = 'attributions_cours';

    protected $fillable = [
        'annee_scolaire_id', 'enseignant_id', 'classe_id', 'matiere_id',
        'volume_horaire_semaine', 'coefficient', 'actif',
        'date_debut', 'date_fin', 'observations',
    ];

    protected $casts = [
        'actif'                  => 'boolean',
        'date_debut'             => 'date',
        'date_fin'               => 'date',
        'coefficient'            => 'decimal:2',
        'volume_horaire_semaine' => 'decimal:2',
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActives($query)                   { return $query->where('actif', true); }
    public function scopeDeAnnee($query, int $anneeId)     { return $query->where('annee_scolaire_id', $anneeId); }
    public function scopeDeClasse($query, int $classeId)   { return $query->where('classe_id', $classeId); }
    public function scopeDeEnseignant($query, int $ensId)  { return $query->where('enseignant_id', $ensId); }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function enseignant(): BelongsTo    { return $this->belongsTo(Enseignant::class); }
    public function classe(): BelongsTo        { return $this->belongsTo(Classe::class); }
    public function matiere(): BelongsTo       { return $this->belongsTo(Matiere::class); }

    public function creneaux(): HasMany
    {
        return $this->hasMany(Creneau::class);
    }
}
