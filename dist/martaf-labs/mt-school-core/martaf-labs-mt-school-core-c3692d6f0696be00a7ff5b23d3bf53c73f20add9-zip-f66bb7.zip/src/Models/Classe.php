<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Classe
 *
 * @property int         $id
 * @property int         $annee_scolaire_id
 * @property int         $niveau_id
 * @property int|null    $filiere_id
 * @property int|null    $salle_id
 * @property int|null    $professeur_principal_id
 * @property array       $libelle
 * @property string      $code
 * @property string|null $abreviation
 * @property int         $effectif_max
 * @property int         $effectif_actuel
 * @property string|null $langue_enseignement
 * @property bool        $actif
 */
class Classe extends MtBaseModel
{
    protected $table = 'classes';

    protected $fillable = [
        'annee_scolaire_id', 'niveau_id', 'filiere_id', 'salle_id',
        'professeur_principal_id', 'libelle', 'code', 'abreviation',
        'effectif_max', 'effectif_actuel', 'langue_enseignement',
        'actif', 'observations', 'meta_data',
    ];

    protected $casts = [
        'actif'           => 'boolean',
        'effectif_max'    => 'integer',
        'effectif_actuel' => 'integer',
        'meta_data'       => 'array',
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code', 'abreviation'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActives($query)                   { return $query->where('actif', true); }
    public function scopeDeAnnee($query, int $anneeId)     { return $query->where('annee_scolaire_id', $anneeId); }
    public function scopeDeNiveau($query, int $niveauId)   { return $query->where('niveau_id', $niveauId); }
    public function scopeDeFiliere($query, int $filiereId) { return $query->where('filiere_id', $filiereId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estPleine(): bool
    {
        return $this->effectif_actuel >= $this->effectif_max;
    }

    public function placesRestantes(): int
    {
        return max(0, $this->effectif_max - $this->effectif_actuel);
    }

    public function tauxRemplissage(): float
    {
        if ($this->effectif_max === 0) return 0;
        return round(($this->effectif_actuel / $this->effectif_max) * 100, 1);
    }

    /** Recalcule et persiste l'effectif actuel depuis les inscriptions validées. */
    public function recalculerEffectif(): self
    {
        $this->effectif_actuel = $this->inscriptions()
            ->where('statut', 'validee')
            ->count();
        $this->saveQuietly();
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo
    {
        return $this->belongsTo(AnneeScolaire::class);
    }

    public function niveau(): BelongsTo
    {
        return $this->belongsTo(Niveau::class);
    }

    public function filiere(): BelongsTo
    {
        return $this->belongsTo(Filiere::class);
    }

    public function salle(): BelongsTo
    {
        return $this->belongsTo(Salle::class);
    }

    public function inscriptions(): HasMany
    {
        return $this->hasMany(Inscription::class);
    }

    public function inscriptionsValidees(): HasMany
    {
        return $this->hasMany(Inscription::class)->where('statut', 'validee');
    }

    public function evaluations(): HasMany
    {
        return $this->hasMany(Evaluation::class);
    }

    public function attributionsCours(): HasMany
    {
        return $this->hasMany(AttributionCours::class);
    }

    public function emploisDuTemps(): HasMany
    {
        return $this->hasMany(EmploiDuTemps::class);
    }

    public function groupesTd(): HasMany
    {
        return $this->hasMany(GroupeTd::class);
    }

    public function conseilsClasse(): HasMany
    {
        return $this->hasMany(ConseilClasse::class);
    }

    public function devoirs(): HasMany
    {
        return $this->hasMany(DevoirMaison::class);
    }

    public function ressourcesPedagogiques(): HasMany
    {
        return $this->hasMany(RessourcePedagogique::class);
    }
}
