<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\StatutFrais;

/**
 * Modèle FraisScolaire
 * Frais individualisés par inscription.
 *
 * @property int         $id
 * @property string      $reference
 * @property int         $inscription_id
 * @property int         $type_frais_id
 * @property float       $montant_brut
 * @property float       $remise
 * @property float       $montant_net
 * @property float       $montant_paye
 * @property float       $montant_restant
 * @property StatutFrais $statut
 * @property bool        $est_exonere
 */
class FraisScolaire extends MtBaseModel
{
    protected $table = 'frais_scolaires';

    protected $fillable = [
        'reference', 'inscription_id', 'type_frais_id',
        'montant_brut', 'remise', 'montant_net', 'montant_paye', 'montant_restant',
        'devise', 'statut', 'est_exonere', 'motif_exoneration', 'observations', 'meta_data',
    ];

    protected $casts = [
        'montant_brut'    => 'decimal:2',
        'remise'          => 'decimal:2',
        'montant_net'     => 'decimal:2',
        'montant_paye'    => 'decimal:2',
        'montant_restant' => 'decimal:2',
        'est_exonere'     => 'boolean',
        'meta_data'       => 'array',
        'statut'          => StatutFrais::class,
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeSoldes($query) { return $query->where('statut', StatutFrais::SOLDE->value); }
    public function scopeActifs($query) { return $query->whereIn('statut', [StatutFrais::EN_ATTENTE->value, StatutFrais::PARTIEL->value]); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estSolde(): bool   { return $this->statut === StatutFrais::SOLDE; }
    public function estExonere(): bool { return $this->est_exonere; }

    public function estEnRetard(): bool
    {
        return $this->echeances()->where('statut', 'en_retard')->exists();
    }

    public function pourcentagePaye(): float
    {
        if (!$this->montant_net) return 0;
        return round(($this->montant_paye / $this->montant_net) * 100, 1);
    }

    /** Recalcule montant_paye et montant_restant depuis les paiements confirmés. */
    public function recalculer(): self
    {
        $paye = $this->paiements()->where('statut', 'confirme')->sum('montant');
        $this->update([
            'montant_paye'    => $paye,
            'montant_restant' => max(0, (float) $this->montant_net - (float) $paye),
            'statut'          => $paye >= $this->montant_net
                ? StatutFrais::SOLDE
                : ($paye > 0 ? StatutFrais::PARTIEL : StatutFrais::EN_ATTENTE),
        ]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscription(): BelongsTo { return $this->belongsTo(Inscription::class); }
    public function typeFrais(): BelongsTo   { return $this->belongsTo(TypeFrais::class); }

    public function echeances(): HasMany
    {
        return $this->hasMany(Echeance::class)->orderBy('ordre');
    }

    public function paiements(): HasMany
    {
        return $this->hasMany(Paiement::class);
    }
}
