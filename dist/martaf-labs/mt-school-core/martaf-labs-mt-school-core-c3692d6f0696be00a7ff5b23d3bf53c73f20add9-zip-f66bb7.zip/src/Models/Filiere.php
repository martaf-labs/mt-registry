<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Filiere
 *
 * @property int         $id
 * @property array       $libelle
 * @property string      $code        'SCI'|'LITT'|'TECH'|'INFO'|'GESTION'
 * @property string|null $abreviation
 * @property string      $couleur
 * @property bool        $actif
 */
class Filiere extends MtBaseModel
{
    protected $table = 'filieres';

    protected $fillable = [
        'libelle', 'code', 'abreviation', 'couleur', 'actif', 'description',
    ];

    protected $casts = [
        'actif' => 'boolean',
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code', 'abreviation'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActives($query) { return $query->where('actif', true); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function labelCourt(): string
    {
        return $this->abreviation ?? $this->code;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function niveaux(): BelongsToMany
    {
        return $this->belongsToMany(Niveau::class, 'niveau_filiere');
    }

    public function classes(): HasMany
    {
        return $this->hasMany(Classe::class);
    }

    public function programmes(): HasMany
    {
        return $this->hasMany(Programme::class);
    }

    public function baremesFrais(): HasMany
    {
        return $this->hasMany(BaremeFrais::class);
    }
}
