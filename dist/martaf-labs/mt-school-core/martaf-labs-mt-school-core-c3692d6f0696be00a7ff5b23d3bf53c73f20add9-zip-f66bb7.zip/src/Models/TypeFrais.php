<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

class TypeFrais extends MtBaseModel
{
    protected $table = 'types_frais';
    protected $fillable = ['libelle', 'code', 'caracteristique', 'actif', 'ordre', 'description'];
    protected $casts = ['actif' => 'boolean'];
    protected array $translatables = ['libelle'];
    protected static array $searchableColumns = ['code'];

    public function scopeActifs($query)       { return $query->where('actif', true); }
    public function scopeObligatoires($query) { return $query->where('caracteristique', 'obligatoire'); }

    public function baremes(): HasMany        { return $this->hasMany(BaremeFrais::class); }
    public function fraisScolaires(): HasMany { return $this->hasMany(FraisScolaire::class); }
}
