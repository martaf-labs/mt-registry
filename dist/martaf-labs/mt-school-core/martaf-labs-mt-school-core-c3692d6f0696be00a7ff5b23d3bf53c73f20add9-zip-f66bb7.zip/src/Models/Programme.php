<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Programme
 * Ensemble de matières (avec coefficients) pour un niveau/filière/année.
 *
 * @property int      $id
 * @property int      $annee_scolaire_id
 * @property int      $niveau_id
 * @property int|null $filiere_id
 * @property array    $libelle
 * @property string   $code
 * @property bool     $actif
 */
class Programme extends MtBaseModel
{
    protected $table = 'programmes';

    protected $fillable = [
        'annee_scolaire_id', 'niveau_id', 'filiere_id',
        'libelle', 'code', 'actif', 'description', 'meta_data',
    ];

    protected $casts = [
        'actif'     => 'boolean',
        'meta_data' => 'array',
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs($query)                { return $query->where('actif', true); }
    public function scopeDeAnnee($query, int $anneeId) { return $query->where('annee_scolaire_id', $anneeId); }

    public function scopeDeNiveauFiliere($query, int $niveauId, ?int $filiereId = null)
    {
        return $query->where('niveau_id', $niveauId)
            ->where('filiere_id', $filiereId);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function totalCoefficients(): float
    {
        return $this->matieres->sum(fn($m) => $m->pivot->coefficient ?? 0);
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function niveau(): BelongsTo        { return $this->belongsTo(Niveau::class); }
    public function filiere(): BelongsTo       { return $this->belongsTo(Filiere::class); }

    public function matieres(): BelongsToMany
    {
        return $this->belongsToMany(Matiere::class, 'programme_matiere')
            ->withPivot(['coefficient', 'volume_horaire_semaine', 'ordre', 'est_eliminatoire', 'note_eliminatoire', 'sur_bulletin'])
            ->withTimestamps()
            ->orderByPivot('ordre');
    }

    public function matieresAuBulletin(): BelongsToMany
    {
        return $this->matieres()->wherePivot('sur_bulletin', true);
    }

    public function matieresEliminatoires(): BelongsToMany
    {
        return $this->matieres()->wherePivot('est_eliminatoire', true);
    }
}
