<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Annonce
 * Message diffusé vers un groupe (tous, une classe, les parents…).
 *
 * @property int    $id
 * @property array  $titre
 * @property array  $contenu
 * @property string $audience_type  'tous'|'eleves'|'parents'|'enseignants'|'classe'|'niveau'
 * @property string $statut         'brouillon'|'publiee'|'archivee'
 * @property string $importance     'normale'|'importante'|'urgente'
 */
class Annonce extends MtBaseModel
{
    protected $table = 'annonces';

    protected $fillable = [
        'titre', 'contenu', 'auteur_id', 'audience_type', 'audience_ids',
        'annee_scolaire_id', 'statut', 'importance',
        'publiee_at', 'expire_at', 'notification_email', 'notification_sms',
        'vues_count', 'pieces_jointes', 'meta_data',
    ];

    protected $casts = [
        'audience_ids'       => 'array',
        'publiee_at'         => 'datetime',
        'expire_at'          => 'datetime',
        'notification_email' => 'boolean',
        'notification_sms'   => 'boolean',
        'pieces_jointes'     => 'array',
        'meta_data'          => 'array',
    ];

    protected array $translatables = ['titre', 'contenu'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePubliees($query)    { return $query->where('statut', 'publiee'); }
    public function scopeUrgentes($query)    { return $query->where('importance', 'urgente'); }
    public function scopeNonExpirees($query) { return $query->where(fn($q) => $q->whereNull('expire_at')->orWhere('expire_at', '>', now())); }

    public function scopePourAudience($query, string $type, ?array $ids = null)
    {
        return $query->where(fn($q) =>
            $q->where('audience_type', 'tous')
              ->orWhere('audience_type', $type)
        );
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estPubliee(): bool { return $this->statut === 'publiee'; }
    public function estExpiree(): bool { return $this->expire_at && $this->expire_at->isPast(); }
    public function estUrgente(): bool { return $this->importance === 'urgente'; }

    public function incrementerVues(): void
    {
        $this->increment('vues_count');
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function lectures(): HasMany        { return $this->hasMany(AnnonceLecture::class); }
}


/**
 * Modèle AnnonceLecture
 * Traçabilité de la lecture d'une annonce par un utilisateur.
 */
class AnnonceLecture extends Model
{
    protected $table = 'annonce_lectures';

    public $timestamps = false;

    protected $fillable = ['annonce_id', 'user_id', 'lu_at'];

    protected $casts = ['lu_at' => 'datetime'];

    public function annonce(): BelongsTo { return $this->belongsTo(Annonce::class); }
}


/**
 * Modèle Conversation
 * Thread de messagerie interne entre utilisateurs.
 *
 * @property int    $id
 * @property string $type  'prive'|'groupe'
 */
class Conversation extends MtBaseModel
{
    protected $table = 'conversations';

    protected $fillable = [
        'sujet', 'type', 'annee_scolaire_id',
        'dernier_message_at', 'messages_count',
    ];

    protected $casts = [
        'sujet'              => 'array',
        'dernier_message_at' => 'datetime',
        'messages_count'     => 'integer',
    ];

    protected array $translatables = ['sujet'];

    public function scopePrivees($query) { return $query->where('type', 'prive'); }
    public function scopeGroupes($query) { return $query->where('type', 'groupe'); }

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }

    public function participants(): HasMany
    {
        return $this->hasMany(ConversationParticipant::class);
    }

    public function messages(): HasMany
    {
        return $this->hasMany(Message::class)->orderBy('created_at');
    }

    public function dernierMessage(): HasMany
    {
        return $this->hasMany(Message::class)->latest()->limit(1);
    }
}


/**
 * Modèle ConversationParticipant
 */
class ConversationParticipant extends Model
{
    protected $table = 'conversation_participants';

    protected $fillable = [
        'conversation_id', 'user_id', 'dernier_vu_at', 'est_admin', 'est_mute',
    ];

    protected $casts = [
        'dernier_vu_at' => 'datetime',
        'est_admin'     => 'boolean',
        'est_mute'      => 'boolean',
    ];

    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
}


/**
 * Modèle Message
 * Message d'une conversation interne.
 *
 * @property int    $id
 * @property int    $conversation_id
 * @property int    $expediteur_id
 * @property string $contenu
 * @property string $type_contenu  'texte'|'image'|'fichier'
 * @property string $statut        'envoye'|'lu'|'supprime'
 */
class Message extends MtBaseModel
{
    protected $table = 'messages';

    protected $fillable = [
        'conversation_id', 'expediteur_id', 'parent_id',
        'contenu', 'type_contenu', 'pieces_jointes', 'statut',
    ];

    protected $casts = [
        'pieces_jointes' => 'array',
    ];

    public function scopeVisibles($query) { return $query->where('statut', '!=', 'supprime'); }

    public function estLu(): bool      { return $this->statut === 'lu'; }
    public function estEnvoye(): bool  { return $this->statut === 'envoye'; }

    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
    public function reponseA(): BelongsTo     { return $this->belongsTo(Message::class, 'parent_id'); }
    public function reponses(): HasMany       { return $this->hasMany(Message::class, 'parent_id'); }
}


/**
 * Modèle EvenementAgenda
 * Calendrier partagé de l'établissement.
 *
 * @property int    $id
 * @property array  $titre
 * @property string $type      'conseil_classe'|'examen'|'vacances'|'reunion'|'sortie'|'ferie'|'autre'
 * @property \Carbon\Carbon $debut_at
 */
class EvenementAgenda extends MtBaseModel
{
    protected $table = 'evenements_agenda';

    protected $fillable = [
        'titre', 'description', 'type', 'annee_scolaire_id',
        'audience_type', 'audience_ids',
        'debut_at', 'fin_at', 'journee_entiere', 'recurrent', 'recurrence_config',
        'lieu', 'salle_id', 'couleur', 'icone', 'publie', 'notification_envoye', 'meta_data',
    ];

    protected $casts = [
        'debut_at'           => 'datetime',
        'fin_at'             => 'datetime',
        'journee_entiere'    => 'boolean',
        'recurrent'          => 'boolean',
        'recurrence_config'  => 'array',
        'audience_ids'       => 'array',
        'publie'             => 'boolean',
        'notification_envoye'=> 'boolean',
        'meta_data'          => 'array',
    ];

    protected array $translatables = ['titre', 'description'];

    public function scopePublies($query)  { return $query->where('publie', true); }
    public function scopeAVenir($query)   { return $query->where('debut_at', '>=', now()); }
    public function scopeDeType($query, string $type) { return $query->where('type', $type); }

    public function estPasse(): bool { return $this->debut_at->isPast(); }

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function salle(): BelongsTo         { return $this->belongsTo(Salle::class); }
}
