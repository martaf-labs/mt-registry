<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Batiment
 *
 * @property int    $id
 * @property array  $libelle
 * @property string $code
 * @property bool   $actif
 */
class Batiment extends MtBaseModel
{
    protected $table = 'batiments';

    protected $fillable = ['libelle', 'code', 'description', 'actif'];

    protected $casts = ['actif' => 'boolean'];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code'];

    public function scopeActifs($query) { return $query->where('actif', true); }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function salles(): HasMany
    {
        return $this->hasMany(Salle::class);
    }

    public function sallesActives(): HasMany
    {
        return $this->hasMany(Salle::class)->where('actif', true);
    }
}
