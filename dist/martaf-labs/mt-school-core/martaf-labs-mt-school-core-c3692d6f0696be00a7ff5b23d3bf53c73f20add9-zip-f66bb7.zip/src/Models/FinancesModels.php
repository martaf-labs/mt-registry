<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\ModePaiement;

/**
 * Modèle Echeance
 * Versement prévu d'un frais scolaire.
 *
 * @property int    $id
 * @property int    $frais_scolaire_id
 * @property int    $ordre
 * @property float  $montant
 * @property \Carbon\Carbon $date_echeance
 * @property string $statut  'en_attente'|'en_retard'|'partiel'|'solde'
 */
class Echeance extends Model
{
    protected $table = 'echeances';

    protected $fillable = [
        'frais_scolaire_id', 'libelle', 'ordre',
        'montant', 'date_echeance', 'statut',
        'montant_paye', 'montant_restant',
    ];

    protected $casts = [
        'libelle'         => 'array',
        'montant'         => 'decimal:2',
        'montant_paye'    => 'decimal:2',
        'montant_restant' => 'decimal:2',
        'date_echeance'   => 'date',
    ];

    protected array $translatables = ['libelle'];

    public function scopeSoldees($query)  { return $query->where('statut', 'solde'); }
    public function scopeEnRetard($query) { return $query->where('statut', 'en_attente')->where('date_echeance', '<', now()); }

    public function estSoldee(): bool  { return $this->statut === 'solde'; }
    public function estEnRetard(): bool{ return $this->statut !== 'solde' && $this->date_echeance->isPast(); }

    public function fraisScolaire(): BelongsTo { return $this->belongsTo(FraisScolaire::class); }
    public function paiements(): HasMany       { return $this->hasMany(Paiement::class); }
}


/**
 * Modèle Paiement
 * Versement effectif réalisé par la famille.
 *
 * @property int          $id
 * @property string       $reference
 * @property int          $frais_scolaire_id
 * @property float        $montant
 * @property \Carbon\Carbon $date_paiement
 * @property ModePaiement $mode_paiement
 * @property string       $statut  'en_attente'|'confirme'|'rejete'|'rembourse'
 */
class Paiement extends MtBaseModel
{
    protected $table = 'paiements';

    protected $fillable = [
        'reference', 'frais_scolaire_id', 'echeance_id',
        'montant', 'devise', 'date_paiement', 'mode_paiement',
        'numero_transaction', 'statut', 'fichier_recu', 'recu_envoye',
        'encaisse_par', 'notes', 'meta_data',
    ];

    protected $casts = [
        'montant'       => 'decimal:2',
        'date_paiement' => 'date',
        'recu_envoye'   => 'boolean',
        'meta_data'     => 'array',
        'mode_paiement' => ModePaiement::class,
    ];

    public function scopeConfirmes($query) { return $query->where('statut', 'confirme'); }
    public function scopeEnAttente($query) { return $query->where('statut', 'en_attente'); }
    public function estConfirme(): bool    { return $this->statut === 'confirme'; }

    public function fraisScolaire(): BelongsTo { return $this->belongsTo(FraisScolaire::class); }
    public function echeance(): BelongsTo      { return $this->belongsTo(Echeance::class); }
}


/**
 * Modèle Bourse
 * Aide financière attribuée à un élève pour une année.
 *
 * @property int    $id
 * @property string $reference
 * @property int    $inscription_id
 * @property array  $libelle
 * @property string $type    'excellence'|'sociale'|'etat'|'autre'
 * @property float  $montant
 * @property string $statut  'en_attente'|'active'|'suspendue'|'retiree'
 */
class Bourse extends MtBaseModel
{
    protected $table = 'bourses';

    protected $fillable = [
        'reference', 'inscription_id', 'libelle', 'type',
        'montant', 'devise', 'couverture', 'taux_couverture',
        'date_attribution', 'date_fin', 'statut',
        'organisme', 'conditions', 'observations',
    ];

    protected $casts = [
        'libelle'          => 'array',
        'montant'          => 'decimal:2',
        'taux_couverture'  => 'decimal:2',
        'date_attribution' => 'date',
        'date_fin'         => 'date',
    ];

    protected array $translatables = ['libelle'];

    public function scopeActives($query)    { return $query->where('statut', 'active'); }
    public function scopeExcellence($query) { return $query->where('type', 'excellence'); }

    public function estActive(): bool   { return $this->statut === 'active'; }
    public function estExpires(): bool  { return $this->date_fin && $this->date_fin->isPast(); }

    public function inscription(): BelongsTo { return $this->belongsTo(Inscription::class); }
}
