<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\TypePeriode;

/**
 * Modèle Periode
 *
 * @property int         $id
 * @property int         $annee_scolaire_id
 * @property int|null    $parent_id
 * @property array       $libelle
 * @property string      $code
 * @property TypePeriode $type
 * @property int         $ordre
 * @property bool        $est_active
 * @property bool        $est_cloturee
 * @property float       $poids
 */
class Periode extends MtBaseModel
{
    protected $table = 'periodes';

    protected $fillable = [
        'annee_scolaire_id', 'parent_id', 'libelle', 'code', 'type',
        'ordre', 'date_debut', 'date_fin', 'est_active', 'est_cloturee', 'poids',
    ];

    protected $casts = [
        'date_debut'   => 'date',
        'date_fin'     => 'date',
        'est_active'   => 'boolean',
        'est_cloturee' => 'boolean',
        'poids'        => 'decimal:2',
        'type'         => TypePeriode::class,
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)     { return $query->where('est_active', true); }
    public function scopeOuverte($query)    { return $query->where('est_cloturee', false); }
    public function scopeRacines($query)    { return $query->whereNull('parent_id'); }
    public function scopeTrimestres($query) { return $query->where('type', TypePeriode::TRIMESTRE->value); }
    public function scopeSemestres($query)  { return $query->where('type', TypePeriode::SEMESTRE->value); }
    public function scopeSequences($query)  { return $query->where('type', TypePeriode::SEQUENCE->value); }

    public function scopeDeAnnee($query, int $anneeId)
    {
        return $query->where('annee_scolaire_id', $anneeId);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public static function courante(): ?self
    {
        return static::where('est_active', true)->orderBy('ordre')->first();
    }

    public function estTrimestre(): bool { return $this->type === TypePeriode::TRIMESTRE; }
    public function estSequence(): bool  { return $this->type === TypePeriode::SEQUENCE; }
    public function estSemestre(): bool  { return $this->type === TypePeriode::SEMESTRE; }
    public function estRacine(): bool    { return is_null($this->parent_id); }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo
    {
        return $this->belongsTo(AnneeScolaire::class);
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Periode::class, 'parent_id');
    }

    public function enfants(): HasMany
    {
        return $this->hasMany(Periode::class, 'parent_id')->orderBy('ordre');
    }

    public function evaluations(): HasMany        { return $this->hasMany(Evaluation::class); }
    public function moyennesMatieres(): HasMany   { return $this->hasMany(MoyenneMatiere::class); }
    public function moyennesPeriodes(): HasMany   { return $this->hasMany(MoyennePeriode::class); }
    public function bulletins(): HasMany          { return $this->hasMany(Bulletin::class); }
    public function conseilsClasse(): HasMany     { return $this->hasMany(ConseilClasse::class); }
    public function devoirs(): HasMany            { return $this->hasMany(DevoirMaison::class); }
}
