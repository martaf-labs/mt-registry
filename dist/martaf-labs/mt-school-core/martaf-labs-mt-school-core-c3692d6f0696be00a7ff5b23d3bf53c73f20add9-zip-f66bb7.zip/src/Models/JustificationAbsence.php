<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Traits\TracksUser;

/**
 * Modèle JustificationAbsence
 * Document/raison fourni par le parent pour justifier une ou plusieurs absences.
 *
 * @property int    $id
 * @property int    $inscription_id
 * @property \Carbon\Carbon $date_debut
 * @property \Carbon\Carbon $date_fin
 * @property string $motif   'maladie'|'deuil'|'evenement_famille'|'voyage'|'autre'
 * @property string $statut  'en_attente'|'acceptee'|'rejetee'
 */
class JustificationAbsence extends Model
{
    use TracksUser;

    protected $table = 'justifications_absence';

    protected $fillable = [
        'inscription_id', 'date_debut', 'date_fin',
        'motif', 'motif_detail', 'document', 'statut',
        'traitee_par', 'traitee_at', 'motif_rejet',
        'soumis_par_type', 'soumis_par_id',
    ];

    protected $casts = [
        'date_debut' => 'date',
        'date_fin'   => 'date',
        'traitee_at' => 'datetime',
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeEnAttente($query)  { return $query->where('statut', 'en_attente'); }
    public function scopeAcceptees($query)  { return $query->where('statut', 'acceptee'); }
    public function scopeRejetees($query)   { return $query->where('statut', 'rejetee'); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estAcceptee(): bool    { return $this->statut === 'acceptee'; }
    public function estEnAttente(): bool   { return $this->statut === 'en_attente'; }

    public function nombreJours(): int
    {
        return $this->date_debut->diffInDays($this->date_fin) + 1;
    }

    public function accepter(int $userId): self
    {
        $this->update([
            'statut'      => 'acceptee',
            'traitee_par' => $userId,
            'traitee_at'  => now(),
        ]);
        // Marquer les présences comme justifiées
        $this->presences()->update(['est_justifiee' => true]);
        return $this;
    }

    public function rejeter(int $userId, string $motif): self
    {
        $this->update([
            'statut'       => 'rejetee',
            'traitee_par'  => $userId,
            'traitee_at'   => now(),
            'motif_rejet'  => $motif,
        ]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscription(): BelongsTo { return $this->belongsTo(Inscription::class); }

    public function presences(): HasMany
    {
        return $this->hasMany(Presence::class, 'justification_id');
    }
}
