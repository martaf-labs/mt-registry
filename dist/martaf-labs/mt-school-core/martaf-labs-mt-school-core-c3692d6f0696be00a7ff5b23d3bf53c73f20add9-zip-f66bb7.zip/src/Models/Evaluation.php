<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\StatutEvaluation;
use Mt\School\Enums\TypeEvaluation;

/**
 * Modèle Evaluation
 * Un devoir, examen, contrôle, TP noté…
 *
 * @property int               $id
 * @property int               $annee_scolaire_id
 * @property int               $periode_id
 * @property int               $classe_id
 * @property int               $matiere_id
 * @property int|null          $enseignant_id
 * @property array             $libelle
 * @property TypeEvaluation    $type
 * @property float             $note_sur
 * @property float             $coefficient
 * @property float             $ponderation    % du poids dans la période
 * @property StatutEvaluation  $statut
 * @property bool              $publiee
 */
class Evaluation extends MtBaseModel
{
    protected $table = 'evaluations';

    protected $fillable = [
        'annee_scolaire_id', 'periode_id', 'classe_id', 'matiere_id', 'enseignant_id',
        'libelle', 'code', 'type', 'note_sur', 'coefficient', 'ponderation',
        'date_evaluation', 'date_saisie_limite', 'statut', 'publiee',
        'consignes', 'meta_data',
    ];

    protected $casts = [
        'note_sur'           => 'decimal:2',
        'coefficient'        => 'decimal:2',
        'ponderation'        => 'decimal:2',
        'date_evaluation'    => 'date',
        'date_saisie_limite' => 'date',
        'publiee'            => 'boolean',
        'meta_data'          => 'array',
        'type'               => TypeEvaluation::class,
        'statut'             => StatutEvaluation::class,
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePubliees($query)                  { return $query->where('publiee', true); }
    public function scopeValidees($query)                  { return $query->where('statut', StatutEvaluation::VALIDEE->value); }
    public function scopeDePeriode($query, int $periodeId) { return $query->where('periode_id', $periodeId); }
    public function scopeDeClasse($query, int $classeId)   { return $query->where('classe_id', $classeId); }
    public function scopeDeMatiere($query, int $matiereId) { return $query->where('matiere_id', $matiereId); }
    public function scopeDeAnnee($query, int $anneeId)     { return $query->where('annee_scolaire_id', $anneeId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estSaisie(): bool   { return $this->statut?->estSaisie() ?? false; }
    public function estValidee(): bool  { return $this->statut === StatutEvaluation::VALIDEE; }
    public function estPubliee(): bool  { return $this->publiee; }

    /** Moyenne de la classe pour cette évaluation (sur 20). */
    public function moyenneClasse(): ?float
    {
        $avg = $this->notes()
            ->whereNotNull('note_finale')
            ->where('est_absent', false)
            ->avg('note_finale');

        if ($avg === null) return null;

        // Ramener sur 20 si note_sur ≠ 20
        return $this->note_sur != 20
            ? round(($avg * 20) / $this->note_sur, 2)
            : round($avg, 2);
    }

    /** Note maximale obtenue dans la classe. */
    public function noteMax(): ?float
    {
        return $this->notes()->whereNotNull('note_finale')->where('est_absent', false)->max('note_finale');
    }

    /** Note minimale obtenue dans la classe. */
    public function noteMin(): ?float
    {
        return $this->notes()->whereNotNull('note_finale')->where('est_absent', false)->min('note_finale');
    }

    /** Nombre de notes saisies. */
    public function nbNotesSaisies(): int
    {
        return $this->notes()->whereNotNull('note_finale')->count();
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function periode(): BelongsTo       { return $this->belongsTo(Periode::class); }
    public function classe(): BelongsTo        { return $this->belongsTo(Classe::class); }
    public function matiere(): BelongsTo       { return $this->belongsTo(Matiere::class); }
    public function enseignant(): BelongsTo    { return $this->belongsTo(Enseignant::class); }

    public function notes(): HasMany
    {
        return $this->hasMany(Note::class);
    }
}
