<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\LienParente;

/**
 * Modèle ParentTuteur
 * Responsable légal d'un ou plusieurs élèves.
 * Peut avoir un compte utilisateur pour le portail parents.
 *
 * @property int         $id
 * @property string      $reference
 * @property string      $nom
 * @property string      $prenom
 * @property string|null $sexe
 * @property string|null $civilite
 * @property string|null $profession
 * @property string|null $email
 * @property string|null $telephone
 * @property bool        $a_compte_utilisateur
 * @property bool        $actif
 */
class ParentTuteur extends MtBaseModel
{
    protected $table = 'parents_tuteurs';

    protected $fillable = [
        'reference', 'nom', 'prenom', 'sexe', 'civilite',
        'profession', 'lieu_travail',
        'email', 'telephone', 'telephone_travail', 'adresse',
        'numero_cni', 'a_compte_utilisateur', 'actif',
        'observations', 'meta_data',
    ];

    protected $casts = [
        'a_compte_utilisateur' => 'boolean',
        'actif'                => 'boolean',
        'meta_data'            => 'array',
    ];

    protected static array $searchableColumns = ['nom', 'prenom', 'email', 'telephone', 'reference'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs($query) { return $query->where('actif', true); }

    public function scopeAvecPortail($query)
    {
        return $query->where('a_compte_utilisateur', true);
    }

    // ── Accesseurs ────────────────────────────────────────────────────────────

    public function getNomCompletAttribute(): string
    {
        $c = $this->civilite ? "{$this->civilite} " : '';
        return $c . trim("{$this->prenom} {$this->nom}");
    }

    public function getNomCompletInverseAttribute(): string
    {
        return trim("{$this->nom} {$this->prenom}");
    }

    public function getInitialesAttribute(): string
    {
        return mb_strtoupper(
            mb_substr($this->prenom ?? '', 0, 1) .
            mb_substr($this->nom ?? '', 0, 1)
        );
    }

    public function fullName(): string { return $this->nomComplet; }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function lienAvec(Eleve $eleve): ?LienParente
    {
        $pivot = $this->eleves()
            ->where('eleves.id', $eleve->id)
            ->first()?->pivot;

        if (!$pivot) return null;
        return LienParente::tryFrom($pivot->lien_parente);
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function eleves(): BelongsToMany
    {
        return $this->belongsToMany(
            Eleve::class,
            'eleve_parent',
            'parent_tuteur_id',
            'eleve_id'
        )->withPivot([
            'lien_parente',
            'est_contact_principal',
            'peut_recuperer',
            'acces_portail',
        ])->withTimestamps();
    }

    public function elevesActifs(): BelongsToMany
    {
        return $this->eleves()->where('eleves.actif', true);
    }

    /**
     * Compte utilisateur — pattern morphable mt-views.
     * users.userable_type = 'Mt\School\Models\ParentTuteur'
     */
    public function user(): MorphOne
    {
        return $this->morphOne(config('auth.providers.users.model'), 'userable');
    }
}
