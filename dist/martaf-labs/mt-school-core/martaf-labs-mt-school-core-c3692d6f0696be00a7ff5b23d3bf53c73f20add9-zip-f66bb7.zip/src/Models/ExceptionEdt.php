<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtViews\Traits\TracksUser;

/**
 * Modèle ExceptionEdt
 * Cours annulé, reporté ou remplacé à une date précise.
 *
 * @property int         $id
 * @property int         $creneau_id
 * @property \Carbon\Carbon $date_exception
 * @property string      $type    'annule'|'reporte'|'remplace'
 * @property array|null  $motif   JSON multilingue
 */
class ExceptionEdt extends Model
{
    use TracksUser;

    protected $table = 'exceptions_edt';

    protected $fillable = [
        'creneau_id', 'date_exception', 'type',
        'nouveau_creneau_id', 'nouvelle_date', 'nouvelle_heure_debut', 'nouvelle_heure_fin',
        'nouvelle_salle_id', 'motif',
    ];

    protected $casts = [
        'date_exception'      => 'date',
        'nouvelle_date'       => 'date',
        'motif'               => 'array',
    ];

    protected array $translatables = ['motif'];

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estAnnule(): bool  { return $this->type === 'annule'; }
    public function estReporte(): bool { return $this->type === 'reporte'; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function creneau(): BelongsTo
    {
        return $this->belongsTo(Creneau::class);
    }

    public function nouveauCreneau(): BelongsTo
    {
        return $this->belongsTo(Creneau::class, 'nouveau_creneau_id');
    }

    public function nouvelleSalle(): BelongsTo
    {
        return $this->belongsTo(Salle::class, 'nouvelle_salle_id');
    }
}
