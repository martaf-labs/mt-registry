<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\MtViews\Traits\TracksUser;

/**
 * Modèle RessourcePedagogique
 * Document, fichier ou lien partagé par un enseignant à ses élèves.
 *
 * @property int    $id
 * @property array  $titre
 * @property string $type      'document'|'video'|'audio'|'lien'|'exercice'|'corrige'|'autre'
 * @property string $audience  'classe'|'niveau'|'enseignants'|'tous'
 * @property bool   $publie
 */
class RessourcePedagogique extends MtBaseModel
{
    protected $table = 'ressources_pedagogiques';

    protected $fillable = [
        'annee_scolaire_id', 'matiere_id', 'classe_id', 'niveau_id', 'enseignant_id',
        'titre', 'description', 'type', 'fichier', 'url_externe', 'mime_type', 'taille_fichier',
        'audience', 'publie', 'telechargements', 'vues', 'tags', 'meta_data',
    ];

    protected $casts = [
        'description' => 'array',
        'tags'        => 'array',
        'meta_data'   => 'array',
        'publie'      => 'boolean',
    ];

    protected array $translatables = ['titre', 'description'];

    protected static array $searchableColumns = [];

    public function scopePubliees($query)              { return $query->where('publie', true); }
    public function scopeDeType($query, string $type)  { return $query->where('type', $type); }

    public function incrementerTelechargements(): void { $this->increment('telechargements'); }
    public function incrementerVues(): void            { $this->increment('vues'); }

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function matiere(): BelongsTo       { return $this->belongsTo(Matiere::class); }
    public function classe(): BelongsTo        { return $this->belongsTo(Classe::class); }
    public function niveau(): BelongsTo        { return $this->belongsTo(Niveau::class); }
    public function enseignant(): BelongsTo    { return $this->belongsTo(Enseignant::class); }
}


/**
 * Modèle DevoirMaison
 * Travail à rendre — avec date limite et soumissions élèves.
 *
 * @property int    $id
 * @property array  $titre
 * @property \Carbon\Carbon $date_limite_remise
 * @property bool   $est_note
 * @property string $statut  'brouillon'|'publie'|'cloture'
 */
class DevoirMaison extends MtBaseModel
{
    protected $table = 'devoirs_maison';

    protected $fillable = [
        'annee_scolaire_id', 'classe_id', 'matiere_id', 'enseignant_id', 'periode_id', 'evaluation_id',
        'titre', 'instructions', 'date_attribution', 'date_limite_remise',
        'est_note', 'note_sur', 'coefficient', 'statut', 'ressources', 'meta_data',
    ];

    protected $casts = [
        'instructions'      => 'array',
        'date_attribution'  => 'date',
        'date_limite_remise'=> 'datetime',
        'est_note'          => 'boolean',
        'note_sur'          => 'decimal:2',
        'coefficient'       => 'decimal:2',
        'ressources'        => 'array',
        'meta_data'         => 'array',
    ];

    protected array $translatables = ['titre', 'instructions'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePublies($query)  { return $query->where('statut', 'publie'); }
    public function scopeEnCours($query)  { return $query->where('statut', 'publie')->where('date_limite_remise', '>', now()); }
    public function scopeExpires($query)  { return $query->where('date_limite_remise', '<', now()); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estExpire(): bool { return $this->date_limite_remise->isPast(); }
    public function estNote(): bool   { return $this->est_note; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function classe(): BelongsTo        { return $this->belongsTo(Classe::class); }
    public function matiere(): BelongsTo       { return $this->belongsTo(Matiere::class); }
    public function enseignant(): BelongsTo    { return $this->belongsTo(Enseignant::class); }
    public function periode(): BelongsTo       { return $this->belongsTo(Periode::class); }
    public function evaluation(): BelongsTo    { return $this->belongsTo(Evaluation::class); }

    public function soumissions(): HasMany
    {
        return $this->hasMany(SoumissionDevoir::class);
    }
}


/**
 * Modèle SoumissionDevoir
 * Rendu d'un élève pour un devoir maison.
 *
 * @property int    $id
 * @property int    $devoir_maison_id
 * @property int    $inscription_id
 * @property bool   $en_retard
 * @property string $statut  'soumis'|'corrige'|'rendu'
 */
class SoumissionDevoir extends Model
{
    protected $table = 'soumissions_devoirs';

    protected $fillable = [
        'devoir_maison_id', 'inscription_id', 'fichier', 'commentaire',
        'soumis_at', 'en_retard', 'note', 'correction', 'fichier_correction', 'corrige_at', 'statut',
    ];

    protected $casts = [
        'soumis_at'  => 'datetime',
        'corrige_at' => 'datetime',
        'en_retard'  => 'boolean',
        'note'       => 'decimal:2',
    ];

    public function scopeCorrigees($query) { return $query->where('statut', 'corrige'); }
    public function scopeEnRetard($query)  { return $query->where('en_retard', true); }

    public function estCorrigee(): bool { return $this->statut === 'corrige'; }

    public function devoirMaison(): BelongsTo { return $this->belongsTo(DevoirMaison::class); }
    public function inscription(): BelongsTo  { return $this->belongsTo(Inscription::class); }
}


/**
 * Modèle CertificatScolarite
 * Document officiel délivré à un élève par l'établissement.
 *
 * @property int    $id
 * @property string $reference
 * @property int    $inscription_id
 * @property string $type    'certificat_scolarite'|'attestation_frequentation'|'releve_notes'|…
 * @property string $statut  'demande'|'en_cours'|'delivre'|'annule'
 * @property string $langue
 */
class CertificatScolarite extends MtBaseModel
{
    protected $table = 'certificats_scolarite';

    protected $fillable = [
        'reference', 'inscription_id', 'type', 'titre', 'motif', 'motif_detail',
        'destinataire', 'langue', 'fichier_pdf', 'signature_hash', 'qr_code',
        'statut', 'demande_par', 'demande_at', 'delivre_par', 'delivre_at',
        'nb_exemplaires', 'valide_jusqu_au', 'observations', 'meta_data',
    ];

    protected $casts = [
        'titre'            => 'array',
        'demande_at'       => 'datetime',
        'delivre_at'       => 'datetime',
        'valide_jusqu_au'  => 'date',
        'nb_exemplaires'   => 'integer',
        'meta_data'        => 'array',
    ];

    protected array $translatables = ['titre'];

    public function scopeDelivres($query) { return $query->where('statut', 'delivre'); }
    public function scopeEnCours($query)  { return $query->whereIn('statut', ['demande','en_cours']); }

    public function estDelivre(): bool { return $this->statut === 'delivre'; }
    public function estValide(): bool  { return !$this->valide_jusqu_au || $this->valide_jusqu_au->isFuture(); }

    public function delivrer(int $userId): self
    {
        $this->update([
            'statut'      => 'delivre',
            'delivre_par' => $userId,
            'delivre_at'  => now(),
        ]);
        return $this;
    }

    public function inscription(): BelongsTo { return $this->belongsTo(Inscription::class); }
}


/**
 * Modèle ParametreSchool
 * Configuration dynamique clé/valeur par groupe et par année scolaire.
 *
 * @property int    $id
 * @property string $cle
 * @property string $valeur
 * @property string $groupe       'general'|'notation'|'bulletin'|'inscription'|'finances'
 * @property string $type_valeur  'string'|'integer'|'decimal'|'boolean'|'json'|'array'
 * @property bool   $modifiable
 */
class ParametreSchool extends Model
{
    use TracksUser;

    protected $table = 'parametres_school';

    protected $fillable = [
        'cle', 'valeur', 'groupe', 'type_valeur', 'libelle', 'description',
        'modifiable', 'annee_scolaire_id',
    ];

    protected $casts = [
        'libelle'    => 'array',
        'modifiable' => 'boolean',
    ];

    protected array $translatables = ['libelle'];

    // ── Accesseurs ────────────────────────────────────────────────────────────

    public function getValeurCasteeAttribute(): mixed
    {
        return match ($this->type_valeur) {
            'integer' => (int) $this->valeur,
            'decimal' => (float) $this->valeur,
            'boolean' => filter_var($this->valeur, FILTER_VALIDATE_BOOLEAN),
            'json', 'array' => json_decode($this->valeur, true),
            default   => $this->valeur,
        };
    }

    // ── Raccourcis statiques ──────────────────────────────────────────────────

    public static function get(string $cle, mixed $defaut = null): mixed
    {
        $param = static::where('cle', $cle)->first();
        return $param ? $param->valeurCastee : $defaut;
    }

    public static function set(string $cle, mixed $valeur, ?string $groupe = 'general'): void
    {
        static::updateOrCreate(
            ['cle' => $cle],
            ['valeur' => is_array($valeur) ? json_encode($valeur) : (string) $valeur, 'groupe' => $groupe]
        );
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
}


/**
 * Modèle NotificationSchool
 * Notification in-app pour un utilisateur.
 *
 * @property int    $id
 * @property int    $user_id
 * @property array  $titre
 * @property string $type      'info'|'succes'|'alerte'|'erreur'
 * @property string $categorie 'note'|'bulletin'|'absence'|'paiement'|'annonce'|'devoir'
 * @property bool   $lue
 */
class NotificationSchool extends Model
{
    protected $table = 'notifications_school';

    protected $fillable = [
        'user_id', 'titre', 'corps', 'type', 'categorie',
        'notifiable_type', 'notifiable_id', 'url', 'lue', 'lue_at',
    ];

    protected $casts = [
        'titre'  => 'array',
        'corps'  => 'array',
        'lue'    => 'boolean',
        'lue_at' => 'datetime',
    ];

    protected array $translatables = ['titre', 'corps'];

    public function scopeNonLues($query) { return $query->where('lue', false); }
    public function scopeDeType($query, string $type) { return $query->where('type', $type); }

    public function marquerLue(): self
    {
        $this->update(['lue' => true, 'lue_at' => now()]);
        return $this;
    }

    public function estLue(): bool { return $this->lue; }
}


/**
 * Modèle ImportExport
 * Traçabilité des imports/exports batch (élèves CSV, bulletins PDF…).
 *
 * @property int    $id
 * @property string $operation  'import'|'export'
 * @property string $entite     'eleves'|'enseignants'|'notes'|'bulletins'|…
 * @property string $format     'csv'|'xlsx'|'pdf'|'json'|'zip'
 * @property string $statut     'en_attente'|'en_cours'|'termine'|'echec'|'partiel'
 */
class ImportExport extends Model
{
    use TracksUser;

    protected $table = 'imports_exports';

    protected $fillable = [
        'operation', 'entite', 'format', 'fichier', 'statut',
        'total_lignes', 'lignes_ok', 'lignes_erreur', 'lignes_ignorees',
        'rapport_erreurs', 'annee_scolaire_id', 'debut_at', 'fin_at', 'notes',
    ];

    protected $casts = [
        'rapport_erreurs' => 'array',
        'debut_at'        => 'datetime',
        'fin_at'          => 'datetime',
    ];

    public function scopeImports($query) { return $query->where('operation', 'import'); }
    public function scopeExports($query) { return $query->where('operation', 'export'); }
    public function scopeTermines($query){ return $query->where('statut', 'termine'); }
    public function scopeEnEchec($query) { return $query->where('statut', 'echec'); }

    public function estTermine(): bool { return $this->statut === 'termine'; }
    public function estEnEchec(): bool { return $this->statut === 'echec'; }

    public function tauxReussite(): float
    {
        if (!$this->total_lignes) return 0;
        return round(($this->lignes_ok / $this->total_lignes) * 100, 1);
    }

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
}
