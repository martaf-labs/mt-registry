<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\StatutContrat;
use Mt\School\Enums\TypePersonnel;

/**
 * Modèle Personnel
 * Toute personne employée par l'établissement.
 * Morphable via BaseUser (userable) pour le compte applicatif.
 *
 * @property int              $id
 * @property string           $reference
 * @property string           $nom
 * @property string           $prenom
 * @property string|null      $sexe
 * @property string|null      $civilite
 * @property TypePersonnel    $type
 * @property StatutContrat|null $statut_contrat
 * @property bool             $actif
 */
class Personnel extends MtBaseModel
{
    protected $table = 'personnels';

    protected $fillable = [
        'reference', 'nom', 'prenom', 'sexe', 'civilite',
        'date_naissance', 'lieu_naissance', 'nationalite', 'numero_cni',
        'type', 'poste', 'grade', 'statut_contrat',
        'date_embauche', 'date_fin_contrat',
        'email', 'telephone', 'telephone_urgence', 'adresse',
        'a_compte_utilisateur', 'actif', 'observations', 'meta_data',
    ];

    protected $casts = [
        'date_naissance'       => 'date',
        'date_embauche'        => 'date',
        'date_fin_contrat'     => 'date',
        'a_compte_utilisateur' => 'boolean',
        'actif'                => 'boolean',
        'meta_data'            => 'array',
        'type'                 => TypePersonnel::class,
        'statut_contrat'       => StatutContrat::class,
    ];

    protected static array $searchableColumns = ['nom', 'prenom', 'reference', 'email', 'telephone'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs($query)                   { return $query->where('actif', true); }
    public function scopeDeType($query, TypePersonnel $t) { return $query->where('type', $t->value); }
    public function scopeEnseignants($query)              { return $query->where('type', TypePersonnel::ENSEIGNANT->value); }
    public function scopeDirection($query)                { return $query->where('type', TypePersonnel::DIRECTION->value); }

    // ── Accesseurs ────────────────────────────────────────────────────────────

    public function getNomCompletAttribute(): string
    {
        return trim("{$this->prenom} {$this->nom}");
    }

    public function getNomCompletInverseAttribute(): string
    {
        return trim("{$this->nom} {$this->prenom}");
    }

    public function getAgeAttribute(): ?int
    {
        return $this->date_naissance?->age;
    }

    public function getInitialesAttribute(): string
    {
        $p = mb_substr($this->prenom ?? '', 0, 1);
        $n = mb_substr($this->nom ?? '', 0, 1);
        return mb_strtoupper("{$p}{$n}");
    }

    /** fullName() pour compatibilité avec BaseUser::fullName() */
    public function fullName(): string
    {
        return $this->nomComplet;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estEnseignant(): bool   { return $this->type === TypePersonnel::ENSEIGNANT; }
    public function estDirection(): bool    { return $this->type === TypePersonnel::DIRECTION; }
    public function estAdministratif(): bool{ return $this->type === TypePersonnel::ADMINISTRATIF; }

    public function contratActif(): bool
    {
        if (!$this->actif) return false;
        if (!$this->date_fin_contrat) return true;
        return $this->date_fin_contrat->isFuture();
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function enseignant(): HasOne
    {
        return $this->hasOne(Enseignant::class);
    }

    /**
     * Compte utilisateur via pattern morphable de mt-views.
     * users.userable_type = 'Mt\School\Models\Personnel'
     * users.userable_id   = $this->id
     */
    public function user(): MorphOne
    {
        return $this->morphOne(config('auth.providers.users.model'), 'userable');
    }
}
