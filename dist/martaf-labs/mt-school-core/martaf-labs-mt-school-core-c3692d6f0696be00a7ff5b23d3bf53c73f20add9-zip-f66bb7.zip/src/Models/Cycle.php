<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\TypeCycle;

/**
 * Modèle Cycle
 *
 * @property int      $id
 * @property array    $libelle
 * @property string   $code     'MATERNEL'|'PRIMAIRE'|'COLLEGE'|'LYCEE'|'SUPERIEUR'
 * @property TypeCycle $type
 * @property int      $ordre
 * @property string   $couleur
 * @property bool     $actif
 */
class Cycle extends MtBaseModel
{
    protected $table = 'cycles';

    protected $fillable = [
        'libelle', 'code', 'type', 'ordre', 'couleur', 'icone', 'description', 'actif',
    ];

    protected $casts = [
        'actif' => 'boolean',
        'type'  => TypeCycle::class,
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActif($query) { return $query->where('actif', true); }

    public function scopeDeType($query, TypeCycle $type)
    {
        return $query->where('type', $type->value);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estPrescolaire(): bool  { return $this->type === TypeCycle::PRESCOLAIRE; }
    public function estPrimaire(): bool     { return $this->type === TypeCycle::PRIMAIRE; }
    public function estSecondaire(): bool   { return $this->type === TypeCycle::SECONDAIRE; }
    public function estSuperieur(): bool    { return $this->type === TypeCycle::SUPERIEUR; }
    public function estLmd(): bool          { return $this->type?->estLmd() ?? false; }
    public function aDesFilieres(): bool    { return $this->type?->aDesFilieres() ?? false; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function niveaux(): HasMany
    {
        return $this->hasMany(Niveau::class)->orderBy('ordre');
    }

    public function niveauxActifs(): HasMany
    {
        return $this->hasMany(Niveau::class)->where('actif', true)->orderBy('ordre');
    }
}
