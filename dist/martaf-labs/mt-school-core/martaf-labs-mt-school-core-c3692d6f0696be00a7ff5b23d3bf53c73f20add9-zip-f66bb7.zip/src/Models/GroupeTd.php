<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle GroupeTd
 * Sous-groupe d'une classe pour les TD/TP (surtout enseignement supérieur).
 *
 * @property int         $id
 * @property int         $classe_id
 * @property int|null    $matiere_id
 * @property array       $libelle
 * @property string      $code        'GRP-A'|'TD1'|'TP-INFO-B'
 * @property string      $type        'td'|'tp'|'oral'|'autre'
 * @property int         $effectif_max
 * @property int         $effectif_actuel
 * @property bool        $actif
 */
class GroupeTd extends MtBaseModel
{
    protected $table = 'groupes_td';

    protected $fillable = [
        'classe_id', 'matiere_id', 'libelle', 'code', 'type',
        'effectif_max', 'effectif_actuel', 'actif', 'observations',
    ];

    protected $casts = [
        'actif'           => 'boolean',
        'effectif_max'    => 'integer',
        'effectif_actuel' => 'integer',
    ];

    protected array $translatables = ['libelle'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs($query)                { return $query->where('actif', true); }
    public function scopeDeClasse($query, int $id)     { return $query->where('classe_id', $id); }
    public function scopeDeMatiere($query, int $id)    { return $query->where('matiere_id', $id); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function placesRestantes(): int
    {
        return max(0, $this->effectif_max - $this->effectif_actuel);
    }

    public function estPlein(): bool
    {
        return $this->effectif_actuel >= $this->effectif_max;
    }

    public function recalculerEffectif(): self
    {
        $this->effectif_actuel = $this->inscriptions()->count();
        $this->saveQuietly();
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function classe(): BelongsTo  { return $this->belongsTo(Classe::class); }
    public function matiere(): BelongsTo { return $this->belongsTo(Matiere::class); }

    public function inscriptions(): BelongsToMany
    {
        return $this->belongsToMany(
            Inscription::class,
            'groupe_td_inscription',
            'groupe_td_id',
            'inscription_id'
        )->withTimestamps();
    }

    public function creneaux(): HasMany
    {
        return $this->hasMany(Creneau::class);
    }
}
