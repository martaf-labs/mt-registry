<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\StatutBulletin;

/**
 * Modèle Bulletin
 * Document officiel par élève par période — agrège moyennes et résultats.
 *
 * @property int             $id
 * @property string          $reference
 * @property int             $inscription_id
 * @property int             $periode_id
 * @property int|null        $moyenne_periode_id
 * @property StatutBulletin  $statut
 * @property string|null     $fichier_pdf
 * @property bool            $visible_portail
 * @property string          $layout
 */
class Bulletin extends MtBaseModel
{
    protected $table = 'bulletins';

    protected $fillable = [
        'reference', 'inscription_id', 'periode_id', 'moyenne_periode_id',
        'statut', 'fichier_pdf',
        'nom_directeur', 'nom_professeur_principal', 'signature_hash',
        'genere_at', 'valide_at', 'publie_at',
        'visible_portail', 'layout', 'meta_data', 'observations',
    ];

    protected $casts = [
        'genere_at'       => 'datetime',
        'valide_at'       => 'datetime',
        'publie_at'       => 'datetime',
        'visible_portail' => 'boolean',
        'meta_data'       => 'array',
        'statut'          => StatutBulletin::class,
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePublies($query)         { return $query->where('statut', StatutBulletin::PUBLIE->value); }
    public function scopeVisiblesPortail($query) { return $query->where('visible_portail', true); }
    public function scopeValides($query)
    {
        return $query->whereIn('statut', [StatutBulletin::VALIDE->value, StatutBulletin::PUBLIE->value]);
    }
    public function scopeDePeriode($query, int $periodeId) { return $query->where('periode_id', $periodeId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estGenere(): bool
    {
        return in_array($this->statut, [StatutBulletin::GENERE, StatutBulletin::VALIDE, StatutBulletin::PUBLIE]);
    }

    public function estValide(): bool
    {
        return in_array($this->statut, [StatutBulletin::VALIDE, StatutBulletin::PUBLIE]);
    }

    public function estPublie(): bool { return $this->statut === StatutBulletin::PUBLIE; }

    public function publier(): self
    {
        $this->update([
            'statut'          => StatutBulletin::PUBLIE,
            'publie_at'       => now(),
            'visible_portail' => true,
        ]);
        return $this;
    }

    public function valider(): self
    {
        $this->update([
            'statut'    => StatutBulletin::VALIDE,
            'valide_at' => now(),
        ]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscription(): BelongsTo
    {
        return $this->belongsTo(Inscription::class);
    }

    public function periode(): BelongsTo
    {
        return $this->belongsTo(Periode::class);
    }

    public function moyennePeriode(): BelongsTo
    {
        return $this->belongsTo(MoyennePeriode::class, 'moyenne_periode_id');
    }
}
