<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtViews\Traits\TracksUser;
use Mt\School\Enums\StatutPresence;

/**
 * Modèle Presence
 * Enregistre la présence/absence/retard d'un élève à un créneau ou journée.
 *
 * @property int            $id
 * @property int            $inscription_id
 * @property int|null       $creneau_id
 * @property \Carbon\Carbon $date
 * @property string         $mode        'creneau'|'demi_journee'|'journee'
 * @property StatutPresence $statut
 * @property int            $retard_minutes
 * @property bool           $est_justifiee
 */
class Presence extends Model
{
    use TracksUser;

    protected $table = 'presences';

    protected $fillable = [
        'inscription_id', 'creneau_id', 'matiere_id', 'enseignant_id',
        'date', 'mode', 'periode_journee', 'statut', 'retard_minutes',
        'justification_id', 'est_justifiee', 'saisi_par', 'observations',
    ];

    protected $casts = [
        'date'          => 'date',
        'est_justifiee' => 'boolean',
        'statut'        => StatutPresence::class,
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopePresents($query)    { return $query->where('statut', StatutPresence::PRESENT->value); }
    public function scopeAbsents($query)     { return $query->where('statut', StatutPresence::ABSENT->value); }
    public function scopeRetards($query)     { return $query->where('statut', StatutPresence::RETARD->value); }
    public function scopeJustifiees($query)  { return $query->where('est_justifiee', true); }
    public function scopeInjustifiees($query){ return $query->where('est_justifiee', false)->where('statut', StatutPresence::ABSENT->value); }

    public function scopeDeDate($query, $date)
    {
        return $query->where('date', $date);
    }

    public function scopeDePeriode($query, $debut, $fin)
    {
        return $query->whereBetween('date', [$debut, $fin]);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estPresent(): bool   { return $this->statut === StatutPresence::PRESENT; }
    public function estAbsent(): bool    { return $this->statut === StatutPresence::ABSENT; }
    public function estEnRetard(): bool  { return $this->statut === StatutPresence::RETARD; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscription(): BelongsTo     { return $this->belongsTo(Inscription::class); }
    public function creneau(): BelongsTo         { return $this->belongsTo(Creneau::class); }
    public function matiere(): BelongsTo         { return $this->belongsTo(Matiere::class); }
    public function enseignant(): BelongsTo      { return $this->belongsTo(Enseignant::class); }
    public function justification(): BelongsTo   { return $this->belongsTo(JustificationAbsence::class, 'justification_id'); }
}
