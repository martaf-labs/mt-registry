<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Niveau
 *
 * @property int         $id
 * @property int         $cycle_id
 * @property array       $libelle
 * @property string      $code
 * @property string|null $abreviation
 * @property int         $ordre
 * @property bool        $actif
 * @property array|null  $meta_data
 */
class Niveau extends MtBaseModel
{
    protected $table = 'niveaux';

    protected $fillable = [
        'cycle_id', 'libelle', 'code', 'abreviation',
        'ordre', 'actif', 'description', 'meta_data',
    ];

    protected $casts = [
        'actif'     => 'boolean',
        'meta_data' => 'array',
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code', 'abreviation'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs($query)            { return $query->where('actif', true); }

    public function scopeDeCycle($query, int $id)  { return $query->where('cycle_id', $id); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function labelCourt(): string
    {
        return $this->abreviation ?? $this->code;
    }

    public function estSuperieur(): bool
    {
        return $this->cycle?->estSuperieur() ?? false;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function cycle(): BelongsTo
    {
        return $this->belongsTo(Cycle::class);
    }

    public function filieres(): BelongsToMany
    {
        return $this->belongsToMany(Filiere::class, 'niveau_filiere');
    }

    public function classes(): HasMany
    {
        return $this->hasMany(Classe::class);
    }

    public function programmes(): HasMany
    {
        return $this->hasMany(Programme::class);
    }

    public function baremesFrais(): HasMany
    {
        return $this->hasMany(BaremeFrais::class);
    }
}
