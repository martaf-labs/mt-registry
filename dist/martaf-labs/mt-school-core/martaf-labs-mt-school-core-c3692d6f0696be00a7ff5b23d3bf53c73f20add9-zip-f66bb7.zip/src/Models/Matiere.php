<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\GroupeDisciplinaire;

/**
 * Modèle Matiere
 *
 * @property int                  $id
 * @property array                $libelle
 * @property string               $code
 * @property string|null          $abreviation
 * @property GroupeDisciplinaire  $groupe
 * @property string               $couleur
 * @property bool                 $actif
 * @property bool                 $est_principale
 */
class Matiere extends MtBaseModel
{
    protected $table = 'matieres';

    protected $fillable = [
        'libelle', 'code', 'abreviation', 'groupe',
        'couleur', 'icone', 'actif', 'est_principale', 'description',
    ];

    protected $casts = [
        'actif'          => 'boolean',
        'est_principale' => 'boolean',
        'groupe'         => GroupeDisciplinaire::class,
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code', 'abreviation'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActives($query)                          { return $query->where('actif', true); }
    public function scopePrincipales($query)                      { return $query->where('est_principale', true); }
    public function scopeDeGroupe($query, GroupeDisciplinaire $g) { return $query->where('groupe', $g->value); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function labelCourt(): string
    {
        return $this->abreviation ?? $this->code;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function programmes(): BelongsToMany
    {
        return $this->belongsToMany(Programme::class, 'programme_matiere')
            ->withPivot(['coefficient', 'volume_horaire_semaine', 'ordre', 'est_eliminatoire', 'note_eliminatoire', 'sur_bulletin'])
            ->withTimestamps();
    }

    public function enseignants(): BelongsToMany
    {
        return $this->belongsToMany(Enseignant::class, 'enseignant_matiere');
    }

    public function attributionsCours(): HasMany
    {
        return $this->hasMany(AttributionCours::class);
    }

    public function evaluations(): HasMany
    {
        return $this->hasMany(Evaluation::class);
    }

    public function moyennesMatieres(): HasMany
    {
        return $this->hasMany(MoyenneMatiere::class);
    }

    public function ressourcesPedagogiques(): HasMany
    {
        return $this->hasMany(RessourcePedagogique::class);
    }
}
