<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Eleve
 * Profil permanent de l'apprenant — indépendant des années scolaires.
 * Le rattachement classe/année se fait via Inscription.
 *
 * @property int              $id
 * @property string           $reference    Matricule auto-généré
 * @property string           $nom
 * @property string           $prenom
 * @property string|null      $sexe         'M'|'F'
 * @property \Carbon\Carbon|null $date_naissance
 * @property string|null      $photo
 * @property bool             $actif
 */
class Eleve extends MtBaseModel
{
    protected $table = 'eleves';

    protected $fillable = [
        'reference', 'nom', 'prenom', 'sexe',
        'date_naissance', 'lieu_naissance', 'nationalite', 'numero_extrait',
        'photo', 'email', 'telephone', 'adresse',
        'groupe_sanguin', 'allergies', 'infos_medicales',
        'ecole_precedente', 'classe_precedente', 'annee_precedente',
        'langue_maternelle', 'a_compte_utilisateur', 'actif',
        'observations', 'meta_data',
    ];

    protected $casts = [
        'date_naissance'       => 'date',
        'a_compte_utilisateur' => 'boolean',
        'actif'                => 'boolean',
        'meta_data'            => 'array',
    ];

    protected static array $searchableColumns = ['nom', 'prenom', 'reference', 'email', 'telephone'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs($query)        { return $query->where('actif', true); }
    public function scopeGarcons($query)       { return $query->where('sexe', 'M'); }
    public function scopeFilles($query)        { return $query->where('sexe', 'F'); }

    // ── Accesseurs ────────────────────────────────────────────────────────────

    public function getNomCompletAttribute(): string
    {
        return trim("{$this->prenom} {$this->nom}");
    }

    public function getNomCompletInverseAttribute(): string
    {
        return trim("{$this->nom} {$this->prenom}");
    }

    public function getAgeAttribute(): ?int
    {
        return $this->date_naissance?->age;
    }

    public function getInitialesAttribute(): string
    {
        return mb_strtoupper(
            mb_substr($this->prenom ?? '', 0, 1) .
            mb_substr($this->nom ?? '', 0, 1)
        );
    }

    public function getSexeLabelAttribute(): string
    {
        return match ($this->sexe) {
            'M' => 'Masculin',
            'F' => 'Féminin',
            default => 'Non renseigné',
        };
    }

    public function fullName(): string { return $this->nomComplet; }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Inscription pour une année donnée (défaut : année active). */
    public function inscriptionDe(?int $anneeId = null): ?Inscription
    {
        $anneeId ??= AnneeScolaire::courante()?->id;
        if (!$anneeId) return null;
        return $this->inscriptions()->where('annee_scolaire_id', $anneeId)->first();
    }

    /** Classe actuelle (via inscription de l'année active). */
    public function classeActuelle(): ?Classe
    {
        return $this->inscriptionDe()?->classe;
    }

    public function estInscritCetteAnnee(): bool
    {
        return $this->inscriptionDe() !== null;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscriptions(): HasMany
    {
        return $this->hasMany(Inscription::class);
    }

    public function inscriptionActuelle(): HasOne
    {
        return $this->hasOne(Inscription::class)
            ->whereHas('anneeScolaire', fn($q) => $q->where('est_active', true));
    }

    public function parentsTuteurs(): BelongsToMany
    {
        return $this->belongsToMany(
            ParentTuteur::class,
            'eleve_parent',
            'eleve_id',
            'parent_tuteur_id'
        )->withPivot([
            'lien_parente',
            'est_contact_principal',
            'peut_recuperer',
            'acces_portail',
        ])->withTimestamps();
    }

    public function contactPrincipal(): BelongsToMany
    {
        return $this->parentsTuteurs()
            ->wherePivot('est_contact_principal', true);
    }

    /**
     * Compte utilisateur — pattern morphable mt-views.
     * users.userable_type = 'Mt\School\Models\Eleve'
     */
    public function user(): MorphOne
    {
        return $this->morphOne(config('auth.providers.users.model'), 'userable');
    }
}
