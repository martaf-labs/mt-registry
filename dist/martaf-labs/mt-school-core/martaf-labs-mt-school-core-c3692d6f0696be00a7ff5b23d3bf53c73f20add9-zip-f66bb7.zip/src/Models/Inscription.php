<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\ResultatInscription;
use Mt\School\Enums\StatutInscription;

/**
 * Modèle Inscription — NŒUD CENTRAL du package.
 * Lien entre un Élève, une Classe et une AnneeScolaire.
 * Toutes les notes, présences, bulletins et frais s'y rattachent.
 *
 * @property int                    $id
 * @property string                 $reference       'INS-2024-00001'
 * @property int                    $annee_scolaire_id
 * @property int                    $eleve_id
 * @property int                    $classe_id
 * @property StatutInscription      $statut
 * @property ResultatInscription|null $resultat
 * @property float|null             $moyenne_annuelle
 * @property int|null               $rang_annuel
 * @property bool                   $est_redoublant
 * @property bool                   $est_boursier
 */
class Inscription extends MtBaseModel
{
    protected $table = 'inscriptions';

    protected $fillable = [
        'reference', 'annee_scolaire_id', 'eleve_id', 'classe_id',
        'inscription_precedente_id',
        'statut', 'date_inscription', 'date_validation', 'valide_par',
        'resultat', 'moyenne_annuelle', 'rang_annuel',
        'etablissement_origine', 'etablissement_destination',
        'numero_table', 'est_boursier', 'est_redoublant', 'est_transfere',
        'motif_rejet', 'observations', 'documents', 'meta_data',
    ];

    protected $casts = [
        'date_inscription'  => 'date',
        'date_validation'   => 'date',
        'est_boursier'      => 'boolean',
        'est_redoublant'    => 'boolean',
        'est_transfere'     => 'boolean',
        'moyenne_annuelle'  => 'decimal:2',
        'documents'         => 'array',
        'meta_data'         => 'array',
        'statut'            => StatutInscription::class,
        'resultat'          => ResultatInscription::class,
    ];

    protected static array $searchableColumns = ['reference'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeValidees($query)
    {
        return $query->where('statut', StatutInscription::VALIDEE->value);
    }

    public function scopeEnAttente($query)
    {
        return $query->where('statut', StatutInscription::EN_ATTENTE->value);
    }

    public function scopeDeAnnee($query, int $anneeId)
    {
        return $query->where('annee_scolaire_id', $anneeId);
    }

    public function scopeDeClasse($query, int $classeId)
    {
        return $query->where('classe_id', $classeId);
    }

    public function scopeDeEleve($query, int $eleveId)
    {
        return $query->where('eleve_id', $eleveId);
    }

    public function scopeRedoublants($query)
    {
        return $query->where('est_redoublant', true);
    }

    public function scopeBoursiers($query)
    {
        return $query->where('est_boursier', true);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estValidee(): bool   { return $this->statut === StatutInscription::VALIDEE; }
    public function estEnAttente(): bool { return $this->statut === StatutInscription::EN_ATTENTE; }
    public function estRejetee(): bool   { return $this->statut === StatutInscription::REJETEE; }
    public function estAdmis(): bool     { return $this->resultat === ResultatInscription::ADMIS; }

    /** Valide l'inscription et met à jour l'effectif de la classe. */
    public function valider(int $userId): self
    {
        $this->update([
            'statut'          => StatutInscription::VALIDEE,
            'date_validation' => now(),
            'valide_par'      => $userId,
        ]);
        $this->classe->recalculerEffectif();
        return $this;
    }

    /** Rejette l'inscription avec un motif. */
    public function rejeter(string $motif, int $userId): self
    {
        $this->update([
            'statut'       => StatutInscription::REJETEE,
            'motif_rejet'  => $motif,
            'valide_par'   => $userId,
        ]);
        return $this;
    }

    /** Bulletin d'une période donnée. */
    public function bulletinDe(int $periodeId): ?Bulletin
    {
        return $this->bulletins()->where('periode_id', $periodeId)->first();
    }

    /** Moyenne générale d'une période donnée. */
    public function moyennePeriodeDe(int $periodeId): ?MoyennePeriode
    {
        return $this->moyennesPeriodes()->where('periode_id', $periodeId)->first();
    }

    /** Solde financier : total restant dû. */
    public function soldeFinancier(): float
    {
        return (float) $this->fraisScolaires()->sum('montant_restant');
    }

    public function estAJour(): bool
    {
        return $this->soldeFinancier() <= 0;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo
    {
        return $this->belongsTo(AnneeScolaire::class);
    }

    public function eleve(): BelongsTo
    {
        return $this->belongsTo(Eleve::class);
    }

    public function classe(): BelongsTo
    {
        return $this->belongsTo(Classe::class);
    }

    public function inscriptionPrecedente(): BelongsTo
    {
        return $this->belongsTo(Inscription::class, 'inscription_precedente_id');
    }

    // ── Évaluation ────────────────────────────────────────────────────────────

    public function notes(): HasMany
    {
        return $this->hasMany(Note::class);
    }

    public function moyennesMatieres(): HasMany
    {
        return $this->hasMany(MoyenneMatiere::class);
    }

    public function moyennesPeriodes(): HasMany
    {
        return $this->hasMany(MoyennePeriode::class);
    }

    public function bulletins(): HasMany
    {
        return $this->hasMany(Bulletin::class);
    }

    // ── Présences ─────────────────────────────────────────────────────────────

    public function presences(): HasMany
    {
        return $this->hasMany(Presence::class);
    }

    public function absences(): HasMany
    {
        return $this->hasMany(Presence::class)->where('statut', 'absent');
    }

    public function justificationsAbsence(): HasMany
    {
        return $this->hasMany(JustificationAbsence::class);
    }

    // ── Finances ──────────────────────────────────────────────────────────────

    public function fraisScolaires(): HasMany
    {
        return $this->hasMany(FraisScolaire::class);
    }

    public function bourses(): HasMany
    {
        return $this->hasMany(Bourse::class);
    }

    // ── Discipline & Pédagogie ────────────────────────────────────────────────

    public function sanctions(): HasMany
    {
        return $this->hasMany(Sanction::class);
    }

    public function soumissionsDevoirs(): HasMany
    {
        return $this->hasMany(SoumissionDevoir::class);
    }

    public function certificats(): HasMany
    {
        return $this->hasMany(CertificatScolarite::class);
    }
}
