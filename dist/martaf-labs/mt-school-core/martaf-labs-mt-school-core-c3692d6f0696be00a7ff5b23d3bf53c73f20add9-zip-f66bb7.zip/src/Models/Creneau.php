<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Traits\LogActivityAction;
use Mt\MtViews\Traits\TracksUser;
use Mt\School\Enums\JourSemaine;
use Mt\School\Enums\TypeCreneau;

/**
 * Modèle Creneau
 * Une séance de cours dans la grille hebdomadaire.
 *
 * @property int          $id
 * @property int          $emploi_du_temps_id
 * @property int|null     $attribution_cours_id
 * @property int          $matiere_id
 * @property int|null     $enseignant_id
 * @property int|null     $salle_id
 * @property int|null     $groupe_td_id
 * @property JourSemaine  $jour_semaine
 * @property string       $heure_debut   'HH:MM:SS'
 * @property string       $heure_fin     'HH:MM:SS'
 * @property TypeCreneau  $type
 * @property string       $recurrence   'toutes_semaines'|'semaines_paires'|'semaines_impaires'
 * @property bool         $actif
 */
class Creneau extends Model
{
    use TracksUser, LogActivityAction;

    protected $table = 'creneaux';

    protected $fillable = [
        'emploi_du_temps_id', 'attribution_cours_id', 'matiere_id',
        'enseignant_id', 'salle_id', 'groupe_td_id',
        'jour_semaine', 'heure_debut', 'heure_fin',
        'type', 'recurrence', 'actif', 'observations',
    ];

    protected $casts = [
        'actif'        => 'boolean',
        'jour_semaine' => JourSemaine::class,
        'type'         => TypeCreneau::class,
    ];

    // ── Accesseurs ────────────────────────────────────────────────────────────

    public function getDureeMinutesAttribute(): int
    {
        $debut = \Carbon\Carbon::createFromTimeString($this->heure_debut);
        $fin   = \Carbon\Carbon::createFromTimeString($this->heure_fin);
        return (int) $debut->diffInMinutes($fin);
    }

    public function getJourLabelAttribute(): string
    {
        return $this->jour_semaine?->label() ?? '';
    }

    public function getHeuresFormatAttribute(): string
    {
        $d = substr($this->heure_debut, 0, 5);
        $f = substr($this->heure_fin, 0, 5);
        return "{$d} – {$f}";
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estCours(): bool { return $this->type?->estCours() ?? false; }

    /** Vérifie si ce créneau est actif à une date donnée (gestion semaines paires/impaires). */
    public function estActifLe(\Carbon\Carbon $date): bool
    {
        if (!$this->actif) return false;

        return match ($this->recurrence) {
            'semaines_paires'   => $date->weekOfYear % 2 === 0,
            'semaines_impaires' => $date->weekOfYear % 2 !== 0,
            default             => true,
        };
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function emploiDuTemps(): BelongsTo   { return $this->belongsTo(EmploiDuTemps::class); }
    public function attributionCours(): BelongsTo{ return $this->belongsTo(AttributionCours::class); }
    public function matiere(): BelongsTo         { return $this->belongsTo(Matiere::class); }
    public function enseignant(): BelongsTo      { return $this->belongsTo(Enseignant::class); }
    public function salle(): BelongsTo           { return $this->belongsTo(Salle::class); }
    public function groupeTd(): BelongsTo        { return $this->belongsTo(GroupeTd::class); }

    public function exceptions(): HasMany
    {
        return $this->hasMany(ExceptionEdt::class);
    }

    public function presences(): HasMany
    {
        return $this->hasMany(Presence::class);
    }
}
