<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\JourSemaine;
use Mt\School\Enums\TypeCreneau;

/**
 * Modèle EmploiDuTemps
 * Grille hebdomadaire d'une classe pour une année scolaire.
 *
 * @property int    $id
 * @property int    $annee_scolaire_id
 * @property int    $classe_id
 * @property string $statut  'brouillon'|'publie'|'archive'
 * @property bool   $est_actif
 */
class EmploiDuTemps extends MtBaseModel
{
    protected $table = 'emplois_du_temps';

    protected $fillable = [
        'annee_scolaire_id', 'classe_id', 'libelle', 'code',
        'statut', 'date_debut_validite', 'date_fin_validite',
        'est_actif', 'observations',
    ];

    protected $casts = [
        'date_debut_validite' => 'date',
        'date_fin_validite'   => 'date',
        'est_actif'           => 'boolean',
        'libelle'             => 'array',
    ];

    protected array $translatables = ['libelle'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActifs($query)  { return $query->where('est_actif', true); }
    public function scopePublies($query) { return $query->where('statut', 'publie'); }

    public function scopeDeAnnee($query, int $anneeId)
    {
        return $query->where('annee_scolaire_id', $anneeId);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estPublie(): bool { return $this->statut === 'publie'; }

    public function publier(): self
    {
        $this->update(['statut' => 'publie', 'est_actif' => true]);
        return $this;
    }

    /** Créneaux groupés par jour de la semaine. */
    public function creneauxParJour(): \Illuminate\Support\Collection
    {
        return $this->creneaux()
            ->with(['matiere', 'enseignant.personnel', 'salle'])
            ->orderBy('jour_semaine')
            ->orderBy('heure_debut')
            ->get()
            ->groupBy('jour_semaine');
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function classe(): BelongsTo        { return $this->belongsTo(Classe::class); }

    public function creneaux(): HasMany
    {
        return $this->hasMany(Creneau::class)
            ->orderBy('jour_semaine')
            ->orderBy('heure_debut');
    }

    public function creneauxActifs(): HasMany
    {
        return $this->creneaux()->where('actif', true);
    }
}
