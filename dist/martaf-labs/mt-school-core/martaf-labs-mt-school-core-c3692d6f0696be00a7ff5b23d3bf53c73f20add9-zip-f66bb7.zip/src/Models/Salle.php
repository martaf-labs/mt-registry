<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle Salle
 *
 * @property int         $id
 * @property int|null    $batiment_id
 * @property array       $libelle
 * @property string      $code
 * @property string      $type       'classe'|'laboratoire'|'amphi'|'informatique'|'sport'
 * @property int         $capacite
 * @property bool        $actif
 * @property array|null  $equipements
 */
class Salle extends MtBaseModel
{
    protected $table = 'salles';

    protected $fillable = [
        'batiment_id', 'libelle', 'code', 'type',
        'capacite', 'actif', 'description', 'equipements',
    ];

    protected $casts = [
        'actif'       => 'boolean',
        'capacite'    => 'integer',
        'equipements' => 'array',
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActives($query)           { return $query->where('actif', true); }
    public function scopeDeType($query, string $t) { return $query->where('type', $t); }

    public function scopeDisponible($query, int $capaciteMin = 1)
    {
        return $query->where('actif', true)->where('capacite', '>=', $capaciteMin);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estLabo(): bool       { return $this->type === 'laboratoire'; }
    public function estAmphi(): bool      { return $this->type === 'amphi'; }
    public function estInformatique(): bool{ return $this->type === 'informatique'; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function batiment(): BelongsTo
    {
        return $this->belongsTo(Batiment::class);
    }

    public function classes(): HasMany
    {
        return $this->hasMany(Classe::class);
    }

    public function creneaux(): HasMany
    {
        return $this->hasMany(Creneau::class);
    }

    public function evenements(): HasMany
    {
        return $this->hasMany(EvenementAgenda::class);
    }
}
