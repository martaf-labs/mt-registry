<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtViews\Traits\TracksUser;

/**
 * Modèle MoyenneMatiere
 * Moyenne d'un élève dans une matière pour une période.
 * Calculée depuis les notes ou saisie manuellement.
 *
 * @property int        $id
 * @property int        $inscription_id
 * @property int        $periode_id
 * @property int        $matiere_id
 * @property float|null $moyenne
 * @property float      $coefficient
 * @property float|null $moyenne_ponderee   moyenne × coefficient
 * @property int|null   $rang
 * @property bool       $est_eliminatoire
 * @property bool       $validee
 */
class MoyenneMatiere extends Model
{
    use TracksUser;

    protected $table = 'moyennes_matieres';

    protected $fillable = [
        'inscription_id', 'periode_id', 'matiere_id',
        'moyenne', 'coefficient', 'moyenne_ponderee',
        'rang', 'moyenne_classe', 'note_max_classe', 'note_min_classe',
        'appreciation', 'est_eliminatoire', 'est_manuelle', 'validee',
    ];

    protected $casts = [
        'moyenne'          => 'decimal:2',
        'coefficient'      => 'decimal:2',
        'moyenne_ponderee' => 'decimal:2',
        'moyenne_classe'   => 'decimal:2',
        'note_max_classe'  => 'decimal:2',
        'note_min_classe'  => 'decimal:2',
        'est_eliminatoire' => 'boolean',
        'est_manuelle'     => 'boolean',
        'validee'          => 'boolean',
    ];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeValidees($query)        { return $query->where('validee', true); }
    public function scopeEliminatoires($query)   { return $query->where('est_eliminatoire', true); }
    public function scopeDePeriode($query, int $periodeId) { return $query->where('periode_id', $periodeId); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function valider(int $userId): self
    {
        $this->update(['validee' => true]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscription(): BelongsTo { return $this->belongsTo(Inscription::class); }
    public function periode(): BelongsTo     { return $this->belongsTo(Periode::class); }
    public function matiere(): BelongsTo     { return $this->belongsTo(Matiere::class); }
}
