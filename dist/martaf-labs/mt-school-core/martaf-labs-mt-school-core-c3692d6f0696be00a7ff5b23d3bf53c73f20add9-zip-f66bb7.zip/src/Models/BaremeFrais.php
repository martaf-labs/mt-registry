<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtViews\Traits\TracksUser;

class BaremeFrais extends Model
{
    use TracksUser;

    protected $table = 'baremes_frais';
    protected $fillable = [
        'annee_scolaire_id', 'type_frais_id', 'niveau_id', 'filiere_id',
        'montant', 'devise', 'actif', 'description',
    ];
    protected $casts = ['actif' => 'boolean', 'montant' => 'decimal:2'];

    public function scopeActifs($query)                { return $query->where('actif', true); }
    public function scopeDeAnnee($query, int $anneeId) { return $query->where('annee_scolaire_id', $anneeId); }

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function typeFrais(): BelongsTo     { return $this->belongsTo(TypeFrais::class); }
    public function niveau(): BelongsTo        { return $this->belongsTo(Niveau::class); }
    public function filiere(): BelongsTo       { return $this->belongsTo(Filiere::class); }
}
