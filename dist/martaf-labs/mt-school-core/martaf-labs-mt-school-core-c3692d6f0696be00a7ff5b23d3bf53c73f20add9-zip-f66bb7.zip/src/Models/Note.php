<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Mt\MtViews\Traits\TracksUser;

/**
 * Modèle Note
 * Note obtenue par un élève (inscription) à une évaluation.
 * note_finale = note + bonus - malus (calculée automatiquement au saving).
 *
 * @property int        $id
 * @property int        $evaluation_id
 * @property int        $inscription_id
 * @property float|null $note
 * @property float      $bonus
 * @property float      $malus
 * @property float|null $note_finale      note + bonus - malus
 * @property bool       $est_absent
 * @property bool       $absence_justifiee
 * @property bool       $est_manquante
 * @property string|null $appreciation
 * @property int|null   $rang
 * @property bool       $validee
 */
class Note extends Model
{
    use TracksUser;

    protected $table = 'notes';

    protected $fillable = [
        'evaluation_id', 'inscription_id',
        'note', 'bonus', 'malus', 'note_finale',
        'est_absent', 'absence_justifiee', 'est_manquante',
        'appreciation', 'rang',
        'validee', 'validee_par', 'validee_at',
        'observations',
    ];

    protected $casts = [
        'note'             => 'decimal:2',
        'bonus'            => 'decimal:2',
        'malus'            => 'decimal:2',
        'note_finale'      => 'decimal:2',
        'est_absent'       => 'boolean',
        'absence_justifiee'=> 'boolean',
        'est_manquante'    => 'boolean',
        'validee'          => 'boolean',
        'validee_at'       => 'datetime',
    ];

    // ── Boot : calcul automatique de note_finale ──────────────────────────────

    protected static function boot(): void
    {
        parent::boot();

        static::saving(function (self $note) {
            if ($note->note !== null && !$note->est_absent) {
                $sur = $note->evaluation?->note_sur ?? 20;
                $note->note_finale = round(
                    max(0, min((float) $sur, (float) $note->note + (float) $note->bonus - (float) $note->malus)),
                    2
                );
            } elseif ($note->est_absent) {
                $note->note_finale = $note->absence_justifiee ? null : 0;
            }
        });
    }

    // ── Accesseurs ────────────────────────────────────────────────────────────

    /**
     * Note finale ramenée sur 20 (indépendamment du barème de l'évaluation).
     * Utilisée pour les moyennes homogènes.
     */
    public function getNoteRameneeSur20Attribute(): ?float
    {
        $sur = $this->evaluation?->note_sur ?? 20;
        if ($this->note_finale === null || (float) $sur == 0) return null;
        return round(((float) $this->note_finale * 20) / (float) $sur, 2);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estValide(): bool    { return $this->validee; }
    public function estAbsent(): bool    { return $this->est_absent; }
    public function estManquante(): bool { return $this->est_manquante; }
    public function estSaisie(): bool    { return $this->note !== null || $this->est_absent; }

    public function valider(int $userId): self
    {
        $this->update(['validee' => true, 'validee_par' => $userId, 'validee_at' => now()]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function evaluation(): BelongsTo
    {
        return $this->belongsTo(Evaluation::class);
    }

    public function inscription(): BelongsTo
    {
        return $this->belongsTo(Inscription::class);
    }
}
