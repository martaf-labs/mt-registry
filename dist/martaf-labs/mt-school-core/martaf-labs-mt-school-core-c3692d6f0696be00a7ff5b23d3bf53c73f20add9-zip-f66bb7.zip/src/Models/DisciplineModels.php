<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;
use Mt\School\Enums\TypeSanction;

/**
 * Modèle Sanction
 * Mesure disciplinaire consignée dans le dossier d'un élève.
 *
 * @property int          $id
 * @property string       $reference
 * @property int          $inscription_id
 * @property TypeSanction $type
 * @property string       $statut  'en_cours'|'levee'|'archive'
 * @property bool         $parent_informe
 */
class Sanction extends MtBaseModel
{
    protected $table = 'sanctions';

    protected $fillable = [
        'reference', 'inscription_id', 'type', 'libelle', 'motif',
        'date_sanction', 'date_fin', 'prononcee_par', 'statut',
        'parent_informe', 'parent_informe_at', 'suite_donnee', 'meta_data',
    ];

    protected $casts = [
        'libelle'           => 'array',
        'date_sanction'     => 'date',
        'date_fin'          => 'date',
        'parent_informe'    => 'boolean',
        'parent_informe_at' => 'datetime',
        'meta_data'         => 'array',
        'type'              => TypeSanction::class,
    ];

    protected array $translatables = ['libelle'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeEnCours($query)    { return $query->where('statut', 'en_cours'); }
    public function scopeGraves($query)
    {
        return $query->whereIn('type', [
            TypeSanction::EXCLUSION_TEMP->value,
            TypeSanction::EXCLUSION_DEF->value,
        ]);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estEnCours(): bool   { return $this->statut === 'en_cours'; }
    public function estGrave(): bool     { return $this->type?->estGrave() ?? false; }

    public function informerParent(int $userId): self
    {
        $this->update([
            'parent_informe'    => true,
            'parent_informe_at' => now(),
        ]);
        return $this;
    }

    public function lever(): self
    {
        $this->update(['statut' => 'levee']);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function inscription(): BelongsTo { return $this->belongsTo(Inscription::class); }
}


/**
 * Modèle ConseilClasse
 * Réunion formelle des enseignants d'une classe à la fin d'une période.
 * Produit un PV et valide les décisions (résultats, orientations).
 *
 * @property int    $id
 * @property int    $annee_scolaire_id
 * @property int    $classe_id
 * @property int    $periode_id
 * @property string $statut  'planifie'|'tenu'|'pv_redige'|'valide'
 */
class ConseilClasse extends MtBaseModel
{
    protected $table = 'conseils_classe';

    protected $fillable = [
        'annee_scolaire_id', 'classe_id', 'periode_id', 'titre',
        'date_conseil', 'lieu', 'statut', 'president_id',
        'pv_contenu', 'pv_fichier', 'valide_at', 'valide_par',
        'observations', 'meta_data',
    ];

    protected $casts = [
        'titre'        => 'array',
        'date_conseil' => 'datetime',
        'valide_at'    => 'datetime',
        'meta_data'    => 'array',
    ];

    protected array $translatables = ['titre'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeTenus($query)    { return $query->whereIn('statut', ['tenu','pv_redige','valide']); }
    public function scopeValides($query)  { return $query->where('statut', 'valide'); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function estTenu(): bool   { return in_array($this->statut, ['tenu','pv_redige','valide']); }
    public function estValide(): bool { return $this->statut === 'valide'; }

    public function valider(int $userId): self
    {
        $this->update([
            'statut'     => 'valide',
            'valide_at'  => now(),
            'valide_par' => $userId,
        ]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function anneeScolaire(): BelongsTo { return $this->belongsTo(AnneeScolaire::class); }
    public function classe(): BelongsTo        { return $this->belongsTo(Classe::class); }
    public function periode(): BelongsTo       { return $this->belongsTo(Periode::class); }

    public function participants(): HasMany
    {
        return $this->hasMany(ConseilParticipant::class);
    }
}


/**
 * Modèle ConseilParticipant
 * Participant à un conseil de classe avec son rôle et sa signature.
 */
class ConseilParticipant extends \Illuminate\Database\Eloquent\Model
{
    protected $table = 'conseil_participants';

    protected $fillable = [
        'conseil_classe_id', 'user_id', 'role_conseil', 'present', 'a_signe',
    ];

    protected $casts = [
        'present' => 'boolean',
        'a_signe' => 'boolean',
    ];

    public function conseilClasse(): BelongsTo
    {
        return $this->belongsTo(ConseilClasse::class);
    }
}
