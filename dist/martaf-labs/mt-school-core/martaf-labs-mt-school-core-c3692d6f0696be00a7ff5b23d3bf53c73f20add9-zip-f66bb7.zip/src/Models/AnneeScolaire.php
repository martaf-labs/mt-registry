<?php

namespace Mt\School\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Mt\MtViews\Models\MtBaseModel;

/**
 * Modèle AnneeScolaire — TABLE RACINE du package.
 *
 * @property int         $id
 * @property array       $libelle
 * @property string      $code        Ex : '2024-2025'
 * @property \Carbon\Carbon $date_debut
 * @property \Carbon\Carbon $date_fin
 * @property bool        $est_active
 * @property bool        $est_cloturee
 * @property array|null  $meta_data
 */
class AnneeScolaire extends MtBaseModel
{
    protected $table = 'annees_scolaires';

    protected $fillable = [
        'libelle', 'code', 'date_debut', 'date_fin',
        'est_active', 'est_cloturee', 'description', 'meta_data',
    ];

    protected $casts = [
        'date_debut'   => 'date',
        'date_fin'     => 'date',
        'est_active'   => 'boolean',
        'est_cloturee' => 'boolean',
        'meta_data'    => 'array',
    ];

    protected array $translatables = ['libelle'];

    protected static array $searchableColumns = ['code'];

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeEnCours($query)    { return $query->where('est_active', true); }
    public function scopeOuverte($query)    { return $query->where('est_cloturee', false); }
    public function scopeCloturee($query)   { return $query->where('est_cloturee', true); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public static function courante(): ?self
    {
        return static::where('est_active', true)->first();
    }

    public function activer(): self
    {
        static::query()->update(['est_active' => false]);
        $this->update(['est_active' => true]);
        return $this;
    }

    public function cloturer(): self
    {
        $this->update(['est_cloturee' => true, 'est_active' => false]);
        return $this;
    }

    public function estActive(): bool   { return $this->est_active; }
    public function estCloturee(): bool { return $this->est_cloturee; }
    public function estOuverte(): bool  { return !$this->est_cloturee; }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function periodes(): HasMany
    {
        return $this->hasMany(Periode::class)->orderBy('ordre');
    }

    public function trimestresPrincipaux(): HasMany
    {
        return $this->hasMany(Periode::class)->whereNull('parent_id')->orderBy('ordre');
    }

    public function classes(): HasMany          { return $this->hasMany(Classe::class); }
    public function inscriptions(): HasMany     { return $this->hasMany(Inscription::class); }
    public function programmes(): HasMany       { return $this->hasMany(Programme::class); }
    public function evaluations(): HasMany      { return $this->hasMany(Evaluation::class); }
    public function emploisDuTemps(): HasMany   { return $this->hasMany(EmploiDuTemps::class); }
    public function attributionsCours(): HasMany{ return $this->hasMany(AttributionCours::class); }
    public function baremesFrais(): HasMany     { return $this->hasMany(BaremeFrais::class); }
    public function annonces(): HasMany         { return $this->hasMany(Annonce::class); }
    public function evenementsAgenda(): HasMany { return $this->hasMany(EvenementAgenda::class); }
    public function periodesConges(): HasMany   { return $this->hasMany(PeriodeConges::class); }
    public function parametres(): HasMany       { return $this->hasMany(ParametreSchool::class); }
    public function conseils(): HasMany         { return $this->hasMany(ConseilClasse::class); }
}
