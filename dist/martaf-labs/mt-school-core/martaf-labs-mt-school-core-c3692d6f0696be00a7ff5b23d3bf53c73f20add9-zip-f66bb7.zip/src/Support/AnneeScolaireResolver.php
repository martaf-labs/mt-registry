<?php

namespace Mt\School\Support;

use Mt\School\Models\AnneeScolaire;

/**
 * Résoluteur de l'année scolaire active — injecté comme singleton.
 * Met en cache l'instance pour éviter les requêtes multiples.
 */
class AnneeScolaireResolver
{
    protected ?AnneeScolaire $courante = null;

    public function courante(): ?AnneeScolaire
    {
        if ($this->courante === null) {
            $this->courante = AnneeScolaire::where('est_active', true)->first();
        }
        return $this->courante;
    }

    public function idCourant(): ?int
    {
        return $this->courante()?->id;
    }

    public function labelActif(): string
    {
        return $this->courante()?->code ?? '';
    }

    /** Invalide le cache (utile après activation d'une nouvelle année). */
    public function rafraichir(): self
    {
        $this->courante = null;
        return $this;
    }
}
