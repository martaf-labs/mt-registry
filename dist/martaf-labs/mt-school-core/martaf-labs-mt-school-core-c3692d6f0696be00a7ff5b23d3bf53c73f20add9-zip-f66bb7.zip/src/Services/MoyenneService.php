<?php namespace Mt\School\Services;

use Mt\School\Models\Inscription;
use Mt\School\Models\MoyenneMatiere;
use Mt\School\Models\MoyennePeriode;
use Mt\School\Enums\Mention;

/**
 * Service de calcul des moyennes.
 * Calcule les moyennes par matière puis la moyenne générale d'une période.
 */
class MoyenneService
{
    /**
     * Calcule et persiste les moyennes d'une classe pour une période.
     */
    public function calculerPourClasse(int $classeId, int $periodeId): void
    {
        $inscriptions = Inscription::where('classe_id', $classeId)
            ->where('statut', 'validee')
            ->get();

        foreach ($inscriptions as $inscription) {
            $this->calculerPourInscription($inscription, $periodeId);
        }

        // Calculer les rangs après avoir toutes les moyennes
        $this->calculerRangs($classeId, $periodeId);
    }

    /**
     * Calcule la moyenne d'un élève pour une période.
     */
    public function calculerPourInscription(Inscription $inscription, int $periodeId): ?MoyennePeriode
    {
        $notes = $inscription->notes()
            ->whereHas('evaluation', fn($q) => $q->where('periode_id', $periodeId)->where('statut', 'validee'))
            ->with('evaluation')
            ->get();

        if ($notes->isEmpty()) return null;

        $totalPoints      = 0;
        $totalCoefficients= 0;

        foreach ($notes as $note) {
            if ($note->est_absent && !$note->absence_justifiee) {
                $noteVal = 0;
            } elseif ($note->note_finale === null) {
                continue;
            } else {
                $noteVal = (float) $note->noteRamenee; // ramenée sur 20
            }
            $coef              = (float) $note->evaluation->coefficient;
            $totalPoints      += $noteVal * $coef;
            $totalCoefficients += $coef;
        }

        if ($totalCoefficients == 0) return null;

        $moyenne = round($totalPoints / $totalCoefficients, 2);

        return MoyennePeriode::updateOrCreate(
            ['inscription_id' => $inscription->id, 'periode_id' => $periodeId],
            [
                'moyenne_generale'   => $moyenne,
                'total_points'       => $totalPoints,
                'total_coefficients' => $totalCoefficients,
                'mention'            => Mention::fromMoyenne($moyenne)->value,
            ]
        );
    }

    /**
     * Calcule et persiste les rangs d'une classe pour une période.
     */
    public function calculerRangs(int $classeId, int $periodeId): void
    {
        $moyennes = MoyennePeriode::whereHas(
            'inscription', fn($q) => $q->where('classe_id', $classeId)
        )
        ->where('periode_id', $periodeId)
        ->orderByDesc('moyenne_generale')
        ->get();

        $effectif = $moyennes->count();
        $rang = 1;

        foreach ($moyennes as $moy) {
            $moy->update(['rang' => $rang, 'effectif_classe' => $effectif]);
            $rang++;
        }
    }
}
