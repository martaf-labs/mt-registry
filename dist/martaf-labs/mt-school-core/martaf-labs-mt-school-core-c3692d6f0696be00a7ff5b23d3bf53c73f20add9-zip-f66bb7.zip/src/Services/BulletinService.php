<?php namespace Mt\School\Services;

use Mt\School\Models\Bulletin;
use Mt\School\Models\Inscription;
use Mt\School\Enums\StatutBulletin;

/**
 * Service de génération et de publication des bulletins.
 */
class BulletinService
{
    public function __construct(protected MoyenneService $moyenneService) {}

    /**
     * Génère les bulletins de toute une classe pour une période.
     */
    public function genererPourClasse(int $classeId, int $periodeId): int
    {
        // 1. Recalculer les moyennes
        $this->moyenneService->calculerPourClasse($classeId, $periodeId);

        $inscriptions = Inscription::where('classe_id', $classeId)
            ->where('statut', 'validee')
            ->get();

        $count = 0;
        foreach ($inscriptions as $inscription) {
            $this->genererPourInscription($inscription, $periodeId);
            $count++;
        }

        return $count;
    }

    /**
     * Génère le bulletin d'un élève pour une période.
     */
    public function genererPourInscription(Inscription $inscription, int $periodeId): Bulletin
    {
        $moyennePeriode = $inscription->moyennePeriodeDe($periodeId)->first();

        $bulletin = Bulletin::updateOrCreate(
            ['inscription_id' => $inscription->id, 'periode_id' => $periodeId],
            [
                'moyenne_periode_id' => $moyennePeriode?->id,
                'statut'             => StatutBulletin::GENERE,
                'genere_at'          => now(),
                'layout'             => config('mtschool.bulletin.layout', 'standard'),
                'nom_directeur'      => config('mtschool.etablissement.directeur', ''),
            ]
        );

        return $bulletin;
    }

    /**
     * Publie tous les bulletins validés d'une classe/période.
     */
    public function publierPourClasse(int $classeId, int $periodeId): int
    {
        return Bulletin::whereHas(
            'inscription', fn($q) => $q->where('classe_id', $classeId)
        )
        ->where('periode_id', $periodeId)
        ->where('statut', StatutBulletin::VALIDE->value)
        ->each(fn($b) => $b->publier())
        ->count();
    }
}
