<?php namespace Mt\School\Services;

/**
 * Génère des références uniques pour chaque entité.
 * Format : PREFIXE-ANNEE-SEQUENCE (ex: INS-2024-00001)
 */
class ReferenceSchoolService
{
    public function inscription(int $annee): string  { return $this->generer('INS', $annee); }
    public function bulletin(int $annee): string     { return $this->generer('BUL', $annee); }
    public function paiement(int $annee): string     { return $this->generer('PAY', $annee); }
    public function frais(int $annee): string        { return $this->generer('FRS', $annee); }
    public function certificat(int $annee): string   { return $this->generer('CER', $annee); }
    public function eleve(): string                  { return $this->generer('ELV', date('Y')); }
    public function personnel(): string              { return $this->generer('PER', date('Y')); }

    protected function generer(string $prefix, int $annee): string
    {
        $sequence = str_pad(random_int(1, 99999), 5, '0', STR_PAD_LEFT);
        return "{$prefix}-{$annee}-{$sequence}";
    }
}
