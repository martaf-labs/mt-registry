<?php

namespace Mt\SchoolCore;

use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;
use Mt\School\Events\InscriptionValidee;
use Mt\School\Events\NotesSaisies;
use Mt\School\Events\BulletinPublie;
use Mt\School\Events\PaiementRecu;
use Mt\School\Events\AbsenceEnregistree;
use Mt\School\Listeners\RecalculerEffectifClasse;
use Mt\School\Listeners\NotifierParentAbsence;
use Mt\School\Listeners\NotifierBulletinDisponible;
use Mt\School\Listeners\NotifierPaiementConfirme;
use Mt\School\Services\ReferenceSchoolService;
use Mt\School\Services\BulletinService;
use Mt\School\Services\MoyenneService;
use Mt\School\Support\AnneeScolaireResolver;

class MtSchoolCoreServiceProvider extends ServiceProvider
{
    /**
     * Chemin racine du package.
     */
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        $this->basePath = dirname(__DIR__);
    }

    // =========================================================================
    // REGISTER
    // =========================================================================

    public function register(): void
    {
        // ── Config ────────────────────────────────────────────────────────────
        $this->mergeConfigFrom(
            $this->basePath . '/config/mtschool.php',
            'mtschool'
        );

        // ── Singletons ────────────────────────────────────────────────────────

        /**
         * Résoluteur de l'année scolaire active.
         * Usage : app(AnneeScolaireResolver::class)->courante()
         */
        $this->app->singleton(AnneeScolaireResolver::class, function ($app) {
            return new AnneeScolaireResolver();
        });

        /**
         * Service de génération de références uniques (INS-2024-00001, PAY-…, BUL-…).
         */
        $this->app->singleton(ReferenceSchoolService::class, function ($app) {
            return new ReferenceSchoolService();
        });

        /**
         * Service de calcul des moyennes.
         */
        $this->app->singleton(MoyenneService::class, function ($app) {
            return new MoyenneService();
        });

        /**
         * Service de génération et publication des bulletins.
         */
        $this->app->singleton(BulletinService::class, function ($app) {
            return new BulletinService(
                $app->make(MoyenneService::class)
            );
        });

        // ── Alias de façades ──────────────────────────────────────────────────
        $this->app->alias(AnneeScolaireResolver::class, 'mt-school.annee');
        $this->app->alias(MoyenneService::class, 'mt-school.moyennes');
        $this->app->alias(BulletinService::class, 'mt-school.bulletins');
    }

    // =========================================================================
    // BOOT
    // =========================================================================

    public function boot(): void
    {
        // Ordre important : helpers → config → migrations → vues →
        //                  composants → traductions → assets →
        //                  livewire → events → morph map → publishing

        $this->loadHelpers();
        $this->loadMigrations();
        $this->loadViews();
        $this->loadTranslations();
        $this->registerBladeComponents();
        $this->registerBladeDirectives();
        $this->registerLivewireComponents();
        $this->registerEvents();
        $this->registerMorphMap();
        $this->registerPublishing();
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    protected function loadHelpers(): void
    {
        $helper = $this->basePath . '/src/Helpers/helpers.php';
        if (file_exists($helper)) {
            require_once $helper;
        }
    }

    // =========================================================================
    // MIGRATIONS
    // =========================================================================

    protected function loadMigrations(): void
    {
        if (is_dir($this->basePath . '/database/migrations')) {
            $this->loadMigrationsFrom($this->basePath . '/database/migrations');
        }
    }

    // =========================================================================
    // VUES — namespace 'mtschool'
    // =========================================================================

    protected function loadViews(): void
    {
        $viewsPath = $this->basePath . '/resources/views';

        if (is_dir($viewsPath)) {
            // Namespace Blade pour @include('mtschool::...') et @extends('mtschool::...')
            $this->loadViewsFrom($viewsPath, 'mtschool');
        }
    }

    // =========================================================================
    // TRADUCTIONS — namespace 'mtschool'
    // =========================================================================

    protected function loadTranslations(): void
    {
        $langPath = $this->basePath . '/lang';

        if (is_dir($langPath)) {
            // Usage : __('mtschool::messages.inscription_validee')
            $this->loadTranslationsFrom($langPath, 'mtschool');
            $this->loadJsonTranslationsFrom($langPath);
        }
    }

    // =========================================================================
    // COMPOSANTS BLADE
    // =========================================================================

    protected function registerBladeComponents(): void
    {
        $viewsPath = $this->basePath . '/resources/views';

        // ── Composants anonymes ───────────────────────────────────────────────
        // Usage : <x-mtschool::card /> <x-mtschool::badge />
        if (is_dir($viewsPath . '/components')) {
            Blade::anonymousComponentPath(
                $viewsPath . '/components',
                'mtschool'
            );
        }

        // ── Composants de classe (si présents) ────────────────────────────────
        // Usage : <x-mtschool-bulletin /> → Maps vers Mt\School\Views\Components\Bulletin
        // Blade::componentNamespace('Mt\\School\\Views\\Components', 'mtschool');
    }

    // =========================================================================
    // DIRECTIVES BLADE
    // =========================================================================

    protected function registerBladeDirectives(): void
    {
        /**
         * @mtschoolAssets
         * Injecte les CSS/JS du package dans le layout.
         * Usage : @mtschoolAssets
         */
        Blade::directive('mtschoolAssets', function () {
            $css = asset('vendor/mt/school/css/mtschool.css');
            $js  = asset('vendor/mt/school/js/mtschool.js');
            return "
                <link rel='stylesheet' href='{$css}'>
                <script defer src='{$js}'></script>
            ";
        });

        /**
         * @mtschoolBulletinAssets
         * Assets spécifiques à l'impression des bulletins.
         */
        Blade::directive('mtschoolBulletinAssets', function () {
            $css = asset('vendor/mt/school/css/bulletin.css');
            return "<link rel='stylesheet' href='{$css}' media='print'>";
        });

        /**
         * @anneeActive
         * Affiche le libellé de l'année scolaire active.
         * Usage : @anneeActive
         */
        Blade::directive('anneeActive', function () {
            return "<?php echo e(app('mt-school.annee')->labelActif()); ?>";
        });

        /**
         * @school('nom')
         * Accède aux paramètres de l'établissement.
         * Usage : @school('nom') → "Lycée Bilingue de X"
         */
        Blade::directive('school', function (string $expression) {
            return "<?php echo e(config('mtschool.etablissement.' . {$expression})); ?>";
        });

        /**
         * @multilingualEnabled
         * Bloc conditionnel si le multilinguisme est activé.
         * Usage : @multilingualEnabled ... @endmultilingualEnabled
         */
        Blade::if('multilingualEnabled', function () {
            return config('mtschool.multilingual.enabled', false);
        });

        /**
         * @moduleEnabled('finances')
         * Bloc conditionnel selon les modules activés.
         * Usage : @moduleEnabled('finances') ... @endmoduleEnabled
         */
        Blade::if('moduleEnabled', function (string $module) {
            return config("mtschool.{$module}.enabled", true);
        });
    }

    // =========================================================================
    // COMPOSANTS LIVEWIRE 3+
    // Préfixe commun : mtschool.
    // Convention nommage : mtschool.{domaine}.{composant}
    // =========================================================================

    protected function registerLivewireComponents(): void
    {
        // ── ADMINISTRATION — Années & Périodes ────────────────────────────────
        Livewire::component('mtschool.admin.annees.index',   \Mt\School\Livewire\Admin\Annees\Index::class);
        Livewire::component('mtschool.admin.annees.form',    \Mt\School\Livewire\Admin\Annees\Form::class);
        Livewire::component('mtschool.admin.periodes.index', \Mt\School\Livewire\Admin\Periodes\Index::class);
        Livewire::component('mtschool.admin.periodes.form',  \Mt\School\Livewire\Admin\Periodes\Form::class);

        // ── ADMINISTRATION — Structure académique ─────────────────────────────
        Livewire::component('mtschool.admin.cycles.index',   \Mt\School\Livewire\Admin\Cycles\Index::class);
        Livewire::component('mtschool.admin.cycles.form',    \Mt\School\Livewire\Admin\Cycles\Form::class);
        Livewire::component('mtschool.admin.niveaux.index',  \Mt\School\Livewire\Admin\Niveaux\Index::class);
        Livewire::component('mtschool.admin.niveaux.form',   \Mt\School\Livewire\Admin\Niveaux\Form::class);
        Livewire::component('mtschool.admin.filieres.index', \Mt\School\Livewire\Admin\Filieres\Index::class);
        Livewire::component('mtschool.admin.filieres.form',  \Mt\School\Livewire\Admin\Filieres\Form::class);

        // ── ADMINISTRATION — Infrastructure ───────────────────────────────────
        Livewire::component('mtschool.admin.salles.index',   \Mt\School\Livewire\Admin\Salles\Index::class);
        Livewire::component('mtschool.admin.salles.form',    \Mt\School\Livewire\Admin\Salles\Form::class);

        // ── ADMINISTRATION — Classes ──────────────────────────────────────────
        Livewire::component('mtschool.admin.classes.index',  \Mt\School\Livewire\Admin\Classes\Index::class);
        Livewire::component('mtschool.admin.classes.form',   \Mt\School\Livewire\Admin\Classes\Form::class);
        Livewire::component('mtschool.admin.classes.show',   \Mt\School\Livewire\Admin\Classes\Show::class);

        // ── ADMINISTRATION — Matières & Programmes ────────────────────────────
        Livewire::component('mtschool.admin.matieres.index',    \Mt\School\Livewire\Admin\Matieres\Index::class);
        Livewire::component('mtschool.admin.matieres.form',     \Mt\School\Livewire\Admin\Matieres\Form::class);
        Livewire::component('mtschool.admin.programmes.index',  \Mt\School\Livewire\Admin\Programmes\Index::class);
        Livewire::component('mtschool.admin.programmes.form',   \Mt\School\Livewire\Admin\Programmes\Form::class);

        // ── ADMINISTRATION — Personnel & Enseignants ──────────────────────────
        Livewire::component('mtschool.admin.personnels.index',      \Mt\School\Livewire\Admin\Personnels\Index::class);
        Livewire::component('mtschool.admin.personnels.form',       \Mt\School\Livewire\Admin\Personnels\Form::class);
        Livewire::component('mtschool.admin.personnels.show',       \Mt\School\Livewire\Admin\Personnels\Show::class);
        Livewire::component('mtschool.admin.enseignants.index',     \Mt\School\Livewire\Admin\Enseignants\Index::class);
        Livewire::component('mtschool.admin.enseignants.form',      \Mt\School\Livewire\Admin\Enseignants\Form::class);
        Livewire::component('mtschool.admin.attributions.index',    \Mt\School\Livewire\Admin\Attributions\Index::class);
        Livewire::component('mtschool.admin.attributions.form',     \Mt\School\Livewire\Admin\Attributions\Form::class);

        // ── ADMINISTRATION — Élèves & Parents ─────────────────────────────────
        Livewire::component('mtschool.admin.eleves.index', \Mt\School\Livewire\Admin\Eleves\Index::class);
        Livewire::component('mtschool.admin.eleves.form',  \Mt\School\Livewire\Admin\Eleves\Form::class);
        Livewire::component('mtschool.admin.eleves.show',  \Mt\School\Livewire\Admin\Eleves\Show::class);
        Livewire::component('mtschool.admin.parents.index',\Mt\School\Livewire\Admin\Parents\Index::class);
        Livewire::component('mtschool.admin.parents.form', \Mt\School\Livewire\Admin\Parents\Form::class);

        // ── ADMINISTRATION — Inscriptions ─────────────────────────────────────
        Livewire::component('mtschool.admin.inscriptions.index',    \Mt\School\Livewire\Admin\Inscriptions\Index::class);
        Livewire::component('mtschool.admin.inscriptions.form',     \Mt\School\Livewire\Admin\Inscriptions\Form::class);
        Livewire::component('mtschool.admin.inscriptions.show',     \Mt\School\Livewire\Admin\Inscriptions\Show::class);
        Livewire::component('mtschool.admin.inscriptions.valider',  \Mt\School\Livewire\Admin\Inscriptions\Valider::class);

        // ── ADMINISTRATION — Emploi du temps ──────────────────────────────────
        Livewire::component('mtschool.admin.edt.index',    \Mt\School\Livewire\Admin\Edt\Index::class);
        Livewire::component('mtschool.admin.edt.grille',   \Mt\School\Livewire\Admin\Edt\Grille::class);
        Livewire::component('mtschool.admin.edt.form',     \Mt\School\Livewire\Admin\Edt\Form::class);

        // ── ADMINISTRATION — Évaluations & Notes ──────────────────────────────
        Livewire::component('mtschool.admin.evaluations.index',  \Mt\School\Livewire\Admin\Evaluations\Index::class);
        Livewire::component('mtschool.admin.evaluations.form',   \Mt\School\Livewire\Admin\Evaluations\Form::class);
        Livewire::component('mtschool.admin.notes.saisie',       \Mt\School\Livewire\Admin\Notes\Saisie::class);
        Livewire::component('mtschool.admin.notes.validation',   \Mt\School\Livewire\Admin\Notes\Validation::class);

        // ── ADMINISTRATION — Résultats & Bulletins ────────────────────────────
        Livewire::component('mtschool.admin.resultats.index',       \Mt\School\Livewire\Admin\Resultats\Index::class);
        Livewire::component('mtschool.admin.resultats.calcul',      \Mt\School\Livewire\Admin\Resultats\Calcul::class);
        Livewire::component('mtschool.admin.bulletins.index',       \Mt\School\Livewire\Admin\Bulletins\Index::class);
        Livewire::component('mtschool.admin.bulletins.generateur',  \Mt\School\Livewire\Admin\Bulletins\Generateur::class);
        Livewire::component('mtschool.admin.bulletins.show',        \Mt\School\Livewire\Admin\Bulletins\Show::class);

        // ── ADMINISTRATION — Présences ─────────────────────────────────────────
        Livewire::component('mtschool.admin.presences.saisie',      \Mt\School\Livewire\Admin\Presences\Saisie::class);
        Livewire::component('mtschool.admin.presences.index',       \Mt\School\Livewire\Admin\Presences\Index::class);
        Livewire::component('mtschool.admin.presences.justifier',   \Mt\School\Livewire\Admin\Presences\Justifier::class);

        // ── ADMINISTRATION — Finances ─────────────────────────────────────────
        Livewire::component('mtschool.admin.frais.index',       \Mt\School\Livewire\Admin\Frais\Index::class);
        Livewire::component('mtschool.admin.frais.baremes',     \Mt\School\Livewire\Admin\Frais\Baremes::class);
        Livewire::component('mtschool.admin.paiements.index',   \Mt\School\Livewire\Admin\Paiements\Index::class);
        Livewire::component('mtschool.admin.paiements.form',    \Mt\School\Livewire\Admin\Paiements\Form::class);
        Livewire::component('mtschool.admin.paiements.recu',    \Mt\School\Livewire\Admin\Paiements\Recu::class);
        Livewire::component('mtschool.admin.bourses.index',     \Mt\School\Livewire\Admin\Bourses\Index::class);
        Livewire::component('mtschool.admin.bourses.form',      \Mt\School\Livewire\Admin\Bourses\Form::class);

        // ── ADMINISTRATION — Communication ────────────────────────────────────
        Livewire::component('mtschool.admin.annonces.index',  \Mt\School\Livewire\Admin\Annonces\Index::class);
        Livewire::component('mtschool.admin.annonces.form',   \Mt\School\Livewire\Admin\Annonces\Form::class);
        Livewire::component('mtschool.admin.agenda.index',    \Mt\School\Livewire\Admin\Agenda\Index::class);
        Livewire::component('mtschool.admin.agenda.form',     \Mt\School\Livewire\Admin\Agenda\Form::class);
        Livewire::component('mtschool.admin.messagerie.index',\Mt\School\Livewire\Admin\Messagerie\Index::class);
        Livewire::component('mtschool.admin.messagerie.thread',\Mt\School\Livewire\Admin\Messagerie\Thread::class);

        // ── ADMINISTRATION — Discipline ───────────────────────────────────────
        Livewire::component('mtschool.admin.sanctions.index',        \Mt\School\Livewire\Admin\Sanctions\Index::class);
        Livewire::component('mtschool.admin.sanctions.form',         \Mt\School\Livewire\Admin\Sanctions\Form::class);
        Livewire::component('mtschool.admin.conseils.index',         \Mt\School\Livewire\Admin\Conseils\Index::class);
        Livewire::component('mtschool.admin.conseils.form',          \Mt\School\Livewire\Admin\Conseils\Form::class);

        // ── ADMINISTRATION — Ressources & Devoirs ─────────────────────────────
        Livewire::component('mtschool.admin.ressources.index', \Mt\School\Livewire\Admin\Ressources\Index::class);
        Livewire::component('mtschool.admin.ressources.form',  \Mt\School\Livewire\Admin\Ressources\Form::class);
        Livewire::component('mtschool.admin.devoirs.index',    \Mt\School\Livewire\Admin\Devoirs\Index::class);
        Livewire::component('mtschool.admin.devoirs.form',     \Mt\School\Livewire\Admin\Devoirs\Form::class);
        Livewire::component('mtschool.admin.devoirs.corrections', \Mt\School\Livewire\Admin\Devoirs\Corrections::class);

        // ── ADMINISTRATION — Certificats ──────────────────────────────────────
        Livewire::component('mtschool.admin.certificats.index',  \Mt\School\Livewire\Admin\Certificats\Index::class);
        Livewire::component('mtschool.admin.certificats.form',   \Mt\School\Livewire\Admin\Certificats\Form::class);

        // ── ADMINISTRATION — Paramètres & Imports ─────────────────────────────
        Livewire::component('mtschool.admin.parametres.index',   \Mt\School\Livewire\Admin\Parametres\Index::class);
        Livewire::component('mtschool.admin.imports.index',      \Mt\School\Livewire\Admin\Imports\Index::class);
        Livewire::component('mtschool.admin.imports.eleves',     \Mt\School\Livewire\Admin\Imports\Eleves::class);
        Livewire::component('mtschool.admin.imports.notes',      \Mt\School\Livewire\Admin\Imports\Notes::class);

        // ── DASHBOARDS ────────────────────────────────────────────────────────
        Livewire::component('mtschool.dashboard.admin',      \Mt\School\Livewire\Dashboard\Admin::class);
        Livewire::component('mtschool.dashboard.enseignant', \Mt\School\Livewire\Dashboard\Enseignant::class);
        Livewire::component('mtschool.dashboard.eleve',      \Mt\School\Livewire\Dashboard\Eleve::class);
        Livewire::component('mtschool.dashboard.parent',     \Mt\School\Livewire\Dashboard\Parent::class);

        // ── PORTAIL ENSEIGNANT ────────────────────────────────────────────────
        Livewire::component('mtschool.enseignant.mes-classes',   \Mt\School\Livewire\Enseignant\MesClasses::class);
        Livewire::component('mtschool.enseignant.saisie-notes',  \Mt\School\Livewire\Enseignant\SaisieNotes::class);
        Livewire::component('mtschool.enseignant.presences',     \Mt\School\Livewire\Enseignant\Presences::class);
        Livewire::component('mtschool.enseignant.devoirs',       \Mt\School\Livewire\Enseignant\Devoirs::class);
        Livewire::component('mtschool.enseignant.ressources',    \Mt\School\Livewire\Enseignant\Ressources::class);
        Livewire::component('mtschool.enseignant.edt',           \Mt\School\Livewire\Enseignant\Edt::class);

        // ── PORTAIL ÉLÈVE ─────────────────────────────────────────────────────
        Livewire::component('mtschool.eleve.mes-notes',      \Mt\School\Livewire\Eleve\MesNotes::class);
        Livewire::component('mtschool.eleve.mes-bulletins',  \Mt\School\Livewire\Eleve\MesBulletins::class);
        Livewire::component('mtschool.eleve.mon-edt',        \Mt\School\Livewire\Eleve\MonEdt::class);
        Livewire::component('mtschool.eleve.mes-devoirs',    \Mt\School\Livewire\Eleve\MesDevoirs::class);
        Livewire::component('mtschool.eleve.mes-ressources', \Mt\School\Livewire\Eleve\MesRessources::class);
        Livewire::component('mtschool.eleve.mes-absences',   \Mt\School\Livewire\Eleve\MesAbsences::class);
        Livewire::component('mtschool.eleve.mes-frais',      \Mt\School\Livewire\Eleve\MesFrais::class);

        // ── PORTAIL PARENT ────────────────────────────────────────────────────
        Livewire::component('mtschool.parent.mes-enfants',   \Mt\School\Livewire\Parent\MesEnfants::class);
        Livewire::component('mtschool.parent.suivi',         \Mt\School\Livewire\Parent\Suivi::class);
        Livewire::component('mtschool.parent.bulletins',     \Mt\School\Livewire\Parent\Bulletins::class);
        Livewire::component('mtschool.parent.paiements',     \Mt\School\Livewire\Parent\Paiements::class);
        Livewire::component('mtschool.parent.justifier',     \Mt\School\Livewire\Parent\Justifier::class);
        Livewire::component('mtschool.parent.messagerie',    \Mt\School\Livewire\Parent\Messagerie::class);

        // ── COMPOSANTS PARTAGÉS (shared) ──────────────────────────────────────
        Livewire::component('mtschool.shared.notifications',     \Mt\School\Livewire\Shared\Notifications::class);
        Livewire::component('mtschool.shared.annonces',          \Mt\School\Livewire\Shared\Annonces::class);
        Livewire::component('mtschool.shared.agenda',            \Mt\School\Livewire\Shared\Agenda::class);
        Livewire::component('mtschool.shared.messagerie',        \Mt\School\Livewire\Shared\Messagerie::class);
        Livewire::component('mtschool.shared.locale-switcher',   \Mt\School\Livewire\Shared\LocaleSwitcher::class);
    }

    // =========================================================================
    // EVENTS & LISTENERS
    // =========================================================================

    protected function registerEvents(): void
    {
        // Inscription validée → recalculer l'effectif de la classe
        Event::listen(InscriptionValidee::class, RecalculerEffectifClasse::class);

        // Absence enregistrée → notifier le parent (si activé)
        Event::listen(AbsenceEnregistree::class, NotifierParentAbsence::class);

        // Bulletin publié → notifier l'élève/parent
        Event::listen(BulletinPublie::class, NotifierBulletinDisponible::class);

        // Paiement reçu → notifier la famille
        Event::listen(PaiementRecu::class, NotifierPaiementConfirme::class);
    }

    // =========================================================================
    // MORPH MAP — évite les FQCN en base de données
    // =========================================================================

    protected function registerMorphMap(): void
    {
        /*
         * Cartographie des modèles morphables.
         * Permet d'utiliser 'Eleve' au lieu de 'Mt\School\Models\Eleve'
         * dans les colonnes *_type (ex: userable_type, notifiable_type).
         */
        Relation::morphMap([
            // Acteurs principaux (morphable via users.userable_*)
            'eleve'          => \Mt\School\Models\Eleve::class,
            'parent_tuteur'  => \Mt\School\Models\ParentTuteur::class,
            'personnel'      => \Mt\School\Models\Personnel::class,
            'enseignant'     => \Mt\School\Models\Enseignant::class,

            // Entités notifiables (notifiable_type)
            'inscription'    => \Mt\School\Models\Inscription::class,
            'bulletin'       => \Mt\School\Models\Bulletin::class,
            'paiement'       => \Mt\School\Models\Paiement::class,
            'evaluation'     => \Mt\School\Models\Evaluation::class,
            'devoir_maison'  => \Mt\School\Models\DevoirMaison::class,
            'annonce'        => \Mt\School\Models\Annonce::class,

            // Stock matériel (beneficiaire_type)
            'classe'         => \Mt\School\Models\Classe::class,
            'salle'          => \Mt\School\Models\Salle::class,
        ], false); // false = merge sans enforcer (ne remplace pas l'app hôte)
    }

    // =========================================================================
    // PUBLISHING — artisan vendor:publish
    // =========================================================================

    protected function registerPublishing(): void
    {
        if (! $this->app->runningInConsole()) {
            return;
        }

        $basePath  = $this->basePath;
        $viewsPath = $basePath . '/resources/views';
        $langPath  = $basePath . '/lang';
        $publicPath= $basePath . '/public/assets';

        // ── Vues ──────────────────────────────────────────────────────────────
        $this->publishes([
            $viewsPath => resource_path('views/vendor/mt/school'),
        ], 'mtschool-views');

        // ── Traductions ───────────────────────────────────────────────────────
        $this->publishes([
            $langPath => $this->app->langPath('vendor/mt/school'),
        ], 'mtschool-lang');

        // ── Configuration ─────────────────────────────────────────────────────
        $this->publishes([
            $basePath . '/config/mtschool.php' => config_path('mtschool.php'),
        ], 'mtschool-config');

        // ── Assets (CSS / JS) ─────────────────────────────────────────────────
        if (is_dir($publicPath)) {
            $this->publishes([
                $publicPath => public_path('vendor/mt/school'),
            ], 'mtschool-assets');
        }

        // ── Migrations (publication manuelle si non auto-chargées) ────────────
        $this->publishes([
            $basePath . '/database/migrations' => database_path('migrations'),
        ], 'mtschool-migrations');

        // ── Tout publier d'un coup : php artisan vendor:publish --tag=mtschool ─
        $this->publishes([
            $viewsPath                          => resource_path('views/vendor/mt/school'),
            $langPath                           => $this->app->langPath('vendor/mt/school'),
            $basePath . '/config/mtschool.php'  => config_path('mtschool.php'),
            $publicPath                         => public_path('vendor/mt/school'),
        ], 'mtschool');
    }
}
