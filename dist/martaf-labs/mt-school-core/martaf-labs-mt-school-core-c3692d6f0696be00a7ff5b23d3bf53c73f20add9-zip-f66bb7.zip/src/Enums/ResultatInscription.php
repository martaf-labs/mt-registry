<?php

namespace Mt\School\Enums;

enum ResultatInscription: string
{
    case ADMIS      = 'admis';
    case REDOUBLE   = 'redouble';
    case ORIENTE    = 'oriente';
    case EXCLU      = 'exclu';
    case ABANDONNE  = 'abandonne';
    case TRANSFERE  = 'transfere';

    public function label(): string
    {
        return match ($this) {
            self::ADMIS     => 'Admis(e)',
            self::REDOUBLE  => 'Redoublant(e)',
            self::ORIENTE   => 'Orienté(e)',
            self::EXCLU     => 'Exclu(e)',
            self::ABANDONNE => 'Abandon',
            self::TRANSFERE => 'Transféré(e)',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::ADMIS     => 'success',
            self::REDOUBLE  => 'warning',
            self::ORIENTE   => 'info',
            self::EXCLU     => 'danger',
            self::ABANDONNE => 'secondary',
            self::TRANSFERE => 'primary',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
