<?php

namespace Mt\School\Enums;

enum TypeEvaluation: string
{
    case DEVOIR      = 'devoir';
    case EXAMEN      = 'examen';
    case CONTROLE    = 'controle';
    case TP          = 'tp';
    case ORAL        = 'oral';
    case PROJET      = 'projet';
    case DEVOIR_MAISON = 'devoir_maison';
    case AUTRE       = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::DEVOIR       => 'Devoir surveillé',
            self::EXAMEN       => 'Examen',
            self::CONTROLE     => 'Contrôle',
            self::TP           => 'Travaux pratiques',
            self::ORAL         => 'Oral',
            self::PROJET       => 'Projet',
            self::DEVOIR_MAISON => 'Devoir maison',
            self::AUTRE        => 'Autre',
        };
    }

    public function abreviation(): string
    {
        return match ($this) {
            self::DEVOIR       => 'DS',
            self::EXAMEN       => 'EX',
            self::CONTROLE     => 'CC',
            self::TP           => 'TP',
            self::ORAL         => 'OR',
            self::PROJET       => 'PJ',
            self::DEVOIR_MAISON => 'DM',
            self::AUTRE        => 'AU',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::DEVOIR       => 'primary',
            self::EXAMEN       => 'danger',
            self::CONTROLE     => 'warning',
            self::TP           => 'success',
            self::ORAL         => 'info',
            self::PROJET       => 'purple',
            self::DEVOIR_MAISON => 'secondary',
            self::AUTRE        => 'secondary',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
