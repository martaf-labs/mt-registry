<?php namespace Mt\School\Enums;

enum StatutFrais: string
{
    case EN_ATTENTE = 'en_attente';
    case PARTIEL    = 'partiel';
    case SOLDE      = 'solde';
    case EXONERE    = 'exonere';
    case ANNULE     = 'annule';

    public function label(): string
    {
        return match ($this) {
            self::EN_ATTENTE => 'En attente',
            self::PARTIEL    => 'Paiement partiel',
            self::SOLDE      => 'Soldé',
            self::EXONERE    => 'Exonéré',
            self::ANNULE     => 'Annulé',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::EN_ATTENTE => 'warning',
            self::PARTIEL    => 'info',
            self::SOLDE      => 'success',
            self::EXONERE    => 'secondary',
            self::ANNULE     => 'danger',
        };
    }

    public function estActif(): bool
    {
        return in_array($this, [self::EN_ATTENTE, self::PARTIEL]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
