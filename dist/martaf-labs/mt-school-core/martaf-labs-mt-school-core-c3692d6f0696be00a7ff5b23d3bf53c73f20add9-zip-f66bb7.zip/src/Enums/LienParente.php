<?php

namespace Mt\School\Enums;

enum LienParente: string
{
    case PERE        = 'pere';
    case MERE        = 'mere';
    case TUTEUR      = 'tuteur';
    case GRAND_PARENT = 'grand_parent';
    case FRERE_SOEUR = 'frere_soeur';
    case ONCLE_TANTE = 'oncle_tante';
    case AUTRE       = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::PERE        => 'Père',
            self::MERE        => 'Mère',
            self::TUTEUR      => 'Tuteur / Tutrice',
            self::GRAND_PARENT => 'Grand-parent',
            self::FRERE_SOEUR => 'Frère / Sœur',
            self::ONCLE_TANTE => 'Oncle / Tante',
            self::AUTRE       => 'Autre',
        };
    }

    public function estParentDirect(): bool
    {
        return in_array($this, [self::PERE, self::MERE]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
