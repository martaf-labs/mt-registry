<?php

namespace Mt\School\Enums;

enum StatutPresence: string
{
    case PRESENT   = 'present';
    case ABSENT    = 'absent';
    case RETARD    = 'retard';
    case EXCLUSION = 'exclusion';

    public function label(): string
    {
        return match ($this) {
            self::PRESENT   => 'Présent',
            self::ABSENT    => 'Absent',
            self::RETARD    => 'En retard',
            self::EXCLUSION => 'Exclusion',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::PRESENT   => 'success',
            self::ABSENT    => 'danger',
            self::RETARD    => 'warning',
            self::EXCLUSION => 'dark',
        };
    }

    public function icone(): string
    {
        return match ($this) {
            self::PRESENT   => 'fa-check-circle',
            self::ABSENT    => 'fa-times-circle',
            self::RETARD    => 'fa-clock',
            self::EXCLUSION => 'fa-ban',
        };
    }

    public function estAbsence(): bool
    {
        return in_array($this, [self::ABSENT, self::EXCLUSION]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
