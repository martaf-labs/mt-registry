<?php

namespace Mt\School\Enums;

enum StatutEvaluation: string
{
    case PLANIFIEE  = 'planifiee';
    case EN_COURS   = 'en_cours';
    case CORRIGEE   = 'corrigee';
    case SAISIE     = 'saisie';
    case VALIDEE    = 'validee';

    public function label(): string
    {
        return match ($this) {
            self::PLANIFIEE => 'Planifiée',
            self::EN_COURS  => 'En cours',
            self::CORRIGEE  => 'Corrigée',
            self::SAISIE    => 'Notes saisies',
            self::VALIDEE   => 'Validée',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::PLANIFIEE => 'secondary',
            self::EN_COURS  => 'warning',
            self::CORRIGEE  => 'info',
            self::SAISIE    => 'primary',
            self::VALIDEE   => 'success',
        };
    }

    public function estSaisie(): bool
    {
        return in_array($this, [self::SAISIE, self::VALIDEE]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
