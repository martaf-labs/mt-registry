<?php

namespace Mt\School\Enums;

enum TypeCycle: string
{
    case PRESCOLAIRE = 'prescolaire';
    case PRIMAIRE    = 'primaire';
    case SECONDAIRE  = 'secondaire';
    case SUPERIEUR   = 'superieur';

    public function label(): string
    {
        return match ($this) {
            self::PRESCOLAIRE => 'Préscolaire',
            self::PRIMAIRE    => 'Primaire',
            self::SECONDAIRE  => 'Secondaire',
            self::SUPERIEUR   => 'Supérieur',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::PRESCOLAIRE => 'pink',
            self::PRIMAIRE    => 'green',
            self::SECONDAIRE  => 'blue',
            self::SUPERIEUR   => 'purple',
        };
    }

    /** Ce cycle utilise-t-il le système LMD ? */
    public function estLmd(): bool
    {
        return $this === self::SUPERIEUR;
    }

    /** Ce cycle a-t-il des filières ? */
    public function aDesFilieres(): bool
    {
        return in_array($this, [self::SECONDAIRE, self::SUPERIEUR]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
