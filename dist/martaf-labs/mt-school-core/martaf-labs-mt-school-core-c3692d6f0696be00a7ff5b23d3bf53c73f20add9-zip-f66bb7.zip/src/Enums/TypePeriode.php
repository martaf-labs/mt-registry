<?php

namespace Mt\School\Enums;

enum TypePeriode: string
{
    case TRIMESTRE = 'trimestre';
    case SEMESTRE  = 'semestre';
    case SEQUENCE  = 'sequence';
    case ANNUEL    = 'annuel';
    case AUTRE     = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::TRIMESTRE => 'Trimestre',
            self::SEMESTRE  => 'Semestre',
            self::SEQUENCE  => 'Séquence',
            self::ANNUEL    => 'Annuel',
            self::AUTRE     => 'Autre',
        };
    }

    /** Une séquence est enfant d'un trimestre/semestre */
    public function estEnfant(): bool
    {
        return $this === self::SEQUENCE;
    }

    /** Peut contenir des séquences enfants */
    public function estParent(): bool
    {
        return in_array($this, [self::TRIMESTRE, self::SEMESTRE]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
