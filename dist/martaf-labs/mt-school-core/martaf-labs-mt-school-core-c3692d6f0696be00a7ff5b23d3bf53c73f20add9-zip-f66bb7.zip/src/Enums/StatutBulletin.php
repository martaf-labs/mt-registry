<?php

namespace Mt\School\Enums;

enum StatutBulletin: string
{
    case BROUILLON = 'brouillon';
    case GENERE    = 'genere';
    case VALIDE    = 'valide';
    case PUBLIE    = 'publie';
    case ARCHIVE   = 'archive';

    public function label(): string
    {
        return match ($this) {
            self::BROUILLON => 'Brouillon',
            self::GENERE    => 'Généré',
            self::VALIDE    => 'Validé',
            self::PUBLIE    => 'Publié',
            self::ARCHIVE   => 'Archivé',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::BROUILLON => 'secondary',
            self::GENERE    => 'info',
            self::VALIDE    => 'primary',
            self::PUBLIE    => 'success',
            self::ARCHIVE   => 'dark',
        };
    }

    public function estPubliable(): bool
    {
        return in_array($this, [self::VALIDE]);
    }

    public function estVisible(): bool
    {
        return in_array($this, [self::PUBLIE]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
