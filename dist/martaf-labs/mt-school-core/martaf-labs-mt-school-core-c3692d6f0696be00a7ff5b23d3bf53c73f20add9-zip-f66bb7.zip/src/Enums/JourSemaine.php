<?php namespace Mt\School\Enums;

enum JourSemaine: int
{
    case LUNDI    = 1;
    case MARDI    = 2;
    case MERCREDI = 3;
    case JEUDI    = 4;
    case VENDREDI = 5;
    case SAMEDI   = 6;
    case DIMANCHE = 7;

    public function label(): string
    {
        return match ($this) {
            self::LUNDI    => 'Lundi',
            self::MARDI    => 'Mardi',
            self::MERCREDI => 'Mercredi',
            self::JEUDI    => 'Jeudi',
            self::VENDREDI => 'Vendredi',
            self::SAMEDI   => 'Samedi',
            self::DIMANCHE => 'Dimanche',
        };
    }

    public function abreviation(): string
    {
        return match ($this) {
            self::LUNDI    => 'Lun',
            self::MARDI    => 'Mar',
            self::MERCREDI => 'Mer',
            self::JEUDI    => 'Jeu',
            self::VENDREDI => 'Ven',
            self::SAMEDI   => 'Sam',
            self::DIMANCHE => 'Dim',
        };
    }

    public function estWeekend(): bool
    {
        return in_array($this, [self::SAMEDI, self::DIMANCHE]);
    }

    public static function joursOuvrables(): array
    {
        return [self::LUNDI, self::MARDI, self::MERCREDI, self::JEUDI, self::VENDREDI];
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
