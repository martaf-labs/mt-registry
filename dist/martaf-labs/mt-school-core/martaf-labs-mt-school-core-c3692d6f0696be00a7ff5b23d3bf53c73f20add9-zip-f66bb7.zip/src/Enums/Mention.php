<?php namespace Mt\School\Enums;

enum Mention: string
{
    case EXCELLENT   = 'Excellent';
    case TRES_BIEN   = 'Très Bien';
    case BIEN        = 'Bien';
    case ASSEZ_BIEN  = 'Assez Bien';
    case PASSABLE    = 'Passable';
    case INSUFFISANT = 'Insuffisant';

    public function label(): string { return $this->value; }

    public function badge(): string
    {
        return match ($this) {
            self::EXCELLENT   => 'success',
            self::TRES_BIEN   => 'primary',
            self::BIEN        => 'info',
            self::ASSEZ_BIEN  => 'warning',
            self::PASSABLE    => 'orange',
            self::INSUFFISANT => 'danger',
        };
    }

    public function seuilMin(): float
    {
        return match ($this) {
            self::EXCELLENT   => 18.0,
            self::TRES_BIEN   => 16.0,
            self::BIEN        => 14.0,
            self::ASSEZ_BIEN  => 12.0,
            self::PASSABLE    => 10.0,
            self::INSUFFISANT => 0.0,
        };
    }

    public static function fromMoyenne(float $moyenne): self
    {
        return match (true) {
            $moyenne >= 18 => self::EXCELLENT,
            $moyenne >= 16 => self::TRES_BIEN,
            $moyenne >= 14 => self::BIEN,
            $moyenne >= 12 => self::ASSEZ_BIEN,
            $moyenne >= 10 => self::PASSABLE,
            default        => self::INSUFFISANT,
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
