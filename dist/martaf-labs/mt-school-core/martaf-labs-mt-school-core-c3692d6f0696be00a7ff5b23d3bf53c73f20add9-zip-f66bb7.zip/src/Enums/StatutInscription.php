<?php

namespace Mt\School\Enums;

enum StatutInscription: string
{
    case EN_ATTENTE  = 'en_attente';
    case VALIDEE     = 'validee';
    case REJETEE     = 'rejetee';
    case ANNULEE     = 'annulee';
    case TRANSFEREE  = 'transferee';

    public function label(): string
    {
        return match ($this) {
            self::EN_ATTENTE => 'En attente',
            self::VALIDEE    => 'Validée',
            self::REJETEE    => 'Rejetée',
            self::ANNULEE    => 'Annulée',
            self::TRANSFEREE => 'Transférée',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::EN_ATTENTE => 'warning',
            self::VALIDEE    => 'success',
            self::REJETEE    => 'danger',
            self::ANNULEE    => 'secondary',
            self::TRANSFEREE => 'info',
        };
    }

    public function couleur(): string
    {
        return match ($this) {
            self::EN_ATTENTE => '#f59e0b',
            self::VALIDEE    => '#10b981',
            self::REJETEE    => '#ef4444',
            self::ANNULEE    => '#6b7280',
            self::TRANSFEREE => '#3b82f6',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
