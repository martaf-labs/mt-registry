<?php

namespace Mt\School\Enums;

enum GroupeDisciplinaire: string
{
    case LITTERAIRE   = 'litteraire';
    case SCIENTIFIQUE = 'scientifique';
    case TECHNIQUE    = 'technique';
    case SPORTIF      = 'sportif';
    case ARTISTIQUE   = 'artistique';
    case LANGUE       = 'langue';
    case AUTRE        = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::LITTERAIRE   => 'Littéraire',
            self::SCIENTIFIQUE => 'Scientifique',
            self::TECHNIQUE    => 'Technique',
            self::SPORTIF      => 'Sportif',
            self::ARTISTIQUE   => 'Artistique',
            self::LANGUE       => 'Langue',
            self::AUTRE        => 'Autre',
        };
    }

    public function couleur(): string
    {
        return match ($this) {
            self::LITTERAIRE   => '#8b5cf6',
            self::SCIENTIFIQUE => '#3b82f6',
            self::TECHNIQUE    => '#f59e0b',
            self::SPORTIF      => '#10b981',
            self::ARTISTIQUE   => '#ec4899',
            self::LANGUE       => '#06b6d4',
            self::AUTRE        => '#6b7280',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
