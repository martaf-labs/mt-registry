<?php namespace Mt\School\Enums;

enum TypeCreneau: string
{
    case COURS       = 'cours';
    case TD          = 'td';
    case TP          = 'tp';
    case EXAMEN      = 'examen';
    case PERMANENCE  = 'permanence';
    case PAUSE       = 'pause';
    case AUTRE       = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::COURS      => 'Cours',
            self::TD         => 'Travaux dirigés',
            self::TP         => 'Travaux pratiques',
            self::EXAMEN     => 'Examen',
            self::PERMANENCE => 'Permanence',
            self::PAUSE      => 'Pause / Récréation',
            self::AUTRE      => 'Autre',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::COURS      => 'primary',
            self::TD         => 'info',
            self::TP         => 'success',
            self::EXAMEN     => 'danger',
            self::PERMANENCE => 'warning',
            self::PAUSE      => 'light',
            self::AUTRE      => 'secondary',
        };
    }

    public function estCours(): bool
    {
        return in_array($this, [self::COURS, self::TD, self::TP]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
