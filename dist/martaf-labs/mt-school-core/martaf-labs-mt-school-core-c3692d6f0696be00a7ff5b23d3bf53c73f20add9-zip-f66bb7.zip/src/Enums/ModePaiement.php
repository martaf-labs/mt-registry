<?php

namespace Mt\School\Enums;

enum ModePaiement: string
{
    case ESPECE       = 'espece';
    case VIREMENT     = 'virement';
    case CHEQUE       = 'cheque';
    case MOBILE_MONEY = 'mobile_money';
    case CARTE        = 'carte';
    case AUTRE        = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::ESPECE       => 'Espèces',
            self::VIREMENT     => 'Virement bancaire',
            self::CHEQUE       => 'Chèque',
            self::MOBILE_MONEY => 'Mobile Money',
            self::CARTE        => 'Carte bancaire',
            self::AUTRE        => 'Autre',
        };
    }

    public function icone(): string
    {
        return match ($this) {
            self::ESPECE       => 'fa-money-bill',
            self::VIREMENT     => 'fa-university',
            self::CHEQUE       => 'fa-file-invoice',
            self::MOBILE_MONEY => 'fa-mobile-alt',
            self::CARTE        => 'fa-credit-card',
            self::AUTRE        => 'fa-ellipsis-h',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
