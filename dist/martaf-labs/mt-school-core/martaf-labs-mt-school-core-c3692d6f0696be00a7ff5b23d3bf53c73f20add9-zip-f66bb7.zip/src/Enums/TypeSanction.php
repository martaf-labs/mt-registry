<?php namespace Mt\School\Enums;

enum TypeSanction: string
{
    case AVERTISSEMENT       = 'avertissement';
    case BLAME               = 'blame';
    case EXCLUSION_TEMP      = 'exclusion_temp';
    case EXCLUSION_DEF       = 'exclusion_def';
    case PUNITION            = 'punition';
    case CONVOCATION_PARENT  = 'convocation_parent';
    case AUTRE               = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::AVERTISSEMENT      => 'Avertissement',
            self::BLAME              => 'Blâme',
            self::EXCLUSION_TEMP     => 'Exclusion temporaire',
            self::EXCLUSION_DEF      => 'Exclusion définitive',
            self::PUNITION           => 'Punition',
            self::CONVOCATION_PARENT => 'Convocation des parents',
            self::AUTRE              => 'Autre',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::AVERTISSEMENT      => 'warning',
            self::BLAME              => 'orange',
            self::EXCLUSION_TEMP     => 'danger',
            self::EXCLUSION_DEF      => 'dark',
            self::PUNITION           => 'secondary',
            self::CONVOCATION_PARENT => 'info',
            self::AUTRE              => 'light',
        };
    }

    public function estGrave(): bool
    {
        return in_array($this, [self::EXCLUSION_TEMP, self::EXCLUSION_DEF]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
