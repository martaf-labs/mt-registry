<?php

namespace Mt\School\Enums;

enum StatutContrat: string
{
    case TITULAIRE   = 'titulaire';
    case VACATAIRE   = 'vacataire';
    case CONTRACTUEL = 'contractuel';
    case STAGIAIRE   = 'stagiaire';
    case BENEVOLE    = 'benevole';

    public function label(): string
    {
        return match ($this) {
            self::TITULAIRE   => 'Titulaire',
            self::VACATAIRE   => 'Vacataire',
            self::CONTRACTUEL => 'Contractuel',
            self::STAGIAIRE   => 'Stagiaire',
            self::BENEVOLE    => 'Bénévole',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::TITULAIRE   => 'success',
            self::VACATAIRE   => 'warning',
            self::CONTRACTUEL => 'info',
            self::STAGIAIRE   => 'secondary',
            self::BENEVOLE    => 'light',
        };
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
