<?php

namespace Mt\School\Enums;

enum TypePersonnel: string
{
    case ENSEIGNANT    = 'enseignant';
    case ADMINISTRATIF = 'administratif';
    case TECHNIQUE     = 'technique';
    case DIRECTION     = 'direction';

    public function label(): string
    {
        return match ($this) {
            self::ENSEIGNANT    => 'Enseignant',
            self::ADMINISTRATIF => 'Administratif',
            self::TECHNIQUE     => 'Technique',
            self::DIRECTION     => 'Direction',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::ENSEIGNANT    => 'primary',
            self::ADMINISTRATIF => 'info',
            self::TECHNIQUE     => 'warning',
            self::DIRECTION     => 'success',
        };
    }

    public function estEnseignant(): bool
    {
        return $this === self::ENSEIGNANT;
    }

    public function estDirection(): bool
    {
        return $this === self::DIRECTION;
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
