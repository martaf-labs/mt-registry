<?php

namespace Mt\School\Enums;

enum RoleSchool: string
{
    case SUPER_ADMIN = 'super_admin';
    case DIRECTEUR   = 'directeur';
    case CENSEUR     = 'censeur';
    case COMPTABLE   = 'comptable';
    case ENSEIGNANT  = 'enseignant';
    case ELEVE       = 'eleve';
    case PARENT      = 'parent';
    case PERSONNEL   = 'personnel';

    public function label(): string
    {
        return match ($this) {
            self::SUPER_ADMIN => 'Super Administrateur',
            self::DIRECTEUR   => 'Directeur',
            self::CENSEUR     => 'Censeur / Proviseur adjoint',
            self::COMPTABLE   => 'Comptable',
            self::ENSEIGNANT  => 'Enseignant',
            self::ELEVE       => 'Élève / Étudiant',
            self::PARENT      => 'Parent / Tuteur',
            self::PERSONNEL   => 'Personnel',
        };
    }

    public function badge(): string
    {
        return match ($this) {
            self::SUPER_ADMIN => 'danger',
            self::DIRECTEUR   => 'dark',
            self::CENSEUR     => 'primary',
            self::COMPTABLE   => 'success',
            self::ENSEIGNANT  => 'info',
            self::ELEVE       => 'secondary',
            self::PARENT      => 'warning',
            self::PERSONNEL   => 'light',
        };
    }

    /** Niveaux d'accès pour la hiérarchie */
    public function niveau(): int
    {
        return match ($this) {
            self::SUPER_ADMIN => 10,
            self::DIRECTEUR   => 8,
            self::CENSEUR     => 7,
            self::COMPTABLE   => 5,
            self::ENSEIGNANT  => 4,
            self::PERSONNEL   => 3,
            self::PARENT      => 2,
            self::ELEVE       => 1,
        };
    }

    public function peutGererNotes(): bool
    {
        return in_array($this, [self::SUPER_ADMIN, self::DIRECTEUR, self::CENSEUR, self::ENSEIGNANT]);
    }

    public function peutVoirFinances(): bool
    {
        return in_array($this, [self::SUPER_ADMIN, self::DIRECTEUR, self::COMPTABLE]);
    }

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($c) => [$c->value => $c->label()])
            ->toArray();
    }
}
