@if (isset($model))

    @php
        //initialisation des variables
        $titre= $titre ?? '';
        $model= $model ?? '';
        $navItems = $navItems ?? null;
        $datas = $datas ?? [];
        $filtres = $filtres ?? [];
        $datafiltres = $datafiltres ?? [];
        $filterOptions = $filterOptions ?? [];
        $addButton= $addButton ?? false;
        $buttonRoute= isset($buttonRoute) ? $buttonRoute : null;
        $buttonLabel= isset($buttonLabel) ? $buttonLabel : null;
        $icone= getIcone($model);
        $optionsItems = $optionsItems ?? [];
        $displayView=$displayView?? 'list';  //le mode d'affichage: grid, list, detail

        //Si la table de donnees est vide, le bouton fixer d'ajout d'element ne s'affiche pas
        $addRoute= $addButton ? (is_null($buttonRoute) && (Route::has('admin.'.Str::plural($model).'.create')) ? getRoute(Str::plural($model).'_create'): $buttonRoute) : null;

        //reconfiguration du addButton si le label est fournit
        if ($addButton && !is_null($buttonLabel) && Str::length($buttonLabel) > 0) {
            $addRoute=[
                'route' => $addRoute,
                'label' => $buttonLabel,
            ];
        }

    @endphp
    <x-app-layout :titre="$titre" :icone="$icone" :addRoute="$addRoute" :navItems="$navItems" :optionsItems="$optionsItems" viewName="index">
        <div class="row row-cols-1">
            <div class="col">
                <x-section-page>

                    <div class="container-fluid p-2 bg-t-coul4 rounded-2">
                        @if (count($datas) <= 0)
                            <div class="container d-flex flex-column justify-content-center align-items-center px-2 py-4">
                                <span class="{{ $icone }} opacity-50" style="font-size: 500%"></span>
                                <p class="opacity-50">Aucun élément à afficher</p>
                                @if (isset($addRoute) && $addRoute != null)
                                    <a href="{{ $addRoute }}" class="btn-coul1 px-3 py-1 rounded-pill">
                                        <span class="bi bi-plus"></span>
                                        <span class="">Ajouter</span>
                                    </a> 
                                @endif
                            </div>                       
                        @else
                            {{-- <x-table :jsonParams="$jsonParams"></x-table> --}}
                            <x-filtre :filters="$filtres" :filterOptions="$filterOptions">
        
                                <!-- Conteneur des résultats filtrés, initialement vide -->
                                @php
                                    $rowCols=$displayView === 'grid'? 'row-cols-1 row-cols-lg-4' : 'row-cols-1 row-cols-lg-2';
                                @endphp
                                <div id="resultats" class="row {{ $rowCols }} px-2 mb-2" data-tab-datas='@json($datas)' data-tab-model='@json($model)' data-filtres='@json($datafiltres)' data-tab-display="{{ $displayView }}">
                                    <!--les elements du tableau generer par le js s'affichent ici-->
                                </div>
                            
                            
                            </x-filtre>
                        @endif
                    </div>
                </x-section-page>
            </div>
        </div>

    </x-app-layout>
@else

    {{-- rediriger vers la page d'accueil --}}
    <script>
        window.location.href="/";
    </script>

@endif

