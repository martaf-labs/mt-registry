@if (isset($model))

    @php
        //initialisation des variables
        $display= $display ?? '';
        $titre= $titre ?? '';
        $model= $model ?? '';
        $navItems = $navItems ?? null;
        $data = $data ?? [];
        $icone= getIcone($model);
        $optionsItems = $optionsItems ?? [];
        $addButton= $addButton ?? false;
        $buttonRoute= isset($buttonRoute) ? $buttonRoute : null;
        $buttonLabel= isset($buttonLabel) ? $buttonLabel : null;

        //variables utiles
        $titre=$data['titre']?? null;
        $titreLabel=$data['titreLabel']?? null;
        $image=$data['image']?? null;
        $images=$data['images']?? null;
        $details=$data['details']?? null;
        $subDatas=$data['subDatas']?? null;


        //Bouton d'ajout d'élément (optionnel)
        $addRoute= $addButton? (is_null($buttonRoute) && (Route::has('admin.'.Str::plural($model).'.create')) ? getRoute(Str::plural($model).'_create'): $buttonRoute) : null;

        //reconfiguration du addButton si le label est fournit
        if ($addButton && !is_null($buttonLabel) && Str::length($buttonLabel) > 0) {
            $addRoute=[
                'route' => $addRoute,
                'label' => $buttonLabel,
            ];
        }

    @endphp

    <x-app-layout :titre="$titre" :icone="$icone" :navItems="$navItems" :optionsItems="$optionsItems" :addRoute="$addRoute">
        <div class="container-fluid py-1 py-lg-3 my-0 my-lg-2">
            <div class="col-12 col-lg-8 py-2 px-0 px-lg-2">
                <h6 class="fg-coul1 fw-bold">{{ $titre }}</h6>
            </div>
            <div class="container-fluid py-1 py-lg-2 px-0 px-lg-2 fg-coul3-0 fs-90">
                <x-mt-table :headers="$subDatas['headers']" :rows="$subDatas['bodies'] ?? []" />
            </div>
        </div>
    </x-app-layout>

@else

    {{-- rediriger vers la page d'accueil --}}
    <script>
        window.location.href="/";
    </script>

@endif
