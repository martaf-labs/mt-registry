<!doctype html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Application de suivi de materiels de la société SGNI TCHAD">
        <meta name="author" content="Djoukeng Brice Marcello, debuté le 04 juin 2024 à 02h00, à kousseri">
        <meta name="generator" content="">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link rel="icon" type="image/png" href="{{ asset(config('app.favicon')) }}">

        <title>{{ strip_tags($titre?? 'mt-test') }}</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">


        <link href="{{ asset('vendor/mt/css/bootstrap.min.css') }}" rel="stylesheet">
        <link href="{{ asset('vendor/mt/bootstrap-icons-1.13.1/bootstrap-icons.min.css') }}" rel="stylesheet">
        <link href="{{ asset('vendor/mt/css/common.css') }}" rel="stylesheet">
        <link href="{{ asset('vendor/mt/css/app.css') }}" rel="stylesheet">
        <script src="{{ asset('vendor/mt/vendor/tinymce/js/tinymce/tinymce.min.js') }}"></script>
        <script src="{{ asset('vendor/mt/js/chart.umd.js') }}" defer></script>
        <script src="{{ asset('vendor/mt/js/common.js') }}" defer></script>

        <style>
            /* .dropdown:hover > .dropdown-menu{
                display:block;
            } */

        </style>

    </head>
    <body class="bg-t-coul1">

        <!--fixed button -->
        <div class="position-fixed bottom-0 end-0 mb-5 pb-4 pb-lg-3 me-4" style="z-index: 99;">

            @if(!is_null($addRoute?? null))

                @php
                    $route=is_array($addRoute)? $addRoute['route'] : $addRoute;
                    $label=is_array($addRoute)? $addRoute['label'] : 'Nouveau';
                @endphp

                <a href="{{ $route }}" class="btn-l-gradient-coul1 px-3 px-lg-3 py-2 py-lg-2 rounded-pill">
                    <span class="{{ getIcone('nouveau') }}"> {{ $label }}</span>
                    <span class="ms-1 d-inline-block"></span>
                </a>
            @endif

            @if(!is_null($editRoute?? null))

                @php
                    $route=is_array($editRoute)? $editRoute['route'] : $editRoute;
                    $label=is_array($editRoute)? $editRoute['label'] : 'Modifier';
                @endphp

                <a href="{{ $route }}" class="btn-l-gradient-coul1 px-3 px-lg-3 py-1 py-lg-2 rounded-pill">
                    <span class="{{ getIcone('modifier') }}"></span>
                    <span class="ms-1 d-inline-block"> {{ $label }}</span>
                </a>
            @endif
        </div>


        @php
        // dd(getSidebar());

            /**
             * Données de la sidebar
            */

            //additems
            $addItems=[
            ];
            
            $addItems = array_filter($addItems);

            $bottomBarItems=[
                // "menu"=>[
                //     "label"=>"Menu",
                //     "icon"=>"bi bi-list",
                //     "id"=>"menu",
                //     "route"=>"#",
                //     "subItems" => $sideBarItems
                // ], 
            ];

            $user=Auth::user();
        @endphp


        @php
            // les données de recherche
            $searchItems=[];

            // ajout des engins
            // $searchItems['engin']=[
            //     'position' => 'One',
            //     'label' => 'Engins',
            //     'datas' => [],
            // ];
            // foreach (App\Models\Engin::all() as $data) {
            //     $searchItems['engin']['datas'][]=[
            //         'titre' => $data->nom,
            //         'image' => $data->imageUrl(),
            //         'lien' => getRoute('engins_show',['engin' => $data->id]),
            //     ];
            // }
            
            //reformatage du tabeau
            $searchItems=array_values($searchItems);
            
        @endphp

        <!--header-->
        @include('mt::layouts.partials.app_header')

        <div class="row row-cols-1 row-cols-lg-2 p-0 m-0">
            <!--sidebar-->
            {{-- @include('mt::layouts.partials.sidebar') --}}

            {{-- insertion du composant de recherche --}}
            <x-mt::search-form id="recherche" :searchItems="$searchItems" display="center" searchButtonEnabled="true"></x-mt::search-form>

            {{-- insertion du composant de notifications --}}
            {{-- <x-mt::notifications-modal id="notifications" display="center" notificationButtonEnabled="true"></x-mt::notifications-modal> --}}

            <main class="col col-md-9 col-lg-10 ms-lg-auto px-0 px-lg-3">

                <div class="container-fluid mt-0 mt-lg-3 px-0 px-lg-3 py-1 py-lg-3 rounded-3 bg-coul4" style="min-height: 50vh; margin-bottom:70px; width:100%; overflow-x:hidden;">
                    
                    @if (isset($navItems) && count($navItems) > 0)
                        <div class="container-fluid d-none d-lg-flex flex-row flex-nowrap bg-white rounded-1 fs-80">

                            <div class="list-group list-group-horizontal d-flex justify-content-start">
                                {{-- <a href="javascript:window.history.back()" class="list-group-item list-group-item-action p-1 pe-0 border-0">
                                    <span class="{{ $icone }}">
                                </a> --}}
                                <span class="list-group-item p-1 ps-0 border-0 {{ $icone }}"></span>
                                @foreach ($navItems as $navItem)

                                    @if ($loop->index > 0)
                                        <span class="list-group-item py-1 px-0 border-0 bi bi-chevron-right"></span>
                                    @endif

                                    <a href="{{ $navItem['lien'] }}" class="list-group-item list-group-item-action rounded-pill w-auto p-1 border-0 @if($loop->first) fw-bold fg-coul3 @endif  @if(!$loop->last) fw-bold @endif @if($loop->last) disabled @endif">
                                        {{ Str::ucfirst(substr($navItem['label'], 0, 20)) }}@if(strlen($navItem['label'])>20)...@endif
                                    </a>

                                @endforeach
                            </div>
                            {{-- <a href="javascript:window.history.back()" class=" lnk-coul1 me-1"><span class="bi bi-arrow-left"></a> --}}
                            {{-- <h6 class="fw-bold fg-coul1 {{ $icone }}">&nbsp;{{ $titre }}</h6> --}}
                            <ol class="d-none ps-1 m-0 list-group-horizontal">
                                <li class="">
                                    <a href="javascript:window.history.back()" class=" lnk-coul1"><span class="bi bi-arrow-left"></a>
                                </li>
                                <li class="" aria-current="page">
                                    <a href="/" class=" lnk-coul1"><span class="bi bi-house"></a>
                                </li>
                                @foreach ($navItems as $navItem)
                                    <li class="breadcrumb-item">
                                        <a href="{{ $navItem['lien'] }}" class="lnk-coul1">{{ $navItem['label'] }}</a>
                                    </li> 
                                    {{-- @if ($loop->last)
                                        <span class="ms-1 fg-coul3">/</span>
                                    @endif --}}
                                    
                                @endforeach
                                

                            </ol>
                        </div>
                    @endif

                    @if(isset($viewName) && in_array($viewName,['index']))
                        <div class="container-fluid pt-3 my-0">
                            <h2 class="fw-bold text-linear-gradient-coul1">{{ $titre }}</h2>
                        </div>
                    @endif

                    {{-- {{ $slot }} --}}
                </div>
            </main>
        </div>


        <!--message-->
        @if (session('success') || session('error') || session('warning'))
            
            @if (session('success'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        createAlert({alertType : 'info', alertId : 'alertModal',alertTitle : "{{ (session('action')) }}",bodyContent : "{!! session('success') !!}",cancelBtnLabel : 'D\'accord'});
                    })
                </script>
            @endif   
            
            @if (session('error'))
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        createAlert({alertType : 'error', alertId : 'alertModal',alertTitle : "{{ (session('action')) }}",bodyContent : "{!! session('error') !!}",cancelBtnLabel : 'D\'accord'});
                    })
                </script>
            @endif
            
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    var alertModal=new bootstrap.Modal(document.getElementById('alertModal'));
                    alertModal.show();
                });
            </script>

        @endif   

        {{-- @php
            $unreadCount=count(auth()->user()->unreadNotifications);
        @endphp --}}

        {{-- <script>
            // Compteur des notifications non lues
            let previousUnreadCount = {{ $unreadCount ?? 0 }};

            // Func­tion d'affichage d'une notification
            function showNotification(data) {
                createNotification({ 
                    title: data.title,
                    message: data.message,
                    image: data.image || "{{ asset('vendor/mt/images/placeholder-image.jpg') }}",
                    time: `il y a ${data.time}`
                });
            }

            // Vérifier toutes les 10sec s'il y a une nouvelle notification
            async function checkNewNotifications() {
                try {
                    const res = await fetch('/api/notifications', { credentials: 'include' });
                    if (!res.ok) {
                        console.error('Erreur!', res.status);
                        return;
                    }
                    const data = await res.json();

                    // Filtrer toutes les notifications non lues
                    const unreadNotifications = data.notifications.filter(n => !n.read_at);

                    if (unreadNotifications.length > previousUnreadCount) {
                        // Nouvelle notification détectée
                        const newNotification = unreadNotifications[0]; // la plus récente non lue

                        showNotification({ 
                            title: newNotification.data.title,
                            message: newNotification.data.message,
                            time: tempsEcoule(newNotification.created_at),
                            image: newNotification.data.image
                        });

                        // Marquer la notification comme lue
                        await markAsReadNotifications([newNotification.id]);

                        // Mettre à jours le compteur
                        previousUnreadCount = unreadNotifications.length;
                    } 
                    // S'il est plus petit, quelques notifications ont été lues depuis
                    else if (unreadNotifications.length < previousUnreadCount) {
                        previousUnreadCount = unreadNotifications.length;
                    }
                } catch (error) {
                    console.error('Erreur!', error);
                }
            }

            // lancer toutes les 10sec
            setInterval(checkNewNotifications, 5000);
            // vérification initiale
            checkNewNotifications();

        </script> --}}

        {{-- <script>
            // interception des notifications non lues
            let notificationsBadge = document.querySelector('.notifications-badge');

            function refreshUnreadNotificationsCount(){
                fetch('/api/notifications/unread-count', {
                    credentials:'include',
                    headers: {
                        'Accept': 'application/json'
                    }
                })
                .then((response) => {
                    return response.json()
                })
                .then((data) => {
                    if (data && typeof data.unread_count !== "undefined") {
                        notificationsBadge.textContent = data.unread_count > 0 ? addZero(data.unread_count) : 0;
                    } else {
                        // console.error("Propriété unread_count manquante dans la réponse.");
                        notificationsBadge.textContent = 0;
                    }
                })
                .catch((error) => console.error(error));

            }

            // lancer toutes les 3sec et immédiatement
            setInterval(refreshUnreadNotificationsCount, 5000);
            refreshUnreadNotificationsCount();

        </script> --}}




        
        <script src="{{ asset('vendor/mt/js/bootstrap.bundle.min.js') }}"></script>
        {{-- <script src="{{ asset('vendor/mt/js/chart.js/chart.umd.js') }}"></script> --}}
        <script src="{{ asset('vendor/mt/js/app.js') }}"> defer</script>
        <!-- use xlsx.full.min.js from version 0.20.3 -->
        <script lang="javascript" src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>
    </body>
</html>
