<header id="header" class="flex-column justify-content-start align-items-center py-2 py-lg-2 px-2 px-lg-3 sticky-top">
    <div class="container-fluid d-flex flex-row flex-nowrap justify-content-between align-items-center p-0">

        <div class="d-flex flex-row flex-nowrap justify-content-start align-items-center">

            <button class="d-none px-0 bg-none border-0 fs-2 me-1" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                <x-mt::circle-item icone="bi bi-list" bg="bg-coul1-0" fg="fg-coul4"></x-mt::circle-item>
            </button>

            <a href="/" class="d-flex d-md-none align-items-center me-lg-auto text-white text-decoration-none text-center rounded-2">
                <img class="" src="{{ asset(config("app.logo")) }}" alt="logo {{ config("app.name") }}"  height="30" class="">
                <span class="fs-5 fg-coul1 fw-bold ms-2" translate="no">{{ config("app.name") }}</span>
            </a>

            <a href="/" class="d-none d-md-flex align-items-center me-lg-auto text-white text-decoration-none text-center rounded-2">
                <img class="" src="{{ asset(config("app.logo")) }}" alt="logo {{ config("app.name") }}"  height="45" class="">
                <span class="fs-5 fg-coul1 fw-bold ms-2" translate="no">{{ config("app.name") }}</span>
            </a>
        </div>

        <div class="d-flex flex-row flex-nowrap justify-content-end align-items-center"> 

            <a href="#recherche" class="mt-search-button">
                <x-mt::circle-item icone="{{ getIcone('recherche') }}" bg="bg-coul4" fg="fg-coul1"></x-mt::circle-item>
            </a>

            <a href="#notification" class="mt-notifications-button ms-2 position-relative">
                <x-mt::circle-item icone="{{ getIcone('notification') }}" bg="bg-coul4" fg="fg-coul1"></x-mt::circle-item>
                <span  class="notifications-badge bg-danger fg-coul4 px-1 fs-60 rounded-pill" style="position: absolute; top:0; right:0">
                    0
                </span>
            </a>

            <div class="dropdown ms-2"> 
                <a href="#" class="dropdown-toggle d-flex flex-row flex-nowrap justify-content-end align-items-center" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    @auth
                        <x-mt::circle-item image="{{ Auth::user()?->userable?->imageUrl() }}" bg="bg-coul4"></x-mt::circle-item>
                        <h4 class="fs-90 fg-coul3 ms-2 d-none d-lg-block lh-1">
                            {{ strlen(Auth::user()?->userable?->fullName()) > 15? substr(Auth::user()?->userable?->fullName(), 0, 15)."..." : Auth::user()?->userable?->fullName()}}
                            <span class="d-block fg-coul1 fs-70">{{ Str::ucfirst(Auth::user()?->role) }}</span>
                        </h4>
                    @endauth

                    @guest
                        <x-mt::circle-item icone="bi bi-person" bg="bg-coul4" fg="fg-coul1"></x-mt::circle-item>
                    @endguest
                </a>
                @php
                @endphp
                <ul class="dropdown-menu text-small">
                    <li>
                        <h4 class="dropdown-header fs-90">
                            {{ strlen(Auth::user()?->userable?->fullName()) > 15? substr(Auth::user()?->userable?->fullName(), 0, 15)."..." : Auth::user()?->userable?->fullName() }}
                            {{-- <span class="badge bg-coul1 fg-coul4">{{ Str::ucfirst(Auth::user()->role) }}</span> --}}
                        </h4>
                    </li>

                    <li><a class="dropdown-item fs-80" href="{{ getRoute('users_show',['user'=>Auth::user()?->id]) }}">Votre profile</a></li>
                    
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form action="{{ getRoute('logout') }}" method="post">
                            {{-- @method('delete') --}}
                            @csrf
                            <button class="dropdown-item fs-80">Déconnexion</button>
                        </form>    
                    </li>
                    
                </ul>
            </div>
        </div>
    </div>

</header>

<script>

    window.addEventListener('scroll',function(){
        const fixe_menu=document.getElementById('header');
        let optionClass=['bg-coul4', 'shadow-sm']
        if (window.scrollY >0) {

            optionClass.forEach(function(item){
                fixe_menu.classList.add(item)
            });

        } else {
            optionClass.forEach(function(item){
                fixe_menu.classList.remove(item)
            });
        }
    });
    
</script>
