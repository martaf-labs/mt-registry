
@props(['titre'=>'','icone'=>'','image'=>'','bg'=>'bg-coul1-0','fg'=>'fg-coul3','rounded'=>'rounded-circle'])
@php
    $width=$width?? null;
@endphp

<div class="d-flex d-lg-none flex-row flex-nowrap justify-content-start align-items-center">
    <div {{ $attributes->merge(['class' => '' , 'style' => is_null($width)? 'width:35px' : 'width:'.$width.'px']) }}>
        <div class="square {{ $bg }}  {{ $rounded }}">
            @if($icone != '')
                <span class="square-content {{ $rounded }} {{ $fg }} {{ $icone }}">
                </span>
            @endif
            @if($image != '')
                <span class="d-block square-content mtblock-sqr lazy-bg  {{ $rounded }}" data-bg="{{ $image }}"  style="background-attachment: scroll;background-position:top center; background-size:contain">
                </span>
            @endif
        </div>
    </div>
    @if($titre != '')
        <h6 class="ms-2 p-0 fw-bold {{ $fg }}"> {{ $titre }} </h6>
    @endif
</div>

<!--version lg-->
<div class="d-none d-lg-flex flex-row flex-nowrap justify-content-start align-items-center">
    <div {{ $attributes->merge(['class' => '' , 'style' => is_null($width)? 'width:45px' : 'width:'.$width.'px']) }}>
        <div class="square {{ $bg }}  {{ $rounded }}">
            @if($icone != '')
                <span class="square-content  {{ $rounded }} {{ $fg }} {{ $icone }}">
                </span>
            @endif
            @if($image != '')
                <span class="d-block square-content mtblock-sqr lazy-bg  {{ $rounded }}" data-bg="{{ $image }}"  style="background-attachment: scroll;background-position:top center; background-size:contain">
                </span>
            @endif
        </div>
    </div>
    @if($titre != '')
        <h4 class="ms-2 p-0 fw-bold {{ $fg }}"> {{ $titre }} </h4>
    @endif
</div>

