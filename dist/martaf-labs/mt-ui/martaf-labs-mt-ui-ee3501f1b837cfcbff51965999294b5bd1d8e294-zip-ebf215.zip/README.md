# PACKAGE mt-views,

initié le Mercredi 06 Août 2025, à N'Djaména
mt-views est un package Laravel destiné à centraliser toutes les vues Blade partagées utilisées dans plusieurs projets Laravel. Il inclut des layouts standards, des composants Blade personnalisés (alertes, boutons, modals…), des partials réutilisables (headers, footers, sidebars), et d'autres structures visuelles communes.

L'objectif est de faciliter la cohérence visuelle, d'accélérer le développement, et de maintenir un design unifié à travers tous les projets Laravel.

##   Pour versionner, c-a-d creer un tag git:
git tag -a v1.0.1 -m "Version 1.0.1 - premier release stable du package mt-views"
git push origin v1.0.1

## Pour recreer la version taguée:
git add .
git commit -m "Fix compatibility with Laravel 11 and 12"
git tag -a v1.0.2 -m "Compatible with Laravel 11 & 12"
git push origin v1.0.2

## pour supprimer un tag:
git tag -d 1.0.2
git push origin :refs/tags/1.0.2

## supprimer tous les tag en locaux  et distants:
#!/bin/bash

# Supprimer tous les tags locaux
git tag -l | xargs git tag -d

# Supprimer tous les tags distants
git tag -l | xargs git tag -d
git tag -l | xargs -n 1 git push --delete origin
echo "✅ Tous les tags locaux et distants ont été supprimés."

# Pour revenir à n'importe quelle version du package à tout momment
git checkout v1.0.1(version desirée)


################
##############-----------------[10-12-2025]---------#####################
# Migration vers la Version 2.0.1 du package
################

## Changement majeurs

1. Intégration de *Livewire 3*

```
"require": {
    "livewire/livewire": "^3.0"
}
```

## Etapes
1. Modification du fichier fichier *composer.json* dans le package pour définir la nouvelle

```
"version": "2.0.1",
```

2. Creation d'un tag Git pour la version 2.0.1

```
git add .
git commit -m "Version 2.0.1 - migration vers mt-views v2.0.1"
git tag v2.0.1

```