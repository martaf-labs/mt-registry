<?php

namespace Mt\MtViews;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class MtViewsServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any package services.
     */
    public function boot(): void
    {
        // Charger les vues avec un alias (namespace)
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'mt');

        // Rendre les assets (public) publiables
        $this->publishes([
            __DIR__.'/../public' => public_path('vendor/mt'),
        ], 'mt-assets');

        // Rendre les vues publiables
        $this->publishes([
            __DIR__.'/../resources/views' => $this->app->resourcePath('views/vendor/mt'),
        ], 'mt-views');

        // Déclarer le namespace pour les composants anonymes: pour que dans les projets, on ne soit pas obliger de faire x-mt-composant.
        Blade::anonymousComponentPath(__DIR__.'/../resources/views/components', 'mt');


        // (Optionnel) Charger des composants Blade si tu en as
        Blade::componentNamespace('MtViews\\View\\Components', 'mt');
        
        if (file_exists(__DIR__.'/helpers.php')) {
            require_once __DIR__.'/helpers.php';
        }

         // Charger tous les autres fichiers du dossier Helpers/
        // foreach (glob(__DIR__.'/Helpers/*.php') as $filename) {
        //     if (basename($filename) !== 'helpers.php') {
        //         require_once $filename;
        //     }
        // }
    }

    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }
}
