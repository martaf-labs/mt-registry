<?php

use Carbon\Carbon;
use App\Models\User;
use App\Models\Visite;
use Illuminate\Support\Str;
use Mt\MtViews\Helpers\NavHelper;
use Mt\MtViews\Helpers\ViewHelper;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use App\Notifications\HandleNotification;

/**
 * Layout actif
 */
if (!function_exists('getActiveLayout')) {
    function getActiveLayout() {
        return session('active_layout');
    }
}

/**
 * Niveau d'accès utilisateur
 */
if (!function_exists('get_access_level')) {
    function get_access_level() {
        $user = Auth::user();
        if (!$user) return 999;

        $roles = $user->roles;
        $levels = [];
        foreach ($roles as $role) {
            $levels[] = User::getAccessLevels()[$role->name] ?? 999;
        }
        return min($levels);
    }
}

if (!function_exists('has_access_level')) {
    function has_access_level($maxLevel) {
        return get_access_level() <= $maxLevel;
    }
}

if (!function_exists('has_role')) {
    function has_role(array $roles) {
        $user = Auth::user();
        if (!$user) return false;
        foreach ($roles as $role) {
            if ($user->hasRole($role)) return true;
        }
        return false;
    }
}

if (!function_exists('is_dev')) {
    function is_dev(): bool {
        return Auth::user()->hasRole(User::DEVELOPPEUR);
    }
}

if (!function_exists('is_admin')) {
    function is_admin(): bool {
        return Auth::user()->hasRole(User::ADMIN);
    }
}

if (!function_exists('can_access')) {
    function can_access($permission) {
        return auth()->check() && auth()->user()->hasPermissionTo($permission);
    }
}

/**
 * Gestion des viewItems
 */
if (!function_exists('viewItems')) {
    function viewItems(string $model, string $mainLabel): ViewHelper {
        return new ViewHelper($model, $mainLabel);
    }
}

/**
 * Gestion des navItems
 */
if (!function_exists('navItems')) {
    function navItems(string $model, string $mainLabel): NavHelper {
        return new NavHelper($model, $mainLabel);
    }
}

/**
 * Session formulaire
 */
if (!function_exists('formSession')) {
    function formSession(string $model) {
        return session("formSessionData.{$model}") ?? null;
    }
}

/**
 * Disque de stockage
 */
if (!function_exists('storage_disk')) {
    function getStorageDisk() {
        return config('app.storage_disk') ?? '';
    }
}

/**
 * Assets partagés
 */
if (!function_exists('mt_shared')) {
    function mt_shared($path = '') {
        return rtrim(config('app.mt_shared_url'), '/') . '/' . ltrim($path, '/');
    }
}

/**
 * Résolution de chaîne ou constante
 */
if (!function_exists('resolve_string')) {
    function resolve_string($code) {
        if (!str_contains($code, '::')) return $code;
        [$class, $const] = explode('::', $code);
        if (class_exists($class) && defined("{$class}::{$const}")) return constant("{$class}::{$const}");
        return $code;
    }
}

if (!function_exists('resolve_count')) {
    function resolve_count($code) {
        return eval("return $code;");
    }
}

/**
 * Sidebar
 */
if (!function_exists('getSidebar')) {
    function getSidebar(): array {
        $sideBarItems = config('sidebar');
        $currentUrl = request()->fullUrl();
        $activeKey = null;

        foreach ($sideBarItems as &$item) {
            $item['key'] = $item['key'] ?? Str::slug($item['label']);
            $item['icon'] = isset($item['icon']) ? getIcone($item['icon']) : null;
            $item['count'] = isset($item['count']) ? addZero(resolve_count($item['count'])) : null;
            $item['isActive'] = false;

            $itemParams = $item['params'] ?? [];
            foreach ($itemParams as $k => $v) if (str_contains($v, '::')) $itemParams[$k] = constant($v);

            if (isset($item['route'])) $item['route'] = getRoute($item['route'], $itemParams);

            if (!empty($item['route'])) {
                $currentPath = parse_url($currentUrl, PHP_URL_PATH);
                $itemPath = parse_url($item['route'], PHP_URL_PATH);
                if ($item['route'] === $currentUrl || $itemPath === $currentPath) {
                    $item['isActive'] = true;
                    $activeKey = $item['key'];
                }
            }

            if (!empty($item['subItems'])) {
                foreach ($item['subItems'] as &$sub) {
                    $sub['key'] = $sub['key'] ?? Str::slug($sub['label']);
                    $sub['icon'] = isset($sub['icon']) ? getIcone($sub['icon']) : null;
                    $sub['count'] = isset($sub['count']) ? addZero(resolve_count($sub['count'])) : null;
                    $sub['isActive'] = false;

                    $subParams = $sub['params'] ?? [];
                    foreach ($subParams as $k => $v) if (str_contains($v, '::')) $subParams[$k] = constant($v);

                    if (isset($sub['route'])) $sub['route'] = getRoute($sub['route'], $subParams);

                    if (!empty($sub['route']) && $sub['route'] === $currentUrl) {
                        $sub['isActive'] = true;
                        $item['isActive'] = true;
                        $activeKey = $sub['key'];
                    }
                }
            }
        }

        if ($activeKey) session(['active_sidebar_key' => $activeKey]);
        return $sideBarItems;
    }
}

/**
 * Icônes et routes
 */
if (!function_exists('getIcone')) {
    function getIcone(string $item) {
        return config('app.icones')[$item] ?? '';
    }
}

if (!function_exists('getRoute')) {
    function getRoute(string $item, array $parametres=[]): string {
        $route = config('routes.'.$item);
        if (!$route) throw new InvalidArgumentException("La route {$item} n'existe pas dans la configuration...");
        return route($route, $parametres);
    }
}

/**
 * Highlight texte
 */
if (!function_exists('markTerms')) {
    function markTerms(string $phrase='', string $expression='') {
        if (strlen($phrase) > 0 && strlen($expression) > 0) {
            return preg_replace_callback('/'.preg_quote($expression, '/').'/i', fn($matches) => '<mark>'.$matches[0].'</mark>', $phrase);
        }
        return '';
    }
}

/**
 * Vérification fichier
 */
if (!function_exists('fileExists')) {
    function fileExists(string $filePath) {
        return Storage::exists($filePath);
    }
}

/**
 * Notification
 */
if (!function_exists('notifier')) {
    function notifier($userIds, array $data) {
        $ids = is_array($userIds) ? $userIds : [$userIds];
        foreach ($ids as $id) {
            $user = User::find($id);
            if ($user) $user->notify(new HandleNotification(...$data));
        }
    }
}

/**
 * Format nombre
 */
if (!function_exists('addZero')) {
    function addZero($nbre): string {
        $nbre = (int)$nbre;
        if (0 < $nbre && $nbre < 10) return '0'.$nbre;
        if ($nbre < 1_000) return (string)$nbre;
        if ($nbre < 1_000_000) return round($nbre / 1_000, 1).'K';
        if ($nbre < 1_000_000_000) return round($nbre / 1_000_000, 1).'M';
        return round($nbre / 1_000_000_000, 1).'Md';
    }
}

/**
 * Vérification intervalle
 */
if (!function_exists('inRange')) {
    function inRange(int $val, int $min, int $max): int {
        return $val >= $min && $val <= $max;
    }
}

/**
 * Temps écoulé
 */
if (!function_exists('tempsEcoule')) {
    function tempsEcoule($debut, $fin = null, $abrege = false, $prefixe = false, $type = null) {
        try {
            $now = is_null($fin) ? Carbon::now() : Carbon::parse($fin);
            $debut = Carbon::parse($debut);
        } catch (\Exception $e) {
            return null;
        }

        $future = $debut->greaterThan($now);
        $ref1 = $future ? $now : $debut;
        $ref2 = $future ? $debut : $now;

        if ($type) {
            $type = strtolower($type);
            $val = 0;
            $label = '';

            switch ($type) {
                case 'seconde': case 's': $val = $ref1->diffInSeconds($ref2); $label = $abrege?'s':'seconde'.($val>1?'s':''); break;
                case 'minute': case 'min': $val = $ref1->diffInMinutes($ref2); $label = $abrege?'min':'minute'.($val>1?'s':''); break;
                case 'heure': case 'h': $val = $ref1->diffInHours($ref2); $label = $abrege?'h':'heure'.($val>1?'s':''); break;
                case 'jour': case 'j': $val = $ref1->diffInDays($ref2); $label = $abrege?'j':'jour'.($val>1?'s':''); break;
                case 'semaine': case 'sem': $val = floor($ref1->diffInDays($ref2)/7); $label = $abrege?'sem':'semaine'.($val>1?'s':''); break;
                case 'mois': $val = $ref1->diffInMonths($ref2); $label = 'mois'; break;
                case 'an': case 'annee': $val = $ref1->diffInYears($ref2); $label = $abrege?'an':'an'.($val>1?'s':''); break;
            }

            return ($prefixe ? ($future?'dans ':'il y a ') : '').addZero($val).' '.$label;
        }

        $diff = $ref1->diff($ref2);
        $joursTotal = $ref1->diffInDays($ref2);
        $semaines = floor($joursTotal / 7);
        $resteJours = $joursTotal % 7;
        $parts = [];

        if ($diff->y > 0) $parts[] = addZero($diff->y).' '.($abrege?'an':'an'.($diff->y>1?'s':''));
        if ($diff->m > 0) $parts[] = addZero($diff->m).' mois';
        if ($semaines > 0) $parts[] = addZero($semaines).' '.($abrege?'sem':'semaine'.($semaines>1?'s':''));
        if ($resteJours > 0) $parts[] = addZero($resteJours).' '.($abrege?'j':'jour'.($resteJours>1?'s':''));
        if ($diff->h>0 && empty($parts)) $parts[] = addZero($diff->h).' '.($abrege?'h':'heure'.($diff->h>1?'s':''));
        if ($diff->i>0 && empty($parts)) $parts[] = addZero($diff->i).' '.($abrege?'min':'minute'.($diff->i>1?'s':''));
        if ($diff->s>0 && empty($parts)) $parts[] = addZero($diff->s).' '.($abrege?'s':'seconde'.($diff->s>1?'s':''));

        $texte = implode(' et ', array_slice($parts,0,2));
        return $prefixe ? ($future?'dans '.$texte:'il y a '.$texte) : $texte;
    }
}
