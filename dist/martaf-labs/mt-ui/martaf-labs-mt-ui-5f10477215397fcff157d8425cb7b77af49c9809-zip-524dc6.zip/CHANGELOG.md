Le 20 Janvier 2026

Transformation du package "mt-ui" en un veritable "Squeletton-core" pour les projets Laravel



##############[03-02-2026]#####################

■ Ajouter ceci au niveau du fichier **tailwind.config.js** du projet qui utilise la package:

*dark: 'selector',* dans *export_default*

et ensuite dans *theme/extend*, ajoute les tableaux suivants

fontFamily: {
    sans: ['Figtree', ...defaultTheme.fontFamily.sans],
    heading: ['var(--font-mt-heading)', 'sans-serif'],
    body: ['var(--font-mt-body)', 'sans-serif'],
},
colors: {
    // On lie les couleurs Tailwind aux variables CSS de votre package "mt-ui"
    "mt-primary": 'rgb(var(--mt-primary) / <alpha-value>',
    'mt-bg': 'rgb(var(--mt-bg) / <alpha-value>)',
    'mt-text': 'rgb(var(--mt-text) / <alpha-value>)',
    'mt-secondary': 'rgb(var(--mt-secondary) / <alpha-value>)',
},



