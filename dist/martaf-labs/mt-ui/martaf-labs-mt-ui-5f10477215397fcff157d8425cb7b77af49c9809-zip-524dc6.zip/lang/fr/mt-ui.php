<?php

return [

    // Navigation & layout
    'menu'              => 'Menu',
    'more'              => 'Plus',
    'quick_actions'     => 'Actions rapides',
    'main_menu'         => 'Menu principal',
    'close'             => 'Fermer',
    'back'              => 'Retour',
    'back_to_site'      => 'Retour vers le site',
    'home'              => 'Accueil',
    'dashboard'         => 'Tableau de bord',
    'profile'           => 'Profil',
    'settings'          => 'Paramètres',
    'initial_setup'     => 'Configuration initiale',
    'logout'            => 'Se déconnecter',
    'logout_confirm_title' => 'Se déconnecter ?',
    'logout_confirm_text'  => 'Vous devrez vous reconnecter pour accéder à votre espace.',
    'delete_confirm'    => 'Voulez-vous vraiment supprimer cet élément ? Cette action est irréversible.',
    'delete_confirm_title' => 'Supprimer cet élément ?',
    'login'             => 'Se connecter',
    'login_title'          => 'Connexion',
    'login_subtitle'       => 'Entrez vos identifiants pour accéder à votre espace',
    'login_immersive_sub'  => 'Votre espace de gestion',

    // Recherche
    'search'            => 'Rechercher',
    'search_placeholder'=> 'Rechercher dans l\'application',
    'search_placeholder_examples' => 'Pages, commandes, contacts…',
    'search_shortcut'   => 'Ctrl+K',
    'no_results'        => 'Aucun résultat',
    'no_results_found'  => 'Aucun résultat trouvé',
    'search_history'    => 'Recherches récentes',
    'load_more'         => 'Voir plus',
    'results_count'     => ':count résultat(s)',

    // Notifications
    'notifications'         => 'Notifications',
    'notifications_short'   => 'Notifs',
    'no_notifications'      => 'Aucune notification',
    'no_notifications_yet'  => 'Aucune notification pour le moment.',
    'mark_all_read'         => 'Tout marquer comme lu',
    'read_all'              => 'Tout lire',
    'view_all_notifications'=> 'Voir toutes les notifications',

    // Formulaires
    'save'              => 'Enregistrer',
    'save_and_continue' => 'Enregistrer et continuer',
    'cancel'            => 'Annuler',
    'delete'            => 'Supprimer',
    'edit'              => 'Modifier',
    'create'            => 'Créer',
    'update'            => 'Mettre à jour',
    'confirm'           => 'Confirmer',
    'submit'            => 'Soumettre',
    'reset'             => 'Réinitialiser',
    'upload'            => 'Téléverser',
    'download'          => 'Télécharger',
    'select'            => 'Sélectionner',
    'select_all'        => 'Tout sélectionner',
    'deselect_all'      => 'Tout désélectionner',

    // Statuts & messages
    'loading'           => 'Chargement...',
    'saving'            => 'Enregistrement...',
    'saved'             => 'Enregistré avec succès',
    'deleted'           => 'Supprimé avec succès',
    'error'             => 'Une erreur est survenue',
    'success'           => 'Opération réussie',
    'warning'           => 'Attention',
    'info'              => 'Information',
    'confirm_delete'    => 'Voulez-vous vraiment supprimer cet élément ?',
    'action_irreversible' => 'Cette action est irréversible.',

    // Tableau / liste
    'no_data'           => 'Aucune donnée disponible',
    'per_page'          => 'Par page',
    'total'             => 'Total',
    'showing'           => 'Affichage de :from à :to sur :total entrées',
    'previous'          => 'Précédent',
    'next'              => 'Suivant',
    'first'             => 'Premier',
    'last'              => 'Dernier',

    // Langue
    'language'          => 'Langue',
    'change_language'   => 'Changer de langue',

    // Thème
    'theme'             => 'Thème',
    'light_mode'        => 'Mode clair',
    'dark_mode'         => 'Mode sombre',
    'system_mode'       => 'Système',
    'toggle_appearance' => 'Basculer l\'apparence',
    'toggle_theme'      => 'Basculer le thème',


    // Prérequis d'écran (composant prerequisite-gate)
    'prerequisites_title'    => 'Avant de continuer',
    'prerequisites_subtitle' => 'Cet écran a besoin de quelques éléments qui n\'existent pas encore.',
    'prerequisites_go'       => 'Y aller',

    // État vide (composant empty-state)
    'empty_state_title' => 'Aucune donnée pour le moment',
    'index_empty_title' => 'Aucun élément trouvé',
    'index_empty_hint'  => 'Modifiez vos critères de recherche ou vos filtres.',
    'index_empty_reset' => 'Tout réinitialiser',

    // Barre d'outils du base-index (recherche + filtres)
    'index_search_ph'   => 'Rechercher…',
    'filters'           => 'Filtres',
    'filters_apply'     => 'Appliquer',
    'filters_all'       => 'Tous',
    'index_results'     => 'Résultats',

    // Page de recherche (search/results + search-results)
    'search_refine_ph'       => 'Affiner la recherche…',
    'search_empty_title'     => 'Lancez une recherche',
    'search_empty_hint'      => 'Tapez au moins :min caractères pour rechercher dans toute l’application.',
    'search_recent'          => 'Recherches récentes',
    'search_clear_all'       => 'Tout effacer',
    'search_all'             => 'Tout',
    'search_searching'       => 'Recherche en cours…',
    'search_count'           => ':count résultat|:count résultats',
    'search_for'             => 'pour',
    'search_no_results_title' => 'Aucun résultat',
    'search_no_results_hint' => 'Aucun résultat pour « :query ». Essayez d’autres termes ou vérifiez l’orthographe.',
    'search_remove_category' => 'Retirer le filtre catégorie',
    'search_load_more'       => 'Charger plus',
    'search_remaining'       => ':n restants',
    'search_loading'         => 'Chargement…',
    'search_end'             => 'Fin — :count au total',
    'search_modal_ph'        => 'Rechercher dans toute l’application…',
    'search_clear'           => 'Effacer',
    'search_prompt_title'    => 'Que cherchez-vous ?',
    'search_result_singular' => 'résultat',
    'search_result_plural'   => 'résultats',
    'search_see_all'         => 'Voir les :count résultats dans :category →',
    'search_kbd_navigate'    => 'Naviguer',
    'search_kbd_open'        => 'Ouvrir',
    'search_kbd_close'       => 'Fermer',
    // Tableau de bord (greeting + états vides widgets)
    'greeting_morning' => 'Bonjour',
    'greeting_afternoon' => 'Bon après-midi',
    'greeting_evening' => 'Bonsoir',
    'dash_widget_empty' => 'Aucun élément',
    'dash_no_activity' => 'Aucune activité récente',
    // Visite guidée (bouton de relance + navigation)
    'tour_replay' => 'Revoir le guide',
    'tour_skip'   => 'Passer',
    'tour_prev'   => 'Précédent',
    'tour_next'   => 'Suivant',
    'tour_finish' => 'Terminer',
];
