{{--
    Pagination mt-ui (Livewire-aware). Rendue via {{ $items->links('mt::pagination.livewire') }}.
    100 % tokens --mt-* + icônes mt-icons + STYLES INLINE (classes utilitaires + variantes sm:
    de la vue Tailwind par défaut de Laravel sont ABSENTES du CSS servi mt-ui → conteneur
    desktop `hidden sm:flex` invisible). wire:click (pas de href) : mise à jour AJAX Livewire.
--}}
@if ($paginator->hasPages())
    <nav role="navigation" aria-label="Pagination" class="mt-pagination">
        <style>
            .mt-pagination { display: flex; align-items: center; justify-content: flex-end; gap: 4px; flex-wrap: wrap; }
            .mt-pagination .pg {
                display: inline-flex; align-items: center; justify-content: center;
                min-width: 2rem; height: 2rem; padding: 0 .5rem;
                border: 1px solid rgb(var(--mt-ui-card-border));
                border-radius: .5rem; font-size: .8125rem; line-height: 1;
                color: rgba(var(--mt-text), .8); background: transparent;
                cursor: pointer; user-select: none; transition: all .15s ease;
            }
            .mt-pagination .pg:hover { background: rgba(var(--mt-text), .05); color: rgb(var(--mt-text)); }
            .mt-pagination .pg-active {
                background: rgb(var(--mt-primary)); color: rgb(var(--mt-primary-content));
                border-color: rgb(var(--mt-primary)); font-weight: 600;
            }
            .mt-pagination .pg-disabled { opacity: .4; cursor: not-allowed; }
            .mt-pagination .pg-disabled:hover { background: transparent; }
            .mt-pagination .pg-gap { border: none; background: none; cursor: default; }
        </style>

        {{-- Précédent --}}
        @if ($paginator->onFirstPage())
            <span class="pg pg-disabled" aria-disabled="true"><x-mt::icon name="chevron-left" size="xs" /></span>
        @else
            <button type="button" class="pg" wire:click.prevent="previousPage" aria-label="{{ __('pagination.previous') }}">
                <x-mt::icon name="chevron-left" size="xs" />
            </button>
        @endif

        {{-- Numéros de page --}}
        @foreach ($elements as $element)
            @if (is_string($element))
                <span class="pg pg-gap">{{ $element }}</span>
            @endif
            @if (is_array($element))
                @foreach ($element as $page => $url)
                    @if ($page == $paginator->currentPage())
                        <span class="pg pg-active" aria-current="page">{{ $page }}</span>
                    @else
                        <button type="button" class="pg" wire:click.prevent="gotoPage({{ $page }})">{{ $page }}</button>
                    @endif
                @endforeach
            @endif
        @endforeach

        {{-- Suivant --}}
        @if ($paginator->hasMorePages())
            <button type="button" class="pg" wire:click.prevent="nextPage" aria-label="{{ __('pagination.next') }}">
                <x-mt::icon name="chevron-right" size="xs" />
            </button>
        @else
            <span class="pg pg-disabled" aria-disabled="true"><x-mt::icon name="chevron-right" size="xs" /></span>
        @endif
    </nav>
@endif
