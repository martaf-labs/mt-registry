<div class="h-full overflow-hidden rounded-2xl">

    {{-- ===== TABS ===== --}}
    <div class="flex rounded-full" style="background: rgba(var(--mt-text), 0.02)">
        @foreach ([
            'gallery' => ['label' => 'Galerie', 'icon' => 'mt-icon-images',       'badge' => count($existing)],
            'upload'  => ['label' => 'Ajouter', 'icon' => 'mt-icon-upload'],
            'results' => ['label' => 'Résultats','icon' => 'mt-icon-chart-simple','badge' => count($results), 'disabled' => count($results) === 0],
        ] as $tab => $info)
            <button
                wire:click="$set('activeTab', '{{ $tab }}')"
                @if(!empty($info['disabled'])) disabled @endif
                class="flex items-center gap-1 lg:gap-1.5 p-1.5 lg:px-4 lg:py-2.5 rounded-full text-xs lg:text-sm lg:font-medium transition-colors"
                style="{{ $activeTab === $tab
                    ? 'color: rgb(var(--mt-primary)); background: rgb(var(--mt-bg))'
                    : 'color: rgba(var(--mt-text), 0.5);' }}">
                <i class="{{ $info['icon'] }} text-xs"></i>
                {{ $info['label'] }}
                @if (!empty($info['badge']) && $info['badge'] > 0)
                    <span class="ml-0.5 px-1.5 py-0.5 text-xs rounded-full"
                          style="{{ $activeTab === $tab
                            ? 'background: rgba(var(--mt-primary), 0.12); color: rgb(var(--mt-primary))'
                            : 'background: rgba(var(--mt-text), 0.08); color: rgba(var(--mt-text), 0.6)' }}">
                        {{ $info['badge'] }}
                    </span>
                @endif
            </button>
        @endforeach
    </div>

    <div class="h-full px-2 py-5 overflow-y-auto lg:pb-12 lg:p-5">

        {{-- ============================= GALERIE ============================= --}}
        @if ($activeTab === 'gallery')
            @if (count($existing) === 0)
                <div class="flex flex-col items-center justify-center py-12 mt-text-muted">
                    <span class="mb-3"><x-mt::icon name="image" size="2xl" /></span>
                    <p class="mb-3 text-sm">Aucun {{ strtolower($this->kindLabel) }} pour l'instant…</p>
                    <button wire:click="$set('activeTab', 'upload')" class="mt-btn mt-btn-sm mt-btn-outline mt-rounded-full">
                        <span class="mr-1"><x-mt::icon name="plus" size="xs" /></span> Ajouter
                    </button>
                </div>
            @else
                {{-- ----- Médias IMAGE : grille de vignettes ----- --}}
                <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
                    @foreach ($existing as $m)
                        @if ($m['is_image'])
                            <div class="relative overflow-hidden group aspect-square rounded-xl"
                                 style="border: 2px solid {{ $m['is_featured'] ? 'rgb(var(--mt-warning))' : 'transparent' }};
                                        background: rgba(var(--mt-text), 0.05)">

                                <x-mt::image-loader :src="$m['url']" :alt="$m['title']" class="aspect-square" />

                                @if ($m['is_featured'])
                                    <div class="absolute top-1.5 left-1.5" style="color: rgb(var(--mt-warning))">
                                        <x-mt::icon name="star" />
                                    </div>
                                @endif

                                @if ($m['savings'])
                                    <div class="absolute bottom-1.5 left-1.5 text-white text-xs px-1.5 py-0.5 rounded-full"
                                         style="background: rgba(var(--mt-success), 0.9)">
                                        -{{ round($m['savings']) }}%
                                    </div>
                                @endif

                                <div class="absolute inset-0 flex items-center justify-center gap-2 transition-all duration-200 opacity-0 bg-black/0 group-hover:bg-black/40 group-hover:opacity-100">
                                    @if (!$m['is_featured'])
                                        <button wire:click="setFeatured({{ $m['id'] }})" title="Définir comme principale"
                                                class="flex items-center justify-center w-8 h-8 rounded-full shadow hover:opacity-80"
                                                style="background: rgb(var(--mt-warning))">
                                            <x-mt::icon name="star" class="text-white" />
                                        </button>
                                    @endif
                                    @if ($allowDelete)
                                        <button wire:click="deleteMedia({{ $m['id'] }})"
                                                wire:confirm="Supprimer ce média et ses variantes ?"
                                                title="Supprimer"
                                                class="flex items-center justify-center w-8 h-8 rounded-full shadow hover:opacity-80"
                                                style="background: rgb(var(--mt-danger))">
                                            <x-mt::icon name="trash" class="text-white" />
                                        </button>
                                    @endif
                                </div>
                            </div>
                        @endif
                    @endforeach
                </div>

                {{-- ----- Médias NON-IMAGE : liste de fichiers ----- --}}
                @php $files = collect($existing)->where('is_image', false); @endphp
                @if ($files->count() > 0)
                    <div class="mt-3 space-y-2">
                        @foreach ($files as $m)
                            @php
                                $ext  = strtolower(pathinfo($m['original_name'], PATHINFO_EXTENSION));
                                $icon = match (true) {
                                    $ext === 'pdf'                          => 'fa-solid fa-file-pdf',
                                    in_array($ext, ['doc','docx'])          => 'fa-solid fa-file-word',
                                    in_array($ext, ['xls','xlsx','csv'])    => 'fa-solid fa-file-excel',
                                    in_array($ext, ['ppt','pptx'])          => 'fa-solid fa-file-powerpoint',
                                    in_array($ext, ['mp4','mov','avi','mkv','webm']) => 'fa-solid fa-file-video',
                                    default                                 => 'fa-solid fa-file',
                                };
                            @endphp
                            <div class="flex items-center gap-3 p-3 rounded-xl"
                                 style="background: rgba(var(--mt-text), 0.03); border: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                                <i class="{{ $icon }} text-lg" style="color: rgb(var(--mt-primary))"></i>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium truncate mt-text">{{ $m['original_name'] }}</p>
                                    <p class="text-xs mt-text-muted">
                                        {{ strtoupper($ext) }}@if($m['size']) · {{ number_format($m['size'] / 1024, 0) }} KB @endif
                                    </p>
                                </div>
                                <a href="{{ $m['url'] }}" target="_blank" title="Ouvrir"
                                   class="flex items-center justify-center w-8 h-8 rounded-lg mt-btn-icon">
                                    <i class="fa-solid fa-arrow-up-right-from-square text-xs"></i>
                                </a>
                                @if ($allowDelete)
                                    <button wire:click="deleteMedia({{ $m['id'] }})"
                                            wire:confirm="Supprimer ce document ?"
                                            title="Supprimer"
                                            class="flex items-center justify-center w-8 h-8 rounded-lg mt-text-danger">
                                        <i class="fa-solid fa-trash text-xs"></i>
                                    </button>
                                @endif
                            </div>
                        @endforeach
                    </div>
                @endif
            @endif
        @endif

        {{-- ============================= UPLOAD ============================= --}}
        @if ($activeTab === 'upload')
            <div class="space-y-4">
                <x-mt::form.file-upload
                    id="mt-media-input-{{ $this->getId() }}"
                    wire:model="uploads"
                    :item-type="$this->uploadItemType"
                    :multiple="$multiple"
                />

                @error('uploads.*')
                    <div class="flex items-center gap-2 p-3 text-sm rounded-lg mt-alert mt-alert-danger">
                        <i class="flex-shrink-0 fa-solid fa-circle-exclamation"></i> {{ $message }}
                    </div>
                @enderror
                @error('uploads')
                    <div class="flex items-center gap-2 p-3 text-sm rounded-lg mt-alert mt-alert-danger">
                        <i class="flex-shrink-0 fa-solid fa-circle-exclamation"></i> {{ $message }}
                    </div>
                @enderror

                @if (count($uploads) > 0)
                    <div class="flex items-center gap-3 p-3 text-sm rounded-lg"
                         style="background: rgba(var(--mt-info), 0.08); border: 1px solid rgba(var(--mt-info), 0.2)">
                        <span class="mt-text-info"><x-mt::icon name="images" size="sm" /></span>
                        <span class="font-medium mt-text-info">
                            {{ count($uploads) }} fichier{{ count($uploads) > 1 ? 's' : '' }} prêt{{ count($uploads) > 1 ? 's' : '' }}
                        </span>
                        <button wire:click="$set('uploads', [])" class="ml-auto mt-text-info hover:opacity-75">
                            <x-mt::icon name="x" size="sm" />
                        </button>
                    </div>
                @endif

                @if ($loading && $progress > 0)
                    <div class="space-y-1.5">
                        <div class="flex justify-between text-xs mt-text-muted">
                            <span>Traitement…</span><span class="font-medium">{{ $progress }}%</span>
                        </div>
                        <div class="w-full h-2 overflow-hidden rounded-full mt-bg-secondary">
                            <div class="h-2 transition-all duration-300 rounded-full"
                                 style="width: {{ $progress }}%; background: rgb(var(--mt-primary))"></div>
                        </div>
                    </div>
                @endif

                <x-mt::button wire:click="process" loading="process" variant="success" icon="bolt"
                              disabled="{{ count($uploads) === 0 }}">
                    <span wire:loading.remove wire:target="process">
                        Enregistrer {{ count($uploads) > 0 ? count($uploads) . ' fichier' . (count($uploads) > 1 ? 's' : '') : '' }}
                    </span>
                    <span wire:loading wire:target="process">Traitement…</span>
                </x-mt::button>
            </div>
        @endif

        {{-- ============================= RÉSULTATS ============================= --}}
        @if ($activeTab === 'results')
            <div class="space-y-2">
                @foreach ($results as $result)
                    <div class="flex items-center gap-3 p-3 rounded-xl"
                         style="{{ $result['success']
                            ? 'background: rgba(var(--mt-success), 0.06); border: 1px solid rgba(var(--mt-success), 0.15)'
                            : 'background: rgba(var(--mt-danger), 0.06); border: 1px solid rgba(var(--mt-danger), 0.15)' }}">
                        <div class="flex items-center justify-center flex-shrink-0 w-8 h-8 rounded-full"
                             style="{{ $result['success'] ? 'background: rgba(var(--mt-success), 0.12)' : 'background: rgba(var(--mt-danger), 0.12)' }}">
                            <i class="{{ $result['success'] ? 'fa-solid fa-check' : 'fa-solid fa-xmark' }} text-xs"
                               style="color: {{ $result['success'] ? 'rgb(var(--mt-success))' : 'rgb(var(--mt-danger))' }}"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium truncate mt-text">{{ $result['filename'] }}</p>
                            @if ($result['success'])
                                <p class="text-xs mt-text-muted">
                                    {{ ucfirst($result['kind'] ?? '') }}
                                    @if (!empty($result['variants']))
                                        · {{ count($result['variants']) }} variante{{ count($result['variants']) > 1 ? 's' : '' }}
                                    @endif
                                </p>
                            @else
                                <p class="text-xs truncate mt-text-danger">{{ $result['error'] ?? 'Erreur' }}</p>
                            @endif
                        </div>
                        @if ($result['success'] && !empty($result['savings_percent']))
                            <span class="flex-shrink-0 text-sm font-bold mt-text-success">-{{ round($result['savings_percent']) }}%</span>
                        @endif
                    </div>
                @endforeach
            </div>
        @endif

    </div>
</div>
