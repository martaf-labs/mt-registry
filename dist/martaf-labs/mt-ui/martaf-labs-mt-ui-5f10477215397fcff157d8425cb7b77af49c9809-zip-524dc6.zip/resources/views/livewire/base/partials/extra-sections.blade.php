{{--
    Rendu générique des sections de champs supplémentaires fournies par l'hôte
    via BaseForm::extraSections(). Liées au bag `extraData.<clé>`.
    Vide si l'hôte n'override pas extraSections() → aucun impact.
--}}
@php $extraSections = $this->extraSections(); @endphp

@if(!empty($extraSections))
    <div class="mt-6 space-y-5">
        @foreach($extraSections as $si => $section)
            <div class="rounded-2xl border p-5"
                 style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))"
                 wire:key="extra-section-{{ $si }}">

                @if(!empty($section['title']))
                    <h3 class="mb-1 text-sm font-semibold mt-text">{{ $section['title'] }}</h3>
                @endif
                @if(!empty($section['description']))
                    <p class="mt-text-muted mb-4 text-xs">{{ $section['description'] }}</p>
                @endif

                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    @foreach(($section['fields'] ?? []) as $fi => $field)
                        @php
                            $name     = $field['name'];
                            $type     = $field['type'] ?? 'text';
                            $label    = $field['label'] ?? '';
                            $required = $field['required'] ?? false;
                            $hint     = $field['hint'] ?? null;
                            $options  = $field['options'] ?? [];
                            $multiple = $field['multiple'] ?? false;
                            $err      = $errors->first($name);
                        @endphp

                        <div wire:key="extra-field-{{ $si }}-{{ $fi }}"
                             @class(['sm:col-span-2' => in_array($type, ['textarea'])])>
                            @switch($type)
                                @case('textarea')
                                    <x-mt::form.textarea :label="$label" :model="$name" :required="$required"
                                                         :help="$hint" :error="$err" rows="3" />
                                    @break
                                @case('toggle')
                                    <x-mt::form.toggle :label="$label" :model="$name" :help="$hint" :error="$err" />
                                    @break
                                @case('select')
                                    <x-mt::form.select :label="$label" :model="$name" :required="$required"
                                                       :multiple="$multiple" :help="$hint" :error="$err">
                                        @unless($multiple)<option value="">-</option>@endunless
                                        @foreach($options as $val => $optLabel)
                                            <option value="{{ $val }}">{{ $optLabel }}</option>
                                        @endforeach
                                    </x-mt::form.select>
                                    @break
                                @default
                                    <x-mt::form.input :label="$label" :model="$name" :type="$type"
                                                      :required="$required" :help="$hint" :error="$err" />
                            @endswitch
                        </div>
                    @endforeach
                </div>
            </div>
        @endforeach
    </div>
@endif
