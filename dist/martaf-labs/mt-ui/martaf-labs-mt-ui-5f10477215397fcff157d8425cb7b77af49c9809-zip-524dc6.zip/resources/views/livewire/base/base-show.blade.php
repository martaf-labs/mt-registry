{{--
    BASE-SHOW — 3e vue-modèle de mt-ui (fiche de consultation).
    Deux modes : SECTIONS (North Star — le Show Object surcharge sections())
    et LEGACY (getShowData — conservé pour les shows historiques, ex. sgni-app).
--}}
<div>
    @if($sectionsMode && $data)
        @include('mt::livewire.base.partials.show-sections')
    @else
        @include('mt::livewire.base.partials.show-legacy')
    @endif
</div>
