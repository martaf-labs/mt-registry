{{--
    BASE-SHOW mode SECTIONS (North Star) : en-tête avatar/badges + stats compactes
    + onglets client (Alpine) + sections attributes|table|view. Lecture seule —
    les actions d'en-tête suivent la grammaire des mainActions du base-index.
--}}
@php
    $headerImage    = $header['image'] ?? null;
    $headerLetters  = $header['letters'] ?? mb_substr($title, 0, 2);
    $headerSubtitle = $header['subtitle'] ?? null;
    $headerBadges   = $header['badges'] ?? [];
    $defaultTab     = array_key_first($tabs ?? []) ?? '';
    // Mode PROFIL (fiche de personne) : avatar rond « photo d'identité », un peu
    // plus grand ; mode SHOW (chose) : vignette arrondie classique.
    $isProfile      = $isProfile ?? false;
    $avatarShape    = $isProfile ? 'rounded-full' : 'rounded-2xl';
    $avatarSize     = $isProfile ? '5.5rem' : '4.5rem';
@endphp

<div class="min-h-screen py-3 lg:py-6">
    <div class="px-2 mx-auto max-w-7xl lg:px-8">

        <x-mt::breadcrumbs :title="$title" :datas="$navItems ?? []" :actions="$showActions ?? []" />

        {{-- ===================== EN-TÊTE (identité) ===================== --}}
        <div class="mt-card mb-5 p-5">
            <div class="flex flex-wrap items-center gap-4">
                @if($headerImage)
                    <img src="{{ $headerImage }}" alt="{{ strip_tags($title) }}"
                         class="shrink-0 {{ $avatarShape }} object-cover"
                         style="width: {{ $avatarSize }}; height: {{ $avatarSize }}"
                         onerror="this.style.display='none'; this.nextElementSibling && (this.nextElementSibling.style.display='flex')" />
                    <div class="shrink-0 items-center justify-center {{ $avatarShape }} font-bold"
                         style="display:none; width: {{ $avatarSize }}; height: {{ $avatarSize }}; font-size: 1.25rem; background: rgba(var(--mt-primary),0.12); color: rgb(var(--mt-primary))">
                        {{ mb_strtoupper(mb_substr($headerLetters, 0, 2)) }}
                    </div>
                @else
                    <div class="flex shrink-0 items-center justify-center {{ $avatarShape }} font-bold"
                         style="width: {{ $avatarSize }}; height: {{ $avatarSize }}; font-size: 1.25rem; background: rgba(var(--mt-primary),0.12); color: rgb(var(--mt-primary))">
                        {{ mb_strtoupper(mb_substr($headerLetters, 0, 2)) }}
                    </div>
                @endif

                <div class="min-w-0 flex-1">
                    <div class="flex flex-wrap items-center gap-2">
                        <h2 class="text-xl font-bold mt-text">{{ $title }}</h2>
                        @foreach($headerBadges as $badge)
                            <x-mt::badge :label="$badge['label'] ?? ''" :variant="$badge['type'] ?? $badge['color'] ?? 'secondary'" class="px-2 py-0.5" style="font-size:11px" />
                        @endforeach
                    </div>
                    @if($headerSubtitle)
                        <p class="mt-1 text-sm mt-text-muted">{{ $headerSubtitle }}</p>
                    @endif
                </div>
            </div>
        </div>

        {{-- ===================== STATISTIQUES (option) — unifiées avec le dashboard ============ --}}
        @if (!empty($statistics))
        <div class="mb-5">
            <x-mt::stats-scroll :stats="$statistics" />
        </div>
        @endif

        {{-- ===================== ONGLETS + SECTIONS ===================== --}}
        <div x-data="{ tab: @js($activeTab !== '' ? $activeTab : $defaultTab) }">

            @if (!empty($tabs))
            <div class="mb-5 flex flex-wrap gap-1" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                @foreach($tabs as $tabKey => $tabLabel)
                <button type="button" @click="tab = @js($tabKey)"
                        class="px-4 py-2 text-sm font-medium transition-colors"
                        style="margin-bottom: -1px; border-bottom: 2px solid transparent"
                        :style="tab === @js($tabKey)
                            ? { borderBottomColor: 'rgb(var(--mt-primary))', color: 'rgb(var(--mt-primary))' }
                            : { color: 'rgba(var(--mt-text),0.6)' }">
                    {{ $tabLabel }}
                </button>
                @endforeach
            </div>
            @endif

            <div class="space-y-5">
                @foreach($sections as $section)
                @php
                    $sectionTab  = $section['tab'] ?? $defaultTab;
                    $sectionType = $section['type'] ?? 'attributes';
                @endphp
                <div @if(!empty($tabs)) x-show="tab === @js($sectionTab)" x-cloak @endif>
                    <div class="mt-card p-5">
                        @if(!empty($section['title']))
                            <h3 class="mb-4 text-sm font-semibold mt-text">{{ $section['title'] }}</h3>
                        @endif

                        @if($sectionType === 'attributes')
                            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                                @foreach(($section['items'] ?? []) as $attrLabel => $attrValue)
                                <div>
                                    <div class="text-xs mt-text-muted">{{ $attrLabel }}</div>
                                    <div class="mt-1 text-sm font-medium mt-text">{{ ($attrValue !== null && $attrValue !== '') ? $attrValue : '—' }}</div>
                                </div>
                                @endforeach
                            </div>

                        @elseif($sectionType === 'table')
                            @if(empty($section['rows']))
                                <x-mt::empty-state :icon="$section['emptyIcon'] ?? 'inbox-stack'" :title="$section['empty'] ?? __('mt-ui::mt-ui.empty_state_title')" />
                            @else
                            <div class="w-full overflow-x-auto rounded-xl border" style="border-color: rgb(var(--mt-ui-card-border))">
                                <table class="w-full border-collapse text-xs">
                                    <thead>
                                        <tr class="text-left mt-text-muted" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                                            @foreach(($section['columns'] ?? []) as $col)
                                            <th class="px-4 py-3 font-medium">{{ $col }}</th>
                                            @endforeach
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($section['rows'] as $row)
                                        <tr class="transition-colors" style="border-top: 1px solid rgba(var(--mt-ui-card-border),0.5)"
                                            onmouseover="this.style.background='rgba(var(--mt-text),0.03)'" onmouseout="this.style.background=''">
                                            @foreach($row as $cell)
                                            <td class="px-4 py-3 text-sm mt-text">
                                                @if(is_array($cell) && isset($cell['badge']))
                                                    <x-mt::badge :label="$cell['badge']" :variant="$cell['type'] ?? 'secondary'" class="px-2 py-0.5" style="font-size:10px" />
                                                @else
                                                    {{ ($cell !== null && $cell !== '') ? $cell : '—' }}
                                                @endif
                                            </td>
                                            @endforeach
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @endif

                        @elseif($sectionType === 'view')
                            @include($section['view'], ['model' => $data])
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    {{-- Gestionnaire de médias (features.canAddImages) --}}
    @if ($canAddImages ?? false)
    <div x-data="{ open: false }"
        x-on:media-updated.window="$wire.$refresh()"
        x-on:open-image-manager.window="open = true">
        <x-mt::modal name="image-manager-modal" title="Gérer les médias" x-show="open" icon="images">
            <livewire:mt.forms.media-manager
                :key="'media-show-'.$id"
                :model-type="$modelClass"
                :model-id="$id"
                kind="image"
                type="photo"
                :multiple="true"
                :allow-delete="true"
            />
        </x-mt::modal>
    </div>
    @endif

    {{-- Point d'extension : partials du composant hôte (modales custom…) --}}
    @foreach ($this->extraPartials() as $extraPartial)
        @include($extraPartial)
    @endforeach
</div>
