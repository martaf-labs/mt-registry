<div>
    @php
        $sections = $profileDatas['sections'] ?? false;
        $process = $sections && isset($sections['process']) ? $sections['process'] : false;
        $personalInfos = $sections? $sections['personalInfos'] : false;
        $sidebar = $profileDatas['sidebar'] && !empty($profileDatas['sidebar']) ? $profileDatas['sidebar'] : false;
        $profileCard = $sidebar && isset($sidebar['profileCard']) ? $sidebar['profileCard'] : false;
        $requiredItemsList = $sidebar && isset($sidebar['requiredItemsList']) ? $sidebar['requiredItemsList'] : false;
        $detailsItemsList = $sidebar && isset($sidebar['detailsItemsList']) ? $sidebar['detailsItemsList'] : false;
        $actionsHistory = $sidebar && isset($sidebar['actionsHistory']) ? $sidebar['actionsHistory'] : false;
        $actions = $this->getActions();
        $modules = $this->getModules();
        $hasActions = count($actions) > 0;
        $hasModules = count($modules) > 0;
        $quickStats = $this->getQuickStats();
    @endphp

    <div class="min-h-screen py-6 bg-zinc-50 dark:bg-zinc-800">
        <div class="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
            <!-- En-tête avec breadcrumbs et boutons d'action -->
            <div class="flex flex-col justify-between gap-4 mb-6 sm:flex-col sm:items-start">
                <x-mt::breadcrumbs :title="$title" :datas="$navItems ?? []" />

                <!-- Boutons d'action globaux -->
                @if($data && $hasActions)

                <div class="w-full flex justify-end">

                    @php

                        $defaultActions=array_filter($actions['defaults'], function($a){ return $a != false;});
                        $allActions=$actions['main'] ?? [];
                        foreach($defaultActions as $type => $action){
                            switch ($type) {
                                case 'print':
                                    $allActions[]= [
                                        'type' => 'print',
                                        'label' => 'Imprimer',
                                        'icon' => "printer",
                                        'variant' => "outline",
                                        'onclick' => "window.print()"
                                    ];
                                    break;

                                case 'export':
                                    $allActions[]= [
                                        'type' => 'export',
                                        'label' => 'Exporter',
                                        'icon' => "document-arrow-down",
                                        'variant' => "outline",
                                        'click' => "exportModule('{{ $activeModule }}')"
                                    ];
                                    break;

                                case 'share':
                                    $allActions[]= [
                                        'type' => 'share',
                                        'label' => 'Partager',
                                        'icon' => "share",
                                        'variant' => "outline",
                                        'route' => ""
                                    ];
                                    break;
                                
                                default:
                                    # code...
                                    break;
                            }
                        }
                        
                    @endphp

                    <x-mt::actions.grid :actions="$allActions" visible="4" />

                </div>
                @endif
            </div>

            @if(!$data)
            <div class="p-8 text-center bg-white rounded-lg shadow dark:bg-zinc-800">
                <div class="flex items-center justify-center w-24 h-24 mx-auto mb-4 rounded-full bg-zinc-100 dark:bg-zinc-700">
                    <x-mt::icon name="exclamation-triangle" class="size-12 text-zinc-400"/>
                </div>
                <h3 class="mb-2 text-lg font-medium text-zinc-800 dark:text-white">
                    Profil non trouvé
                </h3>
                <p class="mb-4 text-gray-500 dark:text-gray-400">Le profil que vous recherchez n'existe pas.</p>
                <x-mt::button icon="arrow-left" href="{{ route('dashboard') }}" variant="primary" wire:navigate>
                    Retour au tableau de bord
                </x-mt::button>
            </div>
            @else

            <div class="relative grid grid-cols-1 gap-6 lg:grid-cols-4">


                @if ($sidebar)
                <!-- SIDEBAR -->
                <div class="lg:sticky top-0 lg:col-span-1">
                    <div class="space-y-6">
                        @if ($profileCard)
                        <!-- Carte Profil -->
                        <div class="overflow-hidden bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                            <div class="flex flex-col items-center justify-center p-6 text-center">
                                <!-- Avatar -->
                                @if($profileCard['image'] ?? false)
                                <div class="flex items-center justify-center w-32 h-32 text-4xl text-blue-500 rounded-lg">
                                    <x-mt::avatar
                                        name="N A"
                                        :image="$profileCard['image']"
                                        size="32"
                                    />
                                </div>
                                @endif

                                <!-- Informations -->
                                <h2 class="mt-3 text-xl font-bold text-zinc-900 dark:text-white">
                                    {{ $profileCard['text'] }}
                                </h2>
                                <p class="mb-2 text-sm text-zinc-500 dark:text-zinc-400">
                                    {{ $profileCard['subText'] ?? '' }}
                                </p>

                                <!-- Membre depuis -->
                                {{-- @if($sidebar['profile']['member_since'] ?? false)
                                <div class="mt-2 text-xs text-zinc-500 dark:text-zinc-400">
                                    Employé depuis {{ $sidebar['profile']['member_since'] }}
                                </div>
                                @endif --}}
                            </div>
                        </div>
                        @endif

                        <!-- Statistiques rapides -->
                        @if(count($quickStats) > 0)
                        <div class="p-6 bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                            <h3 class="mb-4 text-lg font-semibold text-zinc-900 dark:text-white">
                                Aperçu
                            </h3>
                            <div class="space-y-3">
                                @foreach($quickStats as $stat)
                                <div class="flex items-center justify-between">
                                    <span class="text-sm text-zinc-600 dark:text-zinc-400">{{ $stat['label'] }}</span>
                                    <x-mt::badge label="{{ $stat['value'] }}" type="{{ $stat['type'] ?? 'secondary' }}" rounded="full" />
                                </div>
                                @endforeach
                            </div>
                        </div>
                        @endif

                        <!-- $requiredItemsList -->
                        @if($requiredItemsList)
                        <div class="p-6 bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                            <h3 class="mb-4 text-md font-semibold text-zinc-900 dark:text-white">
                                {{ $requiredItemsList['title'] }}
                            </h3>
                            <div class="space-y-2">

                                @if ($requiredItemsList['items'] && count($requiredItemsList['items']) > 0)
                                    @include('mt::components.required-items-list', [
                                        'items' => $requiredItemsList['items'],
                                        'progressChart' => 'line'
                                    ])
                                @endif

                            </div>
                        </div>
                        @endif

                        <!-- $detailsItemsList -->
                        @if($detailsItemsList)
                        <div class="p-6 bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                            <h3 class="mb-4 text-md font-semibold text-zinc-900 dark:text-white">
                                {{ $detailsItemsList['title'] }}
                            </h3>
                            <div class="space-y-2">

                                @if ($detailsItemsList['items'] && count($detailsItemsList['items']) > 0)
                                    @include('mt::components.details-items-list', [
                                        'items' => $detailsItemsList['items'],
                                        'total' => $detailsItemsList['total'],
                                        'infos' => $detailsItemsList['infos'],
                                    ])
                                @endif

                            </div>
                        </div>
                        @endif
                        
                        <!-- $actionsHistory -->
                        @if($actionsHistory)
                        <div class="p-6 bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                            <h3 class="mb-4 text-md font-semibold text-zinc-900 dark:text-white">
                                {{ $actionsHistory['title'] }}
                            </h3>
                            <div class="space-y-2">

                                @if ($actionsHistory['items'] && count($actionsHistory['items']) > 0)
                                    @include('mt::components.actions-history', [
                                        'items' => $actionsHistory['items'],
                                    ])
                                @endif

                            </div>
                        </div>
                        @endif
                    </div>
                </div>
                @endif

                <!-- CONTENU PRINCIPAL -->
                <div class="lg:col-span-3">
                    <div class="space-y-6">

                        @if ($process)
                            <!-- sectionProcess -->
                            @foreach ($process as $subProcess)
                            <x-mt::templates.app.page-section :title="$subProcess['title']">

                                @include('mt::components.step-indicator', [
                                    'steps' => $subProcess['steps'],
                                ])

                            </x-mt::templates.app.page-section>
                            @endforeach
                        @endif

                        @if($personalInfos)
                        <!-- personalInfos -->
                        <div class="lg:col-span-2 hidden">

                            @foreach ($personalInfos as $subPersonalInfos)
                            @php
                                $subPersonalActions=count($subPersonalInfos['actions'] ?? [] ) > 0 ? $subPersonalInfos['actions'] : false;
                                $image=$subPersonalInfos['image'] ?? false;
                                $subPersonalInfosFields=$subPersonalInfos['fields'] ?? [];
                            @endphp
                            
                            <x-mt::templates.app.page-section :title="$subPersonalInfos['title']" :actions="$subPersonalActions">

                                {{-- @include('mt::components.personal-infos', [
                                    'steps' => $subProcess['steps'],
                                ]) --}}
                                <div class="flex flex-col gap-6 md:flex-row">

                                    @if ($image)
                                    <div class="flex-shrink-0">
                                        <div class="flex items-center justify-center w-32 h-32 text-4xl text-blue-500 rounded-lg">
                                            <x-mt::avatar
                                                name="N A"
                                                :image="$image"
                                                size="32"
                                            />
                                        </div>
                                    </div>
                                    @endif
                                    <div class="grid flex-grow grid-cols-1 gap-4 md:grid-cols-6">

                                        @if (!empty($subPersonalInfosFields))
                                            @foreach ($subPersonalInfosFields as $field => $fieldData)
                                                @php
                                                    $fieldDataValue=Str::length($fieldData['value'] ?? '') > 0 ? $fieldData['value'] : 'N\A';
                                                    $fieldDataCol=$fieldData['col'];
                                                @endphp
                                                <div class="@if($fieldDataCol==12) md:col-span-6
                                                    @elseif($fieldDataCol==9) md:col-span-4
                                                    @elseif($fieldDataCol==6) md:col-span-3
                                                    @elseif($fieldDataCol==4) md:col-span-2
                                                    @elseif($fieldDataCol==3) md:col-span-1
                                                    @else md:col-span-1 @endif">
                                                    <label class="text-xs font-medium text-gray-500">{{ $fieldData['label'] }}</label>
                                                    <p class="text-primary hover:text-secondary">{{ $fieldDataValue }}</p>
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                </div>
                            </x-mt::templates.app.page-section>

                            @endforeach

                            <!-- Détails de la scolarité -->
                            {{-- <div class="mb-6 bg-white rounded-lg shadow">
                                <div class="p-6 border-b border-gray-200">
                                    <div class="flex items-center justify-between">
                                        <h3 class="text-lg font-bold text-gray-900">Détails de la scolarité</h3>
                                        <button class="text-primary hover:text-secondary" onclick="openEditSchoolingModal()">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="p-6">
                                    <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                                        <div>
                                            <label class="text-sm font-medium text-gray-500">Cycle scolaire</label>
                                            <p class="font-medium text-gray-900">Collège</p>
                                        </div>
                                        <div>
                                            <label class="text-sm font-medium text-gray-500">Niveau demandé</label>
                                            <p class="font-medium text-gray-900">6ème (Première année collège)</p>
                                        </div>
                                        <div>
                                            <label class="text-sm font-medium text-gray-500">Classe suggérée</label>
                                            <p class="font-medium text-gray-900">6ème A</p>
                                        </div>
                                        <div>
                                            <label class="text-sm font-medium text-gray-500">Année scolaire</label>
                                            <p class="font-medium text-gray-900">2024-2025</p>
                                        </div>
                                        <div>
                                            <label class="text-sm font-medium text-gray-500">Date d'entrée prévue</label>
                                            <p class="font-medium text-gray-900">02/09/2024</p>
                                        </div>
                                        <div>
                                            <label class="text-sm font-medium text-gray-500">Type d'inscription</label>
                                            <p class="font-medium text-gray-900">Nouvelle admission</p>
                                        </div>
                                        <div class="md:col-span-2">
                                            <label class="text-sm font-medium text-gray-500">Établissement précédent</label>
                                            <p class="font-medium text-gray-900">École Primaire Les Lilas, Paris 12ème</p>
                                        </div>
                                    </div>

                                    <!-- Options pédagogiques -->
                                    <div class="mt-6">
                                        <h4 class="mb-3 font-medium text-gray-900">Options pédagogiques choisies</h4>
                                        <div class="flex flex-wrap gap-2">
                                            <span class="px-3 py-1 text-sm text-blue-800 bg-blue-100 rounded-full">Anglais LV1</span>
                                            <span class="px-3 py-1 text-sm text-green-800 bg-green-100 rounded-full">Latin</span>
                                            <span class="px-3 py-1 text-sm text-purple-800 bg-purple-100 rounded-full">Classe orchestre</span>
                                            <span class="px-3 py-1 text-sm text-yellow-800 bg-yellow-100 rounded-full">Section sportive football</span>
                                        </div>
                                    </div>
                                </div>
                            </div> --}}
                        </div>
                        @endif

                        <!-- 
                            ##############" Section Modules ##############"
                        -->
                        @if($hasModules)

                        @php
                            //
                        @endphp
                        <div class="bg-white border shadow-sm dark:bg-zinc-800 rounded-xl border-zinc-200 dark:border-zinc-700">
                            <!-- Barre de navigation des modules avec scrollbar au survol -->
                            <div class="border-b border-zinc-200 dark:border-zinc-700">
                                <div class="relative group">
                                    <nav class="flex -mb-px overflow-x-auto transition-colors scrollbar-thin scrollbar-thumb-zinc-300 scrollbar-track-transparent hover:scrollbar-thumb-zinc-400 dark:scrollbar-thumb-zinc-600 dark:hover:scrollbar-thumb-zinc-500">
                                        @foreach($modules as $module)
                                            @if($module['active'] ?? false)
                                            <button
                                                wire:click="setActiveModule('{{ $module['type'] }}')"
                                                class="flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-all duration-200 flex-shrink-0 {{ $activeModule === $module['type'] ? 'border-blue-500 text-blue-600 bg-blue-50 dark:bg-blue-900/20 dark:text-blue-400' : 'border-transparent text-zinc-500 hover:text-zinc-700 hover:bg-zinc-50 dark:text-zinc-400 dark:hover:text-zinc-300 dark:hover:bg-zinc-700/50' }}"
                                            >
                                                <x-mt::icon name="{{ $module['icon'] }}" class="flex-shrink-0 w-4 h-4" />
                                                <span class="truncate max-w-32">{{ $module['title'] }}</span>
                                                @if($activeModule === $module['type'])
                                                <div class="flex-shrink-0 w-2 h-2 bg-blue-500 rounded-full"></div>
                                                @endif
                                            </button>
                                            @endif
                                        @endforeach
                                    </nav>
                                </div>
                            </div>

                            <!-- Contenu du module actif -->
                            @if($activeModule && $activeModuleData)
                            <div class="p-6">
                                <!-- En-tête du module avec métriques -->
                                <div class="flex flex-col justify-between gap-4 mb-6 sm:flex-row sm:items-start">
                                    <div class="flex items-start gap-3">
                                        <div class="flex-shrink-0 p-2 bg-blue-100 rounded-lg dark:bg-blue-900/20">
                                            {{-- repli = icône EXISTANTE ('cube' n'est pas dans mt-icons → carré rouge) ;
                                                 indexation par type (les modules sont une liste, pas une map) --}}
                                            <x-mt::icon name="{{ collect($modules)->firstWhere('type', $activeModule)['icon'] ?? 'rectangle-stack' }}" class="w-5 h-5 text-blue-600 dark:text-blue-400" />
                                        </div>
                                        <div class="min-w-0">
                                            <h2 class="text-md font-semibold truncate text-zinc-900 dark:text-white">
                                                {{ $activeModuleData['title'] }}
                                            </h2>
                                            <p class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
                                                {{ $activeModuleData['description'] ?? 'Informations détaillées sur ' . strtolower($activeModuleData['title']) }}
                                            </p>
                                        </div>
                                    </div>

                                    <!-- Actions du module -->
                                    <div class="flex flex-wrap gap-2">
                                        @if(isset($activeModuleData['actions']) && count($activeModuleData['actions']) > 0)
                                        <x-mt::actions.grid :actions="$activeModuleData['actions']" visible="1" />
                                        @endif
                                    </div>
                                </div>

                                <!-- Statistiques du module -->
                                @if(isset($activeModuleData['stats']) && count($activeModuleData['stats']) > 0)
                                <div class="grid grid-cols-1 gap-4 mb-6 md:grid-cols-2 lg:grid-cols-{{ min(count($activeModuleData['stats']), 4) }}">
                                    @foreach($activeModuleData['stats'] as $stat)
                                    <div class="p-4 border rounded-lg shadow-sm bg-gradient-to-br from-white to-zinc-50 dark:from-zinc-800 dark:to-zinc-700/50 border-zinc-200 dark:border-zinc-700">
                                        <div class="flex items-center gap-3">
                                            <div class="p-2 bg-{{ $stat['type'] }}-100 dark:bg-{{ $stat['type'] }}-900/20 rounded-lg flex-shrink-0">
                                                <x-mt::icon name="{{ $stat['icon'] }}" class="w-4 h-4 text-{{ $stat['type'] }}-600 dark:text-{{ $stat['type'] }}-400" />
                                            </div>
                                            <div class="flex-1 min-w-0">
                                                <p class="text-sm font-medium truncate text-zinc-600 dark:text-zinc-400">{{ $stat['label'] }}</p>
                                                <p class="text-lg font-semibold truncate text-zinc-900 dark:text-white">{{ $stat['value'] }}</p>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                                @endif

                                <!-- Organisation du contenu du module -->
                                @php
                                    $moduleDatas= count($activeModuleData['datas'] ?? []) > 0 ? $activeModuleData['datas'] : false;
                                    
                                @endphp
                                <div class="space-y-6">
                                    <!-- Données principales -->
                                    @if($moduleDatas)

                                        @php
                                            $process=$moduleDatas['profileProcess'] ?? false;
                                            $personalInfos=$moduleDatas['personalInfos'] ?? false;
                                        @endphp

                                        @if ($process)
                                            <!-- sectionProcess -->
                                            @foreach ($process as $subProcess)
                                            <x-mt::templates.app.page-section :title="$subProcess['title']">

                                                @include('mt::components.step-indicator', [
                                                    'steps' => $subProcess['steps'],
                                                ])

                                            </x-mt::templates.app.page-section>
                                            @endforeach
                                        @endif
                                    
                                        @if($personalInfos)
                                        <!-- personalInfos -->
                                        <div class="lg:col-span-2">

                                            @foreach ($personalInfos as $subPersonalInfos)
                                            @php
                                                $subPersonalActions=count($subPersonalInfos['actions'] ?? [] ) > 0 ? $subPersonalInfos['actions'] : false;
                                                $image=$subPersonalInfos['image'] ?? false;
                                                $subPersonalInfosFields=$subPersonalInfos['fields'] ?? [];
                                            @endphp
                                            
                                            <x-mt::templates.app.page-section :title="$subPersonalInfos['title']" :actions="$subPersonalActions">

                                                {{-- @include('mt::components.personal-infos', [
                                                    'steps' => $subProcess['steps'],
                                                ]) --}}
                                                <div class="flex flex-col gap-6 md:flex-row">

                                                    @if ($image)
                                                    <div class="flex-shrink-0">
                                                        <div class="flex items-center justify-center w-32 h-32 text-4xl text-blue-500 rounded-lg">
                                                            <x-mt::avatar
                                                                name="N A"
                                                                :image="$image"
                                                                size="32"
                                                            />
                                                        </div>
                                                    </div>
                                                    @endif
                                                    <div class="grid flex-grow grid-cols-1 gap-4 md:grid-cols-6">

                                                        @if (!empty($subPersonalInfosFields))
                                                            @foreach ($subPersonalInfosFields as $field => $fieldData)
                                                                @php
                                                                    $fieldDataValue=Str::length($fieldData['value'] ?? '') > 0 ? $fieldData['value'] : 'N\A';
                                                                    $fieldDataCol=$fieldData['col'];
                                                                @endphp
                                                                <div class="@if($fieldDataCol==12) md:col-span-6
                                                                    @elseif($fieldDataCol==9) md:col-span-4
                                                                    @elseif($fieldDataCol==6) md:col-span-3
                                                                    @elseif($fieldDataCol==4) md:col-span-2
                                                                    @elseif($fieldDataCol==3) md:col-span-1
                                                                    @else md:col-span-1 @endif">
                                                                    <label class="text-xs font-medium text-gray-500">{{ $fieldData['label'] }}</label>
                                                                    <p class="text-primary hover:text-secondary">{{ $fieldDataValue }}</p>
                                                                </div>
                                                            @endforeach
                                                        @endif
                                                    </div>
                                                </div>
                                            </x-mt::templates.app.page-section>

                                            @endforeach

                                            <!-- Détails de la scolarité -->
                                            {{-- <div class="mb-6 bg-white rounded-lg shadow">
                                                <div class="p-6 border-b border-gray-200">
                                                    <div class="flex items-center justify-between">
                                                        <h3 class="text-lg font-bold text-gray-900">Détails de la scolarité</h3>
                                                        <button class="text-primary hover:text-secondary" onclick="openEditSchoolingModal()">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="p-6">
                                                    <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                                                        <div>
                                                            <label class="text-sm font-medium text-gray-500">Cycle scolaire</label>
                                                            <p class="font-medium text-gray-900">Collège</p>
                                                        </div>
                                                        <div>
                                                            <label class="text-sm font-medium text-gray-500">Niveau demandé</label>
                                                            <p class="font-medium text-gray-900">6ème (Première année collège)</p>
                                                        </div>
                                                        <div>
                                                            <label class="text-sm font-medium text-gray-500">Classe suggérée</label>
                                                            <p class="font-medium text-gray-900">6ème A</p>
                                                        </div>
                                                        <div>
                                                            <label class="text-sm font-medium text-gray-500">Année scolaire</label>
                                                            <p class="font-medium text-gray-900">2024-2025</p>
                                                        </div>
                                                        <div>
                                                            <label class="text-sm font-medium text-gray-500">Date d'entrée prévue</label>
                                                            <p class="font-medium text-gray-900">02/09/2024</p>
                                                        </div>
                                                        <div>
                                                            <label class="text-sm font-medium text-gray-500">Type d'inscription</label>
                                                            <p class="font-medium text-gray-900">Nouvelle admission</p>
                                                        </div>
                                                        <div class="md:col-span-2">
                                                            <label class="text-sm font-medium text-gray-500">Établissement précédent</label>
                                                            <p class="font-medium text-gray-900">École Primaire Les Lilas, Paris 12ème</p>
                                                        </div>
                                                    </div>

                                                    <!-- Options pédagogiques -->
                                                    <div class="mt-6">
                                                        <h4 class="mb-3 font-medium text-gray-900">Options pédagogiques choisies</h4>
                                                        <div class="flex flex-wrap gap-2">
                                                            <span class="px-3 py-1 text-sm text-blue-800 bg-blue-100 rounded-full">Anglais LV1</span>
                                                            <span class="px-3 py-1 text-sm text-green-800 bg-green-100 rounded-full">Latin</span>
                                                            <span class="px-3 py-1 text-sm text-purple-800 bg-purple-100 rounded-full">Classe orchestre</span>
                                                            <span class="px-3 py-1 text-sm text-yellow-800 bg-yellow-100 rounded-full">Section sportive football</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> --}}
                                        </div>
                                        @endif
                                    
                                    @endif

                                    <!-- Contenu spécifique selon le type de module -->
                                    {{-- (bloc dexemple module retiré) --}}
                                </div>
                            </div>
                            @else
                            <!-- Aucun module sélectionné -->
                            <div class="p-12 text-center">
                                <div class="flex items-center justify-center w-16 h-16 mx-auto mb-4 rounded-full bg-zinc-100 dark:bg-zinc-700">
                                    <x-mt::icon name="table-cells" class="size-8 text-zinc-400"/>
                                </div>
                                <h3 class="mb-2 text-lg font-medium text-zinc-800 dark:text-white">
                                    Sélectionnez un module
                                </h3>
                                <p class="text-gray-500 dark:text-gray-400">
                                    Choisissez un module dans la navigation pour afficher ses informations.
                                </p>
                            </div>
                            @endif
                        </div>
                        @endif
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>

    @push('styles')
    <!-- Styles pour les scrollbars personnalisées -->
    <style>
        .scrollbar-thin {
            scrollbar-width: thin;
        }

        .scrollbar-thin::-webkit-scrollbar {
            height: 6px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .scrollbar-thin:hover::-webkit-scrollbar {
            opacity: 1;
        }

        .scrollbar-thin::-webkit-scrollbar-track {
            background: transparent;
            border-radius: 3px;
        }

        .scrollbar-thin::-webkit-scrollbar-thumb {
            background: #d4d4d8;
            border-radius: 3px;
            transition: background 0.3s;
        }

        .scrollbar-thin::-webkit-scrollbar-thumb:hover {
            background: #a1a1aa;
        }

        .dark .scrollbar-thin::-webkit-scrollbar-thumb {
            background: #52525b;
        }

        .dark .scrollbar-thin::-webkit-scrollbar-thumb:hover {
            background: #71717a;
        }

        .scrollbar-thumb-zinc-300::-webkit-scrollbar-thumb {
            background: #d4d4d8;
        }

        .scrollbar-thumb-zinc-400::-webkit-scrollbar-thumb {
            background: #a1a1aa;
        }

        .dark .scrollbar-thumb-zinc-600::-webkit-scrollbar-thumb {
            background: #52525b;
        }

        .dark .scrollbar-thumb-zinc-500::-webkit-scrollbar-thumb {
            background: #71717a;
        }

        .sidebar {
            transition: all 0.3s ease;
        }
        .card-hover {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .mobile-menu {
                display: none;
            }
            .mobile-menu.active {
                display: block;
                animation: slideIn 0.3s ease-out;
            }
        }

        /* Print styles */
        @media print {
            .no-print {
                display: none !important;
            }
            .print-only {
                display: block !important;
            }
        }
    </style>
    @endpush
</div>
