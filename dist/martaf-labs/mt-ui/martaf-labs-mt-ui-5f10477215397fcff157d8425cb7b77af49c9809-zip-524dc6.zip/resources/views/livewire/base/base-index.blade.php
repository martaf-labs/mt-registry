<div>

    @php

        $features = $indexDatas['features'] ?? [];

        $firstColumnField = $firstColumn['field'] ?? [];
        $firstColumnLabel = $firstColumn['label'] ?? '';

        $canAddImages = $indexDatas['canAddImages'] ?? false;
        $showFilters = $indexDatas['showFilters'] ?? false;

        $hasMainActions = count($mainActions) > 0;
        $searchable = $features['searchable'] ?? true;

        // Filtres dynamiques : $filtersEnabled = « cet index déclare des filtres »
        // (à ne pas confondre avec la propriété Livewire showFilters = panneau ouvert/fermé).
        $filtersEnabled = $indexDatas['showFilters'] ?? false;
        $availableFilters = $filtersData['availableFilters'] ?? [];
        $activeFilters = $filtersData['activeFilters'] ?? [];
        $filterValues = $filtersData['filterValues'] ?? [];
        $activeFiltersCount = $filtersData['activeFiltersCount'] ?? 0;
    @endphp

    <div class="min-h-screen py-3 lg:py-6">
        <div class="px-2 mx-auto max-w-7xl lg:px-8">

            <div class="hidden lg:block">
                <x-mt::breadcrumbs
                    :title="$title"
                    :datas="$navItems"
                    :actions="$mainActions"
                ></x-mt::breadcrumbs>
            </div>

            {{-- Mobile : si la barre de nav mobile existe, elle porte LE FAB → on lui pousse
                 l'action principale de CET écran (FAB contextuel), pas un 2e FAB flottant.
                 Sinon (projet sans barre mobile), on garde le FAB flottant historique. --}}
            @if(!empty(mt_mobile_nav()))
                @if($hasMainActions)
                    {{-- On pousse TOUTES les actions de l'écran au FAB de la barre : 1 = tap direct,
                         plusieurs = popover (cf. layout). NB : json encode dans un bloc php puis
                         echappe non-echappe (le combo push+json inline casse le parseur Blade). --}}
                    @php
                        $__fabActs = collect($mainActions)
                            ->filter(fn ($a) => is_array($a) && (!empty($a['route']) || !empty($a['method'])))
                            ->map(fn ($a) => [
                                'label'  => $a['label'] ?? '',
                                'icon'   => $a['icon'] ?? 'plus',
                                'route'  => $a['route'] ?? null,
                                'method' => $a['method'] ?? null,
                                'target' => $a['target'] ?? null,
                            ])->values()->all();
                        $__fabJson = !empty($__fabActs) ? json_encode($__fabActs) : null;
                    @endphp
                    @if($__fabJson)
                        @push('mobileFabActions'){!! $__fabJson !!}@endpush
                    @endif
                @endif
            @else
                <div class="lg:hidden">
                    <x-mt::actions.floating :actions="$mainActions" visible="4"/>
                </div>
            @endif

            {{-- Statistiques : DESKTOP/TABLETTE seulement (mobile = liste épurée, cf. concept). --}}
            @if (!empty($statistics))
            <div class="hidden mb-5 lg:block">
                <x-mt::stats-scroll :stats="$statistics" />
            </div>
            @endif

            {{-- Toolbar visible aussi quand la recherche/les filtres donnent 0 résultat
                 (sinon impossible de les réinitialiser). --}}
            @if (!empty($this->columns()) && ($items->count() > 0 || $search !== '' || $activeFiltersCount > 0))
            <!-- Barre de recherche et filtres -->
            <div class="py-2 lg:mb-3">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:gap-4">
                    <div class="flex lg:gap-3">
                        @if(!empty($searchableFields))
                        <div class="w-full ml-auto mr-0 lg:basis-2/3">
                            <div class="hidden lg:block">
                                <x-mt::form.input type="search" :placeholder="__('mt-ui::mt-ui.index_search_ph')" icon="magnifying-glass" wire:model.live="search" />
                            </div>
                            <div class="block lg:hidden">
                                <x-mt::form.input type="search" rounded="full" :placeholder="__('mt-ui::mt-ui.index_search_ph')" icon="magnifying-glass" wire:model.live="search" />
                            </div>
                        </div>

                        <div class="hidden basis-1/3 lg:block">
                            @php
                                // Paliers standard : doivent contenir la valeur par défaut (perPage
                                // de la config), sinon le select affiche un palier ≠ réalité.
                                $nberPerPages = [10, 25, 50, 100];
                            @endphp
                            <x-mt::form.select wire:model.live="perPage">
                                @foreach ($nberPerPages as $nber)
                                    <option value="{{ $nber }}">{{ $nber }}</option>
                                @endforeach
                            </x-mt::form.select>
                        </div>
                        @endif
                    </div>

                    {{-- Bouton « Filtres » : DESKTOP/TABLETTE seulement (mobile = pastilles ci-dessous). --}}
                    <div class="justify-end flex-grow hidden lg:block">
                        <div class="flex justify-end gap-2">
                            @if($filtersEnabled && count($availableFilters) > 0)
                            <x-mt::button
                                icon="funnel"
                                wire:click="toggleFilters"
                                :variant="$activeFiltersCount > 0 ? 'primary' : 'ghost'">
                                {{ __('mt-ui::mt-ui.filters') }} @if($activeFiltersCount > 0)<span class="ml-1">({{ $activeFiltersCount }})</span>@endif
                            </x-mt::button>
                            @endif
                        </div>
                    </div>
                </div>

                {{-- ══ MOBILE : pastilles de filtre (concept) — 1er filtre "select" en pastilles horizontales. ══ --}}
                @if($filtersEnabled && count($availableFilters) > 0)
                    @php
                        $__chipKey = null; $__chipCfg = null;
                        foreach($availableFilters as $__k => $__cfg) {
                            if (($__cfg['type'] ?? 'select') === 'select' && !empty($__cfg['options'])) { $__chipKey = $__k; $__chipCfg = $__cfg; break; }
                        }
                    @endphp
                    @if($__chipKey)
                        {{-- `.mob-fchip`/`.mob-fchips` sont désormais GLOBAUX (partials/theme-vars). --}}
                        <div class="flex gap-2 mob-fchips lg:hidden" style="margin-top:.85rem;padding:.15rem 0 .35rem">
                            @php $__cur = (string) ($filterValues[$__chipKey] ?? ''); @endphp
                            @if(!($__chipCfg['required'] ?? false))
                                <button type="button" wire:click="$set('filterValues.{{ $__chipKey }}', '')" class="mob-fchip {{ $__cur === '' ? 'on' : '' }}">{{ $__chipCfg['emptyLabel'] ?? __('mt-ui::mt-ui.filters_all') }}</button>
                            @endif
                            @foreach($__chipCfg['options'] as $__val => $__lbl)
                                <button type="button" wire:click="$set('filterValues.{{ $__chipKey }}', '{{ $__val }}')" class="mob-fchip {{ $__cur === (string) $__val ? 'on' : '' }}">{{ $__lbl }}</button>
                            @endforeach
                        </div>
                    @endif
                @endif

                <!-- Panneau des filtres -->
                @if($filtersEnabled && count($availableFilters) > 0)
                <div x-data="{ open: @entangle('showFilters') }" x-show="open" @click.outside="open = false"
                    x-transition:enter="transition ease-out duration-200"
                    x-transition:enter-start="opacity-0 transform -translate-y-2"
                    x-transition:enter-end="opacity-100 transform translate-y-0"
                    x-transition:leave="transition ease-in duration-150"
                    x-transition:leave-start="opacity-100 transform translate-y-0"
                    x-transition:leave-end="opacity-0 transform -translate-y-2"
                    class="p-4 mt-4 rounded-lg mt-card">

                    {{-- Filtres INSTANTANÉS (wire:model.live) : pas de bouton « Appliquer ». --}}
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-sm font-medium mt-text">{{ __('mt-ui::mt-ui.filters') }}</h3>
                        @if($activeFiltersCount > 0)
                        <x-mt::button size="sm" variant="ghost" wire:click="resetAllFilters" icon="x-mark">
                            {{ __('mt-ui::mt-ui.reset') }}
                        </x-mt::button>
                        @endif
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
                        @foreach($availableFilters as $filterKey => $filterConfig)
                            @php
                                $filterType = $filterConfig['type'] ?? 'select';
                                $filterLabel = $filterConfig['label'] ?? $filterKey;
                                $isMultiple = $filterConfig['multiple'] ?? false;
                                $filterOptions = $filterConfig['options'] ?? [];
                                $currentValue = $filterValues[$filterKey] ?? '';
                            @endphp

                            @php
                                $filterIsActive = !empty($activeFilters[$filterKey])
                                    || !empty($activeFilters[$filterKey.'_min'])
                                    || !empty($activeFilters[$filterKey.'_max']);
                                // 'required' => true : filtre OBLIGATOIRE (pas d'option « Tous »,
                                // pas de croix d'effacement) — ex. la classe du caissier, le niveau de la grille.
                                $filterRequired = $filterConfig['required'] ?? false;
                            @endphp
                            <div class="space-y-2">
                                {{-- Label + croix d'effacement INLINE (pas de croix flottante sous le champ) --}}
                                <div class="flex items-center justify-between gap-2">
                                    <label class="text-xs mt-label">{{ $filterLabel }}</label>
                                    @if($filterIsActive && ! $filterRequired)
                                        <button
                                            type="button"
                                            wire:click="resetFilter('{{ $filterKey }}')"
                                            title="{{ __('mt-ui::mt-ui.reset') }}"
                                            class="inline-flex items-center gap-1 text-xs transition-opacity hover:opacity-75"
                                            style="color: rgb(var(--mt-danger))"
                                        >
                                            <x-mt::icon name="x-mark" class="size-3" />
                                        </button>
                                    @endif
                                </div>

                                @if($filterType === 'select')
                                    <x-mt::form.select
                                        wire:model.live="filterValues.{{ $filterKey }}"
                                        :multiple="$isMultiple"
                                        size="sm">
                                        {{-- 'emptyLabel' : libellé métier de l'option vide (ex. « Générale » pour une filière) --}}
                                        @if(! $filterRequired)<option value="">{{ $filterConfig['emptyLabel'] ?? __('mt-ui::mt-ui.filters_all') }}</option>@endif
                                        @foreach($filterOptions as $value => $label)
                                            <option value="{{ $value }}">{{ $label }}</option>
                                        @endforeach
                                    </x-mt::form.select>

                                @elseif($filterType === 'range')
                                    <div class="flex gap-2">
                                        <x-mt::form.input type="number" placeholder="Min" wire:model.live.debounce.500ms="filterValues.{{ $filterKey }}_min" size="sm" :min="$filterConfig['min'] ?? ''" :max="$filterConfig['max'] ?? ''" />
                                        <x-mt::form.input type="number" placeholder="Max" wire:model.live.debounce.500ms="filterValues.{{ $filterKey }}_max" size="sm" :min="$filterConfig['min'] ?? ''" :max="$filterConfig['max'] ?? ''" />
                                    </div>

                                @elseif($filterType === 'date')
                                    <x-mt::form.input type="date" wire:model.live="filterValues.{{ $filterKey }}" size="sm" />

                                @elseif($filterType === 'checkbox')
                                    <div class="space-y-1 overflow-y-auto max-h-32">
                                        @foreach($filterOptions as $value => $label)
                                            <label class="flex items-center space-x-2 text-xs">
                                                <input
                                                    type="checkbox"
                                                    value="{{ $value }}"
                                                    wire:model.live="filterValues.{{ $filterKey }}"
                                                    class="rounded mt-checkbox"
                                                >
                                                <span class="mt-text">{{ $label }}</span>
                                            </label>
                                        @endforeach
                                    </div>
                                @endif
                            </div>
                        @endforeach
                    </div>
                </div>
                @endif
            </div>
            @endif

            <!-- Tableau -->
            <div class="w-full overflow-hidden">
                @if (!empty($this->columns()) && $items->count() > 0)
                @php
                    // La colonne Actions existe si AU MOINS une ligne de la page a des actions
                    // (les actions peuvent dépendre de l'état de la ligne — ex. valider/refuser
                    // seulement une inscription en attente). Ne PAS sonder un id codé en dur.
                    $anyRowActions = $items->getCollection()->contains(fn ($row) => count($this->getRowActions($row->id)) > 0);
                @endphp
                {{-- ══ DESKTOP/TABLETTE : tableau (mobile → cartes ci-dessous) ══ --}}
                <div class="hidden w-full overflow-x-auto lg:block rounded-xl" style="border-color: rgb(var(--mt-ui-card-border))">
                    <table class="w-full min-w-[60%] border-collapse text-xs">
                        <thead style="">
                            <tr>
                                <!-- Première colonne -->
                                @if(isset($firstColumn) && !is_null($firstColumnField))
                                @php
                                    $sortIcon = ($sortBy === $firstColumnField) ? "chevron-".($sortDirection === 'asc' ? 'up' : 'down') : "chevron-up-down";
                                    $isSortable = $this->isSortableField($firstColumnField);
                                @endphp
                                <th class="lg:px-4 py-2 lg:py-3 text-left text-xs font-medium mt-text-muted cursor-pointer w-full lg:min-w-[30%] lg:max-w-[40%] sticky left-0 z-20"
                                   @if($isSortable) wire:click="setSort('{{ $firstColumnField }}')" @endif>
                                    <div class="flex items-center gap-1">
                                        <span>{{ Illuminate\Support\Str::ucfirst($firstColumnLabel) }}</span>
                                        @if ($isSortable)
                                        <x-mt::icon name="{{ $sortIcon }}" class="size-4" />
                                        @endif
                                    </div>
                                </th>
                                @endif

                                @foreach($othersColumns as $columnField => $column)
                                    @php
                                        $columnLabel = $column['label'];
                                        $icon = ($sortBy === $columnField) ? "chevron-".($sortDirection === 'asc' ? 'up' : 'down') : "chevron-up-down";
                                        $isSortable = $this->isSortableField($columnField);
                                    @endphp
                                <th class="hidden py-2 text-xs font-medium text-left cursor-pointer lg:table-cell lg:px-4 lg:py-3 mt-text-muted whitespace-nowrap"
                                    @if($isSortable) wire:click="setSort('{{ $columnField }}')" @endif>
                                    <div class="flex items-center gap-1">
                                        <span>{{ Illuminate\Support\Str::ucfirst($columnLabel) }}</span>
                                        @if ($isSortable)
                                            <x-mt::icon name="{{ $icon }}" class="size-4" />
                                        @endif
                                    </div>
                                </th>
                                @endforeach

                                {{-- colonnes cachées --}}
                                @foreach ($hiddenColumns as $column)
                                    <th class="hidden"></th>
                                @endforeach

                                @if($anyRowActions)
                                <th class="sticky right-0 z-20 py-2 pr-2 text-xs font-medium text-left lg:w-20 lg:px-4 lg:py-3 mt-text-muted whitespace-nowrap mt-bg">
                                    <span class="hidden lg:block">Actions</span>
                                    <span class="sr-only">Actions</span>
                                </th>
                                @endif
                            </tr>
                        </thead>
                        <tbody class="relative" style="--tw-divide-color: rgb(var(--mt-ui-card-border)); border-color: rgb(var(--mt-ui-card-border))">

                            @foreach($items as $item)
                                @php
                                    $rowActions = $this->getRowActions($item->id);
                                    $itemColumns = $this->columns($item->id);
                                    $itemFirstColumn = $itemColumns['firstColumn'] ?? [];
                                    $itemOthersColumns = $itemColumns['othersColumns'] ?? [];
                                    $itemHiddenColumns = $itemColumns['hiddenColumns'] ?? [];
                                @endphp

                                <tr wire:key="item-{{ $item->id }}-{{ $item->updated_at->timestamp }}"
                                    class="transition-opacity duration-200 @if ($loop->index % 2 == 0) mt-bg-primary-soft @endif hover:border-b border-[rgb(var(--mt-ui-card-border))]">

                                    <!-- Première colonne -->
                                    @if(!empty($itemFirstColumn))
                                    @php
                                        $firstColumnValue        = $itemFirstColumn['value'] ?? '---';
                                        $firstColumnMetaDatas    = $itemFirstColumn['metaDatas'] ?? [];
                                        $firstColumnLabel        = $itemFirstColumn['label'];
                                        $firstColumnShowImage    = $itemFirstColumn['showImage'] ?? false;
                                        $firstColumnImage        = $itemFirstColumn['image'] ?? false;
                                        $firstColumnShowIcon     = $itemFirstColumn['showIcon'] ?? false;
                                        $firstColumnIcon         = $itemFirstColumn['icon'] ?? '';
                                        $firstColumnColor        = $itemFirstColumn['color'] ?? '';
                                        $firstColumnShowLetters  = $firstColumn['showLetters'] ?? false;
                                        $firstColumnLetters      = $itemFirstColumn['letters'] ?? false;
                                    @endphp

                                    <td class="lg:px-4 py-3 w-full lg:min-w-[30%] lg:max-w-[40%] sticky left-0 z-10">
                                        <div class="flex items-center gap-3">
                                            @if($firstColumnShowImage || $firstColumnShowLetters || $firstColumnIcon)
                                                <x-mt::avatar
                                                    :name="$firstColumnLetters"
                                                    :image="$firstColumnImage"
                                                    :icon="$firstColumnIcon"
                                                    size="10"
                                                    rounded="lg"
                                                />
                                            @endif

                                            <div class="flex-1 min-w-0">
                                                <div class="text-xs font-medium mt-text lg:text-sm">
                                                    {{ Illuminate\Support\Str::limit($firstColumnValue, 85) }}
                                                </div>
                                                @if(!empty($firstColumnMetaDatas))
                                                    <div class="text-[9px] lg:text-xs mt-text-muted truncate">
                                                        @foreach ($firstColumnMetaDatas as $metadata)
                                                            <span>{{ $metadata }}</span> @if(!$loop->last) • @endif
                                                        @endforeach
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </td>
                                    @endif

                                    @foreach($itemOthersColumns as $columnField => $column)
                                    @php
                                        $columnValue   = $column['value'] ?? '---';
                                        $badgeDatas    = $column['badgeDatas'] ?? [];
                                        $editableCfg   = $column['editable'] ?? null; // ['method','type','placeholder','width'] : cellule éditable inline
                                        $columnAlign   = $column['align'] ?? null;    // 'right'|'center' : alignement (montants…)
                                    @endphp
                                    <td class="hidden lg:table-cell p-1.5 lg:px-4 lg:py-3 text-xs lg:text-sm mt-text whitespace-nowrap"
                                        @if($columnAlign) style="text-align: {{ $columnAlign }}" @endif>
                                        @if (!empty($editableCfg))
                                        {{-- Cellule ÉDITABLE : wire:change → méthode du composant hôte (rowId, champ, valeur) --}}
                                        <input
                                            type="{{ $editableCfg['type'] ?? 'text' }}"
                                            value="{{ $column['value'] ?? '' }}"
                                            placeholder="{{ $editableCfg['placeholder'] ?? '—' }}"
                                            wire:change="{{ $editableCfg['method'] ?? 'updateCell' }}({{ $item->id }}, '{{ $columnField }}', $event.target.value)"
                                            class="mt-input"
                                            style="width: {{ $editableCfg['width'] ?? '8rem' }}; padding: .35rem .6rem; font-size: .85rem; text-align: right"
                                        />
                                        @elseif (!empty($badgeDatas))
                                        @php
                                            $columnBadge      = $badgeDatas ?? null;
                                            // 'type' attendu ; 'color' accepté (alias utilisé par certains index)
                                            $columnBadgeType  = $columnBadge['type'] ?? $columnBadge['color'] ?? 'secondary';
                                            $columnBadgeLabel = $columnBadge['label'] ?? $columnValue;
                                        @endphp
                                        <x-mt::badge :label="$columnBadgeLabel" :type="$columnBadgeType" rounded="full" />
                                        @else
                                        {{ Illuminate\Support\Str::ucfirst($columnValue) }}
                                        @endif
                                    </td>
                                    @endforeach

                                    {{-- colonnes cachées --}}
                                    @foreach ($itemHiddenColumns as $column)
                                        <td class="hidden">
                                            <span>{{ $column['value'] }}</span>
                                        </td>
                                    @endforeach

                                    {{-- Cellule TOUJOURS rendue si la colonne Actions existe (alignement),
                                         dropdown seulement si cette ligne a des actions. --}}
                                    @if($anyRowActions)
                                    <td class="right-0 z-10 duration-200 lg:sticky lg:px-4 lg:py-3 focus-within:z-10 group-transition-opacity">
                                        @if(count($rowActions) > 0)
                                        <div class="flex items-center justify-end w-full">
                                            <x-mt::dropdown>
                                                <x-slot:trigger>
                                                    <button title="Plus d'actions" class="py-0 text-lg">
                                                        <x-mt::icon name="ellipsis-vertical" size="md" />
                                                    </button>
                                                </x-slot:trigger>

                                                <x-mt::dropdown.menu>
                                                @foreach ($rowActions as $action)
                                                    @php
                                                        $actionType    = $action['type'] ?? 'route';
                                                        $actionRoute   = $action['route'] ?? '#';
                                                        $actionMethod  = $action['method'] ?? '';
                                                        $actionParams  = $action['params'] ?? '';
                                                        $actionLabel   = $action['label'] ?? '';
                                                        $actionIcon    = $action['icon'] ?? '';
                                                        $actionVariant = $action['variant'] ?? 'default';
                                                    @endphp

                                                    @if ($actionType == 'route')
                                                    {{-- 'target' => '_blank' (PDF, relevés…) : nouvel onglet — le composant
                                                         détecte `target` et n'ajoute PAS wire:navigate (sinon Livewire
                                                         injecterait le binaire comme du HTML). --}}
                                                    @if (($action['target'] ?? null) === '_blank')
                                                    <x-mt::dropdown.item
                                                        target="_blank"
                                                        href="{{ $actionRoute }}"
                                                        :icon="$actionIcon"
                                                        :variant="$actionVariant"
                                                        :label="$actionLabel">
                                                    </x-mt::dropdown.item>
                                                    @else
                                                    <x-mt::dropdown.item
                                                        href="{{ $actionRoute }}"
                                                        :icon="$actionIcon"
                                                        :variant="$actionVariant"
                                                        :label="$actionLabel">
                                                    </x-mt::dropdown.item>
                                                    @endif
                                                    @endif

                                                    @if ($actionType == 'livewire')
                                                        @if(!empty($action['confirm']))
                                                        {{-- Action à confirmer → ouvre le modal stylé (mt-confirm) au lieu d'un wire:click direct. --}}
                                                        <x-mt::dropdown.item
                                                            :dispatch="['name' => 'mt-confirm', 'data' => ['method' => $actionMethod, 'params' => $action['params'] ?? null, 'message' => $action['confirm'], 'variant' => $actionVariant]]"
                                                            :icon="$actionIcon" :variant="$actionVariant" :label="$actionLabel" />
                                                        @else
                                                        <x-mt::dropdown.item
                                                            method="{{ $actionMethod }}({{ $actionParams }})"
                                                            :icon="$actionIcon" :variant="$actionVariant" :label="$actionLabel" />
                                                        @endif
                                                    @endif
                                                @endforeach
                                                </x-mt::dropdown.menu>
                                            </x-mt::dropdown>
                                        </div>
                                        @endif
                                    </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                {{-- ══ MOBILE : cartes (reproduction du concept mobile : vignette + nom + méta
                     + badge de statut + montant à droite ; générique → tous les projets). ══ --}}
                <div class="space-y-1 lg:hidden">
                    @foreach($items as $item)
                        @php
                            $rowActions        = $this->getRowActions($item->id);
                            $itemColumns       = $this->columns($item->id);
                            $itemFirstColumn   = $itemColumns['firstColumn'] ?? [];
                            $itemOthersColumns = $itemColumns['othersColumns'] ?? [];

                            $fcValue     = $itemFirstColumn['value'] ?? '---';
                            $fcMeta      = $itemFirstColumn['metaDatas'] ?? [];
                            $fcImage     = $itemFirstColumn['image'] ?? false;
                            $fcIcon      = $itemFirstColumn['icon'] ?? '';
                            $fcLetters   = $itemFirstColumn['letters'] ?? false;
                            $fcShowThumb = ($itemFirstColumn['showImage'] ?? false) || ($firstColumn['showLetters'] ?? false) || !empty($fcIcon);

                            // ── Répartition des colonnes pour la carte mobile ──
                            // LIGNE 1 = 1re colonne (identité) + actions ⋮, POINT.
                            // LIGNE 2 = TOUTES les autres colonnes, dans leur TYPE D'ORIGINE (badge → badge,
                            // texte → texte, montant → montant), séparées par un trait vertical, scrollable.
                            $cardEditables = [];
                            $__badges = $__rest = [];
                            foreach ($itemOthersColumns as $cf => $col) {
                                if (!empty($col['editable'])) {
                                    $cardEditables[] = ['field' => $cf, 'col' => $col];
                                } elseif (!empty($col['badgeDatas'])) {
                                    $badgeLabel = $col['badgeDatas']['label'] ?? ($col['value'] ?? '');
                                    // Un badge « nombre nu » (compteur « 3 ») est illisible hors tableau
                                    // → préfixe du libellé de colonne (« 3 chambres »). Reste UN badge.
                                    if (is_numeric(trim((string) $badgeLabel)) && !empty($col['label'])) {
                                        $badgeLabel = trim((string) $badgeLabel) . ' ' . mb_strtolower((string) $col['label']);
                                    }
                                    $__badges[] = ['kind' => 'badge', 'label' => $badgeLabel,
                                        'type' => $col['badgeDatas']['type'] ?? $col['badgeDatas']['color'] ?? 'secondary'];
                                } else {
                                    $val = trim((string) ($col['value'] ?? ''));
                                    // Colonne VIDE / placeholder (« - », « — », « --- »…) → on l'ignore
                                    // (sinon séparateurs orphelins « · - · - » sur la ligne 2).
                                    if ($val === '' || preg_match('/^[-–—]+$/u', $val)) { continue; }
                                    // Un texte simple = nombre nu (compteur « 3 ») est incompréhensible sans
                                    // en-tête de colonne → on le préfixe du libellé (« 3 articles »).
                                    if (is_numeric($val) && !empty($col['label'])) {
                                        $val = $val . ' ' . mb_strtolower((string) $col['label']);
                                    }
                                    $__rest[] = ['kind' => ($col['align'] ?? null) === 'right' ? 'amount' : 'meta', 'value' => $val];
                                }
                            }
                            // Les BADGES d'abord, puis le reste (montants/textes) dans l'ordre déclaré.
                            $cardLine2 = array_merge($__badges, $__rest);
                        @endphp

                        {{-- Zébrage : bordure TOUJOURS présente ; le FOND alterne entre deux niveaux
                             de surface (1er = un peu plus soutenu, 2e = surface de base, etc.). --}}
                        <div class="p-3 border rounded-2xl {{ $loop->index % 2 === 0 ? 'mob-zebra-a' : 'mob-zebra-b' }}" style="border-color: rgb(var(--mt-ui-card-border))">
                            <div class="flex items-center gap-3">
                                @if($fcShowThumb)
                                    <x-mt::avatar :name="$fcLetters" :image="$fcImage" :icon="$fcIcon" size="10" rounded="lg" />
                                @endif

                                <div class="flex-1 min-w-0">
                                    <div class="font-semibold truncate mt-text">{{ Illuminate\Support\Str::limit($fcValue, 60) }}</div>
                                    @php
                                        // Sous-titre = métadonnées de la 1re colonne uniquement (le reste
                                        // des colonnes part sur la ligne 2). Jointes par « · », sans libellés.
                                        $__metaBits = array_values(array_filter(array_map(fn ($v) => trim((string) $v), $fcMeta ?: []), fn ($v) => $v !== ''));
                                    @endphp
                                    @if(!empty($__metaBits))
                                        <div class="mt-1 text-xs truncate mt-text-muted">{{ implode(' · ', $__metaBits) }}</div>
                                    @endif
                                </div>

                                @if(count($rowActions) > 0)
                                    <div class="shrink-0">
                                        <x-mt::dropdown>
                                            <x-slot:trigger>
                                                <button title="Plus d'actions" class="mt-btn-icon" style="padding:.35rem"><x-mt::icon name="ellipsis-vertical" size="md" /></button>
                                            </x-slot:trigger>
                                            <x-mt::dropdown.menu>
                                                @foreach ($rowActions as $action)
                                                    @php
                                                        $actionType    = $action['type'] ?? 'route';
                                                        $actionRoute   = $action['route'] ?? '#';
                                                        $actionMethod  = $action['method'] ?? '';
                                                        $actionParams  = $action['params'] ?? '';
                                                        $actionLabel   = $action['label'] ?? '';
                                                        $actionIcon    = $action['icon'] ?? '';
                                                        $actionVariant = $action['variant'] ?? 'default';
                                                    @endphp
                                                    @if ($actionType === 'route')
                                                        @if (($action['target'] ?? null) === '_blank')
                                                            <x-mt::dropdown.item target="_blank" href="{{ $actionRoute }}" :icon="$actionIcon" :variant="$actionVariant" :label="$actionLabel" />
                                                        @else
                                                            <x-mt::dropdown.item href="{{ $actionRoute }}" :icon="$actionIcon" :variant="$actionVariant" :label="$actionLabel" />
                                                        @endif
                                                    @elseif ($actionType === 'livewire')
                                                        @if(!empty($action['confirm']))
                                                            <x-mt::dropdown.item :dispatch="['name' => 'mt-confirm', 'data' => ['method' => $actionMethod, 'params' => $action['params'] ?? null, 'message' => $action['confirm'], 'variant' => $actionVariant]]" :icon="$actionIcon" :variant="$actionVariant" :label="$actionLabel" />
                                                        @else
                                                            <x-mt::dropdown.item method="{{ $actionMethod }}({{ $actionParams }})" :icon="$actionIcon" :variant="$actionVariant" :label="$actionLabel" />
                                                        @endif
                                                    @endif
                                                @endforeach
                                            </x-mt::dropdown.menu>
                                        </x-mt::dropdown>
                                    </div>
                                @endif
                            </div>

                            {{-- LIGNE 2 : toutes les autres colonnes (type d'origine conservé), séparées
                                 par un trait vertical « | », scrollable horizontalement. Texte plus petit
                                 que la ligne 1 ; chaque élément ne rétrécit pas (sinon les badges cassent). --}}
                            @if(!empty($cardLine2))
                                <div class="flex items-center mob-fchips" style="margin-top:.6rem">
                                    @foreach($cardLine2 as $__i => $c)
                                        @if($__i > 0)<span class="mob-fchip-sep" aria-hidden="true">&middot;</span>@endif
                                        @if($c['kind'] === 'badge')
                                            <x-mt::badge :label="$c['label']" :type="$c['type']" rounded="full" class="shrink-0" style="white-space:nowrap; flex:0 0 auto" />
                                        @elseif($c['kind'] === 'amount')
                                            <span class="text-xs font-semibold mt-text" style="white-space:nowrap; flex:0 0 auto; font-variant-numeric: tabular-nums">{{ $c['value'] }}</span>
                                        @else
                                            <span class="text-xs mt-text-muted" style="white-space:nowrap; flex:0 0 auto">{{ $c['value'] }}</span>
                                        @endif
                                    @endforeach
                                </div>
                            @endif

                            @if(!empty($cardEditables))
                                <div class="flex flex-wrap items-center gap-2 pt-3 mt-3 border-t" style="border-color: rgb(var(--mt-ui-card-border))">
                                    @foreach($cardEditables as $e)
                                        @php $ec = $e['col']['editable']; @endphp
                                        <label class="flex items-center gap-2 text-xs mt-text-muted">
                                            {{ Illuminate\Support\Str::ucfirst($e['col']['label'] ?? '') }}
                                            <input type="{{ $ec['type'] ?? 'text' }}" value="{{ $e['col']['value'] ?? '' }}" placeholder="{{ $ec['placeholder'] ?? '—' }}"
                                                wire:change="{{ $ec['method'] ?? 'updateCell' }}({{ $item->id }}, '{{ $e['field'] }}', $event.target.value)"
                                                class="mt-input" style="width:6rem; padding:.35rem .6rem; font-size:.85rem; text-align:right" />
                                        </label>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    @endforeach
                </div>
                @else

                <div class="py-12 text-center">
                    <x-mt::empty-state
                        :title="__('mt-ui::mt-ui.index_empty_title')"
                        icon="list"
                        :description="__('mt-ui::mt-ui.index_empty_hint')"
                    >
                    @if($search || $activeFiltersCount > 0)
                    <x-mt::button variant="primary" icon="arrow-path" wire:click="resetSearchAndFilters">
                        {{ __('mt-ui::mt-ui.index_empty_reset') }}
                    </x-mt::button>
                    @endif
                    </x-mt::empty-state>
                </div>
                @endif

                <!-- Pagination -->
                @if(!empty($this->columns()) && $items->hasPages() && $items->count() > 0)
                <div class="px-2 py-4">
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        @if ($items->total() > 0)
                            <div class="text-xs mt-text-muted">
                                Affichage de {{ $items->firstItem() }} à {{ $items->lastItem() }} sur {{ $items->total() }} éléments
                            </div>
                        @else
                            <div class="text-sm mt-text-muted">
                                Aucun élément à afficher
                            </div>
                        @endif

                        <div class="paginate-nav">
                            {{-- Vue mt-ui (Livewire-aware, tokens/mt-icons) : la vue Tailwind par
                                 défaut de Laravel reste invisible (conteneur `hidden sm:flex`, sm: absent du CSS servi). --}}
                            {{ $items->links('mt::pagination.livewire') }}
                        </div>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>

    {{-- Modals --}}
    @if ($canAddImages)
    <div x-data="{ open: false }"
        x-on:media-updated.window="$wire.$refresh()"
        x-on:open-image-manager.window="
            open = true;
            @this.set('modelClass', $event.detail.modelClass);
            @this.set('modelId', $event.detail.modelId);
        ">
        <x-mt::modal name="image-manager-modal" title="Gérer les médias" x-show="open" icon="mt-icon-image">
            <livewire:mt.forms.media-manager
                :key="'media-'.class_basename($modelClass).'-'.$modelId"
                :model-type="$modelClass"
                :model-id="$modelId"
                kind="image"
                type="photo"
                :multiple="true"
                :allow-delete="true"
            />
        </x-mt::modal>
    </div>
    @endif

    {{-- Point d'extension : partials du composant hôte (modales custom, etc.)
         — même philosophie que extraSections() de BaseForm. --}}
    @foreach ($this->extraPartials() as $extraPartial)
        @include($extraPartial)
    @endforeach

    {{-- Modal de CONFIRMATION stylé (Alpine pur, comme la déconnexion) — fiable, sans entangle
         ni event cross-composant : au clic « Confirmer » on appelle directement $wire[method](params).
         Ouvert par l'event window `mt-confirm` (dispatché par les actions à confirmer). --}}
    <div x-data="{ open: false, method: null, params: null, message: '' }"
         @mt-confirm.window="open = true; method = $event.detail.method; params = $event.detail.params ?? null; message = $event.detail.message ?? ''"
         @keydown.escape.window="open = false"
         x-cloak>
        <div x-show="open" x-transition.opacity class="fixed inset-0" style="z-index:10085; background:rgba(0,0,0,.5); backdrop-filter:blur(2px)" @click="open = false"></div>
        <div x-show="open" class="fixed inset-0 flex items-center justify-center p-4" style="z-index:10090" @click="open = false">
            <div @click.stop
                 x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
                 class="w-full max-w-sm p-6 text-center shadow-2xl rounded-2xl"
                 style="background:rgb(var(--mt-ui-card-bg)); border:1px solid rgb(var(--mt-ui-card-border))">
                <div class="grid mx-auto mb-3 rounded-2xl place-items-center" style="width:54px;height:54px;background:rgb(var(--mt-danger) / .12); color:rgb(var(--mt-danger))">
                    <x-mt::icon name="trash-x" />
                </div>
                <h3 class="text-base font-semibold mt-text">{{ __('mt-ui::mt-ui.delete_confirm_title') }}</h3>
                <p class="mt-1.5 mb-5 text-sm mt-text-muted" x-text="message"></p>
                <div class="flex justify-center gap-2">
                    <x-mt::button variant="ghost" type="button" x-on:click="open = false" class="min-w-24">{{ __('mt-ui::mt-ui.cancel') }}</x-mt::button>
                    <x-mt::button variant="danger" type="button" x-on:click="$wire[method](params); open = false" class="min-w-24">{{ __('mt-ui::mt-ui.confirm') }}</x-mt::button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('livewire:initialized', () => {
            Livewire.on('hide-flash-after-delay', () => {
                setTimeout(() => { @this.hideFlash(); }, 5000);
            });
        });
        {{-- Fermeture du panneau Filtres : gérée par Alpine (@click.outside), plus de handler global. --}}
    </script>

</div>