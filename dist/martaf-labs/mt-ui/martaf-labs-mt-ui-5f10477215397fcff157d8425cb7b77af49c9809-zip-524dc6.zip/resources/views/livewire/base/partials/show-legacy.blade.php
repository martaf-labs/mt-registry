    @php
        $mainItems = $showDatas['fields'] ?? [];
        $medias = $showDatas['medias'] ?? [];
        $actions = $this->getActions();
        $metaDatas = $showDatas['metaDatas'] ?? [];
        $hasActions = count($actions) > 0;

        $mainItemsCount = count($mainItems);
        $mediasCount = count($medias);
        $metaDatasCount = count($metaDatas);
    @endphp

    <div class="min-h-screen py-6 mt-bg">
        <div class="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
            <!-- En-tête avec breadcrumbs -->
            <x-mt::breadcrumbs :title="$title" :datas="$navItems ?? []" />

            <!-- Messages flash -->
            @if (session()->has('success'))
            <div class="p-4 mb-6 rounded-lg mt-alert mt-alert-success">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-check-circle"></i>
                    <span>{{ session('success') }}</span>
                </div>
            </div>
            @endif

            @if (session()->has('error'))
            <div class="p-4 mb-6 rounded-lg mt-alert mt-alert-danger">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-exclamation-triangle"></i>
                    <span>{{ session('error') }}</span>
                </div>
            </div>
            @endif

            <!-- Affichage si aucune donnée -->
            @if(!$data)
            <div class="p-8 text-center rounded-lg mt-card">
                <div class="flex items-center justify-center w-24 h-24 mx-auto mb-4 rounded-full mt-bg-secondary">
                    <x-mt::icon name="exclamation-triangle" class="size-12 mt-text-muted"/>
                </div>
                <h3 class="mb-2 text-lg font-medium mt-text">Élément non trouvé</h3>
                <p class="mb-4 mt-text-muted">L'élément que vous recherchez n'existe pas ou a été supprimé.</p>
                <x-mt::button icon="arrow-left" href="{{ mt_get_route($model_plural.'_index') }}" variant="primary" wire:navigate>
                    Retour à la liste
                </x-mt::button>
            </div>
            @else
            <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
                <!-- COLONNE GAUCHE -->
                <div class="space-y-6 lg:col-span-2">
                    @if($mediasCount > 0)
                        @php
                            $mainImage = $medias['image'] ?? [];
                            $othersImages = $medias['images'] ?? [];
                        @endphp

                        <div class="max-w-6xl px-4 mx-auto">
                            <div class="rounded-xl">
                                <div class="grid gap-6">
                                    @if(isset($mainImage['url']))
                                    <div class="relative group">
                                        <img
                                            id="main-image"
                                            class="w-full h-auto max-w-full rounded-lg object-cover object-center md:h-[480px] image-transition cursor-zoom-in"
                                            src="{{ $mainImage['url'] }}"
                                            alt="Image principale de la galerie"
                                        />
                                        <div class="absolute flex space-x-2 transition-opacity duration-300 opacity-0 bottom-4 right-4 group-hover:opacity-100">
                                            <button class="p-2 rounded-full shadow-md mt-card mt-btn-icon">
                                                <x-mt::icon name="arrow-down" class="mt-text-warning"/>
                                            </button>
                                        </div>
                                    </div>
                                    @endif

                                    @if(count($othersImages) > 1)
                                        <div class="flex p-2 space-x-4 overflow-x-auto scrollbar-thin">
                                            @foreach ($othersImages as $index => $image)
                                                <div class="relative flex-shrink-0">
                                                    <img
                                                        src="{{ $image['src'] ?? '' }}"
                                                        class="object-cover object-center w-20 h-20 rounded-lg cursor-pointer image-transition @if($loop->first) active-image @endif"
                                                        alt="{{ $image['title'] ?? 'Image galerie' }}"
                                                        onclick="changeImage('{{ $image['src'] ?? '' }}', '{{ $image['title'] ?? 'Image galerie' }}', this, {{ $index }})"
                                                    />
                                                </div>
                                            @endforeach
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endif

                    @if($mainItemsCount > 0)
                        <div class="p-3 rounded-xl mt-card">
                            <fieldset>
                                <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                                    @foreach($mainItems as $item)
                                        @php
                                            $itemType  = $item['type'] ?? 'text';
                                            $itemLabel = $item['label'] ?? '';
                                            $itemName  = $item['name'] ?? '';
                                            $itemCol   = $item['col'] ?? 12;
                                            $itemValue = $item['value'] ?? 'N/A';
                                        @endphp

                                        <div class="@if($itemCol == 12) md:col-span-2 @elseif($itemCol == 6) md:col-span-1 @elseif($itemCol == 4) md:col-span-1 @elseif($itemCol == 3) md:col-span-1 @endif space-y-2 p-2 rounded-md mt-bg-secondary">
                                            <div class="flex flex-col">
                                                <span class="mb-1 text-sm font-medium mt-text-muted">
                                                    {{ $itemLabel }}
                                                </span>
                                                <div class="text-base mt-text">
                                                    {!! $itemValue !!}
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </fieldset>
                        </div>
                    @endif
                </div>

                <!-- COLONNE DROITE : Métadonnées et actions -->
                <div class="space-y-6">
                    @if($metaDatasCount > 0)
                    <div class="p-6 rounded-xl mt-card">
                        <div class="flex items-center gap-3 mb-6">
                            <h2 class="text-lg font-semibold mt-text">Métadonnées</h2>
                        </div>
                        <div class="space-y-3 text-sm">
                            @foreach($metaDatas as $key => $data)
                            <div class="flex flex-col items-start justify-start">
                                <span class="mt-text-muted">{{ $data['label'] ?? '' }}</span>
                                <span class="font-medium mt-text">{{ $data['value'] ?? '' }}</span>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    @endif

                    @if($hasActions)
                    <div class="sticky p-6 rounded-xl mt-card top-6">
                        <div class="flex items-center gap-3 mb-6">
                            <h2 class="text-lg font-semibold mt-text">Actions</h2>
                        </div>
                        <div class="space-y-3">
                            @foreach($actions as $actionKey => $action)
                                @php
                                    $route   = $action['route'] ?? '#';
                                    $method  = $action['method'] ?? '#';
                                    $variant = $action['variant'] ?? 'ghost';
                                    $icon    = $action['icon'] ?? null;
                                @endphp

                                @if($action['type'] == 'routeAction')
                                    <x-mt::button href="{{ $route }}" wire:navigate variant="{{ $variant }}" class="w-full">
                                        <i class="{{ $icon }}"></i>
                                        {{ $action['label'] ?? '' }}
                                    </x-mt::button>
                                @endif

                                @if($action['type'] == 'methodAction')
                                    <x-mt::button variant="{{ $variant }}" wire:click='{{ $method }}' class="w-full">
                                        <i class="{{ $icon }}"></i>
                                        {{ $action['label'] ?? '' }}
                                    </x-mt::button>
                                @endif
                            @endforeach
                        </div>
                    </div>
                    @endif
                </div>
            </div>
            @endif
        </div>

        @if($model && $model === 'engin')
            {{-- modal de gestion de caracteristiques pour les engins --}}
        @endif  

    </div>

    @push('styles')
    <style>
        .prose { max-width: none; }
        .prose img { border-radius: 0.5rem; margin: 1rem 0; }
        .prose p { margin-bottom: 1rem; }
        .prose ul { list-style-type: disc; padding-left: 1.5rem; }
        .prose ol { list-style-type: decimal; padding-left: 1.5rem; }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.5rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .images-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(3rem, 1fr));
            gap: 0.5rem;
        }
        .image-item { position: relative; aspect-ratio: 1; }
        .image-item img {
            width: 100%; height: 100%;
            object-fit: cover;
            border-radius: 0.375rem;
            border: 1px solid rgb(var(--mt-ui-card-border));
        }

        .scrollbar-thin::-webkit-scrollbar { width: 6px; height: 6px; }
        .scrollbar-thin::-webkit-scrollbar-track { background: transparent; }
        .scrollbar-thin::-webkit-scrollbar-thumb { background: rgb(var(--mt-ui-card-border)); border-radius: 3px; }
        .scrollbar-thin { scrollbar-width: thin; scrollbar-color: rgb(var(--mt-ui-card-border)) transparent; }
    </style>
    @endpush

    <script>
        const images = @json($othersImages ?? []);
        let currentImageIndex = 0;

        function changeImage(src, alt, element, index = null) {
            const mainImage = document.getElementById('main-image');
            if (index !== null) { currentImageIndex = index; }
            else { currentImageIndex = images.findIndex(img => img.src === src); }
            mainImage.style.opacity = '0.7';
            setTimeout(() => {
                mainImage.src = src;
                mainImage.alt = alt;
                if (currentImageIndex !== -1 && images[currentImageIndex]) {
                    const imageTitle = document.getElementById('image-title');
                    const imageDescription = document.getElementById('image-description');
                    if (imageTitle) imageTitle.textContent = images[currentImageIndex].title || 'Image';
                    if (imageDescription) imageDescription.textContent = images[currentImageIndex].description || '';
                }
                mainImage.style.opacity = '1';
            }, 150);
            updateActiveThumbnail();
        }

        function updateActiveThumbnail() {
            const thumbnails = document.querySelectorAll('.flex.overflow-x-auto img');
            thumbnails.forEach((thumb, index) => {
                thumb.classList.remove('active-image');
                if (index === currentImageIndex) { thumb.classList.add('active-image'); }
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            if (images.length > 0) { currentImageIndex = 0; updateActiveThumbnail(); }
        });
    </script>

