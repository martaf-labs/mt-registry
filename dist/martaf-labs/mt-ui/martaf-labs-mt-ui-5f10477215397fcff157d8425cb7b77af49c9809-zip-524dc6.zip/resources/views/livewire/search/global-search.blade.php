{{--
    Composant Global Search — mt::livewire.global-search
    ─────────────────────────────────────────────────────
    Usage : <livewire:mt.global-search />

    Comportement :
    • Le trigger est un bouton (ou faux champ) dans le header
    • Clic sur le trigger  → ouvre le modal
    • Ctrl+K / ⌘K          → ouvre le modal
    • Toute la recherche se passe DANS le modal
    • Esc / clic backdrop  → ferme le modal

    THÈME : tokens --mt-* + icônes mt-icons SVG. Les icônes de catégorie fournies
    par les modèles (searchIcon) sont pré-rendues côté serveur en SVG (champ
    iconHtml) et injectées via Alpine x-html — Alpine ne peut pas rendre un SVG
    mt-icons depuis un simple nom de chaîne.
--}}

@php
    $debounce = config('mt-search.debounce', 300);
    $minChars = config('mt-search.min_chars', 2);
@endphp


<div
    x-data="mtSearch()"
    x-init="init()"
    @keydown.window.ctrl.k.prevent="openModal()"
    @keydown.window.meta.k.prevent="openModal()"
    @keydown.window.escape="closeModal()"
    style="@if(!mt_has_search()) display:none @endif"
>

    {{-- ═══════════════════════════════════════════════════
         TRIGGER — bouton dans le header
         ═══════════════════════════════════════════════════ --}}

    {{-- Desktop : faux champ cliquable --}}
    <button
        @click="openModal()"
        type="button"
        class="items-center hidden gap-2 text-sm search-trigger md:flex"
        aria-label="{{ __('mt-ui::mt-ui.search') }}"
        aria-haspopup="dialog"
    >
        <span class="mt-text-muted"><x-mt::icon name="magnifying-glass" size="sm" /></span>
        <span class="mt-text-muted flex-1 text-left">{{ __('mt-ui::mt-ui.search') }}…</span>
        <div class="flex items-center gap-0.5 ml-2">
            <kbd class="search-kbd">⌘</kbd><kbd class="search-kbd">K</kbd>
        </div>
    </button>

    {{-- Mobile : icône seule --}}
    <button
        @click="openModal()"
        type="button"
        class="p-2 transition-colors rounded-lg md:hidden mt-text"
        aria-label="{{ __('mt-ui::mt-ui.search') }}"
    >
        <x-mt::icon name="magnifying-glass" size="sm" />
    </button>

    {{-- ═══════════════════════════════════════════════════
         MODAL — téléporté sur <body>
         ═══════════════════════════════════════════════════ --}}

    {{-- Backdrop --}}
    <div
        x-show="modalOpen"
        x-transition:enter="transition-opacity ease-out duration-200"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition-opacity ease-in duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="fixed inset-0 bg-black/60 backdrop-blur-sm z-[1000]"
        @click="closeModal()"
        aria-hidden="true"
        x-cloak
    ></div>

    {{-- Panel --}}
    <div
        x-show="modalOpen"
        x-transition:enter="transition ease-out duration-250"
        x-transition:enter-start="opacity-0 sm:scale-95 sm:-translate-y-3 translate-y-full"
        x-transition:enter-end="opacity-100 sm:scale-100 sm:translate-y-0 translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 sm:scale-100 sm:translate-y-0 translate-y-0"
        x-transition:leave-end="opacity-0 sm:scale-95 sm:-translate-y-3 translate-y-full"
        class="search-modal fixed z-[1001]
               bottom-0 inset-x-0 rounded-t-3xl
               sm:bottom-auto sm:inset-x-auto sm:rounded-2xl
               sm:top-[6vh] sm:left-1/2 sm:-translate-x-1/2
               sm:w-[640px] sm:max-w-[calc(100vw-2rem)]
               w-full max-h-[92vh] sm:max-h-[82vh]
               flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-label="{{ __('mt-ui::mt-ui.search') }}"
        x-cloak
    >

        {{-- Handle drag (mobile) --}}
        <div class="flex justify-center flex-shrink-0 pt-3 pb-1 sm:hidden">
            <div class="w-10 h-1 rounded-full" style="background: rgba(var(--mt-text), .2)"></div>
        </div>

        {{-- ── Barre de recherche ── --}}
        <div class="flex items-center gap-3 px-4 py-3.5 flex-shrink-0" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
            {{-- Spinner ou icône --}}
            <div class="flex items-center justify-center flex-shrink-0 w-5">
                <template x-if="$wire.searching">
                    <svg class="w-4 h-4 animate-spin" style="color: rgb(var(--mt-primary))" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                    </svg>
                </template>
                <template x-if="!$wire.searching">
                    <span class="mt-text-muted"><x-mt::icon name="magnifying-glass" size="sm" /></span>
                </template>
            </div>

            {{-- Input --}}
            <input
                x-ref="modalInput"
                type="text"
                wire:model.live.debounce.{{ $debounce }}ms="query"
                @keydown.arrow-down.prevent="navigateDown()"
                @keydown.arrow-up.prevent="navigateUp()"
                @keydown.enter.prevent="selectFocused() || goToFullPage()"
                @keydown.escape.prevent="closeModal()"
                placeholder="{{ __('mt-ui::mt-ui.search_modal_ph') }}"
                class="search-modal-input flex-1 min-w-0 text-base bg-transparent outline-none"
                autocomplete="off"
                spellcheck="false"
            >

            {{-- Clear --}}
            <button
                x-show="$wire.query"
                @click="$wire.set('query', ''); $refs.modalInput.focus()"
                class="flex items-center justify-center flex-shrink-0 rounded-full w-7 h-7 mt-text-muted transition-opacity hover:opacity-70"
                x-cloak
                aria-label="{{ __('mt-ui::mt-ui.search_clear') }}"
            >
                <x-mt::icon name="x-mark" size="sm" />
            </button>

            {{-- Esc hint (desktop) --}}
            <kbd class="flex-shrink-0 hidden search-kbd-escape sm:inline-flex">Esc</kbd>
        </div>

        {{-- ── Filtres catégories ── --}}
        <div
            x-data="{ categories: @js($this->categories) }"
            x-show="categories.length > 1"
            class="flex items-center gap-1.5 px-4 py-2.5 overflow-x-auto flex-shrink-0 scrollbar-none"
            style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))"
        >
            <button
                @click="$wire.set('activeCategory', null)"
                class="search-filter-btn"
                :class="$wire.activeCategory === null ? 'active' : ''">
                <span class="mr-1.5 inline-flex"><x-mt::icon name="list" size="xs" /></span>{{ __('mt-ui::mt-ui.search_all') }}
            </button>
            <template x-for="cat in categories" :key="cat.key">
                <button
                    @click="$wire.set('activeCategory', cat.key)"
                    class="search-filter-btn"
                    :class="$wire.activeCategory === cat.key ? 'active' : ''">
                    <span class="mr-1.5 inline-flex" x-html="cat.iconHtml"></span>
                    <span x-text="cat.label"></span>
                </button>
            </template>
        </div>

        {{-- ── Corps scrollable ── --}}
        <div class="flex-1 min-h-0 overflow-y-auto search-modal-body">

            {{-- État vide : historique ou prompt --}}
            <template x-if="$wire.query.length < {{ $minChars }}">
                <div>
                    <template x-if="history.length > 0">
                        <div class="p-3">
                            <div class="flex items-center justify-between px-2 py-2">
                                <span class="text-[11px] font-semibold uppercase tracking-wider mt-text-muted">
                                    {{ __('mt-ui::mt-ui.search_recent') }}
                                </span>
                                <button @click="clearHistory()"
                                        class="text-xs mt-text-primary transition-opacity hover:opacity-70">
                                    {{ __('mt-ui::mt-ui.search_clear_all') }}
                                </button>
                            </div>
                            <template x-for="(item, idx) in history" :key="idx">
                                <a :href="item.url" wire:navigate
                                   @click="closeModal()"
                                   class="search-result-item group">
                                    <div class="flex items-center w-full gap-3">
                                        <div class="flex items-center justify-center flex-shrink-0 w-9 h-9 rounded-xl mt-text-muted"
                                             style="background: rgba(var(--mt-text), .06)">
                                            <x-mt::icon name="clock" size="sm" />
                                        </div>
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm font-medium mt-text truncate" x-text="item.title"></p>
                                            <p x-show="item.category"
                                               class="text-xs mt-text-muted truncate"
                                               x-text="item.category"></p>
                                        </div>
                                        <button @click.prevent.stop="removeFromHistory(idx)"
                                                class="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg mt-text-muted transition-all hover:opacity-70"
                                                aria-label="{{ __('mt-ui::mt-ui.search_clear') }}">
                                            <x-mt::icon name="x-mark" size="xs" />
                                        </button>
                                    </div>
                                </a>
                            </template>
                        </div>
                    </template>
                    <template x-if="history.length === 0">
                        <div class="px-4 py-16 text-center mt-text-muted">
                            <span class="mb-4 inline-flex opacity-30" style="font-size:0"><x-mt::icon name="magnifying-glass" size="2xl" /></span>
                            <p class="text-sm font-medium mt-text">{{ __('mt-ui::mt-ui.search_prompt_title') }}</p>
                            <p class="mt-1 text-xs mt-text-muted">
                                {{ __('mt-ui::mt-ui.search_empty_hint', ['min' => $minChars]) }}
                            </p>
                        </div>
                    </template>
                </div>
            </template>

            {{-- Skeleton --}}
            <template x-if="$wire.searching && $wire.results.length === 0 && $wire.query.length >= {{ $minChars }}">
                <div class="p-4 space-y-3">
                    <template x-for="i in 5">
                        <div class="flex items-center gap-3 px-2 animate-pulse">
                            <div class="flex-shrink-0 w-9 h-9 rounded-xl" style="background: rgba(var(--mt-text), .08)"></div>
                            <div class="flex-1 space-y-2">
                                <div class="h-3.5 rounded-full w-2/3" style="background: rgba(var(--mt-text), .08)"></div>
                                <div class="h-2.5 rounded-full w-1/3" style="background: rgba(var(--mt-text), .05)"></div>
                            </div>
                            <div class="w-10 h-2.5 rounded-full" style="background: rgba(var(--mt-text), .05)"></div>
                        </div>
                    </template>
                </div>
            </template>

            {{-- Aucun résultat --}}
            <template x-if="!$wire.searching && $wire.results.length === 0 && $wire.query.length >= {{ $minChars }}">
                <div class="px-4 py-16 text-center">
                    <div class="flex items-center justify-center w-16 h-16 mx-auto mb-4 rounded-3xl mt-text-muted"
                         style="background: rgba(var(--mt-text), .06)">
                        <x-mt::icon name="magnifying-glass" size="xl" />
                    </div>
                    <p class="text-base font-semibold mt-text">{{ __('mt-ui::mt-ui.search_no_results_title') }}</p>
                    <p class="text-sm mt-text-muted mt-1.5">
                        {{ __('mt-ui::mt-ui.search_for') }}
                        <span class="font-semibold mt-text" x-text="'«' + $wire.query + '»'"></span>
                    </p>
                    <button x-show="$wire.activeCategory"
                            @click="$wire.set('activeCategory', null)"
                            class="search-inline-btn px-4 py-2 mt-4 text-sm font-medium rounded-xl">
                        <span class="mr-1.5 inline-flex"><x-mt::icon name="x-mark" size="xs" /></span>{{ __('mt-ui::mt-ui.search_remove_category') }}
                    </button>
                </div>
            </template>

            {{-- Résultats groupés par catégorie --}}
            <template x-if="!$wire.searching && $wire.results.length > 0 && $wire.query.length >= {{ $minChars }}">
                <div class="py-1.5">
                    <template x-for="(group, gIdx) in $wire.results" :key="gIdx">
                        <div class="mb-2">

                            {{-- En-tête catégorie --}}
                            <div class="search-group-header">
                                <div class="flex items-center gap-2">
                                    <span class="search-cat-badge" :class="'badge-' + group.color">
                                        <span x-html="group.iconHtml"></span>
                                    </span>
                                    <span class="text-[11px] font-semibold uppercase tracking-wider mt-text-muted"
                                          x-text="group.category"></span>
                                </div>
                                <span class="text-[10px] mt-text-muted"
                                      x-text="group.count + ' ' + (group.count > 1 ? '{{ __('mt-ui::mt-ui.search_result_plural') }}' : '{{ __('mt-ui::mt-ui.search_result_singular') }}')"></span>
                            </div>

                            {{-- Items --}}
                            <template x-for="(item, iIdx) in group.items" :key="item.id">
                                <a
                                    :href="item.url" wire:navigate
                                    @click="addToHistory(item); closeModal()"
                                    class="search-result-item group"
                                    :class="{ 'focused': isFocused(gIdx, iIdx) }"
                                >
                                    <div class="flex items-center w-full gap-3">
                                        {{-- Avatar --}}
                                        <div class="flex-shrink-0">
                                            <template x-if="item.avatar">
                                                <img :src="item.avatar"
                                                     class="object-cover w-9 h-9 rounded-xl"
                                                     :alt="item.title?.replace(/<[^>]*>/g,'')">
                                            </template>
                                            <template x-if="!item.avatar">
                                                <div class="flex items-center justify-center text-sm font-bold text-white w-9 h-9 rounded-xl"
                                                     :class="'bg-cat-' + group.color"
                                                     x-text="item.avatar_text || item.title?.replace(/<[^>]*>/g,'')?.charAt(0)?.toUpperCase()">
                                                </div>
                                            </template>
                                        </div>

                                        {{-- Texte --}}
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm font-medium mt-text truncate" x-html="item.title"></p>
                                            <p x-show="item.subtitle"
                                               class="text-xs mt-text-muted truncate mt-0.5"
                                               x-html="item.subtitle"></p>
                                        </div>

                                        {{-- Meta --}}
                                        <div x-show="item.meta" class="flex-shrink-0 hidden sm:block">
                                            <span class="text-xs mt-text-muted whitespace-nowrap" x-text="item.meta"></span>
                                        </div>

                                        {{-- Flèche --}}
                                        <div class="items-center justify-center flex-shrink-0 hidden w-6 h-6 transition-all rounded-lg group-hover:flex mt-text-muted"
                                             style="background: rgba(var(--mt-text), .06)">
                                            <x-mt::icon name="arrow-right" size="xs" />
                                        </div>
                                    </div>
                                </a>
                            </template>

                            {{-- Voir tout dans cette catégorie --}}
                            <button
                                x-show="group.count > group.items.length"
                                @click="$wire.set('activeCategory', group.class); goToFullPage(); closeModal()"
                                class="search-seeall w-full mx-1.5 px-3.5 py-2 text-xs text-left font-medium rounded-xl"
                                x-text="'{{ __('mt-ui::mt-ui.search_see_all', ['count' => '__C__', 'category' => '__CAT__']) }}'.replace('__C__', group.count).replace('__CAT__', group.category)">
                            </button>
                        </div>
                    </template>
                </div>
            </template>

        </div>

        {{-- ── Footer ── --}}
        <div class="flex-shrink-0 search-modal-footer">
            <div x-show="$wire.query.length < {{ $minChars }}" class="text-[10px] mt-text-muted">
                Created by martaf
            </div>

            {{-- Raccourcis --}}
            <div class="flex items-center gap-3 text-[10px] mt-text-muted">
                <span x-show="$wire.results.length > 0">
                    <kbd class="search-kbd-sm">↑↓</kbd> {{ __('mt-ui::mt-ui.search_kbd_navigate') }}
                </span>
                <span x-show="$wire.results.length > 0">
                    <kbd class="search-kbd-sm">↵</kbd> {{ __('mt-ui::mt-ui.search_kbd_open') }}
                </span>
                <span class="hidden sm:inline">
                    <kbd class="search-kbd-sm">Esc</kbd> {{ __('mt-ui::mt-ui.search_kbd_close') }}
                </span>
            </div>
        </div>

    </div>

    {{-- ═══════════════════════════════════════════════════
         STYLES — tokens --mt-* (light/dark auto). La palette
         catégorielle badge-*/bg-cat-* (couleurs de DONNÉES) reste fixe.
         ═══════════════════════════════════════════════════ --}}
    <style>
        /* ── Trigger bouton ── */
        .search-trigger {
            width: 100%;
            max-width: 264px;
            padding: 7px 12px;
            background: rgb(var(--mt-ui-input-bg));
            border: 1px solid rgb(var(--mt-ui-input-border));
            border-radius: 10px;
            cursor: pointer;
            transition: border-color .15s, box-shadow .15s, background .15s;
        }
        .search-trigger:hover {
            border-color: rgba(var(--mt-primary), .4);
            box-shadow: 0 1px 4px rgba(0,0,0,.06);
        }

        /* ── Modal ── */
        .search-modal {
            background: rgb(var(--mt-ui-card-bg));
            border: 1px solid rgb(var(--mt-ui-card-border));
            box-shadow: 0 32px 80px -8px rgba(0,0,0,.30), 0 8px 24px -4px rgba(0,0,0,.12);
        }
        @media (max-width: 639px) {
            .search-modal { border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; }
        }
        .search-modal-input { color: rgb(var(--mt-text)); caret-color: rgb(var(--mt-primary)); }
        .search-modal-input::placeholder { color: rgba(var(--mt-text), .45); }

        /* Scrollbar modale */
        .search-modal-body { scrollbar-width: thin; scrollbar-color: rgba(var(--mt-text), .2) transparent; }
        .search-modal-body::-webkit-scrollbar { width: 4px; }
        .search-modal-body::-webkit-scrollbar-thumb { background: rgba(var(--mt-text), .2); border-radius: 2px; }

        /* ── Group header ── */
        .search-group-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 8px 16px 4px;
        }

        /* ── Result item ── */
        .search-result-item {
            display: flex; align-items: center;
            padding: 10px 10px;
            margin: 1px 6px;
            cursor: pointer; text-decoration: none;
            border-radius: 12px;
            transition: background .1s;
        }
        .search-result-item:hover,
        .search-result-item.focused { background: rgba(var(--mt-text), .05); }
        .search-result-item.focused { box-shadow: inset 0 0 0 2px rgba(var(--mt-primary), .3); }

        /* ── Boutons inline (retirer filtre) ── */
        .search-inline-btn {
            color: rgb(var(--mt-primary));
            background: rgba(var(--mt-primary), .1);
            transition: background .15s;
        }
        .search-inline-btn:hover { background: rgba(var(--mt-primary), .18); }

        /* ── Voir tout ── */
        .search-seeall {
            color: rgb(var(--mt-primary));
            transition: background .15s;
        }
        .search-seeall:hover { background: rgba(var(--mt-primary), .08); }

        /* ── Category badge (palette de DONNÉES — fixe) ── */
        .search-cat-badge {
            width: 18px; height: 18px; border-radius: 5px;
            display: inline-flex; align-items: center; justify-content: center;
        }
        .badge-blue   { background:#dbeafe; color:#2563eb; }
        .badge-green  { background:#dcfce7; color:#16a34a; }
        .badge-purple { background:#ede9fe; color:#7c3aed; }
        .badge-orange { background:#ffedd5; color:#ea580c; }
        .badge-red    { background:#fee2e2; color:#dc2626; }
        .badge-teal   { background:#ccfbf1; color:#0d9488; }
        .badge-pink   { background:#fce7f3; color:#db2777; }
        .badge-gray   { background:#f3f4f6; color:#6b7280; }
        .dark .badge-blue   { background:rgba(37,99,235,.2);   color:#93c5fd; }
        .dark .badge-green  { background:rgba(22,163,74,.2);   color:#86efac; }
        .dark .badge-purple { background:rgba(124,58,237,.2);  color:#c4b5fd; }
        .dark .badge-orange { background:rgba(234,88,12,.2);   color:#fdba74; }
        .dark .badge-red    { background:rgba(220,38,38,.2);   color:#fca5a5; }
        .dark .badge-teal   { background:rgba(13,148,136,.2);  color:#5eead4; }
        .dark .badge-pink   { background:rgba(219,39,119,.2);  color:#f9a8d4; }
        .dark .badge-gray   { background:#374151; color:#9ca3af; }

        /* ── Avatar colors (palette de DONNÉES — fixe) ── */
        .bg-cat-blue   { background:#3b82f6; }
        .bg-cat-green  { background:#22c55e; }
        .bg-cat-purple { background:#8b5cf6; }
        .bg-cat-orange { background:#f97316; }
        .bg-cat-red    { background:#ef4444; }
        .bg-cat-teal   { background:#14b8a6; }
        .bg-cat-pink   { background:#ec4899; }
        .bg-cat-gray   { background:#6b7280; }

        /* ── Highlight ── */
        mark.search-highlight {
            background: rgba(var(--mt-warning), .3);
            color: inherit;
            border-radius: 2px; padding: 0 1px; font-weight: 600;
        }

        /* ── Kbd ── */
        .search-kbd {
            display:inline-flex; align-items:center; justify-content:center;
            padding:1px 5px; font-size:10px; font-family:monospace;
            background: rgba(var(--mt-text), .06); color: rgba(var(--mt-text), .6);
            border:1px solid rgb(var(--mt-ui-card-border)); border-bottom-width:2px;
            border-radius:4px; line-height:1;
        }
        .search-kbd-sm {
            display:inline-flex; align-items:center; justify-content:center;
            padding:1px 4px; font-size:9px; font-family:monospace;
            background: rgba(var(--mt-text), .06); color: rgba(var(--mt-text), .6);
            border:1px solid rgb(var(--mt-ui-card-border)); border-bottom-width:2px;
            border-radius:3px; line-height:1.4;
        }
        .search-kbd-escape {
            display:inline-flex; align-items:center; justify-content:center;
            padding:2px 8px; font-size:11px;
            background: rgba(var(--mt-text), .06); color: rgba(var(--mt-text), .6);
            border:1px solid rgb(var(--mt-ui-card-border)); border-bottom-width:2px; border-radius:6px;
        }

        /* ── Filter buttons ── */
        .search-filter-btn {
            display:inline-flex; align-items:center;
            padding:4px 10px; border-radius:20px;
            font-size:11px; font-weight:500; white-space:nowrap;
            color: rgba(var(--mt-text), .65);
            background: rgba(var(--mt-text), .05);
            border:1px solid transparent;
            cursor:pointer; transition:all .15s;
            flex-shrink: 0;
        }
        .search-filter-btn:hover { background: rgba(var(--mt-text), .1); color: rgb(var(--mt-text)); }
        .search-filter-btn.active {
            background: rgba(var(--mt-primary), .1);
            color: rgb(var(--mt-primary));
            border-color: rgba(var(--mt-primary), .3);
        }

        /* ── Modal footer ── */
        .search-modal-footer {
            display:flex; align-items:center; justify-content:space-between;
            padding:10px 16px;
            border-top:1px solid rgb(var(--mt-ui-card-border));
            background: rgba(var(--mt-text), .02);
        }

        /* ── Safe area (iPhone notch) ── */
        @supports (padding-bottom: env(safe-area-inset-bottom)) {
            @media (max-width: 639px) {
                .search-modal-footer { padding-bottom: calc(10px + env(safe-area-inset-bottom, 0px)); }
            }
        }

        .scrollbar-none { scrollbar-width:none; }
        .scrollbar-none::-webkit-scrollbar { display:none; }

        [x-cloak] { display: none !important; }
    </style>

    {{-- ═══════════════════════════════════════════════════
         ALPINE CONTROLLER
         ═══════════════════════════════════════════════════ --}}
    <script>
        function mtSearch() {
            return {
                modalOpen:    false,
                focusedGroup: 0,
                focusedItem:  -1,
                history:      [],

                init() {
                    this.loadHistory();
                },

                // ── Modal ────────────────────────────────────────────────────────
                openModal() {
                    this.modalOpen    = true;
                    this.focusedGroup = 0;
                    this.focusedItem  = -1;
                    document.body.style.overflow = 'hidden';
                    this.$nextTick(() => {
                        if (this.$refs.modalInput) {
                            this.$refs.modalInput.focus();
                        }
                    });
                },

                closeModal() {
                    this.modalOpen    = false;
                    this.focusedGroup = 0;
                    this.focusedItem  = -1;
                    document.body.style.overflow = '';
                },

                // ── Navigation clavier ───────────────────────────────────────────
                navigateDown() {
                    const results = this.$wire.results;
                    if (!results || !results.length) return;
                    const group = results[this.focusedGroup];
                    if (!group) return;
                    if (this.focusedItem < group.items.length - 1) {
                        this.focusedItem++;
                    } else if (this.focusedGroup < results.length - 1) {
                        this.focusedGroup++;
                        this.focusedItem = 0;
                    }
                },

                navigateUp() {
                    if (this.focusedItem > 0) {
                        this.focusedItem--;
                    } else if (this.focusedGroup > 0) {
                        this.focusedGroup--;
                        const prev = this.$wire.results[this.focusedGroup];
                        this.focusedItem = prev ? prev.items.length - 1 : 0;
                    } else {
                        this.focusedItem = -1;
                    }
                },

                isFocused(gIdx, iIdx) {
                    return this.focusedGroup === gIdx && this.focusedItem === iIdx;
                },

                selectFocused() {
                    const results = this.$wire.results;
                    if (!results || !results.length || this.focusedItem < 0) return false;
                    const group = results[this.focusedGroup];
                    if (!group) return false;
                    const item  = group.items[this.focusedItem];
                    if (!item)  return false;
                    this.addToHistory(item);
                    window.location.href = item.url;
                    this.closeModal();
                    return true;
                },

                // ── Page complète ────────────────────────────────────────────────
                goToFullPage() {
                    const q = this.$wire.query;
                    if (!q || q.length < {{ $minChars }}) return;
                    const cat = this.$wire.activeCategory
                        ? '&category=' + encodeURIComponent(this.$wire.activeCategory)
                        : '';
                    window.location.href = '{{ route("search.index") }}?q=' + encodeURIComponent(q) + cat;
                },

                // ── Historique localStorage ───────────────────────────────────────
                loadHistory() {
                    try {
                        const raw = localStorage.getItem('mt_search_history');
                        this.history = raw ? JSON.parse(raw) : [];
                    } catch {
                        this.history = [];
                    }
                },

                addToHistory(item) {
                    const entry = {
                        title:    item.title?.replace(/<[^>]*>/g, '') ?? '',
                        url:      item.url   ?? '#',
                        category: item.category ?? null,
                    };
                    this.history = [entry, ...this.history.filter(h => h.url !== entry.url)].slice(0, 8);
                    localStorage.setItem('mt_search_history', JSON.stringify(this.history));
                },

                removeFromHistory(idx) {
                    this.history.splice(idx, 1);
                    localStorage.setItem('mt_search_history', JSON.stringify(this.history));
                },

                clearHistory() {
                    this.history = [];
                    localStorage.removeItem('mt_search_history');
                },
            };
        }
    </script>

</div>
