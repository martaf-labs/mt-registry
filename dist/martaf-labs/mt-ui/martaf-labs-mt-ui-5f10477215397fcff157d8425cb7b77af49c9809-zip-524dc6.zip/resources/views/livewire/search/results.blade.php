{{--
    Page de résultats complète - mt::search.results
    ─────────────────────────────────────────────────
    Route : GET /search?q=terme&category=App\Models\User

    Dans routes/search.php (ou routes/web.php) :
        Route::get('/search', function () {
            return view('mt::search.results', [
                'query'    => request('q', ''),
                'category' => request('category'),
            ]);
        })->name('search.index')->middleware(['web', 'auth']);

    THÈME : 100 % tokens --mt-* (aucune couleur en dur), icônes mt-icons SVG inline,
    chaînes via mt-ui::mt-ui.search_* (fr/en/ar).
--}}

<x-mt::layouts.master>

<div
    x-data="mtSearchResultsPage()"
    x-init="init()"
    @search-result-clicked.window="addToHistory($event.detail)"
    class="min-h-screen"
    style="background: rgb(var(--mt-bg))"
>

    {{-- ══════════════════════════════════════════════
         HERO - champ de recherche + breadcrumb
         ══════════════════════════════════════════════ --}}
    <div style="background: rgb(var(--mt-ui-card-bg)); border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

            {{-- Breadcrumb --}}
            <div class="flex items-center gap-2 text-sm mt-text-muted mb-4">
                <a href="{{ route('dashboard') }}" wire:navigate class="inline-flex transition-opacity hover:opacity-70">
                    <x-mt::icon name="home" size="sm" />
                </a>
                <x-mt::icon name="chevron-right" size="xs" />
                <span class="font-medium mt-text">{{ __('mt-ui::mt-ui.search') }}</span>
                @if($query)
                    <x-mt::icon name="chevron-right" size="xs" />
                    <span class="font-semibold mt-text truncate max-w-[200px]">
                        {{ $query }}
                    </span>
                @endif
            </div>

            {{-- Champ principal (lié au composant Livewire via l'événement search-query-updated) --}}
            <div class="relative max-w-2xl">
                <span class="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none z-10 mt-text-muted">
                    <x-mt::icon name="magnifying-glass" size="sm" />
                </span>
                <input
                    x-ref="pageInput"
                    type="text"
                    value="{{ $query }}"
                    @input.debounce.{{ config('mt-search.debounce', 300) }}ms="
                        $dispatch('search-query-updated', { query: $event.target.value })
                    "
                    @keydown.enter.prevent="$dispatch('search-query-updated', { query: $refs.pageInput.value })"
                    placeholder="{{ __('mt-ui::mt-ui.search_refine_ph') }}"
                    class="results-main-input w-full pl-12 pr-12 py-3.5 text-base"
                    autocomplete="off"
                >
                <button
                    x-show="$refs.pageInput && $refs.pageInput.value"
                    @click="$refs.pageInput.value = ''; $dispatch('search-query-updated', { query: '' }); $refs.pageInput.focus()"
                    class="absolute right-4 top-1/2 -translate-y-1/2 mt-text-muted transition-opacity hover:opacity-70"
                    x-cloak>
                    <x-mt::icon name="x-circle" size="sm" />
                </button>
            </div>

        </div>
    </div>


    {{-- ══════════════════════════════════════════════
         COMPOSANT LIVEWIRE - SearchResults
         Il gère : filtres, stats, liste, load more
         ══════════════════════════════════════════════ --}}
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8"
         @search-query-updated.window="syncUrl($event.detail.query)">

        {{-- État vide - aucune query --}}
        @if(strlen(trim($query)) < config('mt-search.min_chars', 2))
            <div class="py-10" id="empty-state">
                <x-mt::empty-state
                    icon="magnifying-glass"
                    :title="__('mt-ui::mt-ui.search_empty_title')"
                    :description="__('mt-ui::mt-ui.search_empty_hint', ['min' => config('mt-search.min_chars', 2)])"
                />

                {{-- Historique --}}
                <div x-show="history.length > 0" class="mt-8 max-w-lg mx-auto text-left">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-xs font-semibold uppercase tracking-wider mt-text-muted">
                            {{ __('mt-ui::mt-ui.search_recent') }}
                        </h3>
                        <button @click="clearHistory()"
                                class="text-xs mt-text-primary transition-opacity hover:opacity-70">
                            {{ __('mt-ui::mt-ui.search_clear_all') }}
                        </button>
                    </div>
                    <div class="space-y-1.5">
                        <template x-for="(item, idx) in history" :key="idx">
                            <a :href="item.url" wire:navigate class="results-history-item flex items-center gap-3 px-4 py-3 rounded-2xl transition-all group">
                                <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-text-muted"
                                     style="background: rgba(var(--mt-text), 0.06)">
                                    <x-mt::icon name="clock" size="xs" />
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium mt-text truncate" x-text="item.title"></p>
                                    <p x-show="item.category" class="text-xs mt-text-muted truncate" x-text="item.category"></p>
                                </div>
                                <button @click.prevent.stop="removeFromHistory(idx)"
                                        class="opacity-0 group-hover:opacity-100 p-1 rounded-lg mt-text-muted transition-all hover:opacity-70">
                                    <x-mt::icon name="x-mark" size="xs" />
                                </button>
                            </a>
                        </template>
                    </div>
                </div>
            </div>
        @endif

        {{-- ── Composant Livewire SearchResults ──
             Rendu uniquement si une query est présente.
             Il écoute l'événement 'search-query-updated' pour se synchroniser
             avec le champ input du hero ci-dessus.
        --}}
        @if(strlen(trim($query)) >= config('mt-search.min_chars', 2))
            <livewire:mt.search-results
                :initial-query="$query"
                :initial-category="$category ?? null"
                wire:key="search-results-{{ md5($query . ($category ?? '')) }}"
            />
        @endif

    </div>

</div>


{{-- ══════════════════════════════════════════════
     STYLES — tokens --mt-* uniquement (light/dark suivent
     automatiquement, pas de variantes .dark nécessaires).
     Exception documentée : la palette catégorielle badge-*/bg-cat-*
     (couleurs de DONNÉES par catégorie de résultat, pas des surfaces
     du thème) reste fixe.
     ══════════════════════════════════════════════ --}}
@push('styles')
<style>
    /* ── Champ principal ── */
    .results-main-input {
        background: rgb(var(--mt-ui-input-bg));
        border: 1.5px solid rgb(var(--mt-ui-input-border));
        border-radius: 14px;
        color: rgb(var(--mt-text));
        outline: none;
        box-shadow: 0 1px 4px rgba(0,0,0,.04);
        transition: border-color .15s, box-shadow .15s;
    }
    .results-main-input:focus {
        border-color: rgb(var(--mt-primary));
        box-shadow: 0 0 0 4px rgba(var(--mt-primary), .12);
    }
    .results-main-input::placeholder { color: rgba(var(--mt-text), .45); }

    /* ── Historique ── */
    .results-history-item {
        background: rgb(var(--mt-ui-card-bg));
        border: 1px solid rgb(var(--mt-ui-card-border));
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
    }
    .results-history-item:hover {
        border-color: rgba(var(--mt-primary), .35);
        background: rgba(var(--mt-primary), .05);
    }

    /* ── Filtres ── */
    .results-filter-btn {
        display: inline-flex; align-items: center;
        padding: 5px 12px; border-radius: 20px;
        font-size: 12px; font-weight: 500; white-space: nowrap;
        color: rgba(var(--mt-text), .65);
        background: rgb(var(--mt-ui-card-bg));
        border: 1.5px solid rgb(var(--mt-ui-card-border));
        cursor: pointer; transition: all .15s;
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
    }
    .results-filter-btn:hover {
        background: rgba(var(--mt-text), .04);
        color: rgb(var(--mt-text));
    }
    .results-filter-btn.active {
        background: rgba(var(--mt-primary), .1);
        color: rgb(var(--mt-primary));
        border-color: rgba(var(--mt-primary), .4);
        box-shadow: 0 0 0 2px rgba(var(--mt-primary), .1);
    }

    /* ── Item résultat ── */
    .results-item {
        display: flex; align-items: center; gap: 14px;
        padding: 14px 16px;
        background: rgb(var(--mt-ui-card-bg));
        border: 1.5px solid rgb(var(--mt-ui-card-border));
        border-radius: 16px;
        text-decoration: none;
        box-shadow: 0 1px 3px rgba(0,0,0,.04);
        transition: all .15s ease;
    }
    .results-item:hover {
        border-color: rgba(var(--mt-primary), .35);
        box-shadow: 0 4px 12px rgba(var(--mt-primary), .08), 0 1px 3px rgba(0,0,0,.04);
        transform: translateY(-1px);
    }
    .results-item .results-arrow {
        background: rgba(var(--mt-text), .06);
        color: rgba(var(--mt-text), .65);
        transition: all .15s;
    }
    .results-item:hover .results-arrow {
        background: rgba(var(--mt-primary), .12);
        color: rgb(var(--mt-primary));
    }

    /* ── Bouton « charger plus » ── */
    .results-more-btn {
        color: rgb(var(--mt-primary));
        background: rgb(var(--mt-ui-card-bg));
        border: 1px solid rgb(var(--mt-ui-card-border));
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
        transition: all .15s;
    }
    .results-more-btn:hover {
        background: rgba(var(--mt-primary), .06);
        border-color: rgba(var(--mt-primary), .35);
    }

    /* ── Badge catégorie (palette de DONNÉES — fixe, cf. note d'en-tête) ── */
    .results-cat-badge { display: inline-flex; align-items: center; gap: 3px; padding: 3px 8px; border-radius: 20px; }
    .badge-blue   { background:#dbeafe; color:#2563eb; }
    .badge-green  { background:#dcfce7; color:#16a34a; }
    .badge-purple { background:#ede9fe; color:#7c3aed; }
    .badge-orange { background:#ffedd5; color:#ea580c; }
    .badge-red    { background:#fee2e2; color:#dc2626; }
    .badge-teal   { background:#ccfbf1; color:#0d9488; }
    .badge-pink   { background:#fce7f3; color:#db2777; }
    .badge-gray   { background:#f3f4f6; color:#6b7280; }
    .dark .badge-blue   { background:rgba(37,99,235,.2);   color:#93c5fd; }
    .dark .badge-green  { background:rgba(22,163,74,.2);   color:#86efac; }
    .dark .badge-purple { background:rgba(124,58,237,.2);  color:#c4b5fd; }
    .dark .badge-orange { background:rgba(234,88,12,.2);   color:#fdba74; }
    .dark .badge-red    { background:rgba(220,38,38,.2);   color:#fca5a5; }
    .dark .badge-teal   { background:rgba(13,148,136,.2);  color:#5eead4; }
    .dark .badge-pink   { background:rgba(219,39,119,.2);  color:#f9a8d4; }
    .dark .badge-gray   { background:#374151; color:#9ca3af; }

    /* ── Avatars (palette de DONNÉES — fixe) ── */
    .bg-cat-blue   { background:#3b82f6; }
    .bg-cat-green  { background:#22c55e; }
    .bg-cat-purple { background:#8b5cf6; }
    .bg-cat-orange { background:#f97316; }
    .bg-cat-red    { background:#ef4444; }
    .bg-cat-teal   { background:#14b8a6; }
    .bg-cat-pink   { background:#ec4899; }
    .bg-cat-gray   { background:#6b7280; }

    /* ── Highlight ── */
    mark.search-highlight {
        background: rgba(var(--mt-warning), .3);
        color: inherit;
        border-radius: 2px; padding: 0 1px; font-weight: 600;
    }

    .scrollbar-none { scrollbar-width: none; }
    .scrollbar-none::-webkit-scrollbar { display: none; }
</style>
@endpush


{{-- ══════════════════════════════════════════════
     ALPINE - gestion historique + sync URL
     ══════════════════════════════════════════════ --}}
@push('scripts')
<script>
function mtSearchResultsPage() {
    return {
        history: [],

        init() {
            this.loadHistory();
        },

        // Sync l'URL sans rechargement quand la query change
        syncUrl(query) {
            const url = new URL(window.location.href);
            query
                ? url.searchParams.set('q', query)
                : url.searchParams.delete('q');
            window.history.replaceState({}, '', url.toString());
        },

        // ── Historique localStorage ────────────────────
        loadHistory() {
            try {
                const raw = localStorage.getItem('mt_search_history');
                this.history = raw ? JSON.parse(raw) : [];
            } catch { this.history = []; }
        },

        addToHistory(detail) {
            const entry = {
                title:    detail.title ?? '',
                url:      detail.url ?? '#',
                category: detail.category ?? null,
            };
            this.history = [
                entry,
                ...this.history.filter(h => h.url !== entry.url),
            ].slice(0, {{ config('mt-search.history_limit', 8) }});
            localStorage.setItem('mt_search_history', JSON.stringify(this.history));
        },

        removeFromHistory(idx) {
            this.history.splice(idx, 1);
            localStorage.setItem('mt_search_history', JSON.stringify(this.history));
        },

        clearHistory() {
            this.history = [];
            localStorage.removeItem('mt_search_history');
        },
    };
}
</script>
@endpush

</x-mt::layouts.master>
