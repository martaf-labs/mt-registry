{{--
    Vue partielle du composant SearchResults
    ─────────────────────────────────────────
    Rendue par SearchResults::render()
    Intégrée dans mt::search.results via <livewire:mt.search-results />
    THÈME : tokens --mt-* + icônes mt-icons SVG (les icônes déclarées par les
    modèles Searchable sont normalisées via mt_icon_name — rétro-compat FA).
--}}
<div>

    {{-- Filtres catégories --}}
    <div class="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none mt-4"
        x-show="categories.length > 1">

        @if(count($categories) > 1)
            <button
                wire:click="setCategory(null)"
                class="results-filter-btn {{ $activeCategory === null ? 'active' : '' }}">
                <span class="mr-1.5 inline-flex"><x-mt::icon name="list" size="xs" /></span>
                {{ __('mt-ui::mt-ui.search_all') }}
            </button>

            @foreach($categories as $cat)
                <button
                    wire:click="setCategory('{{ addslashes($cat['key']) }}')"
                    class="results-filter-btn {{ $activeCategory === $cat['key'] ? 'active' : '' }}">
                    <span class="mr-1.5 inline-flex"><x-mt::icon :name="mt_icon_name($cat['icon'] ?? null, 'tag')" size="xs" /></span>
                    {{ $cat['label'] }}
                </button>
            @endforeach
        @endif

    </div>

    {{-- Stats --}}
    <p class="text-sm mt-text-muted mt-3"
    x-show="'{{ strlen(trim($query)) }}' >= '{{ config('mt-search.min_chars', 2) }}'">

        @if($searching)
            <span class="flex items-center gap-2">
                <svg class="animate-spin w-3.5 h-3.5" style="color: rgb(var(--mt-primary))" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                </svg>
                {{ __('mt-ui::mt-ui.search_searching') }}
            </span>
        @else
            <span>
                <span class="font-semibold mt-text">{{ trans_choice('mt-ui::mt-ui.search_count', $totalResults, ['count' => $totalResults]) }}</span>
                {{ __('mt-ui::mt-ui.search_for') }}
                <span class="font-semibold mt-text">«{{ strip_tags($query) }}»</span>
            </span>
        @endif

    </p>

    {{-- Corps résultats --}}
    <div class="mt-6 space-y-2">

        {{-- Skeleton --}}
        @if($searching && count($loadedResults) === 0)
            @for($i = 0; $i < 8; $i++)
                <div class="flex items-center gap-4 p-4 rounded-2xl animate-pulse"
                     style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgb(var(--mt-ui-card-border))">
                    <div class="w-11 h-11 rounded-xl flex-shrink-0" style="background: rgba(var(--mt-text), .08)"></div>
                    <div class="flex-1 space-y-2">
                        <div class="h-4 rounded w-1/3" style="background: rgba(var(--mt-text), .08)"></div>
                        <div class="h-3 rounded w-1/2" style="background: rgba(var(--mt-text), .05)"></div>
                    </div>
                    <div class="flex-shrink-0 space-y-1.5">
                        <div class="h-3 w-16 rounded ml-auto" style="background: rgba(var(--mt-text), .05)"></div>
                        <div class="h-5 w-20 rounded-full ml-auto" style="background: rgba(var(--mt-text), .08)"></div>
                    </div>
                </div>
            @endfor
        @endif

        {{-- Aucun résultat --}}
        @if(!$searching && count($loadedResults) === 0 && strlen(trim($query)) >= config('mt-search.min_chars', 2))
            <div class="py-10">
                <x-mt::empty-state
                    icon="magnifying-glass"
                    :title="__('mt-ui::mt-ui.search_no_results_title')"
                    :description="__('mt-ui::mt-ui.search_no_results_hint', ['query' => strip_tags($query)])"
                >
                    @if($activeCategory)
                        <x-mt::button variant="outline" size="sm" icon="x-mark" wire:click="setCategory(null)">
                            {{ __('mt-ui::mt-ui.search_remove_category') }}
                        </x-mt::button>
                    @endif
                </x-mt::empty-state>
            </div>
        @endif

        {{-- Liste des résultats --}}
        @foreach($loadedResults as $idx => $item)
            <a
                href="{{ $item['url'] }}"
                x-data
                @click="$dispatch('search-result-clicked', {{ json_encode(['title' => strip_tags($item['title']), 'url' => $item['url'], 'category' => $item['category'] ?? null]) }})"
                class="results-item group"
                wire:key="result-{{ $idx }}-{{ $item['id'] ?? $idx }}"
                wire:navigate
            >
                {{-- Avatar --}}
                <div class="flex-shrink-0">
                    @if(!empty($item['avatar']))

                    <x-mt::image-loader :src="$item['avatar']" :alt="$item['title']" class="w-11 h-11 rounded-xl" />

                    @else
                        <div class="w-11 h-11 rounded-xl flex items-center justify-center text-sm font-bold text-white flex-shrink-0 bg-cat-{{ $item['color'] ?? 'gray' }}">
                            {{ strtoupper(substr(strip_tags($item['avatar_text'] ?? $item['title']), 0, 2)) }}
                        </div>
                    @endif
                </div>

                {{-- Contenu --}}
                <div class="flex-1 min-w-0">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <p class="text-sm font-semibold mt-text truncate leading-snug">
                                {!! $item['title'] !!}
                            </p>
                            @if(!empty($item['subtitle']))
                                <p class="text-sm mt-text-muted truncate mt-0.5">
                                    {!! $item['subtitle'] !!}
                                </p>
                            @endif
                        </div>
                        <div class="flex-shrink-0 text-right">
                            @if(!empty($item['meta']))
                                <p class="text-xs mt-text-muted whitespace-nowrap mb-1.5">
                                    {{ $item['meta'] }}
                                </p>
                            @endif
                            @if(!empty($item['category']))
                                <span class="results-cat-badge badge-{{ $item['color'] ?? 'gray' }} inline-flex items-center gap-1">
                                    <x-mt::icon :name="mt_icon_name($item['icon'] ?? null, 'tag')" size="xs" />
                                    <span class="text-[10px] font-semibold capitalize">{{ $item['category'] }}</span>
                                </span>
                            @endif
                        </div>
                    </div>
                </div>

                {{-- Flèche hover --}}
                <div class="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div class="results-arrow w-7 h-7 rounded-lg flex items-center justify-center">
                        <x-mt::icon name="arrow-right" size="xs" />
                    </div>
                </div>
            </a>
        @endforeach

        {{-- Load More --}}
        @if($searching && count($loadedResults) > 0)
            <div class="flex flex-col items-center justify-center gap-2 py-4 text-sm mt-text-muted">
                <svg class="animate-spin w-4 h-4" style="color: rgb(var(--mt-primary))" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                </svg>
                {{ __('mt-ui::mt-ui.search_loading') }}
            </div>
        @endif

        @if(!$searching && $hasMore)
            <div class="pt-6 text-center">
                <button
                    wire:click="loadMore"
                    wire:loading.attr="disabled"
                    wire:target="loadMore"
                    class="results-more-btn inline-flex items-center gap-2.5 px-6 py-3 text-sm font-medium rounded-2xl disabled:opacity-60 disabled:cursor-wait"
                >
                    <span wire:loading.remove wire:target="loadMore" class="inline-flex items-center gap-1.5">
                        <x-mt::icon name="chevron-down" size="xs" />
                        {{ __('mt-ui::mt-ui.search_load_more') }}
                        <span class="text-xs mt-text-muted">
                            ({{ __('mt-ui::mt-ui.search_remaining', ['n' => $totalResults - count($loadedResults)]) }})
                        </span>
                    </span>
                    <span wire:loading wire:target="loadMore" class="flex items-center gap-2">
                        <svg class="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                        </svg>
                        {{ __('mt-ui::mt-ui.search_loading') }}
                    </span>
                </button>
            </div>
        @endif

        {{-- Fin des résultats --}}
        @if(!$searching && !$hasMore && count($loadedResults) > 0)
            <div class="pt-6 pb-4 text-center">
                <div class="inline-flex items-center gap-3 text-xs mt-text-muted">
                    <div class="w-16 h-px" style="background: rgb(var(--mt-ui-card-border))"></div>
                    <span>{{ __('mt-ui::mt-ui.search_end', ['count' => $totalResults]) }}</span>
                    <div class="w-16 h-px" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>
            </div>
        @endif

    </div>
</div>
