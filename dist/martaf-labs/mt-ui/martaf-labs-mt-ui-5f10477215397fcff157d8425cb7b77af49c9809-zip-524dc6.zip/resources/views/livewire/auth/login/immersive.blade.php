{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : immersive (refonte mobile-first 2026-07)               ║
║  Vue    : login/immersive.blade.php                              ║
║  Habillage : <x-mt::auth-shell> (bandeau de marque + feuille).   ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@section('title', 'Connexion')

<x-mt::auth-shell
    :title="__('mt-ui::mt-ui.login_title')"
    :subtitle="__('mt-ui::mt-ui.login_subtitle')"
    icon="key">

    <x-mt::auth-session-status class="text-sm" :status="session('status')" />

    <form wire:submit="login" class="flex flex-col gap-4">
        <x-mt::form.input
            wire:model="email"
            icon="envelope"
            :label="__('Adresse e-mail')"
            type="email"
            :error="$errors->first('email')"
            required autofocus autocomplete="email"
            placeholder="email@exemple.com" />

        <div>
            <x-mt::form.input
                wire:model="password"
                icon="lock-closed"
                :label="__('Mot de passe')"
                type="password"
                :error="$errors->first('email')"
                required autocomplete="current-password"
                :placeholder="__('••••••••')"
                viewable />
            @if($hasPasswordReset)
                <div class="flex justify-end mt-1.5">
                    <a href="{{ route('password.request') }}" wire:navigate
                       class="text-xs font-semibold" style="color:rgb(var(--mt-primary))">{{ __('Mot de passe oublié ?') }}</a>
                </div>
            @endif
        </div>

        @if($hasRemember)
            <x-mt::form.toggle wire:model="remember" :label="__('Rester connecté')" />
        @endif

        <x-mt::button variant="primary" type="submit" endIcon="arrow-right"
                      loading="login" data-test="login-button" class="w-full">
            {{ __('mt-ui::mt-ui.login') }}
        </x-mt::button>
    </form>

    @if($hasRegister || $hasHome)
        <div class="flex flex-col gap-1 mt-auto text-sm text-center" style="color:rgb(var(--mt-text) / .6)">
            @if($hasRegister)
                <p>{{ __('Pas encore de compte ?') }}
                    <a href="{{ route('register') }}" wire:navigate class="font-bold" style="color:rgb(var(--mt-primary))">{{ __("S'inscrire") }}</a>
                </p>
            @endif
            @if($hasHome)
                <a href="{{ route('home') }}" wire:navigate class="font-bold" style="color:rgb(var(--mt-primary))">← {{ mt_config('app_name') }}</a>
            @endif
        </div>
    @endif
</x-mt::auth-shell>
