<x-mt::auth-shell
    :title="__('Définir le mot de passe')"
    :subtitle="__('Choisissez un mot de passe robuste — 8 caractères minimum.')"
    icon="shield-check" :back="true">

    <x-mt::auth-session-status class="text-sm text-center" :status="session('status')" />

    <form method="POST" wire:submit="resetPassword" class="flex flex-col gap-4">
        <x-mt::form.input
            model="email"
            icon="envelope"
            :label="__('E-mail')"
            type="email"
            :required="true"
            :error="$errors->first('email')"
            autocomplete="email" />

        <x-mt::form.input
            model="password"
            icon="lock-closed"
            :label="__('Nouveau mot de passe')"
            type="password"
            :required="true"
            :error="$errors->first('password')"
            autocomplete="new-password"
            :placeholder="__('••••••••')"
            viewable />

        <x-mt::form.input
            model="password_confirmation"
            icon="lock-closed"
            :label="__('Confirmer le mot de passe')"
            type="password"
            :required="true"
            :error="$errors->first('password_confirmation')"
            autocomplete="new-password"
            :placeholder="__('••••••••')" />

        <x-mt::button type="submit" variant="primary" class="w-full">
            {{ __('Réinitialiser le mot de passe') }}
        </x-mt::button>
    </form>
</x-mt::auth-shell>
