{{--
  Partial : _form.blade.php
  Formulaire de connexion commun à toutes les variantes.
  Données : $hasPasswordReset, $hasRegister, $hasHome
--}}

<x-mt::auth-session-status class="mb-5 text-sm" :status="session('status')" />

<form wire:submit="login" class="space-y-5">

    {{-- Email --}}
    <x-mt::form.input
        wire:model="email"
        :label="__('Adresse e-mail')"
        type="email"
        :error="$errors->first('email')"
        required
        autofocus
        autocomplete="email"
        placeholder="email@exemple.com"
    />

    {{-- Mot de passe --}}
    <div>
        <x-mt::form.input
            wire:model="password"
            :label="__('Mot de passe')"
            type="password"
            :error="$errors->first('email')"
            required
            autocomplete="current-password"
            :placeholder="__('••••••••')"
            viewable
        />
        @if($hasPasswordReset)
            <div class="flex justify-end mt-1.5">
                <a href="{{ route('password.request') }}" wire:navigate
                   class="text-xs mt-text-muted hover:mt-text-primary mt-transition">
                    Mot de passe oublié ?
                </a>
            </div>
        @endif
    </div>

    @if ($hasRemember)
    {{-- Se souvenir --}}
    <x-mt::form.toggle wire:model="remember" :label="__('Rester connecté')" />
    @endif
    {{-- Bouton --}}
    <x-mt::button
        variant="primary"
        type="submit"
        endIcon="chevron-right"
        loading="login"
        data-test="login-button"
        class="w-full"
    >
        {{ __('mt-ui::mt-ui.login') }}
    </x-mt::button>

</form>
