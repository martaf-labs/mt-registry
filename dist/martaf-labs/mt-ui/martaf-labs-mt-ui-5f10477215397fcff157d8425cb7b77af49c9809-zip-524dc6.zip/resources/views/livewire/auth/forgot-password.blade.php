<x-mt::auth-shell
    :title="__('Réinitialiser l\'accès')"
    :subtitle="__('Indiquez l\'adresse liée à votre compte : un lien de réinitialisation vous sera envoyé.')"
    icon="envelope" :back="true">

    <x-mt::auth-session-status class="text-sm text-center" :status="session('status')" />

    <form method="POST" wire:submit="sendPasswordResetLink" class="flex flex-col gap-4">
        <x-mt::form.input
            model="email"
            icon="envelope"
            :label="__('Adresse e-mail')"
            type="email"
            :required="true"
            :error="$errors->first('email')"
            autofocus
            placeholder="email@exemple.com" />

        <x-mt::button variant="primary" type="submit" endIcon="paper-airplane" class="w-full">
            {{ __('Envoyer le lien') }}
        </x-mt::button>

        <a href="{{ route('login') }}" wire:navigate class="text-sm font-semibold text-center" style="color:rgb(var(--mt-primary))">
            ← {{ __('Revenir à la connexion') }}
        </a>
    </form>
</x-mt::auth-shell>
