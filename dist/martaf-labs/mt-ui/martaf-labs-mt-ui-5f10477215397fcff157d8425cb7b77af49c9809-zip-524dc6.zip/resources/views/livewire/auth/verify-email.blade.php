<div class="mt-4 flex flex-col gap-6">
    <p class="text-center text-sm mt-text-muted">
        {{ __('Veuillez vérifier votre adresse e-mail en cliquant sur le lien que nous venons de vous envoyer par e-mail.') }}
    </p>

    @if (session('status') == 'verification-link-sent')
        <p class="text-center text-sm font-medium" style="color:rgb(var(--mt-success))">
            {{ __('Un nouveau lien de vérification a été envoyé à l\'adresse e-mail que vous avez fournie lors de l\'inscription.') }}
        </p>
    @endif

    <div class="flex flex-col items-center justify-between space-y-3">
        <x-mt::button wire:click="sendVerification" variant="primary" class="w-full">
            {{ __('Renvoyer le lien de vérification') }}
        </x-mt::button>

        <button type="button" wire:click="logout" class="text-sm cursor-pointer font-medium mt-text-primary hover:underline">
            {{ __('Se déconnecter') }}
        </button>
    </div>
</div>
