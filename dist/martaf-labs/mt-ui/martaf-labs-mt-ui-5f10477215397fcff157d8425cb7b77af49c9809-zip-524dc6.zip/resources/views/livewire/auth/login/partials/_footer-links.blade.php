{{--
  Partial : _footer-links.blade.php
  Liens secondaires (inscription, retour accueil).
  Données : $hasRegister, $hasHome
--}}

@if($hasRegister || $hasHome)
<div class="space-y-3 text-center text-sm">

    @if($hasRegister)
        <p class="mt-text-muted">
            Pas encore de compte ?
            <a href="{{ route('register') }}" wire:navigate
               class="font-semibold mt-text-primary hover:underline underline-offset-2 ml-1">
                Inscrivez-vous
            </a>
        </p>
    @endif

    @if($hasHome)
        <a href="{{ route('home') }}" wire:navigate
           class="block text-xs mt-text-muted hover:mt-text-primary mt-transition">
            ← Retour à {{ mt_config('app_name') }}
        </a>
    @endif

</div>
@endif
