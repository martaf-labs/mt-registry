{{--
╔══════════════════════════════════════════════════════════════════╗
║  LAYOUT : classic                                                ║
║  Vue    : login/classic.blade.php                                ║
╠══════════════════════════════════════════════════════════════════╣
║  Structure : card centrée, logo en haut, formulaire standard     ║
║  Usage     : blog généraliste, application SaaS, back-office     ║
╚══════════════════════════════════════════════════════════════════╝
--}}

@section('title', 'Connexion')

<div class="flex items-center justify-center min-h-screen p-4 mt-bg">

    <div class="w-full max-w-sm">

        {{-- Marque : logo image si configuré, sinon badge en DÉGRADÉ avec l'initiale de l'app. --}}
        <div class="flex flex-col items-center mb-8">
            @if(mt_config('assets.logos.png'))
                <img src="{{ asset(mt_config('assets.logos.png')) }}"
                     alt="{{ mt_config('app_name') }}"
                     class="w-auto h-11 mb-4">
            @else
                <div class="flex items-center justify-center mb-4 shadow-lg mt-gradient-brand"
                     style="width:3.5rem; height:3.5rem; border-radius:1rem">
                    <span class="text-2xl font-black" style="color:rgb(var(--mt-primary-content))">
                        {{ strtoupper(substr(mt_config('app_name'), 0, 1)) }}
                    </span>
                </div>
            @endif
            <h1 class="mt-h3">{{ mt_config('app_name') }}</h1>
        </div>

        {{-- Card : fond distinct de l'arrière-plan + ombre pour la profondeur --}}
        <div class="space-y-6 mt-card mt-shadow-md p-6 sm:p-7">

            <div class="space-y-1">
                <h2 class="mt-h3">Connexion</h2>
                <p class="mt-text-muted text-sm">
                    Entrez vos identifiants pour accéder à votre espace
                </p>
            </div>

            @include('mt::livewire.auth.login.partials._form')

        </div>

        {{-- Liens secondaires --}}
        <div class="mt-5">
            @include('mt::livewire.auth.login.partials._footer-links')
        </div>

    </div>
</div>
