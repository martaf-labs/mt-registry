<div class="flex flex-col gap-6">
    @section('title', 'Inscription')

    <x-mt::auth-header :title="__('Créer un compte')" :description="__('Entrez vos informations pour créer votre compte')" />

    <!-- Session Status -->
    <x-mt::auth-session-status class="text-center" :status="session('status')" />

    <form method="POST" wire:submit="register" class="flex flex-col gap-6">
        <!-- Name -->
        <x-mt::form.input
            model="name"
            :label="__('Nom')"
            type="text"
            :required="true"
            :error="$errors->first('name')"
            autofocus
            autocomplete="name"
            :placeholder="__('Nom complet')"
        />

        <!-- Email Address -->
        <x-mt::form.input
            model="email"
            :label="__('Adresse e-mail')"
            type="email"
            :required="true"
            :error="$errors->first('email')"
            autocomplete="email"
            placeholder="email@example.com"
        />

        <!-- Password -->
        <x-mt::form.input
            model="password"
            :label="__('Mot de passe')"
            type="password"
            :required="true"
            :error="$errors->first('password')"
            autocomplete="new-password"
            :placeholder="__('Mot de passe')"
        />

        <!-- Confirm Password -->
        <x-mt::form.input
            model="password_confirmation"
            :label="__('Confirmer le mot de passe')"
            type="password"
            :required="true"
            :error="$errors->first('password_confirmation')"
            autocomplete="new-password"
            :placeholder="__('Confirmer le mot de passe')"
        />

        <div class="flex items-center justify-end">
            <x-mt::button type="submit" variant="primary" class="w-full">
                {{ __('Créer un compte') }}
            </x-mt::button>
        </div>
    </form>

    <div class="space-x-1 rtl:space-x-reverse text-center text-sm mt-text-muted">
        <span>{{ __('Vous avez déjà un compte ?') }}</span>
        <a href="{{ route('login') }}" wire:navigate class="font-medium mt-text-primary hover:underline">{{ __('Connectez-vous') }}</a>
    </div>
</div>
