<div class="min-h-screen mt-bg">

    {{-- Actions rapides poussees au FAB de la barre mobile : 1 = tap direct, plusieurs = popover.
         NB : json encode dans un bloc php puis echappe (le combo push+json inline casse le parseur). --}}
    @if(count($quickActions) > 0)
        @php
            $__dashFabJson = json_encode(collect($quickActions)->map(fn ($a) => [
                'label'  => $a['label'] ?? '',
                'icon'   => $a['icon'] ?? 'bolt',
                'route'  => $a['route'] ?? null,
                'method' => $a['method'] ?? null,
                'target' => $a['target'] ?? null,
            ])->values()->all());
        @endphp
        @push('mobileFabActions'){!! $__dashFabJson !!}@endpush
    @endif

    {{-- ══════════════════════════════════════════════════════
         HEADER
    ══════════════════════════════════════════════════════ --}}
    <div class="px-4 py-5 sm:px-8 lg:py-6" style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.5)">
        <div class="mx-auto max-w-7xl">
            <div class="flex items-start justify-between gap-3 sm:items-center">
                <div class="min-w-0">
                    {{-- Salutation mise en avant sur mobile (le titre est déjà porté par la topbar). --}}
                    <p class="text-sm font-medium lg:text-xs mt-text-muted">
                        {{ $greeting }},
                        <span class="font-semibold mt-text-primary">{{ auth()->user()?->name ?? 'Utilisateur' }}</span>
                    </p>
                    <h1 class="hidden text-2xl font-bold mt-text lg:block">{{ $title }}</h1>
                    <p class="mt-1 text-xs mt-text-muted">{{ $subtitle }}</p>
                </div>

                <div class="flex flex-wrap items-center justify-end gap-2 shrink-0">
                    {{-- Relance de la visite guidée (n'apparaît que si l'hôte déclare un tour "dashboard") --}}
                    <x-mt::tour-button name="dashboard" />

                    @if(count($quickActions) > 0)
                    <div id="mt-dash-actions" class="hidden lg:block">
                        <x-mt::actions.grid :actions="$quickActions" visible="1" size="sm" />
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="px-4 py-6 sm:px-8 lg:py-8">
        <div class="mx-auto space-y-6 lg:space-y-8 max-w-7xl">

            {{-- HERO (point d'extension hôte) : vue mise en avant en tête, rendue AVANT les stats. --}}
            @if(!empty($hero['view'] ?? null))
                @include($hero['view'], $hero['data'] ?? [])
            @endif

            {{-- ══════════════════════════════════════════════════════
                 STATS CARDS - grille dynamique selon le nombre
            ══════════════════════════════════════════════════════ --}}
            {{-- Cartes de stats : composant partagé (même rendu pour dashboard / base-index / base-show). --}}
            <div id="mt-dash-stats">
                <x-mt::stats-scroll :stats="$stats" />
            </div>

            {{-- ══════════════════════════════════════════════════════
                 WIDGETS - grille 3 colonnes
            ══════════════════════════════════════════════════════ --}}
            @if(count($widgets) > 0)
            @once
            <style>
                /* Widget : SANS fond sur MOBILE (section transparente, cf. artefact — le contenu
                   porte son propre fond). Sur DESKTOP, carte discrète pour la structure de la grille. */
                .mt-widget-card { border-radius: 1rem; }
                @media (min-width: 1024px) {
                    .mt-widget-card {
                        background: rgb(var(--mt-ui-card-bg));
                        border: 1px solid rgb(var(--mt-ui-card-border));
                        padding: 1rem 1.1rem;
                    }
                }
            </style>
            @endonce
            <div id="mt-dash-widgets" class="grid grid-cols-1 lg:grid-cols-3" style="row-gap: 1.9rem; column-gap: 1.5rem">
                @foreach($widgets as $widget)
                @php
                    $span = $widget['span'] ?? 1;
                    $spanClass = match($span) {
                        3 => 'lg:col-span-3',
                        2 => 'lg:col-span-2',
                        default => 'lg:col-span-1',
                    };
                @endphp

                <div class="{{ $spanClass }}">
                    <div class="flex flex-col h-full mt-widget-card">

                        {{-- Widget Header --}}
                        <div class="flex items-center justify-between flex-shrink-0 px-0 py-1"
                             style="">
                            <div class="min-w-0">
                                <h3 class="text-sm font-semibold truncate mt-text">{{ $widget['title'] }}</h3>
                                @if(isset($widget['subtitle']))
                                    <p class="text-xs mt-text-muted mt-0.5">{{ $widget['subtitle'] }}</p>
                                @endif
                            </div>
                            @if(!empty($widget['actions']))
                            <div class="flex items-center flex-shrink-0 gap-3 ml-3">
                                
                                <x-mt::actions.grid :actions="$widget['actions']" visible="0" size="sm" />
                                
                                {{-- @foreach($widget['actions'] as $wAction)
                                    @if(isset($wAction['route']))
                                        <a href="{{ $wAction['route'] }}" wire:navigate
                                           class="text-xs font-medium transition-opacity mt-text-primary hover:opacity-75 whitespace-nowrap">
                                            {{ $wAction['label'] }}
                                        </a>
                                    @elseif(isset($wAction['method']))
                                        <button wire:click="{{ $wAction['method'] }}"
                                                class="text-xs font-medium transition-opacity mt-text-primary hover:opacity-75 whitespace-nowrap">
                                            {{ $wAction['label'] }}
                                        </button>
                                    @endif
                                @endforeach --}}
                            </div>
                            @endif
                        </div>

                        {{-- Widget Body --}}
                        <div class="flex-1 px-0 py-2 overflow-hidden">

                            {{-- ── TYPE : LIST ──────────────────────────── --}}
                            @if($widget['type'] === 'list')
                                @if(empty($widget['data']))
                                    <div class="flex flex-col items-center justify-center h-full py-8 mt-text-muted">
                                        <span class="mb-3" style="opacity:0.25"><x-mt::icon name="inbox-stack" size="2xl" /></span>
                                        <p class="text-xs">{{ __('mt-ui::mt-ui.dash_widget_empty') }}</p>
                                    </div>
                                @else
                                <div class="max-h-full -mx-5 space-y-0 overflow-y-auto">
                                    @foreach($widget['data'] as $item)
                                    @php $itemUrl = $item['route'] ?? null; @endphp
                                    @if($itemUrl)
                                    <a href="{{ $itemUrl }}" wire:navigate
                                       class="flex items-center gap-3 px-5 py-3 transition-colors"
                                       onmouseover="this.style.background='rgba(var(--mt-text),0.03)'"
                                       onmouseout="this.style.background=''">
                                    @else
                                    <div class="flex items-center gap-3 px-5 py-3">
                                    @endif

                                        {{-- Avatar / icône / initiales --}}
                                        @if(isset($item['image']))
                                            <img src="{{ $item['image'] }}" alt="{{ $item['title'] }}"
                                                 class="flex-shrink-0 object-cover rounded-lg w-9 h-9">
                                        @elseif(isset($item['icon']))
                                            <div class="flex items-center justify-center flex-shrink-0 rounded-lg w-9 h-9"
                                                 style="background: rgba(var(--mt-primary),0.1)">
                                                <span class="mt-text-primary"><x-mt::icon :name="mt_icon_name($item['icon'])" size="sm" /></span>
                                            </div>
                                        @elseif(isset($item['initials']))
                                            <div class="flex items-center justify-center flex-shrink-0 text-xs font-bold text-white rounded-lg w-9 h-9"
                                                 style="background: rgb(var(--mt-primary))">
                                                {{ $item['initials'] }}
                                            </div>
                                        @endif

                                        {{-- Contenu --}}
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm font-medium truncate mt-text">{{ $item['title'] }}</p>
                                            @if(isset($item['meta']))
                                                <p class="text-xs truncate mt-text-muted">{{ $item['meta'] }}</p>
                                            @endif
                                        </div>

                                        {{-- Badge / valeur --}}
                                        @if(isset($item['badge']))
                                            <x-mt::badge
                                                :label="is_array($item['badge']) ? $item['badge']['label'] : $item['badge']"
                                                :variant="is_array($item['badge']) ? ($item['badge']['variant'] ?? 'gray') : 'gray'"
                                            />
                                        @elseif(isset($item['value']))
                                            <span class="flex-shrink-0 ml-2 text-sm font-semibold mt-text">
                                                {{ $item['value'] }}
                                            </span>
                                        @endif

                                    @if($itemUrl) </a> @else </div> @endif
                                    @endforeach
                                </div>
                                @endif

                            {{-- ── TYPE : CHART ─────────────────────────── --}}
                            @elseif($widget['type'] === 'chart')
                                <div style="height: {{ $widget['height'] ?? '250px' }}">
                                    <canvas id="chart-{{ $loop->index }}"></canvas>
                                </div>
                                @push('scripts')
                                <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    if (typeof Chart === 'undefined') {
                                        // Charger Chart.js si absent
                                        const s = document.createElement('script');
                                        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js';
                                        s.onload = () => initChart{{ $loop->index }}();
                                        document.head.appendChild(s);
                                    } else {
                                        initChart{{ $loop->index }}();
                                    }

                                    function initChart{{ $loop->index }}() {
                                        const ctx = document.getElementById('chart-{{ $loop->index }}');
                                        if (!ctx) return;

                                        const isDark = document.documentElement.classList.contains('dark');
                                        const style  = getComputedStyle(document.documentElement);
                                        const primary    = style.getPropertyValue('--mt-primary').trim();
                                        const textColor  = style.getPropertyValue('--mt-text').trim();
                                        const borderC    = style.getPropertyValue('--mt-ui-card-border').trim();

                                        const chartType = '{{ $widget['chart_type'] ?? 'bar' }}';
                                        const showLegend = {{ isset($widget['legend']) && $widget['legend'] ? 'true' : 'false' }};

                                        const data = @json($widget['data']);

                                        // Couleurs de dataset par défaut dérivées du thème (--mt-primary),
                                        // pour les hôtes qui ne fixent pas de couleur littérale (les variables
                                        // CSS ne se résolvent pas sur un canvas). N'écrase jamais une couleur fournie.
                                        const palette = [primary, textColor, borderC];
                                        (data.datasets || []).forEach((ds, di) => {
                                            const triplet = palette[di % palette.length] || primary;
                                            if (ds.backgroundColor == null) {
                                                ds.backgroundColor = (chartType === 'doughnut' || chartType === 'pie')
                                                    ? (data.labels || []).map((_, li) => `rgba(${palette[li % palette.length] || primary}, 0.75)`)
                                                    : `rgba(${triplet}, 0.7)`;
                                            }
                                            if (ds.borderColor == null && (chartType === 'line' || chartType === 'radar')) {
                                                ds.borderColor = `rgb(${triplet})`;
                                            }
                                        });

                                        const tooltipBg = isDark ? 'rgba(30,30,30,0.97)' : 'rgba(255,255,255,0.97)';

                                        new Chart(ctx, {
                                            type: chartType,
                                            data: data,
                                            options: {
                                                responsive: true,
                                                maintainAspectRatio: false,
                                                plugins: {
                                                    legend: {
                                                        display: showLegend,
                                                        labels: {
                                                            color: `rgba(${textColor}, 0.7)`,
                                                            boxWidth: 12,
                                                            padding: 16,
                                                            font: { size: 11 },
                                                        }
                                                    },
                                                    tooltip: {
                                                        backgroundColor: tooltipBg,
                                                        titleColor: `rgb(${textColor})`,
                                                        bodyColor: `rgba(${textColor}, 0.7)`,
                                                        borderColor: `rgb(${borderC})`,
                                                        borderWidth: 1,
                                                        padding: 12,
                                                        boxPadding: 6,
                                                        usePointStyle: true,
                                                        callbacks: {
                                                            label: function(ctx) {
                                                                // Cartésien : parsed.y ; circulaire (doughnut/pie) : parsed est le nombre.
                                                                var v = (ctx.parsed && ctx.parsed.y !== undefined) ? ctx.parsed.y : ctx.parsed;
                                                                var lead = ctx.dataset.label ? ctx.dataset.label + ' : '
                                                                         : (ctx.label ? ctx.label + ' : ' : '');
                                                                return ' ' + lead + v;
                                                            }
                                                        }
                                                    }
                                                },
                                                scales: chartType === 'doughnut' || chartType === 'pie' ? {} : {
                                                    y: {
                                                        beginAtZero: true,
                                                        grid: {
                                                            color: `rgba(${borderC}, 0.4)`,
                                                            drawBorder: false,
                                                        },
                                                        ticks: {
                                                            color: `rgba(${textColor}, 0.55)`,
                                                            font: { size: 11 },
                                                            padding: 8,
                                                        }
                                                    },
                                                    x: {
                                                        grid: { display: false },
                                                        ticks: {
                                                            color: `rgba(${textColor}, 0.55)`,
                                                            font: { size: 11 },
                                                            maxRotation: 0,
                                                        }
                                                    }
                                                },
                                                animation: {
                                                    duration: 600,
                                                    easing: 'easeInOutQuart',
                                                }
                                            }
                                        });

                                        // Sync avec le toggle dark mode
                                        const observer = new MutationObserver(() => {
                                            // Simple reload du canvas au changement de thème
                                            ctx.style.opacity = '0';
                                            setTimeout(() => { ctx.style.opacity = '1'; }, 150);
                                        });
                                        observer.observe(document.documentElement, {
                                            attributes: true, attributeFilter: ['class']
                                        });
                                    }
                                });
                                </script>
                                @endpush

                            {{-- ── TYPE : ACTIVITY ──────────────────────── --}}
                            @elseif($widget['type'] === 'activity')
                                @if(empty($widget['data']))
                                    <div class="flex flex-col items-center justify-center h-full py-8 mt-text-muted">
                                        <span class="mb-3" style="opacity:0.25"><x-mt::icon name="clock" size="2xl" /></span>
                                        <p class="text-xs">{{ __('mt-ui::mt-ui.dash_no_activity') }}</p>
                                    </div>
                                @else
                                <div class="max-h-full space-y-4 overflow-y-auto">
                                    @foreach($widget['data'] as $activity)
                                    <div class="flex items-start gap-3">
                                        <div class="flex items-center justify-center flex-shrink-0 mt-1 rounded-full w-7 h-7"
                                             style="background: rgba(var(--mt-primary), 0.1)">
                                            <span style="color: rgb(var(--mt-primary))"><x-mt::icon :name="mt_icon_name($activity['icon'] ?? null, 'bell')" size="xs" /></span>
                                        </div>
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm leading-snug mt-text">
                                                {!! $activity['text'] !!}
                                            </p>
                                            <p class="text-xs mt-text-muted mt-0.5">{{ $activity['time'] }}</p>
                                        </div>
                                        @if(isset($activity['badge']))
                                            <x-mt::badge
                                                :label="$activity['badge']['label']"
                                                :variant="$activity['badge']['variant'] ?? 'gray'"
                                            />
                                        @endif
                                    </div>
                                    @endforeach
                                </div>
                                @endif

                            {{-- ── TYPE : STAT GROUP ────────────────────── --}}
                            @elseif($widget['type'] === 'stat_group')
                                <div class="space-y-2">
                                    @foreach($widget['data'] as $item)
                                    <div class="flex items-center justify-between py-2.5"
                                         style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.5)">
                                        <div class="flex items-center gap-2">
                                            @if(isset($item['icon']))
                                                <span class="mt-text-muted"><x-mt::icon :name="mt_icon_name($item['icon'])" size="xs" /></span>
                                            @endif
                                            <span class="text-sm mt-text-muted">{{ $item['label'] }}</span>
                                        </div>
                                        <div class="flex items-center gap-2">
                                            <span class="text-sm font-semibold mt-text">{{ $item['value'] }}</span>
                                            @if(isset($item['badge']))
                                                <x-mt::badge
                                                    :label="$item['badge']['label']"
                                                    :variant="$item['badge']['variant'] ?? 'gray'"
                                                />
                                            @endif
                                        </div>
                                    </div>
                                    @endforeach
                                </div>

                            {{-- ── TYPE : PROGRESS ──────────────────────── --}}
                            @elseif($widget['type'] === 'progress')
                                <div class="max-h-full space-y-4 overflow-y-auto">
                                    @foreach($widget['data'] as $item)
                                    @php
                                        $pct = min(100, max(0, $item['percent'] ?? 0));
                                        $pColorVar = match($item['color'] ?? 'primary') {
                                            'success' => 'var(--mt-success)',
                                            'warning' => 'var(--mt-warning)',
                                            'danger'  => 'var(--mt-danger)',
                                            'info'    => 'var(--mt-info)',
                                            'gray'    => 'var(--mt-text)',
                                            default   => 'var(--mt-primary)',
                                        };
                                    @endphp
                                    <div>
                                        <div class="flex items-center justify-between mb-1.5">
                                            <div class="flex items-center min-w-0 gap-2">
                                                @if(isset($item['icon']))
                                                    <span class="flex-shrink-0" style="color: rgb({{ $pColorVar }})"><x-mt::icon :name="mt_icon_name($item['icon'])" size="xs" /></span>
                                                @endif
                                                <span class="text-sm truncate mt-text">{{ $item['label'] }}</span>
                                            </div>
                                            <div class="flex items-center flex-shrink-0 gap-2 ml-2">
                                                @if(isset($item['value']))
                                                    <span class="text-xs font-medium mt-text-muted">{{ $item['value'] }}</span>
                                                @endif
                                                <span class="text-xs font-bold" style="color: rgb({{ $pColorVar }})">
                                                    {{ $pct }}%
                                                </span>
                                            </div>
                                        </div>
                                        <div class="w-full h-1.5 rounded-full mt-bg-secondary">
                                            <div class="h-1.5 rounded-full transition-all duration-700"
                                                 style="width: {{ $pct }}%; background: rgb({{ $pColorVar }})">
                                            </div>
                                        </div>
                                        @if(isset($item['meta']))
                                            <p class="mt-1 text-xs mt-text-muted">{{ $item['meta'] }}</p>
                                        @endif
                                    </div>
                                    @endforeach
                                </div>

                            {{-- ── TYPE : CUSTOM ────────────────────────── --}}
                            @elseif($widget['type'] === 'custom')
                                @if(isset($widget['view']))
                                    @include($widget['view'], $widget['view_data'] ?? [])
                                @endif
                            @endif

                        </div>

                        {{-- Widget Footer optionnel --}}
                        @if(isset($widget['footer']))
                        <div class="flex-shrink-0 px-5 py-3 text-xs mt-text-muted"
                             style="border-top: 1px solid rgb(var(--mt-ui-card-border)); background: rgba(var(--mt-text), 0.02)">
                            {{ $widget['footer'] }}
                        </div>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
            @endif

            {{-- État vide --}}
            @if(count($stats) === 0 && count($widgets) === 0)
            <div class="py-24 text-center">
                <div class="inline-flex items-center justify-center w-20 h-20 mb-6 rounded-full mt-bg-secondary">
                    <span class="mt-text-muted"><x-mt::icon name="chart-bar" size="2xl" /></span>
                </div>
                <h3 class="mb-2 text-lg font-semibold mt-text">Dashboard non configuré</h3>
                <p class="max-w-sm mx-auto text-sm mt-text-muted">
                    Étendez <code class="mt-badge mt-badge-gray px-1.5 py-0.5 rounded text-xs">Mt\MtUi\Livewire\Dashboard</code>
                    et surchargez <code class="mt-badge mt-badge-gray px-1.5 py-0.5 rounded text-xs">getStats()</code>
                    et <code class="mt-badge mt-badge-gray px-1.5 py-0.5 rounded text-xs">getWidgets()</code>.
                </p>
            </div>
            @endif

        </div>
    </div>

    {{-- Visite guidée (contenu piloté par config/tours.php de l'hôte, clé "dashboard" ; sinon rien) --}}
    <x-mt::tour name="dashboard" />
</div>
