<section class="w-full">
    @include('mt::partials.settings-heading')

    <x-mt::settings.layout :heading="__('Update password')" :subheading="__('Ensure your account is using a long, random password to stay secure')">
        <form method="POST" wire:submit="updatePassword" class="mt-6 space-y-6">
            <x-mt::form.input
                model="current_password"
                :label="__('Current password')"
                type="password"
                :required="true"
                :error="$errors->first('current_password')"
                autocomplete="current-password"
            />
            <x-mt::form.input
                model="password"
                :label="__('New password')"
                type="password"
                :required="true"
                :error="$errors->first('password')"
                autocomplete="new-password"
            />
            <x-mt::form.input
                model="password_confirmation"
                :label="__('Confirm Password')"
                type="password"
                :required="true"
                :error="$errors->first('password_confirmation')"
                autocomplete="new-password"
            />

            <div class="flex items-center gap-4">
                <div class="flex items-center justify-end">
                    <x-mt::button variant="primary" type="submit" class="w-full">{{ __('Save') }}</x-mt::button>
                </div>

                <x-action-message class="me-3" on="password-updated">
                    {{ __('Saved.') }}
                </x-action-message>
            </div>
        </form>
    </x-mt::settings.layout>
</section>
