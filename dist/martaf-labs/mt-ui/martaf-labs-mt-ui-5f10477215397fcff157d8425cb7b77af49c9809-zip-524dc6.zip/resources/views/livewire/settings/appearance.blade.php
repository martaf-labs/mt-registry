<section class="w-full">
    @include('mt::partials.settings-heading')

    <x-mt::settings.layout :heading="__('Appearance')" :subheading="__('Update the appearance settings for your account')">
        <div
            x-data="{
                theme: localStorage.getItem('theme') || 'system',
                apply() {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                    const dark = this.theme === 'dark' || (this.theme === 'system' && prefersDark);
                    document.documentElement.classList.toggle('dark', dark);
                    if (this.theme === 'system') { localStorage.removeItem('theme'); }
                    else { localStorage.setItem('theme', this.theme); }
                }
            }"
            x-init="apply()"
        >
            <div class="inline-flex gap-1 p-1 rounded-xl mt-bg-secondary">
                @foreach (['light' => ['sun', __('Light')], 'dark' => ['moon', __('Dark')], 'system' => ['computer-desktop', __('System')]] as $val => $cfg)
                    <button type="button" @click="theme = '{{ $val }}'; apply()"
                            class="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors"
                            :class="theme === '{{ $val }}' ? 'mt-bg mt-text-primary font-medium shadow-sm' : 'mt-text-muted'">
                        <x-mt::icon name="{{ $cfg[0] }}" class="size-4" />
                        {{ $cfg[1] }}
                    </button>
                @endforeach
            </div>
        </div>
    </x-mt::settings.layout>
</section>
