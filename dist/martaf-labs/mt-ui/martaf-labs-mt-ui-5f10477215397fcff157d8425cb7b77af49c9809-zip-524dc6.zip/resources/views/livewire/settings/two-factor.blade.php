<section class="w-full">
    @include('mt::partials.settings-heading')

    <x-mt::settings.layout
        :heading="__('Two Factor Authentication')"
        :subheading="__('Manage your two-factor authentication settings')"
    >
        <div class="flex flex-col w-full mx-auto space-y-6 text-sm" wire:cloak>
            @if ($twoFactorEnabled)
                <div class="space-y-4">
                    <div class="flex items-center gap-3">
                        <x-mt::badge type="success" :label="__('Enabled')" />
                    </div>

                    <p class="text-sm mt-text">
                        {{ __('With two-factor authentication enabled, you will be prompted for a secure, random pin during login, which you can retrieve from the TOTP-supported application on your phone.') }}
                    </p>

                    <livewire:settings.two-factor.recovery-codes :$requiresConfirmation/>

                    <div class="flex justify-start">
                        <x-mt::button variant="danger" icon="shield-exclamation" wire:click="disable">
                            {{ __('Disable 2FA') }}
                        </x-mt::button>
                    </div>
                </div>
            @else
                <div class="space-y-4">
                    <div class="flex items-center gap-3">
                        <x-mt::badge type="danger" :label="__('Disabled')" />
                    </div>

                    <p class="text-sm mt-text-muted">
                        {{ __('When you enable two-factor authentication, you will be prompted for a secure pin during login. This pin can be retrieved from a TOTP-supported application on your phone.') }}
                    </p>

                    <x-mt::button variant="primary" icon="shield-check" wire:click="enable">
                        {{ __('Enable 2FA') }}
                    </x-mt::button>
                </div>
            @endif
        </div>
    </x-mt::settings.layout>

    <x-mt::modal name="two-factor-setup-modal" wire="showModal" maxWidth="md">
        <div class="space-y-6">
            <div class="flex flex-col items-center space-y-4">
                <div class="p-2.5 rounded-full mt-bg-secondary">
                    <x-mt::icon name="qr-code" class="size-6 mt-text-primary"/>
                </div>

                <div class="space-y-2 text-center">
                    <h3 class="text-lg font-semibold mt-text">{{ $this->modalConfig['title'] }}</h3>
                    <p class="text-sm mt-text-muted">{{ $this->modalConfig['description'] }}</p>
                </div>
            </div>

            @if ($showVerificationStep)
                <div class="space-y-6">
                    <div class="flex flex-col items-center space-y-3">
                        <x-mt::input-otp
                            :digits="6"
                            name="code"
                            wire:model="code"
                            autocomplete="one-time-code"
                        />
                        @error('code')
                            <p class="text-sm" style="color:rgb(var(--mt-danger))">
                                {{ $message }}
                            </p>
                        @enderror
                    </div>

                    <div class="flex items-center space-x-3">
                        <x-mt::button variant="outline" class="flex-1" wire:click="resetVerification">
                            {{ __('Back') }}
                        </x-mt::button>

                        <x-mt::button
                            variant="primary"
                            class="flex-1"
                            wire:click="confirmTwoFactor"
                            x-bind:disabled="$wire.code.length < 6"
                        >
                            {{ __('Confirm') }}
                        </x-mt::button>
                    </div>
                </div>
            @else
                @error('setupData')
                    <div class="p-3 rounded-lg mt-alert mt-alert-danger">{{ $message }}</div>
                @enderror

                <div class="flex justify-center">
                    <div class="relative w-64 overflow-hidden border rounded-lg aspect-square" style="border-color: rgb(var(--mt-ui-card-border))">
                        @empty($qrCodeSvg)
                            <div class="absolute inset-0 flex items-center justify-center mt-bg-secondary animate-pulse">
                                <i class="fa-solid fa-circle-notch fa-spin mt-text-muted"></i>
                            </div>
                        @else
                            <div class="flex items-center justify-center h-full p-4">
                                {!! $qrCodeSvg !!}
                            </div>
                        @endempty
                    </div>
                </div>

                <div>
                    <x-mt::button
                        :disabled="$errors->has('setupData')"
                        variant="primary"
                        class="w-full"
                        wire:click="showVerificationIfNecessary"
                    >
                        {{ $this->modalConfig['buttonText'] }}
                    </x-mt::button>
                </div>

                <div class="space-y-4">
                    <div class="relative flex items-center justify-center w-full">
                        <div class="absolute inset-0 w-full h-px top-1/2" style="background: rgb(var(--mt-ui-card-border))"></div>
                        <span class="relative px-2 text-sm mt-bg mt-text-muted">
                            {{ __('or, enter the code manually') }}
                        </span>
                    </div>

                    <div
                        class="flex items-center space-x-2"
                        x-data="{
                            copied: false,
                            async copy() {
                                try {
                                    await navigator.clipboard.writeText('{{ $manualSetupKey }}');
                                    this.copied = true;
                                    setTimeout(() => this.copied = false, 1500);
                                } catch (e) {
                                    console.warn('Could not copy to clipboard');
                                }
                            }
                        }"
                    >
                        <div class="flex items-stretch w-full border rounded-xl" style="border-color: rgb(var(--mt-ui-card-border))">
                            @empty($manualSetupKey)
                                <div class="flex items-center justify-center w-full p-3 mt-bg-secondary">
                                    <i class="fa-solid fa-circle-notch fa-spin mt-text-muted"></i>
                                </div>
                            @else
                                <input
                                    type="text"
                                    readonly
                                    value="{{ $manualSetupKey }}"
                                    class="w-full p-3 bg-transparent outline-none mt-text"
                                />

                                <button
                                    @click="copy()"
                                    class="px-3 transition-colors border-l cursor-pointer"
                                    style="border-color: rgb(var(--mt-ui-card-border))"
                                >
                                    <x-mt::icon name="copy" x-show="!copied" />
                                    <x-mt::icon name="check" x-show="copied" class="text-green-500" />
                                </button>
                            @endempty
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </x-mt::modal>
</section>
