<section class="w-full">
    @include('mt::partials.settings-heading')

    <x-mt::settings.layout :heading="__('Profile')" :subheading="__('Update your name and email address')">
        <form wire:submit="updateProfileInformation" class="my-6 w-full space-y-6">
            <x-mt::form.input model="name" :label="__('Name')" type="text" :required="true" :error="$errors->first('name')" autofocus autocomplete="name" />

            <div>
                <x-mt::form.input model="email" :label="__('Email')" type="email" :required="true" :error="$errors->first('email')" autocomplete="email" />

                @if (auth()->user() instanceof \Illuminate\Contracts\Auth\MustVerifyEmail &&! auth()->user()->hasVerifiedEmail())
                    <div>
                        <p class="mt-4 text-sm mt-text-muted">
                            {{ __('Your email address is unverified.') }}

                            <button type="button" class="text-sm cursor-pointer font-medium mt-text-primary hover:underline" wire:click.prevent="resendVerificationNotification">
                                {{ __('Click here to re-send the verification email.') }}
                            </button>
                        </p>

                        @if (session('status') === 'verification-link-sent')
                            <p class="mt-2 text-sm font-medium" style="color:rgb(var(--mt-success))">
                                {{ __('A new verification link has been sent to your email address.') }}
                            </p>
                        @endif
                    </div>
                @endif
            </div>

            <div class="flex items-center gap-4">
                <div class="flex items-center justify-end">
                    <x-mt::button variant="primary" type="submit" class="w-full">{{ __('Save') }}</x-mt::button>
                </div>

                <x-mt::action-message class="me-3" on="profile-updated">
                    {{ __('Saved.') }}
                </x-mt::action-message>
            </div>
        </form>

        {{-- alias enregistré dans le SP = mt.settings.delete-user (pas …-form) --}}
        <livewire:mt.settings.delete-user />
    </x-mt::settings.layout>
</section>
