<section class="mt-10 space-y-6">
    <div class="relative mb-5">
        <h2 class="text-lg font-semibold mt-text">{{ __('Delete account') }}</h2>
        <p class="text-sm mt-text-muted">{{ __('Delete your account and all of its resources') }}</p>
    </div>

    <x-mt::button variant="danger" x-data="" @click="$dispatch('open-modal', { name: 'confirm-user-deletion' })">
        {{ __('Delete account') }}
    </x-mt::button>

    <x-mt::modal name="confirm-user-deletion" maxWidth="lg" :title="__('Delete account')">
        <form method="POST" wire:submit="deleteUser" class="space-y-6">
            <div>
                <h3 class="text-lg font-semibold mt-text">{{ __('Are you sure you want to delete your account?') }}</h3>

                <p class="mt-1 text-sm mt-text-muted">
                    {{ __('Once your account is deleted, all of its resources and data will be permanently deleted. Please enter your password to confirm you would like to permanently delete your account.') }}
                </p>
            </div>

            <x-mt::form.input model="password" :label="__('Password')" type="password" :error="$errors->first('password')" />

            <div class="flex justify-end space-x-2 rtl:space-x-reverse">
                <x-mt::button variant="ghost" type="button" @click="$dispatch('close-modal', { name: 'confirm-user-deletion' })">{{ __('Cancel') }}</x-mt::button>
                <x-mt::button variant="danger" type="submit">{{ __('Delete account') }}</x-mt::button>
            </div>
        </form>
    </x-mt::modal>
</section>
