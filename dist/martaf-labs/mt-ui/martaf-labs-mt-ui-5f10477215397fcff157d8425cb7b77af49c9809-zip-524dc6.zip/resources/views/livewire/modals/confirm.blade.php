<x-mt::modal wire="isOpen" openEvent="open-confirm-modal" :closable="false" maxWidth="sm">
    <div class="text-center">
        <div class="flex flex-col items-center gap-4 p-2">
            <!-- Icône -->
            <div class="p-3 rounded-full {{
                match($variant) {
                    'danger' => 'bg-red-100 text-red-600 dark:bg-red-900/20 dark:text-red-400',
                    'primary' => 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',
                    'success' => 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400',
                    'warning' => 'bg-amber-100 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400',
                    default => 'bg-red-100 text-red-600 dark:bg-red-900/20 dark:text-red-400'
                }
            }}">
                <x-mt::icon name="{{ $icon }}" class="w-6 h-6" />
            </div>

            <!-- Titre -->
            <h3 class="text-lg font-semibold mt-text">
                {{ $title }}
            </h3>

            <!-- Message -->
            <p class="mt-2 text-sm mt-text-muted">
                {!! $message !!}
            </p>
        </div>
    </div>

    <div class="flex justify-center gap-3 mt-2">
        <x-mt::button variant="ghost" wire:click="closeModal" class="min-w-24">
            {{ $cancelText }}
        </x-mt::button>

        <x-mt::button :variant="$variant === 'danger' ? 'danger' : 'primary'" wire:click="confirm" class="min-w-24">
            {{ $confirmText }}
        </x-mt::button>
    </div>
</x-mt::modal>
