<x-mt::modal wire="isOpen" :closable="false" maxWidth="sm">
    <div class="text-center">
        <div class="flex flex-col items-center gap-4 p-2">
            <!-- Icône -->
            <div class="p-3 rounded-full {{
                match($variant) {
                    'success' => 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400',
                    'error' => 'bg-red-100 text-red-600 dark:bg-red-900/20 dark:text-red-400',
                    'warning' => 'bg-amber-100 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400',
                    'info' => 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',
                    default => 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400'
                }
            }}">
                <x-mt::icon name="{{ $icon }}" class="w-6 h-6" />
            </div>

            <!-- Titre -->
            <h3 class="text-lg font-semibold mt-text">
                {{ $title }}
            </h3>

            <!-- Message -->
            <p class="text-sm mt-text-muted whitespace-pre-line">
                {{ $message }}
            </p>

            <!-- Barre de progression pour auto-close -->
            @if($autoClose)
            <div class="w-full mt-2 bg-zinc-200 dark:bg-zinc-700 rounded-full h-1">
                <div
                    class="h-1 rounded-full {{
                        match($variant) {
                            'success' => 'bg-green-500',
                            'error' => 'bg-red-500',
                            'warning' => 'bg-amber-500',
                            'info' => 'bg-blue-500',
                            default => 'bg-green-500'
                        }
                    }}"
                    x-data="{ width: '0%' }"
                    x-init="setTimeout(() => { width = '100%' }, 100);
                            setTimeout(() => $wire.closeModal(), {{ $autoCloseDelay }});"
                    :style="`width: ${width}; transition: width {{ $autoCloseDelay }}ms linear;`"
                ></div>
            </div>
            @endif
        </div>
    </div>

    <div class="flex justify-center mt-4">
        <x-mt::button wire:click="closeModal" class="min-w-24">
            {{ $buttonText }}
        </x-mt::button>
    </div>

    @script
    <script>
        Livewire.on('startAutoClose', ({ delay }) => {
            setTimeout(() => { $wire.closeModal(); }, delay);
        });
    </script>
    @endscript
</x-mt::modal>
