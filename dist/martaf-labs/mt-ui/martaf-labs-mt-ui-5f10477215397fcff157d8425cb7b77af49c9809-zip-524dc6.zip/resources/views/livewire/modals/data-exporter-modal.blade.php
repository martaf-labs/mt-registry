<div>
    @php
        $name = "data-exporter-modal";
    @endphp

    <x-mt::modal name="{{ $name }}" wire="isOpen" maxWidth="xl" :title="__('Exporter les données')">

        <div>
            <p class="my-2 text-sm mt-text-muted">
                Sélectionnez le format et les colonnes pour l'exportation
            </p>
        </div>

        <div class="h-full w-full">
            <div class="space-y-4 h-full p-5 border border-dashed rounded-lg" style="border-color: rgb(var(--mt-ui-card-border))">

                <div class="p-2">
                    <!-- En-tête -->
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-lg font-semibold mt-text">
                            Exporter les données
                        </h3>

                        @if($exportSuccess)
                            <div class="flex items-center gap-2" style="color:rgb(var(--mt-success))">
                                <x-mt::icon name="check-circle" class="w-5 h-5" />
                                <span class="text-sm font-medium">Export réussi</span>
                            </div>
                        @endif
                    </div>

                    <!-- Sélection du format -->
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium mt-text-muted mb-2">
                                Format d'export
                            </label>
                            <div class="grid grid-cols-2 md:grid-cols-5 gap-2">
                                @foreach([
                                    'excel' => ['color' => 'bg-green-50 border-green-200 text-green-700', 'icon' => '📊', 'label' => 'Excel'],
                                    'pdf' => ['color' => 'bg-red-50 border-red-200 text-red-700', 'icon' => '📄', 'label' => 'PDF'],
                                ] as $format => $config)
                                    <button
                                        type="button"
                                        wire:click="$set('selectedFormat', '{{ $format }}')"
                                        class="p-3 border-2 rounded-lg text-center transition-all duration-200 hover:scale-105 {{ $selectedFormat === $format ? 'ring-2 ring-offset-2 ' . $config['color'] : 'mt-card mt-text' }}"
                                    >
                                        <div class="text-2xl mb-1">{{ $config['icon'] }}</div>
                                        <div class="text-sm font-medium">{{ $config['label'] }}</div>
                                    </button>
                                @endforeach
                            </div>
                        </div>

                        <div class="py-4 space-y-4">
                            <!-- Champs à exporter -->
                            <x-mt::form.select wire:model.defer="selectedcolumns" multiple>
                                @forelse ($allowedcolumns as $field => $label)
                                    <option value="{{ $field }}">{{ $label }}</option>
                                @empty
                                    <option value="">Aucune colonne...</option>
                                @endforelse
                            </x-mt::form.select>

                            <!-- Nom du fichier -->
                            <x-mt::form.input type="text" model="filename" label="Nom du fichier" />
                        </div>

                        <div class="flex items-center justify-between pt-4">
                            <div class="text-sm mt-text-muted">
                                @if($data && count($data) > 0)
                                    {{ count($data) }} enregistrement(s) à exporter
                                @else
                                    Aucune donnée à exporter
                                @endif
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Message d'erreur -->
        @if($exportMessage)
            <div class="mt-4 p-3 rounded-md mt-alert mt-alert-danger">
                <div class="flex items-center">
                    <x-mt::icon name="exclamation-triangle" class="w-5 h-5 mr-2" />
                    <span class="text-sm">{{ $exportMessage }}</span>
                </div>
            </div>
        @endif

        <div class="flex justify-end gap-3 mt-4 pt-4">
            <x-mt::button
                variant="primary"
                icon="arrow-down-tray"
                wire:click="export"
                wire:loading.attr="disabled"
                wire:target="export"
                :disabled="count($data ?? []) === 0"
            >
                <span wire:loading.remove wire:target="export">
                    Exporter en {{ strtoupper($selectedFormat) }}
                </span>
                <span wire:loading wire:target="export" class="flex items-center">
                    <x-mt::icon name="arrow-path" class="w-4 h-4 mr-2 animate-spin" />
                    Export en cours...
                </span>
            </x-mt::button>
        </div>
    </x-mt::modal>

</div>
