{{--
    Composant : <x-mt::modal>
    Modal générique (Alpine + tokens mt). Remplace flux:modal.

    Contrôle :
      - via Livewire : <x-mt::modal wire="isOpen"> (entangle la propriété)
      - via évènements : $dispatch('open-modal', { name: 'X' }) / 'close-modal'
        avec <x-mt::modal name="X">
      - via x-show passé par un parent Alpine (l'attribut x-show est respecté)

    RESPONSIVE (2026-07-22) : DESKTOP/TABLETTE = carte centrée (rise+fade) ; MOBILE (< lg) =
    BOTTOM-SHEET (poignée + glissement depuis le bas, coins arrondis haut, max-height + scroll,
    safe-area) — même esprit que le dropdown. Positionnement/forme/anim pilotés par des classes
    `.mt-modal-*` (média-query en @once → fiable, indépendant des utilitaires responsives du CSS servi).
    Le SLOT n'est PAS dupliqué (un modal contient des forms Livewire → un seul rendu).

    IMPORTANT z-index : style INLINE (z-index: 10000), pas la classe arbitraire z-[10000]
    (absente du CSS précompilé → aucun effet).

    Props : name, title, icon, closable, closeOnOverlay, maxWidth (sm|md|lg|xl), wire
    Slots : (défaut) corps, $footer (optionnel)
--}}
@props([
    'name'           => 'modal',
    'title'          => null,
    'icon'           => null,
    'closable'       => true,
    'closeOnOverlay' => true,   // false = l'overlay ne ferme pas (formulaires critiques)
    'maxWidth'       => 'md',
    'wire'           => null,
    'openEvent'      => null,   // nom d'évènement window → ouverture OPTIMISTE (instantanée, côté Alpine)
    'closeEvent'     => null,   // idem pour fermer
])
@php
    $w = ['sm' => '24rem', 'md' => '28rem', 'lg' => '32rem', 'xl' => '42rem'][$maxWidth] ?? '28rem';
@endphp

@once
<style>
    /* Conteneur : desktop centré / mobile ancré en bas. */
    .mt-modal-wrap  { align-items: center; padding: 1rem; }
    /* Panneau : desktop carte arrondie ; largeur max via var CSS locale. */
    .mt-modal-panel { width: 100%; max-width: var(--mt-modal-w, 28rem); border-radius: 1rem; }
    /* Anim d'entrée : desktop léger « rise », mobile glissement plein depuis le bas. */
    .mt-modal-enter { transform: translateY(24px); }
    @media (max-width: 1023px) {
        .mt-modal-wrap  { align-items: flex-end; padding: 0; }
        .mt-modal-panel {
            max-width: 100%;
            border-radius: 22px 22px 0 0;
            max-height: 92vh; overflow-y: auto;
            padding-bottom: env(safe-area-inset-bottom, 0px);
        }
        .mt-modal-enter { transform: translateY(100%); }
    }
</style>
@endonce

<div
    x-data="{ open: @if($wire)@entangle($wire)@else false @endif }"
    @open-modal.window="if ($event.detail?.name === '{{ $name }}') open = true"
    @close-modal.window="if ($event.detail?.name === '{{ $name }}') open = false"
    @if($openEvent) x-on:{{ $openEvent }}.window="open = true" @endif
    @if($closeEvent) x-on:{{ $closeEvent }}.window="open = false" @endif
    @keydown.escape.window="@if($closable) open = false @endif"
    x-show="open"
    x-cloak
    class="fixed inset-0 flex justify-center mt-modal-wrap"
    style="z-index: 10000;"
>
    {{-- Overlay - le clic ferme seulement si closeOnOverlay=true --}}
    <div x-show="open" x-transition.opacity
         @if($closable && $closeOnOverlay) @click="open = false" @endif
         class="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>

    {{-- Panneau - fond SOLIDE via token (opaque), au-dessus de l'overlay --}}
    <div x-show="open"
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 mt-modal-enter"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0 mt-modal-enter"
         @click.stop
         class="relative overflow-hidden shadow-2xl mt-modal-panel"
         style="--mt-modal-w: {{ $w }}; background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgba(var(--mt-ui-card-border), 0.6);">

        {{-- Poignée (mobile uniquement) --}}
        <div class="flex justify-center pt-3 pb-1 lg:hidden">
            <div style="width:42px;height:5px;border-radius:999px;background:rgb(var(--mt-ui-card-border))"></div>
        </div>

        @if($title || $closable)
            <div class="flex items-center justify-between gap-3 px-5 py-4"
                 style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                <div class="flex items-center min-w-0 gap-2">
                    @if($icon)
                        <span class="mt-text-primary"><x-mt::icon :name="$icon" /></span>
                    @endif
                    @if($title)
                        <h3 class="text-base font-semibold truncate mt-text">{{ $title }}</h3>
                    @endif
                </div>
                @if($closable)
                    <button type="button" @click="open = false"
                            class="flex items-center justify-center w-8 h-8 rounded-full mt-btn-icon">
                        <x-mt::icon name="x-mark" />
                    </button>
                @endif
            </div>
        @endif

        <div class="p-5">{{ $slot }}</div>

        @isset($footer)
            <div class="flex items-center justify-end gap-3 px-5 py-4"
                 style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                {{ $footer }}
            </div>
        @endisset
    </div>
</div>
