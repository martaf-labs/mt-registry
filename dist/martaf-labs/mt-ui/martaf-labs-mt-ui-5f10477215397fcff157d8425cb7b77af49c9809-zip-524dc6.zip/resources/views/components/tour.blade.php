{{--
    Composant : <x-mt::tour>
    Visite guidée légère (Alpine, zéro dépendance JS). Surbrillance pas-à-pas
    pilotée par un registre côté hôte (config/tours.php → mt_tour($name)).

    - Spotlight : un cadre `fixed` sur la cible + `box-shadow` géant = masque sombre
      avec « trou » sur l'élément visé (pas d'overlay multi-div).
    - Complétion mémorisée en localStorage (clé mt-tour-<name>) → ne se relance pas.
    - `auto` (défaut true) : démarre au 1er accès si non terminé. Sinon, déclencher
      via window-event : $dispatch('start-tour', { name: '<name>' }).

    ⚠️ x-data INLINE (pas de `Alpine.data('mtTour', …)` via @push/alpine:init) : sur
    wire:navigate, Alpine est déjà démarré et `alpine:init` NE se redéclenche PLUS →
    un composant nommé enregistré à ce moment serait « not defined » sur la page suivante.
    L'objet inline, lui, est évalué à chaque rendu/navigation comme help/toggle/modal.

    Props : name (clé de tour), auto (bool)
--}}
@props([
    'name' => 'default',
    'auto' => true,
])
@php $steps = mt_tour($name); @endphp

@if(!empty($steps))
    <div
        x-data="{
            name: @js($name),
            steps: @js($steps),
            auto: @js((bool) $auto),
            index: 0,
            active: false,
            rect: null,
            _placement: 'bottom',

            init() {
                if (this.auto && !this.done()) {
                    // Laisse le DOM se stabiliser (Livewire morph).
                    setTimeout(() => this.start(), 600);
                }
                window.addEventListener('start-tour', (e) => {
                    if (!e.detail || e.detail.name === this.name) this.start(true);
                });
                window.addEventListener('resize', () => this.measure());
                window.addEventListener('scroll', () => this.measure(), true);
            },

            get current() { return this.steps[this.index] || { title: '', body: '' }; },

            storageKey() { return 'mt-tour-' + this.name; },
            done() { try { return localStorage.getItem(this.storageKey()) === '1'; } catch (e) { return false; } },
            markDone() { try { localStorage.setItem(this.storageKey(), '1'); } catch (e) {} },

            start(force = false) {
                if (!this.steps.length) return;
                if (!force && this.done()) return;
                this.index = 0;
                this.active = true;
                this.$nextTick(() => this.goTo(0));
            },

            goTo(i) {
                if (i < 0 || i >= this.steps.length) return;
                this.index = i;
                const el = document.querySelector(this.steps[i].target);
                if (!el) {
                    // Cible absente → étape suivante (ou fin).
                    if (i < this.steps.length - 1) return this.goTo(i + 1);
                    return this.stop(true);
                }
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                setTimeout(() => this.measure(), 250);
            },

            measure() {
                if (!this.active) return;
                const el = document.querySelector(this.steps[this.index].target);
                if (!el) { this.rect = null; return; }
                const r = el.getBoundingClientRect();
                this.rect = { left: r.left, top: r.top, width: r.width, height: r.height, bottom: r.bottom };
                this._placement = (r.bottom + 180 > window.innerHeight) ? 'top' : 'bottom';
            },

            tooltipStyle() {
                if (!this.rect) return {};
                const below = this._placement === 'bottom';
                return {
                    position: 'fixed',
                    left: Math.min(Math.max(this.rect.left, 12), window.innerWidth - 300) + 'px',
                    top: (below ? this.rect.bottom + 14 : this.rect.top - 14) + 'px',
                    transform: below ? 'none' : 'translateY(-100%)',
                    zIndex: 10061,
                };
            },

            next() {
                if (this.index === this.steps.length - 1) return this.stop(true);
                this.goTo(this.index + 1);
            },
            prev() { this.goTo(this.index - 1); },

            stop(markDone = false) {
                this.active = false;
                this.rect = null;
                if (markDone) this.markDone();
            },
        }"
        x-cloak
    >
        <template x-if="active && rect">
            {{-- Spotlight : trou sur la cible --}}
            <div :style="{
                    position: 'fixed',
                    left: rect.left - 6 + 'px',
                    top: rect.top - 6 + 'px',
                    width: rect.width + 12 + 'px',
                    height: rect.height + 12 + 'px',
                    borderRadius: '12px',
                    boxShadow: '0 0 0 9999px rgba(0,0,0,0.6)',
                    border: '2px solid rgb(var(--mt-primary))',
                    zIndex: 10060,
                    pointerEvents: 'none',
                    transition: 'all 0.2s ease',
                 }"></div>
        </template>

        {{-- Capteur de clic plein écran (fermer en cliquant hors infobulle) --}}
        <template x-if="active">
            <div @click="stop(true)"
                 style="position: fixed; inset: 0; z-index: 10055;"></div>
        </template>

        {{-- Infobulle --}}
        <template x-if="active && rect">
            <div :style="tooltipStyle()"
                 class="w-72 max-w-xs rounded-2xl p-4 shadow-2xl"
                 style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgb(var(--mt-ui-card-border));"
                 @click.stop>
                <div class="mb-2 flex items-center justify-between gap-3">
                    <h4 class="text-sm font-semibold mt-text" x-text="current.title"></h4>
                    <span class="text-[11px] mt-text-muted" x-text="(index + 1) + ' / ' + steps.length"></span>
                </div>
                <p class="mt-text-muted text-xs leading-relaxed" x-text="current.body"></p>

                <div class="mt-4 flex items-center justify-between gap-2">
                    <button type="button" @click="stop(true)"
                            class="text-[11px] mt-text-muted hover:mt-text transition">
                        {{ __('mt-ui::mt-ui.tour_skip') }}
                    </button>
                    <div class="flex items-center gap-2">
                        <button type="button" x-show="index > 0" @click="prev()"
                                class="rounded-lg px-3 py-1.5 text-xs mt-text"
                                style="border: 1px solid rgb(var(--mt-ui-card-border));">
                            {{ __('mt-ui::mt-ui.tour_prev') }}
                        </button>
                        <button type="button" @click="next()"
                                class="rounded-lg px-3 py-1.5 text-xs font-medium"
                                style="background: rgb(var(--mt-primary)); color: rgb(var(--mt-primary-content));"
                                x-text="index === steps.length - 1 ? @js(__('mt-ui::mt-ui.tour_finish')) : @js(__('mt-ui::mt-ui.tour_next'))"></button>
                    </div>
                </div>
            </div>
        </template>
    </div>
@endif
