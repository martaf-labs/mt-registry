@props([
    'name',
    'size' => 'md',
    'color' => 'currentColor',
    'class' => '',
])

@php
    // IconRenderer attend le nom BRUT (ex. "home"). On tolère un nom préfixé
    // "mt-icon-..." (renvoyé par mt_get_icon / la config sidebar) en retirant le préfixe.
    $iconName = \Illuminate\Support\Str::startsWith($name, 'mt-icon-')
        ? \Illuminate\Support\Str::after($name, 'mt-icon-')
        : $name;
@endphp

{!! app(\MtIcons\IconRenderer::class)->render($iconName, [
    'size'  => $size,
    'color' => $color,
    'class' => $class . ($attributes->get('class') ?? ''),
]) !!}
