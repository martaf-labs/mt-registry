@props([
    'actions' => false,
    'visible' => 1,
    'size' => "md"
])

@php
    // Tolère UNE action (tableau associatif) OU une LISTE d'actions. Sans cette
    // normalisation, une action unique était comptée par ses CLÉS → un ⋮ vide s'affichait.
    $actions = is_array($actions) ? (array_is_list($actions) ? $actions : [$actions]) : [];
    // N'garde que des actions réelles (tableaux).
    $actions = array_values(array_filter($actions, 'is_array'));
@endphp

@if(count($actions) > 0)

    @php
        $visible = intVal($visible);
        $visibleActions=$visible != 0 ? array_slice($actions, 0,$visible) : [];
        $hiddenActions=$visible != 0 ? array_slice($actions, $visible) : $actions;
    @endphp

    <div class="flex justify-end items-center gap-2 flex-nowrap">
        @if(count($visibleActions) > 0) 
            @foreach ($visibleActions as $action)
                @php $actionIcon=$action['icon'] ?? $action['icone'] ?? ''; @endphp
                @if (is_array($action))
                    {{-- ⚠️ pas de directive @if DANS un tag de composant → branches autour du tag --}}
                    @if (isset($action['lien']) || isset($action['route']))
                        @if (($action['target'] ?? null) === '_blank')
                        {{-- 'target' => '_blank' : PDF/export en nouvel onglet --}}
                        <x-mt::button href="{{ $action['lien'] ?? $action['route'] ?? '#' }}" target="_blank" icon="{{ $actionIcon }}" size="{{ $size }}" variant="{{ $action['variant'] ?? 'outline' }}" style="">
                            {{ $action['label'] ?? '' }}
                        </x-mt::button>
                        @else
                        <x-mt::button href="{{ $action['lien'] ?? $action['route'] ?? '#' }}" icon="{{ $actionIcon }}" size="{{ $size }}" variant="{{ $action['variant'] ?? 'outline' }}" style="">
                            {{ $action['label'] ?? '' }}
                        </x-mt::button>
                        @endif
                    @endif

                    @if (isset($action['method']))
                        @if (!empty($action['confirm']))
                        {{-- 'confirm' => '…' : confirmation Livewire avant l'action (générer/publier…) --}}
                        <x-mt::button wire:click="{{ $action['method'] ?? '' }}" wire:confirm="{{ $action['confirm'] }}" size="{{ $size }}" icon="{{ $actionIcon }}" variant="{{ $action['variant'] ?? 'outline' }}" style="">
                            {{ $action['label'] ?? '' }}
                        </x-mt::button>
                        @else
                        <x-mt::button wire:click="{{ $action['method'] ?? '' }}" size="{{ $size }}" icon="{{ $actionIcon }}" variant="{{ $action['variant'] ?? 'outline' }}" style="">
                            {{ $action['label'] ?? '' }}
                        </x-mt::button>
                        @endif
                    @endif
                @endif
            @endforeach
        @endif
        

        @if (count($hiddenActions) > 0)
        <x-mt::dropdown>                
            <x-slot:trigger>
                <button type="button" class="mt-btn-icon mt-btn-icon-sm" title="Plus d'actions">
                    <x-mt::icon name="ellipsis-horizontal" size="sm" />
                </button>
            </x-slot:trigger>

                <x-mt::dropdown.menu>
                @foreach ($hiddenActions as $action)
                    @php $actionIcon = $action['icon'] ?? $action['icone'] ?? ''; @endphp
                    @if (is_array($action))
                        <x-mt::dropdown.item
                            href="{{ $action['lien'] ?? $action['route'] ?? '#'}}"
                            :icon="$actionIcon"
                            variant="{{ $action['variant'] ?? 'secondary' }}"
                            label="{{ $action['label'] ?? '' }}" 
                        />
                    @endif
                @endforeach
            </x-mt::dropdown.menu>
        </x-mt::dropdown>
        @endif

    </div>
@endif