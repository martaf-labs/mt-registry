@props([
    'actions' => false,
    'visible' => 1
])

@if($actions)
@php
    $visibleActions = array_slice($actions, 0, $visible);
    $hiddenActions = array_slice($actions, $visible);
@endphp

<div 
    x-data="{ open: false }" 
    class="fixed bottom-[75px] right-5 flex flex-col items-end z-30 space-y-2">

    {{-- Actions visibles --}}
    <template x-if="open">
        <div class="flex flex-col items-end mt-2 space-y-2">
            @foreach($visibleActions as $action)
                @if(is_array($action))
                    @if(isset($action['lien']) || isset($action['route']))
                        <x-mt::button 
                            href="{{ $action['lien'] ?? $action['route'] ?? '#' }}" 
                            label="{{ $action['label'] ?? '' }}"
                            icon="{{ $action['icon'] ?? '' }}"
                            variant="{{ 'secondary' }}"
                            size="sm"
                            {{-- class="flex items-center gap-2 px-4 py-2 text-sm text-gray-800 transition bg-white rounded-lg shadow lg:text-md hover:bg-gray-100" --}}
                            />
                    @endif

                    @if(isset($action['method']))
                        <x-mt::button 
                            variant="{{ 'secondary' }}" 
                            wire:click="{{ $action['method'] ?? '' }}" 
                            label="{{ $action['label'] ?? '' }}"
                            icon="{{ $action['icon'] ?? '' }}"
                            size="sm"
                            {{-- class="flex items-center gap-2 px-4 py-2 text-sm text-gray-800 transition bg-white rounded-lg shadow lg:text-md hover:bg-gray-100" --}}
                        />
                    @endif
                @endif
            @endforeach
        </div>
    </template>

    {{-- Actions cachées --}}
    @if(count($hiddenActions) > 0)
    <x-mt::dropdown class="mt-2">
        <x-slot:trigger>
            <x-mt::button variant="secondary" icon="ellipsis-vertical" title="Plus d'actions"></x-mt::button>
        </x-slot:trigger>
        <x-mt::dropdown.menu>
            @foreach($hiddenActions as $action)
                @if(is_array($action))
                    <x-mt::dropdown.item
                        wire:navigate
                        href="{{ $action['lien'] ?? $action['route'] ?? '#' }}"
                        :variant="$action['variant'] ?? 'secondary'"
                        :icon="$action['icon'] ?? null"
                        :label="$action['label'] ?? ''" />
                @endif
            @endforeach
        </x-mt::dropdown.menu>
    </x-mt::dropdown>
    @endif

    {{-- Bouton flottant principal --}}
    <button 
        @click="open = !open" 
        class="w-12 h-12 p-2 text-white transition bg-green-700 rounded-full shadow-lg hover:bg-green-700/90"
        aria-label="Actions">
        <x-mt::icon name="plus" />
    </button>

</div>
@endif