{{--
    Composant : <x-mt::auth-shell title="…" subtitle="…" icon="key" [brand] [back] [pip]>…form…</x-mt::auth-shell>
    Habillage immersif commun des écrans d'authentification (login, mot de passe oublié, reset) :
    bandeau de marque en dégradé mt-primary + feuille de saisie surélevée. Plein écran sur mobile,
    carte-device centrée sur desktop. 100 % tokens mt-ui (thème clair/sombre + tenant).

    Props : title (titre de la feuille) · subtitle (sous-titre de la feuille) · icon (icône du médaillon,
            défaut 'key') · brand (sous-titre du bandeau, défaut login_immersive_sub) · back (flèche retour
            → login + titre dans la barre au lieu du grand logo) · pip (icône de la pastille d'accent).
--}}
@props([
    'title'    => '',
    'subtitle' => null,
    'icon'     => 'key',
    'brand'    => null,
    'back'     => false,
    'pip'      => 'shield-check',
])

<div class="mt-auth-imm">
    @once
    <style>
        /* Full-bleed : les BANDES de couleur occupent toute la largeur à toutes les tailles ;
           le CONTENU est centré via `.mt-auth-inner` (max-width). Pas d'arrondi, pas de halo. */
        .mt-auth-imm{min-height:100vh;display:flex;flex-direction:column;background:rgb(var(--mt-ui-card-bg))}
        .mt-auth-device{flex:1;width:100%;display:flex;flex-direction:column;background:rgb(var(--mt-ui-card-bg))}
        .mt-auth-top{position:relative;text-align:center;color:rgb(var(--mt-primary-content));
            padding:calc(2.75rem + env(safe-area-inset-top,0px)) 1.5rem 4rem;overflow:hidden;
            background:
                radial-gradient(120% 90% at 84% -12%, color-mix(in oklab, rgb(var(--mt-accent)) 60%, transparent) 0%, transparent 52%),
                radial-gradient(90% 80% at -5% 0%, color-mix(in oklab, rgb(var(--mt-primary)) 60%, #fff 40%) 0%, transparent 46%),
                linear-gradient(158deg, rgb(var(--mt-primary)) 0%, color-mix(in oklab, rgb(var(--mt-primary)) 50%, #000 50%) 100%)}
        .mt-auth-top::after{content:"";position:absolute;left:-30%;right:-30%;bottom:-1px;height:54px;
            background:rgb(var(--mt-ui-card-bg));border-radius:50% 50% 0 0 / 100% 100% 0 0}
        .mt-auth-topbar{position:absolute;left:1rem;right:1rem;top:calc(1.25rem + env(safe-area-inset-top,0px));
            display:flex;align-items:center;justify-content:space-between;gap:.5rem}
        .mt-auth-back{width:34px;height:34px;border-radius:12px;display:grid;place-items:center;color:#fff;
            background:rgba(255,255,255,.16);text-decoration:none}
        .mt-auth-back .mt-icon,.mt-auth-back svg{width:17px;height:17px}
        .mt-auth-tbtitle{font-size:.95rem;font-weight:700}
        .mt-auth-badge{width:90px;height:90px;margin:0 auto;border-radius:26px;display:grid;place-items:center;position:relative;
            background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.28);box-shadow:0 16px 34px -14px rgba(0,0,0,.55)}
        .mt-auth-badge .mt-icon,.mt-auth-badge svg{width:42px;height:42px}
        .mt-auth-pip{position:absolute;right:-6px;top:-6px;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;
            background:rgb(var(--mt-accent));color:rgb(var(--mt-primary-content));box-shadow:0 6px 14px -4px rgba(0,0,0,.5)}
        .mt-auth-pip .mt-icon,.mt-auth-pip svg{width:15px;height:15px}
        .mt-auth-logo{font-size:1.7rem;font-weight:900;letter-spacing:.01em;margin-top:.85rem;line-height:1}
        .mt-auth-sub{margin:.45rem auto 0;font-size:.8rem;line-height:1.5;opacity:.85;max-width:28ch}
        .mt-auth-sheet{position:relative;z-index:2;margin-top:-2rem;padding:.25rem 1.5rem 2.5rem;flex:1;
            background:rgb(var(--mt-ui-card-bg));display:flex;flex-direction:column}
        .mt-auth-inner{width:100%;max-width:25rem;margin:0 auto;flex:1;display:flex;flex-direction:column;gap:1.15rem}
        .mt-auth-inner > h1{margin:.5rem 0 0;text-align:center;font-size:1.4rem;font-weight:800;letter-spacing:-.01em;color:rgb(var(--mt-text))}
        .mt-auth-inner > .lead{margin:0;text-align:center;font-size:.82rem;line-height:1.5;color:rgb(var(--mt-text) / .6)}
    </style>
    @endonce

    <div class="mt-auth-device">
        <div class="mt-auth-top">
            @if($back)
                <div class="mt-auth-topbar">
                    <a href="{{ route('login') }}" wire:navigate class="mt-auth-back" aria-label="{{ __('mt-ui::mt-ui.login_title') }}"><x-mt::icon name="chevron-left" /></a>
                    <span class="mt-auth-tbtitle">{{ $title }}</span>
                    <span style="width:34px"></span>
                </div>
            @endif

            {{-- <div class="mt-auth-badge" @if($back) style="margin-top:2.25rem" @endif>
                @if(mt_config('assets.logos.svg') && ! $back)
                    <img src="{{ asset(mt_config('assets.logos.svg')) }}" alt="{{ mt_config('app_name') }}" style="height:42px;width:auto">
                @else
                    <x-mt::icon :name="$icon" />
                @endif
                <span class="mt-auth-pip"><x-mt::icon :name="$pip" /></span>
            </div> --}}

            @unless($back)
                <div class="mt-auth-logo">{{ mt_config('app_name') }}</div>
            @endunless
            <p class="mt-auth-sub">{{ $brand ?? __('mt-ui::mt-ui.login_immersive_sub') }}</p>
        </div>

        <div class="mt-auth-sheet">
            <div class="mt-auth-inner">
                <h1>{{ $title }}</h1>
                @if($subtitle)<p class="lead">{{ $subtitle }}</p>@endif
                {{ $slot }}
            </div>
        </div>
    </div>
</div>
