{{--
    Composant : <x-mt::help>
    Bulle d'aide d'usage contextuelle - icône « ? » + popover Alpine.

    Contenu (par ordre de priorité) :
      - slot par défaut (HTML libre)  → <x-mt::help>Texte…</x-mt::help>
      - prop :text                    → <x-mt::help text="…" />
      - prop key (registre hôte)      → <x-mt::help key="custom_fields.intro" />
        (résolu via mt_help() → config/help.php de l'hôte ; '' si absent)

    Le popover est TÉLÉPORTÉ dans <body> + positionné `fixed` ancré au déclencheur
    (sinon rogné dans un conteneur en overflow - cf. North Star mt-ui). z-index inline.
    Surface compacte : pas de .mt-card, fond/bordure via tokens en style inline.

    Props : key, text, title, size (sm|md), placement (top|bottom)
--}}
@props([
    'key'       => null,
    'text'      => null,
    'title'     => null,
    'size'      => 'md',
    'placement' => 'top',
])
@php
    $content = trim($slot->toHtml());
    if ($content === '') {
        $content = $text ?? ($key ? mt_help($key) : '');
        $content = e($content); // texte simple → échappé
    }
    $iconSize = $size === 'sm' ? '0.95rem' : '1.1rem';
@endphp

@if(filled($content))
    <span
        x-data="{
            open: false,
            x: 0, y: 0,
            place: '{{ $placement }}',
            show() {
                const r = $refs.trigger.getBoundingClientRect();
                // Bascule auto : pas assez de place en haut → on passe en bas (et inversement).
                this.place = '{{ $placement }}';
                if (this.place === 'top' && r.top < 140) this.place = 'bottom';
                if (this.place === 'bottom' && r.bottom + 140 > window.innerHeight) this.place = 'top';
                this.x = r.left + r.width / 2;
                this.y = this.place === 'bottom' ? r.bottom + 8 : r.top - 8;
                this.open = true;
            },
        }"
        class="relative inline-flex align-middle"
    >
        <button type="button" x-ref="trigger"
                @mouseenter="show()" @mouseleave="open = false"
                @click.stop="open ? open = false : show()"
                @focus="show()" @blur="open = false"
                class="inline-flex items-center justify-center mt-text-muted hover:mt-text-primary transition"
                style="width: {{ $iconSize }}; height: {{ $iconSize }}; line-height: 1;"
                aria-label="Aide">
            <x-mt::icon name="question-circle" />
        </button>

        <template x-teleport="body">
            <div x-show="open" x-cloak x-transition.opacity
                 :style="{
                     position: 'fixed',
                     left: x + 'px',
                     top: y + 'px',
                     transform: place === 'bottom'
                         ? 'translate(-50%, 0)' : 'translate(-50%, -100%)',
                     zIndex: 10050,
                 }"
                 class="w-64 max-w-xs rounded-xl p-3 text-xs leading-relaxed shadow-2xl"
                 style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgba(var(--mt-ui-card-border), 0.8); color: rgb(var(--mt-text));">
                @if($title)
                    <div class="mb-1 text-[11px] font-semibold mt-text">{{ $title }}</div>
                @endif
                <div class="mt-text-muted">{!! $content !!}</div>
            </div>
        </template>
    </span>
@endif
