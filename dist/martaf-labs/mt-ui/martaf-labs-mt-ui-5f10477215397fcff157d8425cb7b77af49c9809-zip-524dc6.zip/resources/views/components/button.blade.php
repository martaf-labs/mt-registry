{{--
    Composant : <x-mt::button>
    Variantes  : primary | secondary | danger | ghost | outline
    Tailles    : xs | sm | md | lg | xl
    Props      : href, variant, size, label, loading, icon, endIcon, disabled
--}}
@props([
    'href'     => null,
    'variant'  => 'primary',
    'size'     => 'md',
    'label'    => null,
    'loading'  => null,
    'icon'     => null,
    'endIcon'  => null,
    'disabled' => false,
    'navigate' => true, // false → navigation navigateur classique (pas de SPA)
])

@php
    $variantClass = match($variant) {
        'secondary' => 'mt-btn-secondary',
        'danger'    => 'mt-btn-danger',
        'ghost'     => 'mt-btn-ghost',
        'outline'   => 'mt-btn-outline',
        default     => 'mt-btn-primary',
    };

    $sizeClass = match($size) {
        'xs' => 'mt-btn-xs',
        'sm' => 'mt-btn-sm',
        'lg' => 'mt-btn-lg',
        'xl' => 'mt-btn-xl',
        default => 'mt-btn-md',
    };

    $tag = $href ? 'a' : 'button';
    // Nouvel onglet / lien binaire (PDF, export…) : JAMAIS de wire:navigate —
    // Livewire irait chercher la ressource en fetch et l'injecterait comme du
    // HTML → page d'octets illisibles. `target` présent ⇒ navigation classique.
    $spaNavigate = $navigate && ! $attributes->get('target');
@endphp

<{{ $tag }}
    @if($href) href="{{ $href }}" @if($spaNavigate) wire:navigate @endif @endif
    {{ $attributes->merge([
        'class' => "mt-btn {$variantClass} {$sizeClass}",
        'type'  => $href ? null : 'button',
    ]) }}
    @if($loading)   wire:loading.attr="disabled" wire:target="{{ $loading }}" @endif
    @if($disabled)  disabled @endif
>
    {{-- Icône de début (cachée pendant le chargement) / Spinner (caché au repos) --}}
    {{-- ⚠️ Les spans wrapper DOIVENT être inline-flex + line-height:0/1 : un <span> inline
         nu pose son contenu sur la baseline de sa boîte de ligne → icône décalée de ~3px
         vers le haut par rapport au label (le bouton est flex/items-center mais ne centre
         que le WRAPPER, pas l'icône dedans). wire:loading.inline-flex conserve ce display. --}}
    @if($icon)
        @if($loading)
            {{-- Spinner : visible uniquement pendant le chargement --}}
            <span wire:loading.inline-flex wire:target="{{ $loading }}"
                  style="display:none;align-items:center;line-height:1;">
                <i class="fa-solid fa-circle-notch fa-spin" style="font-size:1.25rem; line-height:1;"></i>
            </span>
            {{-- Icône : masquée pendant le chargement --}}
            <span wire:loading.remove wire:target="{{ $loading }}"
                  style="display:inline-flex;align-items:center;line-height:0;">
                <x-mt::icon :name="$icon" class="" />
            </span>
        @else
            {{-- Pas de chargement : icône toujours visible --}}
            <x-mt::icon :name="$icon" class="" />
        @endif
    @elseif($loading)
        {{-- Bouton sans icône mais avec loading : spinner seul --}}
        <span wire:loading.inline-flex wire:target="{{ $loading }}"
              style="display:none;align-items:center;line-height:1;">
            <i class="fa-solid fa-circle-notch fa-spin" style="font-size:1.25rem; line-height:1;"></i>
        </span>
    @endif

    <span>{{ $label ?? $slot }}</span>

    {{-- Icône de fin --}}
    @if($endIcon)
        <x-mt::icon :name="$endIcon" class="ml-2" />
    @endif

</{{ $tag }}>
