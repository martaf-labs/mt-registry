@props([
    'title' => null,
    'metaInfos' => null,
    'description' => '',
    'datas' => [],
    'actions' => false,
])

@php
    $titleContent = is_array($title) ? ($title['content'] ?? '') : $title;
    $titleIcon    = is_array($title) ? ($title['icon'] ?? false) : false;
    $metaInfos    = is_array($title) ? ($title['metaInfos'] ?? $metaInfos) : $metaInfos;

    $hasDatas = !empty($datas);
    $firstData = $hasDatas ? reset($datas) : null;
    $lastData  = $hasDatas ? end($datas) : null;

    // On garde la logique de réduction si plus de 5 éléments
    $overDatas = count($datas) > 5 ? array_slice($datas, 1, -1) : [];

    // Icônes SVG inline (NE PAS utiliser les classes mt-icon-* CSS mask - elles nécessitent les SVG publiés)
    $iconRenderer = app(\MtIcons\IconRenderer::class);
    $iconHome      = $iconRenderer->render('home',               ['size' => 'sm']);
    $iconChevron   = $iconRenderer->render('chevron-right',      ['size' => 'xs']);
    $iconEllipsis  = $iconRenderer->render('ellipsis-horizontal', ['size' => 'sm']);
@endphp

<div {{ $attributes->merge(['class' => 'mb-6 mt-breadcrumbs']) }}>
    {{-- Couleurs = TOKENS du thème mt-ui (--mt-*) uniquement. Pas de zinc/white en dur :
         le composant doit suivre la charte (light/dark, marque par tenant). Les états hover
         passent par ce style scopé car le CSS précompilé n'a pas de variantes hover mt-*. --}}
    <style>
        {{-- .65 = même alpha que .mt-text-muted (pas de token --mt-muted dans le thème). --}}
        .mt-breadcrumbs nav[aria-label="Breadcrumb"] a { color: rgba(var(--mt-text), .65); transition: color .15s ease; }
        .mt-breadcrumbs nav[aria-label="Breadcrumb"] a:hover { color: rgb(var(--mt-primary)); }
        .mt-breadcrumbs nav[aria-label="Breadcrumb"] button:hover { background: rgba(var(--mt-text), 0.06); }
        .mt-breadcrumbs .mt-breadcrumbs-item a:hover { background: rgba(var(--mt-text), 0.06); }
    </style>
    <div class="flex flex-col justify-between gap-4 md:flex-row md:items-center">

        <div class="flex-1 min-w-0">
            {{-- Fil d'Ariane --}}
            @if ($hasDatas)
                <nav class="flex mb-3" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center text-[11px]">
                        {{-- Accueil --}}
                        <li class="inline-flex items-center">
                            <a href="{{ route('dashboard') }}">
                                {!! $iconHome !!}
                            </a>
                        </li>

                        @if (!empty($overDatas))
                            {{-- Premier élément après accueil --}}
                            <li>
                                <div class="flex items-center">
                                    <span class="inline-flex items-center mt-text-muted" style="opacity:.6">{!! $iconChevron !!}</span>
                                    <a href="{{ $firstData['lien'] ?? '#' }}">
                                        {{ Illuminate\Support\Str::limit($firstData['label'], 15) }}
                                    </a>
                                </div>
                            </li>

                            {{-- Dropdown Ellipsis --}}
                            <li x-data="{ open: false }" class="relative">
                                <div class="flex items-center">
                                    <span class="inline-flex items-center mt-text-muted" style="opacity:.6">{!! $iconChevron !!}</span>
                                    <button @click="open = !open" class="px-1 transition-colors rounded mt-text-muted">
                                        {!! $iconEllipsis !!}
                                    </button>

                                    <div x-show="open" x-cloak @click.away="open = false"
                                         x-transition:enter="transition ease-out duration-100"
                                         x-transition:enter-start="opacity-0 scale-95"
                                         x-transition:enter-end="opacity-100 scale-100"
                                         x-transition:leave="transition ease-in duration-75"
                                         x-transition:leave-start="opacity-100 scale-100"
                                         x-transition:leave-end="opacity-0 scale-95"
                                         class="absolute left-0 w-48 py-1 mt-8 border rounded-lg shadow-xl"
                                         style="z-index: 50; background: rgb(var(--mt-ui-card-bg)); border-color: rgb(var(--mt-ui-card-border))">
                                        @foreach ($overDatas as $data)
                                            <span class="mt-breadcrumbs-item">
                                                <a href="{{ $data['lien'] ?? '#' }}" class="block px-4 py-2 text-[12px] mt-text">
                                                    {{ Illuminate\Support\Str::ucfirst($data['label']) }}
                                                </a>
                                            </span>
                                        @endforeach
                                    </div>
                                </div>
                            </li>

                            {{-- Dernier élément --}}
                            <li aria-current="page">
                                <div class="flex items-center">
                                    <span class="inline-flex items-center mt-text-muted" style="opacity:.6">{!! $iconChevron !!}</span>
                                    <span class="mt-text font-medium">
                                        {{ Illuminate\Support\Str::ucfirst(Illuminate\Support\Str::limit($lastData['label'], 25)) }}
                                    </span>
                                </div>
                            </li>
                        @else
                            {{-- Liste courte --}}
                            @foreach ($datas as $data)
                                <li>
                                    <div class="flex items-center">
                                        <span class="inline-flex items-center mt-text-muted" style="opacity:.6">{!! $iconChevron !!}</span>
                                        @if($loop->last)
                                            <span aria-current="page" class="mt-text font-medium">{{ Illuminate\Support\Str::limit($data['label'], 30) }}</span>
                                        @else
                                            <a href="{{ $data['lien'] ?? '#' }}">
                                                {{ Illuminate\Support\Str::ucfirst(Illuminate\Support\Str::limit($data['label'] ?? '', 20)) }}
                                            </a>
                                        @endif
                                    </div>
                                </li>
                            @endforeach
                        @endif
                    </ol>
                </nav>
            @endif

            {{-- Titre et Meta --}}
            <div class="space-y-1">
                <h1 class="flex items-center gap-2 text-xl font-bold mt-text-primary">
                    {{-- @if ($titleIcon)
                        <i class="{{ $titleIcon }} text-primary-500/90 text-lg"></i>
                    @endif --}}
                    <span class="truncate">{{ $titleContent }}</span>
                </h1>
                
                @if($description)
                    <p class="max-w-3xl text-xs leading-normal mt-text">
                        {{ $description }}
                    </p>
                @endif

                @if ($metaInfos)
                    <div class="flex flex-wrap items-center mt-1 gap-x-3 gap-y-1">
                        @foreach ($metaInfos as $info)
                            @if(($info['type'] ?? '') === 'badge')
                                <x-mt::badge 
                                    :label="$info['label']"
                                    :variant="$info['variant'] ?? 'info'" 
                                    :dot="isset($info['dot'])"
                                    class="px-2 py-0.5 text-[10px]"
                                />
                            @else
                                <span class="flex items-center text-[11px] font-semibold mt-text-muted">
                                    @if(isset($info['icon']))
                                        <i class="{{ $info['icon'] }} mr-1.5 opacity-70"></i>
                                    @endif
                                    {{ $info['label'] }}
                                </span>
                            @endif
                        @endforeach
                    </div>
                @endif
            </div>
        </div>

        {{-- Actions : tableau de config (grille mt-actions) OU slot de markup libre --}}
        @if($actions instanceof \Illuminate\View\ComponentSlot)
            @if(! $actions->isEmpty())
                <div class="flex items-center justify-end gap-2 md:self-end">{{ $actions }}</div>
            @endif
        @elseif($actions)
            <div class="flex items-center justify-end origin-right transform scale-95 md:self-end">
                <x-mt::actions.grid :actions="$actions" visible="4" />
            </div>
        @endif
    </div>
</div>