{{--
    <x-mt::alert type="success|error|danger|warning|info" [:message="…"] [title="…"] [dismissible] />
    ou avec slot : <x-mt::alert type="warning">Contenu libre…</x-mt::alert>

    Alerte INLINE (bandeau) thémée : icône + message, fond/texte/bordure teintés par le token
    du type. `dismissible` ajoute une croix qui masque le bandeau (Alpine, optimiste).
    100 % tokens --mt-* + mt-icons SVG — aucune couleur/icône en dur.
    (Remplace l'ancien composant modal Bootstrap legacy, qui n'était plus utilisé.)
--}}
@props([
    'type'        => 'info',
    'message'     => null,
    'title'       => null,
    'dismissible' => false,
])

@php
    // 'error' = alias de 'danger'.
    $t = $type === 'error' ? 'danger' : $type;
    $map = [
        'success' => ['token' => 'success', 'icon' => 'check-circle'],
        'danger'  => ['token' => 'danger',  'icon' => 'x-circle'],
        'warning' => ['token' => 'warning', 'icon' => 'exclamation-triangle'],
        'info'    => ['token' => 'info',    'icon' => 'info'],
    ];
    $conf  = $map[$t] ?? $map['info'];
    $token = $conf['token'];
@endphp

<div
    x-data="{ show: true }"
    x-show="show"
    role="alert"
    {{ $attributes->merge(['class' => 'flex items-start gap-3 rounded-xl border p-3 text-sm']) }}
    style="border-color: rgba(var(--mt-{{ $token }}), 0.35); background: rgba(var(--mt-{{ $token }}), 0.10)"
>
    <span class="mt-0.5 shrink-0" style="color: rgb(var(--mt-{{ $token }}))">
        <x-mt::icon :name="$conf['icon']" size="sm" />
    </span>

    <div class="min-w-0 flex-1">
        @if($title)
            <div class="font-semibold mt-text">{{ $title }}</div>
        @endif
        <div class="mt-text">{{ $message ?? $slot }}</div>
    </div>

    @if($dismissible)
        <button type="button" @click="show = false"
                class="shrink-0 mt-text-muted transition-opacity hover:opacity-70"
                aria-label="{{ __('mt-ui::mt-ui.close') }}">
            <x-mt::icon name="x-mark" size="sm" />
        </button>
    @endif
</div>
