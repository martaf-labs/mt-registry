@if(mt_config('tinymce.enabled', false))
<script>
    window.tinymceConfig = {
        apiKey: '{{ mt_config('tinymce.api_key', '') }}',
        uploadUrl: '{{ route('admin.image.upload') }}',
        language: '{{ app()->getLocale() }}',
    };
</script>
@endif
