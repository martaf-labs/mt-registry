
{{-- dark-mode-toggle.blade.php --}}
{{-- Fonctionne grâce au themeManager() déclaré sur <html> dans master.blade.php --}}
<div class="p-1">
    @if(mt_has_dark_mode())
    <button @click="darkMode = !darkMode"
        class="p-2 transition-all rounded-lg group mt-btn-icon"
        :title="darkMode ? 'Passer au mode clair' : 'Passer au mode sombre'">

        <!-- Soleil : visible en mode sombre -->
        <x-mt::icon x-show="darkMode" x-cloak name="sun"
            class="w-5 h-5 transition-transform duration-300 text-amber-400 group-hover:rotate-45" />

        <!-- Lune : visible en mode clair -->
        <x-mt::icon x-show="!darkMode" x-cloak name="moon"
            class="w-5 h-5 transition-transform duration-300 group-hover:-rotate-12"
            style="color: rgb(var(--mt-secondary))" />
    </button>
    @endif    
</div>