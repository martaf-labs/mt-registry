{{--
| mt-ui :: dropdown/divider.blade.php
| Séparateur horizontal subtil entre groupes d'items.
| Usage : <x-mt::dropdown.divider />
--}}
<div class="my-1" style="height: 1px; background: rgba(var(--mt-ui-card-border), 0.8)"></div>
