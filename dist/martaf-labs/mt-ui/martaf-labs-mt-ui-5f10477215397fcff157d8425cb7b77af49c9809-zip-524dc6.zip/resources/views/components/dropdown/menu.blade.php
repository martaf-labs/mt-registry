{{--
| mt-ui :: dropdown/menu.blade.php
| Conteneur des items du dropdown.
--}}
{{-- Pas de fond ici : on hérite du fond unique du panneau (évite la double teinte).
     p-1 : classe présente dans le CSS précompilé (p-1.5 ne l'est PAS → aucun inset,
     les items collent aux bords du panneau). --}}
<div class="p-1">
    {{ $slot }}
</div>
