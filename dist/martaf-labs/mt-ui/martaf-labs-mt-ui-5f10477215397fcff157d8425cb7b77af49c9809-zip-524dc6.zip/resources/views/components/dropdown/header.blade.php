{{--
| mt-ui :: dropdown/header.blade.php
| Bloc en-tête utilisateur en haut du dropdown.
|
| Usage :
|   <x-mt::dropdown.header
|       name="{{ auth()->user()->name }}"
|       email="{{ auth()->user()->email }}"
|       :avatar="auth()->user()->avatar_url ?? null"
|   />
--}}

@props([
    'name'   => '',
    'email'  => '',
    'avatar' => null,
])

@php
    $initials = collect(explode(' ', $name))
        ->take(2)
        ->map(fn($w) => strtoupper(substr($w, 0, 1)))
        ->implode('');
@endphp

<div class="flex items-center gap-3 px-4 py-3">

    {{-- Avatar --}}
    <div class="shrink-0 relative">
        @if($avatar)
            <img
                src="{{ $avatar }}"
                alt="{{ $name }}"
                class="w-9 h-9 rounded-xl object-cover"
                style="box-shadow: 0 0 0 2px rgba(var(--mt-primary), 0.2)"
            >
        @else
            <div class="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold text-white"
                 style="background: linear-gradient(135deg, rgb(var(--mt-primary)), rgba(var(--mt-primary), 0.7))">
                {{ $initials ?: '?' }}
            </div>
        @endif
        {{-- Indicateur en ligne (offsets/taille .5 absents du CSS précompilé → inline) --}}
        <span class="absolute rounded-full"
              style="bottom: -2px; right: -2px; width: 0.625rem; height: 0.625rem; background: rgb(var(--mt-success)); box-shadow: 0 0 0 2px rgb(var(--mt-bg))"></span>
    </div>

    {{-- Infos --}}
    <div class="min-w-0 flex-1">
        <p class="text-sm font-semibold mt-text truncate leading-tight">{{ $name }}</p>
        <p class="text-xs mt-text-muted truncate leading-tight" style="margin-top: 0.125rem">{{ $email }}</p>
    </div>

</div>
