{{--
| mt-ui :: dropdown/item.blade.php
|
| Props :
|   label   → texte affiché
|   icon    → nom d'icône mt-icons ou classe FontAwesome
|   href    → URL (défaut: null → <button>)
|   method  → méthode Livewire wire:click (si pas de href)
|   variant → default | danger
|   badge   → badge numérique optionnel
|   active  → item actif (défaut: false)
--}}

@props([
    'label'    => '',
    'icon'     => null,
    'href'     => null,
    'method'   => null,
    'confirm'  => null,   // message → confirmation NATIVE (wire:confirm) avant l'action livewire
    'dispatch' => null,   // ['name'=>…, 'data'=>[…]] → au clic, dispatche un event window (+ ferme le menu)
    'variant'  => 'default',
    'badge'    => null,
    'active'   => false,
    'navigate' => true, // false → navigation navigateur classique (pas de SPA)
])

@php
    $label     = Illuminate\Support\Str::ucfirst($label);
    $danger    = $variant === 'danger';
    $renderer  = app(\MtIcons\IconRenderer::class);
    $iconHtml  = $icon
        ? ($renderer->exists($icon)
            ? $renderer->render($icon, ['size' => 'sm'])
            : '<i class="' . e($icon) . '"></i>')
        : null;

    // px-3/py-2/gap-2 : classes PRESENTES dans le CSS precompile (px-2.5/py-1.5/gap-2.5
    // ne le sont PAS -> items sans padding, icone collee au texte).
    $baseClass = 'group flex items-center gap-2 w-full px-3 py-2 text-sm text-start rounded-lg transition-all duration-150 cursor-pointer';

    $colorStyle = $danger
        ? 'color: rgb(var(--mt-danger))'
        : ($active
            ? 'color: rgb(var(--mt-primary)); background: rgba(var(--mt-primary),0.08); font-weight: 600'
            : 'color: rgba(var(--mt-text), 0.75)');

    $iconColor = $danger
        ? 'rgb(var(--mt-danger))'
        : ($active ? 'rgb(var(--mt-primary))' : 'rgba(var(--mt-text),0.35)');

    $hoverOver = $danger
        ? "this.style.background='rgba(var(--mt-danger),0.08)'"
        : "this.style.background='rgba(var(--mt-text),0.05)'; this.style.color='rgb(var(--mt-text))'";

    $hoverOut = $danger
        ? "this.style.background=''"
        : "this.style.background=''; this.style.color='rgba(var(--mt-text),0.75)'";
@endphp

@php
    $tag = $href ? 'a' : 'button';
    // Nouvel onglet / lien binaire (PDF, export…) : JAMAIS de wire:navigate —
    // Livewire irait chercher la ressource en fetch et l'injecterait comme du
    // HTML → page d'octets illisibles. `target` présent ⇒ navigation classique.
    $spaNavigate = $navigate && ! $attributes->get('target');
@endphp

<{{ $tag }}
    @if($href) href="{{ $href }}" @if($spaNavigate) wire:navigate @endif @endif
    @if(!$href && !$dispatch && $method) wire:click="{{ $method }}" @endif
    @if(!$href && !$dispatch && $method && $confirm) wire:confirm="{{ $confirm }}" @endif
    {{-- Sélectionner un item ferme le menu (sinon il flotte au-dessus du backdrop d'un modal ouvert par l'action). `open` vient du scope x-data du dropdown parent (préservé malgré le téléport). --}}
    @if($dispatch)
        x-on:click="$dispatch('{{ $dispatch['name'] }}', {{ \Illuminate\Support\Js::from($dispatch['data'] ?? []) }}); open = false"
    @else
        @click="open = false"
    @endif
    {{ $attributes->except(['class', 'style']) }}
    class="{{ $baseClass }}"
    role="menuitem"
    style="{{ $colorStyle }}"
    @if(!$active) onmouseover="{{ $hoverOver }}" onmouseout="{{ $hoverOut }}" @endif
>
    @if($iconHtml)
        <span class="flex-shrink-0 w-4 h-4 transition-colors duration-150" style="color: {{ $iconColor }}">
            {!! $iconHtml !!}
        </span>
    @endif

    <span class="flex-1 truncate">{{ $label }}</span>

    @if($badge)
        {{-- min-w/px/text arbitraires absents du CSS précompilé → inline. --}}
        <span class="inline-flex items-center justify-center h-5 font-bold rounded-full mt-badge mt-badge-primary"
              style="min-width: 1.25rem; padding: 0 0.375rem; font-size: 10px;">
            {{ $badge }}
        </span>
    @endif

    @if($active)
        <x-mt::icon name="check" class="w-3 h-3 opacity-80" style="color: rgb(var(--mt-primary))" />
    @endif
</{{ $tag }}>

@if($slot->isNotEmpty())
    <div>{{ $slot }}</div>
@endif
