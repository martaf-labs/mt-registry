{{--
| mt-ui :: dropdown/section.blade.php
| Label de groupe d'items.
| Usage : <x-mt::dropdown.section label="Navigation" />
--}}

@props(['label' => ''])

{{-- text-[10px] arbitraire absent du CSS précompilé → font-size inline. --}}
<p class="px-4 pt-3 pb-1 font-bold uppercase tracking-widest select-none mt-text-muted" style="font-size: 10px">
    {{ $label }}
</p>
