{{--
|==========================================================================
| EXEMPLE D'UTILISATION - Navbar avec Dropdown profil
|==========================================================================
--}}

@auth
<x-mt::dropdown align="right" width="md" :offsetY="8">

    {{-- Déclencheur --}}
    <x-slot:trigger>
        <button class="flex items-center gap-2 py-1 pl-2 pr-1 rounded-lg transition-all mt-btn-ghost"
                style="--focus-ring: rgba(var(--mt-primary), 0.3)">

            {{-- Miniature avatar --}}
            <div class="w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold text-white"
                 style="background: linear-gradient(135deg, rgb(var(--mt-primary)), rgba(var(--mt-primary), 0.6))">
                {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
            </div>

            {{-- Nom + chevron --}}
            <span class="hidden sm:block text-sm font-medium mt-text max-w-[120px] truncate">
                {{ auth()->user()->name }}
            </span>
            <i class="fa-solid fa-chevron-down text-[10px] mt-text-muted transition-transform duration-200"
               :class="{ 'rotate-180': open }"></i>
        </button>
    </x-slot:trigger>

    {{-- En-tête utilisateur --}}
    <x-mt::dropdown.header
        name="{{ auth()->user()->name }}"
        email="{{ auth()->user()->email }}"
    />

    {{-- Navigation principale --}}
    <div class="py-1">
        <x-mt::dropdown.section label="Navigation" />
        <x-mt::dropdown.item icon="fa-solid fa-gauge"  label="Tableau de Bord" :href="route('dashboard')" />
        <x-mt::dropdown.item icon="fa-solid fa-user"   label="Mon profil"       :href="route('profile')" />
        <x-mt::dropdown.item icon="fa-solid fa-bell"   label="Notifications"    :href="route('home')" badge="3" />
        <x-mt::dropdown.item icon="fa-solid fa-gear"   label="Paramètres"       :href="route('home')" />
    </div>

    {{-- Déconnexion --}}
    <div class="py-1">
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" class="w-full text-left">
                <x-mt::dropdown.item
                    icon="fa-solid fa-arrow-right-from-bracket"
                    label="Déconnexion"
                    variant="danger"
                />
            </button>
        </form>
    </div>

</x-mt::dropdown>
@endauth
