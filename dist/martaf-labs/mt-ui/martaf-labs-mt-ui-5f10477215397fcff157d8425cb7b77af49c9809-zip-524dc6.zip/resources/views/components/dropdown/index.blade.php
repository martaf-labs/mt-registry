{{--
| mt-ui :: Composant anonyme - Dropdown
|
| Usage:
|   <x-mt::dropdown>
|       <x-slot:trigger><button>Déclencheur</button></x-slot:trigger>
|       <x-mt::dropdown.item icon="gear" label="Paramètres" :href="route('settings')" />
|   </x-mt::dropdown>
|
| Props : align (left|right, def. right) · width (sm|md|lg|full, def. md)
|
| ── RESPONSIVE (2026-07-22) ──────────────────────────────────────────────────
| • DESKTOP/TABLETTE (≥ lg) : panneau flottant TÉLÉPORTÉ dans <body>, positionné
|   `fixed` près du déclencheur (échappe aux overflow, flip haut/bas auto).
| • MOBILE (< lg) : BOTTOM-SHEET (pattern mobile natif façon Mobbin) — scrim
|   sombre + poignée + glissement depuis le bas, items plus grands (tap-friendly).
| Le basculement se fait par `isMobile` (matchMedia) + `x-if` (rend l'un OU l'autre,
| jamais les deux) ; `open` et le slot sont partagés.
--}}

@props([
    'align' => 'right',
    'width' => 'md',
])

@php
    $widthClass = match($width) {
        'sm'   => 'min-w-40 max-w-48',
        'md'   => 'min-w-48 max-w-64',
        'lg'   => 'min-w-56 max-w-80',
        'full' => 'w-full',
        default => 'min-w-48 max-w-64',
    };
@endphp

@once
{{-- Style rendu UNE fois (pas de @stack('styles') dans le layout) : @once inline. --}}
<style>
    /* Bottom-sheet mobile : items plus grands (cibles tactiles confortables). */
    .mt-dd-sheet [role="menuitem"] { padding: .85rem .9rem; font-size: .95rem; border-radius: .8rem; }
    .mt-dd-sheet [role="menuitem"] > span.flex-shrink-0 { width: 1.2rem; height: 1.2rem; }
</style>
@endonce

<div
    x-data="{
        open: false,
        coords: {},
        isMobile: window.matchMedia('(max-width: 1023px)').matches,
        toggle() {
            this.open = ! this.open;
            if (this.open && ! this.isMobile) this.$nextTick(() => this.reposition());
        },
        reposition() {
            if (this.isMobile) return;
            const t = this.$refs.trigger.getBoundingClientRect();
            const menu = this.$refs.menu;
            const h = menu ? menu.offsetHeight : 0;
            const spaceBelow = window.innerHeight - t.bottom;
            const openUp = (spaceBelow < h + 16) && (t.top > spaceBelow);
            const c = {};
            if (openUp) c.bottom = (window.innerHeight - t.top + 8) + 'px';
            else        c.top    = (t.bottom + 8) + 'px';
            @if($align === 'left')
                c.left  = Math.max(8, t.left) + 'px';
            @else
                c.right = Math.max(8, window.innerWidth - t.right) + 'px';
            @endif
            this.coords = c;
        },
    }"
    @keydown.escape.window="open = false"
    @scroll.window.passive="open && reposition()"
    @resize.window="isMobile = window.matchMedia('(max-width: 1023px)').matches; open && reposition()"
    class="inline-flex"
>
    {{-- Déclencheur --}}
    <div x-ref="trigger" @click="toggle()" class="cursor-pointer">
        {{ $trigger }}
    </div>

    <template x-teleport="body">
        <div>
            {{-- ══ DESKTOP : dropdown flottant positionné ══ --}}
            <template x-if="!isMobile">
                <div
                    x-ref="menu"
                    x-show="open"
                    x-cloak
                    @click.outside="open && ! $refs.trigger.contains($event.target) ? open = false : null"
                    :style="coords"
                    x-transition:enter="transition ease-out duration-200"
                    x-transition:enter-start="opacity-0 -translate-y-1 scale-95"
                    x-transition:enter-end="opacity-100 translate-y-0 scale-100"
                    x-transition:leave="transition ease-in duration-150"
                    x-transition:leave-start="opacity-100 translate-y-0 scale-100"
                    x-transition:leave-end="opacity-0 -translate-y-1 scale-95"
                    class="fixed {{ $widthClass }} rounded-xl overflow-hidden shadow-xl"
                    style="z-index: 9999; background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgba(var(--mt-ui-card-border), 0.8);"
                >
                    <div class="divide-y" style="--tw-divide-color: rgba(var(--mt-ui-card-border), 0.5)">
                        {{ $slot }}
                    </div>
                </div>
            </template>

            {{-- ══ MOBILE : bottom-sheet (scrim + poignée + glissement) ══ --}}
            <template x-if="isMobile">
                <div>
                    {{-- Scrim --}}
                    <div x-show="open" x-cloak @click="open = false"
                        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                        x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                        class="fixed inset-0" style="z-index: 10050; background: rgba(0,0,0,0.5); backdrop-filter: blur(2px);"></div>

                    {{-- Feuille --}}
                    <div x-show="open" x-cloak
                        x-transition:enter="transition transform ease-out duration-300" x-transition:enter-start="translate-y-full" x-transition:enter-end="translate-y-0"
                        x-transition:leave="transition transform ease-in duration-200" x-transition:leave-start="translate-y-0" x-transition:leave-end="translate-y-full"
                        class="mt-dd-sheet fixed left-0 right-0 bottom-0 shadow-2xl"
                        style="z-index: 10060; background: rgb(var(--mt-ui-card-bg)); border-top: 1px solid rgb(var(--mt-ui-card-border)); border-radius: 22px 22px 0 0; max-height: 80vh; overflow-y: auto; padding-bottom: calc(.5rem + env(safe-area-inset-bottom, 0px));">
                        {{-- Poignée --}}
                        <div class="flex justify-center pt-3 pb-1">
                            <div style="width: 42px; height: 5px; border-radius: 999px; background: rgb(var(--mt-ui-card-border));"></div>
                        </div>
                        <div class="p-2 divide-y" style="--tw-divide-color: rgba(var(--mt-ui-card-border), 0.5)">
                            {{ $slot }}
                        </div>
                    </div>
                </div>
            </template>
        </div>
    </template>
</div>
