{{--
    Composant : <x-mt::pick-card>
    Tuile cliquable (bouton) — « cliquer pour choisir/ajouter » : catalogue produit,
    grille de types, sélection rapide. Remplace les `<button class="flex flex-col …">`
    faits main. Contenu libre via le slot (titre, prix, méta…).

    Props : size (sm|md), selected (bool → bordure primaire soulignant l'élément choisi)
    Attributs : wire:click / @click… passent au <button>.
--}}
@props([
    'size'     => 'md',
    'selected' => false,
])

@php
    $pad = $size === 'sm' ? 'p-2' : 'p-3';
    $border = $selected ? 'rgb(var(--mt-primary))' : 'rgb(var(--mt-ui-card-border))';
@endphp

<button type="button"
    {{ $attributes->merge(['class' => "flex flex-col items-start rounded-xl border text-left transition hover:-translate-y-0.5 {$pad}"]) }}
    style="border-color: {{ $border }}; background: rgb(var(--mt-ui-card-bg));">
    {{ $slot }}
</button>
