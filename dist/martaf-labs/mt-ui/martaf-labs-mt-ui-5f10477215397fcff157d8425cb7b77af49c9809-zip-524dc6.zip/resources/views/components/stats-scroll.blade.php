@props([
    'stats' => [], // [{label, value, icon, color, ?route, ?details:[{value,label}], ?change, ?changeType}]
])

{{--
    Cartes de statistiques — comportement UNIFIÉ dashboard / base-index / base-show.
    Nombre ILLIMITÉ : scroll horizontal (flèches + dégradés + scrollbar cachée).
    - DESKTOP/TABLETTE : carte large (libellé+valeur à gauche, puce d'icône à droite, bordure-gauche colorée).
    - MOBILE (< lg) : carte COMPACTE verticale (icône en carré soft en haut, libellé, valeur XXL) façon
      app native — ~2 cartes visibles, scroll horizontal. Point d'amélioration UNIQUE pour tous les écrans.
--}}
@once
<style>
    ._mt-stats-scroll::-webkit-scrollbar { display: none; }
    /* Largeur de carte responsive : desktop = 1/4 ; mobile = ~2 par écran. */
    .mt-statcard { flex: 0 0 auto; width: 25%; min-width: 200px; }
    @media (max-width: 1023px) {
        .mt-statcard { width: 44%; min-width: 150px; max-width: 230px; }
    }
</style>
@endonce

@if(count($stats) > 0)
<div class="relative"
     x-data="{
         canLeft: false, canRight: false,
         init() {
             this.$refs.track.classList.add('_mt-stats-scroll');
             this.$nextTick(() => this.check());
         },
         check() {
             const el = this.$refs.track;
             this.canLeft  = el.scrollLeft > 1;
             this.canRight = el.scrollLeft < el.scrollWidth - el.clientWidth - 1;
         },
         scrollBy(delta) { this.$refs.track.scrollBy({ left: delta, behavior: 'smooth' }); }
     }"
     @resize.window="check()">

    {{-- Flèche gauche (desktop) --}}
    <button x-show="canLeft" x-transition.opacity @click="scrollBy(-300)"
            class="absolute left-0 z-20 items-center justify-center hidden -translate-y-1/2 rounded-full top-1/2 w-7 h-7 lg:flex"
            style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgb(var(--mt-ui-card-border)); box-shadow: 0 2px 8px rgba(0,0,0,0.15);">
        <x-mt::icon name="chevron-left" size="xs" />
    </button>
    {{-- Fade gauche --}}
    <div x-show="canLeft" x-transition.opacity class="absolute top-0 bottom-0 left-0 z-10 hidden w-12 pointer-events-none lg:block"
         style="background: linear-gradient(to right, rgb(var(--mt-bg)) 0%, transparent 100%);"></div>

    {{-- Piste de défilement --}}
    <div x-ref="track" @scroll="check()" class="flex gap-3 overflow-x-auto lg:gap-4"
         style="scrollbar-width: none; -ms-overflow-style: none;">

        @foreach($stats as $stat)
        @php
            $colorVar = match($stat['color'] ?? 'primary') {
                'success' => 'var(--mt-success)',
                'warning' => 'var(--mt-warning)',
                'danger'  => 'var(--mt-danger)',
                'info'    => 'var(--mt-info)',
                'gray', 'secondary' => 'var(--mt-text)',
                default   => 'var(--mt-primary)',
            };
            $isPositive = ($stat['changeType'] ?? 'neutral') === 'positive';
            $isNegative = ($stat['changeType'] ?? 'neutral') === 'negative';
            $hasRoute   = !empty($stat['route']);
            $statIcon   = $stat['icon'] ?? '';
            $isFa       = $statIcon && \Illuminate\Support\Str::startsWith($statIcon, ['fa-', 'fas ', 'far ', 'fab ', 'fa ']);
        @endphp

        <div class="shrink-0 mt-statcard">
            @if($hasRoute) <a href="{{ $stat['route'] }}" wire:navigate class="block h-full group">
            @else <div class="h-full group">
            @endif

                {{-- ══ MOBILE : carte compacte verticale (concept) ══ --}}
                <div class="flex flex-col rounded-2xl mt-card lg:hidden"
                     style="height:100%; padding:.85rem; border-left:3px solid rgb({{ $colorVar }});">
                    @if($statIcon)
                    <span style="width:38px;height:38px;border-radius:11px;display:inline-flex;align-items:center;justify-content:center;background:rgba({{ $colorVar }},0.12);color:rgb({{ $colorVar }})">
                        @if($isFa)<i class="{{ $statIcon }}"></i>@else<x-mt::icon :name="mt_icon_name($statIcon, 'rectangle-stack')" />@endif
                    </span>
                    @endif
                    <p class="text-xs font-medium uppercase truncate mt-text-muted" style="margin-top:.7rem">{{ $stat['label'] }}</p>
                    <p class="text-2xl font-bold leading-none truncate mt-text" style="margin-top:.2rem">{{ $stat['value'] }}</p>
                </div>

                {{-- ══ DESKTOP/TABLETTE : carte large (existante) ══ --}}
                <div class="relative hidden h-full p-5 overflow-hidden transition-all duration-200 rounded-2xl mt-card lg:block hover:shadow-md"
                     style="border-left: 3px solid rgb({{ $colorVar }});">
                    <div class="flex items-start justify-between">
                        <div class="flex-1 min-w-0 pr-3">
                            <p class="text-xs font-medium uppercase truncate mt-text-muted">{{ $stat['label'] }}</p>
                            <p class="text-2xl font-bold leading-none truncate lg:text-3xl mt-text" style="margin-top:.375rem">{{ $stat['value'] }}</p>
                        </div>
                        @if($statIcon)
                        <div class="flex-shrink-0 p-3 transition-all duration-200 rounded-xl group-hover:scale-110"
                             style="background: rgba({{ $colorVar }}, 0.1)">
                            @if($isFa)
                                <i class="{{ $statIcon }} text-lg" style="color: rgb({{ $colorVar }})"></i>
                            @else
                                <span style="color: rgb({{ $colorVar }})"><x-mt::icon :name="mt_icon_name($statIcon, 'rectangle-stack')" /></span>
                            @endif
                        </div>
                        @endif
                    </div>

                    @if(!empty($stat['details']) || isset($stat['change']))
                    <div class="flex items-center justify-between mt-3 flex-nowrap" style="gap:.375rem">
                        @if(!empty($stat['details']))
                        <div class="flex flex-wrap gap-1">
                            @foreach(array_slice($stat['details'], 0, 2) as $detail)
                            <span class="text-xs rounded-full mt-badge mt-badge-gray" style="padding:.125rem .5rem">
                                {{ ($detail['value'] ?? '') !== '' ? $detail['value'].' ' : '' }}{{ $detail['label'] ?? '' }}
                            </span>
                            @endforeach
                        </div>
                        @endif
                        @if(isset($stat['change']))
                        <span class="inline-flex items-center gap-1 text-xs font-semibold"
                              style="color: {{ $isPositive ? 'rgb(var(--mt-success))' : ($isNegative ? 'rgb(var(--mt-danger))' : 'rgba(var(--mt-text),0.5)') }}">
                            <x-mt::icon :name="$isPositive ? 'arrow-up' : ($isNegative ? 'arrow-down' : 'arrow-right')" size="xs" />
                            {{ $stat['change'] }}
                        </span>
                        @endif
                    </div>
                    @endif

                    {{-- Hover glow --}}
                    <div class="absolute inset-0 transition-opacity duration-300 opacity-0 pointer-events-none group-hover:opacity-100 rounded-2xl"
                         style="background: radial-gradient(circle at top right, rgba({{ $colorVar }}, 0.06), transparent 70%)"></div>
                </div>

            @if($hasRoute) </a> @else </div> @endif
        </div>
        @endforeach

    </div>

    {{-- Fade droit --}}
    <div x-show="canRight" x-transition.opacity class="absolute top-0 bottom-0 right-0 z-10 hidden w-12 pointer-events-none lg:block"
         style="background: linear-gradient(to left, rgb(var(--mt-bg)) 0%, transparent 100%);"></div>
    {{-- Flèche droite (desktop) --}}
    <button x-show="canRight" x-transition.opacity @click="scrollBy(300)"
            class="absolute right-0 z-20 items-center justify-center hidden -translate-y-1/2 rounded-full top-1/2 w-7 h-7 lg:flex"
            style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgb(var(--mt-ui-card-border)); box-shadow: 0 2px 8px rgba(0,0,0,0.15);">
        <x-mt::icon name="chevron-right" size="xs" />
    </button>
</div>
@endif
