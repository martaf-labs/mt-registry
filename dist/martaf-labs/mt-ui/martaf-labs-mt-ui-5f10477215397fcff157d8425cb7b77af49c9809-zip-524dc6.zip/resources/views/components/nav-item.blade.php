{{-- resources/views/components/nav-item.blade.php --}}
@props(['item'])

@php
    $itemRoute = $item['route'] ?? '#';
    $itemIcon  = $item['icon'] ?? 'fa-circle';

    // Icône en SVG INLINE via IconRenderer (fiable) si elle existe, sinon fallback
    // classe FontAwesome. On retire le préfixe `mt-icon-` éventuel (ajouté par mt_get_icon).
    $renderer  = app(\MtIcons\IconRenderer::class);
    $iconName  = \Illuminate\Support\Str::after($itemIcon, 'mt-icon-');
    $iconSvg   = $renderer->exists($iconName) ? $renderer->render($iconName, ['size' => 'md']) : null;

    $subItems  = $item['subItems'] ?? [];
    $itemCount = isset($item['count']) && $item['count'] ? add_zero($item['count']) : null;

    $isActive = request()->routeIs($itemRoute . '*') ||
                (!empty($subItems) && collect($subItems)->contains(
                    fn($s) => request()->routeIs(($s['route'] ?? '#') . '*')
                ));
@endphp

<div x-data="{ open: @js($isActive) }" class="w-full">

    @if (!empty($subItems))
        {{-- ══════════════════════════════════════════
             GROUPE AVEC SOUS-MENU
        ══════════════════════════════════════════ --}}
        <button
            @click="open = !open"
            :title="$root.closest('[x-data]').__x.$data.sidebarCollapsed ? @js(__($item['label'])) : ''"
            class="group relative flex items-center w-full gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
                   transition-all duration-200 outline-none focus-visible:ring-2 focus-visible:ring-indigo-500/50
                   {{ $isActive
                       ? 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                       : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5 hover:text-zinc-900 dark:hover:text-white' }}"
        >
            {{-- Indicateur actif --}}
            @if($isActive)
                <span class="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r-full bg-indigo-500"></span>
            @endif

            {{-- Icône (SVG inline mt-icons, fallback FontAwesome) --}}
            <span class="flex items-center justify-center w-5 shrink-0 transition-transform duration-200 group-hover:scale-110 {{ $isActive ? 'text-indigo-500 dark:text-indigo-400' : 'text-zinc-400 group-hover:text-indigo-400' }}">
                @if($iconSvg) {!! $iconSvg !!} @else <i class="{{ $itemIcon }} text-base leading-none"></i> @endif
            </span>

            {{-- Label (masqué en collapsed) --}}
            <span
                x-show="!sidebarCollapsed"
                x-transition:enter="transition-opacity duration-150"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-100"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                class="flex-1 text-left truncate"
            >
                {!! __($item['label']) !!}
            </span>

            {{-- Badge compteur --}}
            @if($itemCount)
                <span
                    x-show="!sidebarCollapsed"
                    class="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5
                           text-[10px] font-bold rounded-full
                           {{ $isActive
                               ? 'bg-indigo-500/20 text-indigo-600 dark:text-indigo-300'
                               : 'bg-zinc-200 dark:bg-white/10 text-zinc-500 dark:text-zinc-400' }}"
                >
                    {{ $itemCount }}
                </span>
            @endif

            {{-- Chevron --}}
            <svg
                x-show="!sidebarCollapsed"
                :class="{ 'rotate-180': open }"
                class="w-3.5 h-3.5 shrink-0 transition-transform duration-300 opacity-50"
                fill="none" stroke="currentColor" viewBox="0 0 24 24"
            >
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7"/>
            </svg>
        </button>

        {{-- SOUS-MENU --}}
        <div
            x-show="open && !sidebarCollapsed"
            x-collapse
            class="overflow-hidden"
        >
            <div class="mt-1 ml-4 pl-3.5 border-l border-zinc-200 dark:border-white/10 space-y-0.5 pb-1">
                @foreach ($subItems as $subItem)
                    @php
                        $subRoute    = $subItem['route'] ?? '#';
                        $subCount    = isset($subItem['count']) && $subItem['count'] ? add_zero($subItem['count']) : null;
                        $subIsActive = request()->routeIs($subRoute . '*');
                        $subIcon     = $subItem['icon'] ?? null;
                    @endphp
                    <a
                        href="{{ $subRoute }}"
                        wire:navigate
                        class="group flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-sm
                               transition-all duration-150
                               {{ $subIsActive
                                   ? 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-medium'
                                   : 'text-zinc-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5 hover:text-zinc-800 dark:hover:text-white' }}"
                    >
                        <span class="flex items-center gap-2 truncate">
                            @if($subIcon)
                                <i class="{{ $subIcon }} text-xs opacity-70"></i>
                            @else
                                <span class="w-1 h-1 rounded-full bg-current opacity-50 shrink-0"></span>
                            @endif
                            <span class="truncate">{!! __($subItem['label']) !!}</span>
                        </span>
                        @if($subCount)
                            <span class="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5
                                         text-[10px] font-bold rounded-full shrink-0
                                         {{ $subIsActive
                                             ? 'bg-indigo-500/20 text-indigo-600 dark:text-indigo-300'
                                             : 'bg-zinc-200 dark:bg-white/10 text-zinc-500 dark:text-zinc-400' }}">
                                {{ $subCount }}
                            </span>
                        @endif
                    </a>
                @endforeach
            </div>
        </div>

    @else
        {{-- ══════════════════════════════════════════
             ITEM SIMPLE
        ══════════════════════════════════════════ --}}
        <a
            href="{{ $itemRoute }}"
            wire:navigate
            :title="sidebarCollapsed ? @js(__($item['label'])) : ''"
            class="group relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
                   transition-all duration-200 outline-none focus-visible:ring-2 focus-visible:ring-indigo-500/50
                   {{ $isActive
                       ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/25'
                       : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5 hover:text-zinc-900 dark:hover:text-white' }}"
        >
            {{-- Indicateur actif (mode collapsed) --}}
            <span
                x-show="sidebarCollapsed && {{ $isActive ? 'true' : 'false' }}"
                class="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r-full bg-indigo-400"
                x-cloak
            ></span>

            {{-- Icône (SVG inline mt-icons, fallback FontAwesome) --}}
            <span class="flex items-center justify-center w-5 shrink-0 transition-transform duration-200 group-hover:scale-110 {{ $isActive ? 'text-white' : 'text-zinc-400 group-hover:text-indigo-400' }}">
                @if($iconSvg) {!! $iconSvg !!} @else <i class="{{ $itemIcon }} text-base leading-none"></i> @endif
            </span>

            {{-- Label --}}
            <span
                x-show="!sidebarCollapsed"
                x-transition:enter="transition-opacity duration-150"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-100"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                class="flex-1 truncate"
            >
                {!! __($item['label']) !!}
            </span>

            {{-- Badge compteur --}}
            @if($itemCount)
                <span
                    x-show="!sidebarCollapsed"
                    class="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5
                           text-[10px] font-bold rounded-full shrink-0
                           {{ $isActive
                               ? 'bg-white/25 text-white'
                               : 'bg-zinc-200 dark:bg-white/10 text-zinc-500 dark:text-zinc-400' }}"
                >
                    {{ $itemCount }}
                </span>
            @endif
        </a>
    @endif

</div>