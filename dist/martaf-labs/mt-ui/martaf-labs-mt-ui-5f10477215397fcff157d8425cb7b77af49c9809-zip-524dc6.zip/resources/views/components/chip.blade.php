{{--
    Composant : <x-mt::chip>
    Pilule cliquable (bouton) — filtre sélectionnable, bascule d'état, déclencheur.
    Remplace les `<button class="rounded-full …">` faits main dans les projets.

    Variantes de rendu :
      - solid   : fond plein couleur + texte blanc (état sélectionné/actif)
      - soft    : fond teinté (rgba .12) + texte couleur (façon badge, ex. statut)
      - outline : fond surface + bordure fine + texte normal (état inactif)
    Défaut : `active` pilote solid (actif) vs outline (inactif). `variant` force un rendu.

    Props : active (bool), color (token mt: primary|success|warning|danger|info|…),
            variant (solid|soft|outline), icon (nom mt-icon), size (sm|md)
    Attributs : wire:click / @click / type… passent au <button>.
--}}
@props([
    'active'  => false,
    'color'   => 'primary',
    'variant' => null,
    'icon'    => null,
    'size'    => 'md',
])

@php
    $v = $variant ?: ($active ? 'solid' : 'outline');
    $style = match ($v) {
        'solid'   => "background: rgb(var(--mt-{$color})); color: #fff;",
        'soft'    => "background: rgba(var(--mt-{$color}), .12); color: rgb(var(--mt-{$color}));",
        default   => "background: rgb(var(--mt-ui-card-bg)); color: rgb(var(--mt-text)); border: 1px solid rgb(var(--mt-ui-card-border));",
    };
    $sizeClass = $size === 'sm' ? 'px-3 py-1 text-xs' : 'px-4 py-2 text-sm';
@endphp

<button type="button"
    {{ $attributes->merge(['class' => "inline-flex items-center gap-1.5 rounded-full font-medium transition {$sizeClass}"]) }}
    style="{{ $style }}">
    @if($icon)
        <x-mt::icon :name="$icon" class="text-xs" />
    @endif
    <span>{{ $slot }}</span>
</button>
