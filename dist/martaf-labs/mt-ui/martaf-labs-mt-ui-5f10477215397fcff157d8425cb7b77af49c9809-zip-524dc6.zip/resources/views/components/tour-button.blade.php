{{--
    Composant : <x-mt::tour-button name="…" />
    Bouton « Revoir le guide » qui RELANCE une visite guidée (<x-mt::tour>).
    Dispatch l'event window `start-tour` écouté par le composant tour du même `name`.

    Ne s'affiche QUE si un tour est réellement déclaré pour cet écran
    (mt_tour($name) non vide) → neutre sur les projets/écrans sans tour.

    ⚠️ Compose <x-mt::button> (pas de <button> maison) : cohérence design-system +
    padding géré par mt-btn-* (les classes Tailwind décimales px-2.5/py-1.5/gap-1.5
    ne sont PAS dans le CSS précompilé mt-ui → à ne jamais utiliser ici).

    Props : name (clé du tour), label (surcharge du libellé), icon (défaut question-circle),
            variant (défaut ghost), size (défaut sm). Le reste des attributs passe au bouton.
--}}
@props([
    'name'    => 'default',
    'label'   => null,
    'icon'    => 'question-circle',
    'variant' => 'ghost',
    'size'    => 'sm',
])

@if(!empty(mt_tour($name)))
    <x-mt::button
        :variant="$variant"
        :size="$size"
        :icon="$icon"
        onclick="window.dispatchEvent(new CustomEvent('start-tour', { detail: { name: '{{ $name }}' } }))"
        {{ $attributes }}
    >
        {{-- Libellé masqué sur mobile → bouton d'aide compact (icône seule). --}}
        <span class="hidden sm:inline">{{ $label ?? __('mt-ui::mt-ui.tour_replay') }}</span>
    </x-mt::button>
@endif
