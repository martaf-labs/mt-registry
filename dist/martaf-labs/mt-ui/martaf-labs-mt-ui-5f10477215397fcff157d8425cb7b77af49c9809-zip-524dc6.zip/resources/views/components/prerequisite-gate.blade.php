{{--
    <x-mt::prerequisite-gate :items="[…]" />
    Panneau « avant de continuer » : l'écran a des prérequis non satisfaits.
    NEUTRE : le contenu (messages, URLs, libellés CTA) vient de l'hôte —
    items = [['message' => string, 'url' => string, 'cta' => string], …].
    Affiché À LA PLACE du formulaire inutilisable (selects vides, actions vouées à l'échec).
--}}
@props([
    'items' => [],
    'title' => null,
])

@if(!empty($items))
    <div class="mx-auto w-full max-w-2xl">
        <div class="rounded-2xl border p-6"
             style="border-color: rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg))">
            <div class="flex items-start gap-4">
                <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full"
                     style="background: rgba(var(--mt-warning), 0.15)">
                    <x-mt::icon name="exclamation-triangle" style="color: rgb(var(--mt-warning))" />
                </div>
                <div class="min-w-0">
                    <h2 class="text-lg font-bold mt-text">{{ $title ?? __('mt-ui::mt-ui.prerequisites_title') }}</h2>
                    <p class="mt-text-muted mt-1 text-sm">{{ __('mt-ui::mt-ui.prerequisites_subtitle') }}</p>
                </div>
            </div>

            <div class="mt-5 space-y-3">
                @foreach($items as $item)
                    {{-- min-w-0/flex-1 sur le message + shrink-0 sur le CTA : sinon le bouton
                         déborde sur le texte quand le message est long. --}}
                    <div class="flex flex-col gap-3 rounded-xl border p-4 sm:flex-row sm:items-center"
                         style="border-color: rgb(var(--mt-ui-card-border))">
                        <div class="flex min-w-0 flex-1 items-start gap-3">
                            <span class="mt-0.5 shrink-0" style="color: rgb(var(--mt-warning))"><x-mt::icon name="x-circle" size="sm" /></span>
                            <span class="text-sm mt-text">{{ $item['message'] }}</span>
                        </div>
                        @if(!empty($item['url']))
                            <x-mt::button size="sm" variant="primary" :href="$item['url']" endIcon="chevron-right"
                                          class="shrink-0 self-start sm:self-auto"
                                          :label="$item['cta'] ?? __('mt-ui::mt-ui.prerequisites_go')" />
                        @endif
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endif
