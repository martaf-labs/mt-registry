@props([
    'id' => null,
    'model' => null,
    'placeholder' => null
])

@php
    $id = $id ?? Illuminate\Support\Str::slug($model);
@endphp

<div wire:ignore>
    <textarea
        id="{{ $id }}"
        class="tinymce-editor"
        wire:model.defer="{{ $model }}"
        placeholder="{{ $placeholder }}"
    >{{ $slot }}</textarea>
</div>

@once
    <script>
        document.addEventListener("livewire:navigated", initTinyMCE);
        document.addEventListener("DOMContentLoaded", initTinyMCE);

        function initTinyMCE() {
            if (typeof tinymce === 'undefined') { return; } // lib pas encore chargée → onload relancera
            document.querySelectorAll('.tinymce-editor').forEach((textarea) => {

                if (tinymce.get(textarea.id)) {
                    tinymce.get(textarea.id).remove();
                }

                // Récupérer wire:model*
                const modelAttr = Array.from(textarea.attributes).find(a => a.name.startsWith('wire:model'));
                const modelName = modelAttr ? modelAttr.value : null;

                // Récupérer le composant Livewire
                const lwRoot = textarea.closest('[wire\\:id]') || textarea.closest('[wire:id]');
                const componentId = lwRoot ? lwRoot.getAttribute('wire:id') : null;

                tinymce.init({
                    selector: `#${textarea.id}`,
                    plugins: 'link preview fullscreen image code lists table',
                    toolbar: 'undo redo | bold italic | image | preview fullscreen',                    
                    menubar: false,
                    contextmenu: false,
                    license_key: 'gpl',

                    setup(editor) {
                        const sync = () => {
                            if (componentId && modelName) {
                                Livewire.find(componentId).set(modelName, editor.getContent());
                            }
                        };

                        editor.on('keyup change input undo redo', sync);
                        editor.on('blur', sync);
                        editor.on('contextmenu', function(e){
                        });
                    },

                    /* Images options */
                    image_title: true,
                    image_caption: true,
                    image_dimensions: false,
                    images_file_types: 'jpeg,png,jpg,gif,webp,svg',

                    content_style: `
                        img.responsive-img {
                            max-width: 100% !important;
                            height: auto !important;
                            display: block !important;
                        }
                    `,
                    
                    // Désactive le Base64 automatique
                    paste_data_images: false, 
                    
                    // Route vers votre contrôleur Laravel
                    images_upload_url: '/admin/upload-image',
                    
                    // Gestion du token CSRF de Laravel
                    // images_upload_handler: function (blobInfo, success, failure) {
                    //     var xhr, formData;
                    //     xhr = new XMLHttpRequest();
                    //     xhr.withCredentials = false;
                    //     xhr.open('POST', '/admin/upload-image');
                        
                    //     // On récupère le token CSRF dans le meta tag de votre layout
                    //     var token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                    //     xhr.setRequestHeader("X-CSRF-Token", token);

                    //     xhr.onload = function() {
                    //         if (xhr.status != 200) {
                    //             failure('HTTP Error: ' + xhr.status);
                    //             return;
                    //         }
                    //         var json = JSON.parse(xhr.responseText);
                    //         success(json.location);
                    //     };
                        
                    //     formData = new FormData();
                    //     formData.append('file', blobInfo.blob(), blobInfo.filename());
                    //     xhr.send(formData);
                    // },

                    file_picker_callback(callback, value, meta) {
                        if (meta.filetype === 'image') {
                            let input = document.createElement('input');
                            input.type = 'file';
                            input.accept = 'image/*';

                            input.onchange = function () {
                                let file = this.files[0];
                                let reader = new FileReader();

                                reader.onload = function () {
                                    let id = 'blobid' + (new Date()).getTime();
                                    let blobCache = tinymce.activeEditor.editorUpload.blobCache;
                                    let blobInfo = blobCache.create(id, file, reader.result.split(',')[1]);
                                    blobCache.add(blobInfo);
                                    callback(blobInfo.blobUri(), { title: file.name });
                                };

                                reader.readAsDataURL(file);
                            };

                            input.click();
                        }
                    }
                });
            });
        }
    </script>

    {{-- Librairie TinyMCE self-host (public/vendor/tinymce). Placée APRÈS la définition de
         initTinyMCE : onload l'appelle dès que la lib est chargée → fiable en chargement complet
         ET en navigation SPA (wire:navigate), où DOMContentLoaded ne se redéclenche pas. --}}
    <script src="{{ asset('vendor/tinymce/tinymce.min.js') }}" referrerpolicy="origin" onload="initTinyMCE()"></script>
@endonce

{{-- tinyMCE.init({
    selector: 'textarea#content',
    plugins: 'image code',
    toolbar: 'undo redo | image | code',
    
    // Désactive le Base64 automatique
    paste_data_images: false, 
    
    // Route vers votre contrôleur Laravel
    images_upload_url: '/admin/upload-image',
    
    // Gestion du token CSRF de Laravel
    images_upload_handler: function (blobInfo, success, failure) {
        var xhr, formData;
        xhr = new XMLHttpRequest();
        xhr.withCredentials = false;
        xhr.open('POST', '/admin/upload-image');
        
        // On récupère le token CSRF dans le meta tag de votre layout
        var token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        xhr.setRequestHeader("X-CSRF-Token", token);

        xhr.onload = function() {
            if (xhr.status != 200) {
                failure('HTTP Error: ' + xhr.status);
                return;
            }
            var json = JSON.parse(xhr.responseText);
            success(json.location);
        };
        
        formData = new FormData();
        formData.append('file', blobInfo.blob(), blobInfo.filename());
        xhr.send(formData);
    }
}); --}}