{{--
    <x-mt::screen :title="…" [description=…] [:breadcrumbs="[['label'=>…,'lien'=>…],…]"] [:actions=…] [width=7xl|5xl|4xl|3xl|2xl]>
        [<x-slot:actions> … markup libre (boutons) rendu en position actions, haut-droite … </x-slot:actions>]
        … contenu de l'écran …
    </x-mt::screen>

    LE CADRE GLOBAL des écrans — exactement celui de base-index / base-form
    (min-h wrapper → conteneur centré → <x-mt::breadcrumbs> titre/fil d'Ariane/actions).
    Toute vue d'écran (managers, vues hôte, états spéciaux) DOIT poser son contenu
    dans ce cadre : c'est lui qui garantit l'unité visuelle de l'application.
--}}
@props([
    'title'       => null,
    'description' => '',
    'breadcrumbs' => [],
    'actions'     => false,
    'width'       => '7xl',
])

@php
    // Largeur max en STYLE INLINE (toujours appliqué) : certaines classes Tailwind
    // max-w-* (ex. max-w-4xl) sont ABSENTES du CSS précompilé de mt-ui → la classe
    // ne produirait aucune contrainte (page pleine largeur). Valeurs = échelle Tailwind.
    $maxRem = match ($width) {
        '2xl'   => '42rem',
        '3xl'   => '48rem',
        '4xl'   => '56rem',
        '5xl'   => '64rem',
        '6xl'   => '72rem',
        default => '80rem', // 7xl (= base-index / base-form)
    };
@endphp

<div class="min-h-screen py-3 lg:py-6">
    <div {{ $attributes->merge(['class' => 'px-4 mx-auto sm:px-6 lg:px-8']) }} style="max-width: {{ $maxRem }}">
        {{-- En-tête (titre/sous-titre/fil d'Ariane/actions) : DESKTOP/TABLETTE seulement.
             Sur mobile, la topbar porte déjà le titre de l'écran → on masque l'en-tête
             (même squelette que base-index). Les actions principales passent par le FAB. --}}
        <div class="hidden lg:block">
            <x-mt::breadcrumbs
                :title="$title"
                :description="$description"
                :datas="$breadcrumbs"
                :actions="$actions"
            />
        </div>

        {{ $slot }}
    </div>
</div>
