<div class="flex items-start max-md:flex-col">
    <div class="me-10 w-full pb-4 md:w-[220px]">
        @php
            $settingsNav = [
                ['route' => 'settings.profile',    'label' => __('Profile')],
                ['route' => 'settings.password',   'label' => __('Password')],
            ];
            if (class_exists(\Laravel\Fortify\Features::class)
                && \Laravel\Fortify\Features::canManageTwoFactorAuthentication()) {
                $settingsNav[] = ['route' => 'two-factor.show', 'label' => __('Two-Factor Auth')];
            }
            $settingsNav[] = ['route' => 'settings.appearance', 'label' => __('Appearance')];

            // Robustesse : ne rendre QUE les onglets dont la route existe dans l'app hôte
            // (sinon route() fatale → 500 sur toute la page paramètres).
            $settingsNav = array_values(array_filter(
                $settingsNav,
                fn ($i) => \Illuminate\Support\Facades\Route::has($i['route'])
            ));
        @endphp
        <nav class="space-y-1">
            @foreach ($settingsNav as $navItem)
                @php $isActive = request()->routeIs($navItem['route']); @endphp
                <a href="{{ route($navItem['route']) }}" wire:navigate
                   class="block px-3 py-2 text-sm rounded-lg transition-colors {{ $isActive ? 'mt-bg-primary-soft mt-text-primary font-medium' : 'mt-text mt-btn-ghost-muted' }}">
                    {{ $navItem['label'] }}
                </a>
            @endforeach
        </nav>
    </div>

    <hr class="md:hidden w-full" style="border-color: rgba(var(--mt-ui-card-border), 0.6)" />

    <div class="flex-1 self-stretch max-md:pt-6">
        <h2 class="text-lg font-semibold mt-text">{{ $heading ?? '' }}</h2>
        <p class="text-sm mt-text-muted">{{ $subheading ?? '' }}</p>

        <div class="mt-5 w-full max-w-lg">
            {{ $slot }}
        </div>
    </div>
</div>
