<!DOCTYPE html>
{{-- Script synchrone anti-FOUC : applique .dark sur <html> AVANT tout rendu --}}
@if(mt_has_dark_mode())
<script>
    (function(){
        var t = localStorage.getItem('theme');
        if (t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        }
    })();
</script>
@endif
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}"
    dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}"
    class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="@yield('meta_description', mt_config('seo.description'))">

    {{-- ================= SEO ================= --}}
    {{-- <meta property="og:type" content="@yield('og_type', mt_config('seo.og.type'))">
    <meta property="og:url" content="@yield('og_url', url()->current())">
    <meta property="og:site_name" content="@yield('og_site_name', mt_config('seo.og.site_name'))">
    <meta property="og:title" content="@yield('og_title', mt_config('app_name'))">
    <meta property="og:description" content="@yield('og_description', mt_config('seo.description'))">
    <meta property="og:image" content="@yield('og_image', asset(mt_config('assets.logos.jpg')))">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="{{ mt_config('seo.og.twitter_handle') }}">
    <meta name="twitter:title" content="@yield('og_title', mt_config('app_name'))">
    <meta name="twitter:description" content="@yield('og_description', mt_config('seo.description'))">
    <meta name="twitter:image" content="@yield('og_image', asset(mt_config('assets.logos.jpg')))"> --}}

    {{-- ================= FAVICONS ================= --}}
    {{-- <link rel="icon" href="{{ asset(mt_config('assets.favicons.ico')) }}" sizes="any">
    <link rel="icon" href="{{ asset(mt_config('assets.favicons.svg')) }}" type="image/svg+xml">
    <link rel="apple-touch-icon" href="{{ asset(mt_config('assets.favicons.png')) }}">

    <title>@yield('title', $title ?? mt_config('app_name'))</title> --}}


    {{-- ══ SEO ═══════════════════════════════════════════════════ --}}
    {{-- Titre de page : priorité au titre Livewire (`->title()` / `#[Title]`, passé en
         prop $title par le layout hôte), sinon @section('title') des pages @extends, sinon rien.
         Suffixe = marque de l'hôte (`mt_brand_name` = résolveur de brand par tenant, ex. sigle
         de l'école courante) ; repli sur app_name pour les SaaS sans résolveur. --}}
    @php
        $__pageTitle = trim((string) ($title ?? ''));
        if ($__pageTitle === '') {
            $__pageTitle = trim($__env->yieldContent('title'));
        }
        // Marque (mt_brand_name) UNIQUEMENT au navigateur : en mode natif (PWA installée),
        // la fenêtre affiche déjà le nom de l'app → la marque en suffixe ferait doublon.
        // Détection standalone côté serveur via le cookie posé par pwa.js (mt_pwa_mode=1).
        // Cookie absent (mt-pwa non installé ou navigateur) → marque affichée normalement.
        $__brand = request()->cookie('mt_pwa_mode') === '1' ? '' : (string) mt_brand_name();
    @endphp
    <title>{{ $__pageTitle }}{{ ($__pageTitle !== '' && $__brand !== '') ? ' - ' : '' }}{{ $__brand }}</title>

    {{-- Livewire 3 réécrit document.title avec le titre BRUT du composant (->title()), perdant
         le suffixe de marque. On le ré-applique après chaque mise à jour Livewire (marque =
         mt_brand_name = sigle de l'école courante ; repli app_name pour les SaaS sans résolveur). --}}
    <script>
        (function () {
            var BRAND = @json(mt_brand_name());
            if (!BRAND) return;

            // ⚠️ SINGLETON par onglet. wire:navigate CONSERVE le contexte JS entre les pages :
            // ré-exécuter ce script (autre page, autre école après login/déconnexion) ne doit
            // JAMAIS empiler un 2e observer avec une autre marque — deux observers à marques
            // différentes se répondent en boucle (« X - LLR - AL-IHSAN - LLR - … ») et gèlent
            // l'onglet. Un seul observer, la marque vit dans window.__mtBrandTitle.brand.
            var S = window.__mtBrandTitle || (window.__mtBrandTitle = { brand: null, prevBrand: null, observer: null });
            if (S.brand && S.brand !== BRAND) S.prevBrand = S.brand;   // changement d'école
            S.brand = BRAND;

            function esc(b) { return b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
            // Retire la marque PARTOUT : en suffixe " - Brand", en préfixe "Brand - ",
            // ou seule. Ainsi un titre déjà préfixé/suffixé ne double jamais la marque.
            function stripBrand(s, b) {
                var e = esc(b);
                return s
                    .replace(new RegExp('^\\s*' + e + '\\s*$'), '')       // marque seule
                    .replace(new RegExp('^\\s*' + e + '\\s*-\\s*'), '')   // préfixe
                    .replace(new RegExp('\\s*-\\s*' + e + '\\s*$'), '')   // suffixe
                    .trim();
            }

            // Mode NATIF (PWA installée) : la fenêtre affiche DÉJÀ le nom de l'app (Chrome le
            // préfixe au titre). Ajouter la marque ferait doublon → on ne l'ajoute QUE au navigateur.
            function isStandalone() {
                return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches)
                    || window.navigator.standalone === true
                    || document.referrer.indexOf('android-app://') === 0;
            }

            function applyBrand() {
                var brand = S.brand;
                if (!brand) return;
                var cur = document.title || '';
                var base = stripBrand(cur, brand);
                if (S.prevBrand && S.prevBrand !== brand) {             // retire aussi l'ancienne marque
                    base = stripBrand(base, S.prevBrand);
                }
                // Navigateur → « page - marque » ; app installée → « page » seule (marque = doublon).
                var next = isStandalone()
                    ? base
                    : (base === '' ? brand : (base + ' - ' + brand));
                if (next !== cur) document.title = next;                // n'écrit QUE si différent (anti-boucle)
            }

            if (S.observer) { applyBrand(); return; }                   // déjà installé → juste rafraîchir

            function observe() {
                // Observer tout le <head> (subtree) : sur wire:navigate, Livewire REMPLACE le
                // nœud <title> lui-même → observer le <title> seul se ferait détacher.
                if (document.head) {
                    S.observer = new MutationObserver(applyBrand);
                    S.observer.observe(document.head, { childList: true, subtree: true, characterData: true });
                }
            }
            applyBrand();
            if (document.readyState !== 'loading') { observe(); }
            else { document.addEventListener('DOMContentLoaded', function () { applyBrand(); observe(); }); }
            document.addEventListener('livewire:navigated', applyBrand);
        })();
    </script>

    <meta name="description" content="@hasSection('meta_description')
        @yield('meta_description')
    @else
        {{ mt_config('seo.description') ?? "Site d'information et d'analyses." }}
    @endif">

    <meta name="robots" content="index, follow">
    <meta name="author" content="{{  mt_config('app_name') }}">

    <link rel="canonical" href="@hasSection('og_url')
        @yield('og_url')
    @else
        {{ url()->current() }}
    @endif">

    {{-- ══ Open Graph ═════════════════════════════════════════════ --}}
    <meta property="og:type"        content="@hasSection('og_type') @yield('og_type') @else website @endif">
    <meta property="og:site_name"   content="@yield('og_site_name', mt_config('seo.og.site_name'))">
    <meta property="og:locale"      content="{{ str_replace('-', '_', app()->getLocale()) }}">
    <meta property="og:url"         content="@hasSection('og_url') @yield('og_url') @else {{ url()->current() }} @endif">
    <meta property="og:title"       content="@hasSection('og_title') @yield('og_title') @else {{ mt_config('app_name') }} @endif">
    <meta property="og:description" content="@hasSection('og_description') @yield('og_description') @else {{ mt_config('seo.description') ?? "Site d'information et d'analyses." }} @endif">

    @hasSection('og_image')
    <meta property="og:image"        content="@yield('og_image')">
    <meta property="og:image:width"  content="1200">
    <meta property="og:image:height" content="630">
    @endif

    {{-- ══ Twitter Card ═══════════════════════════════════════════ --}}
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:site"        content="{{ mt_config('seo.og.twitter_handle') }}">
    <meta name="twitter:title"       content="@hasSection('og_title') @yield('og_title') @else {{ mt_config('app_name') }} @endif">
    <meta name="twitter:description" content="@hasSection('og_description') @yield('og_description') @else {{ mt_config('seo.description') ?? "Site d'information et d'analyses." }} @endif">

    @hasSection('og_image')
    <meta name="twitter:image" content="@yield('og_image')">
    @endif


    {{-- ================= PACKAGE + PROJECT ASSETS ================= --}}
    @include('mt::partials.assets')

    {{-- ================= FONTS ================= --}}
    @if (mt_config('assets.google_font_url'))
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="{{ mt_config('assets.google_font_url') }}" rel="stylesheet">
    @endif

    @if(mt_has_dark_mode())
    {{-- ================= CRITICAL: DARK MODE ANTI-FLASH ================= --}}
    <script>
        (function () {
            const stored = localStorage.getItem('theme');
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (stored === 'dark' || (!stored && prefersDark)) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        })();
    </script>
    @endif

    {{-- ================= THEME VARS (tokens centralisés, cf. partials/theme-vars) ================= --}}
    @include('mt::partials.theme-vars')
    {{-- Static .mt-* CSS classes are in mt-ui-components.css (compiled via @mtAssets) --}}



    <x-mt::head.tinymce-config />

    @if(mt_has_dark_mode())
    {{-- ================= ALPINE THEME MANAGER CORRIGÉ ================= --}}
    <script>
        // Fonction globale pour appliquer le thème
        window.applyTheme = function(theme) {
            if (theme === 'dark') {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        };

        // Fonction pour obtenir le thème actuel
        window.getCurrentTheme = function() {
            const stored = localStorage.getItem('theme');
            if (stored) return stored;
            return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        };

        document.addEventListener('alpine:init', () => {
            Alpine.data('themeManager', () => ({
                darkMode: document.documentElement.classList.contains('dark'),

                init() {
                    // Initialiser depuis localStorage ou préférence système
                    const savedTheme = localStorage.getItem('theme');
                    if (savedTheme) {
                        this.darkMode = savedTheme === 'dark';
                    } else {
                        this.darkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
                    }
                    
                    // Appliquer le thème initial
                    window.applyTheme(this.darkMode ? 'dark' : 'light');

                    // Surveiller les changements de darkMode
                    this.$watch('darkMode', (val) => {
                        const theme = val ? 'dark' : 'light';
                        localStorage.setItem('theme', theme);
                        window.applyTheme(theme);
                    });

                    // Écouter les changements de préférence système
                    window.matchMedia('(prefers-color-scheme: dark)')
                        .addEventListener('change', e => {
                            if (!localStorage.getItem('theme')) {
                                this.darkMode = e.matches;
                            }
                        });

                    // Maintenir le thème après chaque navigation Livewire (SPA mode)
                    document.addEventListener('livewire:navigated', () => {
                        const currentTheme = window.getCurrentTheme();
                        window.applyTheme(currentTheme);
                        this.darkMode = currentTheme === 'dark';
                    });
                },

                toggleTheme() {
                    this.darkMode = !this.darkMode;
                }
            }));
        });

        // Script de secours pour s'assurer que le thème persiste après chaque chargement
        document.addEventListener('DOMContentLoaded', () => {
            const currentTheme = window.getCurrentTheme();
            window.applyTheme(currentTheme);
        });
    </script>
    @endif

    {{-- Styles Livewire (inclut [wire:loading]{display:none}). OBLIGATOIRE car @livewireScripts
         est placé manuellement (l'auto-injection de Livewire est alors désactivée) → sans ça,
         tous les éléments wire:loading restent visibles en permanence. --}}
    @livewireStyles
</head>

<body class="min-h-screen antialiased" @if(mt_has_dark_mode()) x-data="themeManager()" @endif>
    {{ $slot }}

    @livewireScripts
    @stack('scripts')

    {{-- ================= LIVEWIRE TITLE UPDATE ================= --}}
    <script>
        document.addEventListener('livewire:init', () => {
            Livewire.on('page-title-changed', (event) => {
                document.title = event.title;
            });
        });
    </script>

    {{-- PWA (mt-pwa) — bouton d'installation + bandeau hors-ligne. Rendu UNIQUEMENT
         si le package mt-pwa est installé (neutre : @includeIf, aucun couplage dur). --}}
    @includeIf('mt-pwa::components.pwa-ui')
</body>
</html>