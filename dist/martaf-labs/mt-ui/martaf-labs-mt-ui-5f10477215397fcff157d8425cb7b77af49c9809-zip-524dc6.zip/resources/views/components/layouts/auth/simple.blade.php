<x-mt::layouts.master>
    <div class="min-h-screen mt-bg">
        <div class="w-full">
            {{ $slot }}
        </div>
    </div>
</x-mt::layouts.master>
