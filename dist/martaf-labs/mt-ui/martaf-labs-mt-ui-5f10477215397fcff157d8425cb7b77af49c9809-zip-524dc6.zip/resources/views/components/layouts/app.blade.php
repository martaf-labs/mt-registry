<x-mt::layouts.master :title="$title ?? null">
    <div class="h-full antialiased" x-data="{ 
        sidebarOpen: window.innerWidth >= 1024,
        sidebarCollapsed: false,
        mobileMenuOpen:   false,
        mobileSearchOpen: false,
        mobileNotifOpen:  false,

        get sidebarWidth() {
            if (window.innerWidth < 1024) return 0;
            return this.sidebarCollapsed ? 80 : 256;
        },

        init() {
            window.addEventListener('resize', () => {
                if (window.innerWidth >= 1024) {
                    this.sidebarOpen = true;
                    this.mobileMenuOpen = false;
                } else {
                    this.sidebarOpen = false;
                    this.sidebarCollapsed = false;
                }
            });
            const savedState = localStorage.getItem('sidebarCollapsed');
            if (savedState !== null) this.sidebarCollapsed = savedState === 'true';
        }
    }" 
    x-init="init();
             $watch('sidebarCollapsed', val => localStorage.setItem('sidebarCollapsed', val));
             ">


    {{-- ═══════════════════════════════════════════════════
         DESKTOP SIDEBAR
         ═══════════════════════════════════════════════════ --}}
    <aside class="fixed top-0 left-0 z-50 flex-col hidden h-full transition-all duration-300 ease-in-out shadow-xl lg:shadow-none lg:flex mt-bg mt-border"
           :class="{ 'w-64': !sidebarCollapsed, 'w-20': sidebarCollapsed }">

        <div class="flex items-center justify-between flex-shrink-0 h-16 px-4"
         {{-- style="border-bottom: 1px solid rgb(var(--mt-ui-card-border)) --}}
         ">
            <a href="{{ route('dashboard') }}" class="flex items-center space-x-2 overflow-hidden">
                @php $mtBrandLogo = mt_brand_logo(); @endphp
                @if($mtBrandLogo)
                    <img src="{{ $mtBrandLogo }}" alt="" class="flex-shrink-0 object-cover rounded-lg w-9 h-9" />
                @endif
                <span x-show="!sidebarCollapsed" class="text-xl font-bold uppercase truncate mt-text">
                    {{ mt_brand_name() }}
                </span>
            </a>
            <button @click="sidebarCollapsed = !sidebarCollapsed"
                    class="flex p-1.5 rounded-lg transition-colors mt-btn-icon">
                <span class="transition-transform duration-300" :class="{ 'rotate-180': sidebarCollapsed }"><x-mt::icon name="chevron-left" size="sm" /></span>
            </button>
        </div>

        {{-- Scrollbar de la sidebar masquée (esthétique) : Firefox/Edge en inline,
             WebKit via la règle ci-dessous. Le scroll reste fonctionnel. --}}
        <style>
            nav.mt-sidebar-scroll::-webkit-scrollbar{width:0;height:0;display:none}
            /* Rail du sous-menu déployé : ligne guide alignée sous l'icône du parent +
               segment couleur de marque en face de l'item ACTIF (hover = segment discret).
               Propriétés logiques (inline-start) → RTL-safe pour l'arabe. */
            .mt-subnav { position: relative; margin-inline-start: 1.4rem; padding-inline-start: .8rem; }
            .mt-subnav--mob { margin-inline-start: 1.75rem; }
            .mt-subnav::before { content:''; position:absolute; inset-inline-start:0; top:.4rem; bottom:.4rem;
                                 width:2px; border-radius:2px; background: rgba(var(--mt-text), .10); }
            .mt-subnav-item { position: relative; }
            .mt-subnav-item::before { content:''; position:absolute; inset-inline-start:-.8rem; top:50%;
                                      transform:translateY(-50%); height:1.15rem; width:2px; border-radius:2px;
                                      background: transparent; transition: background .15s ease; }
            .mt-subnav-item:hover::before { background: rgba(var(--mt-text), .30); }
            .mt-subnav-item.mt-subnav-active::before { background: rgb(var(--mt-primary)); }
        </style>
        <nav class="flex-1 px-3 py-4 overflow-y-auto mt-sidebar-scroll"
             style="scrollbar-width: none; -ms-overflow-style: none;">
            <div class="mb-4">
                <h3 x-show="!sidebarCollapsed" class="px-3 mb-2 text-xs font-semibold tracking-wider uppercase mt-text-muted">
                    {{ __('mt-ui::mt-ui.main_menu') }}
                </h3>
                @php
                    // Accordéon : un seul sous-menu déployé à la fois. openGroup partagé par
                    // tous les groupes ; ouvert au départ sur le groupe ACTIF (le cas échéant).
                    $activeGroupKey = collect(mt_get_sidebar())
                        ->first(fn ($it) => ! empty($it['subItems']) && ($it['isActive'] ?? false))['key'] ?? '';
                @endphp
                <div class="space-y-1" x-data="{ openGroup: @js($activeGroupKey) }">
                    @foreach (mt_get_sidebar() as $item)
                        @php
                            $itemRoute  = $item['route'] ?? '';
                            $itemIcon   = $item['icon'] ?? 'fa-solid fa-circle';
                            $subItems   = $item['subItems'] ?? [];
                            $itemCount  = $item['count'] ?? null;
                            $groupKey   = $item['key'] ?? \Illuminate\Support\Str::slug($item['label'] ?? '');
                            // État actif calculé par mt_get_sidebar (chemin + préfixe de segment,
                            // meilleur score) — ne PAS recalculer ici : 'route' est une URL,
                            // pas un nom de route (routeIs(url.'*') ne matche jamais).
                            $isActive   = $item['isActive'] ?? false;
                            $badgeColors = $itemCount > 10 ? 'mt-badge mt-badge-danger'
                                         : ($itemCount > 5  ? 'mt-badge mt-badge-warning'
                                         : 'mt-badge mt-badge-info');
                        @endphp
                        @if(!empty($subItems))
                            <div class="space-y-1">
                                {{-- Réduit : un clic DÉPLIE la sidebar + ouvre ce groupe (sinon l'icône ne
                                     mènerait nulle part, le sous-menu étant masqué en mode réduit).
                                     Déplié : accordéon normal (bascule ce groupe, ferme les autres). --}}
                                <button @click="sidebarCollapsed ? (sidebarCollapsed = false, openGroup = @js($groupKey)) : (openGroup = (openGroup === @js($groupKey) ? null : @js($groupKey)))"
                                        class="flex items-center justify-between w-full px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 {{ $isActive ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}"
                                        :class="{ 'justify-center': sidebarCollapsed }" :title="sidebarCollapsed ? '{{ __($item['label']) }}' : ''">
                                    <div class="flex items-center min-w-0 gap-3" :class="{ 'justify-center': sidebarCollapsed }">
                                        <span class="flex-shrink-0 w-5 h-5 mt-text-muted" :class="{ 'mr-0': sidebarCollapsed, 'mr-3': !sidebarCollapsed }">
                                            <x-mt::icon :name="$itemIcon" />
                                        </span>
                                        <span x-show="!sidebarCollapsed" class="truncate">{!! __($item['label']) !!}</span>
                                    </div>
                                    <template x-if="!sidebarCollapsed">
                                        <span class="flex-shrink-0 ml-2 text-xs transition-transform duration-200" :class="{ 'rotate-180': openGroup === @js($groupKey) }">
                                            <x-mt::icon name="chevron-down" />
                                        </span>
                                    </template>
                                </button>
                                <div
                                    x-show="openGroup === @js($groupKey) && !sidebarCollapsed"
                                    x-transition:enter="transition-all duration-200 ease-out"
                                    x-transition:enter-start="opacity-0 -translate-y-1"
                                    x-transition:enter-end="opacity-100 translate-y-0"
                                    x-transition:leave="transition-all duration-150 ease-in"
                                    x-transition:leave-start="opacity-100 translate-y-0"
                                    x-transition:leave-end="opacity-0 -translate-y-1"
                                    class="mt-subnav space-y-1"
                                >
                                    @foreach ($subItems as $subItem)
                                        @php
                                            $subRoute  = $subItem['route'] ?? '';
                                            $subIcon   = $subItem['icon'] ?? 'fa-solid fa-circle';
                                            $subCount  = $subItem['count'] ?? null;
                                            $subActive = $subItem['isActive'] ?? false;
                                            $subBadge  = $subCount > 10 ? 'mt-badge mt-badge-danger' : ($subCount > 5 ? 'mt-badge mt-badge-warning' : 'mt-badge mt-badge-info');
                                        @endphp
                                        <a href="{{ $subRoute }}" wire:navigate class="mt-subnav-item flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors {{ $subActive ? 'mt-subnav-active mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}">
                                            <div class="flex items-center min-w-0 gap-3">
                                                <x-mt::icon :name="$subIcon" class="flex-shrink-0 w-4 h-4 mt-text-muted" />
                                                <span class="truncate">{!! __($subItem['label']) !!}</span>
                                            </div>
                                            @if($subCount)<span class="{{ $subBadge }} flex-shrink-0 ml-2">{{ $subCount }}</span>@endif
                                        </a>
                                    @endforeach
                                </div>
                            </div>
                        @else
                            <a href="{{ $itemRoute }}" wire:navigate class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 relative {{ $isActive ? 'mt-bg-primary-soft mt-text-primary' : 'mt-text mt-btn-ghost-muted' }}" :class="{ 'justify-center': sidebarCollapsed }" :title="sidebarCollapsed ? '{{ __($item['label']) }}' : ''">
                                <div class="flex items-center min-w-0 gap-3" :class="{ 'justify-center': sidebarCollapsed }">
                                    <span class="flex-shrink-0 w-5 h-5 mt-text-muted" :class="{ 'mr-0': sidebarCollapsed, 'mr-3': !sidebarCollapsed }">
                                        <x-mt::icon :name="$itemIcon" />
                                    </span>
                                    <span x-show="!sidebarCollapsed" class="truncate">{!! __($item['label']) !!}</span>
                                </div>
                                @if($itemCount)
                                    <span x-show="!sidebarCollapsed" class="{{ $badgeColors }} flex-shrink-0 ml-2">{{ $itemCount }}</span>
                                    <span x-show="sidebarCollapsed" class="{{ $badgeColors }} absolute -top-1 -right-1">{{ $itemCount }}</span>
                                @endif
                            </a>
                        @endif
                    @endforeach
                </div>
            </div>

            @if (\Illuminate\Support\Facades\Route::has('home'))   
            <div>
                {{-- Lien statique : jamais « actif » (la variable $isActive de la boucle fuyait ici). --}}
                <a href="{{ mt_get_route('home') }}" wire:navigate class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 relative mt-text mt-btn-ghost-muted" :class="{ 'justify-center': sidebarCollapsed }" :title="sidebarCollapsed ? '{{ __('mt-ui::mt-ui.back_to_site') }}' : ''">
                    <div class="flex items-center min-w-0" :class="{ 'justify-center': sidebarCollapsed }">
                        <span class="flex-shrink-0 w-5 h-5 mt-text-muted" :class="{ 'mr-0': sidebarCollapsed, 'mr-3': !sidebarCollapsed }">
                            <x-mt::icon name="arrow-left" />
                        </span>
                        <span x-show="!sidebarCollapsed" class="truncate">{{ __('mt-ui::mt-ui.back_to_site') }}</span>
                    </div>
                </a>
            </div>        
            @endif
        </nav>

        <div class="flex-shrink-0 p-4"
        {{-- style="border-top: 1px solid rgb(var(--mt-ui-card-border)) --}}
        ">
            <div x-data="{ profileOpen: false }" class="relative">
                <button @click="profileOpen = !profileOpen" class="flex items-center w-full gap-3 px-3 py-2 text-sm transition-colors rounded-lg mt-btn-ghost-muted" :class="{ 'justify-center': sidebarCollapsed }">
                    <span class="flex items-center justify-center flex-shrink-0 w-8 h-8 text-white rounded-lg" style="background: linear-gradient(135deg, rgb(var(--mt-primary)), rgb(var(--mt-secondary)))">{{ getInitials(auth()->user()?->fullName()) }}</span>
                    <template x-if="!sidebarCollapsed">
                        <div class="flex-1 min-w-0 ml-3 text-left">
                            <p class="font-medium truncate mt-text">{{ auth()->user()?->fullName() }}</p>
                            <p class="text-xs truncate mt-text-muted">{{ auth()->user()?->email }}</p>
                        </div>
                    </template>
                    <span x-show="!sidebarCollapsed" class="flex-shrink-0 ml-2 text-xs transition-transform duration-200 mt-text-muted" :class="{ 'rotate-180': profileOpen }">
                        <x-mt::icon name="chevron-up"/>
                    </span>
                </button>
                
                <div x-show="profileOpen" @click.away="profileOpen = false"
                     x-transition:enter="transition ease-out duration-100" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
                     x-transition:leave="transition ease-in duration-75" x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
                     class="absolute left-0 w-full mb-2 overflow-hidden shadow-lg rounded-xl bottom-full mt-card" :class="{ 'w-52': sidebarCollapsed }" x-cloak>

                    {{-- En-tête profil --}}
                    <div class="px-4 py-3" style="border-bottom: 1px solid rgb(var(--mt-ui-card-border))">
                        <p class="text-sm font-semibold truncate mt-text">{{ auth()->user()?->fullName() }}</p>
                        <p class="text-xs truncate mt-text-muted">{{ auth()->user()?->email }}</p>
                    </div>

                    {{-- Actions --}}
                    <div class="py-1">
                        @if(\Illuminate\Support\Facades\Route::has('settings.profile'))
                        <a href="{{ route('settings.profile') }}" wire:navigate
                           class="flex items-center gap-2.5 w-full px-4 py-2 text-sm transition-colors mt-text mt-btn-ghost-muted">
                            <x-mt::icon name="gear" />
                            {{ __('mt-ui::mt-ui.settings') }}
                        </a>
                        @endif

                        <button type="button"
                                onclick="window.dispatchEvent(new CustomEvent('confirm-logout'))"
                                class="flex items-center gap-2.5 w-full px-4 py-2 text-sm transition-colors rounded-none mt-text-danger"
                                style="background:transparent"
                                onmouseover="this.style.background='rgba(var(--mt-danger),0.08)'"
                                onmouseout="this.style.background='transparent'">
                            <x-mt::icon name="logout" />
                            {{ __('mt-ui::mt-ui.logout') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </aside>


    {{-- ═══════════════════════════════════════════════════
         CONTENU PRINCIPAL
         ═══════════════════════════════════════════════════ --}}
    <div class="flex flex-col min-h-screen transition-all duration-300"
         :style="window.innerWidth >= 1024 ? 'padding-left:' + sidebarWidth + 'px' : 'padding-left:0'">

        {{-- ── DESKTOP header ── --}}
        <header class="sticky top-0 z-30 flex-shrink-0 hidden lg:flex backdrop-blur-md mt-bg" style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
            <div class="w-full px-8 py-1">
                <div class="flex items-center justify-between">
                    <div></div>
                    <div class="flex items-center flex-shrink-0 space-x-2">
                        
                        <div>
                            <livewire:mt.global-search />
                        </div>

                        {{-- dropdown langues --}}
                        <livewire:mt.locale-switcher />

                        {{-- toggle dark mode --}}
                        <x-mt::dark-mode-toggle />

                        {{-- dropdown notifications (compteur réel via résolveur hôte) --}}
                        @php $__notif = function_exists('mt_notifications') ? mt_notifications() : ['enabled' => false, 'count' => 0, 'url' => null, 'recent' => []]; @endphp
                        <x-mt::dropdown>
                            <x-slot name="trigger">
                                <button class="relative p-2 rounded-lg mt-btn-icon">
                                    <x-mt::icon name="bell" />
                                    @if ($__notif['enabled'] && $__notif['count'] > 0)
                                        <span style="position:absolute; top:1px; right:1px; min-width:16px; height:16px; padding:0 4px; display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:700; line-height:1; border-radius:999px; background:rgb(var(--mt-danger)); color:#fff;">{{ $__notif['count'] > 99 ? '99+' : $__notif['count'] }}</span>
                                    @endif
                                </button>
                            </x-slot>
                            <x-mt::dropdown.menu>
                                <x-mt::dropdown.section :label="__('mt-ui::mt-ui.notifications')" />
                                <x-mt::dropdown.divider />
                                @forelse ($__notif['recent'] as $__n)
                                    <a href="{{ $__n['url'] ?? ($__notif['url'] ?? '#') }}" wire:navigate
                                       class="block px-3 py-2 text-sm" style="{{ empty($__n['read']) ? 'font-weight:600;' : '' }}">
                                        <span class="block truncate {{ empty($__n['read']) ? '' : 'mt-text-muted' }}">{{ $__n['title'] ?? '' }}</span>
                                        @if (!empty($__n['time']))<span class="block mt-text-muted" style="font-size:11px;">{{ $__n['time'] }}</span>@endif
                                    </a>
                                @empty
                                    <p class="p-3 text-sm mt-text-muted">{{ __('mt-ui::mt-ui.no_notifications_yet') }}</p>
                                @endforelse
                                @if ($__notif['enabled'] && $__notif['url'])
                                    <x-mt::dropdown.divider />
                                    <a href="{{ $__notif['url'] }}" wire:navigate class="block px-3 py-2 text-sm text-center mt-text-primary">{{ __('mt-ui::mt-ui.view_all_notifications') }}</a>
                                @endif
                            </x-mt::dropdown.menu>
                        </x-mt::dropdown>

                    </div>
                </div>
            </div>
        </header>


        {{-- ════════════════════════════════════════════════
             MOBILE TOP BAR
             ════════════════════════════════════════════════ --}}
        <header class="sticky top-0 z-30 flex-shrink-0 lg:hidden mob-topbar backdrop-blur-md mt-bg" style="height:56px">
            <div class="flex items-center w-full h-full gap-3 px-2">
                @php
                    $pageTitle = null;
                    foreach(mt_get_sidebar() as $_item) {
                        foreach(($_item['subItems'] ?? []) as $_sub) {
                            if ($_sub['isActive'] ?? false) { $pageTitle = __($_sub['label']); break 2; }
                        }
                        if ($_item['isActive'] ?? false) { $pageTitle = __($_item['label']); break; }
                    }
                    $pageTitle    = $pageTitle ?? mt_config('app_name');
                    $__brandName  = function_exists('mt_brand_name') ? (mt_brand_name() ?: mt_config('app_name')) : mt_config('app_name');
                    $__brandLogo  = function_exists('mt_brand_logo') ? mt_brand_logo() : null;
                @endphp

                {{-- Marque (vignette) + titre de l'écran (+ sous-titre poussé par l'écran, ex. « N résultats ») --}}
                <div class="flex items-center flex-1 min-w-0 gap-3">
                    <span class="mob-brand-badge">
                        @if($__brandLogo)
                            <img src="{{ $__brandLogo }}" alt="" style="width:100%;height:100%;object-fit:cover">
                        @else
                            {{ getInitials($__brandName) }}
                        @endif
                    </span>
                    @php $__mobSubtitle = trim($__env->yieldPushContent('mobileSubtitle')); @endphp
                    <div class="min-w-0">
                        <h1 class="text-base font-bold leading-tight truncate mt-text">{{ $title ?? $pageTitle }}</h1>
                        @if($__mobSubtitle !== '')
                            <p class="text-xs leading-tight truncate mt-text-muted" style="margin-top:1px">{{ $__mobSubtitle }}</p>
                        @endif
                    </div>
                </div>

                {{-- Actions : un SEUL bouton ⋮ → menu (thème, notifications…). Sur mobile,
                     le dropdown mt-ui s'ouvre en BOTTOM-SHEET (cf. components/dropdown). --}}
                <div class="shrink-0">
                    @php $__mnotif = function_exists('mt_notifications') ? mt_notifications() : ['enabled' => false]; @endphp
                    <x-mt::dropdown align="right" width="sm">
                        <x-slot:trigger>
                            <button type="button" class="mob-top-btn" style="position:relative" aria-label="{{ __('mt-ui::mt-ui.more') }}">
                                <x-mt::icon name="ellipsis-vertical" />
                                @if(!empty($__mnotif['enabled']) && ($__mnotif['count'] ?? 0) > 0)<span class="mob-notif-dot"></span>@endif
                            </button>
                        </x-slot:trigger>

                        {{-- Thème (bascule intégrée — ne ferme pas la feuille) --}}
                        <div class="flex items-center justify-between gap-3 px-3 py-2">
                            <span class="flex items-center gap-2 text-sm mt-text">
                                <x-mt::icon name="moon" class="w-4" style="opacity:.6" />
                                {{ __('mt-ui::mt-ui.theme') }}
                            </span>
                            <x-mt::dark-mode-toggle />
                        </div>

                        {{-- Notifications --}}
                        @if(!empty($__mnotif['enabled']) && !empty($__mnotif['url']))
                            <x-mt::dropdown.item :href="$__mnotif['url']" icon="bell"
                                :label="__('mt-ui::mt-ui.notifications')"
                                :badge="($__mnotif['count'] ?? 0) > 0 ? $__mnotif['count'] : null" />
                        @endif
                    </x-mt::dropdown>
                </div>
            </div>
        </header>


        {{-- Main --}}
        <main class="flex-1 overflow-y-auto">{{ $slot }}</main>
    </div>

    
    {{-- ============================================================
        MOBILE BOTTOM NAVIGATION
        ============================================================ --}}
    <div x-data="mobileSheetsManager()" 
        x-init="init()"
        class="lg:hidden">
        
        {{-- Barre de navigation mobile --}}
        <nav class="fixed bottom-0 left-0 right-0 z-[9999] mt-bg mob-bottom-nav" 
            style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
            <div class="flex items-stretch justify-around px-1 mob-nav-bar">
                @php $__mnav = mt_mobile_nav(); @endphp

                @if(!empty($__mnav['destinations']))
                    {{-- ══ Nav par DESTINATIONS + FAB (hôte a déclaré config mt-ui.mobile_nav) ══ --}}
                    @php
                        $__dest  = $__mnav['destinations'];
                        // Actions du FAB : un écran peut pousser une LISTE via @push('mobileFabActions')
                        // (JSON [{label,icon,route|method,target?}]). Sinon → FAB global unique de la config.
                        $__pushedActs = trim($__env->yieldPushContent('mobileFabActions'));
                        $__fabActions = $__pushedActs ? (json_decode($__pushedActs, true) ?: []) : [];
                        if (empty($__fabActions) && ! empty($__mnav['fab'])) {
                            $__fabActions = [[
                                'label' => $__mnav['fab']['label'] ?? '',
                                'icon'  => $__mnav['fab']['icon'] ?? 'plus',
                                'route' => $__mnav['fab']['url'] ?? null,
                            ]];
                        }
                        $__fabIcon  = $__mnav['fab']['icon'] ?? 'plus'; // icône du bouton FAB lui-même
                        $__fabMulti = count($__fabActions) > 1;
                        $__fabOne   = $__fabActions[0] ?? null;
                        // FAB au centre : [d0][d1] (FAB) [d2][Plus]
                        $__left  = array_slice($__dest, 0, 2);
                        $__right = array_slice($__dest, 2);
                    @endphp

                    @foreach($__left as $__it)
                        <a href="{{ $__it['url'] }}" wire:navigate class="mob-nav-item">
                            <div class="mob-nav-pill {{ $__it['isActive'] ? 'active' : '' }}"><x-mt::icon name="{{ $__it['icon'] }}" /></div>
                            <span class="mob-nav-lbl {{ $__it['isActive'] ? 'on' : '' }}">{{ __($__it['label']) }}</span>
                        </a>
                    @endforeach

                    @if(!empty($__fabActions))
                    <div style="display:contents" x-data="{ fabOpen: false }">
                        {{-- Bouton FAB : 1 action → lien/appel direct ; plusieurs → ouvre le popover. --}}
                        @if($__fabMulti)
                            <button type="button" @click="fabOpen = true" class="mob-fab-wrap" aria-label="{{ __('mt-ui::mt-ui.quick_actions') }}">
                                <span class="mob-fab"><x-mt::icon name="{{ $__fabIcon }}" /></span>
                            </button>
                        @elseif(!empty($__fabOne['event']))
                            <button type="button" @click="Livewire.dispatch('{{ $__fabOne['event'] }}')" class="mob-fab-wrap" aria-label="{{ __($__fabOne['label'] ?? '') }}">
                                <span class="mob-fab"><x-mt::icon name="{{ $__fabOne['icon'] ?? $__fabIcon }}" /></span>
                            </button>
                        @elseif(!empty($__fabOne['method']))
                            <button type="button" wire:click="{{ $__fabOne['method'] }}" class="mob-fab-wrap" aria-label="{{ __($__fabOne['label'] ?? '') }}">
                                <span class="mob-fab"><x-mt::icon name="{{ $__fabOne['icon'] ?? $__fabIcon }}" /></span>
                            </button>
                        @elseif(!empty($__fabOne['route']))
                            <a href="{{ $__fabOne['route'] }}" @if(empty($__fabOne['target'])) wire:navigate @endif class="mob-fab-wrap" aria-label="{{ __($__fabOne['label'] ?? '') }}">
                                <span class="mob-fab"><x-mt::icon name="{{ $__fabOne['icon'] ?? $__fabIcon }}" /></span>
                            </a>
                        @endif

                        {{-- Popover d'actions (bottom-sheet) — seulement si PLUSIEURS actions --}}
                        @if($__fabMulti)
                        <template x-teleport="body">
                            <div>
                                <div x-show="fabOpen" x-cloak @click="fabOpen = false"
                                    x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                                    x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                                    class="fixed inset-0" style="z-index:10050; background:rgba(0,0,0,.5); backdrop-filter:blur(2px)"></div>
                                <div x-show="fabOpen" x-cloak
                                    x-transition:enter="transition transform ease-out duration-300" x-transition:enter-start="translate-y-full" x-transition:enter-end="translate-y-0"
                                    x-transition:leave="transition transform ease-in duration-200" x-transition:leave-start="translate-y-0" x-transition:leave-end="translate-y-full"
                                    class="fixed left-0 right-0 bottom-0 shadow-2xl"
                                    style="z-index:10060; background:rgb(var(--mt-ui-card-bg)); border-top:1px solid rgb(var(--mt-ui-card-border)); border-radius:22px 22px 0 0; max-height:80vh; overflow-y:auto; padding-bottom:calc(1rem + env(safe-area-inset-bottom,0px))">
                                    <div class="flex justify-center pt-3 pb-1"><div style="width:42px;height:5px;border-radius:999px;background:rgb(var(--mt-ui-card-border))"></div></div>
                                    <p class="px-5 pt-2 pb-2 text-xs font-semibold tracking-wide uppercase mt-text-muted">{{ __('mt-ui::mt-ui.quick_actions') }}</p>
                                    <div class="px-2 pb-1">
                                        @foreach($__fabActions as $__a)
                                            @php $__aUrl = $__a['route'] ?? $__a['url'] ?? null; $__aMethod = $__a['method'] ?? null; $__aEvent = $__a['event'] ?? null; @endphp
                                            @if($__aEvent)
                                                {{-- Action = événement Livewire global (atteint le composant de la page, hors island). --}}
                                                <button type="button" @click="Livewire.dispatch('{{ $__aEvent }}'); fabOpen = false" class="mob-fab-action">
                                                    <span class="ic"><x-mt::icon name="{{ $__a['icon'] ?? 'bolt' }}" /></span>
                                                    <span class="lbl">{{ __($__a['label'] ?? '') }}</span>
                                                </button>
                                            @elseif($__aMethod)
                                                <button type="button" wire:click="{{ $__aMethod }}" @click="fabOpen = false" class="mob-fab-action">
                                                    <span class="ic"><x-mt::icon name="{{ $__a['icon'] ?? 'bolt' }}" /></span>
                                                    <span class="lbl">{{ __($__a['label'] ?? '') }}</span>
                                                </button>
                                            @elseif($__aUrl)
                                                <a href="{{ $__aUrl }}" @if(empty($__a['target'])) wire:navigate @endif @click="fabOpen = false" class="mob-fab-action">
                                                    <span class="ic"><x-mt::icon name="{{ $__a['icon'] ?? 'bolt' }}" /></span>
                                                    <span class="lbl">{{ __($__a['label'] ?? '') }}</span>
                                                </a>
                                            @endif
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </template>
                        @endif
                    </div>
                    @endif

                    @foreach($__right as $__it)
                        <a href="{{ $__it['url'] }}" wire:navigate class="mob-nav-item">
                            <div class="mob-nav-pill {{ $__it['isActive'] ? 'active' : '' }}"><x-mt::icon name="{{ $__it['icon'] }}" /></div>
                            <span class="mob-nav-lbl {{ $__it['isActive'] ? 'on' : '' }}">{{ __($__it['label']) }}</span>
                        </a>
                    @endforeach

                    {{-- Plus → menu complet (sheet) --}}
                    <button @click="openSheet('menu')" class="mob-nav-item">
                        <div class="mob-nav-pill" :class="activeSheet === 'menu' ? 'active' : ''"><x-mt::icon name="hamburger" /></div>
                        <span class="mob-nav-lbl" :class="activeSheet === 'menu' ? 'on' : ''">{{ __('mt-ui::mt-ui.more') }}</span>
                    </button>
                @else
                    {{-- ══ Repli : nav utilitaire (aucune destination déclarée) ══ --}}
                    <button @click="openSheet('menu')" class="mob-nav-item">
                        <div class="mob-nav-pill" :class="activeSheet === 'menu' ? 'active' : ''">
                            <x-mt::icon name="hamburger" />
                        </div>
                        <span class="mob-nav-lbl" :class="activeSheet === 'menu' ? 'on' : ''">{{ __('mt-ui::mt-ui.menu') }}</span>
                    </button>

                    <button class="mob-nav-item">
                        <div class="mob-nav-pill" :class="activeSheet === 'search' ? 'active' : ''">
                            <x-mt::icon name="magnifying-glass" />
                        </div>
                        <span class="mob-nav-lbl" :class="activeSheet === 'search' ? 'on' : ''">{{ __('mt-ui::mt-ui.search') }}</span>
                    </button>

                    <button class="mob-nav-item">
                        <div class="relative mob-nav-pill" :class="activeSheet === 'notifications' ? 'active' : ''">
                            <x-mt::icon name="bell" />
                            <span class="mob-notif-dot"></span>
                        </div>
                        <span class="mob-nav-lbl" :class="activeSheet === 'notifications' ? 'on' : ''">{{ __('mt-ui::mt-ui.notifications_short') }}</span>
                    </button>

                    <button @click="openSheet('settings')" class="mob-nav-item">
                        <div class="relative mob-nav-pill" :class="activeSheet === 'settings' ? 'active' : ''">
                            <x-mt::icon name="gear" />
                        </div>
                        <span class="mob-nav-lbl" :class="activeSheet === 'settings' ? 'on' : ''">{{ __('mt-ui::mt-ui.settings') }}</span>
                    </button>
                @endif

            </div>
        </nav>

        {{-- ============================================================
            MENU MOBILE : TIROIR LATÉRAL (se déploie de la GAUCHE vers la droite)
            ⚠️ Translate via classes custom (.mob-drawer-off/on) : les utilitaires
            Tailwind `-translate-x-full` ne sont pas garantis dans le CSS servi.
            z-index INLINE (au-dessus de la barre de nav) : z-[…] arbitraire = no-op.
            ============================================================ --}}
        <style>
            .mob-drawer-off { transform: translateX(-100%); }
            .mob-drawer-on  { transform: translateX(0); }

            /* Items du tiroir : épurés (icône fine, pas de gros carré coloré). */
            .mob-drawer-item{display:flex;align-items:center;gap:.8rem;width:100%;padding:.62rem .7rem;border-radius:12px;
                color:rgb(var(--mt-text));text-decoration:none;font-size:.925rem;font-weight:500;background:transparent;border:none;
                cursor:pointer;text-align:left;-webkit-tap-highlight-color:transparent;transition:background .14s,color .14s}
            .mob-drawer-item:hover{background:rgb(var(--mt-text) / .045)}
            .mob-drawer-item:active{background:rgb(var(--mt-text) / .08)}
            .mob-drawer-item.active{background:rgb(var(--mt-primary) / .12);color:rgb(var(--mt-primary));font-weight:600}
            .mob-drawer-ic{flex:0 0 auto;display:inline-flex;color:rgb(var(--mt-text) / .5)}
            .mob-drawer-ic svg{width:1.25rem;height:1.25rem}
            .mob-drawer-item.active .mob-drawer-ic{color:rgb(var(--mt-primary))}
            .mob-drawer-lbl{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
            .mob-drawer-badge{flex:0 0 auto;font-size:.68rem;font-weight:700;padding:1px 8px;border-radius:999px;
                background:rgb(var(--mt-primary) / .14);color:rgb(var(--mt-primary))}
            .mob-drawer-chev{flex:0 0 auto;color:rgb(var(--mt-text) / .4);display:inline-flex;transition:transform .2s}
            .mob-drawer-chev.open{transform:rotate(180deg)}
            .mob-drawer-sub{margin:2px 0 4px 1.55rem;padding-left:.75rem;border-left:1px solid rgb(var(--mt-ui-card-border));
                display:flex;flex-direction:column;gap:1px}
            .mob-drawer-subitem{display:flex;align-items:center;gap:.6rem;padding:.5rem .6rem;border-radius:9px;
                color:rgb(var(--mt-text) / .78);text-decoration:none;font-size:.87rem}
            .mob-drawer-subitem:hover{background:rgb(var(--mt-text) / .045)}
            .mob-drawer-subitem.active{color:rgb(var(--mt-primary));font-weight:600;background:rgb(var(--mt-primary) / .10)}
            .mob-drawer-subitem svg{width:1rem;height:1rem;flex:0 0 auto;opacity:.75}
            .mob-drawer-section{font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
                color:rgb(var(--mt-text) / .4);padding:.6rem .7rem .25rem}
            /* Déconnexion : même gabarit que les items, en teinte danger. */
            .mob-drawer-logout{color:rgb(var(--mt-danger));font-weight:600}
            .mob-drawer-logout .mob-drawer-ic{color:rgb(var(--mt-danger) / .8)}
            .mob-drawer-logout:hover{background:rgb(var(--mt-danger) / .09)}
            .mob-drawer-logout:active{background:rgb(var(--mt-danger) / .15)}
        </style>
        <div x-show="activeSheet === 'menu'" class="fixed inset-0" style="z-index: 10050" x-cloak>

            <!-- Scrim -->
            <div x-show="activeSheet === 'menu'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('menu')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <!-- Tiroir (gauche) -->
            <div x-show="activeSheet === 'menu'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="mob-drawer-off"
                x-transition:enter-end="mob-drawer-on"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="mob-drawer-on"
                x-transition:leave-end="mob-drawer-off"
                class="fixed top-0 bottom-0 left-0 flex flex-col shadow-2xl mt-bg"
                style="width: 84vw; max-width: 330px; border-right: 1px solid rgb(var(--mt-ui-card-border)); border-radius: 0 22px 22px 0; padding-top: env(safe-area-inset-top, 0px); padding-bottom: env(safe-area-inset-bottom, 0px)">

                <!-- Header -->
                <div class="flex items-center justify-between flex-shrink-0 px-5 py-4" 
                    style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                    <div class="flex items-center gap-3">
                        <span class="flex items-center justify-center text-sm font-bold text-white mt-gradient-brand" style="width:2.5rem;height:2.5rem;border-radius:13px">
                            {{ getInitials(auth()->user()?->fullName()) }}
                        </span>
                        <div>
                            <p class="text-sm font-semibold leading-tight mt-text">{{ auth()->user()?->fullName() }}</p>
                            <p class="text-xs mt-text-muted">{{ auth()->user()?->email }}</p>
                        </div>
                    </div>
                    <button @click="closeSheet('menu')" 
                            class="flex items-center justify-center w-8 h-8 rounded-full mt-btn-icon">
                        <x-mt::icon name="close" size="sm" />
                    </button>
                </div>

                <!-- Navigation items -->
                @php
                    // Accordéon (menu mobile) : un seul groupe déployé à la fois, ouvert sur le groupe actif.
                    $mobileActiveGroup = collect(mt_get_sidebar())
                        ->first(fn ($it) => ! empty($it['subItems']) && ($it['isActive'] ?? false))['key'] ?? '';
                @endphp
                <div class="flex-1 px-3 overflow-y-auto" style="padding-top:.5rem;padding-bottom:.5rem;display:flex;flex-direction:column;gap:2px" x-data="{ openGroup: @js($mobileActiveGroup) }">
                    @foreach(mt_get_sidebar() as $_mi)
                        @php
                            $mr    = $_mi['route'] ?? '#';
                            $mic   = $_mi['icon'] ?? 'fa-solid fa-circle';
                            $ml    = $_mi['label'] ?? '';
                            $mc    = $_mi['count'] ?? null;
                            $msub  = $_mi['subItems'] ?? [];
                            $mact  = $_mi['isActive'] ?? false;
                            $mKey  = $_mi['key'] ?? \Illuminate\Support\Str::slug($ml);
                        @endphp
                        @if(!empty($msub))
                            <div>
                                <button @click="openGroup = (openGroup === @js($mKey) ? null : @js($mKey))"
                                        class="mob-drawer-item {{ $mact ? 'active' : '' }}">
                                    <span class="mob-drawer-ic"><x-mt::icon name="{{ $mic }}" /></span>
                                    <span class="mob-drawer-lbl">{!! __($ml) !!}</span>
                                    <span class="mob-drawer-chev" :class="{ 'open': openGroup === @js($mKey) }"><x-mt::icon name="chevron-down" size="xs" /></span>
                                </button>
                                <div x-show="openGroup === @js($mKey)" x-collapse.duration.150ms class="mob-drawer-sub">
                                    @foreach($msub as $_si)
                                        @php $sr = $_si['route'] ?? '#'; $sa = $_si['isActive'] ?? false; $sc = $_si['count'] ?? null; @endphp
                                        <a href="{{ $sr }}" wire:navigate @click="closeSheet('menu')" class="mob-drawer-subitem {{ $sa ? 'active' : '' }}">
                                            <x-mt::icon name="{{ $_si['icon'] }}" />
                                            <span class="mob-drawer-lbl">{!! __($_si['label']) !!}</span>
                                            @if($sc)<span class="mob-drawer-badge">{{ $sc }}</span>@endif
                                        </a>
                                    @endforeach
                                </div>
                            </div>
                        @else
                            <a href="{{ $mr }}" wire:navigate @click="closeSheet('menu')" class="mob-drawer-item {{ $mact ? 'active' : '' }}">
                                <span class="mob-drawer-ic"><x-mt::icon name="{{ $mic }}" /></span>
                                <span class="mob-drawer-lbl">{!! __($ml) !!}</span>
                                @if($mc)<span class="mob-drawer-badge">{{ $mc }}</span>@endif
                            </a>
                        @endif
                    @endforeach
                </div>

                <!-- Footer : déconnexion en ligne de menu (harmonisée, teinte danger) -->
                <div class="flex-shrink-0 px-3 pt-2 pb-3" style="border-top: 1px solid rgb(var(--mt-ui-card-border) / .6)">
                    <button type="button" onclick="window.dispatchEvent(new CustomEvent('confirm-logout'))" class="mob-drawer-item mob-drawer-logout">
                        <span class="mob-drawer-ic"><x-mt::icon name="logout" /></span>
                        <span class="mob-drawer-lbl">{{ __('mt-ui::mt-ui.logout') }}</span>
                    </button>
                </div>
            </div>
        </div>

        {{-- ============================================================
            SHEET: RECHERCHE
            ============================================================ --}}
        <div x-show="activeSheet === 'search'" class="fixed inset-0 z-[998]" x-cloak>
            
            <div x-show="activeSheet === 'search'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('search')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <div x-show="activeSheet === 'search'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="translate-y-full"
                x-transition:enter-end="translate-y-0"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="translate-y-0"
                x-transition:leave-end="translate-y-full"
                class="fixed bottom-[68px] left-0 right-0 rounded-t-3xl shadow-2xl max-h-[60vh] mt-bg"
                style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                
                <div class="flex justify-center pt-3 pb-1">
                    <div class="w-12 h-1 rounded-full" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>
                
                <div class="px-5 pt-2 pb-6">
                    <h3 class="mb-3 text-lg font-semibold mt-text">{{ __('mt-ui::mt-ui.search') }}</h3>
                    <div class="relative">
                        <x-mt::form.input type="search"
                            :placeholder="__('mt-ui::mt-ui.search_placeholder_examples')"
                            x-model="searchQuery"
                            @keyup.enter="performSearch()"
                            icon="magnifying-glass"
                            />
                    </div>
                    
                    <div x-show="searchResults.length > 0" x-cloak class="mt-4 space-y-2">
                        <template x-for="result in searchResults" :key="result.id">
                            <a :href="result.url" 
                            @click="closeSheet('search')"
                            class="flex items-center gap-3 p-3 transition-colors rounded-xl hover:mt-bg-primary-soft">
                                <i :class="result.icon" class="w-5 text-center mt-text-muted"></i>
                                <div>
                                    <p class="text-sm font-medium mt-text" x-text="result.title"></p>
                                    <p class="text-xs mt-text-muted" x-text="result.description"></p>
                                </div>
                            </a>
                        </template>
                    </div>
                    
                    <div x-show="searchQuery && searchResults.length === 0" x-cloak class="mt-8 text-center">
                        <i class="text-4xl fa-solid fa-search mt-text-muted opacity-30"></i>
                        <p class="mt-2 text-sm mt-text-muted">{{ __('mt-ui::mt-ui.no_results_found') }}</p>
                    </div>
                </div>
            </div>
        </div>

        {{-- ============================================================
            SHEET: NOTIFICATIONS
            ============================================================ --}}
        <div x-show="activeSheet === 'notifications'" class="fixed inset-0 z-[998]" x-cloak>
            
            <div x-show="activeSheet === 'notifications'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('notifications')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <div x-show="activeSheet === 'notifications'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="translate-y-full"
                x-transition:enter-end="translate-y-0"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="translate-y-0"
                x-transition:leave-end="translate-y-full"
                class="fixed bottom-[68px] left-0 right-0 rounded-t-3xl shadow-2xl max-h-[75vh] flex flex-col mt-bg"
                style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                
                <div class="flex justify-center flex-shrink-0 pt-3 pb-1">
                    <div class="w-12 h-1 rounded-full" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>
                
                <div class="flex items-center justify-between flex-shrink-0 px-5 py-4" 
                    style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                    <h3 class="text-base font-semibold mt-text">{{ __('mt-ui::mt-ui.notifications') }}</h3>
                    <span @click="markAllAsRead()"
                        class="text-xs font-medium transition-opacity cursor-pointer mt-text-primary hover:opacity-80">
                        {{ __('mt-ui::mt-ui.read_all') }}
                    </span>
                </div>
                
                <div class="flex-1 overflow-y-auto divide-y" style="--tw-divide-color: rgba(var(--mt-ui-card-border), 0.4)">
                    <div class="flex items-start gap-3 px-5 py-4 transition-colors hover:mt-bg-primary-soft" 
                        style="background: rgba(var(--mt-info), 0.05)">
                        <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" 
                            style="background: rgba(var(--mt-info), 0.12)">
                            <i class="text-sm fa-solid fa-cart-shopping" style="color: rgb(var(--mt-info))"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium mt-text">Nouvelle commande #1234</p>
                            <p class="text-xs mt-text-muted mt-0.5">Un nouveau client vient de passer commande.</p>
                            <p class="text-[11px] mt-1 font-medium mt-text-primary">Il y a 5 minutes</p>
                        </div>
                        <div class="flex-shrink-0 w-2 h-2 mt-2 rounded-full" style="background: rgb(var(--mt-info))"></div>
                    </div>
                    
                    <div class="flex items-start gap-3 px-5 py-4 transition-colors hover:mt-bg-primary-soft">
                        <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                            style="background: rgba(var(--mt-secondary), 0.12)">
                            <i class="text-sm fa-solid fa-comment" style="color: rgb(var(--mt-secondary))"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium mt-text">Message de Jean Dupont</p>
                            <p class="text-xs mt-text-muted mt-0.5">Pouvez-vous rappeler dès que possible ?</p>
                            <p class="text-[11px] mt-text-muted mt-1">Il y a 15 minutes</p>
                        </div>
                    </div>
                </div>
                
                <div class="flex-shrink-0 p-4" style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                    <a href="#" @click="closeSheet('notifications')" 
                    class="block w-full py-2.5 text-sm font-medium text-center rounded-xl transition-colors mt-text-primary hover:mt-bg-primary-soft">
                        {{ __('mt-ui::mt-ui.view_all_notifications') }}
                    </a>
                </div>
            </div>
        </div>

        {{-- ============================================================
            SHEET: PARAMÈTRES
            ============================================================ --}}
        <div x-show="activeSheet === 'settings'" class="fixed inset-0 z-[998]" x-cloak>
            
            <div x-show="activeSheet === 'settings'"
                x-transition:enter="transition-opacity duration-200"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="transition-opacity duration-150"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                @click="closeSheet('settings')"
                class="fixed inset-0 bg-black/50 backdrop-blur-sm">
            </div>

            <div x-show="activeSheet === 'settings'"
                x-transition:enter="transition transform duration-300 ease-out"
                x-transition:enter-start="translate-y-full"
                x-transition:enter-end="translate-y-0"
                x-transition:leave="transition transform duration-200 ease-in"
                x-transition:leave-start="translate-y-0"
                x-transition:leave-end="translate-y-full"
                class="fixed bottom-[68px] left-0 right-0 rounded-t-3xl shadow-2xl max-h-[80vh] flex flex-col mt-bg"
                style="border-top: 1px solid rgb(var(--mt-ui-card-border))">
                
                <div class="flex justify-center flex-shrink-0 pt-3 pb-1">
                    <div class="w-12 h-1 rounded-full" style="background: rgb(var(--mt-ui-card-border))"></div>
                </div>
                
                <div class="flex items-center justify-between flex-shrink-0 px-5 py-4" 
                    style="border-bottom: 1px solid rgba(var(--mt-ui-card-border), 0.6)">
                    <h3 class="text-base font-semibold mt-text">{{ __('mt-ui::mt-ui.settings') }}</h3>
                    <button @click="closeSheet('settings')"
                            class="flex items-center justify-center w-8 h-8 rounded-full mt-btn-icon">
                        <x-mt::icon name="close" size="sm" />
                    </button>
                </div>
                
                <div class="flex-1 overflow-y-auto divide-y" style="--tw-divide-color: rgba(var(--mt-ui-card-border), 0.4)">

                    @if(mt_has_dark_mode())
                    <!-- Thème -->
                    <div class="flex items-center justify-between px-5 py-4">
                        <div class="flex items-center gap-3">
                            <div class="flex items-center justify-center rounded-full w-9 h-9" 
                                style="background: rgba(var(--mt-primary), 0.12)">
                                <i class="text-sm fa-solid fa-moon" style="color: rgb(var(--mt-primary))"></i>
                            </div>
                            <div>
                                <p class="text-sm font-medium mt-text">{{ __('mt-ui::mt-ui.dark_mode') }}</p>
                                <p class="text-xs mt-text-muted">{{ __('mt-ui::mt-ui.toggle_appearance') }}</p>
                            </div>
                        </div>
                        <button @click="toggleTheme()"
                                class="relative min-w-[44px] h-6 rounded-full transition-all duration-200
                                after:content-[''] after:absolute after:top-[2px] after:left-[2px]
                                after:bg-white after:rounded-full after:h-5 after:w-5
                                after:transition-all after:duration-200"
                                :class="darkMode ? 'after:translate-x-[20px]' : 'after:translate-x-0'"
                                :style="darkMode ? 'background: rgb(var(--mt-primary))' : 'background: rgba(var(--mt-ui-card-border))'">
                            <span class="sr-only">{{ __('mt-ui::mt-ui.toggle_theme') }}</span>
                        </button>
                        
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- ============================================================
        CONFIRMATION DE DÉCONNEXION (partagée sidebar desktop + tiroir mobile)
        Déclenchée par l'event window `confirm-logout` ; la déconnexion réelle
        est un POST classique soumis à la validation.
        ============================================================ --}}
    <div x-data="{ open: false }" @confirm-logout.window="open = true" x-cloak>
        <div x-show="open" @click="open = false"
             x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
             x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
             class="fixed inset-0" style="z-index:10080; background:rgba(0,0,0,.5); backdrop-filter:blur(2px)"></div>

        <div x-show="open" x-cloak @keydown.escape.window="open = false"
             class="fixed inset-0 flex items-center justify-center p-4" style="z-index:10090">
            <div @click.stop x-show="open"
                 x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 translate-y-2" x-transition:enter-end="opacity-100 translate-y-0"
                 class="w-full max-w-sm p-5 shadow-2xl rounded-2xl"
                 style="background:rgb(var(--mt-ui-card-bg)); border:1px solid rgb(var(--mt-ui-card-border))">
                <div class="flex items-center gap-3 mb-3">
                    <span class="flex items-center justify-center rounded-full shrink-0" style="width:2.5rem; height:2.5rem; background:rgb(var(--mt-danger) / .12); color:rgb(var(--mt-danger))">
                        <x-mt::icon name="logout" />
                    </span>
                    <h3 class="text-base font-semibold mt-text">{{ __('mt-ui::mt-ui.logout_confirm_title') }}</h3>
                </div>
                <p class="mb-5 text-sm mt-text-muted">{{ __('mt-ui::mt-ui.logout_confirm_text') }}</p>
                <div class="flex justify-end gap-2">
                    <x-mt::button type="button" variant="ghost" @click="open = false">{{ __('mt-ui::mt-ui.cancel') }}</x-mt::button>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <x-mt::button type="submit" variant="danger" icon="logout">{{ __('mt-ui::mt-ui.logout') }}</x-mt::button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- ============================================================
        ALPINE COMPONENT - VERSION CORRIGÉE SANS $watch
        ============================================================ --}}
    <script>
    function mobileSheetsManager() {
        return {
            activeSheet: null,
            searchQuery: '',
            searchResults: [],
            darkMode: document.documentElement.classList.contains('dark'),
            
            init() {
                // console.log('Mobile sheets manager initialized');
                
                // Écouter les changements de classe dark sur le document
                const observer = new MutationObserver((mutations) => {
                    mutations.forEach((mutation) => {
                        if (mutation.attributeName === 'class') {
                            this.darkMode = document.documentElement.classList.contains('dark');
                        }
                    });
                });
                
                observer.observe(document.documentElement, { attributes: true });
            },
            
            openSheet(sheetName) {
                // console.log('Opening sheet:', sheetName);
                
                if (this.activeSheet === sheetName) {
                    this.activeSheet = null;
                } else {
                    this.activeSheet = sheetName;
                    
                    if (sheetName === 'search') {
                        // Reset search when opening
                        this.searchQuery = '';
                        this.searchResults = [];
                        
                        // Focus on search input after animation
                        setTimeout(() => {
                            const input = document.querySelector('input[type="search"]');
                            if (input) input.focus();
                        }, 300);
                    }
                }
            },
            
            closeSheet(sheetName) {
                if (this.activeSheet === sheetName) {
                    this.activeSheet = null;
                }
            },
            
            performSearch() {
                // La recherche mobile est gérée par livewire:mt.global-search
                this.searchResults = [];
            },
            
            toggleTheme() {
                this.darkMode = !this.darkMode;
                const theme = this.darkMode ? 'dark' : 'light';
                localStorage.setItem('theme', theme);
                
                if (this.darkMode) {
                    document.documentElement.classList.add('dark');
                } else {
                    document.documentElement.classList.remove('dark');
                }
            },
            
            markAllAsRead() {
                // console.log('Toutes les notifications ont été marquées comme lues');
                // Ajoutez votre logique ici
            }
        };
    }
    </script>

    <!-- Modals Livewire -->
    <livewire:mt.modals.confirm />
    <livewire:mt.modals.alert />

    @push('styles')
    <style>
        html, body { height: 100%; margin: 0; padding: 0; }
        .backdrop-blur-md { backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); }

        .scrollbar-thin::-webkit-scrollbar { width: 6px; }
        .scrollbar-thin::-webkit-scrollbar-track { background: transparent; }
        .scrollbar-thin::-webkit-scrollbar-thumb { background: rgb(var(--mt-ui-card-border)); border-radius: 3px; }
        .scrollbar-thin { scrollbar-width: thin; scrollbar-color: rgb(var(--mt-ui-card-border)) transparent; }

        /* ── Mobile top bar ── */
        .mob-top-btn {
            width: 30px; height: 30px;
            display: flex; align-items: center; justify-content: center;
            border-radius: 12px; border: none; background: transparent;
            cursor: pointer; color: rgb(var(--mt-text)); font-size: 17px;
            transition: background 0.12s, transform 0.1s;
            -webkit-tap-highlight-color: transparent;
            flex-shrink: 0;
        }
        .mob-top-btn:active { background: rgba(var(--mt-text), 0.08); transform: scale(0.88); }

        /* Vignette de marque (topbar mobile) — dégradé du SYSTÈME mt-ui (suit le thème/tenant). */
        .mob-brand-badge {
            width: 36px; height: 36px; flex: 0 0 auto; border-radius: 11px; overflow: hidden;
            display: flex; align-items: center; justify-content: center;
            font-size: 13px; font-weight: 800; color: #fff;
            background-color: rgb(var(--mt-primary));
            background-image: var(--mt-gradient-brand);
            box-shadow: 0 5px 12px -5px rgb(var(--mt-primary) / 0.7);
        }

        /* ── Bottom nav ── */
        .mob-bottom-nav {
            height: calc(68px + env(safe-area-inset-bottom, 0px));
        }
        .mob-nav-item {
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            gap: 3px; flex: 1; padding: 6px 2px;
            border: none; background: transparent; cursor: pointer; text-decoration: none;
            -webkit-tap-highlight-color: transparent;
            transition: transform 0.12s ease;
        }
        .mob-nav-item:active { transform: scale(0.88); }

        /* Pill highlight */
        .mob-nav-pill {
            width: 48px; height: 30px; border-radius: 15px;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; color: rgba(var(--mt-text), 0.4);
            transition: background 0.2s, color 0.2s;
        }
        .mob-nav-pill.active {
            background: rgba(var(--mt-primary), 0.12);
            color: rgb(var(--mt-primary));
        }

        /* Label */
        .mob-nav-lbl {
            font-size: 10px; font-weight: 500;
            color: rgba(var(--mt-text), 0.4);
            line-height: 1; transition: color 0.2s;
        }
        .mob-nav-lbl.on { color: rgb(var(--mt-primary)); font-weight: 700; }

        /* Notif dot */
        .mob-notif-dot {
            position: absolute; top: 3px; right: 6px;
            width: 7px; height: 7px;
            background: rgb(var(--mt-danger)); border-radius: 50%;
            border: 1.5px solid rgb(var(--mt-bg));
        }

        /* Hauteur de la rangée d'items (la barre ajoute le safe-area en dessous) */
        .mob-nav-bar { height: 68px; }

        /* ── FAB central surélevé (action clé de l'app) ── */
        .mob-fab-wrap {
            flex: 0 0 auto; display: flex; align-items: flex-start; justify-content: center;
            text-decoration: none; padding: 0 8px;
            -webkit-tap-highlight-color: transparent; transition: transform 0.12s ease;
        }
        .mob-fab-wrap:active { transform: scale(0.9); }
        .mob-fab {
            width: 54px; height: 54px; margin-top: -18px; border-radius: 18px;
            display: flex; align-items: center; justify-content: center;
            background: rgb(var(--mt-primary)); color: rgb(var(--mt-primary-content));
            box-shadow: 0 10px 22px -8px rgba(var(--mt-primary), 0.85), 0 2px 6px rgba(0,0,0,0.15);
            border: 3px solid rgb(var(--mt-bg));
        }
        .mob-fab svg { width: 24px; height: 24px; }

        /* Lignes du popover d'actions du FAB (bottom-sheet) — icône en dégradé mt-ui. */
        .mob-fab-action {
            display: flex; align-items: center; gap: .9rem; width: 100%;
            padding: .8rem .9rem; border-radius: 16px; text-decoration: none;
            background: transparent; border: none; cursor: pointer; text-align: left;
            -webkit-tap-highlight-color: transparent;
        }
        .mob-fab-action:active { background: rgb(var(--mt-text) / 0.06); }
        .mob-fab-action .ic {
            width: 44px; height: 44px; border-radius: 13px; flex: 0 0 auto;
            display: flex; align-items: center; justify-content: center; font-size: 18px;
            color: #fff; background-color: rgb(var(--mt-primary)); background-image: var(--mt-gradient-brand);
            box-shadow: 0 4px 10px -4px rgb(var(--mt-primary) / 0.6);
        }
        .mob-fab-action .ic svg { width: 20px; height: 20px; }
        .mob-fab-action .lbl { font-size: .95rem; font-weight: 600; color: rgb(var(--mt-text)); }

        /* Main padding on mobile */
        @media (max-width: 1023px) {
            main { padding-bottom: calc(76px + env(safe-area-inset-bottom, 0px)); }
        }
    </style>
    @endpush

    @push('scripts')


    <script>
    </script>
    @endpush
    </div>


</x-mt::layouts.master>