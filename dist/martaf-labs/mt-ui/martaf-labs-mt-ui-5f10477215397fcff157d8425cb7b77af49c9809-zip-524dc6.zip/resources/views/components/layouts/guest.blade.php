<x-mt::layouts.master>
    @push('styles')
    <style>
        .progress-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            box-shadow: 0 1px 3px 0 rgb(0,0,0,0.1);
            background: linear-gradient(90deg, rgba(var(--mt-primary)), rgba(var(--mt-secondary)));
            z-index: 1000;
            transition: width 0.2s ease;
        }
    </style>
    @endpush

    <!-- Progress bar -->
    <div class="progress-bar" id="progressBar"></div>

    {{ $slot }}

    @push('scripts')
        <script>            
            // Progress bar - gardé : le handler window.onscroll persiste après une
            // navigation SPA (wire:navigate) vers une page sans #progressBar → no-op.
            window.onscroll = function() {
                const bar = document.getElementById("progressBar");
                if (! bar) return;
                let winScroll = document.body.scrollTop || document.documentElement.scrollTop;
                let height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                let scrolled = (winScroll / height) * 100;
                bar.style.width = scrolled + "%";
            };
        </script>
    @endpush
</x-mt::layouts.master>