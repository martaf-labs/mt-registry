@props([
    'href' => null,
    'variant' => 'primary',
    'size' => 'md',
    'label' => null,
    'loading' => null,
    'icon' => null,
    'endIcon' => null,
    'error' => null,
    'help' => null,
    'disabled' => false,
])

@php
$baseClasses = "w-full mt-btn group inline-flex items-center justify-center transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed";

$variants = [
    'primary'   => 'mt-btn-primary',
    'secondary' => 'mt-btn-secondary',
    'danger'    => 'mt-btn-danger',
    'success'   => 'mt-btn-success',
    'warning'   => 'mt-btn-warning',
    'info'      => 'mt-btn-info',
    'outline'   => 'mt-btn-outline',
    'ghost'     => 'mt-btn-ghost',
];

$sizes = [
    'sm' => 'mt-btn-sm',
    'md' => 'mt-btn-md',
    'lg' => 'mt-btn-lg',
];

$classes = $baseClasses
    . ' ' . ($variants[$variant] ?? $variants['primary'])
    . ' ' . ($sizes[$size] ?? $sizes['md']);

$tag = $href ? 'a' : 'button';

// Cible wire:loading valide uniquement si non vide
$target = (is_string($loading) && !empty($loading)) ? $loading : null;

/** @var \MtIcons\IconRenderer $renderer */
$renderer = app(\MtIcons\IconRenderer::class);
@endphp

<div class="inline-flex flex-col w-full">
    <{{ $tag }}
        @if($href)
            href="{{ $href }}" wire:navigate
        @endif
        {{ $attributes->merge(['class' => $classes]) }}
        @if($target)
            wire:loading.attr="disabled"
            wire:target="{{ $target }}"
        @endif
        @if($disabled) disabled @endif
    >
        {{-- Spinner (affiché pendant le chargement) --}}
        @if($target)
            <span class="mr-1 animate-spin"
                  wire:loading.inline-flex
                  wire:target="{{ $target }}"
                  style="display:none;">
                {!! $renderer->render('circle-notch', ['size' => 'sm']) !!}
            </span>
        @endif

        {{-- Icône gauche (cachée pendant le chargement) --}}
        @if($icon)
            <span class="mr-1 group-hover:-translate-x-0.5 transition duration-150 ease-in-out"
                  @if($target) wire:loading.remove wire:target="{{ $target }}" @endif>
                @if($renderer->exists($icon))
                    {!! $renderer->render($icon, ['size' => 'sm']) !!}
                @else
                    <i class="{{ $icon }}"></i>
                @endif
            </span>
        @endif

        <span>{{ $label ?? $slot }}</span>

        {{-- Icône droite (cachée pendant le chargement) --}}
        @if($endIcon)
            <span class="ml-1 group-hover:translate-x-0.5 transition duration-150 ease-in-out"
                  @if($target) wire:loading.remove wire:target="{{ $target }}" @endif>
                @if($renderer->exists($endIcon))
                    {!! $renderer->render($endIcon, ['size' => 'sm']) !!}
                @else
                    <i class="{{ $endIcon }}"></i>
                @endif
            </span>
        @endif
    </{{ $tag }}>
</div>
