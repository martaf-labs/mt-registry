{{--
    <x-mt::empty-state [title=…] [description=…] [icon="inbox"]> … actions … </x-mt::empty-state>
    État vide générique (listes, recherches, sections sans contenu).
    - icon = nom mt-icons (SVG INLINE — jamais de <i> FontAwesome ni de masque CSS mt-icon-*).
      Rétro-compat : les anciens formats 'mt-icon-list' et 'fa-solid fa-inbox' sont normalisés.
    - title/description par défaut traduisibles (mt-ui::mt-ui.empty_state_*).
--}}
@props([
    'title'       => null,
    'description' => null,
    'icon'        => 'inbox-stack',
])

@php
    // Normalisation rétro-compat (FA / masque CSS legacy) → nom mt-icons.
    $iconName = mt_icon_name($icon, 'inbox-stack');

    $title ??= __('mt-ui::mt-ui.empty_state_title');
@endphp

<div {{ $attributes->merge(['class' => 'flex flex-col items-center justify-center p-4 lg:p-12 text-center border-2 border-dashed rounded-3xl'])
    }} style="border-color: rgb(var(--mt-ui-card-border))">

    {{-- Icône : pastille teintée à la couleur de marque (élégant, intentionnel). --}}
    <div class="flex items-center justify-center mb-5 rounded-full"
         style="width:4.5rem; height:4.5rem; background: rgba(var(--mt-primary), 0.10)">
        <span style="color: rgb(var(--mt-primary))"><x-mt::icon :name="$iconName" size="xl" /></span>
    </div>

    {{-- Titre --}}
    <h3 class="text-base font-semibold mt-text">
        {{ $title }}
    </h3>

    {{-- Description --}}
    @if($description)
        <p class="max-w-xs mt-2 text-sm mt-text-muted">
            {{ $description }}
        </p>
    @endif

    {{-- Slot (actions, boutons…) --}}
    @if($slot->isNotEmpty())
        <div class="mt-6">
            {{ $slot }}
        </div>
    @endif

</div>
