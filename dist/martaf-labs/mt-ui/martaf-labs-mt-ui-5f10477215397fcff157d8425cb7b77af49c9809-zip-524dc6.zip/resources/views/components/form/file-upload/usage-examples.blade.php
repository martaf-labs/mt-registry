{{--
|==========================================================================
| EXEMPLES D'UTILISATION - x-mt-file-upload
| Fichier de DOCUMENTATION (jamais rendu) : @verbatim empêche view:cache
| de compiler les tags de composant d'exemple.
|==========================================================================
--}}
@verbatim

{{-- ① Image simple (couverture article) --}}
<x-mt-file-upload
    name="cover"
    wire:model="cover"
    item-type="image"
    label="Image de couverture"
    :required="true"
    :old-value="$article->cover ?? null"
    placeholder="Glissez votre image de couverture"
    max-size="3"
/>


{{-- ② Image + légende (bloc éditeur) --}}
<x-mt-file-upload
    name="photo"
    wire:model="photo"
    item-type="image-legend"
    label="Photo avec légende"
    placeholder="Glissez votre photo"
/>


{{-- ③ Galerie multiple --}}
<x-mt-file-upload
    name="gallery"
    wire:model="gallery"
    item-type="image"
    :multiple="true"
    label="Galerie photos"
    hint="max 10 images"
    max-size="5"
/>


{{-- ④ Vidéo --}}
<x-mt-file-upload
    name="video"
    wire:model="video"
    item-type="video"
    label="Fichier vidéo"
    max-size="50"
/>


{{-- ⑤ Document PDF/DOC --}}
<x-mt-file-upload
    name="document"
    wire:model="document"
    item-type="file"
    accept=".pdf,.doc,.docx"
    label="Document"
    placeholder="Glissez votre document PDF ou Word"
    max-size="10"
/>


{{-- ⑥ Sans label, inline --}}
<x-mt-file-upload
    name="avatar"
    wire:model="avatar"
    item-type="image"
/>
@endverbatim
