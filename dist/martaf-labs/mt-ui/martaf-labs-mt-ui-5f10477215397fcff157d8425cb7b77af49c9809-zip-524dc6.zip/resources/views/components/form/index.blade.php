@props([
    'id' => null,
    'submit' => null,
    'loadingTarget' => "save",
    'withCard' => false
])

@php
    $loadingTarget = $loadingTarget ?? $submit;
@endphp

<div {{ $attributes->merge(['class' => 'w-full']) }}>
    <form 
        @if($submit) wire:submit.prevent="{{ $submit }}" @endif
        @if($id) id="{{ $id }}" @endif
    >
        @if ($errors->any())
            <div class="p-4 mb-6 rounded-r-lg mt-alert mt-alert-danger"
                 style="border-left: 4px solid rgb(var(--mt-danger))">
                <div class="flex">
                    <i class="flex-shrink-0 fa-solid fa-circle-exclamation"></i>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium">
                            Il y a {{ $errors->count() }} erreur(s) dans le formulaire
                        </h3>
                    </div>
                </div>
            </div>
        @endif
        
        <div @class([
            'mt-card p-6 rounded-2xl relative' => $withCard,
        ])>
            {{ $slot }}

            @if(isset($actions))
                @once
                <style>
                    /* Barre d'actions COLLANTE en bas sur MOBILE (toujours atteignable sans scroller
                       jusqu'au bout d'un long formulaire) ; statique sur desktop. Colle au-dessus de
                       la barre de nav mobile car <main> porte un padding-bottom (hauteur de la nav). */
                    @media (max-width: 1023px) {
                        .mt-form-actions {
                            position: sticky; bottom: 0; z-index: 20;
                            margin: 1.25rem 0 0; padding: .75rem 0 calc(.75rem + env(safe-area-inset-bottom, 0px));
                            background: rgb(var(--mt-bg));
                            border-top: 1px solid rgb(var(--mt-ui-card-border));
                            box-shadow: 0 -6px 16px -10px rgba(0,0,0,.35);
                        }
                    }
                </style>
                @endonce
                <div class="flex items-center justify-start w-full gap-3 pt-6 mt-8 mt-form-actions">
                    {{ $actions }}
                </div>
            @endif
        </div>
    </form>

    {{-- @if($loadingTarget)
        <div wire:loading wire:target="{{ $loadingTarget }}"
             class="fixed inset-0 z-50 backdrop-blur-[1px] flex items-center justify-center pointer-events-none"
             style="background: rgba(var(--mt-bg), 0.6)">
            <div class="flex items-center gap-3 p-4 shadow-xl rounded-xl mt-card">
                <div class="mt-spinner"></div>
                <span class="text-sm font-medium mt-text">Traitement en cours...</span>
            </div>
        </div>
    @endif --}}
</div>
