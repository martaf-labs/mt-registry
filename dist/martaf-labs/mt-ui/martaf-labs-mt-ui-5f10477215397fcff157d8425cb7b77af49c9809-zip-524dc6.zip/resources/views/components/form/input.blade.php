@props([
    'label' => null,
    'type'  => 'text',
    'model' => null,
    'icon'  => null,
    'error' => null,
    'help'  => null,
    'required'  => false,
    'size'  => 'md',
    'rounded' => null, // null → rayon par défaut de .mt-input ; sinon full|2xl|xl|lg|md|none (style INLINE)
])

@php
    $sizeClasses = [
        'sm' => 'mt-input-sm',
        'md' => '',
        'lg' => 'mt-input-lg',
    ];
    $inputSizeClass = $sizeClasses[$size] ?? '';

    // ⚠️ Une classe utilitaire (rounded-full…) ne suffit PAS : `.mt-input` du CSS précompilé
    // porte son propre border-radius (même spécificité, déclarée après → elle gagne). On force
    // donc le rayon en style INLINE (toujours prioritaire sur une classe).
    $radiusMap   = ['full' => '9999px', '2xl' => '1rem', 'xl' => '0.75rem', 'lg' => '0.5rem', 'md' => '0.375rem', 'none' => '0'];
    $radiusStyle = ($rounded && isset($radiusMap[$rounded])) ? 'border-radius:' . $radiusMap[$rounded] . ';' : '';
    // Pastille (rounded-full) + icône : un peu plus d'espace à gauche pour ne pas coller à l'arrondi.
    $padStyle    = $icon ? ($rounded === 'full' ? 'padding-left:3.25rem;' : 'padding-left:3rem;') : '';
@endphp

<div class="w-full">
    @if($label)
        <x-mt::form.label :value="$label" :size="$size" :required="$required" />
    @endif

    <div class="relative">
        @if($icon)
            <div class="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none mt-text-muted">
                <x-mt::icon :name="$icon" class="text-sm" />
            </div>
        @endif

        <input 
            type="{{ $type }}"
            @if($model) wire:model="{{ $model }}" @endif
            @if($required) required @endif
            {{ $attributes->merge([
                'class' => 'mt-input ' . $inputSizeClass . ' ' .
                    ($icon ? 'pl-8 lg:pl-16 ' : '') .
                    ($error ? 'mt-input-error' : '')
            ]) }}

            style="{{ $padStyle }}{{ $radiusStyle }}"
        >
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1.5" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1.5" />
    @endif
</div>
