@props([
    'label' => null,
    'model' => null,
    'onclick' => null,
    'error' => null,
    'help'  => null,
    'required' => false,
    'live' => false, // true → @entangle().live : le toggle peut déclencher des fieldActions
])

{{--
    Toggle : styles INLINE + Alpine (les classes Tailwind arbitraires
    min-w-[44px]/after:* ne sont pas dans le CSS précompilé → rail invisible).

    Deux modes d'état :
    - prop "model" fourni → @entangle (sync bidirectionnel fiable avec Livewire,
      reflète correctement l'état en édition / lazy-load).
    - sinon (wire:model passé en attribut, ex. champs de specs) → checkbox caché
      + sync sur change.
--}}
<div class="w-full">
    <label
        class="inline-flex items-center cursor-pointer gap-3"
        @if($model)
            x-data="{ on: @entangle($model)@if($live).live @endif }"
        @else
            x-data="{ on: false }"
            x-init="$nextTick(() => on = $refs.cb?.checked); $refs.cb && $refs.cb.addEventListener('change', () => on = $refs.cb.checked)"
        @endif
    >
        @unless($model)
            <input
                x-ref="cb"
                type="checkbox"
                @if($onclick) wire:click="{{ $onclick }}" @endif
                @if($required) required @endif
                {{ $attributes->merge(['class' => 'sr-only']) }}
            >
        @endunless

        {{-- Rail (clic = bascule en mode entangle ; en mode checkbox, le label coche nativement) --}}
        <span
            @if($model) @click="on = !on" @endif
            style="display:inline-block; position:relative; width:44px; height:24px; border-radius:9999px; transition:background-color .2s; flex:0 0 auto;"
            :style="{ backgroundColor: on ? 'rgb(var(--mt-success))' : 'rgb(var(--mt-ui-input-border))' }"
        >
            <span
                style="position:absolute; top:2px; left:2px; width:20px; height:20px; border-radius:9999px; background:#fff; box-shadow:0 1px 2px rgba(0,0,0,.25); transition:transform .2s;"
                :style="{ transform: on ? 'translateX(20px)' : 'translateX(0)' }"
            ></span>
        </span>

        {{-- Texte et feedback --}}
        <span @if($model) @click="on = !on" @endif>
            @if($label)
                <x-mt::form.label :value="$label" :required="$required" />
            @endif

            @if($error)
                <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1" />
            @elseif($help)
                <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1" />
            @endif
        </span>
    </label>
</div>
