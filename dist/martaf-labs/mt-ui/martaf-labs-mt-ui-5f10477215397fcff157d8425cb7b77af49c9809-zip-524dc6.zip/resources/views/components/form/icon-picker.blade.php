{{--
    Composant : Icon Picker (sélecteur d'icône) - basé sur mt-icons (SVG inline).
    Stocke le NOM d'une icône mt-icons (ex. "heavy-equipment").

    Usage :
    <x-mt::form.icon-picker
        label="Icône"
        model="item.icon"
        :icon="$item['icon']"
        :error="$errors->first('item.icon')"
        help="Choisissez une icône"
    />
--}}

@props([
    'label' => '',
    'model' => '',
    'icon' => null,
    'error' => null,
    'help' => null,
    'required' => false,
])

@php
    $allIcons = mt_icons(); // noms des icônes mt-icons disponibles
    sort($allIcons);
    $isValid = $icon && in_array($icon, $allIcons, true);
@endphp

<div {{ $attributes->merge(['class' => 'w-full']) }}>
    @if($label)
        <label class="mt-label">{{ $label }} @if($required)<span style="color: rgb(var(--mt-danger))">*</span>@endif</label>
    @endif

    <div class="relative mt-1" x-data="{ open: false, q: '' }">
        <div class="flex items-center gap-2">
            {{-- Aperçu + nom sélectionné --}}
            <div class="flex items-center flex-1 gap-3 px-3 py-2 rounded-xl"
                 style="border: 1px solid {{ $error ? 'rgb(var(--mt-danger))' : 'rgb(var(--mt-ui-input-border))' }}; background: rgb(var(--mt-ui-input-bg));">
                <span class="flex items-center justify-center" style="width:28px;height:28px;">
                    @if($isValid)
                        <x-mt::icon :name="$icon" class="size-6" />
                    @else
                        <x-mt::icon name="image" class="size-6" style="opacity:.4" />
                    @endif
                </span>
                <span class="text-sm mt-text">{{ $isValid ? $icon : '-' }}</span>
            </div>

            {{-- Bouton ouvrir --}}
            <button type="button" @click="open = !open"
                    class="px-4 py-2.5 rounded-xl mt-btn-icon"
                    style="border: 1px solid rgb(var(--mt-ui-input-border));">
                <x-mt::icon name="magnifying-glass" class="size-5" />
            </button>
        </div>

        {{-- Dropdown : recherche + grille --}}
        <div x-show="open" x-cloak @click.away="open = false"
             x-transition.opacity
             class="absolute right-0 z-[60] w-80 p-3 mt-2 shadow-2xl rounded-2xl"
             style="background: rgb(var(--mt-ui-card-bg)); border: 1px solid rgb(var(--mt-ui-card-border));">

            <input type="text" x-model="q" placeholder="Rechercher une icône…" autofocus
                   class="w-full px-3 py-2 mb-3 text-sm rounded-lg"
                   style="background: rgb(var(--mt-ui-input-bg)); border: 1px solid rgb(var(--mt-ui-input-border)); color: rgb(var(--mt-text));">

            <div class="overflow-y-auto" style="max-height:18rem;">
                @foreach(mt_icons_categorized() as $catLabel => $catNames)
                    <div x-show="q === '' || {{ \Illuminate\Support\Js::from(array_map('strval', $catNames)) }}.some(n => n.includes(q.toLowerCase()))">
                        <div class="px-1 pt-2 pb-1 text-xs font-semibold" style="color: rgb(var(--mt-muted));">{{ $catLabel }}</div>
                        <div style="display:grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap:4px;">
                            @foreach($catNames as $name)
                                <button type="button"
                                        x-show="q === '' || '{{ $name }}'.includes(q.toLowerCase())"
                                        @click="$wire.set('{{ $model }}', '{{ $name }}'); open = false; q = ''"
                                        title="{{ $name }}"
                                        style="display:flex; align-items:center; justify-content:center; aspect-ratio:1/1; border-radius:8px; cursor:pointer; {{ $icon === $name ? 'background: rgb(var(--mt-primary) / 0.15);' : '' }}"
                                        onmouseover="this.style.background='rgb(var(--mt-ui-card-border))'"
                                        onmouseout="this.style.background='{{ $icon === $name ? 'rgb(var(--mt-primary) / 0.15)' : 'transparent' }}'">
                                    <x-mt::icon name="{{ $name }}" class="size-5" />
                                </button>
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1" />
    @endif
</div>
