@props([
    'label'    => null,
    'model'    => null,
    'options'  => [],
    'error'    => null,
    'help'     => null,
    'required' => false,
    'multiple' => false,
    'live'     => false,
    'columns'  => 2,
])

{{--
    Sélecteur à cartes - mono-choix (radio) ou multi-choix (checkbox via :multiple).
    Bindé par wire:model (ajouter :live pour une mise à jour immédiate).
    Options simples [value => 'Label'] ou riches
    [value => ['title'=>…, 'badge'=>…, 'meta'=>… (ou 'description'), 'icon'=>…, 'image'=>url,
     'disabled'=>bool]].
    'image' (vignette) prime sur 'icon' quand fournie (ex. plats, types de chambre avec photo).

    <x-mt::form.card-select model="form.cycle_id" :options="$cycles" :live="true" />
    <x-mt::form.card-select model="form.langues" :options="$langues" :multiple="true" />
--}}

@php
    $gridCols = match ((int) $columns) {
        1       => 'sm:grid-cols-1',
        3       => 'sm:grid-cols-3',
        4       => 'sm:grid-cols-2 lg:grid-cols-4',
        default => 'sm:grid-cols-2',
    };
@endphp

<div class="w-full">
    @if($label)
        <x-mt::form.label :value="$label" :required="$required" />
    @endif

    {{-- Styles de sélection (sélecteur natif :checked - indépendant de Tailwind) --}}
    @once
        <style>
            .mt-cardsel-card {
                border: 2px solid rgb(var(--mt-ui-card-border));
                transition: border-color .15s, background-color .15s;
            }
            .mt-cardsel-card.is-error { border-color: rgba(var(--mt-danger), .5); }
            .mt-cardsel-input:checked + .mt-cardsel-card {
                border-color: rgb(var(--mt-primary));
                background: rgba(var(--mt-primary), .06);
            }
            .mt-cardsel-icon { color: rgb(var(--mt-ui-muted)); }
            .mt-cardsel-input:checked + .mt-cardsel-card .mt-cardsel-icon {
                color: rgb(var(--mt-primary)) !important;
            }
            .mt-cardsel-input:focus-visible + .mt-cardsel-card {
                outline: 2px solid rgba(var(--mt-primary), .4);
                outline-offset: 2px;
            }
            .mt-cardsel-input:disabled + .mt-cardsel-card { opacity: .5; cursor: not-allowed; }
        </style>
    @endonce

    <div {{ $attributes->merge(['class' => "grid grid-cols-1 gap-3 {$gridCols}"]) }}>
        @foreach($options as $value => $option)
            @php
                $isArr    = is_array($option);
                $title    = $isArr ? ($option['title'] ?? $value) : $option;
                $badge    = $isArr ? ($option['badge'] ?? null) : null;
                $meta     = $isArr ? ($option['meta'] ?? ($option['description'] ?? null)) : null;
                $icon     = $isArr ? ($option['icon'] ?? null) : null;
                $image    = $isArr ? ($option['image'] ?? null) : null;
                $disabled = $isArr ? ($option['disabled'] ?? false) : false;
            @endphp

            <label @class(['block', 'cursor-pointer' => !$disabled])>
                <input
                    type="{{ $multiple ? 'checkbox' : 'radio' }}"
                    @if($model) wire:model{{ $live ? '.live' : '' }}="{{ $model }}" @endif
                    value="{{ $value }}"
                    @disabled($disabled)
                    class="sr-only mt-cardsel-input"
                />

                <div @class(['mt-cardsel-card h-full p-4 rounded-xl', 'is-error' => $error])>
                    <div class="flex items-start justify-between gap-2">
                        <div class="flex items-center min-w-0 gap-2">
                            @if($image)
                                {{-- Vignette (photo de l'option) : prime sur l'icône. `onerror`
                                     masque l'img si l'URL casse (pas de carré cassé). --}}
                                <img src="{{ $image }}" alt="{{ strip_tags($title) }}"
                                     class="shrink-0 rounded-lg object-cover"
                                     style="width:2.5rem;height:2.5rem"
                                     onerror="this.style.display='none'" />
                            @elseif($icon)
                                {{-- Icône = SVG INLINE (x-mt::icon), jamais le mask CSS mt-icon-*
                                     (qui rend des carrés de couleur pour toute icône absente du
                                     sprite compilé). Couleur pilotée par `color` : muted → primary
                                     quand la carte est cochée (cf. .mt-cardsel-icon plus haut). --}}
                                <span class="shrink-0 mt-cardsel-icon" style="display:inline-flex;line-height:0">
                                    <x-mt::icon :name="$icon" size="sm" />
                                </span>
                            @endif
                            <span class="font-semibold truncate mt-text">{{ $title }}</span>
                        </div>
                        @if($badge)
                            <span class="text-xs font-mono px-1.5 py-0.5 rounded shrink-0"
                                  style="background:rgba(var(--mt-ui-card-border),0.8); color:rgb(var(--mt-ui-muted))">{{ $badge }}</span>
                        @endif
                    </div>

                    @if($meta)
                        <div class="mt-1 text-xs mt-text-muted">{{ $meta }}</div>
                    @endif
                </div>
            </label>
        @endforeach
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-2" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-2" />
    @endif
</div>
