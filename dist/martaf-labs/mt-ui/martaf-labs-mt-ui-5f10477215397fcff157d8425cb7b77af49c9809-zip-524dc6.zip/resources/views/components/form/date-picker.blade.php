@props([
    'label' => null,
    'type'  => 'date',
    'model' => null,
    'icon'  => null,
    'error' => null,
    'help'  => null,
    'required' => false,
    'live' => false, // true → @entangle().live : la date déclenche un round-trip immédiat (ex. dispo)
])

<div class="w-full" x-data="{ value: @if ($model) @entangle($model)@if($live).live @endif @else null @endif, isFocused: false }">
    @if($label)
        <x-mt::form.label :value="$label" :required="$required" />
    @endif

    <div class="relative group">
        <div class="absolute inset-y-0 left-0 flex items-center pl-4 transition-colors duration-200 pointer-events-none"
             :class="isFocused ? 'mt-text-primary' : 'mt-text-muted'">
            @php $dpIcon = $icon ?: ($type === 'time' ? 'clock' : 'calendar'); @endphp
            <x-mt::icon :name="$dpIcon" size="sm" />
        </div>

        <input
            type="{{ $type }}"
            x-model="value"
            @focus="isFocused = true"
            @blur="isFocused = false"
            {{ $attributes->merge([
                'class' => 'mt-input ' . ($error ? 'mt-input-error' : '')
            ]) }}
            {{-- color-scheme géré globalement (theme-vars) : suit le thème light/dark. --}}
            style="padding-left: 2.75rem;"
        >

        <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none mt-text-muted">
            <x-mt::icon name="chevron-down" size="xs" />
        </div>
    </div>

    @if($error)
        <x-mt::form.feedback type="error" variant="inline" :message="$error" class="mt-1.5" />
    @elseif($help)
        <x-mt::form.feedback type="help" variant="inline" :message="$help" class="mt-1.5" />
    @endif
</div>

<style>
    input[type="date"]::-webkit-calendar-picker-indicator,
    input[type="datetime-local"]::-webkit-calendar-picker-indicator {
        background: transparent;
        bottom: 0; color: transparent; cursor: pointer;
        height: auto; left: 0; position: absolute;
        right: 0; top: 0; width: auto;
    }
</style>
