@props([
    'datas' => collect([])
])

<div class="relative group"
    x-data="{
        activeImage: 0,
        imagesCount: {{ $datas->count() }}
    }">

    {{-- Image principale --}}
    <div class="aspect-[4/3] overflow-hidden relative rounded-3xl mt-bg-secondary">
        @forelse($datas as $index => $image)
            <x-mt::image-loader
                x-show="activeImage === {{ $index }}"
                x-transition:enter="transition opacity-0 duration-500"
                x-transition:enter-end="opacity-100"
                src="{{ $image->imageUrl }}"
                class="object-cover w-full h-full"
                alt="Image {{ $index }}"
            />
        @empty
            <div class="flex flex-col items-center justify-center w-full h-full mt-text-muted">
                <span class="mb-4"><x-mt::icon name="image" size="2xl" /></span>
                <p>Aucun visuel disponible</p>
            </div>
        @endforelse

        @if($datas->count() > 1)
            {{-- Bouton précédent --}}
            <button @click="activeImage = (activeImage === 0) ? imagesCount - 1 : activeImage - 1"
                    class="absolute p-2 transition -translate-y-1/2 rounded-full left-4 top-1/2 backdrop-blur-sm"
                    style="background: rgba(0,0,0,0.3); color: #fff"
                    onmouseover="this.style.background='rgb(var(--mt-bg))'; this.style.color='rgb(var(--mt-text))'"
                    onmouseout="this.style.background='rgba(0,0,0,0.3)'; this.style.color='#fff'" >
                <x-mt::icon name="chevron-left" />
            </button>
            {{-- Bouton suivant --}}
            <button @click="activeImage = (activeImage + 1) % imagesCount"
                    class="absolute p-2 transition -translate-y-1/2 rounded-full right-4 top-1/2 backdrop-blur-sm"
                    style="background: rgba(0,0,0,0.3); color: #fff"
                    onmouseover="this.style.background='rgb(var(--mt-bg))'; this.style.color='rgb(var(--mt-text))'"
                    onmouseout="this.style.background='rgba(0,0,0,0.3)'; this.style.color='#fff'">
                <x-mt::icon name="chevron-right" />
            </button>
        @endif
    </div>

    {{-- Miniatures --}}
    <div class="flex gap-3 px-1 py-2 mt-4 overflow-x-auto" x-show="imagesCount > 1">
        @foreach($datas as $index => $image)
            <button @click="activeImage = {{ $index }}"
                    :class="activeImage === {{ $index }} ? 'scale-105' : 'opacity-60 hover:opacity-100'"
                    :style="activeImage === {{ $index }} ? 'box-shadow: 0 0 0 2px rgb(var(--mt-primary))' : ''"
                    class="flex-shrink-0 overflow-hidden transition duration-300 w-14 h-14 rounded-xl">
                <x-mt::image-loader src="{{ $image->imageUrl }}" class="object-cover w-full h-full"/>
            </button>
        @endforeach
    </div>

</div>
