{{-- Vite (CSS + JS app) --}}
@if (file_exists(public_path('build/manifest.json')))
    @php $manifest = json_decode(file_get_contents(public_path('build/manifest.json')), true); @endphp
    @if(isset($manifest['resources/css/app.css']))
        <link rel="stylesheet" href="{{ asset('build/' . $manifest['resources/css/app.css']['file']) }}">
    @endif
    @if(isset($manifest['resources/js/app.js']))
        <script type="module" src="{{ asset('build/' . $manifest['resources/js/app.js']['file']) }}"></script>
    @endif
@else
    @vite(['resources/css/app.css', 'resources/js/app.js'])
@endif

{{-- FontAwesome kit (FA7) — configurable ; vider `assets.fontawesome_kit_url` pour le désactiver
     (ex. en local : le kit externe empêche le "network idle" des outils de recette). --}}
@php $faKitUrl = mt_config('assets.fontawesome_kit_url', 'https://kit.fontawesome.com/7b5c5ebcb4.js'); @endphp
@if ($faKitUrl)
<script src="{{ $faKitUrl }}" crossorigin="anonymous"></script>
@endif

{{-- mt-ui CSS + JS --}}
@mtAssets

{{-- mt-icons CSS (mask-based SVG icons) --}}
@mtIcons

{{-- PWA (mt-pwa) — manifest + service worker + méta natif (installable/offline).
     Rendu UNIQUEMENT si le package mt-pwa est installé (neutre : @includeIf, pas de
     couplage dur → mt-ui reste utilisable sans mt-pwa). --}}
@includeIf('mt-pwa::components.pwa-meta')

@stack('styles')
