{{--
    ================= THEME VARS (PHP → CSS variables) =================
    Source unique des tokens de thème mt-ui. Inclus dans le <head> APRÈS
    @mtAssets (mt-ui.css) → surcharge les valeurs du CSS précompilé.

    Couches (cascade) : défauts config  <  charte d'app (config/.env)  <  theme_resolver (runtime/tenant).
    Toutes les valeurs viennent de mt_theme_colors() (config fusionnée au résolveur).
--}}
@php
    $themeColors = mt_theme_colors();

    /* Contrat de tokens : clé de config  =>  nom du token CSS (--mt-<token>) */
    $mtTokenMap = [
        'primary'         => 'primary',
        'primary_content' => 'primary-content',
        'secondary'       => 'secondary',
        'accent'          => 'accent',
        'bg'              => 'bg',
        'surface'         => 'ui-card-bg',
        'surface_border'  => 'ui-card-border',
        'input_bg'        => 'ui-input-bg',
        'input_border'    => 'ui-input-border',
        'text'            => 'text',
        'muted'           => 'muted',
        'danger'          => 'danger',
        'success'         => 'success',
        'warning'         => 'warning',
        'info'            => 'info',
    ];
@endphp
<style>
    :root {
        {{-- Valeurs brutes light & dark (triplets RGB pour rgb(var(--x) / alpha)) --}}
        @foreach ($mtTokenMap as $cfgKey => $token)
            @if (! empty($themeColors['light'][$cfgKey])) --mt-light-{{ $token }}: {{ hexaToRgb($themeColors['light'][$cfgKey]) }}; @endif
            @if (! empty($themeColors['dark'][$cfgKey])) --mt-dark-{{ $token }}: {{ hexaToRgb($themeColors['dark'][$cfgKey]) }}; @endif
        @endforeach

        {{-- Tokens sémantiques = variante light par défaut (surcharge le dist) --}}
        @foreach ($mtTokenMap as $cfgKey => $token)
            @if (! empty($themeColors['light'][$cfgKey])) --mt-{{ $token }}: var(--mt-light-{{ $token }}); @endif
        @endforeach

        --font-mt-heading: {!! hexaToRgb(mt_config('assets.font_heading')) !!};
        --font-mt-body:    {!! hexaToRgb(mt_config('assets.font_body')) !!};

        /* paddings */
        --xs-padding: 0.375rem 0.75rem;
        --sm-padding: 0.4rem 0.8rem;
        --md-padding: 0.425rem 1.25rem;
        --lg-padding: 0.75rem 1.5rem;
        --xl-padding: 1rem 2rem;
        --2xl-padding: 1.5rem;

        /* font-sizes */
        --xs-fs: 0.75rem;
        --sm-fs: 0.875rem;
        --md-fs: 1rem;
        --lg-fs: 1.125rem;
        --xl-fs: 1.25rem;
        --2xl-fs: 1.5rem;

        /* shadows */
        --mt-shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        --mt-shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        --mt-shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        --mt-shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        --mt-shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);

        --mt-animation-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
        --mt-animation-smooth: cubic-bezier(0.4, 0, 0.2, 1);

        /* ═══════════════ SYSTÈME DE DÉGRADÉS mt-ui ═══════════════
           Dérivés des TOKENS (primary/accent/success/…) → suivent automatiquement
           le thème (light/dark) ET la couleur du tenant. `color-mix` garantit un
           dégradé visible même quand accent == primary ; les classes utilitaires
           posent une couleur solide de repli AVANT le dégradé (navigateurs sans
           color-mix → fond plein propre, jamais transparent). */
        --mt-gradient-primary: linear-gradient(135deg,
            rgb(var(--mt-primary)) 0%,
            color-mix(in oklab, rgb(var(--mt-accent)) 78%, #000 22%) 100%);
        --mt-gradient-brand: linear-gradient(140deg,
            color-mix(in oklab, rgb(var(--mt-primary)) 82%, #fff 18%) 0%,
            rgb(var(--mt-primary)) 52%,
            color-mix(in oklab, rgb(var(--mt-accent)) 82%, #000 18%) 100%);
        --mt-gradient-accent:  linear-gradient(135deg, rgb(var(--mt-accent)) 0%, rgb(var(--mt-primary)) 100%);
        --mt-gradient-success: linear-gradient(135deg, rgb(var(--mt-success)) 0%, color-mix(in oklab, rgb(var(--mt-success)) 72%, #000 28%) 100%);
        --mt-gradient-danger:  linear-gradient(135deg, rgb(var(--mt-danger)) 0%,  color-mix(in oklab, rgb(var(--mt-danger)) 72%, #000 28%) 100%);
        --mt-gradient-warning: linear-gradient(135deg, rgb(var(--mt-warning)) 0%, color-mix(in oklab, rgb(var(--mt-warning)) 72%, #000 28%) 100%);
        --mt-gradient-info:    linear-gradient(135deg, rgb(var(--mt-info)) 0%,    color-mix(in oklab, rgb(var(--mt-info)) 72%, #000 28%) 100%);
        /* Voile de surface (cartes/hero) : très subtil, du fond de carte vers un ton plus profond. */
        --mt-gradient-surface: linear-gradient(180deg, rgb(var(--mt-ui-card-bg)) 0%, color-mix(in oklab, rgb(var(--mt-ui-card-bg)) 90%, #000 10%) 100%);
    }

    .dark {
        {{-- Bascule des tokens sémantiques vers la variante dark --}}
        @foreach ($mtTokenMap as $cfgKey => $token)
            @if (! empty($themeColors['dark'][$cfgKey])) --mt-{{ $token }}: var(--mt-dark-{{ $token }}); @endif
        @endforeach
    }

    /* Contrôles NATIFS (input date/datetime/time/month/week, select) : color-scheme suit
       le thème → l'icône native du sélecteur de calendrier (::-webkit-calendar-picker-indicator)
       et les popups natifs restent VISIBLES en dark (sinon icône noire sur fond sombre).
       Scopé aux champs mt → aucun effet de bord sur le reste de la page. */
    .mt-input, .mt-select { color-scheme: light; }
    :root.dark .mt-input, :root.dark .mt-select { color-scheme: dark; }

    /* ════════ FINITION MODERNE des champs de formulaire (2026-07-22) ════════
       Chargé APRÈS @mtAssets → surcharge le CSS servi (radius généreux, plus d'air,
       focus avec HALO primary + micro-élévation, placeholder/label soignés). Rétablit
       aussi la transition des champs (le CSS servi la coupe globalement avec !important). */
    .mt-input, .mt-select, .mt-textarea {
        border-radius: 0.9rem;
        padding: 0.72rem 1rem;
        font-size: 0.95rem;
        border-width: 1.5px;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
        transition: border-color .18s ease, box-shadow .2s ease, background-color .18s ease !important;
    }
    .mt-input:hover:not(:focus), .mt-select:hover:not(:focus), .mt-textarea:hover:not(:focus) {
        border-color: rgba(var(--mt-primary), 0.45);
    }
    .mt-input:focus, .mt-select:focus, .mt-textarea:focus {
        border-color: rgb(var(--mt-primary));
        background-color: color-mix(in oklab, rgb(var(--mt-ui-input-bg)) 90%, rgb(var(--mt-primary)) 10%);
        box-shadow: 0 0 0 4px rgba(var(--mt-primary), 0.14), 0 6px 18px -8px rgba(var(--mt-primary), 0.45);
    }
    .mt-input::placeholder, .mt-textarea::placeholder { color: rgba(var(--mt-text), 0.35); }
    .mt-input-error:focus, .mt-select-error:focus, .mt-textarea-error:focus {
        box-shadow: 0 0 0 4px rgba(var(--mt-danger), 0.14), 0 6px 18px -8px rgba(var(--mt-danger), 0.4);
    }
    .mt-input-sm, .mt-select-sm { border-radius: 0.7rem; padding: 0.5rem 0.85rem; }
    .mt-input-lg, .mt-select-lg { border-radius: 1rem;   padding: 0.85rem 1.1rem; }

    /* MOBILE : arrondi + épaisseur des champs légèrement réduits (rendu plus sobre sur petit écran). */
    @media (max-width: 1023px) {
        .mt-input, .mt-select, .mt-textarea { border-radius: 0.6rem; border-width: 1px; }
        .mt-input-sm, .mt-select-sm { border-radius: 0.5rem; }
        .mt-input-lg, .mt-select-lg { border-radius: 0.7rem; }
    }

    /* Label : plus présent (poids + graisse + espacement), en accord avec la nouvelle densité. */
    .mt-label { font-size: 0.82rem; font-weight: 600; letter-spacing: 0.01em; color: rgba(var(--mt-text), 0.85); margin-bottom: 0.45rem; }

    /* Boutons : MÊME rayon que l'artefact concept mobile (`.btn` = 11px ; large/bloc = 14px).
       Le CSS servi les met en --mt-radius-lg (trop arrondi) → on aligne ici. */
    .mt-btn { border-radius: 11px; }
    .mt-btn-xs { border-radius: 9px; }
    .mt-btn-sm { border-radius: 10px; }
    .mt-btn-lg, .mt-btn-xl { border-radius: 14px; }
    /* Padding VERTICAL des boutons légèrement augmenté (plus d'air, plus « touchable »).
       Seul le padding-block est surchargé → l'horizontal des `--*-padding` est conservé. */
    .mt-btn-xs { padding-block: 0.5rem; }
    .mt-btn-sm { padding-block: 0.55rem; }
    .mt-btn-md { padding-block: 0.6rem; }
    .mt-btn-lg { padding-block: 0.85rem; }
    .mt-btn-xl { padding-block: 1.1rem; }

    /* Pastilles de filtre / onglets MOBILE (base-index filtres, réception, etc.) — GÉNÉRIQUES.
       Rangée horizontale scrollable `.mob-fchips` + pastilles `.mob-fchip` (actif = primary plein). */
    .mob-fchips { display: flex; gap: .5rem; overflow-x: auto; scrollbar-width: none; }
    .mob-fchips::-webkit-scrollbar { height: 0; }
    .mob-fchip {
        flex: 0 0 auto; border: 1px solid rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg));
        color: rgb(var(--mt-text) / .6); border-radius: 999px; padding: .45rem .9rem; font-size: .8rem;
        font-weight: 600; white-space: nowrap; cursor: pointer; -webkit-tap-highlight-color: transparent;
        transition: background .15s, color .15s, border-color .15s;
    }
    .mob-fchip.on { background: rgb(var(--mt-primary)); border-color: rgb(var(--mt-primary)); color: rgb(var(--mt-primary-content)); }
    /* Compteur optionnel intégré à une pastille (`… <span class="mob-fchip-n">3</span>`). */
    .mob-fchip-n {
        display: inline-block; margin-inline-start: .35rem; min-width: 1.15rem; padding: 0 .35rem;
        border-radius: 999px; background: rgb(var(--mt-text) / .1); color: inherit;
        font-size: .72rem; font-weight: 700; text-align: center; line-height: 1.3rem;
    }
    .mob-fchip.on .mob-fchip-n { background: rgb(var(--mt-primary-content) / .22); }
    /* Séparateur vertical entre deux groupes de pastilles sur la même ligne scrollable. */
    /* Séparateur « · » entre deux éléments d'une rangée scrollable (ligne 2 des cartes, groupes de filtres). */
    .mob-fchip-sep { flex: 0 0 auto; align-self: center; color: rgb(var(--mt-text) / .4); font-size: 1.15rem; line-height: 1; font-weight: 700; user-select: none; }
    /* Zébrage des cartes base-index mobile. Réduire l'opacité de card-bg le fait converger vers le fond
       de page (invisible sur thème sombre où card-bg ≈ bg) → on alterne deux TEINTES distinctes : la
       surface de base et la même légèrement éclaircie (mix vers le texte). Repli = card-bg plein. */
    .mob-zebra-a {
        background: rgb(var(--mt-ui-card-bg));
        background: color-mix(in oklab, rgb(var(--mt-ui-card-bg)), rgb(var(--mt-text)) -10%);
    }
    .mob-zebra-b { background: rgb(var(--mt-ui-card-bg)); }
    /* Conteneur PLAT (sans fond ni bordure) : ses enfants (cartes/rangées zébrées) reposent sur le
       fond de PAGE → le zébrage redevient visible (sinon une section card-bg avale mob-zebra-b). */
    .mob-flat-panel { background: transparent; border: 0; padding: 0; }
    /* Carte pleine (fond + bordure + rayon) en DESKTOP, TRANSPARENTE en MOBILE (contenu à même le
       fond de page, façon app concept). Une bordure/accent en style inline (ex. border-left coloré
       d'un KPI) reste visible car l'inline prime. */
    .mob-flat-card { border: 1px solid rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg)); border-radius: 1rem; }
    @media (max-width: 1023px) { .mob-flat-card { background: transparent; } }
    /* Barre d'action COLLANTE en bas sur MOBILE pour écrans bespoke (ex. total + CTA d'un formulaire).
       Statique en desktop. Colle au-dessus de la barre de nav (main porte un padding-bottom = hauteur nav). */
    .mob-actionbar { display: flex; align-items: center; gap: .75rem; }
    @media (max-width: 1023px) {
        .mob-actionbar {
            position: sticky; bottom: 0; z-index: 20;
            margin: .75rem 0 0; padding: .75rem 0 calc(.75rem + env(safe-area-inset-bottom, 0px));
            background: rgb(var(--mt-bg)); border-top: 1px solid rgb(var(--mt-ui-card-border));
            box-shadow: 0 -6px 16px -10px rgba(0,0,0,.35);
        }
    }
    /* Pastille MÉTA (non cliquable) — 2e ligne scrollable des cartes base-index mobile
       (« label valeur » : prix, capacité, compteurs…). GÉNÉRIQUE. */
    .mob-metapill {
        flex: 0 0 auto; display: inline-flex; align-items: baseline; gap: .3rem; white-space: nowrap;
        border: 1px solid rgb(var(--mt-ui-card-border)); background: rgb(var(--mt-ui-card-bg));
        border-radius: 999px; padding: .3rem .7rem; font-size: .78rem; font-weight: 600; color: rgb(var(--mt-text));
    }
    .mob-metapill-k { color: rgb(var(--mt-text) / .5); font-weight: 500; }

    /* ════════ Utilitaires de dégradé mt-ui (repli couleur solide d'abord) ════════
       Usage : <span class="mt-gradient-brand">…</span> (vignettes, hero, FAB, badges).
       `mt-gradient-text` = titre/nombre en dégradé (clip sur le texte). */
    .mt-gradient-primary { background-color: rgb(var(--mt-primary)); background-image: var(--mt-gradient-primary); }
    .mt-gradient-brand   { background-color: rgb(var(--mt-primary)); background-image: var(--mt-gradient-brand); }
    .mt-gradient-accent  { background-color: rgb(var(--mt-accent));  background-image: var(--mt-gradient-accent); }
    .mt-gradient-success { background-color: rgb(var(--mt-success)); background-image: var(--mt-gradient-success); }
    .mt-gradient-danger  { background-color: rgb(var(--mt-danger));  background-image: var(--mt-gradient-danger); }
    .mt-gradient-warning { background-color: rgb(var(--mt-warning)); background-image: var(--mt-gradient-warning); }
    .mt-gradient-info    { background-color: rgb(var(--mt-info));    background-image: var(--mt-gradient-info); }
    .mt-gradient-surface { background-color: rgb(var(--mt-ui-card-bg)); background-image: var(--mt-gradient-surface); }
    .mt-gradient-text {
        background-image: var(--mt-gradient-primary);
        -webkit-background-clip: text; background-clip: text;
        -webkit-text-fill-color: transparent; color: transparent;
    }

    /* ============================================================================
       UTILITAIRES DE GRILLE absents du CSS précompilé mt-ui.
       Le build servi ne contient que .grid-cols-1/2/4 et AUCUNE variante responsive
       (sm:/md:/lg:/xl:grid-cols-*) → toute grille en grid-cols-3 ou en colonnes
       responsives s'effondrait en une seule colonne empilée (cf. North Star §0.4,
       "piège CSS servi"). On les réinjecte ICI (chargé APRÈS @mtAssets, règles non
       layerées → priorité garantie) pour que les grilles standard fonctionnent partout,
       sur toutes les vues actuelles ET futures, sans hack flex-wrap par écran.
       ============================================================================ */
    .grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    .grid-cols-5 { grid-template-columns: repeat(5, minmax(0, 1fr)); }
    .grid-cols-6 { grid-template-columns: repeat(6, minmax(0, 1fr)); }

    @media (min-width: 40rem) { /* sm */
        .sm\:grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
        .sm\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .sm\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .sm\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        .sm\:grid-cols-\[7rem_1fr_auto\] { grid-template-columns: 7rem 1fr auto; }
    }
    @media (min-width: 48rem) { /* md */
        .md\:grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
        .md\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .md\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .md\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        .md\:grid-cols-6 { grid-template-columns: repeat(6, minmax(0, 1fr)); }
        .md\:grid-cols-\[20rem_1fr\] { grid-template-columns: 20rem 1fr; }
        /* Spans de la grille interne des formulaires (base-form, grille 6 colonnes) */
        .md\:col-span-1 { grid-column: span 1 / span 1; }
        .md\:col-span-2 { grid-column: span 2 / span 2; }
        .md\:col-span-3 { grid-column: span 3 / span 3; }
        .md\:col-span-4 { grid-column: span 4 / span 4; }
        .md\:col-span-5 { grid-column: span 5 / span 5; }
        .md\:col-span-6 { grid-column: span 6 / span 6; }
    }
    @media (min-width: 64rem) { /* lg */
        .lg\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .lg\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .lg\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        /* Layout externe de base-form (colonne principale + colonne fichiers) */
        .lg\:col-span-1 { grid-column: span 1 / span 1; }
        .lg\:col-span-2 { grid-column: span 2 / span 2; }
        .lg\:col-span-3 { grid-column: span 3 / span 3; }
        .lg\:col-span-4 { grid-column: span 4 / span 4; }
        .lg\:w-2\/3 { width: 66.666667%; }
        .lg\:w-1\/3 { width: 33.333333%; }
    }
    @media (min-width: 80rem) { /* xl */
        .xl\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .xl\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .xl\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    }
</style>
