<div class="relative mb-6 w-full">
    <h1 class="text-2xl font-bold mt-text">{{ __('Settings') }}</h1>
    <p class="mb-6 text-base mt-text-muted">{{ __('Manage your profile and account settings') }}</p>
    <hr style="border-color: rgba(var(--mt-ui-card-border), 0.6)" />
</div>
