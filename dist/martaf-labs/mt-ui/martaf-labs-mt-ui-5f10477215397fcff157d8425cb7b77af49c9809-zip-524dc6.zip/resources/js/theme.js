// theme.js - corrigé
// document.addEventListener('alpine:init', () => {
//     Alpine.data('themeManager', () => ({
//         darkMode: false,

//         init() {
//             const stored = localStorage.getItem('theme');

//             this.darkMode = stored === 'dark' || (
//                 !stored &&
//                 window.matchMedia('(prefers-color-scheme: dark)').matches
//             );

//             // Appliquer immédiatement au démarrage
//             document.documentElement.setAttribute(
//                 'data-theme',
//                 this.darkMode ? 'dark' : 'light'
//             );
//             // compatibilité avec tailwindcss
//             document.documentElement.classList.toggle(
//                 'dark', this.darkMode
//             );

//             this.$watch('darkMode', (val) => {
//                 const theme = val ? 'dark' : 'light';
//                 localStorage.setItem('theme', theme);
//                 document.documentElement.setAttribute('data-theme', theme);
//                 document.documentElement.classList.toggle('dark', val); //pour compatibilité avec tailwind css
//             });

//             window.matchMedia('(prefers-color-scheme: dark)')
//                 .addEventListener('change', e => {
//                     if (!localStorage.getItem('theme')) {
//                         this.darkMode = e.matches;
//                     }
//                 });
//         }
//     }));
// });