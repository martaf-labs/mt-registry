<?php

use Illuminate\Support\Facades\Route;
use Mt\MtUi\Http\Controllers\ImageUploadController;
use Illuminate\Http\Request;

/**
 * Route GET pour changer la locale sans Livewire.
 * Utilisée par le composant Blade anonyme <x-mt-ui::locale-switcher />.
 *
 * Enregistrement dans MtUiServiceProvider::boot() :
 *   $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
 */
// Route::get('/mt/locale/{locale}', function (Request $request, string $locale) {
//     MtLocale::set($locale);

//     $redirect = $request->query('redirect', url()->previous('/'));

//     // Sécurité : on ne redirige que vers des URLs internes
//     if (! str_starts_with($redirect, config('app.url'))) {
//         $redirect = '/';
//     }

//     return redirect($redirect);
// })
// ->name('mt.locale.switch')
// ->middleware('web');

// Galerie d'icônes : c'est mt-icons qui la possède (Livewire IconPreview, route
// mt-icons.preview). L'ancienne implémentation locale lisait un dossier
// resources/views/icons et une vue mt::icons.index qui N'EXISTENT PAS → 500.
Route::get('/mt-icons', function () {
    abort_unless(\Illuminate\Support\Facades\Route::has('mt-icons.preview'), 404);
    return redirect()->route('mt-icons.preview');
});

Route::get('/mt-docs', function () {
    return view('mt::docs.index');
});

// route upload image de tinymce
// Route::post('/admin/upload-image', [ImageUploadController::class, 'upload'])->name('image.upload');
Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    Route::post('upload-image', [ImageUploadController::class, 'upload'])->name('image.upload');
});


// Route::middleware(['auth'])->group(function () {
//     Route::redirect('settings', 'settings/profile');

//     Route::get('settings/profile', Profile::class)->name('settings.profile');
//     Route::get('settings/password', Password::class)->name('settings.password');
//     Route::get('settings/appearance', Appearance::class)->name('settings.appearance');

//     Route::get('settings/two-factor', TwoFactor::class)
//         ->middleware(
//             when(
//                 Features::canManageTwoFactorAuthentication()
//                     && Features::optionEnabled(Features::twoFactorAuthentication(), 'confirmPassword'),
//                 ['password.confirm'],
//                 [],
//             ),
//         )
//         ->name('two-factor.show');
// });

// Route::middleware(['auth', 'verified'])->group(function () {
//     Route::get('dashboard', \Mt\MtUi\Livewire\MtDashboard::class)->name('dashboard');
// });

require __DIR__.'/auth.php';