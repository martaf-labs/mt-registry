<?php

use Mt\MtUi\Livewire\Auth\Login;
use Illuminate\Support\Facades\Route;
use Mt\MtUi\Livewire\Auth\Register;
use Mt\MtUi\Livewire\Actions\Logout;
use Mt\MtUi\Livewire\Auth\VerifyEmail;
use Mt\MtUi\Livewire\Auth\ResetPassword;
use Mt\MtUi\Livewire\Auth\ForgotPassword;
use Mt\MtAuth\Http\Controllers\Auth\VerifyEmailController;

Route::middleware('guest')->group(function () {
    Route::get('login', Login::class)->name('login');
    Route::get('register', Register::class)->name('register');
    Route::get('forgot-password', ForgotPassword::class)->name('password.request');
    Route::get('reset-password/{token}', ResetPassword::class)->name('password.reset');
});

Route::middleware('auth')->group(function () {
    Route::get('verify-email', VerifyEmail::class)
        ->name('verification.notice');

    Route::get('verify-email/{id}/{hash}', VerifyEmailController::class)
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');
});

Route::post('logout', Logout::class)
    ->name('logout');