<?php

namespace Mt\MtUi\Helpers;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Route;

class NavHelper
{
    protected string $model;
    protected string $mainLabel;
    protected array $navItems = [];

    public function __construct(string $model, string $mainLabel)
    {
        $this->model = $model;
        $this->mainLabel = ucfirst($mainLabel);

        // Lien du 1er item (la liste du module) : résolution par CLÉS LOGIQUES de
        // config/routes.php — '<plural>_index' puis '<plural>' — avec repli sur
        // l'ancienne convention de nom de route 'admin.<plural>.index'.
        // (L'ancienne logique ne testait QUE cette convention → fil d'Ariane mort
        // ('#') dans les apps qui nomment leurs routes autrement.)
        $plural = Str::plural($model);
        $lien = mt_get_route($plural . '_index') ?: mt_get_route($plural);
        if ($lien === '' && Route::has('admin.' . $plural . '.index')) {
            $lien = route('admin.' . $plural . '.index');
        }

        $this->navItems['index'] = [
            'label' => ucfirst($mainLabel),
            'icone' => mt_get_icon($model),
            'lien'  => $lien !== '' ? $lien : '#',
        ];
    }

    public function add(string $label, string $route): self
    {
        $cle=Str::random(5);
        $this->navItems[$cle] = [
            'label' => $label,
            'lien' => $route,
        ];
        return $this;
    }

    public function get(): array
    {
        return $this->navItems;
    }
}
