<?php

namespace Src\Helpers;

use Exception;
use Illuminate\Support\Str;

class ModuleHelper
{
    protected string $module;
    protected string $moduleSingular;
    protected string $modulePlural;
    protected array $moduleConfig;

    public function __construct(string $module)
    {
        $this->module = $module;
        $this->moduleSingular = Str::lower($module);
        $this->modulePlural = Str::plural($this->moduleSingular);
        $this->moduleConfig = $this->getModuleConfig();
    }

    /**
     * Factory method pour une utilisation statique
     */
    public static function for(string $module): self
    {
        return new self($module);
    }

    /**
     * Get form view parameters for create/edit operations
     */
    public function getFormViewParams($data = null): array
    {
        $isEdit = !is_null($data);

        $baseParams = [
            'moduleName' => $this->moduleConfig['name'],
            'moduleIcon' => $this->moduleConfig['icon'] ?? ($isEdit ? 'bi-pencil-square' : 'bi-plus'),
            'indexRoute' => mt_get_route($this->modulePlural),
            'createRoute' => mt_get_route($this->modulePlural.'_create'),
        ];

        if ($isEdit) {
            return array_merge($baseParams, [
                'livewireComponent' => $this->moduleConfig['edit'],
                'data' => $data,
                'mode' => 'edit'
            ]);
        }

        return array_merge($baseParams, [
            'livewireComponent' => $this->moduleConfig['create'],
            'mode' => 'create'
        ]);
    }

    /**
     * Get index view parameters
     */
    public function getIndexViewParams(): array
    {
        return [
            'livewireComponent' => $this->moduleConfig['index'],
            'moduleName' => $this->moduleConfig['plural'],
            'moduleIcon' => $this->moduleConfig['icon'],
        ];
    }

    /**
     * Generate module routes
     */
    public function moduleRoute(string $action = 'index', array $params = []): string
    {
        $routes = [
            'index' => mt_get_route($this->modulePlural),
            'create' => mt_get_route($this->modulePlural.'_create'),
            'edit' => mt_get_route($this->modulePlural.'_edit'),
            'store' => mt_get_route($this->modulePlural.'_store'),
            'update' => mt_get_route($this->modulePlural.'_update'),
            'destroy' => mt_get_route($this->modulePlural.'_destroy'),
        ];

        return route($routes[$action] ?? $routes['index'], $params);
    }

    /**
     * Generate breadcrumbs for modules
     */
    public function moduleBreadcrumbs(string $action = 'index', ?string $itemName = null): array
    {
        $breadcrumbs = [
            ['label' => 'Dashboard', 'url' => route('dashboard'), 'icon' => 'bi-house'],
        ];

        $actions = [
            'index' => [
                ['label' => $this->moduleConfig['plural'], 'url' => $this->moduleRoute(), 'icon' => $this->moduleConfig['icon'], 'active' => true]
            ],
            'create' => [
                ['label' => $this->moduleConfig['plural'], 'url' => $this->moduleRoute(), 'icon' => $this->moduleConfig['icon']],
                ['label' => __('mt-ui::mt-ui.create'), 'url' => $this->moduleRoute('create'), 'icon' => 'bi-plus-circle', 'active' => true]
            ],
            'edit' => [
                ['label' => $this->moduleConfig['plural'], 'url' => $this->moduleRoute(), 'icon' => $this->moduleConfig['icon']],
                ['label' => __('mt-ui::mt-ui.edit') . ' ' . ($itemName ?: ''), 'url' => '#', 'icon' => 'bi-pencil-square', 'active' => true]
            ],
        ];

        return array_merge($breadcrumbs, $actions[$action] ?? $actions['index']);
    }

    /**
     * Get module configuration
     */
    protected function getModuleConfig(): array
    {
        $config = [
            'engins' => $this->createModuleConfig('engin'),
            'users' => $this->createModuleConfig('user'),
            'products' => $this->createModuleConfig('product'),
            'categories' => $this->createModuleConfig('category'),
            // Ajoutez d'autres modules ici
        ];

        if (!isset($config[$this->module])) {
            throw new Exception("Module {$this->module} non configuré");
        }

        return $config[$this->module];
    }

    /**
     * Create standardized module configuration
     */
    protected function createModuleConfig(string $singular): array
    {
        $plural = Str::plural($singular);

        return [
            // 'create' => "admin.{$plural}.{$plural}-form",
            'create' => "admin.{$plural}.{$plural}-form",
            'edit' => "admin.{$plural}.{$plural}-form", 
            'index' => "admin.{$plural}.{$plural}-index",
            'name' => Str::ucfirst($singular),
            'plural' => Str::ucfirst($plural),
            'icon' => mt_get_icon($singular),
        ];
    }

    /**
     * Méthodes statiques pour la rétrocompatibilité
     */
    public static function getFormViewParamsStatic(string $module, $data = null): array
    {
        return self::for($module)->getFormViewParams($data);
    }

    public static function getIndexViewParamsStatic(string $module): array
    {
        return self::for($module)->getIndexViewParams();
    }

    public static function moduleRouteStatic(string $module, string $action = 'index', array $params = []): string
    {
        return self::for($module)->moduleRoute($action, $params);
    }

    public static function moduleBreadcrumbsStatic(string $module, string $action = 'index', ?string $itemName = null): array
    {
        return self::for($module)->moduleBreadcrumbs($action, $itemName);
    }
}