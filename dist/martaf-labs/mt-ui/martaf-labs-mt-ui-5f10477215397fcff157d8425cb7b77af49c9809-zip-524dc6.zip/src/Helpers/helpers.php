<?php

use Illuminate\Support\Str;
use Mt\MtFoundation\Helpers\MtLocale;
use Mt\MtUi\Helpers\NavHelper;
use Mt\MtUi\Helpers\ViewHelper;
use Mt\MtUi\Notifications\HandleNotification;
use Mt\MtUi\Services\ModalService;

/**
 * Récupérer un élément de configuration de "mt-ui"
 */
if (!function_exists('mt_config')) {
    function mt_config(string $key) {
        return config("mt-ui.$key");
    }
}

/**
 * Nom de marque affiché (sidebar, etc.).
 *
 * Point d'extension OPTIONNEL : si le projet hôte déclare un résolveur via
 * `config('mt-ui.brand_resolver')` (classe avec `name(): ?string`), il prime.
 * Sinon repli sur `mt-ui.app_name`. Ex. mt-school renvoie le sigle de l'école.
 */
if (!function_exists('mt_brand_name')) {
    function mt_brand_name(): string {
        $resolver = config('mt-ui.brand_resolver');
        if ($resolver && class_exists($resolver)) {
            $name = app($resolver)->name();
            if (! empty($name)) return $name;
        }
        return (string) (mt_config('app_name') ?? config('app.name', ''));
    }
}

/**
 * URL du logo de marque, ou null. Même mécanisme que mt_brand_name().
 */
if (!function_exists('mt_brand_logo')) {
    function mt_brand_logo(): ?string {
        $resolver = config('mt-ui.brand_resolver');
        if ($resolver && class_exists($resolver)) {
            return app($resolver)->logoUrl();
        }
        return null;
    }
}

/**
 * Notifications de l'utilisateur pour la cloche de la topbar.
 *
 * Point d'extension OPTIONNEL : si le projet hôte déclare un résolveur via
 * `config('mt-ui.notifications_resolver')` (classe avec `count(): int`,
 * `url(): ?string`, et optionnellement `recent(): array`), la cloche affiche
 * le vrai compteur + les derniers items. Sinon → cloche inactive.
 *
 * @return array{enabled: bool, count: int, url: ?string, recent: array}
 */
if (!function_exists('mt_notifications')) {
    function mt_notifications(): array {
        $resolver = config('mt-ui.notifications_resolver');
        if ($resolver && class_exists($resolver)) {
            $r = app($resolver);
            return [
                'enabled' => true,
                'count'   => (int) $r->count(),
                'url'     => method_exists($r, 'url') ? $r->url() : null,
                'recent'  => method_exists($r, 'recent') ? (array) $r->recent() : [],
            ];
        }
        return ['enabled' => false, 'count' => 0, 'url' => null, 'recent' => []];
    }
}

/**
 * Récupérer le tableau des langues configurées
 */
if (!function_exists('get_available_locales')) {
    function get_available_locales() {
        return MtLocale::available();
    }
}

/**
 * Raccourci de traduction pour le namespace mt-ui
 */
if (!function_exists('mt_translate')) {
    function mt_translate(string $key) {
        return MtLocale::trans($key);
    }
}

/**
 * Layout actif (stocké en session)
 */
if (!function_exists('getActiveLayout')) {
    function getActiveLayout() {
        return session('active_layout');
    }
}

/**
 * Construire un ViewHelper pour la gestion des vues liste
 */
if (!function_exists('viewItems')) {
    function viewItems(string $model, string $mainLabel): ViewHelper {
        return new ViewHelper($model, $mainLabel);
    }
}

/**
 * Construire un NavHelper pour la gestion des items de navigation
 */
if (!function_exists('navItems')) {
    function navItems(string $model, string $mainLabel): NavHelper {
        return new NavHelper($model, $mainLabel);
    }
}

/**
 * Données de session du formulaire courant
 */
if (!function_exists('formSession')) {
    function formSession(string $model) {
        return session("formSessionData.{$model}") ?? null;
    }
}

/**
 * Construire la sidebar avec routes actives, icônes et compteurs
 */
if (!function_exists('mt_get_sidebar')) {
    function mt_get_sidebar(): array {
        $sideBarItems = config('sidebar');
        $currentUrl   = request()->fullUrl();
        $activeKey    = null;

        // Gating (optionnel) par MODULE et/ou PERMISSION : si le projet hôte déclare
        // un gate via `config('mt-ui.module_gate')` (classe `enabled(string $code): bool`)
        // et/ou `config('mt-ui.permission_gate')` (classe `allows(string $ability): bool`),
        // on masque les entrées/groupes dont la clé `module` est inactive OU dont la clé
        // `permission` n'est pas accordée à l'utilisateur. Sans gate (autres SaaS), rien n'est filtré.
        $gateClass = config('mt-ui.module_gate');
        $gate      = ($gateClass && class_exists($gateClass)) ? app($gateClass) : null;

        $permClass = config('mt-ui.permission_gate');
        $perm      = ($permClass && class_exists($permClass)) ? app($permClass) : null;

        if ($gate || $perm) {
            $entryOk = function ($entry) use ($gate, $perm) {
                if ($gate && ! empty($entry['module']) && ! $gate->enabled($entry['module'])) {
                    return false;
                }
                if ($perm && ! empty($entry['permission']) && ! $perm->allows($entry['permission'])) {
                    return false;
                }
                return true;
            };

            $sideBarItems = array_values(array_filter($sideBarItems, $entryOk));
            foreach ($sideBarItems as &$gItem) {
                if (! empty($gItem['subItems'])) {
                    $gItem['subItems'] = array_values(array_filter($gItem['subItems'], $entryOk));
                }
            }
            unset($gItem);
            // Retirer les groupes qui avaient des sous-items mais n'en ont plus.
            $sideBarItems = array_values(array_filter(
                $sideBarItems,
                fn ($entry) => ! array_key_exists('subItems', $entry) || ! empty($entry['subItems'])
            ));
        }

        // ── État actif : correspondance par CHEMIN d'URL, préfixe de segment autorisé
        // (une page enfant /finances/payments/student/5 marque l'item /finances/payments).
        // Le chemin correspondant LE PLUS LONG l'emporte (pas de double marquage entre
        // /academics et /academics/assessments). Clé optionnelle 'active' => ['clé_ou_/chemin', …]
        // sur un item/sous-item pour marquer aussi des écrans hors de son préfixe d'URL.
        $currentPath = trim(parse_url($currentUrl, PHP_URL_PATH) ?? '/', '/');
        $currentHost = parse_url($currentUrl, PHP_URL_HOST);

        // Score : -1 = pas de correspondance ; sinon longueur du chemin correspondant
        // (l'égalité exacte score +1 pour battre un préfixe de même base).
        $matchScore = function (?string $url) use ($currentPath, $currentHost): int {
            if (empty($url) || $url === '#') return -1;
            $host = parse_url($url, PHP_URL_HOST);
            if ($host && $currentHost && $host !== $currentHost) return -1;
            $path = trim(parse_url($url, PHP_URL_PATH) ?? '/', '/');
            if ($path === $currentPath) return strlen($path) + 1;
            if ($path !== '' && str_starts_with($currentPath, $path . '/')) return strlen($path);
            return -1;
        };
        $entryScore = function (array $entry) use ($matchScore): int {
            $score = $matchScore($entry['route'] ?? null);
            foreach ((array) ($entry['active'] ?? []) as $extra) {
                $url   = str_starts_with($extra, '/') ? $extra : mt_get_route($extra);
                $score = max($score, $matchScore($url));
            }
            return $score;
        };
        $best = -1;

        foreach ($sideBarItems as &$item) {
            $item['key']      = $item['key'] ?? Str::slug($item['label']);
            $item['icon']     = isset($item['icon'])  ? mt_get_icon($item['icon'])               : null;
            // Compteur : masqué quand il vaut 0 (un badge « 0 » est du bruit — les counts
            // servent d'indicateur « il y a quelque chose à voir »).
            $itemCount        = isset($item['count']) ? (int) resolve_count($item['count']) : 0;
            $item['count']    = $itemCount > 0 ? add_zero($itemCount) : null;
            $item['isActive'] = false;

            $itemParams = $item['params'] ?? [];
            foreach ($itemParams as $k => $v) {
                if (str_contains($v, '::')) $itemParams[$k] = constant($v);
            }

            if (isset($item['route'])) $item['route'] = mt_get_route($item['route'], $itemParams);

            $item['activeScore'] = $entryScore($item);
            $best = max($best, $item['activeScore']);

            if (!empty($item['subItems'])) {
                foreach ($item['subItems'] as &$sub) {
                    $sub['key']      = $sub['key'] ?? Str::slug($sub['label']);
                    $sub['icon']     = isset($sub['icon'])  ? mt_get_icon($sub['icon'])               : null;
                    $subCount        = isset($sub['count']) ? (int) resolve_count($sub['count']) : 0;
                    $sub['count']    = $subCount > 0 ? add_zero($subCount) : null;
                    $sub['isActive'] = false;

                    $subParams = $sub['params'] ?? [];
                    foreach ($subParams as $k => $v) {
                        if (str_contains($v, '::')) $subParams[$k] = constant($v);
                    }

                    if (isset($sub['route'])) $sub['route'] = mt_get_route($sub['route'], $subParams);

                    $sub['activeScore'] = $entryScore($sub);
                    $best = max($best, $sub['activeScore']);
                }
                unset($sub);
            }
        }
        unset($item);

        // Second passage : seules les correspondances au MEILLEUR score sont marquées ;
        // un groupe est actif (ouvert + surligné) si lui-même ou l'un de ses enfants l'est.
        if ($best >= 0) {
            foreach ($sideBarItems as &$item) {
                $item['isActive'] = $item['activeScore'] === $best;
                if ($item['isActive']) $activeKey = $item['key'];
                foreach ($item['subItems'] ?? [] as $i => $sub) {
                    if ($sub['activeScore'] === $best) {
                        $item['subItems'][$i]['isActive'] = true;
                        $item['isActive'] = true;
                        $activeKey        = $sub['key'];
                    }
                }
            }
            unset($item);
        }

        if ($activeKey) session(['active_sidebar_key' => $activeKey]);
        return $sideBarItems;
    }
}

/**
 * Build a CSS icon class from the mt-icons prefix.
 * e.g. mt_get_icon('home') → 'mt-icon-home'
 * The prefix is configured in config('mt-icons.css_prefix'), default 'mt-icon'.
 */
if (!function_exists('mt_get_icon')) {
    function mt_get_icon(string $name): string {
        $prefix = config('mt-icons.css_prefix', 'mt-icon');
        return $prefix . '-' . $name;
    }
}

/**
 * Normalise un nom d'icône vers un nom mt-icons : accepte un nom nu ('users'),
 * un masque CSS legacy ('mt-icon-list') ou une classe FontAwesome legacy
 * ('fa-solid fa-inbox'). Le rendu doit TOUJOURS passer par <x-mt::icon> (SVG inline).
 */
if (!function_exists('mt_icon_name')) {
    function mt_icon_name(?string $icon, string $fallback = 'list'): string {
        $name = trim((string) $icon);
        if ($name === '') {
            return $fallback;
        }
        if (str_contains($name, ' ')) {
            $name = trim(strrchr($name, ' '));
        }
        $name = preg_replace('/^(mt-icon-|fa-)/', '', $name);

        // Alias : noms courants sans équivalent direct dans le set mt-icons.
        return ['inbox' => 'inbox-stack'][$name] ?? $name;
    }
}

/**
 * Couleurs de thème effectives : la charte de config (statique, par app) fusionnée
 * avec les surcharges du theme_resolver (runtime, ex. marque du tenant courant).
 * Cache-safe : le résolveur est une classe (nom en config), pas une closure.
 */
if (!function_exists('mt_theme_colors')) {
    function mt_theme_colors(): array {
        $colors = (array) mt_config('colors', []);

        $resolver = mt_config('theme_resolver');
        if ($resolver && is_string($resolver) && class_exists($resolver)) {
            try {
                $instance = app($resolver);
                if (method_exists($instance, 'colors')) {
                    $overrides = (array) $instance->colors();
                    foreach (['light', 'dark'] as $mode) {
                        if (! empty($overrides[$mode]) && is_array($overrides[$mode])) {
                            $colors[$mode] = array_merge($colors[$mode] ?? [], $overrides[$mode]);
                        }
                    }
                }
            } catch (\Throwable) {
                // résolveur indisponible → on garde la charte de config
            }
        }

        return $colors;
    }
}

/**
 * Résoudre l'URL d'une route depuis le fichier de config routes
 */
if (!function_exists('mt_get_route')) {
    function mt_get_route(string $item, array $parametres = []): string {
        try {
            // ⚠️ config() utilise la notation POINTÉE : une clé logique contenant un point
            // (ex. 'setup.reconfigure') est traversée (routes→setup→reconfigure) et ne
            // retombe JAMAIS sur la clé plate → href vide. Repli : si la clé logique est
            // introuvable, tolérer un NOM de route direct.
            $routeName = config('routes.' . $item);
            if (empty($routeName) || ! is_string($routeName)) {
                $routeName = \Illuminate\Support\Facades\Route::has($item) ? $item : null;
            }
            if (empty($routeName)) return '';
            if (!\Illuminate\Support\Facades\Route::has($routeName)) return '';
            return route($routeName, $parametres);
        } catch (\Throwable) {
            return '';
        }
    }
}

/**
 * Barre de navigation MOBILE (destinations + FAB) — point d'extension de l'hôte.
 * L'hôte déclare `config('mt-ui.mobile_nav')` :
 *   ['destinations' => [['label'=>clé i18n, 'icon'=>nom mt-icon, 'route'=>clé route], …max 3],
 *    'fab' => ['label'=>…, 'icon'=>'plus', 'route'=>…]]   (fab optionnel)
 * Renvoie [] si non configuré → le layout retombe sur la nav utilitaire actuelle
 * (neutre : mt-school et autres SaaS non impactés tant qu'ils n'optent pas).
 * L'état actif est calculé par PRÉFIXE de chemin d'URL (comme la sidebar) : une
 * page enfant (/reservations/create) active l'onglet parent (/reservations).
 */
if (!function_exists('mt_mobile_nav')) {
    function mt_mobile_nav(): array {
        $cfg = config('mt-ui.mobile_nav');
        if (empty($cfg) || empty($cfg['destinations']) || ! is_array($cfg['destinations'])) {
            return [];
        }

        $path = '/' . trim(request()->path(), '/'); // ex. "/reservations/create"

        $resolveUrl = static function (?string $routeKey, ?string $url): string {
            if ($routeKey) return mt_get_route($routeKey);
            return $url ?? '';
        };

        $destinations = [];
        foreach (array_slice($cfg['destinations'], 0, 3) as $item) {
            $url = $resolveUrl($item['route'] ?? null, $item['url'] ?? null);
            if ($url === '' || $url === '#') continue; // route absente (module désactivé) → on saute
            $target = '/' . trim((string) (parse_url($url, PHP_URL_PATH) ?: $url), '/');
            $active = $target !== '/' && ($path === $target || str_starts_with($path, $target . '/'));
            $destinations[] = [
                'label'    => $item['label'] ?? '',
                'icon'     => $item['icon'] ?? 'circle',
                'url'      => $url,
                'isActive' => $active,
            ];
        }

        if (empty($destinations)) return [];

        $fab = null;
        if (! empty($cfg['fab'])) {
            $fabUrl = $resolveUrl($cfg['fab']['route'] ?? null, $cfg['fab']['url'] ?? null);
            if ($fabUrl !== '' && $fabUrl !== '#') {
                $fab = [
                    'label' => $cfg['fab']['label'] ?? '',
                    'icon'  => $cfg['fab']['icon'] ?? 'plus',
                    'url'   => $fabUrl,
                ];
            }
        }

        return ['destinations' => $destinations, 'fab' => $fab];
    }
}

/**
 * Aide d'usage : résoudre un texte d'aide depuis le registre de l'hôte
 * (config/help.php : 'clé.logique' => 'texte' | ['fr'=>…, 'en'=>…]).
 * Renvoie '' si absent (jamais d'erreur). Cache-safe (pas de closures en config).
 */
if (!function_exists('mt_help')) {
    function mt_help(string $key): string {
        $value = config('help.' . $key, '');
        if (is_array($value)) {
            $locale = app()->getLocale();
            $value = $value[$locale] ?? reset($value) ?: '';
        }
        return is_string($value) ? $value : '';
    }
}

/**
 * Visite guidée : résoudre les étapes d'un tour depuis le registre de l'hôte
 * (config/tours.php : 'écran' => ['steps'=>[['target'=>'#sel','title'=>…,'body'=>…], …]]).
 * Chaque step.title/body peut être traduisible (array par locale). Renvoie [] si absent.
 */
if (!function_exists('mt_tour')) {
    function mt_tour(string $key): array {
        $tour = config('tours.' . $key);
        if (empty($tour['steps']) || !is_array($tour['steps'])) {
            return [];
        }

        $locale = app()->getLocale();
        $resolve = function ($v) use ($locale) {
            if (is_array($v)) {
                return $v[$locale] ?? reset($v) ?: '';
            }
            return is_string($v) ? $v : '';
        };

        $steps = [];
        foreach ($tour['steps'] as $step) {
            if (empty($step['target'])) continue;
            $steps[] = [
                'target' => $step['target'],
                'title'  => $resolve($step['title'] ?? ''),
                'body'   => $resolve($step['body'] ?? ''),
            ];
        }
        return $steps;
    }
}

/**
 * Mettre en surbrillance les termes recherchés dans un texte
 */
if (!function_exists('markTerms')) {
    function markTerms(string $phrase = '', string $expression = ''): string {
        if (strlen($phrase) > 0 && strlen($expression) > 0) {
            return preg_replace_callback(
                '/' . preg_quote($expression, '/') . '/i',
                fn ($matches) => '<mark>' . $matches[0] . '</mark>',
                $phrase
            );
        }
        return '';
    }
}

/**
 * Envoyer une notification à un ou plusieurs utilisateurs
 */
if (!function_exists('notifier')) {
    function notifier($userIds, array $data): void {
        $ids = is_array($userIds) ? $userIds : [$userIds];
        foreach ($ids as $id) {
            $user = \Illuminate\Support\Facades\Auth::guard()->getProvider()->retrieveById($id);
            if ($user) $user->notify(new HandleNotification(...$data));
        }
    }
}

/**
 * Déclencher une alerte via Livewire ModalService
 */
if (!function_exists('showAlert')) {
    function showAlert(string $type, string $message, bool $flash = true): void {
        $component = \Livewire\Livewire::current();
        if (!$component) return;

        match ($type) {
            'success' => $component->dispatch('open-alert-modal', ModalService::success($message)),
            'error'   => $component->dispatch('open-alert-modal', ModalService::error($message)),
            default   => null,
        };
    }
}

/**
 * Couleurs par défaut configurées dans mt-ui
 */
if (!function_exists('mt_colors')) {
    function mt_colors(): array {
        return config('mt-ui.default_colors', []);
    }
}

/**
 * Vérifier si au moins un provider de recherche est configuré
 */
if (!function_exists('mt_has_search')) {
    function mt_has_search(): bool {
        return !empty(config('mt-search.providers', []));
    }
}

require_once __DIR__ . '/views-config-helpers.php';
