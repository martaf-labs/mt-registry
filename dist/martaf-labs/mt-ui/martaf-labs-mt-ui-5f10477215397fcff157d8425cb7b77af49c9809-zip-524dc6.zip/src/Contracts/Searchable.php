<?php

namespace Mt\MtUi\Contracts;

/**
 * Interface Searchable
 *
 * Implémentez cette interface sur chaque modèle Eloquent
 * que vous souhaitez rendre cherchable par le composant GlobalSearch.
 *
 * Exemple :
 *   class User extends Model implements Searchable { ... }
 */
interface Searchable
{
    /**
     * Retourne le libellé de la catégorie affiché dans les résultats.
     * Ex : "Utilisateurs", "Produits", "Commandes"
     */
    public static function searchCategory(): string;

    /**
     * Icône FontAwesome affichée à côté de la catégorie.
     * Ex : "fa-solid fa-user", "fa-solid fa-box"
     */
    public static function searchIcon(): string;

    /**
     * Couleur Tailwind utilisée pour le badge de catégorie (sans le préfixe bg-).
     * Ex : "blue", "green", "purple"
     */
    public static function searchColor(): string;

    /**
     * Colonnes Eloquent sur lesquelles la recherche LIKE sera effectuée.
     * Ex : ['name', 'email', 'phone']
     */
    public static function searchableColumns(): array;

    /**
     * Transforme une instance du modèle en tableau normalisé pour l'affichage.
     * Doit retourner :
     * [
     *   'id'          => $this->id,
     *   'title'       => string,         // ligne principale
     *   'subtitle'    => string|null,    // ligne secondaire (optionnel)
     *   'meta'        => string|null,    // badge / info droite (optionnel)
     *   'url'         => string,         // lien cible au clic
     *   'avatar'      => string|null,    // URL image ou null
     *   'avatar_text' => string|null,    // initiales si pas d'image
     * ]
     */
    public function toSearchResult(): array;
}
