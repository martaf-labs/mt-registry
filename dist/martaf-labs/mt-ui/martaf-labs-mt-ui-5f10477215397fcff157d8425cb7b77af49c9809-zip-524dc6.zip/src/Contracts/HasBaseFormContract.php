<?php

namespace Mt\MtUi\Contracts;

interface HasBaseFormContract
{
    /**
     * @return array
     */
    public function fieldActions():array;
}