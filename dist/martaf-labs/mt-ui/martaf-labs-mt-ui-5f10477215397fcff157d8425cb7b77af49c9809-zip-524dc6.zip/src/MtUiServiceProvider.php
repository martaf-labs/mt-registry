<?php

namespace Mt\MtUi;

use Livewire\Livewire;
use Illuminate\Support\Facades\Blade;
use Mt\MtFoundation\MtServiceProvider;
use Mt\MtFoundation\Helpers\MtLocale;
use Mt\MtUi\Services\ModalService;

/**
 * MtUiServiceProvider
 *
 * Service provider principal de mt-ui.
 * Gère TOUTE l'interface graphique de l'écosystème martaf-labs :
 *
 *   - Composants Blade anonymes et de classe
 *   - Composants Livewire (UI, Auth, Settings, Search, Modals)
 *   - Layouts et vues partagées
 *   - Middlewares UI
 *   - Directives Blade personnalisées
 *   - Assets CSS/JS
 *
 * Principe : tout ce qui touche à l'affichage est ici.
 * La logique métier (models, services, migrations) est dans
 * les packages dédiés (mt-auth, mt-images, mt-search...).
 *
 * Dépend de : mt-foundation
 */
class MtUiServiceProvider extends MtServiceProvider
{

    /**
     * Enregistre les bindings dans le conteneur IoC.
     * Appelé avant boot(), idéal pour les bindings simples.
     */
    public function register(): void
    {
        // Configuration principale du package
        $this->mergeConfigFrom(
            $this->basePath . '/config/mt-ui.php',
            'mt-ui'
        );

        // Singleton pour la gestion des locales UI
        $this->app->singleton(MtLocale::class);

        // Singleton pour le service des modals
        $this->app->singleton(ModalService::class);
    }

    /**
     * Démarre les services du package.
     * Appelé après register(), une fois tous les providers chargés.
     */
    public function boot(): void
    {
        $viewsPath = $this->basePath . '/resources/views';
        $langPath  = $this->basePath . '/lang';

        // 1. Routes UI du package
        $this->registerRoutes();

        // 2. Vues avec namespace 'mt'
        //    Permet @include('mt::...') et les composants de classe
        $this->loadViewsFrom($viewsPath, 'mt');

        // 3. Composants Blade anonymes
        //    Permet <x-mt::button />, <x-mt::card />, etc.
        if (is_dir($viewsPath . '/components')) {
            Blade::anonymousComponentPath($viewsPath . '/components', 'mt');
        }

        // 4. Traductions
        $this->loadTranslationsFrom($langPath, 'mt-ui');

        // 5. Middlewares
        $this->registerMiddlewares();
        $this->loadPackageTranslations('mtviews');

        // 6. Directives Blade personnalisées
        $this->registerBladeDirectives();

        // 7. Composants Livewire
        $this->registerLivewireComponents();

        // 8. Publication des ressources (console uniquement)
        if ($this->app->runningInConsole()) {
            $this->registerPublishing($viewsPath, $langPath);
        }
    }

    /**
     * Charge les routes UI du package.
     *
     * Note : les routes de recherche sont gérées par mt-search.
     */
    protected function registerRoutes(): void
    {
        $routesPath = $this->basePath . '/routes/web.php';
        if (file_exists($routesPath)) {
            $this->loadRoutesFrom($routesPath);
        }

        // Routes search (fallback si mt-search n'est pas installé)
        if (! class_exists(\Mt\MtSearch\MtSearchServiceProvider::class)) {
            $searchRoutesPath = $this->basePath . '/routes/search.php';
            if (file_exists($searchRoutesPath)) {
                $this->loadRoutesFrom($searchRoutesPath);
            }
        }
    }

    /**
     * Enregistre les middlewares du package.
     *
     * mt.layout → contrôle le layout actif selon la route
     *
     * Note : SetMtLocale est géré par mt-auth car il dépend
     * de la session utilisateur (logique métier).
     */
    protected function registerMiddlewares(): void
    {
        $this->app['router']->aliasMiddleware(
            'mt.layout',
            \Mt\MtUi\Http\Middleware\SetActiveLayoutMiddleware::class
        );
    }

    /**
     * Enregistre les directives Blade personnalisées.
     *
     * @mtAssets → inclut tous les assets CSS/JS du package
     * @mtIcons  → géré par mt-icons (MtIconsServiceProvider)
     */
    protected function registerBladeDirectives(): void
    {
        Blade::directive('mtAssets', function () {
            return "<?php
                \$html = '';
                if (config('mt-ui.assets.load_package_assets', true)) {
                    \$html .= '<link rel=\"stylesheet\" href=\"' . asset('vendor/mt/mt-ui/css/mt-ui.css') . '\">';
                }
                if (config('mt-ui.assets.load_package_js', true)) {
                    \$html .= '<script src=\"' . asset('vendor/mt/mt-ui/js/mt-ui.js') . '\" defer><\/script>';
                }
                echo \$html;
            ?>";
        });
    }

    /**
     * Enregistre tous les composants Livewire du package.
     *
     * Convention de nommage : mt.{groupe}.{composant}
     *
     * Groupes :
     *   mt.auth.*      → authentification
     *   mt.settings.*  → paramètres utilisateur
     *   mt.modals.*    → modals génériques
     *   mt.forms.*     → formulaires
     *   mt.search.*    → interface de recherche (logique dans mt-search)
     */
    protected function registerLivewireComponents(): void
    {
        // ── Dashboard & Navigation ────────────────────────────────────────
        Livewire::component(
            'mt.mt-dashboard',
            \Mt\MtUi\Livewire\MtDashboard::class
        );
        Livewire::component(
            'mt.locale-switcher',
            \Mt\MtUi\Livewire\LocaleSwitcher::class
        );

        // ── Authentification ──────────────────────────────────────────────
        // Les vues sont ici, la logique métier est dans mt-auth
        Livewire::component(
            'mt.auth.login',
            \Mt\MtUi\Livewire\Auth\Login::class
        );
        Livewire::component(
            'mt.auth.register',
            \Mt\MtUi\Livewire\Auth\Register::class
        );
        Livewire::component(
            'mt.auth.forgot-password',
            \Mt\MtUi\Livewire\Auth\ForgotPassword::class
        );
        Livewire::component(
            'mt.auth.reset-password',
            \Mt\MtUi\Livewire\Auth\ResetPassword::class
        );
        Livewire::component(
            'mt.auth.verify-email',
            \Mt\MtUi\Livewire\Auth\VerifyEmail::class
        );

        // ── Modals génériques ─────────────────────────────────────────────
        Livewire::component(
            'mt.modals.confirm',
            \Mt\MtUi\Livewire\Modals\Confirm::class
        );
        Livewire::component(
            'mt.modals.alert',
            \Mt\MtUi\Livewire\Modals\Alert::class
        );
        Livewire::component(
            'mt.modals.flash-alert',
            \Mt\MtUi\Livewire\Modals\FlashAlert::class
        );
        Livewire::component(
            'mt.modals.select',
            \Mt\MtUi\Livewire\Modals\SelectModal::class
        );
        Livewire::component(
            'mt.modals.export',
            \Mt\MtUi\Livewire\Modals\DataExporterModal::class
        );

        // ── Formulaires ───────────────────────────────────────────────────
        // Gestionnaire de médias polymorphe (images + documents) - mt-media.
        Livewire::component(
            'mt.forms.media-manager',
            \Mt\MtUi\Livewire\Forms\MediaManager::class
        );
        // Alias rétro-compatible : pointe désormais vers MediaManager.
        Livewire::component(
            'mt.forms.image-manager',
            \Mt\MtUi\Livewire\Forms\MediaManager::class
        );

        // ── Paramètres utilisateur ────────────────────────────────────────
        Livewire::component(
            'mt.settings.profile',
            \Mt\MtUi\Livewire\Settings\Profile::class
        );
        Livewire::component(
            'mt.settings.appearance',
            \Mt\MtUi\Livewire\Settings\Appearance::class
        );
        Livewire::component(
            'mt.settings.password',
            \Mt\MtUi\Livewire\Settings\Password::class
        );
        Livewire::component(
            'mt.settings.delete-user',
            \Mt\MtUi\Livewire\Settings\DeleteUserForm::class
        );
        Livewire::component(
            'mt.settings.two-factor',
            \Mt\MtUi\Livewire\Settings\TwoFactor::class
        );

        // ── Recherche (fallback si mt-search n'est pas installé) ──────────
        if (! class_exists(\Mt\MtSearch\MtSearchServiceProvider::class)) {
            Livewire::component('mt.global-search',  \Mt\MtUi\Livewire\Search\GlobalSearch::class);
            Livewire::component('mt.search-results', \Mt\MtUi\Livewire\Search\SearchResults::class);
        }
    }

    /**
     * Déclare les ressources publiables via vendor:publish.
     *
     * Tags disponibles :
     *   mt-ui-config  → config/mt-ui.php
     *   mt-ui-lang    → lang/vendor/mt/mt-ui/
     *   mt-ui-views   → resources/views/vendor/mt/mt-ui/
     *   mt-ui-assets  → public/vendor/mt/mt-ui/
     */
    protected function registerPublishing(string $viewsPath, string $langPath): void
    {
        // Configuration
        $this->publishes([
            $this->basePath . '/config/mt-ui.php' => config_path('mt-ui.php'),
        ], 'mt-ui-config');

        // Traductions
        $this->publishes([
            $langPath => $this->app->langPath('vendor/mt/mt-ui'),
        ], 'mt-ui-lang');

        // Vues (pour personnalisation dans le projet)
        $this->publishes([
            $viewsPath => resource_path('views/vendor/mt/mt-ui'),
        ], 'mt-ui-views');

        // Assets publics (CSS composants uniquement - sans Tailwind preflight, pour éviter le double chargement)
        $this->publishes([
            $this->basePath . '/dist/css/mt-ui-components.css' => public_path('vendor/mt/mt-ui/css/mt-ui.css'),
            $this->basePath . '/public/assets/js/mt-ui.js'     => public_path('vendor/mt/mt-ui/js/mt-ui.js'),
        ], 'mt-ui-assets');
    }
}