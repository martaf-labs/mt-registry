<?php

namespace Mt\MtUi\Livewire\Profiles;

use Carbon\Carbon;
use Mt\MtUi\Models\BaseUser;
use Illuminate\Support\Str;

abstract class GenericProfile
{
    abstract public static function modelClass(): string;
    abstract public function configuration($model): array;

    public function getCurrentUserProfile()
    {
        $modelClass = static::modelClass();

        if ($modelClass === User::class) {
            return auth()->user();
        }

        return auth()->user()->userable ?? null;
    }

    public function getProfileData($model, $profileId = null): array
    {
        $sections =array_filter([
            'process' => method_exists($this, 'profileProcess')? $this->profileProcess($model) : null,
            'personalInfos' => method_exists($this, 'personalInfos')? $this->personalInfos($model) : null,
        ]);
        return array_filter([
            'sections' => $sections,
            'sidebar' => method_exists($this, 'profileSideBar')? $this->profileSideBar($model, $profileId) : null,
            'actions' => method_exists($this, 'profileActions')? $this->profileActions($model, $profileId) : null,
            'modules' => $this->getProfileModules($model, $profileId) // Nouveau: modules additionnels
        ]);
    }


    /**
     * NOUVEAU: Obtenir les modules additionnels du profil
     */
    protected function getProfileModules($model, $profileId = null): ?array
    {
        return method_exists($this, 'profileModules')? $this->profileModules($model, $profileId) : null;
    }

    /**
     * NOUVEAU: Obtenir les données d'un module spécifique
     */
    public function getModuleData($model, $moduleType): array
    {
        $method = 'get' . Str::studly($moduleType) . 'ModuleData';

        if (method_exists($this, $method)) {
            return $this->$method($model);
        }

        return $this->getDefaultModuleData($model, $moduleType);
    }

    /**
     * NOUVEAU: Données par défaut pour les modules
     */
    protected function getDefaultModuleData($model, $moduleType): array
    {
        return [
            'title' => Str::title($moduleType),
            'datas' => [],
            'stats' => [],
            'actions' => []
        ];
    }


    protected function getPersonalInfoFields($model): array
    {
        return [];
    }

    protected function getContactFields($model): array
    {
        return [];
    }

    // protected function mt_get_sidebarData($model, $profileId = null): array
    // {
    //     $isMyProfile = !$profileId || $profileId == auth()->id();
    //     $isUser = get_class($model) === 'Src\Models\User';

    //     return [
    //         // 'profile' => [
    //         //     'name' =>  $isUser ? $model->userable->fullName() : $model->fullName(),
    //         //     'email' => $model->email ?? null,
    //         //     'avatar' => $isUser ? $model->userable->imageUrl() : $model->imageUrl(),
    //         //     'role' => $this->getUserRole($model),
    //         //     'member_since' => $model->created_at ? Carbon::parse($model->created_at)->locale('fr')->translatedFormat('F Y') : null,
    //         // ],
    //         // 'quick_stats' => $this->getQuickStats($model),
    //         // 'is_my_profile' => $isMyProfile
    //     ];
    // }

    protected function getUserRole($model): string
    {
        if (method_exists($model, 'getRoleName')) {
            return $model->getRoleName();
        }

        return class_basename(static::modelClass());
    }

    public function getQuickStats($model): array
    {
        return [];
    }

    public function formatValue($field, $value): string
    {
        if (is_null($value) || $value === '') {
            return '<span class="italic text-zinc-400 dark:text-zinc-500">Non renseigné</span>';
        }

        $fieldType = $field['type'] ?? 'text';

        switch ($fieldType) {
            case 'select':
                return $this->formatSelectValue($field, $value);
            case 'date':
                return $this->formatDateValue($value);
            case 'datetime':
                return $this->formatDateTimeValue($value);
            case 'boolean':
                return $this->formatBooleanValue($value);
            case 'email':
                return '<a href="mailto:' . e($value) . '" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">' . e($value) . '</a>';
            case 'phone':
                return '<a href="tel:' . e($value) . '" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">' . e($value) . '</a>';
            case 'currency':
                return $this->formatCurrencyValue($value);
            case 'percentage':
                return $this->formatPercentageValue($value);
            default:
                return e($value);
        }
    }

    /**
     * NOUVEAU: Formater les valeurs monétaires
     */
    protected function formatCurrencyValue($value): string
    {
        return number_format($value, 2, ',', ' ') . ' €';
    }

    /**
     * NOUVEAU: Formater les pourcentages
     */
    protected function formatPercentageValue($value): string
    {
        return number_format($value, 2, ',', ' ') . ' %';
    }

    protected function formatSelectValue($field, $value): string
    {
        $listItems = $field['listItems'] ?? [];

        if (is_array($listItems) && isset($listItems[$value])) {
            return e($listItems[$value]);
        }

        return e($value);
    }

    protected function formatDateValue($value): string
    {
        if ($value instanceof Carbon) {
            return $value->locale('fr')->translatedFormat('j F Y');
        }

        return e($value);
    }

    protected function formatDateTimeValue($value): string
    {
        if ($value instanceof Carbon) {
            return $value->locale('fr')->translatedFormat('j F Y à H:i');
        }

        return e($value);
    }

    protected function formatBooleanValue($value): string
    {
        $value = (bool) $value;

        if ($value) {
            return '<span class="inline-flex items-center px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-300">
                <i class="mr-1 bi bi-check-circle"></i> Oui
            </span>';
        }

        return '<span class="inline-flex items-center px-2 py-1 text-xs font-medium text-red-800 bg-red-100 rounded-full dark:bg-red-900 dark:text-red-300">
            <i class="mr-1 bi bi-x-circle"></i> Non
        </span>';
    }
}

