<?php

/**
 * ════════════════════════════════════════════════════════════════════
 *  1. ENREGISTREMENT DANS LE SERVICE PROVIDER DU PACKAGE
 * ════════════════════════════════════════════════════════════════════
 *
 * Dans votre MtServiceProvider.php, ajoutez :
 */

// namespace Mt;
//
// use Illuminate\Support\ServiceProvider;
// use Livewire\Livewire;
// use Mt\Livewire\GlobalSearch;
//
// class MtServiceProvider extends ServiceProvider
// {
//     public function boot(): void
//     {
//         // Vues
//         $this->loadViewsFrom(__DIR__.'/../resources/views', 'mt');
//
//         // Config
//         $this->mergeConfigFrom(__DIR__.'/../config/mt-search.php', 'mt');
//         $this->publishes([
//             __DIR__.'/../config/mt-search.php' => config_path('mt.php'),
//         ], 'mt-config');
//
//         // Composant Livewire
//         Livewire::component('mt.global-search', GlobalSearch::class);
//
//         // Route page de résultats (optionnelle - vous pouvez aussi la déclarer
//         // dans routes/web.php de votre application)
//         $this->loadRoutesFrom(__DIR__.'/../routes/search.php');
//     }
// }


/**
 * ════════════════════════════════════════════════════════════════════
 *  2. ROUTE (routes/search.php dans le package)
 * ════════════════════════════════════════════════════════════════════
 */

// use Illuminate\Support\Facades\Route;
//
// Route::middleware(['web', 'auth'])->group(function () {
//     Route::get('/search', function () {
//         return view('mt::search.results', [
//             'query'    => request('q', ''),
//             'category' => request('category'),
//         ]);
//     })->name('search.index');
// });


/**
 * ════════════════════════════════════════════════════════════════════
 *  3. EXEMPLE D'IMPLÉMENTATION SUR UN MODÈLE - User
 * ════════════════════════════════════════════════════════════════════
 */

// namespace App\Models;
//
// use Illuminate\Database\Eloquent\Model;
// use Mt\Contracts\Searchable;
// use Mt\Traits\IsSearchable;
//
// class User extends Model implements Searchable
// {
//     use IsSearchable;
//
//     // ── Interface Searchable ──────────────────────────
//
//     public static function searchCategory(): string
//     {
//         return 'Utilisateurs';
//     }
//
//     public static function searchIcon(): string
//     {
//         return 'fa-solid fa-users';
//     }
//
//     public static function searchColor(): string
//     {
//         return 'blue'; // blue | green | purple | orange | red | teal | pink | gray
//     }
//
//     public static function searchableColumns(): array
//     {
//         return ['name', 'email', 'phone'];
//     }
//
//     public function toSearchResult(): array
//     {
//         return [
//             'id'          => $this->id,
//             'title'       => $this->name,
//             'subtitle'    => $this->email,
//             'meta'        => $this->created_at?->diffForHumans(),
//             'url'         => route('users.show', $this),
//             'avatar'      => $this->profile_photo_url ?? null,
//             'avatar_text' => strtoupper(substr($this->name, 0, 2)),
//         ];
//     }
// }


/**
 * ════════════════════════════════════════════════════════════════════
 *  4. EXEMPLE D'IMPLÉMENTATION - Product
 * ════════════════════════════════════════════════════════════════════
 */

// namespace App\Models;
//
// use Illuminate\Database\Eloquent\Model;
// use Mt\Contracts\Searchable;
// use Mt\Traits\IsSearchable;
//
// class Product extends Model implements Searchable
// {
//     use IsSearchable;
//
//     public static function searchCategory(): string  { return 'Produits'; }
//     public static function searchIcon(): string      { return 'fa-solid fa-box'; }
//     public static function searchColor(): string     { return 'green'; }
//
//     public static function searchableColumns(): array
//     {
//         return ['name', 'sku', 'description'];
//     }
//
//     public function toSearchResult(): array
//     {
//         return [
//             'id'          => $this->id,
//             'title'       => $this->name,
//             'subtitle'    => 'SKU: ' . $this->sku,
//             'meta'        => number_format($this->price, 0, ',', ' ') . ' FCFA',
//             'url'         => route('products.show', $this),
//             'avatar'      => $this->thumbnail_url ?? null,
//             'avatar_text' => strtoupper(substr($this->name, 0, 2)),
//         ];
//     }
// }


/**
 * ════════════════════════════════════════════════════════════════════
 *  5. UTILISATION DANS LES VUES
 * ════════════════════════════════════════════════════════════════════
 *
 * Dans votre layout (master.blade.php) - déjà intégré si vous utilisez
 * le layout généré précédemment. Sinon, ajoutez simplement :
 *
 *   <livewire:mt.global-search />
 *
 * Le raccourci Ctrl+K / ⌘K est automatiquement activé.
 */


/**
 * ════════════════════════════════════════════════════════════════════
 *  6. STRUCTURE DES FICHIERS DANS LE PACKAGE
 * ════════════════════════════════════════════════════════════════════
 *
 *  your-package/
 *  ├── config/
 *  │   └── mt-search.php                     ← config (publier avec php artisan vendor:publish)
 *  ├── src/
 *  │   ├── Contracts/
 *  │   │   └── Searchable.php                ← interface
 *  │   ├── Traits/
 *  │   │   └── IsSearchable.php              ← trait scope Eloquent
 *  │   ├── Livewire/
 *  │   │   └── GlobalSearch.php              ← composant Livewire
 *  │   └── MtServiceProvider.php             ← registration
 *  ├── resources/views/
 *  │   ├── livewire/
 *  │   │   └── global-search.blade.php       ← vue dropdown + modal
 *  │   └── search/
 *  │       └── results.blade.php             ← page de résultats
 *  └── routes/
 *      └── search.php                        ← route /search
 */
