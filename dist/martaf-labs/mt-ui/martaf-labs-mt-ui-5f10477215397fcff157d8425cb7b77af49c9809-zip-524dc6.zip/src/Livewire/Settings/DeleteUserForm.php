<?php

namespace Mt\MtUi\Livewire\Settings;

use Livewire\Component;
use Livewire\Attributes\Layout;
use App\Livewire\Actions\Logout;
use Illuminate\Support\Facades\Auth;
use Mt\MtUi\Livewire\BaseAppComponent;


class DeleteUserForm extends BaseAppComponent
{
    public string $password = '';

    /**
     * Delete the currently authenticated user.
     */
    public function deleteUser(Logout $logout): void
    {
        $this->validate([
            'password' => ['required', 'string', 'current_password'],
        ]);

        tap(Auth::user(), $logout(...))->delete();

        $this->redirect('/', navigate: true);
    }    

    public function render()
    {
        return view('mt::livewire.settings.delete-user-form');
    }
}
