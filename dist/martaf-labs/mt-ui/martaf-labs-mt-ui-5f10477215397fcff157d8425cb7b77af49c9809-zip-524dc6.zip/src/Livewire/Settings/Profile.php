<?php

namespace Mt\MtUi\Livewire\Settings;

use Livewire\Component;
use Mt\MtUi\Models\BaseUser;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Layout;
use Illuminate\Support\Facades\Auth;
use Mt\MtUi\Livewire\BaseAppComponent;
use Illuminate\Support\Facades\Session;



class Profile extends BaseAppComponent
{
    public string $name = '';

    public string $email = '';

    /**
     * Mount the component.
     */
    public function mount(): void
    {
        $user = Auth::user();

        // Générique : tout user n'a PAS forcément de profil `userable` lié (ex. un
        // administrateur). Repli sur le nom du compte — jamais de ->fullName() direct.
        $profile    = $user->userable ?? null;
        $this->name = ($profile && method_exists($profile, 'fullName'))
            ? (string) $profile->fullName()
            : (string) ($user->name ?? '');

        $this->email = (string) $user->email;
    }

    /**
     * Update the profile information for the currently authenticated user.
     */
    public function updateProfileInformation(): void
    {
        $user = Auth::user();

        $validated = $this->validate([
            'name' => ['required', 'string', 'max:255'],

            'email' => [
                'required',
                'string',
                'lowercase',
                'email',
                'max:255',
                // $user::class = le modèle User réel de l'app hôte (la classe `User` n'existe
                // pas dans ce namespace — l'ancien Rule::unique(User::class) fatalait au save).
                Rule::unique($user::class)->ignore($user->id),
            ],
        ]);

        $user->fill($validated);

        if ($user->isDirty('email')) {
            $user->email_verified_at = null;
        }

        $user->save();

        $this->dispatch('profile-updated', name: $user->name);
    }

    /**
     * Send an email verification notification to the current user.
     */
    public function resendVerificationNotification(): void
    {
        $user = Auth::user();

        if ($user->hasVerifiedEmail()) {
            $this->redirectIntended(default: route('dashboard', absolute: false));

            return;
        }

        $user->sendEmailVerificationNotification();

        Session::flash('status', 'verification-link-sent');
    }

    public function render()
    {
        return view('mt::livewire.settings.profile');
    }
}
