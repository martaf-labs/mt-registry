<?php

namespace Mt\MtUi\Livewire\Settings\TwoFactor;

use Exception;
use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Mt\MtUi\Livewire\BaseAppComponent;
use Laravel\Fortify\Actions\GenerateNewRecoveryCodes;

class RecoveryCodes extends BaseAppComponent
{
    #[Locked]
    public array $recoveryCodes = [];

    /**
     * Mount the component.
     */
    public function mount(): void
    {
        $this->loadRecoveryCodes();
    }

    /**
     * Generate new recovery codes for the user.
     */
    public function regenerateRecoveryCodes(GenerateNewRecoveryCodes $generateNewRecoveryCodes): void
    {
        $generateNewRecoveryCodes(auth()->user());

        $this->loadRecoveryCodes();
    }

    /**
     * Load the recovery codes for the user.
     */
    private function loadRecoveryCodes(): void
    {
        $user = auth()->user();

        if ($user->hasEnabledTwoFactorAuthentication() && $user->two_factor_recovery_codes) {
            try {
                $this->recoveryCodes = json_decode(decrypt($user->two_factor_recovery_codes), true);
            } catch (Exception) {
                $this->addError('recoveryCodes', 'Echec du décryptage des codes de récupération.');

                $this->recoveryCodes = [];
            }
        }
    }  

    public function render()
    {
        return view('mt::livewire.settings.two-factor.recovery-codes');
    }
}
