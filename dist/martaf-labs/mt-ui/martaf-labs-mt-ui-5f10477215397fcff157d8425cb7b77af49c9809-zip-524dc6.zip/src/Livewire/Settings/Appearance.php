<?php

namespace Mt\MtUi\Livewire\Settings;

use Livewire\Component;
use Livewire\Attributes\Layout;
use Mt\MtUi\Livewire\BaseAppComponent;


class Appearance extends BaseAppComponent
{
      

    public function render()
    {
        return view('mt::livewire.settings.appearance');
    }
}
