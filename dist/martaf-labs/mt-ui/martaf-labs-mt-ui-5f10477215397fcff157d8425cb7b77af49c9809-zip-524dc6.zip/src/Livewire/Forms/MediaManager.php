<?php

namespace Mt\MtUi\Livewire\Forms;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Relation;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtMedia\Contracts\MediaModelContract;
use Mt\MtMedia\Enums\MediaKind;
use Mt\MtMedia\Services\MediaService;

/**
 * Gestionnaire de médias polymorphe (mt-media).
 *
 * Gère images (optimisées) ET documents/vidéos (stockés tels quels) pour
 * n'importe quel modèle propriétaire.
 *
 * Usage Blade :
 *   <livewire:mt.forms.media-manager
 *       :model-type="$student->getMorphClass()"   {{-- ou la classe complète --}}
 *       :model-id="$student->id"
 *       kind="image"        {{-- image|document|video|any --}}
 *       type="photo"        {{-- finalité libre : photo, certificate, avatar… --}}
 *       :multiple="true"
 *       :allow-delete="true"
 *   />
 */
class MediaManager extends Component
{
    use WithFileUploads;

    /** Classe complète OU alias morph du propriétaire. */
    public string $modelType = '';
    public ?int   $modelId   = null;

    /** Nature gérée (image|document|video|any) et finalité (media.type). */
    public string $kind = 'image';
    public string $type = 'photo';

    public bool $multiple    = true;
    public bool $allowDelete = true;
    public int  $maxFiles    = 10;

    public array  $uploads   = [];
    public array  $results   = [];
    public array  $existing  = [];
    public bool   $loading   = false;
    public int    $progress  = 0;
    public string $activeTab = 'gallery';

    public function mount(
        string $modelType = '',
        ?int   $modelId   = null,
        string $kind      = 'image',
        string $type      = 'photo',
        bool   $multiple  = true,
        bool   $allowDelete = true,
        int    $maxFiles  = 10,
    ): void {
        $this->modelType   = $modelType;
        $this->modelId     = $modelId;
        $this->kind        = $kind;
        $this->type        = $type;
        $this->multiple    = $multiple;
        $this->allowDelete = $allowDelete;
        $this->maxFiles    = $maxFiles;

        $this->loadExisting();
    }

    // =========================================================================
    // Résolution du propriétaire (classe ↔ alias morph)
    // =========================================================================

    /** Alias morph utilisé en base (ex: 'student'), quel que soit l'input. */
    protected function morphAlias(): string
    {
        if (class_exists($this->modelType)) {
            try {
                return (new $this->modelType)->getMorphClass();
            } catch (\Throwable) {
                return $this->modelType;
            }
        }
        return $this->modelType;
    }

    /** Instance du modèle propriétaire, ou null. */
    protected function owner(): ?Model
    {
        $class = class_exists($this->modelType)
            ? $this->modelType
            : Relation::getMorphedModel($this->modelType);

        if (! $class || ! $this->modelId) {
            return null;
        }

        return $class::query()->find($this->modelId);
    }

    protected function mediaModel(): ?string
    {
        try {
            return app(MediaModelContract::class)->model();
        } catch (\Throwable) {
            return null;
        }
    }

    // =========================================================================
    // Upload
    // =========================================================================

    public function updatedUploads(): void
    {
        $maxKb    = config('mt-media.max_upload_size', 10240);
        $allowed  = config("mt-media.allowed.{$this->kind}", []);
        $mimeRule = ! empty($allowed) && $this->kind !== 'any'
            ? '|mimes:' . implode(',', $allowed)
            : '';

        $this->validate([
            'uploads.*' => "file|max:{$maxKb}{$mimeRule}",
        ]);

        if (count($this->uploads) > $this->maxFiles) {
            $this->addError('uploads', "Maximum {$this->maxFiles} fichiers à la fois.");
            $this->uploads = array_slice($this->uploads, 0, $this->maxFiles);
        }
    }

    public function process(): void
    {
        if (empty($this->uploads)) {
            return;
        }

        $owner = $this->owner();
        if (! $owner) {
            $this->addError('uploads', "Propriétaire introuvable.");
            return;
        }

        $this->loading = true;
        $this->results = [];
        $service       = app(MediaService::class);
        $total         = count($this->uploads);
        $hasFeatured   = $this->existingHasFeatured();

        foreach (array_values($this->uploads) as $index => $upload) {
            try {
                $media = $service->attach($owner, $upload, [
                    'type'        => $this->type,
                    // Première image rattachée → featured par défaut
                    'is_featured' => $this->kind === 'image' && ! $hasFeatured && $index === 0,
                ]);

                $this->results[] = [
                    'success'         => true,
                    'filename'        => $media->original_name ?? $media->title,
                    'kind'            => $media->kind->value,
                    'original_size'   => $media->size,
                    'savings_percent' => $media->getSavingsPercent(),
                    'variants'        => $media->metadata['optimizer']['variants'] ?? [],
                ];
            } catch (\Throwable $e) {
                $this->results[] = [
                    'success'  => false,
                    'filename' => $upload->getClientOriginalName(),
                    'error'    => $e->getMessage(),
                ];
            }

            $this->progress = (int) (($index + 1) / $total * 100);
        }

        $this->uploads   = [];
        $this->loading   = false;
        $this->progress  = 0;
        $this->activeTab = 'gallery';

        $this->loadExisting();
        $this->dispatch('media-updated', modelId: $this->modelId);
    }

    // =========================================================================
    // Gestion des médias existants
    // =========================================================================

    public function setFeatured(int $id): void
    {
        $model = $this->mediaModel();
        if (! $model) {
            return;
        }

        // Le hook saving de BaseMedia retire automatiquement les autres featured
        $model::query()->whereKey($id)->first()?->update(['is_featured' => true]);

        $this->loadExisting();
        $this->dispatch('media-updated', modelId: $this->modelId);
    }

    public function deleteMedia(int $id): void
    {
        if (! $this->allowDelete) {
            return;
        }

        app(MediaService::class)->delete($id);

        $this->loadExisting();
        $this->dispatch('media-updated', modelId: $this->modelId);
    }

    // =========================================================================
    // Chargement / helpers
    // =========================================================================

    protected function loadExisting(): void
    {
        $model = $this->mediaModel();
        if (! $model || ! $this->modelId) {
            $this->existing = [];
            return;
        }

        $query = $model::query()
            ->where('model_type', $this->morphAlias())
            ->where('model_id', $this->modelId)
            ->when($this->kind !== 'any', fn ($q) => $q->where('kind', $this->kind))
            ->orderByDesc('is_featured')
            ->orderBy('order')
            ->orderByDesc('created_at');

        $this->existing = $query->get()->map(fn ($m) => [
            'id'            => $m->id,
            'title'         => $m->title,
            'kind'          => $m->kind->value,
            'is_image'      => $m->isImage(),
            'path'          => $m->path,
            'url'           => $m->media_url,
            'webp_url'      => $m->isImage() ? $m->getVariantUrl('webp') : null,
            'is_featured'   => $m->is_featured,
            'savings'       => $m->isImage() ? $m->getSavingsPercent() : null,
            'mime_type'     => $m->mime_type,
            'size'          => $m->size,
            'original_name' => $m->original_name ?? $m->title,
        ])->all();
    }

    protected function existingHasFeatured(): bool
    {
        foreach ($this->existing as $m) {
            if ($m['is_featured']) {
                return true;
            }
        }
        return false;
    }

    public function getKindLabelProperty(): string
    {
        return MediaKind::tryFrom($this->kind)?->label() ?? 'Fichier';
    }

    public function getUploadItemTypeProperty(): string
    {
        return match ($this->kind) {
            'image'    => $this->multiple ? 'images' : 'image',
            'document' => 'document',
            'video'    => 'video',
            default    => 'document',
        };
    }

    public function render()
    {
        return view('mt::livewire.forms.media-manager');
    }
}
