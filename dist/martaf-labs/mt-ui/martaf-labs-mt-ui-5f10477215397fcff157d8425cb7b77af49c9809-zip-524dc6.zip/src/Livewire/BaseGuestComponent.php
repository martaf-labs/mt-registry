<?php

namespace Mt\MtUi\Livewire;

use Livewire\Component;
use Livewire\Attributes\Layout;

#[Layout('mt::components.layouts.guest')]
class BaseGuestComponent extends Component
{
    // Ici on peux ajouter des méthodes ou propriétés communes
}
