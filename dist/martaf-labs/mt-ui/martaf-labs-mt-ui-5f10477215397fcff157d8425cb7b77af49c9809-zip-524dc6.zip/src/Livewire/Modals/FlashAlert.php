<?php

namespace Mt\MtUi\Livewire\Modals;

use Livewire\Component;

class FlashAlert extends Component
{
    public $mtSuccess;
    public $mtError;
    public $mtWarning;
    public $mtInfo;

    // Fermeture manuelle
    public function close($type)
    {
        if (in_array($type, ['mtSuccess', 'mtError', 'mtWarning', 'mtInfo'])) {
            $this->$type = null;
        }
    }

    public function render()
    {
        return view('mt::livewire.modals.flash-alert');
    }
}
