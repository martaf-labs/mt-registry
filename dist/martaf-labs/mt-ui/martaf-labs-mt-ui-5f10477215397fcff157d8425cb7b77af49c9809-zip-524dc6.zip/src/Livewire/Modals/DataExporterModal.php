<?php

namespace Mt\MtUi\Livewire\Modals;

use Illuminate\Support\Str;
use Livewire\WithPagination;
use Illuminate\View\Component;
use Barryvdh\DomPDF\Facade\Pdf;
use Maatwebsite\Excel\Facades\Excel;
use Mt\MtUi\Exports\GlobalExport;
use Illuminate\Support\Facades\Schema;

class DataExporterModal extends Component
{

    public $modelName;
    public $modelClass;
    public $selectedFormat = 'excel';
    public $exporting = false;
    public $exportMessage = '';
    public $exportSuccess = false;
    public $data;
    public $allowedcolumns = [];
    public $selectedcolumns = [];
    public $columns = [];
    public $filename = 'export';
    public $isOpen = false;

    protected $listeners = [
        'open-exporter-modal' => 'openModal',
        'prepareExport' => 'prepareExportData'
    ];

    public function mount(string $modelName)
    {
        $this->modelName = Str::ucfirst(Str::lower($modelName));
        $this->modelClass = "Src\\Models\\$this->modelName";

        //initialisation des donnée
        $instance = new $this->modelClass;
        $table = $instance->getTable();
        $this->allowedcolumns = config("exports.$this->modelName", []);

        $this->selectedcolumns = array_keys($this->allowedcolumns);

        $this->columns = array_values(array_filter(Schema::getColumnListing($table), fn($col) => array_key_exists($col, $this->allowedcolumns)));

        $this->filename = "{$this->modelName}-export";
        $this->data = $this->modelClass::all();
    }

    public function prepareExportData($modelName, $columns = [])
    {
        $this->modelName = $modelName ?: $this->modelName;
        $this->columns = $columns ?: $this->columns;
    }

    public function export()
    {
        $this->validate([
            'selectedFormat' => 'required|in:excel,csv,pdf,json,xml',
            'selectedcolumns' => 'required|array|min:1',
        ]);

        $this->exporting = true;
        $this->exportSuccess = false;
        $this->exportMessage = '';

        try {
            $filename = $this->filename . '_' . now()->format('Y-m-d_H-i-s');

            switch ($this->selectedFormat) {
                case 'excel':
                    return $this->exportExcel($filename);

                case 'csv':
                    return $this->exportCsv($filename);

                case 'pdf':
                    return $this->exportPdf($filename);

                case 'json':
                    return $this->exportJson($filename);

                case 'xml':
                    return $this->exportXml($filename);
            }

        } catch (\Exception $e) {
            $this->exportMessage = 'Erreur lors de l\'export: ' . $e->getMessage();
            $this->exportSuccess = false;
        } finally {
            $this->exporting = false;
        }
    }

    protected function exportExcel($filename)
    {
        $export = new GlobalExport($this->modelName, $this->selectedcolumns);
        return Excel::download($export, $filename . '.xlsx');
    }

    protected function exportCsv($filename)
    {
        $export = new GlobalExport($this->modelName, $this->selectedcolumns);
        return Excel::download($export, $filename . '.csv', \Maatwebsite\Excel\Excel::CSV);
    }

    protected function exportPdf($filename)
    {
        $data = $this->modelClass::select($this->selectedcolumns)->get()->toArray();
        $labels = config("exports.$this->modelName", []);
        $pdf = Pdf::loadView('exports.pdf-template', [
            'data' => $data,
            'columns' => $this->selectedcolumns,
            'labels' => $labels,
            'title' => 'Export de données'
        ])->setPaper('a4', 'portrait');

        return response()->streamDownload(
            fn () => print($pdf->output()),
            $filename . '.pdf'
        );
    }

    protected function exportJson($filename)
    {
        $json = json_encode($this->data->toArray(), JSON_PRETTY_PRINT);

        return response()->streamDownload(
            fn () => print($json),
            $filename . '.json'
        );
    }

    protected function exportXml($filename)
    {
        $xml = new \SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><data></data>');

        foreach ($this->data as $item) {
            $row = $xml->addChild('row');
            foreach ($item as $key => $value) {
                // Nettoyer le nom de la balise pour XML
                $cleanKey = preg_replace('/[^a-zA-Z0-9_]/', '_', $key);
                $row->addChild($cleanKey, htmlspecialchars($value));
            }
        }

        return response()->streamDownload(
            fn () => print($xml->asXML()),
            $filename . '.xml'
        );
    }


    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }

    public function render()
    {
        return view('mt::livewire.modals.data-exporter-modal');
    }
}
