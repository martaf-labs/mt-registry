<?php

namespace Mt\MtUi\Livewire\Indexes;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Relation;

/**
 * Classe de base pour tous les Index Objects.
 * Définit la structure et la configuration des pages d'index.
 */
abstract class GenericIndex
{
    /**
     * Contexte d'exécution injecté par BaseIndex à chaque délégation
     * (filtres actifs du panneau, valeurs saisies, recherche). Permet des
     * colonnes/statistiques CONTEXTUELLES (ex. totaux de la classe filtrée,
     * grille tarifaire du niveau sélectionné).
     */
    protected array $context = [];

    public function withContext(array $context): static
    {
        $this->context = $context;
        return $this;
    }

    /** Valeur d'un filtre ACTIF du panneau (ou null). Ex. $this->contextFilter('class_id'). */
    protected function contextFilter(string $key)
    {
        return $this->context['activeFilters'][$key] ?? null;
    }

    /**
     * Définit la classe du modèle Eloquent associée à cet index.
     * @return string
     */
    abstract public static function modelClass(): string;

    /**
     * Contient la définition de la configuration de l'index.
     * @return array
     */
    abstract public function configuration(): array;

    /**
     * Obtenir les statistiques spécifiques à l'entité.
     * @return array
     */
    public function getStatistics(): array
    {
        try {
            $modelClass = $this->modelClass();
            $total = $modelClass::count();

            return [
                [
                    'label' => 'Total',
                    'value' => $total,
                    'icon' => 'rectangle-stack',
                    'color' => 'primary'
                ]
            ];
        } catch (\Exception $e) {
            return [];
        }
    }

    public function rowActions($row) : array
    {
        return $this->rowActions($row);
    }

    /**
     * Obtenir les options de filtre pour la vue.
     * @return array
     */
    public function getFilterOptions(): array
    {
        return [];
    }

    /**
     * Appliquer les filtres dynamiques à la requête.
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param array $activeFilters
     * @return void
     */
    public function applyFilters($query, array $activeFilters): void
    {
        // À implémenter dans les classes enfants si nécessaire
    }

    /**
     * Obtenir la configuration des filtres disponibles.
     * @return array
     */
    public function getFiltersConfig(): array
    {
        return [];
    }

    /**
     * Obtenir le titre d'une entité donnée.
     */
    public function getEntityTitle($item, $itemField): string
    {
        if (is_null($itemField)) {
            return 'N/A';
        }

        // Cas des champs imbriqués
        if (Str::contains($itemField, '.')) {
            $segments = explode('.', $itemField);
            $current = $item;

            foreach ($segments as $field) {
                if (is_null($current)) {
                    return 'N/A';
                }

                if ($current instanceof Model) {
                    // Attribut direct
                    if (array_key_exists($field, $current->getAttributes())) {
                        $current = $current->getAttribute($field);
                    }
                    // Relation Eloquent
                    elseif (method_exists($current, $field) && $current->$field() instanceof Relation) {
                        $current = $current->$field;
                    }
                    // Méthode personnalisée
                    elseif (method_exists($current, $field)) {
                        $current = $current->$field();
                    }
                    else {
                        return 'N/A';
                    }
                }
                elseif (is_array($current) || $current instanceof \Illuminate\Support\Collection) {
                    $current = $current[$field] ?? 'N/A';
                }
                else {
                    return 'N/A';
                }
            }

            return is_string($current) ? Str::ucfirst($current) : 'N/A';
        }
        // Cas simple
        $value = method_exists($item, $itemField) ? $item->$itemField() : ($item->$itemField ?? null);
        return !empty($value) ? (string) Str::ucfirst($value) : 'N/A';
    }

    /**
     * Obtenir le sous-titre d'une entité donnée.
     */
    public function getEntitySubtitle($item, $itemField): string
    {
        $subtitleFields = $itemField ?? [];

        if (empty($subtitleFields)) {
            return '';
        }

        $parts = [];

        foreach ($subtitleFields as $field) {
            if (Str::contains($field, '.')) {
                $segments = explode('.', $field);
                $relationName = array_shift($segments);
                $related = null;

                // Vérifier si c'est une relation Eloquent
                if (method_exists($item, $relationName) && $item->$relationName() instanceof Relation) {
                    $related = $item->$relationName;
                } else {
                    // Sinon, c'est peut-être un attribut direct
                    $related = $item->$relationName ?? null;
                }

                if ($related instanceof Model) {
                    foreach ($segments as $relatedField) {
                        $value = $this->getFieldValue($related, $relatedField);

                        if (!is_null($value)) {
                            $parts[] = $this->normalizeValue($value);
                        }
                    }
                }
                continue;
            }

            // Champ direct sur l'item principal
            $value = $this->getFieldValue($item, $field);

            if (!is_null($value)) {
                $parts[] = $this->normalizeValue($value);
            }
        }

        return implode(' • ', $parts);
    }

    /**
     * Obtenir la valeur d'un champ de manière sécurisée
     */
    private function getFieldValue($model, $field)
    {
        // 1. Vérifier si c'est une relation Eloquent
        if (method_exists($model, $field) && $model->$field() instanceof Relation) {
            return $model->$field;
        }

        // 2. Vérifier si c'est un accesseur (méthode qui retourne une valeur)
        if (method_exists($model, $field) && !($model->$field() instanceof Relation)) {
            // Vérifier que ce n'est pas une relation avant d'appeler
            try {
                $result = $model->$field();
                // Si c'est un Model, c'est probablement une relation qu'on n'a pas détectée
                if ($result instanceof Model || $result instanceof \Illuminate\Database\Eloquent\Collection) {
                    return null;
                }
                return $result;
            } catch (\Exception $e) {
                return null;
            }
        }

        // 3. Vérifier si c'est un attribut direct
        if (isset($model->$field) || (is_object($model) && property_exists($model, $field))) {
            return $model->$field;
        }

        // 4. Vérifier si c'est un accesseur Eloquent (getFieldAttribute)
        $accessorMethod = 'get' . Str::studly($field) . 'Attribute';
        if (method_exists($model, $accessorMethod)) {
            return $model->$field;
        }

        return null;
    }

    /**
     * Normaliser une valeur pour l'affichage.
     */
    private function normalizeValue($value): string
    {
        if (is_null($value)) {
            return '';
        }

        if (is_array($value)) {
            return implode(', ', array_filter($value));
        }

        if ($value instanceof \Illuminate\Support\Collection) {
            return $value->filter()->join(', ');
        }

        if ($value instanceof Model) {
            // Ne pas afficher les modèles directement
            return '';
        }

        if (is_object($value) && method_exists($value, '__toString')) {
            return (string) $value;
        }

        if (is_object($value)) {
            // Ne pas afficher les objets non-stringifiables
            return '';
        }

        return (string) Str::ucfirst($value);
    }
    /**
     * Obtenir l'image d'une entité donnée.
     */
    public function getEntityImage($item, $itemField): string
    {
        if (is_null($itemField)) {
            return '';
        }

        $value = $this->getEntityTitle($item, $itemField);
        return $value !== 'N/A' ? $value : '';
    }
}
