<?php

namespace Mt\MtUi\Livewire;

use Livewire\Component;

/**
 * Dashboard générique mt-ui
 *
 * Ce composant est conçu pour être ÉTENDU par le projet hôte.
 * Il ne contient aucune logique métier - tout est défini via les méthodes
 * que le projet hôte surcharge dans sa propre classe Dashboard.
 *
 * ──────────────────────────────────────────────────────────────────────────
 * USAGE DANS LE PROJET HÔTE
 * ──────────────────────────────────────────────────────────────────────────
 *
 * 1. Créer App\Livewire\Dashboard qui étend \Mt\MtUi\Livewire\Dashboard
 * 2. Surcharger les méthodes nécessaires
 * 3. Enregistrer le composant dans AppServiceProvider :
 *
 *    Livewire::component('mt.dashboard', \App\Livewire\Dashboard::class);
 *
 * ──────────────────────────────────────────────────────────────────────────
 * STRUCTURE getStats()
 * ──────────────────────────────────────────────────────────────────────────
 * [
 *   'label'       => 'Utilisateurs',
 *   'value'       => 42,
 *   'icon'        => 'fa-solid fa-users',
 *   'color'       => 'primary',       // primary|success|warning|danger|info|gray
 *   'change'      => '+12%',          // optionnel
 *   'changeType'  => 'positive',      // positive|negative|neutral
 *   'details'     => [                // optionnel - badges sous la valeur
 *       ['label' => 'En ligne', 'value' => 5],
 *   ],
 *   'route'       => 'users.index',   // optionnel - clic sur la carte
 * ]
 *
 * ──────────────────────────────────────────────────────────────────────────
 * STRUCTURE getWidgets()
 * ──────────────────────────────────────────────────────────────────────────
 * Types disponibles : list | chart | activity | stat_group | progress | custom
 *
 * Propriétés communes :
 *   'type'     → type du widget
 *   'title'    → titre affiché
 *   'subtitle' → optionnel
 *   'span'     → colonnes sur 3 (1, 2 ou 3)
 *   'data'     → données (format selon type)
 *   'actions'  → ['label' => '...', 'route' => '...'] ou 'method'
 *   'footer'   → texte de pied de widget
 *
 * Type 'list' - item :
 *   'title', 'meta', 'image'|'icon'|'initials', 'badge', 'value', 'route', 'route_params'
 *
 * Type 'chart' - Chart.js :
 *   'chart_type' → 'line'|'bar'|'doughnut'|'pie'|'radar'
 *   'height'     → ex: '260px'
 *   'legend'     → bool
 *   'data'       → { labels: [...], datasets: [...] }
 *
 * Type 'activity' - item :
 *   'icon', 'text' (HTML), 'time', 'badge'
 *
 * Type 'progress' - item :
 *   'label', 'percent' (0-100), 'color', 'value', 'meta', 'icon'
 *
 * Type 'stat_group' - item :
 *   'label', 'value', 'icon', 'badge'
 *
 * Type 'custom' :
 *   'view'      → nom de la vue Blade
 *   'view_data' → données passées à la vue
 */
class MtDashboard extends BaseAppComponent
{
    public string $greeting = '';

    public function mount(): void
    {
        $hour = now()->hour;
        $this->greeting = match(true) {
            $hour < 12 => __('mt-ui::mt-ui.greeting_morning'),
            $hour < 18 => __('mt-ui::mt-ui.greeting_afternoon'),
            default    => __('mt-ui::mt-ui.greeting_evening'),
        };
    }

    /**
     * Titre affiché dans le header du dashboard.
     */
    public function getTitle(): string
    {
        return 'Tableau de bord';
    }

    /**
     * Sous-titre / description du dashboard.
     */
    public function getSubtitle(): string
    {
        return 'Aperçu général de votre activité';
    }

    /**
     * Actions rapides affichées en haut à droite.
     *
     * @return array<int, array{label: string, icon: string, route?: string, method?: string, variant?: string}>
     */
    public function getQuickActions(): array
    {
        return [];
    }

    /**
     * Cartes de statistiques - max 8 recommandé (grille auto 2/3/4 cols).
     *
     * @return array<int, array>
     */
    public function getStats(): array
    {
        return [];
    }

    /**
     * Widgets du dashboard.
     * Chaque widget a un 'span' (1|2|3) pour la largeur dans la grille de 3 colonnes.
     *
     * @return array<int, array>
     */
    public function getWidgets(): array
    {
        return [];
    }

    /**
     * HERO (point d'extension) : vue mise en avant EN TÊTE du dashboard (avant les stats),
     * fournie par le projet hôte. Neutre par défaut (aucun hero).
     * Retour attendu : ['view' => 'ma.vue', 'data' => [...]] (rendue via @include) ou null/[].
     *
     * @return array{view?: string, data?: array}
     */
    public function getHero(): array
    {
        return [];
    }

    /**
     * Nombre de colonnes pour la grille de stats.
     * Surcharger si tu veux forcer un nombre fixe.
     */
    public function getStatsColumns(): int
    {
        $count = count($this->getStats());
        return match(true) {
            $count <= 2 => 2,
            $count <= 3 => 3,
            $count <= 6 => 3,
            default     => 4,
        };
    }

    public function render()
    {
        $stats   = $this->getStats();
        $widgets = $this->getWidgets();

        return view('mt::livewire.mt-dashboard', [
            'title'        => $this->getTitle(),
            'subtitle'     => $this->getSubtitle(),
            'quickActions' => $this->getQuickActions(),
            'stats'        => $stats,
            'widgets'      => $widgets,
            'statsCols'    => $this->getStatsColumns(),
            'hero'         => $this->getHero(),
        ]);
    }
}
