<?php

namespace Mt\MtUi\Livewire\Shows;

use Carbon\Carbon;
use Illuminate\Support\Str;

/**
 * Classe de base pour tous les Show Objects.
 * Définit la structure et la configuration des pages de détail.
 *
 * DEUX MODES DE RENDU (rétro-compatibles) :
 *  - LEGACY : getShowData() (fields/medias/metaDatas/actions) — conservé pour
 *    les shows existants (ex. sgni-app).
 *  - SECTIONS (recommandé, North Star) : surcharger `sections()` (+ header,
 *    actions, tabs, getStatistics) → en-tête avatar/badges, stats compactes,
 *    onglets client, sections attributes|table|view. La fiche CONSULTE —
 *    toute modification passe par base-form ou un manager.
 */
abstract class GenericShow
{
    /** Contexte d'exécution injecté par BaseShow (onglet actif, etc.). */
    protected array $context = [];

    public function withContext(array $context): static
    {
        $this->context = $context;
        return $this;
    }

    /**
     * Définit la classe du modèle Eloquent associée à ce show.
     * @return string
     */
    abstract public static function modelClass(): string;

    /**
     * Contient la définition de la configuration du show.
     * @return array
     */
    abstract public function configuration(): array;

    /* ==================== MODE SECTIONS (North Star) ==================== */

    /**
     * En-tête de la fiche :
     * ['image' => url|null, 'letters' => 'AB', 'title' => '…', 'subtitle' => '…',
     *  'badges' => [['label' => '…', 'type' => 'success'], …]].
     */
    public function header($model): array
    {
        return ['title' => (string) ($model->name ?? $model->getKey())];
    }

    /**
     * Actions d'en-tête — MÊME grammaire que les mainActions du base-index :
     * [['label','icon', 'route'|'method', 'variant', 'confirm', 'target'], …].
     */
    public function actions($model): array
    {
        return [];
    }

    /** Cartes de statistiques compactes (même rendu que base-index). Optionnel. */
    public function getStatistics($model): array
    {
        return [];
    }

    /**
     * Onglets : ['clé' => 'Libellé', …]. Tableau vide = pas d'onglets
     * (les sections s'empilent).
     */
    public function tabs(): array
    {
        return [];
    }

    /**
     * Mode « profil » (fiche de PERSONNE) : avatar rond en médaillon.
     * false ici (aperçu de CHOSE) ; GenericProfile renvoie true.
     * Doctrine : personne → GenericProfile ; chose → GenericShow.
     */
    public function isProfile(): bool
    {
        return false;
    }

    /**
     * Sections de contenu — SURCHARGER cette méthode active le mode sections.
     * Chaque section :
     *  - commun : ['tab' => 'clé', 'title' => '…', 'type' => 'attributes|table|view']
     *  - attributes : ['items' => ['Libellé' => 'valeur', …]] (null → '—')
     *  - table      : ['columns' => ['Col1', …], 'rows' => [[…], …], 'empty' => '…', 'emptyIcon' => '…']
     *  - view       : ['view' => 'ns::chemin.partial'] (reçoit $model) — échappatoire hôte
     */
    public function sections($model): array
    {
        return [];
    }

    /* ==================== MODE LEGACY (rétro-compatibilité) ==================== */

    /**
     * Obtenir les données spécifiques à l'entité.
     * @param mixed $model
     * @return array
     */
    public function getShowData($model): array
    {
        return [
            'fields' => [],
            'medias' => [],
            'metaDatas' => [],
            'actions' => []
        ];
    }

    /**
     * Formater la valeur pour l'affichage
     */
    public function formatValue($field, $value): string
    {
        $fieldType = $field['type'] ?? 'text';

        if (is_null($value) || $value === '') {
            return '<span class="italic text-zinc-400 dark:text-zinc-500">Non renseigné</span>';
        }

        // Formatage selon le type de champ
        switch ($fieldType) {
            case 'select':
                return $this->formatSelectValue($field, $value);
            case 'editor':
                return $this->formatEditorValue($value);
            case 'date':
                return $this->formatDateValue($value);
            case 'datetime':
                return $this->formatDateTimeValue($value);
            case 'boolean':
                return $this->formatBooleanValue($value);
            default:
                return e($value);
        }
    }

    /**
     * Formater les valeurs select
     */
    protected function formatSelectValue($field, $value): string
    {
        $listItems = $field['listItems'] ?? [];

        if (is_array($listItems) && isset($listItems[$value])) {
            return e($listItems[$value]);
        }

        return e($value);
    }

    /**
     * Formater les valeurs éditeur
     */
    protected function formatEditorValue($value): string
    {
        return $value; // Le contenu HTML est déjà formaté
    }

    /**
     * Formater les dates
     */
    protected function formatDateValue($value): string
    {
        if ($value instanceof \Carbon\Carbon) {
            return $value->locale('fr')->translatedFormat('j F Y');
        }

        return e($value);
    }

    /**
     * Formater les dates avec heure
     */
    protected function formatDateTimeValue($value): string
    {
        if ($value instanceof \Carbon\Carbon) {
            return $value->locale('fr')->translatedFormat('j F Y à H:i');
        }

        return e($value);
    }

    /**
     * Formater les booléens
     */
    protected function formatBooleanValue($value): string
    {
        $value = (bool) $value;

        if ($value) {
            return '<span class="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                <i class="mr-1 bi bi-check-circle"></i> Oui
            </span>';
        }

        return '<span class="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
            <i class="mr-1 bi bi-x-circle"></i> Non
        </span>';
    }

    /**
     * Obtenir les métadonnées par défaut
     */
    public function getDefaultMetaDatas($model): array
    {
        return [
            'created_at' => [
                'label' => "Créé le",
                'value' => Carbon::parse($model->created_at)->locale('fr')->translatedFormat('j F Y'),
            ],
            'created_by' => [
                'label' => "Créé par",
                'value' => $model->user->name ?? 'Système',
            ],
            'last_update' => [
                'label' => "Dernière modification",
                'value' => Carbon::parse($model->updated_at)->locale('fr')->translatedFormat('j F Y'),
            ]
        ];
    }

    /**
     * Obtenir les actions par défaut
     */
    public function getDefaultActions($model, $model_plural): array
    {
        return [
            'edit' => [
                'label' => "Modifier",
                'icon' => "pencil-square",
                'variant' => "primary",
                'route' => mt_get_route($model_plural . '_edit', ['id' => $model->id]),
            ],
            'back' => [
                'label' => "Retour à la liste",
                'icon' => "arrow-left",
                'variant' => "ghost",
                'route' => mt_get_route($model_plural . '_index'),
            ]
        ];
    }
}
