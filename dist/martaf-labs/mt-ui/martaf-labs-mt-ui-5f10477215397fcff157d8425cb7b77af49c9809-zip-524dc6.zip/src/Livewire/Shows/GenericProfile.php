<?php

namespace Mt\MtUi\Livewire\Shows;

/**
 * Fiche de PERSONNE (base-profile) : spécialisation de GenericShow pour les
 * entités humaines (élève, personnel, tuteur, membre…). Même moteur de rendu
 * (en-tête + onglets + sections + actions), avec l'identité visuelle « profil » :
 * avatar photo/initiales en médaillon rond.
 *
 * Doctrine : PERSONNE → GenericProfile/BaseProfile ; CHOSE (classe, projet,
 * équipement…) → GenericShow/BaseShow. Les évolutions propres aux personnes
 * (badge imprimable, compte portail, timeline d'activité…) vivent ICI —
 * jamais dans GenericShow.
 */
abstract class GenericProfile extends GenericShow
{
    public function isProfile(): bool
    {
        return true;
    }
}
