<?php

namespace Mt\MtUi\Livewire\Base;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\On;
use Livewire\Component;
use Livewire\WithFileUploads;
use Mt\MtUi\Contracts\HasBaseFormContract;
use Mt\MtMedia\Contracts\ImageOptimizerContract;
use Mt\MtFoundation\Helpers\MtLocale;
use Mt\MtUi\Livewire\BaseAppComponent;
use Mt\MtUi\Traits\WithFormSteps;

/**
 * Composant de base générique pour gérer les formulaires mono et multi-étapes.
 */

abstract class BaseForm extends BaseAppComponent
{
    use WithFileUploads, WithFormSteps;

    // Définitions abstraites, HasPersistentImages
    abstract public function formClass(): string;
    abstract public function getModelName(): string;
    abstract public function getPluralModelName(): string;
    abstract public function getRedirectRouteName(): string;
    abstract public function getModelNavItems($data = null): array;

    /** @var \Src\Livewire\Forms\GenericForm */
    public $form;
    public $modelClass  = null;
    public ?int $id = null;
    public string $mode = 'create';
    public bool $isSubmitting = false;
    public $persistent_images = []; //Propriété pour les images persistantes (temporaire pour upload)
    public $existing_images = []; //Propriété pour les images existantes (édition)
    public bool $optimizeImages = true; // ← persiste entre requêtes Livewire


    public function fieldActions() : array
    {
        // method_exists (pas instanceof) : GenericForm fournit fieldActions() sans
        // implémenter le contrat → le garde instanceof renvoyait toujours [] et
        // cassait la détection des champs déclencheurs (.live) côté blade.
        if (is_object($this->form) && method_exists($this->form, 'fieldActions')) {
            return $this->form->fieldActions();
        }
        return [];
    }

    public function mount(?int $id = null): void
    {
        $this->id = $id;
        $this->mode = is_numeric($this->id) ? 'edit' : 'create';

        // 1. Instanciation du Form Object
        $formClass = $this->formClass();
        $this->form = new $formClass($this, 'form');
        $this->modelClass = $this->form->modelClass();

        if (!is_null($this->modelData())) {
            $this->form->fillModel($this->modelData());
        }

        // Point d'extension : données additionnelles hors form-object (ex. EAV).
        $this->hydrateExtra($this->modelData());

        // 3. Initialiser l'état des étapes
        $this->hasSteps = count($this->steps()) > 1;
        $this->initializeAvailableSteps();
    }

    /**
     * Bag générique pour des champs additionnels NON portés par le form-object
     * (ex. champs personnalisés EAV de l'hôte). Liable en vue via `extraData.<clé>`.
     */
    public array $extraData = [];

    /**
     * Point d'extension : sections de champs supplémentaires à afficher après le
     * schéma principal. Vide par défaut (aucun impact pour les hôtes qui n'override pas).
     *
     * Format attendu : [
     *   ['title' => ?string, 'description' => ?string, 'fields' => [
     *       ['name' => 'extraData.<clé>', 'label' => '…', 'type' => 'text|textarea|number|
     *        date|email|toggle|select', 'required' => bool, 'options' => [val=>label],
     *        'multiple' => bool, 'hint' => ?string],
     *   ]],
     * ]
     */
    public function extraSections(): array
    {
        return [];
    }

    /** Hook : hydrater `extraData` depuis le modèle en édition. No-op par défaut. */
    protected function hydrateExtra(?Model $model): void
    {
    }

    /** Hook : persister `extraData` après l'enregistrement du modèle. No-op par défaut. */
    protected function persistExtra(Model $model): void
    {
    }

    #[Computed]
    public function modelData() : ?Model
    {
        $modelData = null;  //attention , en mode 'create', $modelData doit etre "null"
        // 2. Hydratation en mode édition
        if ($this->mode === 'edit') {
            $modelData = $this->modelClass::findOrFail($this->id);
        }
        return $modelData;
    }

    #[Computed]
    public function navItems() : array
    {
        return $this->getModelNavItems($this->modelData());
    }

    /**
     * Formater les attributs du formulaire si néccessaire
     * @return void
     */
    public function formatFormAttributes()
    {
        
    }

    /**
     * Recupere les règles de validation d'un champ
     */
    public function getRules($field = null)
    {
        if(is_null($field)) {
            return $this->form->rules();
        }
        else{
            return $this->form->rules()[$field] ?? '';
        }
    }

    /**
     * Vérifie si un champ est requis
     */
    public function isRequired($field)
    {
        $allRules=$this->form->rules();

        if($this->hasSteps) {
            $allRules=$this->getStepRules($this->currentStep);
            $field='form.'.$field;
        }

        if(is_null($field) || !in_array($field, array_keys($allRules))) {
            return false;
        }
        else{
            $fieldRules = $allRules[$field];
            return Str::contains(is_array($fieldRules) ? implode('|',$fieldRules) : $fieldRules, 'required');
        }
    }

    /**
     * Mise à jour des champs de select entity
     */
    #[On('entity-selected')]
    public function updateEntity($fields)
    {
        foreach ($fields as $field => $value) {
            $this->form->$field = $value;
        }
    }

    /**
     * Obtient les champs à afficher pour l'étape/rénder actuel
     */
    public function getFieldsToDisplay(): array
    {
        $fields = $this->getCurrentStepFields();

        $availableLocales = get_available_locales();

        // Attributs traduisibles (JSON) - détectés depuis le modèle édité OU,
        // en création, depuis la classe du modèle. Tout champ traduisible est
        // automatiquement rendu en multilingue, sans déclaration dans le schema.
        $translatables = $this->resolveTranslatables();

        foreach ($fields as $key => $value) {
            // Multilingue si : (a) champ traduisible du modèle (auto) OU
            // (b) 'multilingual' => true déclaré dans le schema (explicite — utile quand
            // le champ est traduisible sur un AUTRE modèle que celui du form, ex. les noms
            // de l'enseignant portés par StaffMember alors que le form pilote Teacher).
            $isMultilingual = in_array($key, $translatables, true) || ($value['multilingual'] ?? false) === true;
            if (! $isMultilingual) {
                continue;
            }

            $fields[$key]['multilingual'] = true;

            // Initialise le champ JSON en tableau de locales s'il ne l'est pas déjà
            if (! is_array($this->form->$key ?? null)) {
                $init = [];
                foreach ($availableLocales as $lang => $options) {
                    $init[$lang] = '';
                }
                $this->form->$key = $init;
            }
        }

        return $fields;
    }

    /**
     * Liste des attributs traduisibles du modèle (instance en édition, classe en création).
     */
    protected function resolveTranslatables(): array
    {
        $model = $this->modelData();
        if ($model && method_exists($model, 'getTranslatables')) {
            return $model->getTranslatables();
        }

        if ($this->modelClass && is_subclass_of($this->modelClass, \Illuminate\Database\Eloquent\Model::class)) {
            try {
                $instance = new $this->modelClass;
                if (method_exists($instance, 'getTranslatables')) {
                    return $instance->getTranslatables();
                }
            } catch (\Throwable) {
                // ignore
            }
        }

        return [];
    }

    /**
     * Quand un champ est modifié
     */
    public function updatedForm($value, $key)
    {
        // Exécuter les actions Livewire si configurées
        if (!is_null($key)){
            $this->executeLivewireActions($key, $value);
        }

        // Émettre un événement pour Alpine.js
        $this->dispatch('field-updated',
            field: $key,
            value: $value,
            actions: $this->form->fieldActions()[$key] ?? []
        );

        // Gestion des étapes conditionnelles
        $this->handleStepConditions($key);
    }

    /**
     * Exécuter les actions côté Livewire
     */
    protected function executeLivewireActions(string $field = null, $value): void
    {
        if (is_null($field)) {
            return;
        }

        $actions = $this->form->fieldActions()[$field] ?? [];

        foreach ($actions as $action) {
            $this->executeLivewireAction($action, $field, $value);
        }
    }

    /**
     * Exécuter une action Livewire
     */
    protected function executeLivewireAction(array $action, string $field, $value): void
    {
        $type = $action['type'] ?? '';
        $target = $action['target'] ?? '';

        switch ($type) {
            case 'set':
                if ($target && isset($action['value'])) {
                    $this->form->{$target} = $action['value'];
                }
                break;

            case 'map':
                if ($target && isset($action['map'][$value])) {
                    $this->form->{$target} = $action['map'][$value];
                }
                break;

            case 'clear':
                if ($target) {
                    $this->form->{$target} = null;
                }
                break;

            case 'copy':
                if ($target) {
                    $this->form->{$target} = $value;
                }
                break;
        }
    }

    /**
     * Gérer les conditions des étapes
     */
    protected function handleStepConditions(?string $field): void
    {
        if(is_null($field)){
            return;
        }

        $criticalFields = method_exists($this->form, 'getCriticalFields') ? $this->form->getCriticalFields() : [];

        if (in_array($field, $criticalFields)) {
            $this->initializeAvailableSteps();

            // Recalculer les étapes virtuelles disponibles
            $availableVirtualSteps = array_keys($this->getStepsToDisplay());

            // Si l'étape courante n'est plus dans les étapes disponibles, aller à la prochaine
            if (!in_array($this->currentStep, $availableVirtualSteps)) {
                // Prendre la première étape disponible >= currentStep, sinon la dernière
                $next = collect($availableVirtualSteps)->first(fn($s) => $s >= $this->currentStep);
                $this->currentStep = $next ?? (count($availableVirtualSteps) > 0 ? end($availableVirtualSteps) : 1);
            }

            $this->dispatch('steps-updated');
        }
    }

    /**
     * Méthode de soumission qui délègue la sauvegarde au Form Object.
     */
    public function save()
    {
        $this->dispatch('form-submitting');
        
        // reconvertit vers format DB
        // $this->dehydrateDatesToModel($this->modelData());

        // Valider l'étape actuelle ou tout le formulaire
        if (!$this->validateStep($this->currentStep)) {
            $this->dispatch('form-submit-failed');
            return;
        }

        try {
            $savedItem = $this->form->save($this->modelData());

            if ($savedItem) {
                // Point d'extension : persister les données additionnelles (ex. EAV).
                if ($savedItem instanceof Model) {
                    $this->persistExtra($savedItem);
                }

                if ($this->mode === 'edit') {
                    showAlert('success', 'Élément modifié avec succès!');
                } else {
                    showAlert('success', 'Élément créé avec succès!');
                }
                
            }
            
            // session()->flash('success', $this->mode === 'edit' ?
            //     "{$this->getModelName()} mis à jour avec succès !" :
            //     "{$this->getModelName()} créé avec succès !"
            // );

            // Redirection vers la route d'index
            return $this->redirectRoute($this->getRedirectRouteName(), navigate: true);

        } catch (\Exception $e) {
            $this->dispatch('form-submit-failed');
            session()->flash('error', "Erreur : " . $e->getMessage());
        }
    }

    
    //**___________________________________


    /**
     * Méthode pour enregistrer et continuer (uniquement multi-step)
     */
    public function saveAndContinue()
    { 
        $this->isSubmitting = true;
        if ($this->hasMultipleSteps() && $this->validateStep($this->currentStep)) {
            $this->nextStep();
        } 
        $this->isSubmitting = false;
        // dd($this->isSubmitting);
    }

    public function render()
    {
        $title = $this->mode === 'edit'
            ? __('mt-ui::mt-ui.edit') . ' ' . $this->getModelName()
            : __('mt-ui::mt-ui.create') . ' ' . $this->getModelName();

        return view('mt::livewire.base.base-form', [
            'title'           => $title,
            'description'     => '',
            'schema'          => $this->form->schema(),
            'displayFields'   => $this->getFieldsToDisplay(),
            'hasMultipleSteps'=> $this->hasMultipleSteps(),
            'stepsToDisplay'  => $this->getStepsToDisplay(),
        ])->title($title);
    }
}
