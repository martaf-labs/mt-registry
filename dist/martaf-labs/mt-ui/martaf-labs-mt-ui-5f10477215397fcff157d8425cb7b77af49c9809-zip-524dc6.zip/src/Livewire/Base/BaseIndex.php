<?php

namespace Mt\MtUi\Livewire\Base;

use ReflectionMethod;
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\Attributes\On;
use Livewire\WithPagination;
use Livewire\Attributes\Layout;
use Mt\MtUi\Livewire\BaseAppComponent;
use Mt\MtFoundation\Traits\InteractsWithOverrides;
use Mt\MtUi\Contracts\HasBaseIndexContract;

abstract class BaseIndex extends BaseAppComponent
implements HasBaseIndexContract
{
    use WithPagination, InteractsWithOverrides;

    // États partagés
    public $loading = false;
    public $selectedItemId = null;
    public $showActionMenu = null;
    public $flashMessage = '';
    public $flashType = '';

    // États de l'interface
    public $search = '';
    public $perPage = 20;
    public $sortDirection = 'desc';
    public $sortBy = 'id';

    // Configuration extraite de l'index object
    public $model;
    public $model_plural;
    public $modelClass;
    public $title = '';
    public $navItems = null;
    public $firstColumn = [];
    public $hiddenColumns = [];
    public $othersColumns = [];
    public $features = [];
    public $mainActions = [];
    public $exportAction = true;
    public $exportDatas = [];
    public $filters = [];
    public $sortableFields = [];
    public $searchableFields = [];
    public ?string $modelType = null;
    public ?int $modelId = null;

    // Filtres dynamiques (panneau « Filtres » du base-index)
    public bool $showFilters = false;      // état ouvert/fermé du panneau (@entangle)
    public array $filterValues = [];       // valeurs saisies (différées, appliquées au clic)
    public array $activeFilters = [];      // filtres réellement appliqués à la requête

    // Écouteurs d'événements
    // protected $listeners = [
    //     'item-created' => 'handleItemCreated',
    //     'item-updated' => 'handleItemUpdated',
    //     'item-deleted' => 'handleItemDeleted',
    //     'refresh-data' => '$refresh',
    //     'openExportIndexData' => 'exportIndexData',
    // ];

    abstract public function indexClass(): string;

    // Méthode pour obtenir l'instance de l'index (créée à la volée).
    // Le CONTEXTE (filtres actifs, recherche) est injecté à chaque délégation :
    // l'Index Object peut produire des colonnes/stats contextuelles (contextFilter()).
    private function getIndexInstance()
    {
        $indexClass = $this->indexClass();

        return (new $indexClass())->withContext([
            'activeFilters' => $this->activeFilters,
            'filterValues'  => $this->filterValues,
            'search'        => $this->search,
        ]);
    }

    //Methodes de l'interface HasBaseIndexContract par défaut

    public function getNavItems() : array
    {
        $indexInstance = $this->getIndexInstance();
        return ($this->methodIsOverriden('getNavItems', BaseIndex::class, $indexInstance)) ? $indexInstance->getNavItems() : [];
    }

    public function mainActions() : array
    {
        $indexInstance = $this->getIndexInstance();
        return ($this->methodIsOverriden('mainActions', BaseIndex::class, $indexInstance)) ? $indexInstance->mainActions() : [];
    }

    public function rowActions($rowId) : array
    {
        $indexInstance = $this->getIndexInstance();
        return ($this->methodIsOverriden('rowActions',BaseIndex::class, $indexInstance)) ? $indexInstance->rowActions($rowId) : [];
    }

    public function columns($rowId=null) : array
    {
        $indexInstance = $this->getIndexInstance();
        return ($this->methodIsOverriden('columns',BaseIndex::class, $indexInstance)) ? $indexInstance->columns($rowId) : [];
    }

    public function mount(): void
    {
        // 1. Instanciation de l'Index Object et extraction de la configuration
        $indexInstance = $this->getIndexInstance();
        $config = $indexInstance->configuration();
        $this->model = $config['model'];
        $this->model_plural = $config['model_plural'];
        $this->modelClass = $indexInstance->modelClass();
        $this->title = $config['title'];
        $this->navItems = empty($this->getNavItems()) ? navItems($this->model, $config['mainLabel'])->get() : $this->getNavItems();
        //columns

        $this->firstColumn = $config['firstColumn'] ?? [];
        $this->othersColumns = $config['othersColumns'] ?? [];
        $this->hiddenColumns = $config['hiddenColumns'] ?? [];
        $this->features = $config['features'] ?? [];

        $this->filters = $config['filters'] ?? [];
        $this->sortableFields = $config['sortableFields'] ?? [];
        $this->searchableFields = $config['searchableFields'] ?? [];

        // 2. Application des configurations par défaut
        $this->perPage = $this->features['perPage'] ?? 20;
        $this->sortBy = $this->features['defaultSort'] ?? 'id';
        $this->sortDirection = $this->features['defaultSortDirection'] ?? 'desc';

        // initialisation des actions
        $this->initMainActions();
        $this->initDefaultColumns();

        // Filtres par défaut de l'écran (hook du composant hôte, re-posés au reset).
        if ($defaults = $this->defaultFilters()) {
            $this->filterValues  = $defaults;
            $this->activeFilters = array_filter($defaults, fn ($v) => $v !== '' && $v !== null && $v !== []);
        }
    }

    /**
     * Filtres PAR DÉFAUT de l'écran (ex. un filtre `required` : la classe du
     * caissier, le niveau de la grille tarifaire). Posés au mount ET re-posés
     * par resetAllFilters. À surcharger dans le composant hôte. Pour un défaut
     * « souple » (posé au mount mais effaçable au reset), surcharger mount()
     * à la place.
     */
    protected function defaultFilters(): array
    {
        return [];
    }

    #[On('refresh')]
    public function refreshData()
    {
        return $this->getItemsQuery();
    }

    /**
     * Revenir à la page 1 quand la recherche ou la taille de page change
     * (sinon on reste sur une page hors bornes → résultats vides).
     */
    public function updatingSearch(): void
    {
        $this->resetPage();
    }

    public function updatingPerPage(): void
    {
        $this->resetPage();
    }

    /**
     * Gestion des événements
     */
    #[On('item-created')]
    public function handleItemCreated($data)
    {
        showAlert('success', 'Élément créé avec succès!');
    }

    #[On('item-updated')]
    public function handleItemUpdated($data)
    {
        showAlert('success', 'Élément modifié avec succès!');
    }

    #[On('item-deleted')]
    public function handleItemDeleted($data)
    {
        showAlert('success', 'Élément supprimé avec succès!');
    }

    public function initMainActions()
    {
        // traitement des actions
        $allMainActions=$this->mainActions();

        $this->mainActions = $allMainActions['custom'] ?? [];

        if ($allMainActions['create'] ?? false) {
            $this->mainActions['create'] = [
                'label' => 'Nouveau',
                'icon' => 'plus',
                'route' => mt_get_route($this->model_plural . '_create'),
                'variant' => 'primary',
            ];
        }  

        if ($allMainActions['export'] ?? false) {
            $this->mainActions['export'] = [
                'label' => 'Exporter',
                'icon' => 'download',
                'method' => 'openExportIndexData',
                'variant' => 'outline',
            ];
            $this->exportAction = true;
        }  
    }

    public function getRowActions($rowId) : array
    {
        // traitement des actions
        $allRowActions=$this->rowActions($rowId);

        $rowActions = $allRowActions['custom'] ?? [];

        if ($allRowActions['edit'] ?? false) {
            $rowActions['edit'] = [
                'type' => 'route',
                'label' => 'Modifier',
                'icon' => 'pencil',
                'route' => mt_get_route($this->model_plural. '_edit', ['id' => $rowId]),
            ];
        }  

        if ($allRowActions['image-manager'] ?? false) {
            $rowActions['image-manager'] = [
                'type' => 'livewire',
                'label' => 'Gerer les images',
                'icon' => 'images',
                // 'variant' => 'secondary',
                'method' => "openImageManager",
                'params' => $rowId,
            ];
        }  

        if ($allRowActions['delete'] ?? false) {
            $rowActions['delete'] = [
                'type' => 'livewire',
                'label' => 'Supprimer',
                'icon' => 'trash-x',
                'variant' => 'danger',
                // Confirmation NATIVE (wire:confirm) → fiable, sans modale cross-composant
                // (l'ancien confirmDelete → open-confirm-modal se bloquait par désync open/isOpen).
                'method' => "deleteConfirmed",
                'params' => $rowId,
                'confirm' => __('mt-ui::mt-ui.delete_confirm'),
            ];
        }

        return $rowActions;
        
    }

    /**
     * Initialiser les colone par defaut
     * Il s'agit des colonne de la premiere ligne du tableau
     * @return void
     */
    public function initDefaultColumns()
    {
        $columns=$this->columns();

        $this->firstColumn = $columns['firstColumn'] ?? [];
        $this->hiddenColumns = $columns['hiddenColumns'] ?? [];
        $this->othersColumns = $columns['othersColumns'] ?? [];
        
    }

    /**
     * Délégation des méthodes à l'Index Object
     */
    public function getEntityTitle($item, $field)
    {
        return $this->getIndexInstance()->getEntityTitle($item, $field);
    }

    public function getEntitySubtitle($item, $fields)
    {
        return $this->getIndexInstance()->getEntitySubtitle($item, $fields);
    }

    public function getEntityImage($item, $field)
    {
        return $this->getIndexInstance()->getEntityImage($item, $field);
    }

    /**
     * Obtenir les statistiques
     */
    public function getStatistics()
    {
        return $this->getIndexInstance()->getStatistics();
    }

    /* ==================== Filtres dynamiques (panneau « Filtres ») ==================== */

    /**
     * Configuration des filtres disponibles, fournie par l'Index Object
     * (getFiltersConfig), avec fusion des options dynamiques (getFilterOptions).
     */
    public function getAvailableFilters(): array
    {
        $indexInstance = $this->getIndexInstance();
        $available = $indexInstance->getFiltersConfig();

        foreach ($indexInstance->getFilterOptions() as $key => $options) {
            if (isset($available[$key])) {
                $available[$key]['options'] = $options;
            }
        }

        return $available;
    }

    /**
     * Clés de filtre AUTORISÉES (liste blanche) : uniquement celles déclarées
     * par l'Index Object (+ variantes _min/_max des ranges). Les valeurs de
     * filterValues étant contrôlables côté client, on n'applique JAMAIS une
     * clé non déclarée à la requête.
     */
    protected function allowedFilterKeys(): array
    {
        $keys = [];
        foreach (array_keys($this->getAvailableFilters()) as $key) {
            $keys[] = $key;
            $keys[] = $key . '_min';
            $keys[] = $key . '_max';
        }

        return $keys;
    }

    public function toggleFilters(): void
    {
        $this->showFilters = ! $this->showFilters;
    }

    /**
     * Filtres INSTANTANÉS : toute modification d'une valeur du panneau
     * (wire:model.live="filterValues.*") est appliquée immédiatement.
     */
    public function updatedFilterValues(): void
    {
        $this->applyFilters();
    }

    /**
     * Recalculer les filtres actifs depuis les valeurs saisies.
     */
    public function applyFilters(): void
    {
        $this->activeFilters = array_filter(
            array_intersect_key($this->filterValues, array_flip($this->allowedFilterKeys())),
            fn ($value) => $value !== '' && $value !== null && $value !== []
        );
        $this->resetPage();
    }

    public function resetAllFilters(): void
    {
        // Retour aux filtres par défaut de l'écran (vides si le composant n'en définit pas).
        $defaults = $this->defaultFilters();
        $this->filterValues  = $defaults;
        $this->activeFilters = array_filter($defaults, fn ($v) => $v !== '' && $v !== null && $v !== []);
        $this->resetPage();
    }

    public function resetFilter($key): void
    {
        foreach ([$key, $key . '_min', $key . '_max'] as $variant) {
            unset($this->filterValues[$variant], $this->activeFilters[$variant]);
        }
        $this->resetPage();
    }

    /**
     * Réinitialiser recherche ET filtres (bouton de l'état vide).
     */
    public function resetSearchAndFilters(): void
    {
        $this->search = '';
        $this->resetAllFilters();
    }

    /**
     * Appliquer les filtres actifs à la requête. L'Index Object peut prendre
     * la main (applyFilters surchargé) ; sinon défaut générique :
     * égalité / whereIn (multi) / bornes _min et _max (ranges).
     */
    private function applyActiveFilters($query): void
    {
        $indexInstance = $this->getIndexInstance();

        if ($this->methodIsOverriden('applyFilters', \Mt\MtUi\Livewire\Indexes\GenericIndex::class, $indexInstance)) {
            $indexInstance->applyFilters($query, $this->activeFilters);
            return;
        }

        foreach ($this->activeFilters as $field => $value) {
            if (Str::endsWith($field, '_min')) {
                $query->where(Str::beforeLast($field, '_min'), '>=', $value);
            } elseif (Str::endsWith($field, '_max')) {
                $query->where(Str::beforeLast($field, '_max'), '<=', $value);
            } elseif (is_array($value)) {
                $query->whereIn($field, $value);
            } else {
                $query->where($field, $value);
            }
        }
    }

    /**
     * Point d'extension : partials supplémentaires du composant hôte
     * (modales custom, etc.) rendus à la fin du base-index — même
     * philosophie que extraSections() de BaseForm. No-op par défaut.
     */
    public function extraPartials(): array
    {
        return [];
    }

    /**
     * Afficher un message flash
     */
    private function showFlashMessage($type, $message)
    {
        $this->flashType = $type;
        $this->flashMessage = $message;
        $this->dispatch('hide-flash-after-delay');
    }

    /**
     * Masquer le message flash
     */
    public function hideFlash()
    {
        $this->flashMessage = '';
        $this->flashType = '';
    }

    /**
     * Verifier qu'un champ est triable
     */
    public function isSortableField($field = null)
    {
        $isSortable=in_array($field, $this->sortableFields);
        return $isSortable;
    }

    /**
     * Définir le tri
     */
    public function setSort($field)
    {
        if (!empty($this->sortableFields) && !in_array($field, $this->sortableFields)) {
            return;
        }

        if ($this->sortBy === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortBy = $field;
            $this->sortDirection = 'asc';
        }
    }

    /**
     * Confirmer la suppression
     */
    public function confirmDelete($id)
    {
        $this->dispatch('open-confirm-modal', [
            'title' => 'Confirmation',
            'message' => 'Vous êtes sur le point de supprimer cet élément. Souhaitez-vous poursuivre?',
            'confirmText' => 'Oui',
            'cancelText' => 'Non',
            'variant' => 'primary',
            'action' => 'delete-confirmed',
            'actionParams' => ['id' => $id],
        ]);
    }

    /**
     * Supprimer un élément
     */
    #[On('delete-confirmed')]
    public function deleteConfirmed($id)
    {
        $this->loading = true;
        try {
            $modelClass = $this->modelClass;
            $item = $modelClass::find($id);

            if ($item) {
                $item->delete();
            }
        } catch (\Exception $e) {
            showAlert('error', 'Erreur lors de la suppression: ' . $e->getMessage());
        }

        $this->loading = false;
        
        showAlert('success', 'Élément supprimé avec succès!', false);
    }


    /**
     * Obtenir la requête de base avec gestion d'erreurs robuste
     */
    private function getItemsQuery()
    {
        $query = $this->modelClass::query();

        // Appliquer les filtres statiques (contraintes fixes de la configuration)
        foreach ($this->filters as $condition) {
            if (is_array($condition) && count($condition) >= 2) {
                $query->where(...$condition);
            }
        }

        // Appliquer les filtres dynamiques actifs (panneau « Filtres »)
        if (! empty($this->activeFilters)) {
            $this->applyActiveFilters($query);
        }

        // Appliquer la recherche
        if ($this->search && ($this->features['searchable'] ?? true)) {
            $searchConfig = $this->getSearchConfiguration();

            // préparer le terle de la recherche
            $searchTermLower = '%'.Str::lower($this->search).'%';
            $query->where(function ($q) use ($searchConfig, $searchTermLower) {
                // Champs directs - toujours sécurisés
                foreach ($searchConfig['direct'] as $field) {
                    // $q->orWhere($field, 'like', '%' . $this->search . '%');
                    $q->orWhereRaw('LOWER(' .$field . ') LIKE ?', [$searchTermLower]);
                }

                // Relations - avec gestion d'erreurs
                foreach ($searchConfig['relations'] as $relation => $fields) {
                    $this->applyRelationSearch($q, $relation, $fields);
                }
            });
        }

        // Charger les relations nécessaires avec gestion d'erreurs
        $this->loadRelations($query);

        return $query;
    }

    /**
     * Appliquer la recherche sur une relation avec gestion d'erreurs
     */
    private function applyRelationSearch($query, string $relation, array $fields): void
    {
        try {
            // Vérifier si la relation existe et est valide
            if (!$this->isValidRelation($relation)) {
                return;
            }

            foreach ($fields as $field) {
                $query->orWhereHas($relation, function ($subQ) use ($field, $relation) {
                    try {
                        // Vérifier que le champ existe dans la table de la relation
                        if ($this->isValidRelationField($relation, $field)) {
                            $subQ->where($field, 'like', '%' . $this->search . '%');
                        }
                    } catch (\Exception $e) {
                        // Loguer l'erreur mais continuer l'exécution
                        Log::warning("Erreur recherche relation [{$relation}.{$field}]: " . $e->getMessage());
                    }
                });
            }
        } catch (\Exception $e) {
            // Loguer l'erreur de relation mais continuer l'exécution
            Log::warning("Erreur relation [{$relation}]: " . $e->getMessage());
        }
    }

    /**
     * Vérifier si une relation est valide
     */
    private function isValidRelation(string $relation): bool
    {
        try {
            $model = new $this->modelClass();

            // Vérifier que la méthode existe
            if (!method_exists($model, $relation)) {
                return false;
            }

            // Vérifier que c'est une relation Eloquent
            $relationInstance = $model->$relation();
            if (!$relationInstance instanceof \Illuminate\Database\Eloquent\Relations\Relation) {
                return false;
            }

            // Éviter les relations polymorphiques complexes
            if ($relationInstance instanceof \Illuminate\Database\Eloquent\Relations\MorphTo) {
                return false;
            }

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Vérifier si un champ existe dans la table de la relation
     */
    private function isValidRelationField(string $relation, string $field): bool
    {
        try {
            $model = new $this->modelClass();
            $relationInstance = $model->$relation();

            // Obtenir le modèle lié
            $relatedModel = $relationInstance->getRelated();
            $relatedTable = $relatedModel->getTable();

            // Vérifier que le champ existe dans la table liée
            return \Illuminate\Support\Facades\Schema::hasColumn($relatedTable, $field);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Obtenir la configuration de recherche avec fallback sécurisé
     */
    protected function getSearchConfiguration(): array
    {
        // Si des champs recherchables sont définis explicitement, les utiliser
        if (isset($this->searchableFields) && !empty($this->searchableFields)) {
            return [
                'direct' => $this->searchableFields['direct'] ?? [],
                'relations' => $this->searchableFields['relations'] ?? []
            ];
        }

        // Sinon, générer automatiquement une configuration sécurisée
        return $this->generateSafeSearchConfiguration();
    }

    /**
     * Vérifier si une relation est simple (un seul niveau)
     */
    private function isSimpleRelation(string $field): bool
    {
        $segments = explode('.', $field);
        return count($segments) === 2; // relation.champ
    }

    /**
     * Ajouter une recherche sur une relation
     */
    private function addRelationSearch($query, string $field): void
    {
        $segments = explode('.', $field);

        if (count($segments) !== 2) {
            return; // On ne gère que les relations simples pour la recherche
        }

        $relation = $segments[0];
        $relationField = $segments[1];

        $query->orWhereHas($relation, function ($q) use ($relationField) {
            $q->where($relationField, 'like', '%' . $this->search . '%');
        });
    }

    /**
     * Charger les relations nécessaires
     */
    private function loadRelations($query)
    {
        $relations = [];

        // Relations des autres colonnes
        foreach (array_keys($this->othersColumns) as $column) {
            if (Str::contains($column, '.')) {
                $relation = Str::before($column, '.');
                if ($this->isSimpleRelation($column)) {
                    $relations[] = $relation;
                }
            }
        }

        // Relations de la première colonne
        if (!empty($this->firstColumn['subtitleFields'])) {
            foreach ($this->firstColumn['subtitleFields'] as $field) {
                if (Str::contains($field, '.') && $this->isSimpleRelation($field)) {
                    $relations[] = Str::before($field, '.');
                }
            }
        }

        // Charger les relations uniques
        $relations = array_unique($relations);
        if (!empty($relations)) {
            $query->with($relations);
        }
    }

    /**
     * gerer les caracteristique de l'engin :ajouter,modifier, supprimer
     */
    #[On('openExportIndexData')]
    public function exportIndexData()
    {
        $this->dispatch('open-exporter-modal');
    }

    /**
     *ouvrir le gestionnaire d'images
     */
    public function openImageManager($rowId)
    {
        $this->dispatch('open-image-manager', modelId: $rowId, modelClass: $this->modelClass);
    }

    public function render()
    {
        $query = $this->getItemsQuery();

        $total = $query->count();
        $items = $query->orderBy($this->sortBy, $this->sortDirection)
            ->paginate($this->perPage);

        $this->dispatch('page-title-changed', title: $this->title);

        // Recalculer les actions d'en-tête à CHAQUE rendu : elles peuvent dépendre
        // du contexte courant (ex. lien « PDF classe » construit sur les filtres actifs).
        $this->initMainActions();

        $availableFilters = $this->getAvailableFilters();

        return view('mt::livewire.base.base-index', [
            'items' => $items,
            'total' => $total,
            'statistics' => $this->getStatistics(),
            // ⚠️ la propriété TRAITÉE par initMainActions (forme [label,icon,route|method]),
            // PAS la config brute {create, custom} — actions.grid ne saurait pas la rendre.
            'mainActions' => $this->mainActions,
            'indexDatas' => [
                'firstColumn' => $this->firstColumn,
                'othersColumns' => $this->othersColumns,
                'hiddenColumns' => $this->hiddenColumns,
                'canAddImages' => $this->features['canAddImages'] ?? false,
                'features' => $this->features,
                // le panneau Filtres est disponible dès qu'un index déclare des filtres
                'showFilters' => ($this->features['filterable'] ?? true) && count($availableFilters) > 0,
            ],
            'filtersData' => [
                'availableFilters' => $availableFilters,
                'activeFilters' => $this->activeFilters,
                'filterValues' => $this->filterValues,
                'activeFiltersCount' => count($this->activeFilters),
            ],
        ]);
    }
}
