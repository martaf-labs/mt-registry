<?php

namespace Mt\MtUi\Livewire\Auth;

use Illuminate\Auth\Events\Lockout;
use Illuminate\Auth\Events\Login as LoginEvent;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Session; // utilisé pour 2FA (Session::put)
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Laravel\Fortify\Features;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Validate;
use Livewire\Component;

/**
 * Composant Livewire 3 - Authentification multi-variantes
 *
 * ─────────────────────────────────────────────────────────────────
 * SYSTÈME DE LAYOUT
 * Calqué sur le même procédé qu'ArticleShow :
 *   → chaque variante = un fichier Blade dédié
 *   → render() résout la vue dynamiquement : 'mt::livewire.auth.login.' . $layout
 *   → layout configuré via mt_config('login_layout') ou .env MT_LOGIN_LAYOUT
 *
 * Valeurs : 'classic' | 'split' | 'minimal' | 'immersive'
 * Défaut  : 'classic'
 * ─────────────────────────────────────────────────────────────────
 */
#[Layout('mt::components.layouts.auth')]
class Login extends Component
{
    public const LAYOUTS = ['classic', 'split', 'minimal', 'immersive'];

    // ── Layout ──────────────────────────────────────────────────
    public string $layout = 'classic';

    // ── État ────────────────────────────────────────────────────
    #[Validate('required|string|email|max:255', message: [
        'required' => "L'adresse e-mail est obligatoire.",
        'email'    => 'Veuillez entrer une adresse e-mail valide.',
        'max'      => "L'adresse e-mail ne doit pas dépasser 255 caractères.",
    ])]
    public string $email = '';

    #[Validate('required|string|min:8', message: [
        'required' => 'Le mot de passe est obligatoire.',
        'min'      => 'Le mot de passe doit contenir au moins 8 caractères.',
    ])]
    public string $password = '';

    public bool $remember = false;

    // ── Mount ───────────────────────────────────────────────────
    public function mount(): void
    {
        if (Auth::check()) {
            $this->redirectIntended(
                default: route('dashboard', absolute: false),
                navigate: true
            );
            return;
        }

        $configured   = mt_config('login.layout');
        $this->layout = in_array($configured, self::LAYOUTS, true) ? $configured : 'classic';
    }

    // ── Actions ─────────────────────────────────────────────────

    public function login(): void
    {
        $this->validate();
        $this->ensureIsNotRateLimited();

        $user = $this->validateCredentials();

        // Two-Factor Authentication (Fortify)
        if (
            class_exists(Features::class)
            && Features::canManageTwoFactorAuthentication()
            && method_exists($user, 'hasEnabledTwoFactorAuthentication')
            && $user->hasEnabledTwoFactorAuthentication()
        ) {
            RateLimiter::clear($this->throttleKey());
            Session::put([
                'login.id'       => $user->getKey(),
                'login.remember' => $this->remember,
            ]);
            $this->redirect(route('two-factor.login'), navigate: true);
            return;
        }

        // Auth::login() appelle session->migrate(true) qui régénère l'ID de session.
        // Dans un contexte Livewire (AJAX), le navigateur ne reçoit pas toujours le
        // nouveau Set-Cookie avant d'envoyer le GET /dashboard → session vide → auth échoue.
        // Solution : écrire la clé d'auth directement en session sans changer l'ID.
        $this->writeAuthToSession($user);
        RateLimiter::clear($this->throttleKey());

        $this->redirectIntended(
            default: route('dashboard', absolute: false),
            navigate: true
        );
    }

    // ── Helpers ─────────────────────────────────────────────────

    /**
     * Écrit les données d'auth en session SANS appeler session->migrate().
     *
     * Auth::login() → migrate(true) régénère l'ID de session. Dans un flux
     * Livewire AJAX → redirect, le navigateur peut envoyer l'ancien cookie
     * sur la requête suivante. On écrit directement la clé de garde, ce qui
     * est exactement ce que fait le SessionGuard, sans la régénération d'ID.
     */
    protected function writeAuthToSession(Authenticatable $user): void
    {
        $guard = Auth::guard();

        session()->put($guard->getName(), $user->getAuthIdentifier());

        if ($this->remember) {
            $user->setRememberToken(Str::random(60));
            $user->save();
        }

        $guard->setUser($user);

        event(new LoginEvent(Auth::getDefaultDriver(), $user, $this->remember));
    }

    protected function validateCredentials(): Authenticatable
    {
        $provider = Auth::getProvider();

        $user = $provider->retrieveByCredentials(['email' => $this->email]);

        if (! $user || ! $provider->validateCredentials($user, ['password' => $this->password])) {
            RateLimiter::hit($this->throttleKey());
            $this->reset('password');

            throw ValidationException::withMessages([
                'email' => __('auth.failed'),
            ]);
        }

        return $user;
    }

    protected function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        event(new Lockout(request()));
        $seconds = RateLimiter::availableIn($this->throttleKey());

        throw ValidationException::withMessages([
            'email' => __('auth.throttle', [
                'seconds' => $seconds,
                'minutes' => (int) ceil($seconds / 60),
            ]),
        ]);
    }

    protected function throttleKey(): string
    {
        return Str::transliterate(
            Str::lower($this->email) . '|' . request()->ip()
        );
    }

    // ── Render ──────────────────────────────────────────────────

    public function render(): \Illuminate\View\View
    {
        return view('mt::livewire.auth.login.' . $this->layout, [
            'hasLogo'          => has_option_login('logo'),
            'hasRemember'      => has_option_login('remember'),
            'hasPasswordReset' => has_option_login('password_reset') && \Illuminate\Support\Facades\Route::has('password.request'),
            'hasRegister'      => has_option_login('register') && \Illuminate\Support\Facades\Route::has('register'),
            'hasHome'          => has_option_login('home') && \Illuminate\Support\Facades\Route::has('home'),
        ]);
    }
}
