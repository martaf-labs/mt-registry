<?php

namespace Mt\MtUi\View\Components\Templates\App;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class PageSection extends Component
{
    public $title;
    public $actions;
    /**
     * Create a new component instance.
     */
    public function __construct(?string $title = null, ?array $actions = null)
    {
        $this->$title = $title;
        $this->actions = $actions;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('mt::components.templates.app.page-section');
    }
}
