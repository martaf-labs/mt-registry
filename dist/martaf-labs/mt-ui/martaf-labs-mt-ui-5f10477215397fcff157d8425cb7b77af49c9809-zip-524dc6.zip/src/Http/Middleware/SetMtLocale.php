<?php

namespace Mt\MtUi\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Mt\MtFoundation\Helpers\MtLocale;
use Symfony\Component\HttpFoundation\Response;

class SetMtLocale
{
    /**
     * Applique la locale mt-ui à chaque requête.
     * À enregistrer dans le groupe 'web' du projet hôte.
     *
     * Exemple dans bootstrap/app.php (Laravel 11+) :
     *   ->withMiddleware(function (Middleware $middleware) {
     *       $middleware->appendToGroup('web', SetMtLocale::class);
     *   })
     */
    public function handle(Request $request, Closure $next): Response
    {
        $locale = MtLocale::get();
        app()->setLocale($locale);

        return $next($request);
    }
}
