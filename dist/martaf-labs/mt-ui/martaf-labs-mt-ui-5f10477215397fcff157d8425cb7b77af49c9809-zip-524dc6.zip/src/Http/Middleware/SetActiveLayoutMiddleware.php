<?php
namespace Mt\MtUi\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SetActiveLayoutMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $layout = $this->resolveLayout($request);

        // 1. Session (optionnel)
        session(['active_layout' => $layout]);

        // 2. Container (recommandé)
        app()->instance('mt.layout', $layout);

        // 3. Share avec Blade
        view()->share('mt_layout', $layout);

        return $next($request);
    }

    protected function resolveLayout(Request $request): string
    {
        // 🔥 Config du package
        $rules = config('mt-ui.layouts', []);

        foreach ($rules as $pattern => $layout) {
            if ($request->is($pattern)) {
                return $layout;
            }
        }

        return config('mt-ui.default_layout', 'guest');
    }
}