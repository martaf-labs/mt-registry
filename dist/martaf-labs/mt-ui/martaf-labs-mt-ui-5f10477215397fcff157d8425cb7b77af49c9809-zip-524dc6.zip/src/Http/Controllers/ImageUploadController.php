<?php

namespace Mt\MtUi\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;

class ImageUploadController extends Controller
{
    /**
     * Handle an image upload (used by TinyMCE and other rich-text editors).
     */
    public function upload(Request $request): JsonResponse
    {
        $request->validate([
            'file' => ['required', 'image', 'max:5120'],
        ]);

        $path = $request->file('file')->store(
            'uploads/images',
            config('mt-ui.upload_disk', 'public')
        );

        return response()->json([
            'location' => Storage::disk(config('mt-ui.upload_disk', 'public'))->url($path),
        ]);
    }
}
