# mt-ui - North Star (à lire AVANT toute modification)

> Package **UI/UX générique** de l'écosystème martaf-labs. Utilisé par **plusieurs
> projets / SaaS** (scolaire ET non scolaire). Toute modification doit préserver
> sa neutralité : ce qui est spécifique à un domaine n'a RIEN à faire ici.

## 0. mt-ui = THÈME GLOBAL DE TOUS LES PROJETS (règle transverse)

**L'interface graphique de TOUS les projets est pilotée par mt-ui.** Conséquences
NON négociables, à respecter sur chaque écran de chaque projet hôte :

1. **Même organisation partout.** Toute page d'un projet (y compris les vues propres au
   projet, hors CRUD génériques) DOIT poser son contenu dans le **cadre global**
   `<x-mt::screen>` (= le frame commun de `base-index`/`base-form` : wrapper pleine hauteur
   → conteneur centré → `<x-mt::breadcrumbs>` titre/description/fil d'Ariane/actions).
   Pattern : `<div><x-mt::screen :title :description :breadcrumbs [width] [<x-slot:actions>]>…</x-mt::screen></div>`
   (racine `<div>` nue = contrainte Livewire). **Largeur par défaut = 7xl** (comme base-index) ;
   les pages liste/tableau restent en 7xl — ne PAS les rétrécir (4xl/5xl = incohérence visible).
2. **Composants mt-ui obligatoires.** Réutiliser les composants du package
   (`x-mt::button`, `form.*`, `badge`, `alert`, `modal`, `dropdown`, `empty-state`,
   `breadcrumbs`, `icon`…). Ne pas réinventer un bouton/un tableau/un état-vide à la main.
   État vide = **`<x-mt::empty-state>`** (jamais un `<div>` centré maison).
3. **Thème mt-ui même pour les composants propres à un projet.** Un composant/vue
   spécifique à un projet ADOPTE le thème : **couleurs = tokens `--mt-*` uniquement**
   (jamais `bg-white`/`text-gray-*`/`dark:*`/`blue-500`…), **icônes = mt-icons SVG**
   (`<x-mt::icon>` ; helper `mt_icon_name()` normalise un ancien nom FA/`mt-icon-`), et
   **i18n** (toute chaîne traduisible, fr/en/ar ensemble). Un `<i class="fa-…">` ou une
   couleur en dur dans une vue = à corriger.
4. ⚠️ **Piège CSS servi (récurrent).** Le `public/vendor/mt/mt-ui/css/mt-ui.css`
   servi est un sous-ensemble FIGÉ : beaucoup d'utilitaires Tailwind n'y sont PAS et ne
   produisent alors RIEN (silencieux) — pas décimaux (`px-2.5`, `py-1.5`, `gap-2.5`, `p-1.5`,
   `mt-0.5`, `w-2.5`), `size-*`, arbitraires (`z-[…]`, `min-w-[…]`, `text-[10px]`), et `max-w-4xl`.
   Avant d'utiliser une classe : `grep -E "\.classe\{" public/vendor/mt/mt-ui/css/mt-ui.css`.
   Sinon : classe existante équivalente OU **style inline** (z-index, min-width, font-size,
   largeur via `style="max-width:…"`).
   ✅ **GRILLES : CORRIGÉES à la racine** (2026-07-15). `partials/theme-vars.blade.php` (chargé
   APRÈS `@mtAssets`, règles non layerées → priorité garantie) réinjecte `grid-cols-3/5/6` +
   TOUTES les variantes responsives `sm:/md:/lg:/xl:grid-cols-1..4` (+ 2 arbitraires enregistrées
   `sm:grid-cols-[7rem_1fr_auto]`, `md:grid-cols-[20rem_1fr]`). Donc les grilles Tailwind standard
   **fonctionnent désormais partout** — inutile de re-hacker en `flex flex-wrap`. Seule une valeur
   de grille arbitraire NON encore enregistrée nécessite de l'ajouter au patch (ou style inline).
   ⚠️ Piège jumeau : commentaire Blade `{{-- --}}` DANS un bloc `@php` = erreur PHP → `//`.

5. **VUES GÉNÉRALISTES D'ABORD (doctrine cardinale).** `base-index` = la page d'accueil/liste
   d'un module ; `base-form` = la page d'ajout/édition. Une page liste d'un projet ne se code
   pas à la main : elle **instancie** le moteur (`XIndex extends GenericIndex` +
   `configuration()`), idem pour les forms (`GenericForm` + `schema()`). Écrire une vue Blade
   bespoke qui *imite* base-index = duplication interdite. Un type d'écran qui se répète
   (fiche détail, manager relationnel…) → créer une **nouvelle vue généraliste** ici
   (`base-show`, …), pas N copies dans les projets. Les améliorations (barre de filtres,
   recherche sophistiquée, stats…) se font **une seule fois dans le moteur** base-* → tous les
   projets en profitent. Vue spécifique projet = exception (écran réellement unique), toujours
   dans le thème.

> En bref : « une page d'un projet N'EST PAS une imitation de base-index/base-form — elle en
> est une INSTANCE ; et tout ce qui peut être généralisé vit dans mt-ui ».

## 1. Règle cardinale - AUCUNE dépendance métier

mt-ui ne dépend QUE de `mt-foundation`. Il ne doit **JAMAIS** dépendre de
`mt-school-core` ni d'aucun package métier (pas de `use Mt\MtSchoolCore\…`, pas de
référence à `School`, `Plan`, élèves, etc.). C'est une feuille du graphe de dépendances.

Le couplage avec un projet hôte se fait **uniquement par des points d'extension** :
classes à étendre, méthodes à surcharger, vues à injecter, config cache-safe.

> ⚠️ Si tu dois afficher quelque chose de spécifique (formule d'abonnement, stats
> élèves…), ça se fait côté projet hôte via un point d'extension - jamais en dur ici.

## 2. Points d'extension

### Dashboard (`MtDashboard`)
Composant Livewire générique **conçu pour être étendu**. Le projet hôte crée sa propre
classe `extends \Mt\MtUi\Livewire\MtDashboard` et surcharge :
- `getTitle()`, `getSubtitle()`, `getQuickActions()`, `getStats()`, `getWidgets()`, `getStatsColumns()`.
- `getWidgets()` retourne `[]` par défaut → un SaaS qui ne l'override pas n'a aucun widget.
- Types de widgets : `list | chart | activity | stat_group | progress | custom`.
  **`custom`** = échappatoire : `@include($widget['view'], $widget['view_data'])` → le projet
  hôte fournit sa propre vue sans rien coder en dur dans mt-ui.

### Cartes de stats UNIFIÉES — `<x-mt::stats-scroll :stats="…">` (2026-07-15)
- **UN seul composant** pour toutes les cartes de stats : dashboard, base-index, base-show, et
  écrans bespoke (ex. présences). Scroll horizontal (N cartes, flèches + dégradés + scrollbar
  cachée), carte `mt-card rounded-2xl` bordure-gauche colorée, libellé capitales + valeur XXL +
  puce d'icône. `:stats` = `[{label, value, icon, color, ?route, ?details:[{value,label}],
  ?change, ?changeType}]`. Toute amélioration du rendu des stats se fait ICI, une fois.
  ⚠️ Ne PAS recréer un bloc de stats inline — instancier ce composant.

### Base-index (moteur des pages liste — enrichi 2026-07-15)
- **Stats VISIBLES** : `getStatistics()` de l'Index Object (`[{label, value, icon, color}]`) rendues
  via **`<x-mt::stats-scroll>`** (même comportement que le dashboard).
- **Filtres dynamiques CÂBLÉS** : l'Index Object déclare `getFiltersConfig()`
  (`clé => [label, type select|range|date|checkbox, options]`) → bouton « Filtres (n) » + panneau.
  Application **INSTANTANÉE** (`wire:model.live` + hook `updatedFilterValues` ; ranges en
  `.debounce.500ms` ; pas de bouton Appliquer), croix d'effacement inline par filtre,
  `applyFilters($query, $activeFilters)` surchargeable (défaut : égalité / whereIn / bornes
  `_min`/`_max`), **liste blanche** des clés déclarées (jamais une clé arbitraire du client dans
  la requête). Recherche : `updatingSearch` reset la page ; la toolbar reste visible quand
  recherche/filtres donnent 0 résultat (sinon impossible de reset). Per-page = paliers fixes
  `[10,25,50,100]` (doivent contenir le perPage par défaut de la config).
  Filtre PAR DÉFAUT d'un écran : le poser dans `mount()` seulement si pertinent — ex. Inscriptions
  pré-filtre « en attente » UNIQUEMENT s'il existe des dossiers à traiter (un écran vide alors que
  le badge sidebar annonce N éléments = déroutant).
- **`extraPartials()`** (point d'extension, no-op par défaut) : partials du composant hôte
  (modales custom…) rendus en fin de base-index — jumeau de `extraSections()` de BaseForm.
  Ex. mt-school : modale « motif de refus » de l'écran Inscriptions, modales encaissement/bourse.
- **CONTEXTE injecté dans l'Index Object** : BaseIndex passe `withContext(['activeFilters','filterValues','search'])`
  à chaque délégation → colonnes/stats **contextuelles** via `$this->contextFilter('clé')`
  (ex. totaux de la classe filtrée, grille du niveau sélectionné). Un filtre peut être purement
  contextuel : surcharger `applyFilters($query, $filters)` en no-op (il paramètre l'écran, il
  ne filtre pas la requête).
- **Options de filtre** : `required => true` (pas d'option « Tous », pas de croix — ex. classe
  du caissier, niveau de la grille) ; `emptyLabel => '…'` (libellé métier de l'option vide,
  ex. « — Toutes / aucune — » pour une filière).
- **`defaultFilters()`** (hook composant hôte) : filtres posés au mount ET re-posés par
  resetAllFilters (indispensable avec un filtre `required`). Défaut « souple » (effaçable) →
  surcharger `mount()` à la place.
- **Options de colonne** : `align => 'right'|'center'` (montants…) ; `editable =>
  ['method','type','placeholder','width']` → cellule INPUT inline, `wire:change` appelle
  `method(rowId, champ, valeur)` sur le composant hôte (ex. grille tarifaire : montant par
  type de frais, updateOrCreate/suppression côté hôte).
- **Action de ligne `route`** : clé optionnelle `'target' => '_blank'` (PDF, relevés) → pas de
  wire:navigate.
- **Colonne Actions** : présente si AU MOINS une ligne de la page a des actions (les actions
  peuvent dépendre de l'état de la ligne) ; cellule toujours rendue pour l'alignement.
  Ne JAMAIS sonder `getRowActions(1)` (id en dur).
- Composant hôte : peut surcharger `mount()` (appeler `parent::mount()` puis pré-remplir
  `filterValues`/`activeFilters` = filtre par défaut) et `render()` (garde prérequis puis
  `return parent::render()`).

### Base-show / Base-profile (fiche de consultation — 3e vue-modèle, 2026-07-15)
- **Trilogie** : base-index (liste) · base-form (créer/modifier) · **base-show (consulter)**.
  `XShow extends GenericShow` + `XsShowComponent extends BaseShow` ; route `<pluriel>_show`
  (config/routes.php) → l'action « Voir » de la liste et l'item intermédiaire du fil d'Ariane
  y pointent. La fiche CONSULTE — toute modification passe par base-form/managers.
- **DOCTRINE PERSONNE vs CHOSE** : la fiche d'une PERSONNE (élève, personnel, tuteur…) =
  **`Shows\GenericProfile`** (extends GenericShow, `isProfile()` → avatar ROND en médaillon
  5.5rem « photo d'identité ») — ex. `StudentProfile extends GenericProfile`, route
  `<pluriel>_profile`. La fiche d'une CHOSE (classe, projet, tarif…) = `GenericShow`
  (vignette arrondie 4.5rem). Les évolutions propres aux personnes (badge imprimable,
  compte portail, timeline…) vivent dans GenericProfile, jamais dans GenericShow.
  ⚠️ NE PAS confondre avec le système LEGACY `Livewire\Profiles\GenericProfile` +
  `Base\BaseProfile` + vue `base-profile` (ancienne API sections/sidebar/modules) encore
  utilisé par sgni-app (PersonnelProfile/UserProfile) — intouchable jusqu'à sa migration ;
  le nom de composant `BaseProfile` lui reste réservé (les composants du nouveau système
  étendent BaseShow, le mode profil vient du Show Object).
- **DEUX MODES rétro-compatibles** : LEGACY (getShowData fields/medias/metaDatas — sgni-app,
  mt-blog, NE PAS CASSER) et **SECTIONS** (North Star), activé quand le Show Object surcharge
  `sections()` (détection methodIsOverriden). Blade racine = dispatcher vers
  `partials/show-legacy` (verbatim historique) ou `partials/show-sections`.
- **Mode sections** : `header($m)` (image|letters/title/subtitle/badges — image avec fallback
  initiales via onerror), `actions($m)` (grammaire mainActions : route|method + confirm/target),
  `getStatistics($m)` (cartes compactes), `tabs()` (onglets CLIENT via Alpine, ⚠️ :style OBJET),
  `sections($m)` : types `attributes` (items label=>valeur, null→'—'),
  `table` (columns/rows — cellule array ['badge'=>…,'type'=>…] rendue en x-mt::badge ;
  empty/emptyIcon → empty-state), `view` (partial hôte, reçoit $model).
  `features.canAddImages` → modale MediaManager + méthode générique openImageManager().
  `extraPartials()` (modales hôte) comme base-index. Pilote : fiche élève mt-school.

### Formulaires (schema-driven)
- `BaseForm` (composant) + `GenericForm` (objet form) + `base-form.blade.php` (rendu générique).
- **AUTO-AJUSTEMENT des rangées (2026-07-15)** : les champs se regroupent en rangées (grille
  interne 6 colonnes, span = `col`/2) ; toute rangée incomplète est remplie par répartition
  ÉQUITABLE du reliquat entre ses champs (2+2 → 3+3 ; un champ seul de col 6 → pleine largeur).
  Jamais de trou horizontal. Opt-out ponctuel : `'colFixed' => true` sur un champ. Les classes
  `md:col-span-1..6`, `md:grid-cols-6`, `lg:col-span-1..4`, `lg:w-2/3|1/3` sont INJECTÉES par
  `partials/theme-vars` (le layout des forms ne dépend plus du build Vite de l'hôte).
- ✅ **CHECKLIST à chaque `extends GenericForm` (form de PERSONNE)** :
  1. **Genre** = `SexePersonnel::options()` et **Civilité** = `CivilitePersonnel::options()`
     (enums **mt-foundation**, valeurs M/F/-/Mme/Mlle, libellés i18n via
     `mt-foundation::mt-foundation.*`) — JAMAIS d'options codées à la main ; validation
     `Rule::in(array_keys(Enum::options()))`. Exception : liste métier plus riche (ex. civilité
     enseignant avec Dr/Pr) → select spécifique assumé, documenté.
  2. **Photo** : champ `'photo' => ['type' => 'image', 'oldvalue' => chemin encodé du média
     vedette]` ; save() → `unset($data['photo'])` + dé-vedettiser puis
     `MediaService::attach($model, $photo, ['type' => 'photo', 'is_featured' => true])`.
  3. Champs traduisibles → règle `array` ; unicité → `->where('school_id', …)` +
     `->whereNull('deleted_at')` (MtBaseModel soft-delete TOUT).
  4. **Cohérence Genre ⇄ Civilité** : déclarer `fieldActions()` bidirectionnel (gender→title
     ET title→gender) pour qu'un choix synchronise l'autre (Masculin↔Monsieur, Féminin↔Madame).
  5. Largeurs `col` : penser en rangées de 12 (l'auto-ajustement remplit les trous, mais un
     schéma bien pensé reste plus lisible).
- Trait `WithFormSteps` (multi-étapes via `steps()`).
- Types de champs : text/email/number/select/textarea/toggle/checkbox/radio/date/datetime/
  card-select/icon-picker/color-picker/image(s)/file/editor/modal-select.
- `multilingual` (onglets par locale = `MtLocale::available()` = langues de l'école) : AUTO-détecté
  depuis `getTranslatables()` du modèle du form, OU déclaré EXPLICITEMENT `'multilingual' => true`
  dans le schema quand le champ est traduisible sur un AUTRE modèle que celui piloté par le form
  (ex. noms de l'enseignant portés par StaffMember alors que le form pilote Teacher). Le moteur
  initialise alors la prop en tableau {locale=>''} et fillModel/save doivent lire/écrire des
  tableaux (`getRawOriginal` pour lire le JSON brut, PAS l'accès direct qui aplatit à la locale).
  Un champ nom/prénom peut être rendu FACULTATIF au niveau du form (rule `nullable|array`) —
  usage courant (nom unique) en Afrique francophone.
- **`fieldActions()` — INTERDÉPENDANCES entre champs** (auto-remplissage d'un champ selon un
  autre). L'objet form retourne `['champ_source' => [['type' => 'map'|'set'|'copy'|'clear',
  'target' => 'champ_cible', 'map' => [valeur_source => valeur_cible]]]]`. base-form rend le
  champ SOURCE en **`wire:model.live`** (détecté via `fieldActions()`, opt-in → aucun round-trip
  sur les autres champs) ; au changement, `updatedForm()` applique les actions. **Bidirectionnel**
  = déclarer l'action dans les deux sens (ex. Genre⇄Civilité du tuteur : gender→title ET
  title→gender). Pas de boucle : une écriture serveur (`$form->x = …`) ne re-déclenche pas
  `updatedForm` (seul un changement CLIENT le fait). Supporté sur select/toggle/radio/checkbox
  (prop `:live` sur select & toggle). ⚠️ NE PAS mettre `{{ … }}` dans le NOM d'un attribut de
  COMPOSANT Blade (`wire:model{{ $x }}=` casse la compilation) → passer par une prop. ⚠️
  `BaseForm::fieldActions()` teste `method_exists` (pas `instanceof HasBaseFormContract` :
  GenericForm ne l'implémente pas).
- Un nouveau besoin de champ générique = un nouveau composant `components/form/*` réutilisable.
- **Sections supplémentaires (point d'extension hôte)** : `BaseForm` expose un bag générique
  `public array $extraData = []` + 3 hooks **no-op par défaut** (aucun impact si non override) :
  `extraSections(): array` (sections de champs additionnels rendues après le schéma principal,
  sur la dernière étape / en mono-étape), `hydrateExtra(?$model)` (édition) et `persistExtra($model)`
  (après save). Le partial `livewire/base/partials/extra-sections.blade.php` rend ces sections
  (champs liés à `extraData.<clé>`). Sert à l'hôte pour injecter des champs hors form-object
  (ex. EAV par tenant de mt-school) **sans que mt-ui connaisse le domaine**.

### Brand / identité visuelle (point d'extension)
Le brand de la sidebar (`components/layouts/app.blade.php`) utilise `mt_brand_name()` /
`mt_brand_logo()`. Par défaut → `mt-ui.app_name`. Le projet hôte peut fournir un résolveur :
```php
config(['mt-ui.brand_resolver' => MaClasse::class]); // name(): ?string, logoUrl(): ?string
```
Ex. mt-school renvoie le sigle (short_name) / nom + logo de `School::current()`.

### Thème / couleurs (design tokens - point d'extension)
mt-ui consomme **un seul vocabulaire de tokens CSS** `--mt-*` (en triplets RGB pour
`rgb(var(--mt-x) / alpha)`) : `primary` · `primary-content` · `secondary` · `accent` · `bg` ·
`ui-card-bg`/`ui-card-border` (surfaces) · `ui-input-bg`/`ui-input-border` · `text` · `muted` ·
`danger`/`success`/`warning`/`info`. **Aucun composant n'écrit de couleur en dur.**
Les VALEURS viennent de `mt_theme_colors()` (= `config('mt-ui.colors')` light/dark fusionné
aux surcharges du résolveur) et sont injectées dans le `<head>` par
`partials/theme-vars.blade.php` (inclus APRÈS `@mtAssets` → surcharge le CSS précompilé).
**3 couches (cascade) :** défauts config < charte d'app (`config/mt-ui.php` ou `.env`) <
`theme_resolver` (runtime / par tenant).
```php
config(['mt-ui.theme_resolver' => MaClasse::class]); // colors(): array → ['light'=>['primary'=>'#...'], 'dark'=>[...]]
```
Sans résolveur → charte 100 % statique. Ex. mt-school : couleur de marque par école (runtime).
> Dark : `bg` = page (le plus sombre), `surface`/`input` légèrement **plus clairs** (élévation/harmonie).

### Gating du menu par module (point d'extension)
`mt_get_sidebar()` masque les entrées/groupes du `config('sidebar')` portant une clé `module`,
si le projet hôte déclare un gate :
```php
config(['mt-ui.module_gate' => MaClasse::class]); // enabled(string $code): bool
```
Sans gate (autres SaaS) → aucun filtrage. Ex. mt-school renvoie `moduleEnabled($code)`.

### Gating du menu par PERMISSION (point d'extension — jumeau du module_gate)
`mt_get_sidebar()` masque aussi les entrées/groupes portant une clé `permission` si l'hôte
déclare un gate RBAC :
```php
config(['mt-ui.permission_gate' => MaClasse::class]); // allows(string $ability): bool
```
Un item est masqué si `module` inactif **OU** `permission` non accordée. Sans gate → aucun
filtrage. Ex. mt-school : `Support\SchoolPermissionGate` (→ `auth()->user()?->can($ability)`).
Neutralité préservée : mt-ui ne connaît pas les rôles, il appelle juste `->allows(string)`
sur un résolveur fourni par l'hôte.

### État actif du menu (sidebar + menu mobile)
`mt_get_sidebar()` est la **seule source de vérité** de l'état actif (`isActive` sur items et
sous-items) : correspondance par **chemin d'URL** avec **préfixe de segment** (une page enfant
`/finances/payments/student/5` marque l'item `/finances/payments` et ouvre son groupe), le chemin
correspondant **le plus long l'emporte** (pas de double marquage), l'égalité exacte bat le préfixe.
Clé optionnelle `'active' => ['clé_logique_ou_/chemin', …]` sur un item pour marquer aussi des
écrans hors de son préfixe d'URL. ⚠️ Ne JAMAIS recalculer dans un layout avec
`request()->routeIs($item['route'].'*')` : `route` contient une **URL** (elle sert de href), pas
un nom de route — ça ne matche jamais (c'était le bug historique, corrigé aux 3 points de
consommation : sidebar desktop, titre topbar mobile, feuille menu mobile).

### Cloche de notifications (point d'extension)
La topbar (`components/layouts/app.blade.php`) affiche une cloche **dynamique** : compteur non-lu +
aperçu des derniers items + lien « voir tout ». Contenu fourni par l'hôte via un résolveur :
```php
config(['mt-ui.notifications_resolver' => MaClasse::class]);
// count(): int ; url(): ?string ; recent(): array<{title,read,time,url}>
```
Le helper `mt_notifications()` lit ce résolveur → `['enabled','count','url','recent']`. **Sans résolveur**
(autres SaaS) → repli statique « aucune notification » (mt-ui ignore le domaine). Ex. mt-school :
`Support\NotificationBadgeResolver` (non-lu de l'user connecté, SchoolScope + user_id). Badge en **styles
inline** (pas de classe Tailwind arbitraire).

### Aide d'usage (bulles + visites guidées) - config-driven par l'hôte
Deux mécanismes **génériques**, contenu fourni par l'hôte (jamais en dur ici) :
- **`<x-mt::help>`** : icône « ? » + popover (téléporté `body`, `fixed`, auto-flip haut/bas).
  Contenu : slot, prop `:text`, ou prop `key` → `mt_help('clé')` lit `config('help.<clé>')`
  (registre `config/help.php` de l'hôte, tableaux IMBRIQUÉS pour la notation pointée ;
  string ou `['fr'=>…]`). Absent → rien (pas d'erreur).
- **`<x-mt::tour name="écran">`** : visite guidée légère (Alpine, zéro dépendance JS).
  Étapes via `mt_tour('écran')` → `config('tours.<écran>')` de l'hôte (`steps`:[`target`,`title`,`body`]).
  Spotlight (box-shadow géant), suivant/précédent/passer, complétion en **localStorage**
  (`mt-tour-<name>`). `auto` (1er accès) ; relance manuelle via `$dispatch('start-tour',{name})`.
  Cible absente = étape sautée. Le JS est `@push('scripts')` (stack rendu par master/head).
> Philosophie : remplir le contenu **écran par écran**, quand l'écran se stabilise (pas avant).

### Locale & RTL
- Helper `MtLocale` : `get/set/available/direction/isRtl`. Locales RTL → `dir="rtl"`.
- Middleware `SetMtLocale` (groupe web) applique la locale. Composant `LocaleSwitcher`.
- Les `<html>` des layouts portent `dir="{{ MtLocale::direction() }}"`.
- `available_locales` est fourni par l'hôte (ex. langues de l'école) - pas figé ici.

### Médias
- `MediaManager` (Livewire) consomme `mt-media` (package domaine) via ses contrats -
  branché par config `mt-media.model`, pas de couplage dur.

## 3. Conventions

- **Composants Livewire du package** : à enregistrer dans le service provider (sinon 419 - le snapshot ne résout pas le composant).
- **Icônes** : rendu **INLINE** uniquement - `<x-mt::icon name="home" />` ou `app(\MtIcons\IconRenderer::class)->render($name)` (SVG inline). **NE PAS** utiliser le mask CSS `<i class="mt-icon-X">` (rend des **carrés de couleur** : le mask ne s'applique pas). `<x-mt::icon>` tolère un nom préfixé `mt-icon-…` (il le retire). Noms = **anglais** (`home`, `users`, `list`, `folder`, `trash`, `pencil`, `chevron-*`…) ; lister via `php artisan mt-icons:list`.
- **Surfaces compactes** (dropdown, popover, tooltip) : **NE PAS** utiliser `.mt-card` (padding/bordure/radius généreux → c'est pour des cartes de CONTENU). Utiliser `background: rgb(var(--mt-ui-card-bg))` + bordure fine + padding léger.
- **Alpine `:style`** : pour combiner un style statique (`style="background:…;border:…"`) **et** une position dynamique sur le même élément, le `:style` dynamique DOIT être un **OBJET** (`:style="{top:…,right:…}"`). Une **string** fait `el.setAttribute('style', …)` qui **écrase** tout le style statique (fond/bordure perdus).
- **Dropdown / overflow** : un menu vivant dans un conteneur en overflow (ex. cellule de tableau scrollable du base-index) doit être **téléporté** (`<template x-teleport="body">`) + positionné `fixed` ancré au déclencheur (sinon rogné). Cf. `components/dropdown/index.blade.php`.
- **Config cache-safe** : pas de closures dans `config/mt-ui.php` (config:cache les casse).
  Pour du dynamique, passer par une classe résolveur (nom de classe en config) ou une surcharge.
- **CSS** : utiliser les **tokens mt** (variables CSS `--mt-*`, classes `mt-*`). NE PAS écrire de
  classes Tailwind « arbitraires » qui ne sont pas dans le CSS précompilé `mt-ui.css`.
- **z-index élevé** : les classes arbitraires `z-[9999]`/`z-[10000]` **ne sont PAS** dans `mt-ui.css`
  → elles ne produisent AUCUN z-index (la page passe par-dessus modals/overlays). Utiliser un
  **`style="z-index: …"` inline** (toujours appliqué, sans compilation). Idem fond de surface :
  `style="background: rgb(var(--mt-ui-card-bg))"` plutôt que dépendre de `.mt-card` pour l'opacité.
- **Modal lent à s'ouvrir** : un modal piloté serveur (`wire="isOpen"`/`@entangle`) attend un
  aller-retour Livewire avant d'apparaître. Pour une ouverture **instantanée**, passer un prop
  `openEvent="mon-evenement"` à `<x-mt::modal>` → Alpine ouvre sur le window-event (optimiste),
  le serveur se synchronise après. (Cf. modals confirm/quick-auth/newsletter.)
- **`x-mt::button` spinner** : pendant le loading, l'icône SVG (`mt-icon--md` = `1.25rem × 1.25rem`)
  est remplacée par un `<i class="fa-circle-notch fa-spin">`. Sans `font-size:1.25rem` sur le `<i>`,
  le bouton rétrécit (FA hérite du font-size du bouton, plus petit que le SVG). Le composant
  injecte `style="font-size:1.25rem; line-height:1;"` sur le spinner - **ne pas supprimer**.
- **`x-mt::form.date-picker` padding icône** : la classe `pl-11` de Tailwind peut ne pas être
  dans le CSS précompilé de mt-ui → l'icône chevauche le texte. Padding via `style="padding-left:2.75rem"`
  inline (toujours appliqué). **Ne pas remplacer par une classe Tailwind.**
- **`x-mt::dropdown.item` attributs supplémentaires** : le composant passe maintenant
  `{{ $attributes->except(['class','style']) }}` au `<button>` - on peut ajouter des handlers
  Alpine (`@click.stop`) ou Livewire en plus du prop `method`. Ne pas ajouter `wire:click` via
  `$attributes` si `method` est déjà utilisé (conflit de deux `wire:click`).
- **Dashboard stats - scroll horizontal** : les cards de stats utilisent un flex scroll horizontal
  Alpine (`canLeft`/`canRight` + flèches + dégradés + scrollbar cachée via style injecté),
  identique au pattern du projet-manager. Chaque card : `shrink-0 w-1/4 min-width:200px`.
  **NE PAS** revenir à un CSS grid - le scroll est intentionnel pour supporter N > 4 stats.
- **PSR-4** : une classe par fichier.
- **i18n** : champs traduisibles via `mt-foundation` (`HasTranslatableCasts`) ; ne jamais
  réécrire `$model->{champ}` traduisible dans un hook (le `__get` aplatit à la locale courante).

## 4. Ce qui vit ICI vs dans le projet hôte

- **Ici (mt-ui)** : layouts, composants UI réutilisables, framework de formulaires,
  dashboard générique, auth UI, locale/RTL, recherche, dropdowns, tables, actions.
- **Projet hôte** : routes, config (sidebar, app_name), classes `Dashboard`/`Form` concrètes
  qui étendent les bases, vues de widgets `custom`, brand, données métier.

En cas de doute : « est-ce que ça aurait du sens dans un SaaS non scolaire ? »
Si non → ça va dans le projet hôte ou un package métier, pas dans mt-ui.
