{{--
|--------------------------------------------------------------------------
| mt-ui :: dropdown/divider.blade.php
|--------------------------------------------------------------------------
| Séparateur horizontal subtil entre groupes d'items.
|
| Usage : <x-mt-dropdown.divider />
|
--}}
<div class="h-px bg-gray-100 dark:bg-white/6 my-1"></div>


{{--
|--------------------------------------------------------------------------
| mt-ui :: dropdown/section.blade.php
|--------------------------------------------------------------------------
| Label de section (groupe d'items).
|
| Usage : <x-mt-dropdown.section label="Compte" />
|
--}}

{{-- Ce fichier est séparé ci-dessous - voir section.blade.php --}}
