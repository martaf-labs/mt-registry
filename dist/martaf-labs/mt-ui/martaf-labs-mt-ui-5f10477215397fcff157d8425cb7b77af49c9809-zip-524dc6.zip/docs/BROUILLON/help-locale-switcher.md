# Système de langues - mt-ui

## Fichiers à intégrer

```
mt-ui/
├── config/
│   └── mt-ui.php                  ← ajouter les clés de mt-ui_additions.php
├── lang/
│   ├── fr/mt-ui.php               ✅ prêt
│   ├── en/mt-ui.php               ✅ prêt
│   └── ar/mt-ui.php               ✅ prêt
├── routes/
│   └── web.php                       ✅ prêt (route GET locale switch)
├── src/
│   ├── Helpers/
│   │   └── MtLocale.php              ✅ prêt
│   ├── Http/Middleware/
│   │   └── SetMtLocale.php           ✅ prêt
│   ├── Livewire/
│   │   └── LocaleSwitcher.php        ✅ prêt
│   └── MtUiServiceProvider.php   ← intégrer MtUiServiceProvider_additions.php
└── resources/views/
    ├── components/
    │   └── locale-switcher.blade.php ✅ prêt (version Blade GET)
    └── livewire/
        └── locale-switcher.blade.php ✅ prêt (version Livewire)
```

---

## 1. Intégrer dans MtUiServiceProvider.php

```php
// Dans register()
$this->app->singleton(\Mtech\MtUi\Helpers\MtLocale::class);

// Dans boot()
$this->loadTranslationsFrom(__DIR__ . '/../lang', 'mt-ui');
$this->loadRoutesFrom(__DIR__ . '/../routes/web.php');

$this->publishes([
    __DIR__ . '/../lang' => $this->app->langPath('vendor/mt-ui'),
], 'mt-ui-lang');

// Appliquer la locale sauvegardée en session
$locale = \Mtech\MtUi\Helpers\MtLocale::get();
$this->app->setLocale($locale);

// Livewire component
\Livewire\Livewire::component('mt-ui::locale-switcher', \Mtech\MtUi\Livewire\LocaleSwitcher::class);
```

---

## 2. Ajouter le middleware (projet hôte)

### Laravel 11+ (`bootstrap/app.php`)
```php
->withMiddleware(function (Middleware $middleware) {
    $middleware->appendToGroup('web', \Mtech\MtUi\Http\Middleware\SetMtLocale::class);
})
```

### Laravel 10 (`app/Http/Kernel.php`)
```php
protected $middlewareGroups = [
    'web' => [
        // ...
        \Mtech\MtUi\Http\Middleware\SetMtLocale::class,
    ],
];
```

---

## 3. Utilisation dans les layouts

### Version Livewire (recommandée, mise à jour sans reload)
```blade
<livewire:mt-ui::locale-switcher />
```

### Version Blade + GET (plus simple, reload page)
```blade
<x-mt-ui::locale-switcher />
{{-- ou aligné à gauche : --}}
<x-mt-ui::locale-switcher align="left" />
```

---

## 4. Traduire les strings des composants

```blade
{{-- Avant --}}
<span>Rechercher...</span>

{{-- Après --}}
<span>{{ __('mt-ui::mt-ui.search') }}</span>

{{-- Ou avec le helper --}}
<span>{{ \Mtech\MtUi\Helpers\MtLocale::trans('search') }}</span>
```

---

## 5. Surcharger les traductions (projet hôte)

```bash
php artisan vendor:publish --tag=mt-ui-lang
```

Cela copie les fichiers dans `lang/vendor/mt-ui/` pour surcharge locale.

---

## 6. Ajouter une nouvelle locale

Dans `config/mt-ui.php` du projet hôte :
```php
'available_locales' => [
    'fr' => ['label' => 'Français', 'flag' => '🇫🇷'],
    'en' => ['label' => 'English',  'flag' => '🇬🇧'],
    'ar' => ['label' => 'العربية',  'flag' => '🇹🇩'],
    'de' => ['label' => 'Deutsch',  'flag' => '🇩🇪'], // ← nouvelle langue
],
```

Créer le fichier `lang/vendor/mt-ui/de/mt-ui.php`.

---

## Support RTL (arabe)

Pour activer le RTL automatiquement dans les layouts, ajouter dans `master.blade.php` :
```blade
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}">
```
