# Intégration Image Optimizer → mt-ui

## Fichiers à ajouter / modifier dans ton package mt-ui

---

## 1. Nouveaux fichiers à CRÉER

```
src/
├── Contracts/
│   └── ImageOptimizerContract.php       ← Interface du service
├── DTOs/
│   └── ImageOptimizationResult.php      ← DTO résultat (readonly class)
├── Services/
│   └── ImageOptimizerService.php        ← Cœur de l'optimisation
├── Traits/
│   └── HasImageOptimization.php         ← Trait à ajouter sur BaseImage
├── Jobs/
│   └── OptimizeImageJob.php             ← Job queue
├── Commands/
│   ├── OptimizeImagesCommand.php        ← php artisan mt:images:optimize
│   └── CleanOptimizedImagesCommand.php  ← php artisan mt:images:clean
└── Livewire/Forms/
    └── ImageManager.php                 ← Remplacement de l'existant

resources/views/livewire/forms/
└── image-manager.blade.php              ← Vue enrichie (onglets upload/galerie/résultats)

config/
└── mt-ui.php                         ← Ajout de la clé 'image_optimizer'
```

---

## 2. Fichiers à MODIFIER

### `composer.json` - Ajouter les dépendances

```json
"require": {
    ...
    "intervention/image": "^3.0",
    "spatie/image-optimizer": "^1.7"
}
```

Puis lancer :
```bash
composer update
```

### `MtUiServiceProvider.php` - Ajouter 3 blocs

**Bloc A - Dans `boot()`, après les bindings existants :**
```php
use Mt\MtUi\Services\ImageOptimizerService;
use Mt\MtUi\Contracts\ImageOptimizerContract;

// Binding du service d'optimisation
$this->app->singleton(ImageOptimizerContract::class, function ($app) {
    return new ImageOptimizerService(
        $app['config']['mt-ui.image_optimizer'] ?? []
    );
});
$this->app->alias(ImageOptimizerContract::class, 'mt.image-optimizer');
```

**Bloc B - Dans `boot()`, à la fin :**
```php
if ($this->app->runningInConsole()) {
    $this->commands([
        \Mt\MtUi\Commands\OptimizeImagesCommand::class,
        \Mt\MtUi\Commands\CleanOptimizedImagesCommand::class,
    ]);
}
```

**Bloc C - `registerLivewireComponents()` : le composant `mt.forms.image-manager` est déjà enregistré, il suffit que la nouvelle classe PHP soit en place - rien à changer dans le ServiceProvider.**

### `Models/BaseImage.php` - Ajouter le trait

```php
use Mt\MtUi\Traits\HasImageOptimization;

abstract class BaseImage extends MtBaseModel
{
    use HasImageOptimization; // ← ajouter cette ligne
    ...
}
```

---

## 3. Variables d'environnement à ajouter dans `.env`

```env
# Disque de stockage
MT_IMAGE_DISK=public

# Dossier de sortie (relatif au disque)
MT_IMAGE_OUTPUT_DIR=images/optimized

# Qualité de compression
MT_IMAGE_QUALITY_JPG=85
MT_IMAGE_QUALITY_WEBP=85

# Formats modernes
MT_IMAGE_WEBP=true
MT_IMAGE_AVIF=false

# Taille max upload (en KB)
MT_IMAGE_MAX_SIZE=10240

# File d'attente
MT_IMAGE_QUEUE=true
MT_IMAGE_QUEUE_NAME=default

# Watermark (optionnel)
MT_IMAGE_WATERMARK=false
```

---

## 4. Outils système recommandés (compression maximale)

```bash
# Ubuntu / Debian
sudo apt-get install jpegoptim optipng pngquant gifsicle webp

# macOS
brew install jpegoptim optipng pngquant gifsicle webp
```

Ces outils sont **optionnels** : s'ils ne sont pas installés, l'optimisation via Intervention Image reste active.

---

## 5. Utilisation dans les projets

### A) Composant Livewire dans une vue

```blade
{{-- Gestionnaire complet avec upload, galerie et résultats --}}
<livewire:mt.forms.image-manager
    :model-type="get_class($post)"
    :model-id="$post->id"
    image-type="photo"
    :multiple="true"
    :allow-delete="true"
/>
```

### B) Depuis un modèle qui utilise BaseImage

```php
// Ton modèle Image étend BaseImage (qui a déjà le trait)
class Image extends BaseImage {}

$image = Image::find(1);

// URL optimisée (WebP > original)
echo $image->optimized_url;

// Variante spécifique
echo $image->getVariantUrl('medium');    // URL de la variante medium
echo $image->getVariantUrl('thumbnail'); // URL miniature

// HTML <picture> complet avec srcset WebP/AVIF + fallback
echo $image->getPictureHtml([
    'alt'   => $image->titre,
    'class' => 'w-full rounded-xl object-cover',
]);

// Infos
$image->isOptimized();          // true/false
$image->getSavingsPercent();    // ex: 42.5
$image->getDimensions();        // ['width' => 1200, 'height' => 800]
```

### C) Depuis un Controller ou Service

```php
use Mt\MtUi\Contracts\ImageOptimizerContract;

class PostController extends Controller
{
    public function store(Request $request, ImageOptimizerContract $optimizer)
    {
        $result = $optimizer->optimizeUpload($request->file('image'));

        if ($result->success) {
            Post::create([
                'image_path' => $result->storagePath,
                // Les variantes sont dans $result->variants
            ]);
        }
    }
}
```

### D) Commandes Artisan

```bash
# Optimiser toutes les images
php artisan mt:images:optimize

# Optimiser un dossier précis avec WebP forcé
php artisan mt:images:optimize uploads/posts --webp --quality=80

# Simuler sans modifier
php artisan mt:images:optimize --dry-run

# Nettoyer les images optimisées de plus de 30 jours
php artisan mt:images:clean --older-than=30
```

### E) Écouter les événements Livewire dans un composant parent

```php
use Livewire\Attributes\On;

class PostForm extends Component
{
    public ?string $imagePath = null;

    #[On('mt:image-saved')]
    public function onImageSaved(array $data): void
    {
        $this->imagePath = $data['path'];
        // $data['variants'] contient les URLs WebP, medium, etc.
    }

    #[On('mt:image-deleted')]
    public function onImageDeleted(array $data): void
    {
        $this->imagePath = null;
    }
}
```

---

## 6. Résumé des changements par fichier

| Fichier                              | Action       | Impact                                      |
|--------------------------------------|--------------|---------------------------------------------|
| `composer.json`                      | Modifier     | Ajouter 2 dépendances                       |
| `MtUiServiceProvider.php`         | Modifier      | 3 ajouts ciblés (binding + commands)        |
| `Models/BaseImage.php`               | Modifier     | Ajouter `use HasImageOptimization` (1 ligne) |
| `Contracts/ImageOptimizerContract.php` | Créer      | Interface du service                        |
| `DTOs/ImageOptimizationResult.php`   | Créer        | DTO résultat                                |
| `Services/ImageOptimizerService.php` | Créer        | Cœur de l'optimisation                      |
| `Traits/HasImageOptimization.php`    | Créer        | Méthodes sur les modèles images             |
| `Jobs/OptimizeImageJob.php`          | Créer        | Traitement asynchrone                       |
| `Commands/OptimizeImagesCommand.php` | Créer        | `php artisan mt:images:optimize`            |
| `Commands/CleanOptimizedImagesCommand.php` | Créer  | `php artisan mt:images:clean`               |
| `Livewire/Forms/ImageManager.php`    | Remplacer    | Composant enrichi (même nom de route)       |
| `views/livewire/forms/image-manager.blade.php` | Remplacer | Vue avec onglets                   |
| `config/mt-ui.php`                | Modifier     | Ajouter clé `image_optimizer`               |
