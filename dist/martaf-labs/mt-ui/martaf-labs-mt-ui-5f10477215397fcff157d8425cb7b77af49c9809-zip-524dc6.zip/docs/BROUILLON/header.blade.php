{{--
|--------------------------------------------------------------------------
| mt-ui :: dropdown/header.blade.php
|--------------------------------------------------------------------------
| Bloc en-tête utilisateur en haut du dropdown.
|
| Usage :
|   <x-mt-dropdown.header
|       name="{{ auth()->user()->name }}"
|       email="{{ auth()->user()->email }}"
|       :avatar="auth()->user()->avatar_url ?? null"
|   />
|
| Props :
|   name    → nom affiché
|   email   → email affiché
|   avatar  → URL image (optionnel - sinon initiales)
|
--}}

@props([
    'name'   => '',
    'email'  => '',
    'avatar' => null,
])

@php
    $initials = collect(explode(' ', $name))
        ->take(2)
        ->map(fn($w) => strtoupper(substr($w, 0, 1)))
        ->implode('');
@endphp

<div class="flex items-center gap-3 px-4 py-3.5">

    {{-- Avatar --}}
    <div class="shrink-0 relative">
        @if($avatar)
            <img
                src="{{ $avatar }}"
                alt="{{ $name }}"
                class="w-9 h-9 rounded-xl object-cover ring-2 ring-[rgb(var(--mt-secondary,59_130_246))]/20"
            >
        @else
            <div class="
                w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold text-white
                bg-gradient-to-br from-[rgb(var(--mt-secondary,59_130_246))] to-[rgb(var(--mt-secondary,59_130_246))]/70
            ">
                {{ $initials ?: '?' }}
            </div>
        @endif
        <span class="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-400 rounded-full ring-2 ring-white dark:ring-[rgb(var(--mt-bg,28_28_35))]"></span>
    </div>

    {{-- Infos --}}
    <div class="min-w-0 flex-1">
        <p class="text-sm font-semibold text-gray-900 dark:text-white truncate leading-tight">
            {{ $name }}
        </p>
        <p class="text-xs text-gray-400 dark:text-white/40 truncate leading-tight mt-0.5">
            {{ $email }}
        </p>
    </div>

</div>
