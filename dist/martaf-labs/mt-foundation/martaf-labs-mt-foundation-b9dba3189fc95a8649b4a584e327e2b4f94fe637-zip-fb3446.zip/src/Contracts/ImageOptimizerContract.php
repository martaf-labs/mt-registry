<?php

namespace Mt\MtFoundation\Contracts;

use Mt\MtFoundation\DTOs\ImageOptimizationResult;

interface ImageOptimizerContract
{
    /**
     * Optimise un fichier uploadé (UploadedFile Livewire ou Request).
     */
    public function optimizeUpload(\Illuminate\Http\UploadedFile $file, array $options = []): ImageOptimizationResult;

    /**
     * Optimise une image depuis son chemin absolu sur le disque.
     */
    public function optimizePath(string $absolutePath, array $options = []): ImageOptimizationResult;

    /**
     * Génère toutes les variantes responsive + WebP/AVIF d'un chemin stocké.
     */
    public function generateVariants(string $storagePath, array $options = []): array;

    /**
     * Supprime une image et toutes ses variantes générées.
     */
    public function delete(string $storagePath): bool;
}
