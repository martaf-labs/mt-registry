<?php

namespace Mt\MtFoundation\Contracts;

interface HasBaseIndexContract
{
    /**
     * element de la barre de navigation
     * @return array
     */
    public function getNavItems():array;

    /**
     * Actions principales de la page
     * @return array
     */
    public function mainActions():array;

    /**
     * Actions associé à une ligne
     * @param mixed $rowId
     * @return array
     */
    public function rowActions($rowId):array;

    /**
     * Toutes colones du tableau
     * @param mixed $rowId
     * @return void
     */
    public function columns($rowId=null):array;
}