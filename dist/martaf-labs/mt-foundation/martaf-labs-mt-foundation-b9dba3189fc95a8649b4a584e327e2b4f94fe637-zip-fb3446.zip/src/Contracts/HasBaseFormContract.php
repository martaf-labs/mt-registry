<?php

namespace Mt\MtFoundation\Contracts;

interface HasBaseFormContract
{
    /**
     * @return array
     */
    public function fieldActions():array;
}