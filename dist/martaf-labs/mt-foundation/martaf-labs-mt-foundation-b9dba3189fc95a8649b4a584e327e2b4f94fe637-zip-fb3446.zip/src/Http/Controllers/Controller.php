<?php

namespace Mt\MtFoundation\Http\Controllers;

abstract class Controller
{
    //
}
