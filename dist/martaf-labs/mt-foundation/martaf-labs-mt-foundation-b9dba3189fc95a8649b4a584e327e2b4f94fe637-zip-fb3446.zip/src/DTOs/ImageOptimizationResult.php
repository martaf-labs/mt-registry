<?php

namespace Mt\MtFoundation\DTOs;

/**
 * Résultat d'une opération d'optimisation d'image.
 */
readonly class ImageOptimizationResult
{
    public function __construct(
        public bool    $success,
        public string  $originalPath,   // chemin absolu original
        public string  $storagePath,    // chemin relatif stocké (ex: images/optimized/photo.jpg)
        public int     $originalSize,   // en octets
        public int     $optimizedSize,  // en octets
        public float   $savingsPercent,
        public array   $variants  = [], // ['webp' => 'path', 'medium' => 'path', ...]
        public array   $metadata  = [], // width, height, driver
        public ?string $error     = null,
    ) {}

    public function savedBytes(): int
    {
        return max(0, $this->originalSize - $this->optimizedSize);
    }

    public function toArray(): array
    {
        return [
            'success'          => $this->success,
            'original_path'    => $this->originalPath,
            'storage_path'     => $this->storagePath,
            'original_size'    => $this->originalSize,
            'optimized_size'   => $this->optimizedSize,
            'savings_percent'  => round($this->savingsPercent, 2),
            'saved_bytes'      => $this->savedBytes(),
            'variants'         => $this->variants,
            'metadata'         => $this->metadata,
            'error'            => $this->error,
        ];
    }
}
