<?php

namespace Mt\MtFoundation\Services;

use Mt\MtFoundation\Models\BaseImage;
use Mt\MtFoundation\Contracts\ImageModelContract;

class ImageService
{
    public function __construct(
        protected ImageModelContract $images
    ) {}

    protected function model(): string
    {
        return $this->images->model();
    }

    public function create(array $attributes): BaseImage
    {
        $modelClass = $this->model();

        /** @var BaseImage $image */
        $image = $modelClass::query()->create($attributes);

        return $image;
    }

    public function update(int $id, array $attributes): BaseImage
    {
        $modelClass = $this->model();

        /** @var BaseImage|null $image */
        $image = $modelClass::query()->find($id);

        if (! $image) {
            throw new \RuntimeException("Image #{$id} not found");
        }

        $image->fill($attributes);
        $image->save();
        return $image;
    }
    public function findImage(int $id) : ?BaseImage
    {
        $model = $this->images->model();

        return $model::query()->find($id);
    }

    public function count(): int
    {
        $model = $this->images->model();

        return $model::query()->count();
    }
    public function get()
    {
        $model = $this->images->model();

        return $model::query()->get();
    }
    
    /**
     * Permet de récupérer le builder Eloquent du model Image
     */
    public function query(): \Illuminate\Database\Eloquent\Builder
    {
        return $this->model()::query();

    }

}