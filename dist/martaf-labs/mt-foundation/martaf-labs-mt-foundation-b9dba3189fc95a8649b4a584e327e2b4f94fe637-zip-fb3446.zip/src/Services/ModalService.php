<?php

namespace Mt\MtFoundation\Services;

class ModalService
{
    // Méthodes helpers pour les confirms
    public static function confirmDelete($itemName, $action, $params = [])
    {
        return [
            'title' => 'Suppression',
            'message' => "Êtes-vous sûr de vouloir supprimer \"{$itemName}\" ? Cette action est irréversible.",
            'confirmText' => 'Supprimer',
            'cancelText' => 'Annuler',
            'variant' => 'danger',
            'icon' => 'trash',
            'action' => $action,
            'actionParams' => $params,
        ];
    }

    public static function confirmUpdate($itemName, $action, $params = [])
    {
        return [
            'title' => 'Modification',
            'message' => "Confirmez-vous la modification de \"{$itemName}\" ?",
            'confirmText' => 'Modifier',
            'cancelText' => 'Annuler',
            'variant' => 'primary',
            'icon' => 'pencil',
            'action' => $action,
            'actionParams' => $params,
        ];
    }

    // Méthodes helpers pour les alerts
    public static function success($message, $autoClose = true)
    {
        return [
            'title' => 'Succès',
            'message' => $message,
            'variant' => 'success',
            'icon' => 'check-circle',
            'autoClose' => $autoClose,
        ];
    }

    public static function error($message, $autoClose = false)
    {
        return [
            'title' => 'Erreur',
            'message' => $message,
            'variant' => 'error',
            'icon' => 'x-circle',
            'autoClose' => $autoClose,
        ];
    }

    public static function warning($message, $autoClose = false)
    {
        return [
            'title' => 'Attention',
            'message' => $message,
            'variant' => 'warning',
            'icon' => 'exclamation-triangle',
            'autoClose' => $autoClose,
        ];
    }

    public static function info($message, $autoClose = true)
    {
        return [
            'title' => 'Information',
            'message' => $message,
            'variant' => 'info',
            'icon' => 'information-circle',
            'autoClose' => $autoClose,
        ];
    }
}
