<?php

namespace Mt\MtFoundation\Traits;

use Illuminate\Support\Str;

trait HasMultilingualFormatter
{
    /**
     * Initialise le trait et écoute l'événement "saving".
     */
    protected static function bootHasMultilingualFormatter()
    {
        static::saving(function ($model) {
            $model->formatMultilingualFields();
        });
    }

    /**
     * Logique de formatage et de fallback.
     */
    public function formatMultilingualFields()
    {
        // On suppose que le modèle définit public $translatables = [...];
        if (!isset($this->translatables)) return;

        foreach ($this->translatables as $field) {
            $data = $this->{$field};

            if (is_array($data)) {
                // 1. Formatage spécifique (Nom/Prénom)
                if (in_array($field, ['nom', 'prenom']) && isset($data['fr'])) {
                    $data['fr'] = ucwords(Str::lower(trim($data['fr'])));
                }

                // 2. Fallback automatique vers le français
                foreach (['ar', 'en'] as $lang) {
                    if (empty($data[$lang]) && !empty($data['fr'])) {
                        $data[$lang] = $data['fr'];
                    }
                }

                // Réassignation de la valeur modifiée au modèle
                $this->{$field} = $data;
            }
        }
    }
}
