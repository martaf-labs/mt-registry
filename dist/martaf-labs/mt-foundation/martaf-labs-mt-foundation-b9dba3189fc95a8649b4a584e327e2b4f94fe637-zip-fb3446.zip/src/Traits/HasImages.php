<?php

namespace Mt\MtFoundation\Traits;

use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Mt\MtFoundation\Contracts\ImageModelContract;
use Illuminate\Database\Eloquent\Casts\Attribute;


trait HasImages
{
        
    public function hasFeatured(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->image()->exists(),
        );
        
    }
        
    public function getVariantImage(?string $variant = 'medium')
    {
        return $this->image?->isOptimized() ?
            $this->image->getVariantUrl($variant) : 
            ($this->image?->imageUrl ?? '');
        
    }

    public function images() : MorphMany
    {
        return $this->morphMany( app(ImageModelContract::class)->model(), 'model');
    }

    public function image() : MorphOne
    {
        return $this->morphOne( app(ImageModelContract::class)->model(), 'model')
        ->where('is_featured', true);
    }
}