<?php

namespace Mt\MtFoundation\Traits;

use Illuminate\Database\Eloquent\Builder;

/**
 * Trait IsSearchable
 *
 * Ajoutez ce trait à vos modèles pour bénéficier du scope searchQuery()
 * et d'une implémentation par défaut de searchColor().
 *
 * Usage :
 *   class User extends Model implements Searchable
 *   {
 *       use IsSearchable;
 *       ...
 *   }
 */
trait IsSearchable
{
    /**
     * Scope Eloquent qui applique les conditions LIKE sur les colonnes déclarées.
     * Utilisation : User::searchQuery('john')->limit(5)->get()
     */
    public static function searchQuery(string $query, ?string $category = null): Builder
    {
        $q = trim($query);

        $builder = static::query();

        if ($q === '') {
            return $builder->whereRaw('0 = 1'); // rien si vide
        }

        $columns = static::searchableColumns();

        $builder->where(function (Builder $sub) use ($q, $columns) {
            foreach ($columns as $col) {
                $sub->orWhere($col, 'LIKE', "%{$q}%");
            }
        });

        return $builder;
    }

    /**
     * Couleur par défaut (peut être surchargée dans le modèle).
     */
    public static function searchColor(): string
    {
        return 'blue';
    }
}
