<?php

namespace Mt\MtFoundation\Enums;

enum RolesUser: string
{
    case DEVELOPPEUR      = 'developpeur';
    case ADMINISTRATEUR   = 'administrateur';

    /**
     * Libellé lisible
     * @return string
     */
    public function label() : string
    {
        return match ($this){
            self::DEVELOPPEUR       => 'Développeur',
            self::ADMINISTRATEUR    => 'Administrateur',
        };
    }

    /**
     * Liste clé => label
     * @return array
     */
    public static function options():array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
