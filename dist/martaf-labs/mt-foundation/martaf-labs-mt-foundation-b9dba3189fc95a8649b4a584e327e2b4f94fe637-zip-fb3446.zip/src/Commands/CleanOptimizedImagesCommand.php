<?php

namespace Mt\MtFoundation\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class CleanOptimizedImagesCommand extends Command
{
    protected $signature = 'mt:images:clean
                            {--disk= : Disque à utiliser}
                            {--older-than= : Supprimer les fichiers plus vieux que N jours}
                            {--force : Sans confirmation}';

    protected $description = '[mt-views] Supprime les images optimisées du dossier de sortie';

    public function handle(): int
    {
        $diskName  = $this->option('disk') ?: config('mt-views.image_optimizer.disk', 'public');
        $outputDir = config('mt-views.image_optimizer.output_directory', 'images/optimized');
        $olderThan = $this->option('older-than');
        $disk      = Storage::disk($diskName);

        $files = $disk->allFiles($outputDir);

        if ($olderThan) {
            $cutoff = now()->subDays((int) $olderThan)->timestamp;
            $files  = array_filter($files, fn ($f) => $disk->lastModified($f) < $cutoff);
        }

        $count = count($files);

        if ($count === 0) {
            $this->info('Aucun fichier à supprimer.');
            return self::SUCCESS;
        }

        if (!$this->option('force') && !$this->confirm("{$count} fichier(s) vont être supprimés. Continuer ?")) {
            $this->info('Annulé.');
            return self::SUCCESS;
        }

        foreach ($files as $file) {
            $disk->delete($file);
        }

        $this->info("✅ {$count} fichier(s) supprimé(s) dans [{$outputDir}].");

        return self::SUCCESS;
    }
}
