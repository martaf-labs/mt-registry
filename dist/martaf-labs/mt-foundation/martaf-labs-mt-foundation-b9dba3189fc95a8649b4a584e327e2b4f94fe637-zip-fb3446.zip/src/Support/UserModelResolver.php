<?php

namespace Mt\MtFoundation\Support;

use Mt\MtFoundation\Contracts\UserModelContract;
use Mt\MtFoundation\Models\BaseUser;

class UserModelResolver implements UserModelContract
{
    public function model() : string
    {
 
        /** @var class-string $model */

        $model = config('auth.providers.users.model');
        
        // on retire le "::class" s'il n'est pas écrit par erreur
        $model = str_ends_with($model, '::class') ? substr($model, 0, -7) : $model;       


        if (!is_subclass_of($model, BaseUser::class)) {
            throw new \RuntimeException(
                "Le model User doit être étendu ". BaseUser::class
            );
        }

        return $model;
    }
}