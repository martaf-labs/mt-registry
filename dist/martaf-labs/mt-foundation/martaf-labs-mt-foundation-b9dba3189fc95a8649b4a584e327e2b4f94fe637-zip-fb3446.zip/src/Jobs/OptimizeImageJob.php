<?php

namespace Mt\MtFoundation\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Mt\MtFoundation\Contracts\ImageOptimizerContract;

class OptimizeImageJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 3;
    public int $timeout = 120;

    public function __construct(
        protected string $storagePath,
        protected array  $options = [],
    ) {}

    public function handle(ImageOptimizerContract $optimizer): void
    {
        $disk     = config('mt-views.image_optimizer.disk', 'public');
        $fullPath = Storage::disk($disk)->path($this->storagePath);

        if (!file_exists($fullPath)) {
            Log::warning("[mt-views/OptimizeImageJob] Fichier introuvable : {$this->storagePath}");
            return;
        }

        $optimizer->optimizePath($fullPath, $this->options);
    }

    public function failed(\Throwable $e): void
    {
        Log::channel(config('mt-views.image_optimizer.logging.channel', 'stack'))
            ->error('[mt-views/OptimizeImageJob] Échec : ' . $e->getMessage(), [
                'path' => $this->storagePath,
            ]);
    }
}
