<?php

namespace Mt\MtFoundation;

use Livewire\Livewire;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Relations\Relation;
use Mt\MtFoundation\Contracts\ImageOptimizerContract;
use Mt\MtFoundation\Services\ImageOptimizerService;
use Mt\MtFoundation\Services\ReferenceGeneratorService;

class MtFoundationServiceProvider extends ServiceProvider
{
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        $this->basePath = dirname(__DIR__);
    }

    public function register(): void
    {
        $configPath = $this->basePath . '/config';

        // Fusion des configurations
        if (file_exists($configPath)) {
            $this->mergeConfigFrom($configPath.'/mt-foundation.php', 'mt-foundation');
            $this->mergeConfigFrom($configPath.'/mt-search.php', 'mt-search');
        }

        // Singletons
        $this->app->singleton(\Mt\MtFoundation\Contracts\UserModelContract::class, \Mt\MtFoundation\Support\UserModelResolver::class);
        $this->app->singleton(\Mt\MtFoundation\Contracts\ImageModelContract::class, \Mt\MtFoundation\Support\ImageModelResolver::class);
        $this->app->singleton(\Mt\MtFoundation\Helpers\MtLocale::class);

        $this->app->singleton(ImageOptimizerContract::class, function ($app) {
            return new ImageOptimizerService($app['config']['mt-foundation.image_optimizer'] ?? []);
        });

        $this->app->singleton(ReferenceGeneratorService::class, fn() => new ReferenceGeneratorService());
    }

    public function boot(): void
    {
        $viewsPath = $this->basePath . '/resources/views';
        $langPath  = $this->basePath . '/lang';

        // 4. TRADUCTIONS
        $this->loadTranslationsFrom($langPath, 'mt-foundation');

        // 5. ASSETS & PUBLISHES
        $this->registerPublishing($viewsPath, $langPath);

        // 6. AUTRES SERVICES
        $this->registerDatabaseLogic();
    }

    protected function registerPublishing($viewsPath, $langPath): void
    {
        if ($this->app->runningInConsole()) {
            $this->publishes([$viewsPath => resource_path('views/vendor/mt/mt-foundation')], 'mt-foundation');
            $this->publishes([$langPath => $this->app->langPath('vendor/mt/mt-foundation')], 'mt-foundation-lang');
            $this->publishes([
                $this->basePath . '/config/mt-foundation.php' => config_path('mt-foundation.php'),
            ], 'mt-foundation-config');
        }
    }

    protected function registerDatabaseLogic(): void
    {
        if (is_dir($this->basePath . '/database/migrations')) {
            $this->loadMigrationsFrom($this->basePath . '/database/migrations');
        }

        Blueprint::macro('tracksUser', function () {
            $this->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $this->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $this->foreignId('deleted_by')->nullable()->constrained('users')->nullOnDelete();
        });
    }
}
