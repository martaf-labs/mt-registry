<?php

/**
 * Verifier si le dark mode est actif
 */
if (!function_exists('has_dark_mode')) {
    function has_dark_mode() {
        
        return mt_config('enable_dark_mode');
    }
}

/**
 * Verifier si le dashboard est actif
 */
if (!function_exists('has_dashboard')) {
    function has_dashboard() {
        
        return mt_config('enable_dashboard');
    }
}

/**
 * Verifier l'autorisation d'affichage des options d'une vue ou d'un composant
 */
if (!function_exists('has_option')) {
    function has_option(string $viewName, string $optionName) {

        if(!$viewName || !$optionName){
            return false;
        }
        return mt_config($viewName.''.'.options.'.''.$optionName);
    }
}

/**
 * Verifier l'autorisation d'affichage des options de la vue login
 */
if (!function_exists('has_option_login')) {
    function has_option_login(string $optionName) {

        return has_option('login',$optionName);

    }
}

