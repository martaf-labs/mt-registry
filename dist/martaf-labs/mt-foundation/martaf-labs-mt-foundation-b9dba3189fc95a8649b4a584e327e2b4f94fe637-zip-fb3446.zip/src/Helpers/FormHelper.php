<?php

namespace Mt\MtFoundation\Helpers;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class FormHelper
{
    // Clé de session unique pour ce formulaire multi-étapes
    protected string $sessionKey;

    // Nom du modèle associé
    protected string $modelName;

    // Configuration complète du formulaire (champs, étapes, règles, etc.)
    protected array $formConfig;

    // Constructeur : initialise le nom du modèle, la configuration et la clé de session
    public function __construct(string $modelName, array $formConfig)
    {
        $this->modelName = $modelName;
        $this->formConfig = $formConfig;
        $this->sessionKey = "formSessionData.{$modelName}";

    }

    // Récupère l'étape actuelle à partir de la requête ou de la session
    public function currentStep(): int
    {
        // return $request->input('currentStep', session("{$this->sessionKey}.currentStep", 1));
        return session("{$this->sessionKey}.currentStep", 1);
    }

    // Mettre à jour l'étape actuelle dans la session
    public function storeCurrentStep(int $curentStep)
    {
        session()->put("{$this->sessionKey}.currentStep", $curentStep);
    }

    // Récupère la direction de navigation ('next' ou 'previous'), par défaut 'next'
    public function direction(Request $request): string
    {
        return $request->input('direction', 'next');
    }

    // Vérifie si le formulaire est configuré comme un formulaire multi-étapes
    public function isMultiStep(): bool
    {
        return $this->formConfig['__meta']['isMultiStep'] ?? false;
    }

    // Récupère la liste des étapes définies dans la configuration
    public function steps(): array
    {
        return $this->formConfig['__meta']['steps'] ?? [1];
    }

    // Vérifie si l'étape actuelle est la dernière
    public function isLastStep(int $step): bool
    {
        $steps = $this->steps();
        return $step === end($steps);
    }

    // Récupère les champs définis pour une étape donnée
    public function getStepFields(int $step): array
    {
        return $step>0 ? ($this->formConfig[$step] ?? []) : $this->formConfig;
    }

    // Valide les données de la requête selon les règles de l'étape
    public function validateStep(Request $request, int $step): array
    {
        $fields = $this->getStepFields($step);

        $rules = [];
        foreach ($fields as $name => $field) {
            if (empty($field['rules'])) continue;

            // Si la règle est un tableau (ex: pour fichiers multiples)
            if (is_array($field['rules'])) {
                foreach ($field['rules'] as $subKey => $rule) {
                    $rules[$subKey] = $rule;
                }
            } else {
                $rules[$name] = $field['rules'];
            }
        }

        $messages = $this->formConfig['__messages'] ?? [];

        return $request->validate($rules, $messages);
    }


    // Stocke les données d'une étape dans la session (sauf les champs temporaires)
    public function storeStepData(int $step, array $data): void
    {
        $fields = $this->getStepFields($step);

        // Filtrer les données pour exclure les champs temporaires
        $filtered = collect($data)->filter(fn($value, $key) =>
            !isset($fields[$key]['isTemporary']) || !$fields[$key]['isTemporary']
        )->toArray();

        // Récupère les données existantes et les met à jour
        $all = session($this->sessionKey . '.data', []);
        $all[$step] = $filtered;

        // Enregistre les données dans la session
        session()->put($this->sessionKey . '.data', $all);
        session()->put($this->sessionKey . '.currentStep', $step);
    }

    // Récupère les données globales stockées indépendamment des étapes
    public function getGlobalData(): array
    {
        return session("{$this->sessionKey}.global", []);
    }

    // Stocke ou met à jour les données globales dans la session
    public function storeGlobalData(array $data): void
    {
        $existing = session("{$this->sessionKey}.global", []);
        $merged = array_merge($existing, $data);
        session()->put("{$this->sessionKey}.global", $merged);
    }

    // Récupère et fusionne toutes les données des étapes sous forme de collection
    public function allData(): Collection
    {
        return collect(session("{$this->sessionKey}.data", []))->collapse();
    }

    // Détermine l'étape suivante à partir de l'étape actuelle
    public function goToNextStep(int $current): int
    {
        $steps = $this->steps();
        $index = array_search($current, $steps);
        $step = $steps[$index] ?? end($steps);

        $this->storeCurrentStep($step + 1);

        return $step;
    }

    // Détermine l'étape précédente à partir de l'étape actuelle
    public function goToPreviousStep(int $current): int
    {
        $steps = $this->steps();
        $index = array_search($current, $steps);
        $step = $steps[$index] ?? $steps[0];

        $this->storeCurrentStep($step - 1);

        return $step;
    }

    // Réinitialise toutes les données de session liées à ce formulaire
    public function reset(): void
    {
        session()->forget($this->sessionKey);
    }
}
