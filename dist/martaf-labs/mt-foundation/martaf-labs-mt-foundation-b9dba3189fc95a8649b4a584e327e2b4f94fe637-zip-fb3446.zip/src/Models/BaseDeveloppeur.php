<?php

namespace Mt\MtFoundation\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtFoundation\Models\User;
use Mt\MtFoundation\Traits\LogActivityAction;
use Mt\MtFoundation\Traits\TracksUser;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

abstract class BaseDeveloppeur extends MtBaseModel
{

    protected $fillable = [
        'nom',
        'prenom',
        'sexe',
        'civilite',
        'naissance',
        'email',
        'image',
        'telephone',
        'specialite',
        'description',
    ];

    /*
    ** Methodes du model
    */
    public function user() : MorphOne
    {
        return $this->morphOne(User::class, 'userable');
    }

    public function imageUrl(): string
    {
        $imagePath = $this->image;

        if (!empty($imagePath)) {
            // Vérifie si l'image existe sur le disque CDN
            if (Storage::disk(mt_get_storage_disk())->exists($imagePath)) {
                return Storage::disk(mt_get_storage_disk())->url($imagePath);
            }
        }

        // Retourne une image par défaut si l'image n'existe pas
        return asset('images/placeholder-user.jpg');
    }

    //autres methodes
    public function fullName() : string
    {
        $fullName=$this->nom.' '.$this->prenom ?? '';
        return $fullName;
    }

}
