<?php

namespace Mt\MtFoundation\Models;

use Illuminate\Contracts\Auth\Guard;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Laravel\Fortify\TwoFactorAuthenticatable;
use Laravel\Sanctum\HasApiTokens;
use Mt\MtFoundation\Contracts\UserModelContract;
use Mt\MtFoundation\Enums\RolesUser;
use Mt\MtFoundation\Traits\HasMultilingualFormatter;
use Mt\MtFoundation\Traits\HasTranslatableCasts;
use Mt\MtFoundation\Traits\LogActivityAction;
use Mt\MtFoundation\Traits\TracksUser;
use Spatie\Permission\Traits\HasRoles;

abstract class BaseUser extends Authenticatable
{
    use TwoFactorAuthenticatable, HasFactory, HasMultilingualFormatter, HasTranslatableCasts,  HasRoles, Notifiable, SoftDeletes, TracksUser, LogActivityAction;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'userable_type',
        'userable_id',
        'name',
        'email',
        'password',
        'role',
        'last_seen',
    ];

    protected $guard_name = 'web';

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'last_seen' => 'datetime',
            'role' => RolesUser::class,
        ];
    }


    /**
     * Get the user's initials
     */
    public function initials(): string
    {
        return getInitials($this->fullName());
    }


    /**
     * verifier si un compte utilisateur peut être creer
     */
    public static function canHaveAccount($entityData)
    {
        $email=$entityData->email ?? '';

        if (filter_var($email, \FILTER_VALIDATE_EMAIL) && !self::where('email', $email)->exists()) {
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Configurer les differents niveau d'accès
     */
    public static function getAccessLevels()
    {
        return [
            RolesUser::DEVELOPPEUR->value       => 1,
            RolesUser::ADMINISTRATEUR->value    => 2
        ];
    }



    /*
    ** Methodes du model
    */
    public function userable(): MorphTo
    {
        return $this->morphTo();
    }

    public function isDev()
    {
        return $this->role === RolesUser::DEVELOPPEUR->value;
    }

    public function isAdmin()
    {
        return $this->role === RolesUser::ADMINISTRATEUR->value;
    }

    //verifier si c'est l'utisateur actif:
    public function isActive()
    {
        return $this->id === Auth::user()->id;
    }

    //verifier si un utilisateur est en ligne:
    public function isOnline()
    {
        return $this->last_seen && $this->last_seen->greaterThan(now()->subMinutes(5));
    }

    // les getters et setters

    // recuperer le nom complet de l'utilisateur
    public function fullName()
    { 
        return $this->name ?? ($this->userable? $this->userable->fullName() : null) ?? '';  
    }

}
