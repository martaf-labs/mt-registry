<?php

namespace Mt\MtFoundation\Models;

use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Support\Facades\Storage;
use Mt\MtFoundation\Enums\TypesImage;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtFoundation\Traits\HasImageOptimization; // [IMAGE OPTIMIZER]

abstract class BaseImage extends MtBaseModel
{
    use HasImageOptimization; // [IMAGE OPTIMIZER] ajout du trait

    protected $fillable = [
        'model_type',
        'model_id',
        'type',
        'title',
        'path',
        'description',
        'order',
        'actif',
        'is_featured',
        'metadata',
    ];

    protected $casts = [
        'type'    => TypesImage::class,
        'metadata'    => 'array',
        'is_featured' => 'boolean',
        'actif'       => 'boolean',
    ];

    // =========================================================================
    // Hooks
    // =========================================================================

    protected static function booted(): void
    {
        static::saving(function ($model) {
            // Garantir qu'une seule image est featured par entité
            if ($model->is_featured) {
                static::where('model_type', $model->model_type)
                    ->where('model_id', $model->model_id)
                    ->where('is_featured', true)
                    ->update(['is_featured' => false]);
            }
        });
    }

    // =========================================================================
    // Relations
    // =========================================================================

    public function modele(): MorphTo
    {
        return $this->morphTo();
    }

    // =========================================================================
    // Accesseurs existants (conservés intégralement)
    // =========================================================================

    /**
     * URL publique via asset (chemin storage/).
     */
    public function getUrlAttribute(): string
    {
        return asset('storage/' . $this->path);
    }

    /**
     * Chemin absolu sur le serveur.
     */
    public function getFullPathAttribute(): string
    {
        return storage_path('app/public/' . $this->path);
    }

    /**
     * Vérifie si le fichier physique existe.
     */
    public function fileExists(): bool
    {
        return file_exists($this->full_path);
    }

    /**
     * Supprime le fichier physique.
     */
    public function deleteFile(): bool
    {
        if ($this->fileExists()) {
            return unlink($this->full_path);
        }
        return false;
    }

    /**
     * URL via le disque de stockage (CDN ou local).
     * Conservé tel quel — utilisé comme fallback dans HasImageOptimization.
     */
    public function getImageUrlAttribute(): string
    {
        if (!empty($this->path)) {
            return Storage::disk(mt_get_storage_disk())->url($this->path);
        }

        return asset('images/placeholder-image.jpg');
    }

    // =========================================================================
    // [IMAGE OPTIMIZER] Nouveaux accesseurs (via trait HasImageOptimization)
    // =========================================================================
    //
    // Les accesseurs suivants sont désormais disponibles automatiquement :
    //
    //   $image->optimized_url          → WebP > large > original
    //   $image->getVariantUrl('medium') → URL d'une variante spécifique
    //   $image->getPictureHtml(['alt' => '...', 'class' => '...'])
    //   $image->isOptimized()
    //   $image->getSavingsPercent()
    //   $image->getDimensions()        → ['width' => 1200, 'height' => 800]
}
