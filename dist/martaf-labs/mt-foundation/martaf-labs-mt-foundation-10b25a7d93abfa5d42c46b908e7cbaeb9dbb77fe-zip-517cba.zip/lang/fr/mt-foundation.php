<?php

return [

    // Navigation & layout
    'menu'              => 'Menu',
    'close'             => 'Fermer',
    'back'              => 'Retour',
    'home'              => 'Accueil',
    'dashboard'         => 'Tableau de bord',
    'profile'           => 'Profil',
    'settings'          => 'Paramètres',
    'logout'            => 'Se déconnecter',
    'login'             => 'Se connecter',

    // Recherche
    'search'            => 'Rechercher',
    'search_placeholder'=> 'Rechercher dans l\'application',
    'search_shortcut'   => 'Ctrl+K',
    'no_results'        => 'Aucun résultat',
    'search_history'    => 'Recherches récentes',
    'load_more'         => 'Voir plus',
    'results_count'     => ':count résultat(s)',

    // Notifications
    'notifications'     => 'Notifications',
    'no_notifications'  => 'Aucune notification',
    'mark_all_read'     => 'Tout marquer comme lu',

    // Formulaires
    'save'              => 'Enregistrer',
    'cancel'            => 'Annuler',
    'delete'            => 'Supprimer',
    'edit'              => 'Modifier',
    'create'            => 'Créer',
    'update'            => 'Mettre à jour',
    'confirm'           => 'Confirmer',
    'submit'            => 'Soumettre',
    'reset'             => 'Réinitialiser',
    'upload'            => 'Téléverser',
    'download'          => 'Télécharger',
    'select'            => 'Sélectionner',
    'select_all'        => 'Tout sélectionner',
    'deselect_all'      => 'Tout désélectionner',

    // Statuts & messages
    'loading'           => 'Chargement...',
    'saving'            => 'Enregistrement...',
    'saved'             => 'Enregistré avec succès',
    'deleted'           => 'Supprimé avec succès',
    'error'             => 'Une erreur est survenue',
    'success'           => 'Opération réussie',
    'warning'           => 'Attention',
    'info'              => 'Information',
    'confirm_delete'    => 'Voulez-vous vraiment supprimer cet élément ?',
    'action_irreversible' => 'Cette action est irréversible.',

    // Tableau / liste
    'no_data'           => 'Aucune donnée disponible',
    'per_page'          => 'Par page',
    'total'             => 'Total',
    'showing'           => 'Affichage de :from à :to sur :total entrées',
    'previous'          => 'Précédent',
    'next'              => 'Suivant',
    'first'             => 'Premier',
    'last'              => 'Dernier',

    // Langue
    'language'          => 'Langue',
    'change_language'   => 'Changer de langue',

    // Thème
    'theme'             => 'Thème',
    'light_mode'        => 'Mode clair',
    'dark_mode'         => 'Mode sombre',
    'system_mode'       => 'Système',

];
