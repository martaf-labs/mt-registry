<?php

namespace Mt\MtFoundation\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Mt\MtFoundation\Enums\CivilitePersonnel;
use Mt\MtFoundation\Enums\SexePersonnel;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtFoundation\Traits\HasReference;
use Mt\MtFoundation\Traits\LogActivityAction;
use Mt\MtFoundation\Traits\TracksUser;
use Mt\SgniShared\Models\User;

abstract class BasePersonnel extends MtBaseModel
{

    protected $fillable = [
        'reference',
        'nom',
        'prenom',
        'sexe',
        'civilite',
        'naissance',
        'email',
        'telephone',
        'image',
        'adresse',
        'description',
    ];

    protected $casts = [
        'sexe' => SexePersonnel::class,
        'civilite' => CivilitePersonnel::class,
    ];

    //les constantes

    /*
    ** Methodes du model
    */
    public function userAccount(): MorphOne
    {
        return $this->morphOne(User::class, 'userable');
    }

    //les attributs
    public function dateNaissance() : string
    {
        $date=$this->naissance? Carbon::parse($this->naissance)->locale('fr')->translatedFormat('j F Y') : '';
        return $date;
    }

    public function getFullNameAttribute() : string
    {
        $fullName=$this->nom.' '.$this->prenom ?? '';
        return $fullName;
    }

    public function getImageUrlAttribute(): string
    {
        $imagePath = $this->image;

        if (!empty($imagePath)) {
            // Vérifie si l'image existe sur le disque CDN
            // if (Storage::disk(mt_get_storage_disk())->exists($imagePath)) {
                return Storage::disk(mt_get_storage_disk())->url($imagePath);
            // }
        }

        // Retourne une image par défaut si l'image n'existe pas
        return asset('images/placeholder-image.jpg');
    }

    //les mutateurs
    public function setNomAttribute($valeur)
    {
        $this->attributes['nom']=ucwords(strtolower($valeur));
    }

    public function setPrenomAttribute($valeur)
    {
        $this->attributes['prenom']=ucwords(strtolower($valeur));
    }
}
