<?php

namespace Mt\MtFoundation\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtFoundation\Enums\CivilitePersonnel;
use Mt\MtFoundation\Enums\SexePersonnel;
use Mt\MtFoundation\Enums\TypesContact;
use Mt\MtFoundation\Models\MtBaseModel;
use Mt\MtFoundation\Traits\HasReference;
use Mt\MtFoundation\Traits\LogActivityAction;
use Mt\MtFoundation\Traits\TracksUser;
use Mt\SgniShared\Models\User;

abstract class BaseContact extends MtBaseModel
{
    protected $fillable = [
        'contactable_type',
        'contactable_id', 
        'type',
        'valeur',
        'icone', 
        'couleur',
        'description',
        'principal',
        'actif'
    ];

    protected $casts = [ 
        'type' => TypesContact::class,
        'principal' => 'boolean',
        'actif' => 'boolean',
    ];

    // relations
    public function contactable(): MorphOne
    {
        return $this->morphTo();
    }   
    
    
    // Scopes 
    public function scopeActifs($query)
    {
        return $query->where('actif', true);
    }


    //les mutateurs
    public function setNomAttribute($valeur)
    {
        $this->attributes['nom']=Str::ucfirst($valeur);
    }

    public function setNomCourtAttribute($valeur)
    {
        $this->attributes['nom_court']=Str::ucfirst($valeur);
    }

}
