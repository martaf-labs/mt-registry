<?php

namespace Mt\MtFoundation\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtFoundation\Contracts\Searchable;
use Mt\MtFoundation\Enums\CivilitePersonnel;
use Mt\MtFoundation\Enums\SexePersonnel;
use Mt\MtFoundation\Enums\TypesContact;
use Mt\MtFoundation\Traits\AttributesFormatter;
use Mt\MtFoundation\Traits\HasAutoCasts;
use Mt\MtFoundation\Traits\HasMultilingualFormatter;
use Mt\MtFoundation\Traits\HasReference;
use Mt\MtFoundation\Traits\HasTranslatableCasts;
use Mt\MtFoundation\Traits\IsSearchable;
use Mt\MtFoundation\Traits\LogActivityAction;
use Mt\MtFoundation\Traits\TracksUser;
use Mt\SgniShared\Models\User; 
// HasAutoCasts,

abstract class MtBaseModel extends Model
{
    use HasFactory, SoftDeletes, HasMultilingualFormatter, HasTranslatableCasts, TracksUser, HasReference, LogActivityAction, AttributesFormatter, IsSearchable;

    
    // Scopes 
    public function scopeActif($query)
    {
        return $query->where('actif', true);
    } 
    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

}
