<?php

namespace Mt\MtFoundation\Traits;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

trait HandlesModelDates
{
    protected array $dateFields = [];

    /*
    |--------------------------------------------------------------------------
    | INITIALISATION AUTO
    |--------------------------------------------------------------------------
    */
    protected function bootHandlesModelDates(?Model $model)
    {
        $this->dateFields = $this->extractDateCasts($model);
    }

    protected function extractDateCasts(?Model $model): array
    {
        $casts = $model->getCasts();

        return collect($casts)
            ->filter(fn ($type) => str_contains($type, 'date'))
            ->map(function ($type) {
                if ($type === 'date') return 'date';
                return 'datetime'; // datetime, immutable_datetime...
            })
            ->toArray();
    }

    /*
    |--------------------------------------------------------------------------
    | FORMATTERS
    |--------------------------------------------------------------------------
    */
    protected function toInputFormat($value, $type)
    {
        if (!$value) return null;

        $date = $value instanceof Carbon ? $value : Carbon::parse($value);

        return match ($type) {
            'date'     => $date->format('Y-m-d'),
            'datetime' => $date->format('Y-m-d\TH:i'),
        };
    }

    protected function toDatabaseFormat($value)
    {
        if (!$value) return null;
        return Carbon::parse($value);
    }

    /*
    |--------------------------------------------------------------------------
    | HYDRATE MODEL → LIVEWIRE
    |--------------------------------------------------------------------------
    */
    protected function hydrateDatesFromModel(?Model $model)
    {
        foreach ($this->dateFields as $field => $type) {
            $this->$field = $this->toInputFormat($model->$field, $type);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DEHYDRATE LIVEWIRE → MODEL
    |--------------------------------------------------------------------------
    */
    protected function dehydrateDatesToModel(?Model $model)
    {
        foreach ($this->dateFields as $field => $type) {
            $model->$field = $this->toDatabaseFormat($this->$field);
        }
    }
}
