<?php

namespace Mt\MtFoundation\Enums;

enum SexePersonnel: string
{
    case MASCULIN           = 'M';
    case FEMININ            = 'F';
    case NON_PRECISE        = '-';

    /**
     * Libellé lisible
     * @return string
     */
    public function label() : string
    {
        return match ($this){
            self:: MASCULIN       => 'Masculin',
            self:: FEMININ        => 'Féminin',
            self:: NON_PRECISE    => 'Non précisé',
        };
    }

    /**
     * Liste clé => label
     * @return array
     */
    public static function options():array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
