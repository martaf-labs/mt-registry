<?php

namespace Mt\MtFoundation\Enums;

enum CivilitePersonnel: string
{
    case MONSIEUR       = 'M';
    case MADAME         = 'Mme';
    case MADEMOISELLE   = 'Mlle';
    case NON_PRECISEE    = '-';

    /**
     * Libellé lisible
     * @return string
     */
    public function label() : string
    {
        return match ($this){
            self:: MONSIEUR       => 'Monsieur',
            self:: MADAME         => 'Madame',
            self:: MADEMOISELLE   => 'Mademoiselle',
            self:: NON_PRECISEE    => 'Non précisée',
        };
    }

    /**
     * Liste clé => label
     * @return array
     */
    public static function options():array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
