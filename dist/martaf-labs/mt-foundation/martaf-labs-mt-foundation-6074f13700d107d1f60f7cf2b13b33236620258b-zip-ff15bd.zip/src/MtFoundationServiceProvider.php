<?php

namespace Mt\MtFoundation;

use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Schema\Blueprint;
use Mt\MtFoundation\Helpers\MtLocale;
use Mt\MtFoundation\Services\ReferenceGeneratorService;

/**
 * MtFoundationServiceProvider
 *
 * Service provider principal de mt-foundation.
 * Enregistre uniquement les services du socle commun :
 *   - Configuration
 *   - Traductions
 *   - Migrations
 *   - Singletons de base
 *
 * Tout ce qui concerne les images, vues, auth
 * est géré par leurs packages respectifs.
 */
class MtFoundationServiceProvider extends ServiceProvider
{
    /**
     * Chemin racine du package.
     */
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        $this->basePath = dirname(__DIR__);
    }

    /**
     * Enregistre les bindings dans le conteneur IoC.
     */
    public function register(): void
    {
        // Fusion de la configuration du package
        $this->mergeConfigFrom(
            $this->basePath . '/config/mt-foundation.php',
            'mt-foundation'
        );

        // Singleton pour la gestion des locales mt-*
        $this->app->singleton(MtLocale::class);

        // Singleton pour la génération de références uniques
        $this->app->singleton(
            ReferenceGeneratorService::class,
            fn() => new ReferenceGeneratorService()
        );
    }

    /**
     * Démarre les services du package.
     */
    public function boot(): void
    {
        // Chargement des traductions
        $this->loadTranslationsFrom(
            $this->basePath . '/lang',
            'mt-foundation'
        );

        // Chargement des migrations
        $this->registerMigrations();

        // Enregistrement des macros Blueprint
        $this->registerBlueprintMacros();

        // Publication des ressources (console uniquement)
        if ($this->app->runningInConsole()) {
            $this->registerPublishing();
        }
    }

    /**
     * Enregistre les migrations du package.
     * Permet à Laravel de les découvrir automatiquement.
     */
    protected function registerMigrations(): void
    {
        $migrationsPath = $this->basePath . '/database/migrations';

        if (is_dir($migrationsPath)) {
            $this->loadMigrationsFrom($migrationsPath);
        }
    }

    /**
     * Déclare les ressources publiables via vendor:publish.
     *
     * Tags disponibles :
     *   - mt-foundation-config  → config/mt-foundation.php
     *   - mt-foundation-lang    → lang/vendor/mt/mt-foundation/
     *   - mt-foundation-migrations → database/migrations/
     */
    protected function registerPublishing(): void
    {
        // Configuration
        $this->publishes([
            $this->basePath . '/config/mt-foundation.php' => config_path('mt-foundation.php'),
        ], 'mt-foundation-config');

        // Traductions
        $this->publishes([
            $this->basePath . '/lang' => $this->app->langPath('vendor/mt/mt-foundation'),
        ], 'mt-foundation-lang');

        // Migrations (si le développeur veut les modifier)
        $this->publishes([
            $this->basePath . '/database/migrations' => database_path('migrations'),
        ], 'mt-foundation-migrations');
    }

    /**
     * Enregistre les macros Blueprint personnalisées.
     *
     * tracksUser() → ajoute created_by, updated_by, deleted_by
     * sur n'importe quelle table via $table->tracksUser()
     */
    protected function registerBlueprintMacros(): void
    {
        Blueprint::macro('tracksUser', function () {
            /** @var Blueprint $this */
            $this->foreignId('created_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $this->foreignId('updated_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $this->foreignId('deleted_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();
        });
    }
}