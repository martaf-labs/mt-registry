<?php

namespace Mt\MtFoundation\Enums;

enum CivilitePersonnel: string
{
    case MONSIEUR       = 'M';
    case MADAME         = 'Mme';
    case MADEMOISELLE   = 'Mlle';
    case NON_PRECISEE    = '-';

    /**
     * Libellé lisible
     * @return string
     */
    public function label() : string
    {
        return match ($this){
            self:: MONSIEUR       => __('mt-foundation::mt-foundation.civilite_m'),
            self:: MADAME         => __('mt-foundation::mt-foundation.civilite_mme'),
            self:: MADEMOISELLE   => __('mt-foundation::mt-foundation.civilite_mlle'),
            self:: NON_PRECISEE    => __('mt-foundation::mt-foundation.civilite_x'),
        };
    }

    /**
     * Liste clé => label
     * @return array
     */
    public static function options():array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
