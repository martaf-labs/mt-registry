<?php

namespace Mt\MtFoundation\Enums;

enum SexePersonnel: string
{
    case MASCULIN           = 'M';
    case FEMININ            = 'F';
    case NON_PRECISE        = '-';

    /**
     * Libellé lisible
     * @return string
     */
    public function label() : string
    {
        return match ($this){
            self:: MASCULIN       => __('mt-foundation::mt-foundation.sexe_m'),
            self:: FEMININ        => __('mt-foundation::mt-foundation.sexe_f'),
            self:: NON_PRECISE    => __('mt-foundation::mt-foundation.sexe_x'),
        };
    }

    /**
     * Liste clé => label
     * @return array
     */
    public static function options():array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
