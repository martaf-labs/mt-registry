<?php

namespace Mt\MtFoundation\Traits;

use Illuminate\Support\Facades\App;


trait HasTranslatableCasts
{
    /**
     * Ce trait initialise le trait et fusionne les casts traduisible
     * Laravel appele automatiquement les méthode commençant par "initialize"
     */
    public function initializeHasTranslatableCasts()
    {
        if (isset($this->translatables) && is_array($this->translatables)) {
            $translatableCasts = array_fill_keys($this->translatables, 'array');

            // on fusionne avec les casts restant pour ne rien écraser
            $this->casts = array_merge($this->casts, $translatableCasts);
        }
    }

    /**
     * Intercepte l'accès aux propriété pour retourner la traduction actuelle.
     *
     * @param [type] $key
     * @return void
     */
    public function __get($key)
    {
        if (isset($this->translatables) && in_array($key, $this->translatables)) {
            $value = $this->getAttribute($key);

            return is_array($value) ? $this->resolveTranslation($value) : $value;
        }

        return parent::__get($key);
    }

    /**
     * Renvoie la traduction pour la locale courante, avec REPLI si elle est vide :
     * locale courante → locale de repli (app.fallback_locale) → 1re valeur non vide.
     * Évite l'affichage blanc quand une donnée n'a pas été saisie dans la langue active.
     */
    protected function resolveTranslation(array $value)
    {
        $current = $value[App::getLocale()] ?? null;
        if ($current !== null && $current !== '') {
            return $current;
        }

        $fallback = $value[config('app.fallback_locale')] ?? null;
        if ($fallback !== null && $fallback !== '') {
            return $fallback;
        }

        foreach ($value as $v) {
            if ($v !== null && $v !== '') {
                return $v;
            }
        }

        return null;
    }

    /**
     * Liste publique des attributs traduisibles. Le tableau $translatables étant
     * protected (et masqué par __get), cet accesseur permet aux formulaires de
     * détecter les champs JSON traduisibles, en création comme en édition.
     */
    public function getTranslatables(): array
    {
        return (isset($this->translatables) && is_array($this->translatables))
            ? $this->translatables
            : [];
    }

}
