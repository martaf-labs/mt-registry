<?php

namespace Mt\MtFoundation\Traits;

use Illuminate\Database\Eloquent\Builder;

/**
 * Trait IsSearchable
 *
 * Fournit un scope search() générique.
 * Définir $searchable sur le modèle pour cibler des colonnes précises.
 * Sans $searchable, le scope ne fait rien (pas de recherche aveugle sur toutes colonnes).
 */
trait IsSearchable
{
    /**
     * Scope de recherche textuelle.
     *
     * Exemple d'usage :
     *   Model::search('dupont')->get()
     *
     * Exemple de définition sur le modèle :
     *   protected array $searchable = ['nom', 'prenom', 'email'];
     */
    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        if (empty($term)) {
            return $query;
        }

        $columns = property_exists($this, 'searchable') ? $this->searchable : [];

        if (empty($columns)) {
            return $query;
        }

        return $query->where(function (Builder $q) use ($columns, $term) {
            foreach ($columns as $column) {
                $q->orWhere($column, 'like', "%{$term}%");
            }
        });
    }
}
