<?php

namespace Mt\MtFoundation\Traits;

use Illuminate\Support\Facades\App;

/**
 * Trait HasMultilingualFormatter
 *
 * Fournit des helpers de formatage pour les attributs multilingues stockés en JSON.
 * Complémentaire à HasTranslatableCasts qui gère le cast automatique.
 */
trait HasMultilingualFormatter
{
    /**
     * Retourne la valeur traduite d'un champ dans la locale donnée (ou locale courante).
     * Retombe sur la locale de fallback si la traduction est absente.
     */
    public function translate(string $field, ?string $locale = null): ?string
    {
        $locale   = $locale ?? App::getLocale();
        $fallback = config('app.fallback_locale', 'fr');
        $value    = $this->getRawOriginal($field) ?? $this->getAttribute($field);

        if (is_string($value)) {
            $decoded = json_decode($value, true);
            $value   = is_array($decoded) ? $decoded : null;
        }

        if (! is_array($value)) {
            return null;
        }

        return $value[$locale] ?? $value[$fallback] ?? array_values($value)[0] ?? null;
    }

    /**
     * Retourne toutes les traductions d'un champ sous forme de tableau [locale => valeur].
     */
    public function translations(string $field): array
    {
        $value = $this->getRawOriginal($field) ?? $this->getAttribute($field);

        if (is_string($value)) {
            $decoded = json_decode($value, true);
            return is_array($decoded) ? $decoded : [];
        }

        return is_array($value) ? $value : [];
    }

    /**
     * Construit un tableau de traductions à partir d'une valeur simple ou d'un tableau.
     * Utilisé lors de la sauvegarde via formulaire.
     *
     * @param  string|array  $value
     */
    public static function buildTranslatable(string|array $value, ?string $locale = null): array
    {
        if (is_array($value)) {
            return $value;
        }

        $locale = $locale ?? App::getLocale();

        return [$locale => $value];
    }
}
