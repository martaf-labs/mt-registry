<?php

namespace Mt\MtFoundation\Traits;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

/**
 * Trait TracksUser
 *
 * Remplit automatiquement created_by / updated_by / deleted_by si les colonnes existent.
 * Applique aussi une mise en forme de base (première lettre majuscule) sur les champs texte communs.
 */
trait TracksUser
{
    /** Cache statique : évite de requêter le schéma DB à chaque évènement Eloquent. */
    private static array $columnCache = [];

    public static function bootTracksUser(): void
    {
        static::creating(function ($model) {
            if (Auth::check() && $model->hasColumn('created_by')) {
                $model->created_by = Auth::id();
            }
            static::capitalizeFields($model);
        });

        static::updating(function ($model) {
            if (Auth::check() && $model->hasColumn('updated_by')) {
                $model->updated_by = Auth::id();
            }
            static::capitalizeFields($model);
        });

        static::deleting(function ($model) {
            if (static::modelUsesSoftDeletes($model) && Auth::check() && $model->hasColumn('deleted_by')) {
                $model->deleted_by = Auth::id();
                $model->saveQuietly();
            }
        });
    }

    protected function hasColumn(string $column): bool
    {
        $table = $this->getTable();

        if (! isset(self::$columnCache[$table])) {
            self::$columnCache[$table] = $this->getConnection()
                ->getSchemaBuilder()
                ->getColumnListing($table);
        }

        return in_array($column, self::$columnCache[$table]);
    }

    protected static function modelUsesSoftDeletes(object $model): bool
    {
        return in_array(\Illuminate\Database\Eloquent\SoftDeletes::class, class_uses_recursive($model));
    }

    /**
     * Première lettre en majuscule sur les champs texte courants.
     * Surcharger $capitalizableFields sur le modèle pour personnaliser.
     */
    private static function capitalizeFields(object $model): void
    {
        $fields = property_exists($model, 'capitalizableFields')
            ? $model->capitalizableFields
            : ['titre', 'nom', 'nom_court', 'name', 'libelle', 'description'];

        $translatables = method_exists($model, 'getTranslatables') ? $model->getTranslatables() : [];

        foreach ($fields as $field) {
            // Ne jamais toucher un champ traduisible (JSON) : $model->{$field} renvoie
            // la locale courante via __get, et le réécrire aplatirait le tableau multilingue.
            if (in_array($field, $translatables, true)) {
                continue;
            }

            $value = $model->getAttribute($field);
            if (is_array($value)) {
                continue;
            }

            if (! empty($value)) {
                $model->{$field} = Str::ucfirst($value);
            }
        }
    }
}
