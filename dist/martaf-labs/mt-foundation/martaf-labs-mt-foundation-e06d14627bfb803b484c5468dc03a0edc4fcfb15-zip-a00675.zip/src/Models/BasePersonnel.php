<?php

namespace Mt\MtFoundation\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Support\Facades\Storage;
use Mt\MtFoundation\Enums\CivilitePersonnel;
use Mt\MtFoundation\Enums\SexePersonnel;

/**
 * BasePersonnel
 *
 * Modèle de base pour toute entité "personne" dans l'écosystème martaf-labs.
 * Étendre dans chaque projet (Etudiant, Enseignant, Employe, Patient…).
 *
 * La relation userAccount() utilise le modèle User résolu depuis la config Laravel,
 * ce qui rend BasePersonnel indépendant de tout package d'authentification.
 */
abstract class BasePersonnel extends MtBaseModel
{
    protected $fillable = [
        'reference',
        'nom',
        'prenom',
        'sexe',
        'civilite',
        'naissance',
        'email',
        'telephone',
        'image',
        'adresse',
        'description',
    ];

    protected $casts = [
        'sexe'     => SexePersonnel::class,
        'civilite' => CivilitePersonnel::class,
    ];

    /**
     * Compte utilisateur lié (relation polymorphique inverse).
     * Le modèle User est résolu depuis config('auth.providers.users.model')
     * → aucun couplage à mt-auth ou à une classe concrète.
     */
    public function userAccount(): MorphOne
    {
        return $this->morphOne(config('auth.providers.users.model'), 'userable');
    }

    public function dateNaissance(): string
    {
        return $this->naissance
            ? Carbon::parse($this->naissance)->locale('fr')->translatedFormat('j F Y')
            : '';
    }

    public function getFullNameAttribute(): string
    {
        return trim(($this->nom ?? '') . ' ' . ($this->prenom ?? ''));
    }

    public function fullName(): string
    {
        return $this->getFullNameAttribute();
    }

    public function getImageUrlAttribute(): string
    {
        if (! empty($this->image)) {
            return Storage::disk(mt_get_storage_disk())->url($this->image);
        }

        return asset('images/placeholder-image.jpg');
    }

    public function setNomAttribute($valeur): void
    {
        $this->attributes['nom'] = ucwords(strtolower($valeur));
    }

    public function setPrenomAttribute($valeur): void
    {
        $this->attributes['prenom'] = ucwords(strtolower($valeur));
    }
}
