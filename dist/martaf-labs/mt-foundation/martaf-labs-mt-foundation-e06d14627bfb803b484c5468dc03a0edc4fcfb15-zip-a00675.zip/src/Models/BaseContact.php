<?php

namespace Mt\MtFoundation\Models;

use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Support\Str;
use Mt\MtFoundation\Enums\TypesContact;
use Mt\MtFoundation\Models\MtBaseModel;

abstract class BaseContact extends MtBaseModel
{
    protected $fillable = [
        'contactable_type',
        'contactable_id', 
        'type',
        'valeur',
        'icone', 
        'couleur',
        'description',
        'principal',
        'actif'
    ];

    protected $casts = [ 
        'type' => TypesContact::class,
        'principal' => 'boolean',
        'actif' => 'boolean',
    ];

    // relations
    public function contactable(): MorphTo
    {
        return $this->morphTo();
    }   
    
    
    // Scopes 
    public function scopeActifs($query)
    {
        return $query->where('actif', true);
    }


    //les mutateurs
    public function setNomAttribute($valeur)
    {
        $this->attributes['nom']=Str::ucfirst($valeur);
    }

    public function setNomCourtAttribute($valeur)
    {
        $this->attributes['nom_court']=Str::ucfirst($valeur);
    }

}
