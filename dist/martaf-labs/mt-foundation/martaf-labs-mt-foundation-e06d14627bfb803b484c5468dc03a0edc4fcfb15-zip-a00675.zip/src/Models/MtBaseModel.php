<?php

namespace Mt\MtFoundation\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Mt\MtFoundation\Traits\AttributesFormatter;
use Mt\MtFoundation\Traits\HasMultilingualFormatter;
use Mt\MtFoundation\Traits\HasReference;
use Mt\MtFoundation\Traits\HasTranslatableCasts;
use Mt\MtFoundation\Traits\IsSearchable;
use Mt\MtFoundation\Traits\LogActivityAction;
use Mt\MtFoundation\Traits\TracksUser;

/**
 * MtBaseModel
 *
 * Modèle abstrait de base pour tous les modèles métier de l'écosystème martaf-labs.
 * Fournit : soft deletes, tracking utilisateur, référence automatique,
 * log d'activité, formatage multilingue, recherche générique.
 */
abstract class MtBaseModel extends Model
{
    use HasFactory,
        SoftDeletes,
        TracksUser,
        HasReference,
        LogActivityAction,
        AttributesFormatter,
        HasMultilingualFormatter,
        HasTranslatableCasts,
        IsSearchable;

    public function scopeActif($query)
    {
        return $query->where('actif', true);
    }

    public function scopeActive($query)
    {
        return $query->where('active', true);
    }
}
