<?php

namespace Mt\MtFoundation;

use Illuminate\Support\ServiceProvider;

/**
 * Base service provider for all mt-* packages.
 *
 * Provides shared boilerplate:
 *   - $basePath resolution (dirname(__DIR__) from the subclass location)
 *   - loadPackageMigrations()
 *   - loadPackageTranslations(string $namespace)
 *   - loadPackageViews(string $namespace)
 *
 * Subclasses still override register() and boot() freely —
 * they just call the helpers instead of repeating the path checks.
 */
abstract class MtServiceProvider extends ServiceProvider
{
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        // Each subclass lives one level below its package root (src/),
        // so dirname(__DIR__) correctly resolves to the package root.
        $this->basePath = dirname((new \ReflectionClass(static::class))->getFileName(), 2);
    }

    protected function loadPackageMigrations(): void
    {
        $path = $this->basePath . '/database/migrations';
        if (is_dir($path)) {
            $this->loadMigrationsFrom($path);
        }
    }

    protected function loadPackageTranslations(string $namespace): void
    {
        $path = $this->basePath . '/lang';
        if (is_dir($path)) {
            $this->loadTranslationsFrom($path, $namespace);
        }
    }

    protected function loadPackageViews(string $namespace): void
    {
        $path = $this->basePath . '/resources/views';
        if (is_dir($path)) {
            $this->loadViewsFrom($path, $namespace);
        }
    }
}
