<?php

namespace Mt\MtFoundation;

use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Database\Schema\Blueprint;
use Mt\MtFoundation\Helpers\MtLocale;
use Mt\MtFoundation\Services\ReferenceGeneratorService;

/**
 * MtFoundationServiceProvider
 *
 * Service provider principal de mt-foundation.
 * Enregistre uniquement les services du socle commun :
 *   - Configuration
 *   - Traductions
 *   - Migrations
 *   - Singletons de base
 *
 * Tout ce qui concerne les images, vues, auth
 * est géré par leurs packages respectifs.
 */
class MtFoundationServiceProvider extends MtServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom($this->basePath . '/config/mt-foundation.php', 'mt-foundation');

        $this->app->singleton(MtLocale::class);

        $this->app->singleton(
            ReferenceGeneratorService::class,
            fn() => new ReferenceGeneratorService()
        );
    }

    public function boot(): void
    {
        $this->loadPackageTranslations('mt-foundation');
        $this->loadPackageMigrations();
        $this->registerBlueprintMacros();
        $this->registerMorphMap();

        if ($this->app->runningInConsole()) {
            $this->registerPublishing();
        }
    }

    /**
     * Register polymorphic type aliases for cross-package models.
     *
     * Stores short aliases in the database (e.g. 'developpeur') instead of
     * full class names (e.g. 'App\Models\Developpeur'). The actual class is
     * resolved from config so each project can override the binding via
     * MT_AUTH_DEV_MODEL in .env without touching stored data.
     */
    protected function registerMorphMap(): void
    {
        // merge=true : ne JAMAIS écraser la morph map déjà enregistrée par d'autres
        // packages (ex. mt-blog enregistre ses 19 modèles). false effaçait tout → Article absent.
        Relation::morphMap([
            'user'        => config('auth.providers.users.model', \App\Models\User::class),
            'developpeur' => config('mt-auth.developpeur_model', \App\Models\Developpeur::class),
        ], true);
    }

    /**
     * Déclare les ressources publiables via vendor:publish.
     *
     * Tags disponibles :
     *   - mt-foundation-config  → config/mt-foundation.php
     *   - mt-foundation-lang    → lang/vendor/mt/mt-foundation/
     *   - mt-foundation-migrations → database/migrations/
     */
    protected function registerPublishing(): void
    {
        // Configuration
        $this->publishes([
            $this->basePath . '/config/mt-foundation.php' => config_path('mt-foundation.php'),
        ], 'mt-foundation-config');

        // Traductions
        $this->publishes([
            $this->basePath . '/lang' => $this->app->langPath('vendor/mt/mt-foundation'),
        ], 'mt-foundation-lang');

        // Migrations (si le développeur veut les modifier)
        $this->publishes([
            $this->basePath . '/database/migrations' => database_path('migrations'),
        ], 'mt-foundation-migrations');
    }

    /**
     * Enregistre les macros Blueprint personnalisées.
     *
     * tracksUser() → ajoute created_by, updated_by, deleted_by
     * sur n'importe quelle table via $table->tracksUser()
     */
    protected function registerBlueprintMacros(): void
    {
        Blueprint::macro('tracksUser', function () {
            /** @var Blueprint $this */
            $this->foreignId('created_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $this->foreignId('updated_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();

            $this->foreignId('deleted_by')
                ->nullable()
                ->constrained('users')
                ->nullOnDelete();
        });
    }
}