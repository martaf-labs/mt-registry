<?php

namespace Mt\MtFoundation\Helpers;

use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class MtLocale
{
    /**
     * Returns the active locale (session > config > app.locale)
     */
    public static function get(): string
    {
        return Session::get('mt_locale', config('app.locale', App::getLocale()));
    }

    /**
     * Sets the active locale in session and for the Laravel app
     */
    public static function set(string $locale): void
    {
        $available = array_keys(static::available());

        if (! in_array($locale, $available)) {
            return;
        }

        Session::put('mt_locale', $locale);
        App::setLocale($locale);
    }

    /**
     * Returns available locales from config
     */
    public static function available(): array
    {
        $availableLocales = config('app.available_locales', ['fr']);

        $locales = [
            'fr' => ['label' => 'Français',  'flag' => 'FR', 'icon' => 'language-fr'],
            'en' => ['label' => 'English',    'flag' => 'EN', 'icon' => 'language-en'],
            'ar' => ['label' => 'العربية',    'flag' => 'AR', 'icon' => 'language-ar'],
        ];

        return array_filter(
            $locales,
            fn($code) => in_array($code, $availableLocales),
            ARRAY_FILTER_USE_KEY
        );
    }

    /**
     * Translates a key — namespace is passed by the caller to stay package-agnostic.
     * Example: MtLocale::trans('mt-ui::mt-ui.key')
     */
    public static function trans(string $key, array $replace = []): string
    {
        return __($key, $replace);
    }

    /**
     * Checks if the given locale is the active one
     */
    public static function is(string $locale): bool
    {
        return static::get() === $locale;
    }

    /** Locales à écriture droite-à-gauche. */
    public const RTL_LOCALES = ['ar', 'he', 'fa', 'ur'];

    /**
     * Sens d'écriture de la locale active (ou de celle fournie) : 'rtl' ou 'ltr'.
     */
    public static function direction(?string $locale = null): string
    {
        $locale = $locale ?? static::get();

        return in_array($locale, static::RTL_LOCALES, true) ? 'rtl' : 'ltr';
    }

    /** La locale active (ou fournie) est-elle droite-à-gauche ? */
    public static function isRtl(?string $locale = null): bool
    {
        return static::direction($locale) === 'rtl';
    }

    /**
     * Returns the active locale info array
     */
    public static function current(): array
    {
        $locale    = static::get();
        $available = static::available();

        return $available[$locale] ?? [
            'label' => $locale,
            'flag'  => Str::upper($locale),
            'icon'  => "language-{$locale}",
        ];
    }
}
