<?php

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * convertir une chaine hexa en rgb
 */
if (!function_exists('hexaToRgb')) {
    function hexaToRgb(?string $value) {
        if (is_null($value)) {
            return '';
        }
        $value = ltrim($value, '#');
        if (ctype_xdigit($value) && strlen($value) === 3 || strlen($value) === 6) {
            if (strlen($value) === 3) {
                $r = hexdec(str_repeat(substr($value, 0, 1), 2));
                $g = hexdec(str_repeat(substr($value, 1, 1), 2));
                $b = hexdec(str_repeat(substr($value, 2, 1), 2));
            } else {
                $r = hexdec(substr($value, 0, 2));
                $g = hexdec(substr($value, 2, 2));
                $b = hexdec(substr($value, 4, 2));
            }
            return "$r, $g, $b";
        }
        return $value;
    }
}

/**
 * Disque de stockage configuré dans l'application
 */
if (!function_exists('mt_get_storage_disk')) {
    function mt_get_storage_disk() {
        return config('app.storage_disk') ?? '';
    }
}

/**
 * URL CDN d'un fichier stocké
 */
if (!function_exists('cdn_path')) {
    function cdn_path($path) {
        return Storage::disk(mt_get_storage_disk())->url($path);
    }
}

/**
 * URL des assets partagés entre applications
 */
if (!function_exists('mt_shared')) {
    function mt_shared($path = '') {
        return rtrim(config('app.mt_shared_url'), '/') . '/' . ltrim($path, '/');
    }
}

/**
 * Résoudre une constante de classe sous forme "Classe::CONSTANTE"
 */
if (!function_exists('resolve_string')) {
    function resolve_string($code) {
        if (!str_contains($code, '::')) return $code;
        [$class, $const] = explode('::', $code);
        if (class_exists($class) && defined("{$class}::{$const}")) return constant("{$class}::{$const}");
        return $code;
    }
}

/**
 * Évaluer une expression PHP simple (ex: "Model::count()")
 */
if (!function_exists('resolve_count')) {
    function resolve_count($code) {
        return eval("return $code;");
    }
}

/**
 * Formater un nombre avec abréviation (K, M, Md)
 */
if (!function_exists('add_zero')) {
    function add_zero($nbre): string {
        $nbre = (int)$nbre;
        if (0 < $nbre && $nbre < 10) return '0' . $nbre;
        if ($nbre < 1_000) return (string)$nbre;
        if ($nbre < 1_000_000) return round($nbre / 1_000, 1) . 'K';
        if ($nbre < 1_000_000_000) return round($nbre / 1_000_000, 1) . 'M';
        return round($nbre / 1_000_000_000, 1) . 'Md';
    }
}

/**
 * Vérifier qu'une valeur est dans un intervalle [min, max]
 */
if (!function_exists('inRange')) {
    function inRange(int $val, int $min, int $max): bool {
        return $val >= $min && $val <= $max;
    }
}

/**
 * Calculer le temps écoulé entre deux dates, avec format humain
 */
if (!function_exists('tempsEcoule')) {
    function tempsEcoule($debut, $fin = null, $abrege = false, $prefixe = false, $type = null) {
        try {
            $now   = is_null($fin) ? Carbon::now() : Carbon::parse($fin);
            $debut = Carbon::parse($debut);
        } catch (\Exception $e) {
            return null;
        }

        $future = $debut->greaterThan($now);
        $ref1   = $future ? $now : $debut;
        $ref2   = $future ? $debut : $now;

        if ($type) {
            $type  = strtolower($type);
            $val   = 0;
            $label = '';
            switch ($type) {
                case 'seconde': case 's':   $val = $ref1->diffInSeconds($ref2);              $label = $abrege ? 's'   : 'seconde'  . ($val > 1 ? 's' : ''); break;
                case 'minute':  case 'min': $val = $ref1->diffInMinutes($ref2);              $label = $abrege ? 'min' : 'minute'   . ($val > 1 ? 's' : ''); break;
                case 'heure':   case 'h':   $val = $ref1->diffInHours($ref2);                $label = $abrege ? 'h'   : 'heure'    . ($val > 1 ? 's' : ''); break;
                case 'jour':    case 'j':   $val = $ref1->diffInDays($ref2);                 $label = $abrege ? 'j'   : 'jour'     . ($val > 1 ? 's' : ''); break;
                case 'semaine': case 'sem': $val = floor($ref1->diffInDays($ref2) / 7);      $label = $abrege ? 'sem' : 'semaine'  . ($val > 1 ? 's' : ''); break;
                case 'mois':                $val = $ref1->diffInMonths($ref2);               $label = 'mois'; break;
                case 'an':      case 'annee': $val = $ref1->diffInYears($ref2);              $label = $abrege ? 'an'  : 'an'       . ($val > 1 ? 's' : ''); break;
            }
            return ($prefixe ? ($future ? 'dans ' : 'il y a ') : '') . add_zero($val) . ' ' . $label;
        }

        $diff       = $ref1->diff($ref2);
        $joursTotal = $ref1->diffInDays($ref2);
        $semaines   = floor($joursTotal / 7);
        $resteJours = $joursTotal % 7;
        $parts      = [];

        if ($diff->y > 0)       $parts[] = add_zero($diff->y)    . ' ' . ($abrege ? 'an'  : 'an'      . ($diff->y      > 1 ? 's' : ''));
        if ($diff->m > 0)       $parts[] = add_zero($diff->m)    . ' mois';
        if ($semaines > 0)      $parts[] = add_zero($semaines)   . ' ' . ($abrege ? 'sem' : 'semaine'  . ($semaines     > 1 ? 's' : ''));
        if ($resteJours > 0)    $parts[] = add_zero($resteJours) . ' ' . ($abrege ? 'j'   : 'jour'     . ($resteJours   > 1 ? 's' : ''));
        if ($diff->h > 0 && empty($parts)) $parts[] = add_zero($diff->h) . ' ' . ($abrege ? 'h'   : 'heure'  . ($diff->h > 1 ? 's' : ''));
        if ($diff->i > 0 && empty($parts)) $parts[] = add_zero($diff->i) . ' ' . ($abrege ? 'min' : 'minute' . ($diff->i > 1 ? 's' : ''));
        if ($diff->s > 0 && empty($parts)) $parts[] = add_zero($diff->s) . ' ' . ($abrege ? 's'   : 'seconde'. ($diff->s > 1 ? 's' : ''));

        $texte = implode(' et ', array_slice($parts, 0, 2));
        return $prefixe ? ($future ? 'dans ' . $texte : 'il y a ' . $texte) : $texte;
    }
}

/**
 * Extraire les initiales d'un nom
 */
if (!function_exists('getInitials')) {
    function getInitials(?string $name, int $limit = 2, string $fallback = '..'): string {
        $name = trim($name ?? '');
        $name = Str::slug($name, ' ');

        if (empty($name)) return $fallback;

        $words = preg_split('/\s+/u', $name, -1, PREG_SPLIT_NO_EMPTY);

        if (count($words) === 1) {
            return mb_strtoupper(mb_substr($words[0], 0, $limit));
        }

        return collect($words)
            ->filter()
            ->map(fn ($word) => mb_strtoupper(mb_substr($word, 0, 1)))
            ->take($limit)
            ->implode('') ?: $fallback;
    }
}

/**
 * Convertir une chaîne en nombre (int ou float)
 */
if (!function_exists('toNumber')) {
    function toNumber(string $value): int|float|null {
        $value = trim($value ?? '');

        if (strpos($value, ',') !== false && strpos($value, '.') === false) {
            $value = str_replace(',', '.', $value);
        }

        $value = str_replace([' ', ','], ['', ''], $value);

        if (!is_numeric($value)) {
            return null;
        }

        if (ctype_digit($value)) {
            return (int)$value;
        }

        return (floor($value) == $value) ? (int)$value : (float)$value;
    }
}

/**
 * Vérifier si un fichier existe (local, disk Laravel, ou URL distante)
 */
if (!function_exists('mt_file_exists')) {
    function mt_file_exists(?string $path, ?string $disk = null, int $ttl = 300): bool {
        $disk = $disk ?? mt_get_storage_disk();

        if (!is_string($path)) return false;

        $path = trim($path);

        if ($path === '' || $path === '/' || $path === '.' || $path === '..') return false;

        $cacheKey = 'file_exists:' . md5($disk . '|' . $path);

        return Cache::remember($cacheKey, $ttl, function () use ($path, $disk) {
            if (filter_var($path, FILTER_VALIDATE_URL)) {
                // URL LOCALE /storage/… : vérifier directement sur le disque public.
                // (Un HEAD HTTP vers soi-même est lent, et un nom de fichier hérité
                // avec espaces/parenthèses non encodés faisait échouer la requête →
                // faux « fichier indisponible » mis en cache.)
                $storagePrefix = rtrim(config('app.url'), '/') . '/storage/';
                if (str_starts_with($path, $storagePrefix)) {
                    try {
                        $relative = rawurldecode(substr($path, strlen($storagePrefix)));
                        return Storage::disk('public')->exists($relative);
                    } catch (\Throwable) {
                        return false;
                    }
                }

                try {
                    $response = Http::timeout(5)->head($path);
                    if ($response->successful()) return true;
                    if (in_array($response->status(), [403, 405])) {
                        return Http::timeout(5)->get($path)->successful();
                    }
                    return false;
                } catch (\Throwable) {
                    return false;
                }
            }

            if ($disk) {
                try {
                    return Storage::disk($disk)->exists($path) && !Str::endsWith($path, '/');
                } catch (\Throwable) {
                    return false;
                }
            }

            return is_file($path);
        });
    }
}
