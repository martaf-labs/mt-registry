<?php

return [

    // Person enums (SexePersonnel, CivilitePersonnel)
    'sexe_m'        => 'Male',
    'sexe_f'        => 'Female',
    'sexe_x'        => 'Not specified',
    'civilite_m'    => 'Mr',
    'civilite_mme'  => 'Mrs',
    'civilite_mlle' => 'Miss',
    'civilite_x'    => 'Not specified',

    // Navigation & layout
    'menu'              => 'Menu',
    'close'             => 'Close',
    'back'              => 'Back',
    'home'              => 'Home',
    'dashboard'         => 'Dashboard',
    'profile'           => 'Profile',
    'settings'          => 'Settings',
    'logout'            => 'Log out',
    'login'             => 'Log in',

    // Search
    'search'            => 'Search',
    'search_placeholder'=> 'Search the application',
    'search_shortcut'   => 'Ctrl+K',
    'no_results'        => 'No results found',
    'search_history'    => 'Recent searches',
    'load_more'         => 'Load more',
    'results_count'     => ':count result(s)',

    // Notifications
    'notifications'     => 'Notifications',
    'no_notifications'  => 'No notifications',
    'mark_all_read'     => 'Mark all as read',

    // Forms
    'save'              => 'Save',
    'cancel'            => 'Cancel',
    'delete'            => 'Delete',
    'edit'              => 'Edit',
    'create'            => 'Create',
    'update'            => 'Update',
    'confirm'           => 'Confirm',
    'submit'            => 'Submit',
    'reset'             => 'Reset',
    'upload'            => 'Upload',
    'download'          => 'Download',
    'select'            => 'Select',
    'select_all'        => 'Select all',
    'deselect_all'      => 'Deselect all',

    // Status & messages
    'loading'           => 'Loading...',
    'saving'            => 'Saving...',
    'saved'             => 'Saved successfully',
    'deleted'           => 'Deleted successfully',
    'error'             => 'An error occurred',
    'success'           => 'Operation successful',
    'warning'           => 'Warning',
    'info'              => 'Information',
    'confirm_delete'    => 'Are you sure you want to delete this item?',
    'action_irreversible' => 'This action cannot be undone.',

    // Table / list
    'no_data'           => 'No data available',
    'per_page'          => 'Per page',
    'total'             => 'Total',
    'showing'           => 'Showing :from to :to of :total entries',
    'previous'          => 'Previous',
    'next'              => 'Next',
    'first'             => 'First',
    'last'              => 'Last',

    // Language
    'language'          => 'Language',
    'change_language'   => 'Change language',

    // Theme
    'theme'             => 'Theme',
    'light_mode'        => 'Light mode',
    'dark_mode'         => 'Dark mode',
    'system_mode'       => 'System',

];
