<?php

return [

    // تعدادات « الشخص » (SexePersonnel, CivilitePersonnel)
    'sexe_m'        => 'ذكر',
    'sexe_f'        => 'أنثى',
    'sexe_x'        => 'غير محدد',
    'civilite_m'    => 'السيد',
    'civilite_mme'  => 'السيدة',
    'civilite_mlle' => 'الآنسة',
    'civilite_x'    => 'غير محددة',

    // التنقل والتخطيط
    'menu'              => 'القائمة',
    'close'             => 'إغلاق',
    'back'              => 'رجوع',
    'home'              => 'الرئيسية',
    'dashboard'         => 'لوحة التحكم',
    'profile'           => 'الملف الشخصي',
    'settings'          => 'الإعدادات',
    'logout'            => 'تسجيل الخروج',
    'login'             => 'تسجيل الدخول',

    // البحث
    'search'            => 'بحث...',
    'search_placeholder'=> 'البحث في التطبيق',
    'search_shortcut'   => 'Ctrl+K',
    'no_results'        => 'لا توجد نتائج',
    'search_history'    => 'عمليات البحث الأخيرة',
    'load_more'         => 'تحميل المزيد',
    'results_count'     => ':count نتيجة',

    // الإشعارات
    'notifications'     => 'الإشعارات',
    'no_notifications'  => 'لا توجد إشعارات',
    'mark_all_read'     => 'تحديد الكل كمقروء',

    // النماذج
    'save'              => 'حفظ',
    'cancel'            => 'إلغاء',
    'delete'            => 'حذف',
    'edit'              => 'تعديل',
    'create'            => 'إنشاء',
    'update'            => 'تحديث',
    'confirm'           => 'تأكيد',
    'submit'            => 'إرسال',
    'reset'             => 'إعادة تعيين',
    'upload'            => 'رفع',
    'download'          => 'تنزيل',
    'select'            => 'اختيار',
    'select_all'        => 'تحديد الكل',
    'deselect_all'      => 'إلغاء تحديد الكل',

    // الحالات والرسائل
    'loading'           => 'جار التحميل...',
    'saving'            => 'جار الحفظ...',
    'saved'             => 'تم الحفظ بنجاح',
    'deleted'           => 'تم الحذف بنجاح',
    'error'             => 'حدث خطأ',
    'success'           => 'تمت العملية بنجاح',
    'warning'           => 'تحذير',
    'info'              => 'معلومة',
    'confirm_delete'    => 'هل أنت متأكد من حذف هذا العنصر؟',
    'action_irreversible' => 'هذا الإجراء لا يمكن التراجع عنه.',

    // الجدول / القائمة
    'no_data'           => 'لا توجد بيانات',
    'per_page'          => 'لكل صفحة',
    'total'             => 'المجموع',
    'showing'           => 'عرض :from إلى :to من :total إدخال',
    'previous'          => 'السابق',
    'next'              => 'التالي',
    'first'             => 'الأول',
    'last'              => 'الأخير',

    // اللغة
    'language'          => 'اللغة',
    'change_language'   => 'تغيير اللغة',

    // المظهر
    'theme'             => 'المظهر',
    'light_mode'        => 'الوضع الفاتح',
    'dark_mode'         => 'الوضع الداكن',
    'system_mode'       => 'النظام',

];
