---

MT Foundation

«Socle technique de l’écosystème Martaf Labs»

---

📌 Informations générales

- Package : "mt-foundation"
- Vendor : "martaf-labs"
- Auteur : Brice Marcello Djoukeng
- Lieu : Fialah-fondonera, Dschang, Cameroun
- Date de création : 12 mai 2026
- Licence : MIT

---

🎯 Objectif

"mt-foundation" est le cœur technique de l’écosystème Martaf Labs.
Il centralise les éléments communs afin de :

- réduire la duplication de code
- standardiser les pratiques
- faciliter la maintenance
- améliorer la scalabilité des applications Laravel

---

🧠 Philosophie

Ce package repose sur les principes suivants :

- Séparation des responsabilités
- Modularité
- Réutilisabilité
- Découplage via interfaces (Contracts)

---

🧱 Architecture

Le package est organisé comme suit :

mt-foundation/
│
├── src/
│   ├── Contracts/
│   ├── Enums/
│   ├── Exceptions/
│   ├── Helpers/
│   ├── Models/
│   ├── Providers/
│   ├── Services/
│   ├── Support/
│   ├── Traits/
│   └── ValueObjects/
│
├── config/
├── database/
├── tests/
├── composer.json
└── README.md

---

📦 Contenu

✔ Inclus

- Services techniques (Upload, Cache, etc.)
- Helpers globaux
- Traits réutilisables
- Enums globaux
- Interfaces (Contracts)
- Modèles globaux (optionnels et limités)

---

❌ Exclus

- Logique métier (Blog, School, etc.)
- Interfaces utilisateur (Blade, Livewire)
- Controllers métier
- Migrations spécifiques aux modules

---

⚙️ Installation

Via Composer

composer require martaf-labs/mt-foundation

---

Via repository GitHub (privé)

"repositories": [
  {
    "type": "vcs",
    "url": "https://github.com/martaf-labs/mt-foundation"
  }
]

---

🚀 Utilisation

Exemple : utilisation d’un service

use Martaf\Foundation\Services\FileService;

$fileService = new FileService();
$fileService->upload($file);

---

Exemple : utilisation d’un trait

use Martaf\Foundation\Traits\HasUuid;

class User extends Model
{
    use HasUuid;
}

---

🔌 Service Provider

Le package enregistre automatiquement :

- les bindings (interfaces → implémentations)
- les helpers
- les fichiers de configuration

---

🧪 Tests

Lancer les tests :

phpunit

---

📏 Conventions

- PSR-12 respecté
- Architecture modulaire
- Nom des classes en PascalCase
- Helpers bien segmentés

---

🔗 Dépendances

- Laravel 10+
- PHP 8.1+

---

🧭 Roadmap

- [ ] Ajout d’un système de logging avancé
- [ ] Gestion centralisée des permissions
- [ ] Amélioration des Value Objects
- [ ] Support multi-tenancy

---

🤝 Contribution

Les contributions sont les bienvenues :

1. Fork du projet
2. Création d’une branche
3. Pull Request

---

📜 Licence

Ce projet est sous licence MIT.

---

🧠 À propos

"mt-foundation" est conçu comme la base d’un écosystème modulaire comprenant :

- mt-ui (UI)
- mt-blog (CMS)
- mt-school (gestion scolaire)

---

📬 Contact

Pour toute question ou collaboration :

- Email : (à compléter)
- GitHub : https://github.com/martaf-labs

---

⭐ Remarque

Ce package est en évolution continue.
Merci de vérifier régulièrement les mises à jour.

---
---

💡 Prochaine étape recommandée

Si tu veux, je peux te générer aussi :

un README standardisé pour tous tes packages (mt-blog, mt-school, etc.)

un badge system (version, build, license)

ou un template GitHub prêt à cloner pour uniformiser tout ton écosystème
