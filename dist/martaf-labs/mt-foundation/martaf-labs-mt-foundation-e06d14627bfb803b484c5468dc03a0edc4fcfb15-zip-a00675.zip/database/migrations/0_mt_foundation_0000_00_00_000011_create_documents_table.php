<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if(!Schema::hasTable('documents')){
            Schema::create('documents', function (Blueprint $table) {
                $table->id();
                
                // Polymorphisme : permet de lier à Equipement, mais aussi à d'autres modèles
                $table->string('modele_type');
                $table->unsignedBigInteger('modele_id');
                
                $table->string('titre');
                $table->enum('type', ['manuel', 'certificat', 'plan', 'facture', 'rapport', 'autre'])->default('autre');
                
                // Champs de personnalisation visuelle
                $table->string('icone')->nullable(); // ex: 'fas fa-file-pdf'
                $table->string('couleur')->default('#3a81ebff');
                
                $table->string('path'); // Chemin du fichier (PDF, Word, etc.)
                $table->text('description')->nullable();
                
                $table->integer('ordre')->default(0);
                $table->boolean('actif')->default(true);
                $table->boolean('principale')->default(false);
                
                // Pour stocker extension, poids du fichier, etc.
                $table->json('metadata')->nullable(); 

                $table->index(['modele_type', 'modele_id']);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('documents');
    }
};