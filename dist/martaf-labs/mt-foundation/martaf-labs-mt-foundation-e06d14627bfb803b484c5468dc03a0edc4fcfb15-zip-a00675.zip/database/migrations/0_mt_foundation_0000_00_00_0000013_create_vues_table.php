<?php

use Mt\SgniShared\Models\Vue;
use Mt\SgniShared\Models\Equipement;
use Mt\SgniShared\Models\Video;
use Mt\SgniShared\Models\Chantier;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if(!Schema::hasTable('vues')){
            Schema::create('vues', function (Blueprint $table) {
                $table->id();
                $table->string('model');//'video','chantier','equipement', etc.
                $table->bigInteger('model_id');
                $table->bigInteger('nombre')->nullable()->default(0);
                $table->softDeletes();
                $table->timestamps();
            
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('vues');
    }
};
