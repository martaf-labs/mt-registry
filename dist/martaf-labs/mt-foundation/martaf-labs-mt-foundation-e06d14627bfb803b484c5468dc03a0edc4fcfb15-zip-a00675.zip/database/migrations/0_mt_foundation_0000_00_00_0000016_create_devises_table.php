<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        if(!Schema::hasTable('devises')){
            Schema::create('devises', function (Blueprint $table) {
                $table->id();
                $table->string('code', 3)->unique(); //XAF, XOF, USD, etc.
                $table->string('nom'); //Franc CFA
                $table->string('symbole')->nullable(); 
                $table->string('icone')->nullable(); 
                $table->string('couleur')->nullable();
                $table->decimal('taux', 15, 6)->default(1);
                $table->text('description')->nullable(); 
                $table->boolean('principale')->default(false);
                $table->boolean('actif')->default(true);

                $table->timestamps();
                $table->softDeletes();
                $table->tracksUser();
            });
        }

    }

    public function down(): void
    {
        Schema::dropIfExists('devises');
    }
};
