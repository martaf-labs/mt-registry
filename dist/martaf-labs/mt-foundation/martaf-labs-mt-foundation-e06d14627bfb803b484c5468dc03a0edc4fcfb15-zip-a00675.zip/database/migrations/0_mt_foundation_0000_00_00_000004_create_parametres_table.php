<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        // Vérifie si la table n'existe pas déjà
        if (!Schema::hasTable('parametres')) {
            Schema::create('parametres', function (Blueprint $table) {
                $table->id();
                $table->string('cle')->unique()->comment('Clé du paramètre');
                $table->json('valeur')->nullable()->comment('Valeur du paramètre');
                $table->json('description')->nullable();
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        // Supprime la table si elle existe
        if (Schema::hasTable('parametres')) {
            Schema::dropIfExists('parametres');
        }
    }
};
