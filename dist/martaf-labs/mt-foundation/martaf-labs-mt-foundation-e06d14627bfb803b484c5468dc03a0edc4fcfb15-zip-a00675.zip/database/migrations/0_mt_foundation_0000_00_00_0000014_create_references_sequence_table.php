<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        if(!Schema::hasTable('references_sequence')){
            Schema::create('references_sequence', function (Blueprint $table) {
                $table->id();
                $table->string('pattern', 100); // Pattern de référence
                $table->string('base_reference', 50); // Référence de base
                $table->string('last_reference', 100); // Dernière référence générée
                $table->timestamp('last_used_at');
                $table->timestamps();

                $table->unique(['pattern', 'base_reference']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('references_sequence');
    }
};
