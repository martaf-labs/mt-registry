<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if(!Schema::hasTable('visites')){
            Schema::create('visites', function (Blueprint $table) {
                $table->id();
                $table->string('adresse_ip');
                $table->string('pays');
                $table->string('region');
                $table->string('appareil');
                $table->string('plateforme');
                $table->string('navigateur');
                $table->string('url');
                $table->timestamp('visited_at');
                $table->softDeletes();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('visites');
    }
};
