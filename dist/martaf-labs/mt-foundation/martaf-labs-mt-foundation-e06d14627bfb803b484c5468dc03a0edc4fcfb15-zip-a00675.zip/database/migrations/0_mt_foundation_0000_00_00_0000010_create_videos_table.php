<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if(!Schema::hasTable('videos')){
            Schema::create('videos', function (Blueprint $table) {
                $table->id();
                
                // Polymorphisme pour lier à Chantier, Equipement, etc.
                $table->string('modele_type');
                $table->unsignedBigInteger('modele_id');
                
                // Types spécifiques aux vidéos
                $table->enum('type', ['presentation', 'inspection', 'formation', 'temoignage'])->default('presentation');
                
                $table->string('titre')->nullable();
                $table->string('path'); // Chemin du fichier ou URL
                $table->string('thumbnail_path')->nullable(); // Image de couverture de la vidéo
                
                $table->text('description')->nullable();
                $table->integer('duration')->nullable(); // Durée en secondes
                
                $table->integer('ordre')->default(0);
                $table->boolean('actif')->default(true);
                $table->boolean('is_featured')->default(false);
                
                // Stockage des infos techniques (résolution, codec, poids)
                $table->json('metadata')->nullable(); 
            
                $table->index(['modele_type', 'modele_id']);
                $table->softDeletes();
                $table->tracksUser();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('videos');
    }
};