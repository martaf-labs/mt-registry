<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        if(!Schema::hasTable('contacts')){
            Schema::create('contacts', function (Blueprint $table) {
                $table->id();

                $table->morphs('contactable');// contactable_id + contactable_type
                $table->string('type'); // TELEPHONE, EMAIL, WHATSAPP, SITE_WEB, FAX, FACEBOOK…
                $table->string('valeur'); // numéro / email / url
                $table->string('icone')->nullable(); // icône font-awesome ou autre pour représenter le type de contact
                $table->string('couleur')->nullable(); // couleur hexadécimale pour différencier les types de contact
                $table->text('description')->nullable(); 
                $table->boolean('principal')->default(false);
                $table->boolean('actif')->default(true);

                $table->timestamps();
                $table->softDeletes();
                $table->tracksUser();
            });
        }

    }

    public function down(): void
    {
        Schema::dropIfExists('contacts');
    }
};
