git init
git add .
git commit -m "Initial commit - mt-foundation"
git remote add origin https://github.com/martaf-labs/mt-foundation.git
git branch -M main    
git pull origin main --rebase
git push -u origin main