<?php

namespace MtSkeletonCore;

use Illuminate\Support\ServiceProvider;
use MtSkeletonCore\Console\Commands\InstallCommand;
use MtSkeletonCore\Console\Commands\MakeModuleCommand;
// use MtSkeletonCore\Console\Commands\UpdateCommand;

/**
 * MtSkeletonCoreServiceProvider
 *
 * Point d'entrée principal de mt-skeleton-core.
 *
 * Rôle :
 *   - Enregistre les commandes Artisan (mt:install, mt:module, mt:update)
 *   - Fusionne la configuration du skeleton
 *   - Publie les ressources (config, stubs)
 *
 * Ce provider est automatiquement découvert par Laravel
 * grâce à la section "extra.laravel.providers" du composer.json
 * de mt-skeleton-core.
 */
class MtSkeletonCoreServiceProvider extends ServiceProvider
{
    /**
     * Chemin racine du package.
     * Calculé une seule fois pour éviter les répétitions.
     */
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        $this->basePath = dirname(__DIR__);
    }

    /**
     * Enregistre les services dans le conteneur IoC.
     * Appelé avant boot(), idéal pour les bindings simples.
     */
    public function register(): void
    {
        // Fusion de la configuration du skeleton avec celle de l'app.
        // Permet à l'app de surcharger la config via config/mt-skeleton-core.php
        $this->mergeConfigFrom(
            $this->basePath . '/config/mt-skeleton-core.php',
            'mt-skeleton'
        );
    }

    /**
     * Démarre les services du skeleton.
     * Appelé après register(), une fois tous les providers chargés.
     */
    public function boot(): void
    {
        // Les commandes et ressources publiables
        // ne sont utiles qu'en ligne de commande
        if ($this->app->runningInConsole()) {
            $this->registerCommands();
            $this->registerPublishables();
        }
    }

    /**
     * Enregistre les commandes Artisan du skeleton.
     *
     * mt:install → Assistant interactif d'installation de l'écosystème
     * mt:module  → Ajout d'un module mt-* dans un projet existant
     * mt:update  → Mise à jour des ressources publiables des modules installés
     */
    protected function registerCommands(): void
    {
        $this->commands([
            InstallCommand::class,
            MakeModuleCommand::class,
            // UpdateCommand::class,
        ]);
    }

    /**
     * Déclare les ressources publiables via `php artisan vendor:publish`.
     *
     * Tags disponibles :
     *   mt-skeleton-config → config/mt-skeleton-core.php
     *                        Personnaliser les modules et présets disponibles
     *
     *   mt-skeleton-stubs  → stubs/mt/
     *                        Personnaliser les fichiers générés par les installers
     *                        (routes, controllers, config...)
     */
    protected function registerPublishables(): void
    {
        // Configuration des modules et présets
        $this->publishes([
            $this->basePath . '/config/mt-skeleton-core.php' => config_path('mt-skeleton.php'),
        ], 'mt-skeleton-config');

        // Stubs personnalisables
        // Une fois publiés dans stubs/mt/, ils ont priorité sur
        // les stubs du package (voir BaseInstaller::copyStub)
        $this->publishes([
            $this->basePath . '/stubs' => base_path('stubs/mt'),
        ], 'mt-skeleton-stubs');
    }
}
