<?php

namespace MtSkeletonCore\Installers;

/**
 * AuthInstaller
 *
 * Installer du module mt-auth.
 * Ce module fournit l'authentification complète pour les projets martaf-labs.
 *
 * Il s'occupe de :
 *   - Installer le package via Composer si absent
 *   - Publier la configuration mt-auth.php
 *   - Publier les migrations (users, roles, permissions, password_resets...)
 *   - Publier les vues Blade (login, register, forgot-password...)
 *   - Publier les fichiers de traduction (fr, en, ar)
 *   - Copier les routes d'authentification
 *   - Enregistrer les macros Blueprint (tracksUser)
 *
 * Prérequis : FoundationInstaller doit être exécuté avant.
 */
class AuthInstaller extends BaseInstaller
{
    /**
     * Installation de mt-auth.
     *
     * @param bool $force Écraser les fichiers existants si true
     */
    public function install(bool $force = false): void
    {
        // 1. Installer le package via Composer si pas encore présent
        //    → Nécessaire quand mt:module est appelé après l'installation initiale
        if (! $this->isPackageInstalled('martaf-labs/mt-auth')) {
            $this->requireComposerPackage('martaf-labs/mt-auth');
        }

        // 2. Publier la configuration principale du module
        //    → Génère config/mt-auth.php dans le projet
        //    → Contient : guard, providers, fortify features, redirects...
        $this->publish('mt-auth-config', $force);

        // 3. Publier les migrations
        //    → Tables : users (étendue), roles, permissions,
        //               role_user, permission_role, password_reset_tokens...
        $this->publish('mt-auth-migrations', $force);

        // 4. Publier les vues Blade d'authentification
        //    → resources/views/vendor/mt/mt-auth/
        //    → Inclut : login, register, forgot-password, reset-password,
        //               verify-email, confirm-password
        $this->publish('mt-auth-views', $force);

        // 5. Publier les fichiers de traduction
        //    → lang/vendor/mt/mt-auth/{fr,en,ar}/
        $this->publish('mt-auth-lang', $force);

        // 6. Copier les routes d'authentification
        //    → routes/mt-auth.php
        //    → À inclure dans routes/web.php via :
        //      require __DIR__.'/mt-auth.php';
        $this->copyStub(
            stubPath: 'routes/mt-auth.php',
            destPath: 'routes/mt-auth.php',
            force: $force
        );

        // 7. Rappels importants pour le développeur
        $this->info("Ajoutez dans routes/web.php :");
        $this->info("require __DIR__.'/mt-auth.php';");
        $this->info("Lancez ensuite : php artisan migrate");

        $this->success('mt-auth configuré avec succès.');
    }
}
