<?php

namespace MtSkeletonCore\Installers;

/**
 * ViewsInstaller
 *
 * Installer du module mt-views.
 *
 * Il s'occupe de :
 *   - Installer le package via Composer si absent
 *   - Publier la configuration (thème, layouts, pagination...)
 *   - Publier les vues Blade (composants, layouts)
 *   - Publier les assets CSS/JS compilés
 *   - Publier les fichiers de traduction (fr, en, ar)
 */
class ViewsInstaller extends BaseInstaller
{
    /**
     * Installation de mt-views.
     *
     * @param bool $force Écraser les fichiers existants si true
     */
    public function install(bool $force = false): void
    {
        // 1. Installer le package via Composer si pas encore présent
        if (! $this->isPackageInstalled('martaf-labs/mt-views')) {
            $this->requireComposerPackage('martaf-labs/mt-views');
        }

        // 2. Publier la configuration principale
        //    → config/mt-views.php dans le projet
        $this->publish('mt-views-config', $force);

        // 3. Publier les vues Blade
        //    → resources/views/vendor/mt/mt-views/
        //    → Inclut composants, layouts, partials
        $this->publish('mt-views-views', $force);

        // 4. Publier les assets CSS/JS compilés
        //    → public/vendor/mt/mt-views/
        $this->publish('mt-views-assets', $force);

        // 5. Publier les fichiers de traduction
        //    → lang/vendor/mt/mt-views/{fr,en,ar}/
        $this->publish('mt-views-lang', $force);

        // 6. Informer le développeur d'inclure le middleware
        $this->info("Ajoutez 'mt.layout' dans vos routes si nécessaire.");

        $this->success('mt-views configuré avec succès.');
    }
}