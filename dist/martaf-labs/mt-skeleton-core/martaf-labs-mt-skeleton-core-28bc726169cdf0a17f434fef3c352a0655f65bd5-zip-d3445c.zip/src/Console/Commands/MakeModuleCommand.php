<?php

namespace MtSkeletonCore\Console\Commands;

use Illuminate\Console\Command;

/**
 * MakeModuleCommand
 *
 * Permet d'ajouter un module mt-* dans un projet déjà installé,
 * sans avoir à relancer l'installation complète.
 *
 * Usage :
 *   php artisan mt:module blog
 *   php artisan mt:module school --force
 */
class MakeModuleCommand extends Command
{
    protected $signature = 'mt:module
                            {module : Nom du module à installer (ex: blog, school, docs)}
                            {--force : Écraser les fichiers existants}';

    protected $description = 'Ajoute un module mt-* dans un projet martaf-labs existant';

    public function handle(): int
    {
        $moduleKey = $this->argument('module');
        $modules   = config('mt-skeleton.modules', []);

        // Vérifier que le module existe dans la config
        if (! isset($modules[$moduleKey])) {
            $this->error("Module inconnu : {$moduleKey}");
            $this->line('Modules disponibles : ' . implode(', ', array_keys($modules)));
            return self::FAILURE;
        }

        $module = $modules[$moduleKey];

        $this->line("  <fg=cyan>→</> Installation de <options=bold>{$module['label']}</>...");

        try {
            $installer = new $module['installer']($this);
            $installer->install(force: $this->option('force') ?? false);

            $this->line("  <fg=green>✓</> {$module['label']} installé avec succès.");
            return self::SUCCESS;

        } catch (\Throwable $e) {
            $this->error("Erreur : {$e->getMessage()}");
            return self::FAILURE;
        }
    }
} // CORRECTION : accolade fermante de la classe manquante
