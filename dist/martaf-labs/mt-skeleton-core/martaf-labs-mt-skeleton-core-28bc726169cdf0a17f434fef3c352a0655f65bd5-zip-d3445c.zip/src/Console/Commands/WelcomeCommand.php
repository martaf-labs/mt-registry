<?php

namespace MtSkeletonCore\Console\Commands;

use Illuminate\Console\Command;

class WelcomeCommand extends Command
{
    protected $signature = 'mt:welcome';
    protected $description = 'Affiche le message de bienvenue après création du projet';

    public function handle(): int
    {
        $this->newLine();
        $this->line('  <fg=green;options=bold>✓ Projet créé avec succès !</>');
        $this->newLine();
        $this->line('  <options=bold>Lancez maintenant :</>');
        $this->line('  <fg=yellow>cd ' . basename(getcwd()) . '</>');
        $this->line('  <fg=yellow>php artisan mt:install</>');
        $this->newLine();

        return self::SUCCESS;
    }
}