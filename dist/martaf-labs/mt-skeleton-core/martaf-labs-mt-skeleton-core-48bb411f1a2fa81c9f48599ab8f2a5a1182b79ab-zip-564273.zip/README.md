# mt-skeleton-core

> Noyau de l'écosystème **martaf-labs**.
> Fournit les commandes Artisan, installers, stubs et configuration utilisés par `mt-skeleton`.

---

## Table des matières

- [Présentation](#présentation)
- [Installation](#installation)
- [Commandes Artisan](#commandes-artisan)
- [Architecture](#architecture)
- [Installers disponibles](#installers-disponibles)
- [Ajouter un installer](#ajouter-un-installer)
- [Stubs](#stubs)
- [Configuration](#configuration)
- [Contribuer](#contribuer)

---

## Présentation

`mt-skeleton-core` est le **package noyau** de l'écosystème martaf-labs.

Il est séparé de `mt-skeleton` (le scaffold Laravel) afin de permettre la **mise à jour des commandes et installers** dans tous les projets existants via un simple :

```bash
composer update martaf-labs/mt-skeleton-core
```

Sans `mt-skeleton-core`, toute modification des installers ou commandes nécessiterait de recréer manuellement chaque projet.

---

## Relation avec mt-skeleton

```
mt-skeleton (scaffold Laravel)
│
└── require martaf-labs/mt-skeleton-core
        │
        ├── src/Console/Commands/
        │   ├── InstallCommand.php    → php artisan mt:install
        │   ├── MakeModuleCommand.php → php artisan mt:module
        │   └── UpdateCommand.php     → php artisan mt:update
        │
        ├── src/Installers/
        │   ├── BaseInstaller.php
        │   ├── AuthInstaller.php
        │   ├── FoundationInstaller.php
        │   ├── ViewsInstaller.php
        │   └── SchoolInstaller.php
        │
        ├── config/mt-skeleton.php   → modules & présets
        └── stubs/                   → fichiers copiés dans le projet
```

---

## Installation

Ce package est installé automatiquement via `mt-skeleton` :

```bash
composer create-project martaf-labs/mt-skeleton mon-projet --stability=dev
```

Pour l'ajouter manuellement dans un projet Laravel existant :

```bash
composer require martaf-labs/mt-skeleton-core:dev-main
```

---

## Commandes Artisan

### `php artisan mt:install`

Lance l'assistant interactif d'installation de l'écosystème martaf-labs.

```bash
# Mode interactif
php artisan mt:install

# Avec un préset prédéfini
php artisan mt:install --preset=school

# Avec une sélection manuelle de modules
php artisan mt:install --preset=custom --modules=foundation,views,blog

# Forcer la réinstallation
php artisan mt:install --force
```

### `php artisan mt:module`

Ajoute un module mt-* dans un projet déjà installé.

```bash
php artisan mt:module blog
php artisan mt:module school --force
```

### `php artisan mt:update`

Met à jour les ressources publiables des modules déjà installés.

```bash
# Voir ce qui peut être mis à jour
php artisan mt:update --dry-run

# Mettre à jour un module spécifique
php artisan mt:update --module=foundation

# Tout mettre à jour (avec confirmation)
php artisan mt:update --force
```

---

## Architecture

```
mt-skeleton-core/
├── src/
│   ├── MtSkeletonCoreServiceProvider.php
│   ├── Console/
│   │   └── Commands/
│   │       ├── InstallCommand.php
│   │       ├── MakeModuleCommand.php
│   │       └── UpdateCommand.php
│   └── Installers/
│       ├── BaseInstaller.php        ← classe abstraite commune
│       ├── AuthInstaller.php
│       ├── FoundationInstaller.php
│       ├── ViewsInstaller.php
│       └── SchoolInstaller.php
├── config/
│   └── mt-skeleton.php             ← modules & présets disponibles
├── stubs/
│   └── routes/
│       ├── mt-auth.php
│       └── mt-school.php
└── composer.json
```

---

## Installers disponibles

Chaque module mt-* possède son Installer dans `src/Installers/`.

| Installer | Module | Commande |
|-----------|--------|----------|
| `FoundationInstaller` | `martaf-labs/mt-foundation` | `mt:module foundation` |
| `AuthInstaller` | `martaf-labs/mt-auth` | `mt:module auth` |
| `ViewsInstaller` | `martaf-labs/mt-ui` | `mt:module views` |
| `SchoolInstaller` | `martaf-labs/mt-school-core` | `mt:module school` |

---

## Ajouter un installer

**1. Créer le fichier dans `src/Installers/` :**

```php
<?php

namespace MtSkeletonCore\Installers;

class BlogInstaller extends BaseInstaller
{
    public function install(bool $force = false): void
    {
        if (! $this->isPackageInstalled('martaf-labs/mt-blog')) {
            $this->requireComposerPackage('martaf-labs/mt-blog');
        }

        $this->publish('mt-blog-config', $force);
        $this->publish('mt-blog-migrations', $force);
        $this->publish('mt-blog-views', $force);
        $this->publish('mt-blog-lang', $force);

        $this->copyStub('routes/mt-blog.php', 'routes/mt-blog.php', $force);

        $this->success('mt-blog configuré avec succès.');
    }
}
```

**2. Déclarer le module dans `config/mt-skeleton.php` :**

```php
'blog' => [
    'label'       => 'Site Blog',
    'description' => 'Blog complet : articles, catégories, tags, auteurs.',
    'installer'   => \MtSkeletonCore\Installers\BlogInstaller::class,
    'required'    => false,
    'depends_on'  => ['foundation', 'views'],
],
```

**3. Ajouter le module aux présets souhaités :**

```php
'presets' => [
    'blog' => [
        'label'   => 'Site Blog',
        'modules' => ['foundation', 'auth', 'views', 'blog'],
    ],
],
```

---

## Stubs

Les stubs sont des fichiers copiés dans le projet lors de l'installation d'un module.

**Localisation dans le package :**
```
stubs/
├── routes/
│   ├── mt-auth.php
│   └── mt-school.php
└── controllers/
    └── School/
        └── DashboardController.php
```

**Priorité de résolution (dans `BaseInstaller::copyStub`) :**
1. `stubs/mt/{stub}` dans le projet — stub personnalisé par le développeur
2. `stubs/{stub}` dans `mt-skeleton-core` — stub par défaut du package

Cela permet au développeur de personnaliser les stubs sans modifier le package.

**Publier les stubs dans le projet :**
```bash
php artisan vendor:publish --tag=mt-skeleton-stubs
```

---

## Configuration

Le fichier `config/mt-skeleton.php` définit les modules et présets disponibles.

**Publier la config dans le projet :**
```bash
php artisan vendor:publish --tag=mt-skeleton-config
```

**Structure de la config :**

```php
return [
    'modules' => [
        'foundation' => [
            'label'       => 'mt-foundation (socle commun)',
            'description' => 'Socle obligatoire : helpers, traits, config globale.',
            'installer'   => \MtSkeletonCore\Installers\FoundationInstaller::class,
            'required'    => true,
            'depends_on'  => [],
        ],
        // ...
    ],

    'presets' => [
        'minimal' => [
            'label'   => 'Minimal (foundation + auth)',
            'modules' => ['foundation', 'auth'],
        ],
        // ...
    ],
];
```

---

## Contribuer

### Ajouter un nouveau package mt-* à l'écosystème

1. Créer le repo `martaf-labs/mt-nouveau` sur GitHub
2. Ajouter l'URL dans `mt-registry/satis.json`
3. Créer `NouveauInstaller.php` dans `src/Installers/`
4. Déclarer le module dans `config/mt-skeleton.php`
5. Ajouter les stubs nécessaires dans `stubs/`
6. Pousser sur `main` → le registry se reconstruit automatiquement

### Mettre à jour un projet existant

```bash
composer update martaf-labs/mt-skeleton-core
php artisan mt:update
```# mt-skeleton-core
