<?php
// Chemin vers le dossier des SVG
$svgPath = __DIR__ . '/../resources/views/icons';
$cssPath = __DIR__ . '/../resources/css/icons.css';

// URL publique pour les SVG (adapter si nécessaire)
$publicUrl = ''; 

// Vérifier que le dossier existe
if (!is_dir($svgPath)) {
    echo "Le dossier des icônes n'existe pas.\n";
    exit;
}

// Commencer le contenu CSS
$cssContent = "/* Auto-generated CSS pour mt-icons */\n\n";

// Parcourir tous les SVG
foreach (glob($svgPath . '/*.svg') as $file) {
    $name = pathinfo($file, PATHINFO_FILENAME);
    
    // URL relative du SVG
    // $url = "$publicUrl/$name.svg";
    $url = "$name.svg";

    $cssContent .= <<<CSS
.mt-icon-$name {
    mask: url('$url') no-repeat center;
    -webkit-mask: url('$url') no-repeat center;
    mask-size: contain;
    -webkit-mask-size: contain;
    background-color: currentColor;
    display: inline-block;
    width: 1em;
    height: 1em;
}

CSS;
}

// Écrire le fichier CSS
if (!is_dir(dirname($cssPath))) {
    mkdir(dirname($cssPath), 0755, true);
}

file_put_contents($cssPath, $cssContent);

echo "✅ CSS pour les icônes généré avec succès : $cssPath\n";