{{--
┌──────────────────────────────────────────────────────────────────────────┐
│  mt::livewire.auth.login                                                 │
│  Vue unique — 4 variantes via $variant (mt_config 'login_variant')       │
│                                                                          │
│  PHILOSOPHIE : 100% CSS variables --mt-* du package                     │
│  Aucune couleur hardcodée. Dark mode automatique. Police via --font-mt-* │
│                                                                          │
│  Variantes disponibles :                                                 │
│    luxury    → Split-screen sobre, accentuation sur --mt-primary         │
│    tech      → Centré, glassmorphism, aura --mt-primary animée           │
│    organic   → Card centrée arrondie, illustration SVG --mt-primary      │
│    editorial → Split typographique asymétrique, uppercase                │
└──────────────────────────────────────────────────────────────────────────┘
--}}

@section('title', 'Connexion')

@switch($variant)


{{-- ═══════════════════════════════════════════════════════════════════════
     VARIANTE : luxury
     Split 60/40 · Panneau marque à gauche · Formulaire à droite
     ═══════════════════════════════════════════════════════════════════════ --}}
@case('luxury')

<div class="flex min-h-screen w-full">

    {{-- ── PANNEAU GAUCHE ── --}}
    <div class="hidden lg:flex lg:w-3/5 flex-col justify-between p-16 relative overflow-hidden border-r border-[rgb(var(--mt-ui-card-border))] bg-[rgb(var(--mt-bg))]">
        {{-- Dégradé d'ambiance --}}
        <div class="absolute inset-0 bg-gradient-to-br from-[rgba(var(--mt-primary),0.1)] via-transparent to-transparent pointer-events-none"></div>
        
        {{-- Barre verticale accent --}}
        <div class="absolute left-0 top-0 w-[3px] h-full bg-gradient-to-b from-transparent via-[rgb(var(--mt-primary))] to-transparent opacity-65"></div>
        
        {{-- Cercles décoratifs --}}
        <div class="absolute -bottom-10-right-36 w-128 h-128 rounded-full border border-[rgba(var(--mt-primary),0.1)] pointer-events-none"></div>
        <div class="absolute -bottom-20 -right-20 w-80 h-80 rounded-full border border-[rgba(var(--mt-primary),0.1)] pointer-events-none"></div>

        {{-- Logo --}}
        <div class="relative">
            <span class="text-[rgb(var(--mt-primary))] text-xs font-semibold uppercase">
                {{ mt_config('app_name') }}
            </span>
        </div>

        {{-- Citation --}}
        <div class="relative space-y-6">
            <div class="w-12 h-0.5 bg-[rgb(var(--mt-primary))]"></div>
            <blockquote class="text-4xl md:text-5xl font-light leading-tight max-w-md" style="line-height:1.2;">
                L'excellence<br>commence par
                <span class="text-[rgb(var(--mt-primary))] italic"> l'accès.</span>
            </blockquote>
            <p class="text-sm text-[rgb(var(--mt-text-muted))] leading-relaxed max-w-md" style="line-height:1.7;">
                Une plateforme construite pour les professionnels qui exigent plus.
            </p>
        </div>

        {{-- Footer --}}
        <div class="relative flex items-center gap-4">
            <div class="flex-1 border-t border-[rgb(var(--mt-ui-card-border))]"></div>
            <span class="text-xs text-[rgb(var(--mt-text-muted))] tracking-[.25em] uppercase">
                Sécurisé & Confidentiel
            </span>
        </div>
    </div>

    {{-- ── PANNEAU DROIT ── --}}
    <div class="flex flex-1 flex-col justify-center px-8 py-16 sm:px-16 bg-[rgb(var(--mt-bg))]">
        <div class="lg:hidden mb-10 opacity-0 translate-y-4 animate-[fadeUp_0.45s_ease_forwards]">
            <span class="text-[rgb(var(--mt-primary))] text-xs font-semibold tracking-[.4em] uppercase">
                {{ mt_config('app_name') }}
            </span>
        </div>

        <div class="mx-auto w-full max-w-md">

            <div class="mb-8 space-y-1 opacity-0 translate-y-4 animate-[fadeUp_0.45s_0s_ease_forwards]">
                <h1 class="text-3xl md:text-4xl font-light">Connexion</h1>
                <p class="text-sm text-[rgb(var(--mt-text-muted))]">Entrez vos identifiants pour accéder à votre espace</p>
            </div>

            <x-mt::auth-session-status class="mb-5 text-sm text-center opacity-0 translate-y-4 animate-[fadeUp_0.45s_0s_ease_forwards]" :status="session('status')" />

            <form wire:submit="login" class="space-y-6">
                <div class="opacity-0 translate-y-4 animate-[fadeUp_0.45s_0.08s_ease_forwards]">
                    <x-mt::form.input
                        wire:model="email"
                        :label="__('Adresse e-mail')"
                        type="email" required autofocus
                        autocomplete="email"
                        placeholder="email@exemple.com"
                        :error="$errors->first('email')"
                    />
                </div>

                <div class="opacity-0 translate-y-4 animate-[fadeUp_0.45s_0.16s_ease_forwards]">
                    <x-mt::form.input
                        wire:model="password"
                        :label="__('Mot de passe')"
                        type="password" required
                        autocomplete="current-password"
                        :placeholder="__('••••••••')"
                        viewable
                        :error="$errors->first('password')"
                    />
                    @if($hasPasswordReset)
                        <div class="flex justify-end mt-2">
                            <a href="{{ route('password.request') }}" wire:navigate
                               class="text-xs text-[rgb(var(--mt-text-muted))] hover:text-[rgb(var(--mt-primary))] transition-[var(--mt-transition)]">
                                Mot de passe oublié ?
                            </a>
                        </div>
                    @endif
                </div>

                @if($hasRememberMe)
                <div class="opacity-0 translate-y-4 animate-[fadeUp_0.45s_0.16s_ease_forwards]">
                    <x-mt::form.toggle wire:model="remember" :label="__('Rester connecté')" />
                </div>
                @endif

                <div class="opacity-0 translate-y-4 animate-[fadeUp_0.45s_0.24s_ease_forwards]">
                    <x-mt::button variant="primary" type="submit" endIcon="chevron-right"
                        loading="login" data-test="login-button" class="w-full rounded-none text-[.8125rem] py-4 px-6">
                        {{ mt_translate('login') }}
                    </x-mt::button>
                </div>
            </form>

            @if($hasHome)
                <div class="text-center mt-8 opacity-0 translate-y-4 animate-[fadeUp_0.45s_0.24s_ease_forwards]">
                    <a href="{{ route('home') }}" wire:navigate
                       class="text-sm text-[rgb(var(--mt-text-muted))] transition-[var(--mt-transition)]">
                        ← Retour à {{ mt_config('app_name') }}
                    </a>
                </div>
            @endif
        </div>
    </div>
</div>

@push('styles')
<style>
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(16px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
@endpush
@break


{{-- ═══════════════════════════════════════════════════════════════════════
     VARIANTE : tech
     Centré · Fond mt-bg · Card glassmorphism · Aura --mt-primary animée
     ═══════════════════════════════════════════════════════════════════════ --}}
@case('tech')

<div class="min-h-screen flex items-center justify-center lg:p-4 bg-[rgb(var(--mt-bg))] relative overflow-hidden">
    {{-- Auras --}}
    <div class="hidden lg:block absolute -top-48 -left-48 w-144 h-144 rounded-full bg-[radial-gradient(circle,_rgba(var(--mt-primary),0.16)_0%,_transparent_70%)] animate-techPulse1 pointer-events-none"></div>
    <div class="absolute -bottom-40 -right-32 w-120 h-120 rounded-full bg-[radial-gradient(circle,_rgba(var(--mt-secondary),0.12)_0%,_transparent_70%)] animate-techPulse2 pointer-events-none"></div>
    
    {{-- Grid --}}
    <div class="hidden lg:block absolute inset-0 opacity-[0.03] bg-[linear-gradient(rgba(var(--mt-text),1)_1px,_transparent_1px),_linear-gradient(90deg,_rgba(var(--mt-text),1)_1px,_transparent_1px)] bg-[length:44px_44px] pointer-events-none"></div>

    <div class="lg:bg-[rgba(var(--mt-ui-card-bg),0.65)] backdrop-blur-xl lg:border-0 border-[rgb(var(--mt-ui-card-border))] rounded-xl w-full max-w-md relative overflow-hidden opacity-0 animate-[techUp_0.4s_0s_ease_forwards]">
        {{-- Liseré top --}}
        <div class="hidden lg:block absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-[rgb(var(--mt-primary))] via-[rgba(var(--mt-secondary),0.8)] to-transparent"></div>
        
        <div class="px-2 py-6 lg:p-8">

            {{-- <div class="flex items-center gap-2 opacity-0 translate-y-5 animate-[techUp_0.4s_0s_ease_forwards]">
                <div class="w-2 h-2 rounded-full bg-[rgb(var(--mt-success))] shadow-[0_0_7px_rgba(var(--mt-success),0.75)] animate-techBlink"></div>
                <span class="text-xs text-[rgb(var(--mt-text-muted))] tracking-[.2em] uppercase">
                    Système actif
                </span>
            </div> --}}

            <div class="space-y-1 opacity-0 animate-[techUp_0.4s_0.08s_ease_forwards]">
                <h1 class="text-3xl md:text-4xl font-semibold mt-text-primary">Connexion<span class="text-[rgb(var(--mt-primary))]">_</span></h1>
                <p class="text-sm text-[rgb(var(--mt-text-muted))]">Authentifiez-vous pour continuer</p>
            </div>

            <x-mt::auth-session-status class="text-sm opacity-0 animate-[techUp_0.4s_0.08s_ease_forwards]" :status="session('status')" />

            <form wire:submit="login" class="space-y-5 opacity-0 translate-y-5 animate-[techUp_0.4s_0.16s_ease_forwards]">
                <x-mt::form.input
                    wire:model="email" :label="__('E-mail')"
                    type="email" required autofocus
                    autocomplete="email"
                    placeholder="user@domaine.io"
                    :error="$errors->first('email')"
                />

                <div>
                    <x-mt::form.input
                        wire:model="password" :label="__('Mot de passe')"
                        type="password" required
                        autocomplete="current-password"
                        placeholder="••••••••" viewable
                        :error="$errors->first('password')"
                    />
                    @if($hasPasswordReset)
                        <div class="flex justify-end mt-1.5">
                            <a href="{{ route('password.request') }}" wire:navigate
                               class="text-xs text-[rgb(var(--mt-primary))] transition-[var(--mt-transition)] opacity-85">
                                Mot de passe oublié ?
                            </a>
                        </div>
                    @endif
                </div>

                @if($hasRememberMe)
                <x-mt::form.toggle wire:model="remember" :label="__('Rester connecté')" />
                @endif

                <x-mt::button variant="primary" type="submit" endIcon="chevron-right"
                    loading="login" data-test="login-button" class="w-full">
                    {{ mt_translate('login') }}
                </x-mt::button>
            </form>

            @if($hasHome)
                <div class="text-center opacity-0 translate-y-5 mt-2 animate-[techUp_0.4s_0.24s_ease_forwards]">
                    <a href="{{ route('home') }}" wire:navigate
                       class="text-xs text-[rgb(var(--mt-text-muted))] transition-[var(--mt-transition)] tracking-[.05em]">
                        ↩ {{ mt_config('app_name') }}
                    </a>
                </div>
            @endif
        </div>
    </div>
</div>

@push('styles')
<style>
@keyframes techPulse1 {
    from { transform: translate(0,0) scale(1); }
    to { transform: translate(60px,40px) scale(1.25); }
}
@keyframes techPulse2 {
    from { transform: translate(0,0) scale(1.1); }
    to { transform: translate(-40px,-50px) scale(0.85); }
}
@keyframes techBlink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
}
@keyframes techUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
.animate-techPulse1 { animation: techPulse1 9s ease-in-out infinite alternate; }
.animate-techPulse2 { animation: techPulse2 11s ease-in-out infinite alternate; }
.animate-techBlink { animation: techBlink 2s ease-in-out infinite; }
</style>
@endpush
@break


{{-- ═══════════════════════════════════════════════════════════════════════
     VARIANTE : organic
     Centré · Blobs doux · Card arrondie · Illustration SVG --mt-primary
     ═══════════════════════════════════════════════════════════════════════ --}}
@case('organic')

<div class="min-h-screen flex items-center justify-center p-4 bg-[rgb(var(--mt-bg))] relative overflow-hidden">
    {{-- Blobs --}}
    <div class="absolute -top-40 -left-40 w-112 h-112 rounded-full bg-[radial-gradient(circle,_rgba(var(--mt-primary),0.12)_0%,_transparent_70%)] pointer-events-none"></div>
    <div class="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-[radial-gradient(circle,_rgba(var(--mt-secondary),0.1)_0%,_transparent_70%)] pointer-events-none"></div>
    
    {{-- Dots --}}
    <div class="absolute top-20 right-[25%] w-4 h-4 rounded-full bg-[rgba(var(--mt-primary),0.35)] pointer-events-none"></div>
    <div class="absolute bottom-32 left-[25%] w-3 h-3 rounded-full bg-[rgba(var(--mt-secondary),0.3)] pointer-events-none"></div>

    <div class="w-full max-w-md opacity-0 translate-y-5 animate-[organicUp_0.5s_0s_ease_forwards]">

        <div class="bg-[rgb(var(--mt-ui-card-bg))] border border-[rgba(var(--mt-ui-card-border),0.7)] rounded-2xl">
            <div class="p-8 sm:p-10 space-y-6">

                <div class="text-center space-y-1 opacity-0 translate-y-5 animate-[organicUp_0.5s_0.09s_ease_forwards]">
                    <p class="text-[rgb(var(--mt-primary))] text-xs font-semibold tracking-[.3em] uppercase">
                        {{ mt_config('app_name') }}
                    </p>
                    <h1 class="text-3xl md:text-4xl font-light">Bon retour ! 👋</h1>
                    <p class="text-sm text-[rgb(var(--mt-text-muted))]">Entrez vos informations pour continuer</p>
                </div>

                <x-mt::auth-session-status class="text-sm text-center opacity-0 translate-y-5 animate-[organicUp_0.5s_0.09s_ease_forwards]" :status="session('status')" />

                <form wire:submit="login" class="space-y-5 opacity-0 translate-y-5 animate-[organicUp_0.5s_0.18s_ease_forwards]">
                    <x-mt::form.input
                        wire:model="email" :label="__('Adresse e-mail')"
                        type="email" required autofocus
                        autocomplete="email" placeholder="vous@exemple.com"
                        :error="$errors->first('email')"
                    />

                    <div>
                        <x-mt::form.input
                            wire:model="password" :label="__('Mot de passe')"
                            type="password" required
                            autocomplete="current-password" :placeholder="__('••••••••')" viewable
                            :error="$errors->first('password')"
                        />
                        @if($hasPasswordReset)
                            <div class="flex justify-end mt-1.5">
                                <a href="{{ route('password.request') }}" wire:navigate
                                   class="text-xs text-[rgb(var(--mt-primary))] font-medium transition-[var(--mt-transition)]">
                                    Mot de passe oublié ?
                                </a>
                            </div>
                        @endif
                    </div>

                    @if($hasRememberMe)
                    <x-mt::form.toggle wire:model="remember" :label="__('Se souvenir de moi')" />
                    @endif

                    <x-mt::button variant="primary" type="submit" endIcon="chevron-right"
                        loading="login" data-test="login-button" class="w-full rounded-xl py-3 px-6">
                        {{ mt_translate('login') }}
                    </x-mt::button>
                </form>

                @if($hasRegister || $hasHome)
                    <div class="border-t border-[rgb(var(--mt-ui-card-border))] pt-5 opacity-0 translate-y-5 animate-[organicUp_0.5s_0.27s_ease_forwards]">
                        <div class="space-y-3 text-center">
                            @if($hasRegister)
                                <p class="text-sm text-[rgb(var(--mt-text-muted))]">
                                    Pas encore de compte ?
                                    <a href="{{ route('register') }}" wire:navigate
                                       class="text-[rgb(var(--mt-primary))] font-semibold ml-1 transition-[var(--mt-transition)]">
                                        Inscrivez-vous
                                    </a>
                                </p>
                            @endif
                            @if($hasHome)
                                <a href="{{ route('home') }}" wire:navigate
                                   class="block text-xs text-[rgb(var(--mt-text-muted))] transition-[var(--mt-transition)]">
                                    ← Retour à {{ mt_config('app_name') }}
                                </a>
                            @endif
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
@keyframes organicUp {
    from { opacity: 0; transform: translateY(18px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
@endpush
@break


{{-- ═══════════════════════════════════════════════════════════════════════
     VARIANTE : editorial
     Split asymétrique · Typographie massive · Accent --mt-primary
     ═══════════════════════════════════════════════════════════════════════ --}}
@case('editorial')

<div class="flex min-h-screen bg-[rgb(var(--mt-bg))] overflow-hidden">

    {{-- Panneau gauche --}}
    <div class="hidden lg:flex lg:w-1/2 flex-col justify-between p-12 xl:p-16 border-r-2 border-[rgb(var(--mt-ui-card-border))] bg-[rgb(var(--mt-bg))] relative overflow-hidden opacity-0 translate-x-[-28px] animate-[editorialSlideLeft_0.5s_ease_forwards]">
        {{-- Carré décoratif --}}
        <div class="absolute -bottom-24 -left-24 w-80 h-80 rounded-2xl bg-[rgba(var(--mt-primary),0.07)] rotate-[15deg] pointer-events-none"></div>
        
        <div class="relative">
            <div class="text-[clamp(4.5rem,9vw,9.5rem)] font-extrabold leading-[0.87] tracking-[-0.04em] text-[rgb(var(--mt-text))] select-none">
                CON<br>NEX<br><span class="text-[rgb(var(--mt-primary))]">ION</span>
            </div>
        </div>

        <div class="relative space-y-5">
            <div class="flex items-center gap-4">
                <div class="h-0.5 w-12 bg-[rgb(var(--mt-primary))]"></div>
                <span class="text-xs text-[rgb(var(--mt-text-muted))] tracking-[.35em] uppercase">
                    {{ mt_config('app_name') }}
                </span>
            </div>
            <div class="flex flex-wrap gap-2">
                @foreach(['Sécurisé', 'Rapide', 'Fiable'] as $badge)
                    <span class="border border-[rgb(var(--mt-ui-card-border))] px-3 py-1 text-[0.7rem] tracking-[.2em] uppercase text-[rgb(var(--mt-text))] rounded">
                        {{ $badge }}
                    </span>
                @endforeach
            </div>
            <p class="text-sm text-[rgb(var(--mt-text-muted))] leading-relaxed max-w-sm">
                Accédez à votre espace de travail en quelques secondes.
            </p>
        </div>
    </div>

    {{-- Panneau droit — Formulaire --}}
    <div class="flex-1 flex flex-col justify-center p-4">
        <div class="max-w-md w-full">

            <div class="mb-9 space-y-2 opacity-0 lg:translate-x-[28px] animate-[editorialSlideRight_0.45s_0s_ease_forwards]">
                <div class="h-[3px] w-8 bg-[rgb(var(--mt-primary))]"></div>
                <h2 class="text-xl md:text-3xl font-extrabold tracking-tight">Connectez-vous</h2>
            </div>

            <x-mt::auth-session-status class="mb-5 text-sm opacity-0 translate-x-[28px] animate-[editorialSlideRight_0.45s_0s_ease_forwards]" :status="session('status')" />

            <form wire:submit="login" class="lg:space-y-7">
                <div class="opacity-0 lg:translate-x-[28px] animate-[editorialSlideRight_0.45s_0.08s_ease_forwards]">
                    <x-mt::form.input
                        wire:model="email" :label="__('E-mail')"
                        type="email" required autofocus
                        autocomplete="email" placeholder="vous@domaine.com"
                    :error="$errors->first('email')"
                    />
                </div>

                <div class="space-y-1 mt-3 opacity-0 lg:translate-x-[28px] animate-[editorialSlideRight_0.45s_0.16s_ease_forwards]">
                    <x-mt::form.input
                        wire:model="password" :label="__('Mot de passe')"
                        type="password" required
                        autocomplete="current-password" placeholder="••••••••" viewable
                        :error="$errors->first('password')"
                    />
                    @if($hasPasswordReset)
                        <div class="flex justify-end mt-2">
                            <a href="{{ route('password.request') }}" wire:navigate
                               class="text-xs text-[rgb(var(--mt-text-muted))] transition-[var(--mt-transition)]">
                                Oublié →
                            </a>
                        </div>
                    @endif
                </div>

                @if($hasRememberMe)
                <div class="opacity-0 lg:translate-x-[28px] animate-[editorialSlideRight_0.45s_0.16s_ease_forwards]">
                    <x-mt::form.toggle wire:model="remember" :label="__('Rester connecté')" />
                </div>
                @endif

                <div class="opacity-0 mt-4 lg:translate-x-[28px] animate-[editorialSlideRight_0.45s_0.24s_ease_forwards]">
                    <x-mt::button variant="primary" type="submit" endIcon="chevron-right"
                        loading="login" data-test="login-button" class="w-full py-4 px-6 hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[4px_4px_0_rgba(var(--mt-text),0.18)] active:translate-x-0 active:translate-y-0 active:shadow-none transition-all">
                        {{ mt_translate('login') }}
                    </x-mt::button>
                </div>
            </form>

            @if($hasRegister || $hasHome)
            <div class="border-t border-[rgb(var(--mt-ui-card-border))] mt-8 pt-5 opacity-0 lg:translate-x-[28px] animate-[editorialSlideRight_0.45s_0.24s_ease_forwards]">
                <div class="space-y-1 lg:space-y-3">
                    @if($hasRegister)
                        <div class="flex items-center justify-start lg:justify-between">
                            <span class="text-sm text-[rgb(var(--mt-text-muted))]">Pas de compte ?</span>
                            <a href="{{ route('register') }}" wire:navigate
                               class="text-[rgb(var(--mt-primary))] text-xs font-bold transition-[var(--mt-transition)] ml-3">
                                Créer →
                            </a>
                        </div>
                    @endif
                    @if($hasHome)
                        <div class="flex items-center justify-start lg:justify-between">
                            <span class="text-sm text-[rgb(var(--mt-text-muted))]">Accueil</span>
                            <a href="{{ route('home') }}" wire:navigate
                               class="text-[rgb(var(--mt-primary))] text-xs font-bold transition-[var(--mt-transition)] ml-3">
                                {{ mt_config('app_name') }} →
                            </a>
                        </div>
                    @endif
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

@push('styles')
<style>
@keyframes editorialSlideLeft {
    from { opacity: 0; transform: translateX(-28px); }
    to { opacity: 1; transform: translateX(0); }
}
@keyframes editorialSlideRight {
    from { opacity: 0; transform: translateX(28px); }
    to { opacity: 1; transform: translateX(0); }
}
</style>
@endpush
@break


{{-- Fallback → luxury --}}
@default
    @php $variant = 'luxury'; @endphp
    @include('mt::livewire.auth.login')
@endswitch