{{-- 
    Vue de test globale : Création de Profil Utilisateur 
    Lieu : resources/views/livewire/user-wizard.blade.php
--}}

<div class="max-w-5xl px-4 py-10 mx-auto sm:px-6 lg:px-8" x-data="{ step: @entangle('step') }">
    
    {{-- Système de Notifications (Toaster) --}}
    <x-mt::form.toaster />

    {{-- En-tête de la Page --}}
    <div class="flex items-center justify-between mb-10">
        <div>
            <h1 class="text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white">Configuration du Compte</h1>
            <p class="mt-2 text-gray-600 dark:text-zinc-400">Complétez les étapes pour activer votre espace professionnel.</p>
        </div>
        <x-mt::form.badge variant="info" dot>Version 2.0</x-mt::form.badge>
    </div>

    {{-- 1. Le Stepper --}}
    <div class="mb-12">
        <x-mt::form.stepper :current="$step" :steps="['Identité', 'Préférences', 'Documents', 'Récapitulatif']" />
    </div>

    <div class="grid grid-cols-1 gap-8 lg:grid-cols-3">
        
        {{-- Colonne de gauche : Formulaire Principal --}}
        <div class="space-y-8 lg:col-span-2">
            
            <form wire:submit.prevent="submit" class="p-8 bg-white border border-gray-100 shadow-sm dark:bg-zinc-900 dark:border-zinc-800 rounded-3xl">
                
                {{-- ÉTAPE 1 : Identité --}}
                <x-mt::form.step :step="1" :current="$step">
                    <x-mt::form.fieldset legend="Informations de base" icon="fa-solid fa-id-card">
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                            <x-mt::form.input label="Prénom" model="form.firstname" placeholder="Jean" icon="fa-solid fa-user" required />
                            <x-mt::form.input label="Nom" model="form.lastname" placeholder="Dupont" />
                        </div>
                        <x-mt::form.input label="Email" type="email" model="form.email" icon="fa-solid fa-envelope" help="Utilisé pour la récupération de mot de passe." :error="$errors->first('form.email')" />
                    </x-mt::form.fieldset>

                    <x-mt::form.fieldset legend="Localisation" icon="fa-solid fa-map-marker-alt">
                        <x-mt::form.combobox 
                            label="Pays de résidence" 
                            model="form.country_id" 
                            :options="$countries" 
                            placeholder="Sélectionnez un pays..."
                        />
                    </x-mt::form.fieldset>
                </x-mt::form.step>

                {{-- ÉTAPE 2 : Préférences --}}
                <x-mt::form.step :step="2" :current="$step">
                    <x-mt::form.radio-group 
                        label="Type de compte" 
                        model="form.type" 
                        :options="[
                            'starter' => ['title' => 'Starter', 'description' => 'Idéal pour débuter seul.', 'icon' => 'fa-solid fa-seedling'],
                            'pro' => ['title' => 'Professionnel', 'description' => 'Pour les équipes en croissance.', 'icon' => 'fa-solid fa-rocket'],
                        ]"
                    />

                    <x-mt::form.checkgroup 
                        label="Centres d'intérêt" 
                        model="form.interests" 
                        :options="['tech' => 'Technologie', 'design' => 'Design UX', 'marketing' => 'Marketing']"
                    />

                    <x-mt::form.toggle label="Recevoir la newsletter hebdomadaire" model="form.newsletter" help="Vous pouvez vous désabonner à tout moment." />
                </x-mt::form.step>

                {{-- ÉTAPE 3 : Documents --}}
                <x-mt::form.step :step="3" :current="$step">
                    <x-mt::form.file-upload 
                        label="Photo de profil" 
                        model="form.avatar" 
                        accept="image/*" 
                        help="Format carré recommandé (JPG, PNG)."
                    />
                    
                    <x-mt::form.input-picker 
                        label="Couleur de marque" 
                        model="form.brand_color" 
                        icon="fa-solid fa-eye-dropper" 
                        suggestAction="generateColor"
                    >
                        @foreach(['#3b82f6', '#10b981', '#f59e0b', '#ef4444'] as $color)
                            <button type="button" class="w-8 h-8 rounded-full" style="background: {{ $color }}" @click="$wire.set('form.brand_color', '{{ $color }}'); open = false;"></button>
                        @endforeach
                    </x-mt::form.input-picker>
                </x-mt::form.step>

                {{-- ÉTAPE 4 : Récapitulatif --}}
                <x-mt::form.step :step="4" :current="$step">
                    @if(empty($form['firstname']))
                        <x-mt::empty-state 
                            title="Aucune donnée saisie" 
                            description="Veuillez retourner à l'étape 1 pour remplir vos informations."
                            icon="fa-solid fa-clipboard-list"
                        />
                    @else
                        <div class="space-y-4">
                            <h4 class="font-bold dark:text-white">Vérification finale</h4>
                            <x-mt::form.table>
                                <x-slot name="head">
                                    <th>Champ</th>
                                    <th>Valeur</th>
                                </x-slot>
                                <tr>
                                    <td class="text-gray-500">Nom Complet</td>
                                    <td class="font-medium dark:text-zinc-300">{{ $form['firstname'] }} {{ $form['lastname'] }}</td>
                                </tr>
                                <tr>
                                    <td class="text-gray-500">Type</td>
                                    <td><x-mt::form.badge variant="success">{{ $form['type'] }}</x-mt::form.badge></td>
                                </tr>
                            </x-mt::form.table>
                        </div>
                    @endif
                </x-mt::form.step>

                {{-- Navigation du Formulaire --}}
                <div class="flex justify-between pt-8 mt-10 border-t border-gray-100 dark:border-zinc-800">
                    <x-mt::button variant="secondary" wire:click="previousStep" :disabled="$step === 1">
                        Précédent
                    </x-mt::button>

                    @if($step < 4)
                        <x-mt::button wire:click="nextStep">
                            Suivant <i class="ml-2 fa-solid fa-arrow-right"></i>
                        </x-mt::button>
                    @else
                        <x-mt::button variant="primary" type="submit" loading="submit">
                            Enregistrer le Profil
                        </x-mt::button>
                    @endif
                </div>
            </form>
        </div>

        {{-- Colonne de droite : Aide & Modale --}}
        <div class="space-y-6">
            <div class="p-6 text-white shadow-xl bg-primary-600 rounded-3xl shadow-primary-200 dark:shadow-none">
                <h3 class="mb-2 text-lg font-bold">Besoin d'aide ?</h3>
                <p class="mb-4 text-sm text-primary-100">Consultez notre guide de configuration pour optimiser votre profil.</p>
                <x-mt::button variant="secondary" size="sm" class="w-full" @click="$dispatch('open-modal', 'help-guide')">
                    Lire le guide
                </x-mt::button>
            </div>

            <x-mt::form.fieldset legend="Actions rapides">
                <x-mt::button variant="ghost" class="justify-start w-full" icon="fa-solid fa-share-nodes">Partager</x-mt::button>
                <x-mt::button variant="ghost" class="justify-start w-full text-red-500" icon="fa-solid fa-trash">Réinitialiser</x-mt::button>
            </x-mt::form.fieldset>
        </div>
    </div>

    {{-- Modale d'aide --}}
    <x-mt::modal name="help-guide" title="Guide de Configuration">
        <div class="space-y-4 dark:text-zinc-300">
            <p>Voici comment configurer votre compte mt-views :</p>
            <ul class="ml-5 space-y-2 list-disc">
                <li>Utilisez une adresse email professionnelle.</li>
                <li>La photo de profil aide à l'identification.</li>
                <li>Le type de compte peut être changé plus tard.</li>
            </ul>
        </div>
        <x-slot name="footer">
            <x-mt::button variant="primary" @click="open = false">J'ai compris</x-mt::button>
        </x-slot>
    </x-mt::modal>
</div>