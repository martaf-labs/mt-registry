<script src="{{ asset('vendor/mt/mt-views/tinymce/tinymce.min.js') }}" referrerpolicy="origin" crossorigin="anonymous" defer></script>
{{-- <script>
    document.addEventListener("livewire:navigated", initTinyMCE);
    document.addEventListener("DOMContentLoaded", initTinyMCE);

    function initTinyMCE() {
        document.querySelectorAll('.tinymce-editor').forEach((textarea) => {

            // Évite double initialisation
            if (tinymce.get(textarea.id)) {
                tinymce.get(textarea.id).remove();
            }

            // Récupère l'attribut wire:model*
            const modelAttr = Array.from(textarea.attributes).find(a => a.name.startsWith('wire:model'));
            const modelName = modelAttr ? modelAttr.value : null;

            // Trouver l’ID du composant Livewire parent
            const lwRoot = textarea.closest('[wire\\:id]') || textarea.closest('[wire:id]');
            const componentId = lwRoot ? lwRoot.getAttribute('wire:id') : null;

            tinymce.init({
                selector: `#${textarea.id}`,
                plugins: '{{ $itemPlugins ?? "link preview fullscreen" }}',
                license_key: 'gpl',
                toolbar: 'undo redo | link image | preview fullscreen',
                menubar: false,

                setup(editor) {
                    const pushToLivewire = () => {
                        if (componentId && modelName) {
                            Livewire.find(componentId).set(modelName, editor.getContent());
                        }
                    };

                    editor.on('keyup change input undo redo', pushToLivewire);
                    editor.on('blur', pushToLivewire);
                },

                image_caption: true,
                image_uploadtab: true,
                image_dimensions: false,
                image_title: true,
                images_file_types: 'jpeg,png,jpg,gif,webp,svg',
                image_class_list: [
                    { title: 'Responsive', value: 'img-fluid' },
                ],

                content_style: `
                    img.responsive-img {
                        max-width: 100% !important;
                        height: auto !important;
                        display: block !important;
                    }
                `,

                file_picker_callback: function (callback, value, meta) {
                    if (meta.filetype === 'image') {
                        const input = document.createElement('input');
                        input.type = 'file';
                        input.accept = 'image/*';

                        input.onchange = function () {
                            const file = this.files[0];
                            const reader = new FileReader();

                            reader.onload = function () {
                                const id = 'blobid' + (new Date()).getTime();
                                const blobCache = tinymce.activeEditor.editorUpload.blobCache;
                                const blobInfo = blobCache.create(id, file, reader.result.split(',')[1]);
                                blobCache.add(blobInfo);
                                callback(blobInfo.blobUri(), { title: file.name });
                            };

                            reader.readAsDataURL(file);
                        };

                        input.click();
                    }
                }
            });
        });
    }
</script> --}}
