<?php

namespace Mt\MtViews\Services;

use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class ReferenceGeneratorService
{
    public function generateReference($model, ?string $prefix = null): string
    {
        return DB::transaction(function () use ($model, $prefix) {
            // Générer le préfixe automatiquement si non fourni
            $finalPrefix = $prefix ?? $this->generatePrefixFromModel($model);
            
            $currentYear = Carbon::now()->year;
            // $currentYear = 2024;
            $nextYear = $currentYear + 1;
            $basePrefix = "{$finalPrefix}-{$currentYear}-{$nextYear}";
            
            // Chercher la dernière référence avec verrouillage
            $lastReference = $model::where('reference', 'like', "{$basePrefix}-%")
                ->orderByDesc('reference')
                ->lockForUpdate()
                ->value('reference');
            
            if ($lastReference && preg_match('/-(\d+)$/', $lastReference, $matches)) {
                $nextNumber = (int) $matches[1] + 1;
            } else {
                $nextNumber = 1;
            }
            
            return sprintf("%s-%05d", $basePrefix, $nextNumber);
        });
    }
    
    public function generateCustomReference(
        string $pattern, 
        array $variables = [], 
        int $incrementLength = 5
    ): string {
        return DB::transaction(function () use ($pattern, $variables, $incrementLength) {
            // Remplacer les variables dans le pattern
            $baseReference = $this->replacePatternVariables($pattern, $variables);
            
            // Chercher la dernière référence correspondante
            $lastReference = DB::table('references_sequence')
                ->where('pattern', $pattern)
                ->where('base_reference', $baseReference)
                ->lockForUpdate()
                ->value('last_reference');
            
            if ($lastReference && preg_match('/-(\d+)$/', $lastReference, $matches)) {
                $nextNumber = (int) $matches[1] + 1;
            } else {
                $nextNumber = 1;
            }
            
            $newReference = sprintf("%s-%0{$incrementLength}d", $baseReference, $nextNumber);
            
            // Mettre à jour ou créer la séquence
            DB::table('references_sequence')
                ->updateOrInsert(
                    ['pattern' => $pattern, 'base_reference' => $baseReference],
                    ['last_reference' => $newReference, 'last_used_at' => now()]
                );
            
            return $newReference;
        });
    }
    
    private function generatePrefixFromModel($model): string
    {
        // Extraire le nom de classe sans namespace
        $className = class_basename($model);
        
        // Prendre les 4 premières lettres en majuscules
        $prefix = strtoupper(substr($className, 0, 4));
        
        // Si le nom est trop court, compléter avec des X
        if (strlen($prefix) < 4) {
            $prefix = str_pad($prefix, 4, 'X', STR_PAD_RIGHT);
        }
        
        return $prefix;
    }
    
    private function replacePatternVariables(string $pattern, array $variables): string
    {
        foreach ($variables as $key => $value) {
            $pattern = str_replace("{{$key}}", $value, $pattern);
        }
        
        return $pattern;
    }
}