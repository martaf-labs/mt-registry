<?php

namespace Mt\MtViews\Services;

use Mt\MtViews\Models\BaseUser;
use Mt\MtViews\Contracts\UserModelContract;

class UserService
{
    public function __construct(
        protected UserModelContract $users
    ) {}

    protected function model(): string
    {
        return $this->users->model();
    }
    
    /**
     * Création d'un utilisateur via le modèle concret du projet
     */
    public function create(array $attributes): BaseUser
    {
        $modelClass = $this->model();

        /** @var BaseUser $user */
        $user = $modelClass::query()->create($attributes);

        return $user;
    }
    
    /**
     * Met à jour un utilisateur existant
     */
    public function update(int $id, array $attributes): BaseUser
    {
        $modelClass = $this->model();

        /** @var BaseUser|null $user */
        $user = $modelClass::query()->find($id);

        if (! $user) {
            throw new \RuntimeException("User #{$id} not found");
        }

        $user->fill($attributes);
        $user->save();

        return $user;
    }

    public function findUser(int $id) : ?BaseUser
    {
        $model = $this->users->model();

        return $model::query()->find($id);
    }

    public function count(): int
    {
        $model = $this->users->model();

        return $model::query()->count();
    }
    public function get()
    {
        $model = $this->users->model();

        return $model::query()->get();
    }

    /**
     * Permet de récupérer le builder Eloquent du model Image
     */
    public function query(): \Illuminate\Database\Eloquent\Builder
    {
        return $this->model()::query();

    }

}