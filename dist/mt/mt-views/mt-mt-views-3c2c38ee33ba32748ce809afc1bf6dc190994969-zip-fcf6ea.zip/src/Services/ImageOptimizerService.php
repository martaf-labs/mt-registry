<?php

namespace Mt\MtViews\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver as GdDriver;
use Intervention\Image\Drivers\Imagick\Driver as ImagickDriver;
use Mt\MtViews\Contracts\ImageOptimizerContract;
use Mt\MtViews\DTOs\ImageOptimizationResult;
use Mt\MtViews\Jobs\OptimizeImageJob;

class ImageOptimizerService implements ImageOptimizerContract
{
    protected ImageManager $manager;
    protected array $cfg;

    public function __construct(array $config = [])
    {
        $this->cfg = array_merge($this->defaults(), $config);

        // ✅ Intervention Image 3 : utiliser withDriver() (méthode statique recommandée)
        $this->manager = extension_loaded('imagick')
            ? ImageManager::withDriver(new ImagickDriver())
            : ImageManager::withDriver(new GdDriver());
    }

    // =========================================================================
    // Interface publique
    // =========================================================================

    public function optimizeUpload(UploadedFile $file, array $options = []): ImageOptimizationResult
    {
        $tmpRelPath = $file->store('tmp/mt-optimizer', 'local');
        // $tmpAbsPath = storage_path("app/{$tmpRelPath}");
        $tmpAbsPath = Storage::disk('local')->path($tmpRelPath);

        // verification de sécurité
        if (!file_exists($tmpAbsPath)) {
            return new ImageOptimizationResult(
                success:           false,
                original_path:     $tmpAbsPath,
                storage_path:      '',
                original_size:     0,
                optimized_size:    0,
                savings_percent:   0,
                error:             "Fichier temporaire introuvable : {$tmpAbsPath}",
            );
        }

        $result = $this->optimizePath($tmpAbsPath, array_merge($options, [
            '_original_name' => pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME),
            '_extension'     => strtolower($file->getClientOriginalExtension()),
        ]));

        @unlink($tmpAbsPath);

        return $result;
    }

    public function optimizePath(string $absolutePath, array $options = []): ImageOptimizationResult
    {
        try {
            $opts         = array_merge($this->cfg, $options);
            $originalSize = filesize($absolutePath);

            // ✅ read() est la méthode correcte en v3
            $image = $this->manager->read($absolutePath);

            // Redimensionnement
            if (!empty($opts['max_width']) || !empty($opts['max_height'])) {
                $image->scaleDown($opts['max_width'] ?? null, $opts['max_height'] ?? null);
            }

            // Watermark
            if (!empty($opts['watermark']['enabled']) && !empty($opts['watermark']['path'])) {
                $this->applyWatermark($image, $opts['watermark']);
            }

            $outputDirectory    = $opts['output_directory'] ?? 'images/optimized';
            $baseName    = $opts['_original_name'] ?? pathinfo($absolutePath, PATHINFO_FILENAME);
            $ext         = $opts['_extension']     ?? strtolower(pathinfo($absolutePath, PATHINFO_EXTENSION));
            $disk        = Storage::disk($opts['disk']);
            $storagePath = trim($outputDirectory, '/') . '/' . $baseName . '.' . $ext;

            $disk->put($storagePath, $this->encodeByExt($image, $ext, $opts));

            $optimizedSize = $disk->size($storagePath);

            // Optimiseurs système (optionnel — nécessite spatie/image-optimizer)
            $this->runSystemOptimizers($disk->path($storagePath));
            $optimizedSize = $disk->size($storagePath);

            $variants = $this->generateVariants($storagePath, $opts);

            $savings = $originalSize > 0
                ? (($originalSize - $optimizedSize) / $originalSize) * 100
                : 0;

            $this->log("Optimisé : {$baseName}.{$ext} → économie " . round($savings, 1) . '%');

            return new ImageOptimizationResult(
                success:        true,
                originalPath:   $absolutePath,
                storagePath:    $storagePath,
                originalSize:   $originalSize,
                optimizedSize:  $optimizedSize,
                savingsPercent: $savings,
                variants:       $variants,
                metadata: [
                    'width'  => $image->width(),
                    'height' => $image->height(),
                    'driver' => extension_loaded('imagick') ? 'imagick' : 'gd',
                ],
            );

        } catch (\Throwable $e) {
            $this->log("Erreur : {$e->getMessage()}", 'error');

            return new ImageOptimizationResult(
                success:        false,
                originalPath:   $absolutePath,
                storagePath:    '',
                originalSize:   0,
                optimizedSize:  0,
                savingsPercent: 0,
                error:          $e->getMessage(),
            );
        }
    }

    public function generateVariants(string $storagePath, array $options = []): array
    {
        $opts     = array_merge($this->cfg, $options);
        $disk     = Storage::disk($opts['disk']);
        $image    = $this->manager->read($disk->path($storagePath));
        $baseName = pathinfo($storagePath, PATHINFO_FILENAME);
        $ext      = strtolower(pathinfo($storagePath, PATHINFO_EXTENSION));
        $dir      = $opts['output_directory'];
        $variants = [];

        foreach ($opts['variants'] as $name => $maxWidth) {
            // ✅ En v3, cloner une image se fait via read() sur le même fichier
            $variant = $this->manager->read($disk->path($storagePath));
            $variant->scaleDown($maxWidth);

            $variantPath = "{$dir}/{$baseName}_{$name}.{$ext}";
            $disk->put($variantPath, $this->encodeByExt($variant, $ext, $opts));
            $variants[$name] = $variantPath;

            if (!empty($opts['convert_to_webp'])) {
                $webpPath = "{$dir}/{$baseName}_{$name}.webp";
                // ✅ toWebp() retourne un objet Encoded, cast en string
                $disk->put($webpPath, (string) $variant->toWebp($opts['quality']['webp']));
                $variants["{$name}_webp"] = $webpPath;
            }
        }

        if (!empty($opts['convert_to_webp'])) {
            $webpPath = "{$dir}/{$baseName}.webp";
            $mainImage = $this->manager->read($disk->path($storagePath));
            $disk->put($webpPath, (string) $mainImage->toWebp($opts['quality']['webp']));
            $variants['webp'] = $webpPath;
        }

        if (!empty($opts['convert_to_avif']) && extension_loaded('imagick')) {
            try {
                $avifPath  = "{$dir}/{$baseName}.avif";
                $mainImage = $this->manager->read($disk->path($storagePath));
                $disk->put($avifPath, (string) $mainImage->toAvif($opts['quality']['avif']));
                $variants['avif'] = $avifPath;
            } catch (\Throwable) { /* AVIF non supporté sur ce serveur */ }
        }

        return $variants;
    }

    public function delete(string $storagePath): bool
    {
        $disk     = Storage::disk($this->cfg['disk']);
        $dir      = $this->cfg['output_directory'];
        $baseName = pathinfo($storagePath, PATHINFO_FILENAME);

        $disk->delete($storagePath);

        foreach ($disk->files($dir) as $file) {
            if (str_starts_with(pathinfo($file, PATHINFO_FILENAME), $baseName)) {
                $disk->delete($file);
            }
        }

        return true;
    }

    // =========================================================================
    // Helpers privés
    // =========================================================================

    private function encodeByExt($image, string $ext, array $opts): string
    {
        return match ($ext) {
            'jpg', 'jpeg' => (string) $image->toJpeg($opts['quality']['jpg']),
            'png'         => (string) $image->toPng(),
            'webp'        => (string) $image->toWebp($opts['quality']['webp']),
            'gif'         => (string) $image->toGif(),
            default       => (string) $image->toJpeg($opts['quality']['jpg']),
        };
    }

    private function applyWatermark($image, array $wm): void
    {
        if (!file_exists($wm['path'])) return;

        $watermark = $this->manager->read($wm['path']);
        $watermark->opacity($wm['opacity'] ?? 70);
        $image->place($watermark, $wm['position'] ?? 'bottom-right', $wm['padding'] ?? 10, $wm['padding'] ?? 10);
    }

    private function runSystemOptimizers(string $path): void
    {
        // Nécessite spatie/image-optimizer installé + outils système (jpegoptim, optipng…)
        if (!class_exists(\Spatie\ImageOptimizer\OptimizerChainFactory::class)) return;

        try {
            \Spatie\ImageOptimizer\OptimizerChainFactory::create()->optimize($path);
        } catch (\Throwable) { /* Optionnel */ }
    }

    private function log(string $message, string $level = 'info'): void
    {
        if (empty($this->cfg['logging']['enabled'])) return;
        $channel = $this->cfg['logging']['channel'] ?? 'stack';
        Log::channel($channel)->$level("[mt-views/ImageOptimizer] {$message}");
    }

    private function defaults(): array
    {
        return [
            'disk'             => 'public',
            'output_directory' => 'images/optimized',
            'max_width'        => 2560,
            'max_height'       => 2560,
            'convert_to_webp'  => true,
            'convert_to_avif'  => false,
            'quality'          => ['jpg' => 85, 'png' => 85, 'webp' => 85, 'avif' => 80, 'gif' => 85],
            'variants'         => ['thumbnail' => 150, 'small' => 400, 'medium' => 800, 'large' => 1200],
            'watermark'        => ['enabled' => false, 'path' => null, 'position' => 'bottom-right', 'opacity' => 70, 'padding' => 10],
            'logging'          => ['enabled' => true, 'channel' => 'stack'],
        ];
    }
}