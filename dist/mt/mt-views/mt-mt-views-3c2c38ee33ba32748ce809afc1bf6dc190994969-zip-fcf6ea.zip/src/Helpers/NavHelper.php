<?php

namespace Mt\MtViews\Helpers;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Route;

class NavHelper
{
    protected string $model;
    protected string $mainLabel;
    protected array $navItems = [];

    public function __construct(string $model, string $mainLabel)
    {
        $this->model = $model;
        $this->mainLabel = ucfirst($mainLabel);
        
        $this->navItems['index'] = [
            'label' => ucfirst($mainLabel),
            'icone' => get_icone($model),
            'lien'  => Route::has('admin.'.Str::plural($model).'.index') ? mt_get_route(Str::plural($model)) : '#',
        ];
    }

    public function add(string $label, string $route): self
    {
        $cle=Str::random(5);
        $this->navItems[$cle] = [
            'label' => $label,
            'lien' => $route,
        ];
        return $this;
    }

    public function get(): array
    {
        return $this->navItems;
    }
}
