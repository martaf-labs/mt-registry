<?php

namespace Mt\MtViews\Helpers;

use Illuminate\View\View;
use Illuminate\Support\Str;

class ViewHelper
{
    protected string $model;
    protected string $viewSessionKey;
    protected string $mainLabel;
    protected array $viewItems = [];

    public function __construct(string $model, string $mainLabel)
    {
        $this->model = $model;
        $this->viewSessionKey = "viewsSession.{$model}";
        $this->mainLabel = Str::ucfirst($mainLabel);
    }

    public function get($viewName,$viewDatas):View
    {
        //tentative de reinitialisation de la session du formulaire
        if (!in_array($viewName, ['create', 'edit'])) {
            $formSession="formSessionData";
            session()->forget([$formSession]);
        }
        
        $issetViewNavItems=in_array('navItems',array_keys($viewDatas)) ? true : false; //verifier si un navitems est deja fournit au niveau de la vue
        $navItems = $issetViewNavItems? $viewDatas['navItems'] : navItems($this->model, Str::ucfirst($this->mainLabel));
        //configuration de la vue
        switch ($viewName) {
            case 'index':
                
                $this->viewItems=[
                    'titre'=>$viewDatas['titre']?? $this->mainLabel,
                    'navItems'=>is_array($navItems) ? $navItems : $navItems->get(),
                    'datas'=>$viewDatas['datas']?? null,
                    'filtres'=>$viewDatas['filtres']?? null,
                    'datafiltres'=>$viewDatas['datafiltres']?? null,
                    'filterOptions'=>$viewDatas['filterOptions']?? null,
                    'displayView'=>$viewDatas['displayView']?? null,
                ];
                
                break;
                
            case 'create':

                $this->viewItems=[
                    'titre'=>$viewDatas['titre']?? "Ajouter ".Str::lower(Str::singular($this->mainLabel)),
                    'navItems'=>$issetViewNavItems ? $navItems : $navItems->add('Nouveau','#')->get(),
                    'data'=>$viewDatas['data']?? null,
                    'formDatas'=>$viewDatas['formDatas']?? null,
                ];
                
                break;
                
            case 'show':

                $this->viewItems=[
                    'titre'=>$viewDatas['titre']?? "show ".Str::lower(Str::singular($this->mainLabel)),
                    'navItems'=>is_array($navItems) ? $navItems : $navItems->add($viewDatas['dataLabel'],'#')->get(),
                    'data'=>$viewDatas['data']?? null,
                ];
                
                break;
                
            case 'details':

                $this->viewItems=[
                    'titre'=>$viewDatas['titre']?? "Détails ".Str::lower(Str::singular($this->mainLabel)),
                    'navItems'=>is_array($navItems) ? $navItems : $navItems->add($viewDatas['dataLabel'],'#')->get(),
                    'data'=>$viewDatas['data']?? null,
                ];
                
                break;
                
            case 'edit':
                
                $this->viewItems=[
                    'titre'=>$viewDatas['titre']?? "Modifier ".Str::lower(Str::singular($this->mainLabel)),
                    'navItems'=>is_array($navItems) ? $navItems : ($navItems->add($viewDatas['dataLabel'],'#')->add('Modifier','#')->get()),
                    'data'=>$viewDatas['data']?? null,
                    'formDatas'=>$viewDatas['formDatas']?? null,
                ];
                
                break;
        }
        //fusion avec les donnees par defauts
        $defaultViewItems=array_filter([
            'model'=>$this->model,
            'mode'=>$viewName,
            'params'=>$viewDatas['params'] ?? null,
            'dataLabel'=>$viewDatas['dataLabel']?? '',
            'addButton'=>$viewDatas['addButton']?? false,
            'editButton'=>$viewDatas['editButton']?? false,
            'buttonRoute'=>$viewDatas['buttonRoute']?? false,
            'buttonLabel'=>$viewDatas['buttonLabel']?? null,
        ]);
        $mergedViewItems=array_merge($defaultViewItems, $this->viewItems);
        $allViewItems=array_merge(['viewDatas'=>$mergedViewItems],$mergedViewItems); //pour capturer tous les parametres de la vue;

        return view('mt::admin.pages.'.$viewName, $allViewItems);
    }
}
