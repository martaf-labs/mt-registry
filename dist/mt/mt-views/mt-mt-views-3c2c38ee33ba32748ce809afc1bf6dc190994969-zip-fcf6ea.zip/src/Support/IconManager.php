<?php

namespace Mt\MtViews\Support;

class IconManager
{
    protected static ?array $icons = null;

    /**
     * Récupère la liste des icônes (sans extension), sans scanner le disque à chaque fois grace au cache laravel
     */
    public static function all(): array
    {
        return cache()->remember('mt_icons_list', 3600, function () {

            $path = self::getIconsPath();

            if (!is_dir($path)) {
                return [];
            }

            $files = glob($path . '/*.svg');

            return array_map(fn($file) => pathinfo($file, PATHINFO_FILENAME), $files);
        });
    }

    /**
     * Vérifie si une icône existe
     */
    public static function exists(string $name): bool
    {
        return in_array($name, self::all());
    }
    

    /**
     * Retourne le chemin des icônes
     */
    protected static function getIconsPath(): string
    {
        // chemin dans ton package
        return __DIR__ . '/../../resources/views/icons';
    }
}