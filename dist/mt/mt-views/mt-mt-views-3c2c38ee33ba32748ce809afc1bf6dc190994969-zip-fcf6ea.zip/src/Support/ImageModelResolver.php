<?php

namespace Mt\MtViews\Support;

use Mt\MtViews\Contracts\ImageModelContract;
use Mt\MtViews\Models\BaseImage;

class ImageModelResolver implements ImageModelContract
{
    public function model() : string
    {

        /** @var class-string $model */

        $model = config('mt-views.providers.images.model');
        
        // on retire le "::class" s'il n'est pas écrit par erreur
        $model = str_ends_with($model, '::class') ? substr($model, 0, -7) : $model;

        if (!is_subclass_of($model, BaseImage::class)) {
            throw new \RuntimeException(
                "Le model Image doit être étendu ". BaseImage::class
            );
        }

        return $model;
    }
}