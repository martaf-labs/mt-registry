<?php

namespace Mt\MtViews\Http\Controllers;

abstract class Controller
{
    //
}
