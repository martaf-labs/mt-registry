<?php

namespace Mt\MtViews\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ImageUploadController extends Controller
{
    public function upload(Request $request)
    {
        if ($request->hasFile('file')) {
            // Sauvegarde dans storage/app/public/uploads
            $path = $request->file('file')->store('uploads', mt_get_storage_disk());
            
            // Retourne l'URL pour TinyMCE
            return response()->json(['location' => Storage::url($path)]);
        }

        return response()->json(['error' => 'Upload échoué'], 500);
    }
}