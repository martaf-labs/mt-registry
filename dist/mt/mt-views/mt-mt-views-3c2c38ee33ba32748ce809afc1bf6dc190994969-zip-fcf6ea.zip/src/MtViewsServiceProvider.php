<?php

namespace Mt\MtViews;

use Livewire\Livewire;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Relations\Relation;
use Mt\MtViews\Contracts\ImageOptimizerContract;
use Mt\MtViews\Services\ImageOptimizerService;
use Mt\MtViews\Services\ReferenceGeneratorService;

class MtViewsServiceProvider extends ServiceProvider
{
    protected string $basePath;

    public function __construct($app)
    {
        parent::__construct($app);
        $this->basePath = dirname(__DIR__);
    }

    public function register(): void
    {
        $configPath = $this->basePath . '/config';

        // Fusion des configurations
        if (file_exists($configPath)) {
            $this->mergeConfigFrom($configPath.'/mt-views.php', 'mt-views');
            $this->mergeConfigFrom($configPath.'/mt-search.php', 'mt-search');
        }

        // Singletons
        $this->app->singleton(\Mt\MtViews\Contracts\UserModelContract::class, \Mt\MtViews\Support\UserModelResolver::class);
        $this->app->singleton(\Mt\MtViews\Contracts\ImageModelContract::class, \Mt\MtViews\Support\ImageModelResolver::class);
        $this->app->singleton(\Mt\MtViews\Helpers\MtLocale::class);

        $this->app->singleton(ImageOptimizerContract::class, function ($app) {
            return new ImageOptimizerService($app['config']['mt-views.image_optimizer'] ?? []);
        });

        $this->app->singleton(ReferenceGeneratorService::class, fn() => new ReferenceGeneratorService());
    }

    public function boot(): void
    {
        $viewsPath = $this->basePath . '/resources/views';
        $langPath  = $this->basePath . '/lang';

        // 1. ROUTES
        $this->loadRoutesFrom($this->basePath .'/routes/search.php');
        $this->loadRoutesFrom($this->basePath .'/routes/web.php');

        // 2. MIDDLEWARES
        $this->app['router']->aliasMiddleware('mt.layout', \Mt\Views\Http\Middleware\SetActiveLayoutMiddleware::class);
        
        $this->app->booted(function (){
            $kernel = $this->app->make(\Illuminate\Contracts\Http\Kernel::class);
            $kernel->appendMiddlewareToGroup('web', \Mt\MtViews\Http\Middleware\SetMtLocale::class);
        });

        // 1. Enregistre le namespace pour @include('mt::...') et les composants de classe
        $this->loadViewsFrom($viewsPath, 'mt');

        // 2. Enregistre le namespace pour les composants anonymes <x-mt::... />
        if (is_dir($viewsPath . '/components')) {        
            // On utilise 'mt' au lieu de 'mt-components' pour la cohérence
            Blade::anonymousComponentPath($viewsPath . '/components', 'mt');
        }

        // Blade::componentNamespace('Mt\\MtViews\\Views\\Components', 'mt-views');

        // 4. TRADUCTIONS
        $this->loadTranslationsFrom($langPath, 'mt-views');

        // 5. ASSETS & PUBLISHES
        $this->registerPublishing($viewsPath, $langPath);
        $this->registerBladeDirectives();

        // 6. AUTRES SERVICES
        $this->registerLivewireComponents();
        $this->registerDatabaseLogic();
    }

    protected function registerPublishing($viewsPath, $langPath): void
    {
        if ($this->app->runningInConsole()) {
            $this->publishes([$viewsPath => resource_path('views/vendor/mt/mt-views')], 'mt-views');
            $this->publishes([$langPath => $this->app->langPath('vendor/mt/mt-views')], 'mt-views-lang');
            $this->publishes([
                $this->basePath . '/config/mt-views.php' => config_path('mt-views.php'),
                $this->basePath . '/config/mt-search.php' => config_path('mt-search.php')
            ], 'mt-views-config');
        }
    }

    protected function registerBladeDirectives(): void
    {
        Blade::directive('mtAssets', function () {
            $mtIcons = asset('vendor/mt/mt-views/icons/icons.css');
            return "<link rel='stylesheet' href='{$mtIcons}'>";
        });
    }

    protected function registerDatabaseLogic(): void
    {
        if (is_dir($this->basePath . '/database/migrations')) {
            $this->loadMigrationsFrom($this->basePath . '/database/migrations');
        }

        Blueprint::macro('tracksUser', function () {
            $this->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $this->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $this->foreignId('deleted_by')->nullable()->constrained('users')->nullOnDelete();
        });
    }

    protected function registerLivewireComponents(): void
    {
      
        Livewire::component('mt.mt-dashboard', \Mt\MtViews\Livewire\MtDashboard::class);
        Livewire::component('mt.locale-switcher', \Mt\MtViews\Livewire\LocaleSwitcher::class);

        Livewire::component('mt.tests.form-flow', \Mt\MtViews\Livewire\Tests\FormFlow::class);
        Livewire::component('mt.auth.login', \Mt\MtViews\Livewire\Auth\Login::class);
        Livewire::component('mt.auth.register', \Mt\MtViews\Livewire\Auth\Register::class);
        Livewire::component('mt.settings.profile', \Mt\MtViews\Livewire\Settings\Profile::class);
        Livewire::component('mt.settings.appearance', \Mt\MtViews\Livewire\Settings\Appearance::class);
        Livewire::component('mt.settings.delete-user-form', \Mt\MtViews\Livewire\Settings\DeleteUserForm::class);
        Livewire::component('mt.settings.password', \Mt\MtViews\Livewire\Settings\Password::class);
        Livewire::component('mt.settings.two-factor', \Mt\MtViews\Livewire\Settings\TwoFactor::class);
        Livewire::component('mt.dashboard', \Mt\MtViews\Livewire\Dashboard::class);
        Livewire::component('mt.modals.confirm', \Mt\MtViews\Livewire\Modals\Confirm::class);
        Livewire::component('mt.modals.alert', \Mt\MtViews\Livewire\Modals\Alert::class);
        Livewire::component('mt.modals.export', \Mt\MtViews\Livewire\Modals\DataExporterModal::class);
        Livewire::component('mt.forms.image-manager', \Mt\MtViews\Livewire\Forms\ImageManager::class);
        Livewire::component('mt.global-search', \Mt\MtViews\Livewire\Search\GlobalSearch::class);
        Livewire::component('mt.search-results', \Mt\MtViews\Livewire\Search\SearchResults::class);
    }
}
