<?php

namespace Mt\MtViews\Enums;

enum TypesContact: string
{
    case TELEPHONE  = 'telephone';
    case EMAIL      = 'email';
    case WHATSAPP   = 'whatsapp';
    case SITE_WEB   = 'site_web';
    case FAX        = 'fax';
    case FACEBOOK   = 'facebook'; 

    /**
     * Libellé lisible
     * @return string
     */
    public function label() : string
    {
        return match ($this){
            self::TELEPHONE    => 'Téléphone',
            self::EMAIL        => 'Email',
            self::WHATSAPP     => 'WhatsApp',
            self::SITE_WEB     => 'Site web',
            self::FAX          => 'Fax',
            self::FACEBOOK     => 'Facebook',
        };
    }

    /**
     * Liste clé => label
     * @return array
     */
    public static function options():array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
