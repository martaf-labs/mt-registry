<?php

namespace Mt\MtViews\Enums;

enum TypesImage: string
{
    case PHOTO          = 'photo';
    case CERTIFICAT     = 'certificat';
    case PLAN           = 'plan';

    /**
     * Libellé lisible
     * @return string
     */
    public function label() : string
    {
        return match ($this){
            self::PHOTO         => 'Photo',
            self::CERTIFICAT    => 'Certificat',
            self::PLAN          => 'Plan',
        };
    }

    /**
     * Liste clé => label
     * @return array
     */
    public static function options():array
    {
        return collect(self::cases())
            ->mapWithKeys(fn ($case) => [$case->value => $case->label()])
            ->toArray();
    }
}
