<?php

namespace Mt\MtViews\Livewire\Tests;

use Livewire\Component;
use Livewire\Attribute\Title;
use Livewire\WithFileUploads;
use Mt\MtViews\Livewire\BaseAppComponent;

#[Title("Test Form Flow")]
class FormFlow extends BaseAppComponent
{
    use WithFileUploads;

    // État du formulaire
    public $step = 1;
    public $totalSteps = 4;

    // Données du formulaire 
    public $form = [
        'firstname'    => '',
        'lastname'     => '',
        'email'        => '',
        'country_id'   => null,
        'type'         => 'starter',
        'interests'    => [],
        'newsletter'   => false,
        'avatar'       => null,
        'brand_color'  => '#3b82f6',
    ];

    // Options pour les composants
    public $countries = [
        1 => 'France',
        2 => 'Cameroun',
        3 => 'Belgique',
        4 => 'Canada',
        5 => 'Sénégal'
    ];

    /**
     * Règles de validation par étape
     */
    protected function rules()
    {
        return [
            // Étape 1
            1 => [
                'form.firstname' => 'required|min:2',
                'form.lastname'  => 'required',
                'form.email'     => 'required|email',
                'form.country_id' => 'required',
            ],
            // Étape 2
            2 => [
                'form.type'      => 'required|in:starter,pro',
                'form.interests' => 'required|array|min:1',
            ],
            // Étape 3
            3 => [
                'form.avatar'    => 'nullable|image|max:2048',
            ],
        ][$this->step] ?? [];
    }

    public function nextStep()
    {
        // Valider uniquement les champs de l'étape actuelle
        // $this->validate($this->rules());

        if ($this->step < $this->totalSteps) {
            $this->step++;
        }
    }

    public function previousStep()
    {
        if ($this->step > 1) {
            $this->step--;
        }
    }

    public function generateColor()
    {
        $colors = ['#8b5cf6', '#ec4899', '#f97316', '#06b6d4'];
        $this->form['brand_color'] = $colors[array_rand($colors)];
        
        $this->dispatch('toast', 
            message: 'Couleur magique générée !', 
            type: 'info'
        );
    }

    public function submit()
    {
        // Validation finale de toutes les étapes (optionnel mais sécurisé)
        $this->validate([
            'form.firstname' => 'required',
            'form.email'     => 'required|email',
            'form.type'      => 'required',
        ]);

        // Logique d'enregistrement ici...
        sleep(1); // Simulation réseau

        $this->dispatch('toast', 
            message: 'Votre profil FormFlow a été créé avec succès !', 
            type: 'success'
        );

        return redirect()->to('/dashboard');
    }

    public function render()
    {
        return view('mt::livewire.tests.form-flow');
    }
}