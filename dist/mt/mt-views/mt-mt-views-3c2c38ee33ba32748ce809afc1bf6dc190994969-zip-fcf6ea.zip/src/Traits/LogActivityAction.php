<?php

namespace Mt\MtViews\Traits;

use Illuminate\Support\Str;
use Spatie\Activitylog\LogOptions;


trait LogActivityAction
{
    /**
     * Definir les options de log par défaut pour le modèle
     */

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly($this->getFillable())
            ->useLogName(Str::snake(class_basename($this)))
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }

    public function getDescriptionForEvent(string $eventName): string
    {
        $events = [
            'created' => 'créé',
            'updated' => 'modifié',
            'deleted' => 'supprimé',
        ];
        $action = $events[$eventName] ?? $eventName;
        $modelName = __(Str::headline(class_basename($this)));

        return "{$modelName} " . ($this->id) . " a été {$action}";
    }
}
