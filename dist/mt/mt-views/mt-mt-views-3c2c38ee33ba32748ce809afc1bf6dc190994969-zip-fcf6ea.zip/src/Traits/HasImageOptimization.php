<?php

namespace Mt\MtViews\Traits;

use Illuminate\Support\Facades\Storage;
use Mt\MtViews\Contracts\ImageOptimizerContract;
use Mt\MtViews\Jobs\OptimizeImageJob;

/**
 * Trait à ajouter sur BaseImage (ou tout modèle Eloquent gérant une image).
 *
 * Usage :
 *   class Image extends BaseImage {
 *       use HasImageOptimization;
 *   }
 *
 * Ou directement dans BaseImage pour l'activer globalement sur tous les modèles images.
 */
trait HasImageOptimization
{
    // =========================================================================
    // Hooks Eloquent — optimisation automatique au save
    // =========================================================================

    public static function bootHasImageOptimization(): void
    {
        // Après chaque sauvegarde : si le path a changé → optimiser
        static::saved(function ($model) {
            if ($model->isDirty('path') && !empty($model->path)) {
                $model->triggerOptimization();
            }
        });

        // Suppression : nettoyer les variantes
        static::deleted(function ($model) {
            if (!empty($model->path)) {
                app(ImageOptimizerContract::class)->delete($model->path);
            }
        });
    }

    // =========================================================================
    // Optimisation
    // =========================================================================

    /**
     * Lance l'optimisation (en queue ou immédiatement selon config).
     */
    public function triggerOptimization(array $options = []): void
    {
        $cfg = mt_config('image_optimizer', []);

        if (!empty($cfg['queue']['enabled'])) {
            OptimizeImageJob::dispatch($this->path, $options)
                ->onConnection($cfg['queue']['connection'] ?? null)
                ->onQueue($cfg['queue']['queue_name'] ?? 'default');
        } else {
            $disk     = mt_config('image_optimizer.disk', 'public');
            $fullPath = Storage::disk($disk)->path($this->path);

            if (file_exists($fullPath)) {
                $result = app(ImageOptimizerContract::class)->optimizePath($fullPath, $options);

                // Persister les variantes dans metadata
                if ($result->success && !empty($result->variants)) {
                    $meta = $this->metadata ?? [];
                    $meta['optimizer'] = [
                        'variants'        => $result->variants,
                        'savings_percent' => $result->savingsPercent,
                        'optimized_at'    => now()->toIso8601String(),
                        'width'           => $result->metadata['width']  ?? null,
                        'height'          => $result->metadata['height'] ?? null,
                    ];
                    $this->updateQuietly(['metadata' => $meta]);
                }
            }
        }
    }

    // =========================================================================
    // Accesseurs d'URL
    // =========================================================================

    /**
     * Retourne l'URL de la meilleure version disponible (WebP > optimisé > original).
     * Remplace / enrichit getImageUrlAttribute() déjà présent dans BaseImage.
     */
    public function getOptimizedUrlAttribute(): string
    {
        return $this->getVariantUrl('webp')
            ?? $this->getVariantUrl('large')
            ?? $this->image_url; // fallback sur l'accesseur déjà existant dans BaseImage
    }

    /**
     * Retourne l'URL d'une variante spécifique.
     * $variant : 'webp', 'avif', 'thumbnail', 'small', 'medium', 'large', etc.
     */
    public function getVariantUrl(string $variant): ?string
    {
        $variantPath = $this->metadata['optimizer']['variants'][$variant] ?? null;

        if ($variantPath) {
            $disk = mt_config('image_optimizer.disk', 'public');
            if (Storage::disk($disk)->exists($variantPath)) {
                return Storage::disk($disk)->url($variantPath);
            }
        }

        return null;
    }

    /**
     * Génère le HTML <picture> complet avec srcset WebP/AVIF + fallback.
     * Compatible avec les variantes générées par le service.
     *
     * @param array $attrs Attributs HTML : alt, class, id, etc.
     */
    public function getPictureHtml(array $attrs = []): string
    {
        $disk     = mt_config('image_optimizer.disk', 'public');
        $storage  = Storage::disk($disk);
        $variants = $this->metadata['optimizer']['variants'] ?? [];

        $attrStr = collect($attrs)
            ->map(fn ($v, $k) => "{$k}=\"{$v}\"")
            ->implode(' ');

        // Construire les srcsets à partir des variantes stockées dans metadata
        $responsiveSizes = mt_config('image_optimizer.variants', [
            'thumbnail' => 150, 'small' => 400, 'medium' => 800, 'large' => 1200,
        ]);

        $avifSrcset = $webpSrcset = $imgSrcset = '';

        foreach ($responsiveSizes as $name => $width) {
            if (isset($variants['avif']) && $storage->exists($variants["avif"])) {
                // on n'a qu'un avif principal pour simplifier
            }
            if (isset($variants["{$name}_webp"]) && $storage->exists($variants["{$name}_webp"])) {
                $webpSrcset .= $storage->url($variants["{$name}_webp"]) . " {$width}w, ";
            }
            if (isset($variants[$name]) && $storage->exists($variants[$name])) {
                $imgSrcset .= $storage->url($variants[$name]) . " {$width}w, ";
            }
        }

        // WebP et AVIF globaux
        if (isset($variants['avif']) && $storage->exists($variants['avif'])) {
            $avifSrcset = $storage->url($variants['avif']);
        }
        if (isset($variants['webp']) && $storage->exists($variants['webp'])) {
            $webpSrcset = ($webpSrcset ? rtrim($webpSrcset, ', ') . ', ' : '') . $storage->url($variants['webp']);
        }

        $webpSrcset = rtrim($webpSrcset, ', ');
        $imgSrcset  = rtrim($imgSrcset,  ', ');
        $fallback   = $this->optimized_url;

        $html = '<picture>';
        if ($avifSrcset) {
            $html .= "<source type=\"image/avif\" srcset=\"{$avifSrcset}\">";
        }
        if ($webpSrcset) {
            $html .= "<source type=\"image/webp\" srcset=\"{$webpSrcset}\">";
        }
        $html .= "<img src=\"{$fallback}\"";
        if ($imgSrcset) {
            $html .= " srcset=\"{$imgSrcset}\" sizes=\"(max-width:400px) 400px, (max-width:800px) 800px, 1200px\"";
        }
        $html .= " {$attrStr} loading=\"lazy\">";
        $html .= '</picture>';

        return $html;
    }

    // =========================================================================
    // Infos d'optimisation
    // =========================================================================

    /**
     * Indique si l'image a déjà été optimisée.
     */
    public function isOptimized(): bool
    {
        return !empty($this->metadata['optimizer']['optimized_at']);
    }

    /**
     * Retourne le pourcentage d'économie réalisé lors de l'optimisation.
     */
    public function getSavingsPercent(): float
    {
        return (float) ($this->metadata['optimizer']['savings_percent'] ?? 0.0);
    }

    /**
     * Dimensions de l'image.
     */
    public function getDimensions(): array
    {
        return [
            'width'  => $this->metadata['optimizer']['width']  ?? null,
            'height' => $this->metadata['optimizer']['height'] ?? null,
        ];
    }
}
