<?php

namespace Mt\MtViews\Traits;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

/**
 * Trait TracksUser
 * 
 */
trait TracksUser
{
    public static function bootTracksUser(): void
    {
        static::creating(function ($model) {
            if (Auth::check() && $model->hasColumn('created_by')) {
                $model->created_by = Auth::id();
            }

            //mettre les premiere lettre de mot en majuscule (logique a separer plus tard)
            if ($model->titre) {
                $model->titre = Str::ucfirst($model->titre);
            }
            if ($model->nom) {
                $model->nom = Str::ucfirst($model->nom);
            }
            if ($model->nom_court) {
                $model->nom_court = Str::ucfirst($model->nom_court);
            }
            if ($model->name) {
                $model->name = Str::ucfirst($model->name);
            }
            if ($model->libelle) {
                $model->libelle = Str::ucfirst($model->libelle);
            }
            if ($model->description) {
                $model->description = Str::ucfirst($model->description);
            }

        });

        static::updating(function ($model) {
            if (Auth::check() && $model->hasColumn('updated_by')) {
                $model->updated_by = Auth::id();
            }
            
            //mettre les premiere lettre de mot en majuscule (logique a separer plus tard)
            if ($model->titre) {
                $model->titre = Str::ucfirst($model->titre);
            }
            if ($model->nom) {
                $model->nom = Str::ucfirst($model->nom);
            }
            if ($model->nom_court) {
                $model->nom_court = Str::ucfirst($model->nom_court);
            }
            if ($model->name) {
                $model->name = Str::ucfirst($model->name);
            }
            if ($model->libelle) {
                $model->libelle = Str::ucfirst($model->libelle);
            }
            if ($model->description) {
                $model->description = Str::ucfirst($model->description);
            }
        });

        static::deleting(function ($model) {
            if ($model->isSoftDeleting()) {
                $model->deleted_by = Auth::id();
                $model->save();
            }
        });
    }

    protected function hasColumn(string $column) : bool
    {
        return in_array($column, $this->getConnection()->getSchemaBuilder()->getColumnListing($this->getTable()));        
    }

    // Helper pour savoir si le model utilise softDeletes
    protected function isSoftDeleting()
    {
        return in_array('Illuminate\Database\Eloquent\SoftDeletes', class_uses_recursive($this));
    }
    
}
