<?php

namespace Mt\MtViews\Traits;

trait AttributesFormatter
{
    /**
     * Formater une date pour affichage
     *
     * @param string $attribute
     * @param string $format
     * @return string|null
     */
    public function formatDate(string $attribute, string $format = 'd-m-Y'): ?string
    {
        if (!isset($this->{$attribute}) || !$this->{$attribute}) {
            return null;
        }

        if (is_string($this->{$attribute})) {
            return \Carbon\Carbon::parse($this->{$attribute})->format($format);
        }

        return $this->{$attribute}->format($format);
    }

    /**
     * Formater un montant pour affichage
     *
     * @param string $attribute
     * @param int $decimals
     * @return string|null
     */
    public function formatAmount(string $attribute, int $decimals = 0, $currency = null): ?string
    {
        if (!isset($this->{$attribute}) || $this->{$attribute} === null) {
            return null;
        }

        return number_format($this->{$attribute}, $decimals, ',', ' ').''.($currency? " $currency" : null);
    }
}
