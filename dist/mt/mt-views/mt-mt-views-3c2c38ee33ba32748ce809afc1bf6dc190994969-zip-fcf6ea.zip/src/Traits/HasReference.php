<?php

namespace Mt\MtViews\Traits;

use Illuminate\Support\Facades\App;
use Mt\MtViews\Services\ReferenceGeneratorService;

trait HasReference
{
    public static function bootHasReference(): void
    {
        static::creating(function ($model) {

            if (array_key_exists('reference', $model->getAttributes())) {
                if (empty($model->reference)) {
                    $model->reference = App::make(ReferenceGeneratorService::class)
                        ->generateReference(static::class);
                }
            }
        });
    }
    
    public function generateCustomReference(string $pattern, array $variables = []): string
    {
        return App::make(ReferenceGeneratorService::class)
            ->generateCustomReference($pattern, $variables);
    }
    
    // Méthode pour générer manuellement avec préfixe personnalisé
    public static function generateWithPrefix(?string $prefix = null): string
    {
        return app(ReferenceGeneratorService::class)
            ->generateReference(static::class, $prefix);
    }
}