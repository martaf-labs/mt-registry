<?php

namespace Mt\MtViews\Traits;

use ReflectionMethod;


trait InteractsWithOverrides
{
    /**
     * verifier si une méthode à été définie dans la classe actuelle
     * par rapport à une classe parente spécifique
     */

    protected function methodIsOverriden(string $method, string $baseClass, $childObject=null) : bool
    {
        $child= $childObject ?? $this;

        if (!method_exists($child, $method)) {
            return false;
        }

        $reflection = new ReflectionMethod($child, $method);

        // on verifit si la classe qui déclare la méthode n'est pas la classe de base
         return $reflection->getDeclaringClass()->getName() !== $baseClass;
    }
}