<?php

namespace Mt\MtViews\Traits;

use Illuminate\Support\Facades\App;


trait HasTranslatableCasts
{
    /**
     * Ce trait initialise le trait et fusionne les casts traduisible
     * Laravel appele automatiquement les méthode commençant par "initialize"
     */
    public function initializeHasTranslatableCasts()
    {
        if (isset($this->translatables) && is_array($this->translatables)) {
            $translatableCasts = array_fill_keys($this->translatables, 'array');

            // on fusionne avec les casts restant pour ne rien écraser
            $this->casts = array_merge($this->casts, $translatableCasts);
        }
    }

    /**
     * Intercepte l'accès aux propriété pour retourner la traduction actuelle.
     *
     * @param [type] $key
     * @return void
     */
    public function __get($key)
    {
        if (isset($this->translatables) && in_array($key, $this->translatables)) {
            $value = $this->getAttribute($key);

            return is_array($value) ? ($value[App::getLocale()] ?? null) : $value;
        }

        return parent::__get($key);
    }

}
