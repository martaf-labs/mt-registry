<?php

namespace Mt\MtViews\Contracts;

/**
 * UserModelContract
 * 
 * Indispensable pour la gestion du model User dans le package.
 * Pour eviter par exemple de faire: App/Model/User (car trop dépendant des différent projet) 
 */
interface UserModelContract
{
    public function model() : string ;
}