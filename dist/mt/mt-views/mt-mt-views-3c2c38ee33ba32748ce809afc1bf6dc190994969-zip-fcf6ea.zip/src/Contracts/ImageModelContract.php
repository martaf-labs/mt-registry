<?php

namespace Mt\MtViews\Contracts;

/**
 * ImageModelContract
 * 
 * Indispensable pour la gestion du model Image dans le package.
 * Pour eviter par exemple de faire: App/Model/Image (car trop dépendant des différent projet) 
 */
interface ImageModelContract
{
    public function model() : string ;
}