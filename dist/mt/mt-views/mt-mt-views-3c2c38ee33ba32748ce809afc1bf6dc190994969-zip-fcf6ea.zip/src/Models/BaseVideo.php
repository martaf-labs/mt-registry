<?php

namespace Mt\MtViews\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtViews\Models\MtBaseModel;
use Mt\MtViews\Traits\LogActivityAction;
use Mt\MtViews\Traits\TracksUser;
use Spatie\Activitylog\LogOptions;

abstract class BaseVideo extends MtBaseModel
{
    protected $fillable = [
        'modele_type',
        'modele_id',
        'type',
        'titre',
        'path',
        'thumbnail_path',
        'description',
        'duration',
        'ordre',
        'actif',
        'is_featured',
        'metadata'
    ];

    protected $casts = [
        'metadata' => 'array',
        'is_featured' => 'boolean',
        'actif' => 'boolean',
        'duration' => 'integer'
    ];

    protected static function booted()
    {
        static::saving(function($model){
            if ($model->is_featured) {
                static::where('modele_type', $model->modele_type)
                ->where('modele_id', $model->modele_id)
                ->where('is_featured', true)
                ->update(['is_featured' => false]);
            }
        });
    }

    // Constantes de types
    const PRESENTATION = 'presentation';
    const FORMATION    = 'formation';
    const INSPECTION   = 'inspection';

    public static function types(): array
    {
        return [
            self::PRESENTATION => "Présentation",
            self::FORMATION    => "Formation",
            self::INSPECTION   => "Inspection",
        ];
    }

    public function modele(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Accesseurs pour les URLs
     */
    public function getVideoUrlAttribute(): string
    {
        return $this->path ? Storage::disk(mt_get_storage_disk())->url($this->path) : '';
    }

    public function getThumbnailUrlAttribute(): string
    {
        if (!empty($this->thumbnail_path)) {
            return Storage::disk(mt_get_storage_disk())->url($this->thumbnail_path);
        }
        return asset('images/placeholder-video.jpg');
    }
}