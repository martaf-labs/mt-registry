<?php

namespace Mt\MtViews\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtViews\Contracts\Searchable;
use Mt\MtViews\Enums\CivilitePersonnel;
use Mt\MtViews\Enums\SexePersonnel;
use Mt\MtViews\Enums\TypesContact;
use Mt\MtViews\Traits\AttributesFormatter;
use Mt\MtViews\Traits\HasAutoCasts;
use Mt\MtViews\Traits\HasMultilingualFormatter;
use Mt\MtViews\Traits\HasReference;
use Mt\MtViews\Traits\HasTranslatableCasts;
use Mt\MtViews\Traits\IsSearchable;
use Mt\MtViews\Traits\LogActivityAction;
use Mt\MtViews\Traits\TracksUser;
use Mt\SgniShared\Models\User; 
// HasAutoCasts,

abstract class MtBaseModel extends Model
{
    use HasFactory, SoftDeletes, HasMultilingualFormatter, HasTranslatableCasts, TracksUser, HasReference, LogActivityAction, AttributesFormatter, IsSearchable;

    
    // Scopes 
    public function scopeActif($query)
    {
        return $query->where('actif', true);
    } 
    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

}
