<?php

namespace Mt\MtViews\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtViews\Models\MtBaseModel;
use Mt\MtViews\Traits\LogActivityAction;
use Mt\MtViews\Traits\TracksUser;
use Spatie\Activitylog\LogOptions;

abstract class BaseDocument extends MtBaseModel
{

    protected $fillable = [
        'modele_type',
        'modele_id',
        'titre',
        'type',
        'icone',
        'couleur',
        'path',
        'description',
        'ordre',
        'actif',
        'principale',
        'metadata'
    ];

    protected $casts = [
        'metadata' => 'array',
        'actif' => 'boolean',
        'principale' => 'boolean'
    ];

    protected static function booted()
    {
        static::saving(function($model){
            if ($model->principale) {
                static::where('modele_type', $model->modele_type)
                ->where('modele_id', $model->modele_id)
                ->where('principale', true)
                ->update(['principale' => false]);
            }
        });
    }
    
    // Types de documents
    const MANUEL     = 'manuel';
    const CERTIFICAT = 'certificat';
    const PLAN       = 'plan';
    const FACTURE    = 'facture';
    const RAPPORT    = 'rapport';

    public static function types(): array
    {
        return [
            self::MANUEL     => "Manuel",
            self::CERTIFICAT => "Certificat",
            self::PLAN       => "Plan",
            self::FACTURE    => "Facture",
            self::RAPPORT    => "Rapport",
        ];
    }

    public function modele(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * URL de téléchargement
     */
    public function getDownloadUrlAttribute(): string
    {
        return $this->path ? Storage::disk(mt_get_storage_disk())->url($this->path) : '';
    }

    /**
     * Détermine l'icône automatiquement si non renseignée
     */
    public function getDisplayIconAttribute(): string
    {
        if ($this->icone) return $this->icone;

        $extension = pathinfo($this->path, PATHINFO_EXTENSION);
        return match($extension) {
            'pdf'  => 'fas fa-file-pdf',
            'doc', 'docx' => 'fas fa-file-word',
            'xls', 'xlsx' => 'fas fa-file-excel',
            default => 'fas fa-file-alt'
        };
    }
}