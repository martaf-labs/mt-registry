<?php

namespace Mt\MtViews\Models;


abstract class BaseParametre extends MtBaseModel
{

    public array $translatables = ['valeur', 'description'];

    protected $table = 'parametres';

    protected $fillable = [
        'cle',
        'valeur',
        'description'
    ];

}
