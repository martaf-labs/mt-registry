<?php

namespace Mt\MtViews\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtViews\Enums\CivilitePersonnel;
use Mt\MtViews\Enums\SexePersonnel;
use Mt\MtViews\Enums\TypesContact;
use Mt\MtViews\Models\MtBaseModel;
use Mt\MtViews\Traits\HasReference;
use Mt\MtViews\Traits\LogActivityAction;
use Mt\MtViews\Traits\TracksUser;
use Mt\SgniShared\Models\User;

abstract class BaseContact extends MtBaseModel
{
    protected $fillable = [
        'contactable_type',
        'contactable_id', 
        'type',
        'valeur',
        'icone', 
        'couleur',
        'description',
        'principal',
        'actif'
    ];

    protected $casts = [ 
        'type' => TypesContact::class,
        'principal' => 'boolean',
        'actif' => 'boolean',
    ];

    // relations
    public function contactable(): MorphOne
    {
        return $this->morphTo();
    }   
    
    
    // Scopes 
    public function scopeActifs($query)
    {
        return $query->where('actif', true);
    }


    //les mutateurs
    public function setNomAttribute($valeur)
    {
        $this->attributes['nom']=Str::ucfirst($valeur);
    }

    public function setNomCourtAttribute($valeur)
    {
        $this->attributes['nom_court']=Str::ucfirst($valeur);
    }

}
