<?php

namespace Mt\MtViews\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Mt\MtViews\Models\MtBaseModel;
use Mt\MtViews\Traits\LogActivityAction;
use Mt\MtViews\Traits\TracksUser;

abstract class BaseDevise extends MtBaseModel
{
    protected $fillable = [
        'code',
        'nom', 
        'symbole',
        'icone',
        'couleur', 
        'taux',
        'description',
        'principale',
        'actif'
    ];

    protected $casts = [ 
        'taux' => 'float',
        'principale' => 'boolean',
        'actif' => 'boolean',
    ];
    

    
    // Scopes 
    public function scopeActifs($query)
    {
        return $query->where('actif', true);
    }


    //les mutateurs
    public function setNomAttribute($valeur)
    {
        $this->attributes['nom']=Str::ucfirst($valeur);
    }

}
